/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     朱世平  
 * @version:    1.0
 * Createdate:   2017-1-11 下午3:46:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-11   朱世平      1.0         1.0 Version  
 */

package com.rongji.common.component.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.rongji.common.component.view.CommonUnitView;
import com.rongji.common.util.Constants;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.command.jsdoc.JSCmdLib;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.util.Utils;
import com.rongji.dfish.view.DFishViewFactory;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysOrganize;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.PubService;
import com.rongji.system.sys.service.SysOrganizeService;
import com.rongji.system.sys.service.UserService;
import com.rongji.system.sys.view.UserView;

/**
 * Description: 公用组件弹出控制类 Copyright: Copyright (c)2016 Company: rongji
 * 
 * @author: 朱世平
 * @version: 1.0 Create at: 2017-1-11 下午3:46:55
 * 
 *           Modification History: Date Author Version Description
 *           ------------------------------------------------------------------
 *           2017-1-11 朱世平 1.0 1.0 Version
 */
@Controller
@RequestMapping("/commonUnit")
public class CommonUnitController extends MultiActionController {
	@Autowired
	private UserService userService;
	@Autowired
    private SysOrganizeService orgService;
	@RequestMapping("/deptUsers")
	@ResponseBody
	public Object index() throws Exception {
		BaseView view = new BaseView();

		return view;
	}

	@RequestMapping("/dropDeptOrUser")
	@ResponseBody
	public void dropDeptOrUser(HttpServletRequest request,
			HttpServletResponse response) {
		String type = request.getParameter("type");
		if (Constants.COMBOX_TYPE_USER.equals(type)
				|| Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
			GridPanel grid = DFishViewFactory.getInstance()
					.getDefaultGridPanel();
			// 生成视图
			BaseView view = new BaseView();
			view.setRootPanel(grid);
			// 获得人员下拉列表
			UserView.getOrgGrid(grid);
			outPutXML(response, view);
			return;
		}
		if (Constants.COMBOX_TYPE_DEPT.equals(type)) {
			GridPanel grid = new GridPanel("dept");
			// 生成视图
			BaseView view = new BaseView();
			view.setRootPanel(grid);
			// 获得人员下拉列表
			UserView.getDeptGrid(grid, null);
			outPutXML(response, view);
			return;
		}
	}

	@RequestMapping("/openDeptOrUser")
	public void openDeptOrUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String type = request.getParameter("type");// 弹出控件类型
		String boxId = request.getParameter("boxId");// 控件id
		String cmdName = request.getParameter("cmdName");
		String boxTitle = Utils.getParameter(request, "boxTitle");
		if (Utils.notEmpty(boxTitle)) {
			boxTitle = java.net.URLEncoder.encode(boxTitle.trim(), "UTF-8");
		}
		String hiddenText = request.getParameter("hiddenText");
		String path = request.getParameter("path");
		BaseView view = new BaseView();
		// 分页
		Page page = PubService.getPage(request);
		// 只有用户界面
		if (Constants.COMBOX_TYPE_USER.equals(type)) {
			// 根据参数查询人员信息
			List<String[]> datas = userService.getsysUserFormDio(page, null);
			// 生成面板
			VerticalPanel root = CommonUnitView.buildUserPanel(datas, page,
					null);
			view.setRootPanel(root);
			// 添加保存按钮点击事件
			view.add(new SubmitCommand("addUser",
					"vm:|commonUnit/showNameAndId?boxId=" + boxId + "&cmdName="
							+ cmdName + "&boxTitle=" + boxTitle + "&type="
							+ type + "&hiddenText=" + hiddenText + "&path="
							+ path, null, false));
			// 添加关闭按钮
			view.add(new JSCommand("cannel", "DFish.g_dialog(this).close();"));
			// 添加查询按钮
			view.add(new SubmitCommand("search", "vm:|commonUnit/search?type="
					+ type, "searchPanelHorizon", false));
			// 添加翻页按钮
			// =new AjaxCommand("changeProv","commonUnit/turnPage?cp=$0");
			view.add(new AjaxCommand("turnPage",
					"vm:|commonUnit/turnPage?cp=$0"));
			outPutXML(response, view);
		}
		// 只有单一部门与部门用户界面
		if (Constants.COMBOX_TYPE_DEPT.equals(type)
				|| Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
			List<SysUser2> userList = null;
			if (Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
				userList = userService.getUserNo();
			}
			List<SysDept> datas = userService.getDeptNo(null);
			// 生成面板
			VerticalPanel root = CommonUnitView.buildShowPanel(type,datas, userList,null,false);
			view.setRootPanel(root);
			// 添加保存按钮点击事件
			view.add(new SubmitCommand("addDept",
					"vm:|commonUnit/showNameAndId?boxId=" + boxId + "&cmdName="
							+ cmdName + "&boxTitle=" + boxTitle + "&type="
							+ type + "&hiddenText=" + hiddenText + "&path="
							+ path, null, false));
			// 添加关闭按钮
			view.add(new JSCommand("cannel", "DFish.g_dialog(this).close();"));
			// 添加查询按钮
			view.add(new SubmitCommand("search", "vm:|commonUnit/search?type="
					+ type, "searchPanelHorizon", false));
			outPutXML(response, view);

		}
		//机构
		if (Constants.COMBOX_TYPE_ORG.equals(type)) {
			List<SysUser2> userList = null;
			if (Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
				userList = userService.getUserNo();
			}
			// 生成面板
			VerticalPanel root = CommonUnitView.buildShowPanel(type,null, null,null,false);
			view.setRootPanel(root);
			// 添加保存按钮点击事件
			view.add(new SubmitCommand("addDept",
					"vm:|commonUnit/showNameAndId?boxId=" + boxId + "&cmdName="
							+ cmdName + "&boxTitle=" + boxTitle + "&type="
							+ type + "&hiddenText=" + hiddenText + "&path="
							+ path, null, false));
			// 添加关闭按钮
			view.add(new JSCommand("cannel", "DFish.g_dialog(this).close();"));
			// 添加查询按钮
			view.add(new SubmitCommand("search", "vm:|commonUnit/search?type="
					+ type, "searchPanelHorizon", false));
			outPutXML(response, view);

		}

	}

	/**
	 * 用户分页
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @author 朱世平
	 */
	@RequestMapping("/turnPage")
	public void turnPage(HttpServletRequest request, HttpServletResponse response) {
		Page page = PubService.getPage(request);
		List<String[]> datas = userService.getsysUserFormDio(page, null);
		// 生成面板
		VerticalPanel root = CommonUnitView.buildUserPanel(datas, page, null);
		CommandGroup cg = new CommandGroup("cg");
		UpdateCommand up = new UpdateCommand("up");
		cg.add(up);
	    up.setContent(root);
		outPutXML(response, cg);
	}

	@RequestMapping("/search")
	public void search(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String type = request.getParameter("type");// 弹出控件类型
		// 分页
		Page page = PubService.getPage(request);
		CommandGroup cg = new CommandGroup("cg");
		UpdateCommand up = new UpdateCommand("up");
		cg.add(up);
		if (Constants.COMBOX_TYPE_USER.equals(type)) {
			SysUser2 user = new SysUser2();
			this.bind(request, user);
			// 根据参数查询人员信息
			List<String[]> datas = userService.getsysUserFormDio(page, user);
			// 生成面板
			VerticalPanel root = CommonUnitView.buildUserPanel(datas, page,
					null);
			up.setContent(root);
			outPutXML(response, cg);
			return;
		}
		// 只有单一部门与部门用户界面
		if (Constants.COMBOX_TYPE_DEPT.equals(type)
				|| Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
			List<SysUser2> userList = null;
			if (Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
				userList = userService.getUserNo();

			}
			SysDept dept = new SysDept();
			this.bind(request, dept);
			List<SysDept> datas = userService.getDeptNo(dept);
			// 生成面板
			VerticalPanel root = CommonUnitView.buildShowPanel(type,datas, userList,null,true);
			up.setContent(root);
			outPutXML(response, cg);
			return;
		}
		if (Constants.COMBOX_TYPE_ORG.equals(type)) {
			SysOrganize entity = new SysOrganize();
			this.bind(request, entity);
			List<SysOrganize> datas = orgService.getOrgList(entity);
			// 生成面板
			VerticalPanel root = CommonUnitView.buildShowPanel(type,null, null,datas,true);
			up.setContent(root);
			outPutXML(response, cg);
		}
	}

	private List<String> getSelectedFuncIds(HttpServletRequest request,
			String type) {
		List<String> operIds = new ArrayList<String>();
		java.util.Enumeration<String> names = request.getParameterNames();
		while (names.hasMoreElements()) {
			String name = names.nextElement();
			if (name.startsWith(type) && "1".equals(request.getParameter(name))) {
				operIds.add(name.substring(2));
			}
		}
		return operIds;
	}

	/**
	 * 回显选中的用户或部门等信息
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @return 无
	 * @throws Exception
	 */
	@RequestMapping("/showNameAndId")
	public void showUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String boxId = request.getParameter("boxId");
		String cmdName = request.getParameter("cmdName");
		String type = request.getParameter("type");
		String path = request.getParameter("path");
		String boxTitle = Utils.getParameter(request, "boxTitle");
		String parm = "CB";
		// 选择用户
		if (Constants.COMBOX_TYPE_DEPT_USER.equals(type)) {
			parm = "ue";
		}
		String hiddenText = request.getParameter("hiddenText");
		UpdateCommand up = new UpdateCommand("up");
		List<String> depts = getSelectedFuncIds(request, parm);
		String[] users = request.getParameterValues("selectItem");
		StringBuilder userName = new StringBuilder("");
		StringBuilder userId = new StringBuilder("");
		if (Constants.COMBOX_TYPE_USER.equals(type)) {
			int size = users.length;
			for (int i = 0 ;i < size;i++) {
				String v = users[i];
				String[] idAndName = v.split("-");
				if(i==0){
					userName.append(idAndName[1]);
					userId.append(idAndName[0]);
				}else{
					userName.append(","+idAndName[1] );
					userId.append(","+idAndName[0]);
				}
				
			}
		}
		if (Constants.COMBOX_TYPE_DEPT.equals(type)
				|| Constants.COMBOX_TYPE_DEPT_USER.equals(type) || Constants.COMBOX_TYPE_ORG.equals(type)) {
			int size = depts.size();
			for (int i = 0 ;i < size;i++) {
				String v = depts.get(i);
				String[] idAndName = v.split("-");
				if(i==0){
					userName.append(idAndName[0]);
					userId.append(idAndName[1]);
				}else{
					userName.append(","+idAndName[0]);
					userId.append(","+idAndName[1]);
				}
				
			}
		}
		Onlinebox box = CommonUnitView.getCommonBox(boxId, userName.toString(),
				boxTitle, cmdName, type);
		box.setRowHeight(30);
		up.setContent(box);
		UpdateCommand up1 = new UpdateCommand("up");
		Hidden hid = new Hidden(hiddenText, userId.toString());
		up1.setContent(hid);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/" + path);
		cg.add(up);
		cg.add(up1);
		CommandGroup dialog = new CommandGroup("dialog");
		dialog.add(cg);
		dialog.add(JSCmdLib.dialogClose(""));
		outPutXML(response, dialog);
	}

}

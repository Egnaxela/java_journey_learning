/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     朱世平  
 * @version:    1.0
 * Createdate:   2017-1-11 下午6:27:06  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-11   朱世平      1.0         1.0 Version  
 */  


package com.rongji.common.component.dao;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.rongji.system.common.util.DaoHelper;
import com.rongji.system.entity.SysDept;
import com.sun.xml.ws.policy.privateutil.PolicyUtils.Collections;

/**  
 * Description:   
 * Copyright:   Copyright (c)2016 
 * Company:     rongji  
 * @author:     朱世平  
 * @version:    1.0  
 * Create at:   2017-1-11 下午6:27:06  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-11   朱世平     1.0         1.0 Version  
 */

public class CommonUnitDao {
	
	/**
	 * 获取所有部门
	* <p>描述:</p>
	* @return
	* @author 朱世平
	 */
    public List<SysDept> getDeptList(){
    	String sql = " select e from SysDept e ";
    	return DaoHelper.getSystemPageDAO().getQueryList(sql);
    }
}

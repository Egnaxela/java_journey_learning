/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     朱世平  
 * @version:    1.0
 * Createdate:   2017-1-11 下午4:39:32  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-11   朱世平      1.0         1.0 Version  
 */

package com.rongji.common.component.view;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.util.StringHelper;
import org.springframework.util.CollectionUtils;

import com.rongji.common.util.BasicDataLoad;
import com.rongji.common.util.Constants;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.HorizontalPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.engines.xmltmpl.component.TreeItem;
import com.rongji.dfish.engines.xmltmpl.component.TreePanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysOrganize;
import com.rongji.system.entity.SysUser2;

/**
 * Description: Copyright: Copyright (c)2016 Company: rongji
 * 
 * @author: 朱世平
 * @version: 1.0 Create at: 2017-1-11 下午4:39:32
 * 
 *           Modification History: Date Author Version Description
 *           ------------------------------------------------------------------
 *           2017-1-11 朱世平 1.0 1.0 Version
 */

public class CommonUnitView {

	/**
	 * 返回一个combox
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param id
	 *            组件id
	 * @param value
	 *            选中的值
	 * @param title
	 *            显示名
	 * @param cmdName
	 *            事件名
	 * @param type
	 *            下拉取值类型
	 * @return
	 * @author 朱世平
	 */
	public static Onlinebox getCommonBox(String id, String value, String title,
			String cmdName, String type) {
		if (StringHelper.isEmpty(cmdName)) {
			cmdName = "openDeptOrUser";
		}
		//"vm:|commonUnit/dropDeptOrUser?type=" + type
		Onlinebox orgBox = new Onlinebox(id, title, value,
				null, "VM(this).cmd('"
						+ cmdName + "')", -1, false, false, false, "", true);
		orgBox.setMultiple(true);
		return orgBox;
	}

	/**
	 * 获取弹出框
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param id
	 *            编号
	 * @param title
	 *            显示标题
	 * @param name
	 * @param type
	 *            弹出控件类型：0：只有部门，1：只有人员，2：人员与部门
	 * @param postion
	 * @return
	 * @author 朱世平
	 */
	public static DialogCommand getDialogCommand(String cmdName, String boxId,
			String title, String name, String type,
			String hiddenText,String path,String boxTitle) {
		int width = 380;
		if (Constants.COMBOX_TYPE_USER.equals(type)) {
			width = DialogCommand.WIDTH_MEDIUM;
		}
		StringBuilder sb = new StringBuilder();
		if (Utils.notEmpty(boxTitle)) {
			try {
				sb.append("&boxTitle=").append(
						java.net.URLEncoder.encode(boxTitle.trim(), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				return null;
			}
		}
		DialogCommand dc = new DialogCommand(cmdName,
				ViewFactory.ID_DIALOG_STANDARD, title, "lmOrgSelector", width,
				DialogCommand.HEIGHT_LARGE, DialogPosition.middle,
				"vm:|commonUnit/openDeptOrUser?type=" + type + "&boxId="
						+ boxId + "&cmdName=" + cmdName + "&hiddenText="
						+ hiddenText+"&path="+path+sb.toString());
		dc.setPophide(true);
		return dc;
	}

	/**
	 * 创建用户选择
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param datas
	 * @param page
	 * @param sysUser
	 * @return
	 * @author 朱世平
	 */
	public static VerticalPanel buildUserPanel(List<String[]> datas, Page page,
			SysUser2 sysUser) {
		// 生成视图
		BaseView view = ViewTemplate.buildIndexHasBtnView(false);
		// 设置搜索栏面板宽高
		VerticalPanel rootPanel = new VerticalPanel("userRootPanel",
				"40,350,40,60");
		HorizontalPanel searchPanel = new HorizontalPanel("searchPanelHorizon",
				"*,200");
		rootPanel.addSubPanel(searchPanel);
		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_MAIN_SEARCH);
		searchForm.add(0, 0, new Text("userName", "用户名称", "", 10));
		searchForm.add(0, 1, new Text("loginName", "登录名", "", 10));
		searchPanel.setStyleClass("bd-onlybottom  bd-title");
		ButtonBarPanel btnPanel = new ButtonBarPanel("userBtnPanel");
		btnPanel.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('search')"));
		btnPanel.addButton(new ClickButton("", "   刷新   ", "VM(this).reload();"));
		btnPanel.setStyle("margin-top:-3px;margin-bottom:0;");
		searchPanel.addSubPanel(searchForm);
		searchPanel.addSubPanel(btnPanel);
		PagePanel pagePanel = new PagePanel("showUserPage");
		// 添加分页面板
		
		pagePanel.setCurrentRecords(datas.size());
		pagePanel.setCurrentPage(page.getCurrentPage());
		pagePanel.setMaxPage(page.getPageCount());
		pagePanel.setSumRecords(page.getRowCount());
		pagePanel.setClk("VM(this).cmd('turnPage',$0)");
		GridPanel userGrid = getUserGridView(datas);
		rootPanel.addSubPanel(userGrid);
		rootPanel.addSubPanel(pagePanel);
		ButtonBarPanel bbp = new ButtonBarPanel("btn");
		bbp.setStyle("padding-right:15px;margin-top:-60px;");
		bbp.setAlign(Align.right);
		bbp.addButton(new ClickButton("img/b/save.gif", "确定",
				"VM(this).cmd('addUser');"));
		bbp.addButton(new ClickButton("img/b/new.gif", "取消",
				"VM(this).cmd('cannel');"));
		// 关闭对话框
		view.add(new JSCommand("cannel", "DFish.g_dialog(this).close();"));
		rootPanel.addSubPanel(bbp);
		return rootPanel;
	}

	/**
	 * 创建 部门显示面板
	 */
	public static VerticalPanel buildShowPanel(String type,List<SysDept> depts,
			List<SysUser2> userList,List<SysOrganize> orgList,boolean searchFlag) {
		// 生成视图
		BaseView view = ViewTemplate.buildIndexHasBtnView(false);
		// 设置搜索栏面板宽高
		VerticalPanel rootPanel = new VerticalPanel("deptRootPanel",
				"80,*,60");
		HorizontalPanel searchPanel = new HorizontalPanel("searchPanelHorizon",
				"*,80");
		searchPanel.setStyleClass("bd-onlybottom  bd-title");
		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_MAIN_SEARCH);
		
		String name = Constants.COMBOX_TYPE_ORG.equals(type)?"orgNameSc":Constants.COMBOX_TYPE_DEPT.equals(type)?"deptName":"userName";
		String code = Constants.COMBOX_TYPE_ORG.equals(type)?"orgCode":Constants.COMBOX_TYPE_DEPT.equals(type)?"deptNo":"loginName";
		String showName = Constants.COMBOX_TYPE_ORG.equals(type)?"机构名称":Constants.COMBOX_TYPE_DEPT.equals(type)?"部门名称":"用户名";
		String showCode = Constants.COMBOX_TYPE_ORG.equals(type)?"机构代码":Constants.COMBOX_TYPE_DEPT.equals(type)?"部门编号":"登陆名";
		searchForm.add(0, 0, new Text(name, showName, "", -1));
		searchForm.add(1, 0, new Text(code, showCode, "", 10));
		ButtonBarPanel btnPanel = new ButtonBarPanel("userBtnPanels");
		btnPanel.setAlign(Align.center);
//		btnPanel.setStyleClass("bd-onlybottom  bd-title");
		btnPanel.setCellspacing(10);
		btnPanel.setDirectionVertical(true);
		btnPanel.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('search')"));
		btnPanel.addButton(new ClickButton("", "   刷新   ", "VM(this).reload();"));
		btnPanel.setStyle("margin-bottom:0;text-align:right");
		searchPanel.addSubPanel(searchForm);
		searchPanel.addSubPanel(btnPanel);
		
		rootPanel.addSubPanel(searchPanel);
	
		TreePanel treePanel = new TreePanel("deptTree");
//		treePanel.addTreeItem(root);
		treePanel.setScroll(Scroll.auto);
		buildShowTree(type,treePanel, depts, userList,orgList,searchFlag);
		rootPanel.addSubPanel(treePanel);
		ButtonBarPanel bbp = new ButtonBarPanel("btn");
		bbp.setStyle("padding-right:15px;margin-top:-60px;");
		bbp.setAlign(Align.right);
		bbp.addButton(new ClickButton("img/b/save.gif", "确定",
				"VM(this).cmd('addDept');"));
		bbp.addButton(new ClickButton("img/b/new.gif", "取消",
				"VM(this).cmd('cannel');"));
		// 关闭对话框
		view.add(new JSCommand("cannel", "DFish.g_dialog(this).close();"));
		rootPanel.addSubPanel(bbp);
		return rootPanel;
	}

	/**
	 * 构建部门树
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param root
	 * @param depts
	 * @author 朱世平
	 */
	public static void buildShowTree(String type,TreePanel root, List<SysDept> depts,
			List<SysUser2> listUsers,List<SysOrganize> orgList,boolean searchFlag) {
		Map map = new HashMap();//
		//机构数据展示
		if(Constants.COMBOX_TYPE_ORG.equals(type)){
			showOrgTreePanel(orgList,root,searchFlag);
			return;
		}
		//部门与用户都需要部门数据，为空将不执行相关处理操作
		if (CollectionUtils.isEmpty(depts)) {
			return;
		}
		boolean isUserFlag = CollectionUtils.isEmpty(listUsers);
		TreeItem rootItem = new TreeItem();
		rootItem.setProperty(TreeItem.KEY_PRIMARY_KEY, "root");
		rootItem.setProperty(TreeItem.KEY_TEXT, isUserFlag?"所有部门":"所有用户");
		rootItem.setProperty(TreeItem.KEY_CHECKBOX_NAME, "root");
		root.addTreeItem(rootItem);
		for (SysDept dept : depts) {
			TreeItem item = new TreeItem();
			item.setProperty(TreeItem.KEY_PRIMARY_KEY, dept.getDeptNo());
			item.setProperty(TreeItem.KEY_TEXT, dept.getDeptName());
			item.setProperty(TreeItem.KEY_CHECKBOX_NAME,
					"CB" + dept.getDeptName() + "-" + dept.getDeptNo());
			item.setProperty(TreeItem.KEY_CHECKBOX_VALUE,true);
			map.put(dept.getDeptNo(), item);
		}
		// 添加部门节点
		for (SysDept dept : depts) {
			String deptNo = dept.getDeptNo();
			String parentNo = dept.getParentNo();
			// 如果parentNo为空，说明为一级节点
			if (StringHelper.isEmpty(parentNo)) {
				TreeItem item = (TreeItem) map.get(deptNo);
				rootItem.addTreeItem(item);
				continue;
			}
			// 如果该节点是子节点，查找其父节点，将其加到父节点上
			TreeItem sonItem = (TreeItem) map.get(deptNo);
			TreeItem parentItem = (TreeItem) map.get(parentNo);
			if(null!=parentItem)
				parentItem.addTreeItem(sonItem);
			else
				rootItem.addTreeItem(sonItem);
		}
		if(CollectionUtils.isEmpty(listUsers)){
			return;
		}
		// 添加用户节点
		TreeItem item = new TreeItem();
		item.setProperty(TreeItem.KEY_PRIMARY_KEY, "otherDeptNo");
		item.setProperty(TreeItem.KEY_TEXT, "未知部门人员");
		item.setProperty(TreeItem.KEY_CHECKBOX_NAME, "otherDeptNo");
		root.addTreeItem(item);
		for (SysUser2 user : listUsers) {
			String deptNo = user.getDeptNo();
			TreeItem userItem = new TreeItem();
			userItem.setProperty(TreeItem.KEY_PRIMARY_KEY, user.getUserId());
			userItem.setProperty(TreeItem.KEY_ICON,"img/b/user-on.gif");
			userItem.setProperty(TreeItem.KEY_TEXT, user.getUserName());
			userItem.setProperty(TreeItem.KEY_CHECKBOX_NAME,
					"ue" + user.getUserName() + "-" + user.getUserId());
			userItem.setProperty(TreeItem.KEY_CHECKBOX_VALUE,true);//设置不带级联模式
			if (StringHelper.isEmpty(deptNo)) {
				item.addTreeItem(userItem);
			} else {
				String[] deptNos = deptNo.split(",");
				for (int i = 0; i < deptNos.length; i++) {
					TreeItem deptItem = (TreeItem) map.get(deptNos[i]);
					deptItem.addTreeItem(userItem);
				}

			}
		}

	}

	/**
	 * 展示机构树
	* <p>描述:</p>
	* @param orgList
	* @param root
	* @param searchFlag查询标识：true为查询false不是
	* @author 朱世平
	 */
    public static void showOrgTreePanel(List<SysOrganize> orgList,TreePanel root,boolean searchFlag){
    	//如果不是查询数据，使用缓存数据构建权
    	if(CollectionUtils.isEmpty(orgList)&&!searchFlag){
    		TreeItem item = (TreeItem) BasicDataLoad.orgTreeMap.get("00000000");
			root.addTreeItem(item);
    		return;
    	}else{
    		TreeItem treeItem = new TreeItem();
    		treeItem.setProperty(TreeItem.KEY_PRIMARY_KEY, "00000000");
    		treeItem.setProperty(TreeItem.KEY_TEXT, "国家质检总局本部");
    		treeItem.setProperty(TreeItem.KEY_CHECKBOX_NAME, "00000000");
    		root.addTreeItem(treeItem);
    		if(CollectionUtils.isEmpty(orgList)){
    			return;
    		}
    		Map treeMap = new HashMap();
    		for(SysOrganize sys:orgList){
    			TreeItem sonItem = new TreeItem();
    			sonItem.setProperty(TreeItem.KEY_PRIMARY_KEY, sys.getCategoryCode());
    			sonItem.setProperty(TreeItem.KEY_TEXT, sys.getOrgNameSc());
    			sonItem.setProperty(TreeItem.KEY_CHECKBOX_NAME,
    					"CB" + sys.getOrgNameSc() + "-" + sys.getOrgCode());
    			sonItem.setProperty(TreeItem.KEY_CHECKBOX_VALUE, true);
    			treeMap.put(sys.getCategoryCode(), sonItem);
    		}
    		for(SysOrganize sys:orgList){
    		    String code = sys.getCategoryCode();
    		    if("00000000".equals(code)){
    		    	continue;
    		    }
    		    String parentCode = sys.getSeniorCategoryCode();
		    	TreeItem sonItem = (TreeItem) treeMap.get(code);
    		    if(treeMap.containsKey(parentCode)&&!"00000000".equals(parentCode)){
    		    	TreeItem item = (TreeItem) treeMap.get(parentCode);
    		    	item.addTreeItem(sonItem);
    		    }else{
    		    	treeItem.addTreeItem(sonItem);
    		    }
    		    
    		}
    	}
    }
	
	/**
	 * 获取人员弹出框表格内容
	 * 
	 * @param datas
	 *            用户信息
	 * @return 无
	 * @throws 无
	 */
	public static GridPanel getUserGridView(List<String[]> datas) {
		GridPanel grid = new GridPanel("userGrid");
		grid.setData(datas);
		grid.setNobr(true);

		// 添加列 ,添加一个隐藏列
		grid.addColumn(GridColumn.hidden(0, "code"));
		// 添加显示内容
		GridColumn code = GridColumn.checkbox("code", "20");
		code.setStyle("font-size:14px;text-overflow: ellipsis;overflow: hidden;");
		grid.addColumn(code);

		GridColumn dept = GridColumn.hidden(0, "U1");
		grid.addColumn(dept);

		GridColumn note = GridColumn.text(1, "U2", "姓名", "*");
		note.setStyle("font-size:14px;text-overflow: ellipsis;overflow: hidden;");
		grid.addColumn(note);

		// 登录账号
		GridColumn loginname = GridColumn.text(2, "U3", "登录名", "*");
		loginname
				.setStyle("font-size:14px;text-overflow: ellipsis;overflow: hidden;");
		grid.addColumn(loginname);


		// 用户状态
		GridColumn status = GridColumn.text(4, "U5", "状态", "*");
		status.setStyle("font-size:14px;text-overflow: ellipsis;overflow: hidden;");
		grid.addColumn(status);

		return grid;
	}

}

package com.rongji.common.mfile;

public abstract class AbstractFileManager implements FileManager {

	@Override
	public String upload(byte[] file, String extName) throws Exception {
		return upload(file, extName, null);
	}

	@Override
	public String upload(byte[] file) throws Exception {
		return upload(file, null, null);
	}

	@Override
	public String upload(FileAdapter fileAdapter) throws Exception {
		return upload(fileAdapter.getFile(), fileAdapter.getExtName(),
				fileAdapter.getMetadata());
	}

}

package com.rongji.common.mfile;

import java.util.Map;

/**
 * 文件转换接口
 * <p>
 * 文件管理器接受这样的接口作为文件的代理
 * 
 * @author whf
 * 
 */
public interface FileAdapter {

	/**
	 * 返回文件字节数组
	 * 
	 * @return 文件字节数组
	 */
	public byte[] getFile();

	/**
	 * 返回文件扩展名，不含[.]
	 * 
	 * @return 文件扩展名
	 */
	public String getExtName();

	/**
	 * 返回文件元数据集合
	 * 
	 * @return 文件元数据集合
	 */
	public Map<String, String> getMetadata();
}

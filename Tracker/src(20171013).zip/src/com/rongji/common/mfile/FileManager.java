package com.rongji.common.mfile;

import java.io.IOException;
import java.util.Map;

/**
 * 文件管理接口
 * <p>
 * 主要定义文件的上传，下载等功能
 * 
 * @author whf
 * 
 */
public interface FileManager {

	/**
	 * 上传文件，参数为文件代理对象
	 * 
	 * @param fileAdapter
	 *            文件代理对象
	 * @return 文件ID
	 * @throws Exception
	 */
	public String upload(FileAdapter fileAdapter) throws Exception;

	/**
	 * 上传文件
	 * 
	 * @param file
	 *            文件字节数组
	 * @return 文件ID
	 * @throws Exception
	 */
	public String upload(byte[] file) throws Exception;

	/**
	 * 上传文件
	 * 
	 * @param file
	 *            文件字节数组
	 * @param extName
	 *            文件扩展名称，不包含[.]
	 * @return 文件ID
	 * @throws Exception
	 */
	public String upload(byte[] file, String extName) throws Exception;

	/**
	 * 上传文件
	 * 
	 * @param file
	 *            文件字节数组
	 * @param extName
	 *            文件扩展名称，不包含[.]
	 * @param metadata
	 *            文件元数据描述
	 * @return 文件ID
	 * @throws Exception
	 */
	public String upload(byte[] file, String extName,
			Map<String, String> metadata) throws Exception;

	/**
	 * 下载文件
	 * 
	 * @param fileId
	 *            文件ID
	 * @return 文件字节数组
	 * @throws IOException
	 */
	public byte[] download(String fileId) throws Exception;

	/**
	 * 获取文件元数据描述
	 * 
	 * @param fileId
	 *            文件ID
	 * @return 元数据描述
	 * @throws Exception
	 */
	public Map<String, String> getMetadata(String fileId) throws Exception;

	/**
	 * 获取文件下载地址，应该返回一个能下载文件的完整URL地址
	 * 
	 * @param fileId
	 *            文件ID
	 * @return 文件URL地址
	 */
	public String getDownloadUrl(String fileId);

	/**
	 * 根据文件ID删除文件
	 * 
	 * @param fileId
	 *            文件ID
	 * @return 删除的数量
	 * @throws Exception
	 */
	public int deleteFile(String fileId) throws Exception;
}

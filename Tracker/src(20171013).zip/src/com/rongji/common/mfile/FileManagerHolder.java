package com.rongji.common.mfile;

public class FileManagerHolder {

	private static FileManager fileManager;

	public static FileManager getFileManager() {
		return fileManager;
	}

	public static void setFileManager(FileManager fm) {
		fileManager = fm;
	}
}

package com.rongji.common.mfile.impl;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.csource.common.NameValuePair;
import org.csource.fastdfs.ClientGlobal;
import org.csource.fastdfs.StorageClient1;
import org.csource.fastdfs.StorageServer;
import org.csource.fastdfs.TrackerClient;
import org.csource.fastdfs.TrackerGroup;
import org.csource.fastdfs.TrackerServer;

import com.rongji.common.mfile.AbstractFileManager;

public class FastdfsFileManager extends AbstractFileManager {

	private int networkTimeout;
	private int connectTimeout;
	private String charset;
	private String trackerServer;
	private static final int DEFAULT_PORT = 22122;
	TrackerClient tracker;

	public void init() {
		if (networkTimeout <= 0) {
			networkTimeout = 10000;// 默认网络超时10秒
		}
		if (connectTimeout <= 0) {
			connectTimeout = 10000;// 默认连接超时10秒
		}
		if (charset == null || "".equals(charset)) {
			charset = "UTF-8";
		}
		if (trackerServer == null || "".equals(trackerServer)) {
			throw new RuntimeException("fastdfs文件管理，参数trackerServer不能为空");
		}
		ClientGlobal.setG_charset(charset);
		ClientGlobal.setG_network_timeout(networkTimeout);
		ClientGlobal.setG_connect_timeout(connectTimeout);
		String[] trackers;
		if (trackerServer.contains(";")) {
			trackers = trackerServer.split(";");
		} else {
			trackers = new String[] { trackerServer };
		}
		InetSocketAddress[] isas = new InetSocketAddress[trackers.length];
		int i = 0;
		for (String tracker : trackers) {
			int index = tracker.lastIndexOf(":");
			String ip;
			int port;
			if (index <= 0) {
				ip = tracker;
				port = DEFAULT_PORT;
			} else {
				ip = tracker.substring(0, index);
				port = Integer.parseInt(tracker.substring(index + 1));
			}
			isas[i++] = new InetSocketAddress(ip, port);
		}
		TrackerGroup tg = new TrackerGroup(isas);
		ClientGlobal.setG_tracker_group(tg);
		tracker = new TrackerClient();
	}

	@Override
	public byte[] download(String fileId) throws Exception {
		TrackerServer trackerServer = tracker.getConnection();
		try {
			StorageServer storageServer = null;
			StorageClient1 client = new StorageClient1(trackerServer,
					storageServer);
			return client.download_file1(fileId);
		} finally {
			trackerServer.close();
		}
	}

	@Override
	public String getDownloadUrl(String fileId) {
		throw new RuntimeException("当前功能暂未实现，联系whf...");
	}

	@Override
	public Map<String, String> getMetadata(String fileId) throws Exception {
		TrackerServer trackerServer = tracker.getConnection();
		try {
			StorageServer storageServer = null;
			StorageClient1 client = new StorageClient1(trackerServer,
					storageServer);
			NameValuePair[] nvPairs = client.get_metadata1(fileId);
			if (nvPairs == null || nvPairs.length < 1) {
				return new HashMap<String, String>();
			}
			Map<String, String> metadatas = new HashMap<String, String>();
			for (NameValuePair nvp : nvPairs) {
				metadatas.put(nvp.getName(), nvp.getValue());
			}
			return metadatas;
		} finally {
			trackerServer.close();
		}
	}

	@Override
	public String upload(byte[] file, String extName,
			Map<String, String> metadata) throws Exception {
		TrackerServer trackerServer = tracker.getConnection();
		try {
			StorageServer storageServer = null;
			StorageClient1 client = new StorageClient1(trackerServer,
					storageServer);
			NameValuePair[] metaList = null;
			if (metadata != null && metadata.size() > 0) {
				metaList = new NameValuePair[metadata.size()];
				Iterator<Entry<String, String>> itr = metadata.entrySet()
						.iterator();
				int i = 0;
				while (itr.hasNext()) {
					Entry<String, String> ety = itr.next();
					metaList[i++] = new NameValuePair(ety.getKey(), ety
							.getValue());
				}
			}
			return client.upload_file1(file, extName, metaList);
		} finally {
			trackerServer.close();
		}
	}

	public int getNetworkTimeout() {
		return networkTimeout;
	}

	public void setNetworkTimeout(int networkTimeout) {
		this.networkTimeout = networkTimeout;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getTrackerServer() {
		return trackerServer;
	}

	public void setTrackerServer(String trackerServer) {
		this.trackerServer = trackerServer;
	}

	@Override
	public int deleteFile(String fileId) throws Exception {
		TrackerServer trackerServer = tracker.getConnection();
		try {
			StorageServer storageServer = null;
			StorageClient1 client = new StorageClient1(trackerServer,
					storageServer);
			int rl = client.delete_file1(fileId);
			if (rl != 0) {
				return 0;
			}
			return 1;
		} finally {
			trackerServer.close();
		}
	}

}

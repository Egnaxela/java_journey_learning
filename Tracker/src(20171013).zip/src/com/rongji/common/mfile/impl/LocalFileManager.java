package com.rongji.common.mfile.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import com.rongji.common.mfile.AbstractFileManager;

public class LocalFileManager extends AbstractFileManager {

	private String storeLocation;
	private static final String DATAS = "datas";
	private static final String PPS = "ABCDEFGHIJKLMOPQRSTUVWXYZ";
	private static int l = PPS.length();
	private Random ran = new Random();
	private String datasLocation;

	public void init() {
		if (storeLocation == null || "".equals(storeLocation)) {
			throw new RuntimeException("本地文件存储，未配置参数storeLocation");
		}
		initPath();
	}

	private void initPath() {
		datasLocation = storeLocation + File.separator + DATAS;
		File f = new File(datasLocation);
		if (!f.exists() || f.isFile()) {
			f.mkdirs();
		}
		char[] chars = PPS.toCharArray();
		for (char c : chars) {
			File fs = new File(datasLocation + File.separator + c);
			if (fs.exists() && fs.isDirectory()) {
				continue;
			}
			fs.mkdir();
		}
	}

	@Override
	public byte[] download(String fileId) throws Exception {
		char c = fileId.charAt(0);
		File f = new File(datasLocation + File.separator + c + File.separator
				+ fileId);
		if (!f.exists() || f.isDirectory()) {
			return null;
		}
		FileInputStream fis = new FileInputStream(f);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int bl = 4096;
		byte[] buff = new byte[bl];
		int len = 0;
		while ((len = fis.read(buff)) != -1) {
			baos.write(buff, 0, len);
		}
		fis.close();
		return baos.toByteArray();
	}

	@Override
	public String getDownloadUrl(String fileId) {
		return null;
	}

	@Override
	public Map<String, String> getMetadata(String fileId) {
		return null;
	}

	@Override
	public String upload(byte[] file, String extName,
			Map<String, String> metadata) throws Exception {
		int c = ran.nextInt(l);
		char x = PPS.charAt(c);
		String fileId = x + uuid();
		File f = new File(datasLocation + File.separator + x + File.separator
				+ fileId);
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(file);
		fos.flush();
		fos.close();
		return fileId;
	}

	private String uuid() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	public String getStoreLocation() {
		return storeLocation;
	}

	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}

	@Override
	public int deleteFile(String fileId) {
		char c = fileId.charAt(0);
		File f = new File(datasLocation + File.separator + c + File.separator
				+ fileId);
		if (!f.exists() || f.isDirectory()) {
			return 0;
		}
		f.delete();
		return 1;
	}
}

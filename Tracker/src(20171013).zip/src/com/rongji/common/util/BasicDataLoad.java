/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     朱世平  
 * @version:    1.0
 * Createdate:   2017-1-10 上午11:12:02  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-10   朱世平      1.0         1.0 Version  
 */

package com.rongji.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.rongji.dfish.engines.xmltmpl.component.TreeItem;
import com.rongji.system.common.util.DaoHelper;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysFunction;
import com.rongji.system.entity.SysOrganize;

/**
 * Description: Copyright: Copyright (c)2016 Company: rongji
 * 
 * @author: 朱世平
 * @version: 1.0 Create at: 2017-1-10 上午11:12:02
 * 
 *           Modification History: Date Author Version Description
 *           ------------------------------------------------------------------
 *           2017-1-10 朱世平 1.0 1.0 Version
 */

public class BasicDataLoad extends HttpServlet {
	public static Map menuMap = new HashMap();
	public static Map deptMap = new HashMap();
	public static Map orgMap = new HashMap();
	public static Map orgTreeMap = new HashMap();

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		loadMenu();// 加载菜单数据
		loadDept();// 加载部门数据
		loadOrg();// 加载机构数据
	}

	public static void loadOrg() {
		String sql = " select e from SysOrganize e ";
		List<SysOrganize> list = DaoHelper.getSystemPageDAO().getQueryList(sql);
		for (SysOrganize sys : list) {
			String orgCode = sys.getOrgCode();
			orgMap.put(orgCode, sys);
			TreeItem sonItem = new TreeItem();
			sonItem.setProperty(TreeItem.KEY_PRIMARY_KEY, sys.getCategoryCode());
			sonItem.setProperty(TreeItem.KEY_TEXT, sys.getOrgNameSc());
			sonItem.setProperty(TreeItem.KEY_CHECKBOX_NAME,
					"CB" + sys.getOrgNameSc() + "-" + sys.getOrgCode());
			sonItem.setProperty(TreeItem.KEY_CHECKBOX_VALUE, true);
			orgTreeMap.put(sys.getCategoryCode(), sonItem);
		}
		// 构建完整的树，可以直接从map中根据categroyCode取出该节点的树
		for (SysOrganize sys : list) {
			String parentCode = sys.getSeniorCategoryCode();
			String code = sys.getCategoryCode();
			TreeItem sonItem = (TreeItem) orgTreeMap.get(code);
			if ("00000000".equals(code)) {
				continue;
			}
			//取出该节点并将子节点加入到父节点
			TreeItem item = (TreeItem) orgTreeMap.get(parentCode);
			if(item!=null){
				item.addTreeItem(sonItem);
			}
		
		}
	}

	public static void loadMenu() {
		String sql = " select e from SysFunction e ";
		List<SysFunction> list = DaoHelper.getSystemPageDAO().getQueryList(sql);
		for (SysFunction sys : list) {
			menuMap.put(sys.getFunctionId(), sys);
		}
	}

	public static void loadDept() {
		String sql = " select e from SysDept e ";
		List<SysDept> list = DaoHelper.getSystemPageDAO().getQueryList(sql);
		for (SysDept sys : list) {
			deptMap.put(sys.getDeptNo(), sys);
		}
	}
}

﻿/*
 * File:Constants.java
 * company:RONGJI
 * @version: 01
 * Date: 2014-10-27
 */
package com.rongji.common.util;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * 
 * Description: 对一些常量的定义
 * Copyright:   Copyright (c)2014  
 * Company:     rongji 
 * @author:     YSY  
 * @version:    1.0  
 * Create at:   2011-6-1 下午03:11:31  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2011-6-1   YSY      1.0         1.0 Version
 */
public class Constants {
	/**
	 * 登录人员信息在session中的名字
	 */
	public static final String LOGIN_USER_KEY = "com.rongji.dfish.LOGIN_USER_KEY";

	/**
	 * 人员使用字符集在session中的名字
	 */
	public static final String USER_LOCALE_KEY = "com.rongji.dfish.USER_LOCALE_KEY";
	/**
	 * 定义本系统基本参数配置文件名字
	 */
	public static final String SYSTEM_CONFIG_FILE = "dfish_config.xml";
	public static final String UPLOAD_FILEPATH = "upload/";
	//上架处理
	public static final String UPLOAD_SIGN="upCabinet";
	//下架处理
    public static final String DOWN_SIGN="downCabinet";
    //置顶处理
    public static final String SET_TOP="top";
    //沉底处理
    public static final String SET_BOTTOM="bottom";
    //上移
    public static final String SET_UP="up";
    //下移
    public static final String SET_DOWN="down";
    //取消置顶
    public static final String UN_TOP="unTop";
    //通过网银支付备注
    public static final String NET_PAY_DESC="通过网上银行支付";
    public static final String USER_ADD="add";
    public static final String USER_UPDATE="update";
    public static final String ORDER_STATUS_CHECK="check";
    public static final String ORDER_STATUS_PAY="pay";
    
    public final static String ELEMENT_PANEL_ID = "f-element-panel";
    
    /**文件方式访问*/
    public static final String CLUSTER_FILE = "0";
    /**webservice方式访问*/
    public static final String CLUSTER_WEBSERVICE = "1";
    /**redis方式访问*/
    public static final String CLUSTER_REDIS = "2";
    public static final String COMBOX_TYPE_DEPT = "DEPT";//只有部门
    public static final String COMBOX_TYPE_USER = "USER";//只选人
    public static final String COMBOX_TYPE_DEPT_USER = "USER_DEPT";//部门和人
    public static final String COMBOX_TYPE_ORG = "ORG";//部门和人
    
	/**
	 * 定义个人界面定制配置文件名称
	 */
	public static final String PERSON_CONFIG_FILE = "person"; // "personality_config.xml";

	public static final NullAbleDateFormat DEFAULT_DATEFORMAT = new NullAbleDateFormat("yyyy-MM-dd HH:mm");
	public static final NullAbleDateFormat FULL_DATEFORMAT = new NullAbleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final NullAbleDateFormat LONG_FULL_DATEFORMAT = new NullAbleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	public static final NullAbleDateFormat SHORT_DATEFORMAT = new NullAbleDateFormat("yyyy-MM-dd");
	public static final NullAbleDateFormat FILE_DATEFORMAT = new NullAbleDateFormat("yyMM");
	public final static SimpleDateFormat ORDER_DATEFORMAT = new SimpleDateFormat("yyyyMMddHHmm");
	public final static SimpleDateFormat FULL_CHART_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public final static SimpleDateFormat SHORT_CHART_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd");
	public final static SimpleDateFormat CHART_DATEFORMAT = new SimpleDateFormat("yyyy/MM/dd");
	/**
	 * 默认字符集
	 */
	public static final String ENCODING = "UTF-8";

	public final static String OBJ_TYPE_SITE = "CL";
	public final static String OBJ_TYPE_CA = "CA"; 

	public static class NullAbleDateFormat implements Serializable{
		private static final long serialVersionUID = 625323001437146360L;
		private SimpleDateFormat core;
		public NullAbleDateFormat(String pattern){
			core=new SimpleDateFormat(pattern);
		}
		
		public String format(Date date) {
			if(date==null)return null;
			synchronized(core){
				return core.format(date);
			}
		}

		public Date parse(String source) throws ParseException {
			if(source==null||source.equals(""))return null;
			synchronized(core){
				return core.parse(source);
			}
		}
		
	}
}

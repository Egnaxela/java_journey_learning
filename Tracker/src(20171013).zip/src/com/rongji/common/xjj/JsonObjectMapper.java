/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-7-20 上午11:11:04  
 *  
 */  

package com.rongji.common.xjj;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonGenerator;  
import com.fasterxml.jackson.core.JsonProcessingException;  
import com.fasterxml.jackson.databind.JsonSerializer;  
import com.fasterxml.jackson.databind.SerializerProvider;  

/**  
 * Description: json空值转换工具类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-7-20 上午11:11:04  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-7-20      李晨阳                      1.0         1.0 Version  
 */

public class JsonObjectMapper extends ObjectMapper {
	private static final long serialVersionUID = 1L;  
	  
    public JsonObjectMapper() {  
        super();  
        // 空值处理为空串  
        this.getSerializerProvider().setNullValueSerializer(new JsonSerializer<Object>() {  
            @Override  
            public void serialize(Object value, JsonGenerator jg, SerializerProvider sp) throws IOException, JsonProcessingException {  
                jg.writeString("");  
            }  
        });  
    }  

}

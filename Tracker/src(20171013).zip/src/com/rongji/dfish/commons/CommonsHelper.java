package com.rongji.dfish.commons;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.dbcp.BasicDataSource;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.rongji.dfish.base.DataBaseInfo;
import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.IPv4Filter;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.framework.SystemData;

public class CommonsHelper extends FrameworkHelper {

	public static IPv4Filter filter = null;
	public static String smsType = "";
	/**
	 * @Description: 获取配置内容
	 * @Author: LinLW
	 * @CreateDate: 2015-6-17
	 * @param saveAs
	 * @return
	 */
	public static String getContentType(String saveAs) {
		SAXReader reader = new SAXReader();
		String contentType = null;
		try {
			File file = new File(SystemData.getInstance().getServletInfo()
					.getServletRealPath()
					+ "WEB-INF/config/contenttype.xml");
			int l = saveAs.lastIndexOf(".");
			String extension = saveAs.substring(l + 1);
			Document document = reader.read(file);
			Node node = document
					.selectSingleNode("/contentType/mime-mapping[extension='"
							+ extension + "']");
			Element element = (Element) node;
			if (element != null) {
				contentType = element.elementTextTrim("mime-type");
			} else {
				contentType = "application/octet-stream";
			}
		} catch (DocumentException e) {
			e.printStackTrace();
			contentType = "application/octet-stream";
		}

		return contentType;
	}

	/**
	 * @Description: 获取年份
	 * @Author: yuliangmei
	 * @CreateDate: 2015-6-17
	 * @param date
	 * @return
	 */
	public static Integer getYear(Date date) {
		Integer year = null;
		if (date != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			year = cal.get(Calendar.YEAR);
		}
		return year;
	}

	/**
	 * @Description: 判断两个时间是否是同一天
	 * @Author: yuliangmei
	 * @CreateDate: 2015-6-17
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isSameDay(Date date1, Date date2) {
		if (date1 != null && date2 != null) {
			String date1Str = DateUtil.format(date1, DateUtil.LV_DATE);
			String date2Str = DateUtil.format(date2, DateUtil.LV_DATE);
			return date1Str.equals(date2Str);
		} else if (date1 == null && date2 == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @Description: 从序列中获取主键的值（没有hibernate映射文件时调用）
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param tableName
	 *            表名
	 * @param key
	 *            表中主键的字段名
	 * @param length
	 *            主键的长度
	 * @return
	 */
	public static String getNewId(String tableName, String key, int length) {
		String nextId = getNextKeyId(tableName, key, length);
		if (Utils.isEmpty(nextId)) {
			createSequence(tableName, key, 0);
			nextId = getNextKeyId(tableName, key, length);
			if (Utils.isEmpty(nextId)) {
				throw new RuntimeException("can not get next id.");
			}
		}
		return nextId;
	}

	/**
	 * @Description: 从序列中获取主键的值
	 * @Author: huangjunyang
	 * @CreateDate: 2015-6-17
	 * @param tableName
	 *            表名
	 * @param key
	 *            表中主键的字段名
	 * @param length
	 *            主键的长度
	 * @param startSeq
	 *            序列初始值
	 * @return
	 */
	private static String getNewId(String tableName, String key, int length,
			long startSeq) {
		String nextId = getNextKeyId(tableName, key, length);
		if (nextId == null) {
			createSequence(tableName, key, startSeq);
			nextId = getNextKeyId(tableName, key, length);
			if (nextId == null) {
				throw new RuntimeException("can not get next id.");
			}
		}
		return nextId;
	}

	/**
	 * @Description: 获取驱动名称
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @return
	 */
	public static String getDataBaseDriverName() {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SystemData.getInstance()
				.getBeanFactory().getBean("jdbcTemplate");
		BasicDataSource basicDataSource = (BasicDataSource) jdbcTemplate
				.getDataSource();
		return basicDataSource.getDriverClassName();
	}

	/**
	 * @Description: 获取下一个序列的值
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param tableName
	 * @param key
	 * @param length
	 * @return
	 */
	private static String getNextKeyId(String tableName, String key, int length) {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SystemData.getInstance()
				.getBeanFactory().getBean("jdbcTemplate");
		// String driverName = getDataBaseDriverName();
		String seq = getSequenceName(tableName);
		String sql = "";
		if (SystemData.getInstance().getDataBaseInfo().getDatabaseType() == DataBaseInfo.DATABASE_POSTGRESQL) {
			sql = "SELECT nextval('" + seq + "')";
		} else {
			sql = "SELECT " + seq + ".NEXTVAL FROM DUAL";
		}
		String nextId = null;
		try {
			List idList = jdbcTemplate.queryForList(sql);
			for (Object id : idList) {
				Map idMap = (Map) id;
				nextId = idMap.get("NEXTVAL").toString();
			}
			StringBuilder sb = new StringBuilder();
			for (Long i = Long.valueOf(nextId.length()); i < length; i++) {
				sb.append('0');
			}
			sb.append(nextId);
			nextId = sb.toString();
		} catch (DataAccessException e) {
		}
		return nextId;
	}

	/**
	 * @Description: 根据表名创建序列
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param tableName
	 * @param key
	 * @param startId
	 * @return
	 */
	private static boolean createSequence(String tableName, String key,
			long startId) {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SystemData.getInstance()
				.getBeanFactory().getBean("jdbcTemplate");
		String maxId = "1";
		long nextId = 1;
		boolean isPgSql = SystemData.getInstance().getDataBaseInfo()
				.getDatabaseType() == DataBaseInfo.DATABASE_POSTGRESQL;
		try {
			List resultList = jdbcTemplate.queryForList("SELECT MAX(" + key
					+ ") FROM " + tableName);
			if (Utils.notEmpty(resultList)) {
				for (Object result : resultList) {
					Map resultMap = (Map) result;
					Object max = resultMap.get(isPgSql ? "max" : "MAX(" + key
							+ ")");
					if (max != null) {
						maxId = max.toString();
						nextId = Long.valueOf(maxId) + 1;
					}
				}
			}
		} catch (DataAccessException e1) {
			// TODO Auto-generated catch block
			throw new RuntimeException("表名或主键名出错");
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			List resultList = jdbcTemplate.queryForList("SELECT MAX(" + key
					+ ") FROM " + tableName + " where regexp_like(" + key
					+ ", '^([0-9]+)$')");
			if (Utils.notEmpty(resultList)) {
				for (Object result : resultList) {
					Map resultMap = (Map) result;
					Object max = resultMap.get("MAX(" + key + ")");
					if (max != null) {
						maxId = max.toString();
						nextId = Long.valueOf(maxId) + 1;
					}
				}
			}
		}
		String seq = getSequenceName(tableName);
		if (startId > 0) {
			if (startId > nextId) {
				nextId = startId;
			}
		}
		String sql = "";
		if (isPgSql) {
			sql = "CREATE SEQUENCE "
					+ seq
					+ " INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START "
					+ nextId + " CACHE 1;";
		} else {
			sql = "CREATE SEQUENCE " + seq + " minvalue 1 "
					+ "maxvalue 999999999999999999999999 start with " + nextId
					+ " increment by 1 cache 10";
		}
		try {
			jdbcTemplate.update(sql);
			return true;
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			return false;
		}
	}

	/**
	 * @Description: 根据表名创建序列
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param seq
	 * @param startId
	 * @return
	 */
	public static boolean createSequence(String seq, long startId) {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SystemData.getInstance()
				.getBeanFactory().getBean("jdbcTemplate");
		long nextId = 1;
		boolean isPgSql = SystemData.getInstance().getDataBaseInfo()
				.getDatabaseType() == DataBaseInfo.DATABASE_POSTGRESQL;
		String sql = "";
		if (isPgSql) {
			sql = "CREATE SEQUENCE "
					+ seq
					+ " INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START "
					+ nextId + " CACHE 1;";
		} else {
			sql = "CREATE SEQUENCE " + seq + " minvalue 1 "
					+ "maxvalue 999999999999999999999999 start with " + nextId
					+ " increment by 1 cache 10";
		}
		try {
			jdbcTemplate.update(sql);
			return true;
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			return false;
		}
	}

	public static String getNextKeyId(String seq, int length) {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SystemData.getInstance()
				.getBeanFactory().getBean("jdbcTemplate");
		String sql = "";
		if (SystemData.getInstance().getDataBaseInfo().getDatabaseType() == DataBaseInfo.DATABASE_POSTGRESQL) {
			sql = "SELECT nextval('" + seq + "')";
		} else {
			sql = "SELECT " + seq + ".NEXTVAL FROM DUAL";
		}
		String nextId = null;
		try {
			List idList = jdbcTemplate.queryForList(sql);
			for (Object id : idList) {
				Map idMap = (Map) id;
				nextId = idMap.get("NEXTVAL").toString();
			}
			StringBuilder sb = new StringBuilder();
			for (Long i = Long.valueOf(nextId.length()); i < length; i++) {
				sb.append('0');
			}
			sb.append(nextId);
			nextId = sb.toString();
		} catch (DataAccessException e) {
		}
		return nextId;
	}
	
	
	/**
	 * @Description: 获取序列名
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param tableName
	 * @return
	 */
	private static String getSequenceName(String tableName) {
		String seq = "SEQ_" + tableName;
		if (seq.length() > 30) {
			// seq.substring(0, 30);
			throw new RuntimeException("表的名字超过26位");
		}
		return seq;
	}

	/**
	 * 获取持久化对象的主键值
	 * 
	 * @param clazz
	 * @return
	 */
	/**
	 * @Description: 从序列中获取主键的值（有hibernate映射文件时调用）
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @return
	 */
	public static String getNewId(Class clazz) {
		String[] tableInfo = CommonsHelper.getTablePkNameLength(clazz);
		int length = 0;
		try {
			length = Integer.parseInt(tableInfo[2]);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("can not get next id.");
		}
		String nextId = CommonsHelper.getNewId(tableInfo[0], tableInfo[1],
				length);
		return nextId;
	}

	/**
	 * @Description: 获取持久化对象的主键值，指定序列初始值
	 * @Author: huangjunyang
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @param startSeq
	 * @return
	 */
	public static String getNewId(Class clazz, long startSeq) {
		String[] tableInfo = CommonsHelper.getTablePkNameLength(clazz);
		int length = 0;
		try {
			length = Integer.parseInt(tableInfo[2]);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("can not get next id.");
		}
		String nextId = CommonsHelper.getNewId(tableInfo[0], tableInfo[1],
				length, startSeq);
		return nextId;
	}

	/**
	 * @Description: 获取持久化对象对应的表名、主键对应的列名、主键的长度
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 *            实体对应的类
	 * @return String[] 表名、主键列名、长度
	 */
	private static String[] getTablePkNameLength(Class clazz) {
		String[] tableInfo = new String[3];
		tableInfo[0] = getTableName(clazz);
		tableInfo[1] = getPkColumnName(clazz);
		tableInfo[2] = getPkLength(clazz) + "";
		return tableInfo;
	}

	/**
	 * @Description: 获取持久化对象的表名
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @return
	 */
	private static String getTableName(Class clazz) {
		return getPersistentClass(clazz).getTable().getName();
	}

	/**
	 * @Description: 获取持久化对象主键对应的列名
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @return
	 */
	private static String getPkColumnName(Class clazz) {
		return getPersistentClass(clazz).getTable().getPrimaryKey()
				.getColumn(0).getName();

	}

	/**
	 * @Description: 获取持久化对象主键长度
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @return
	 */
	private static int getPkLength(Class clazz) {
		return getPersistentClass(clazz).getTable().getPrimaryKey()
				.getColumn(0).getLength();

	}

	private static Configuration hibernateConf;

	/**
	 * @Description: 获得Hibernate的配置
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @return
	 */
	private static Configuration getHibernateConf() {
		if (hibernateConf == null) {
			return new Configuration();
		}
		return hibernateConf;
	}

	/**
	 * @Description: 获得Hibernate持久化类
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param clazz
	 * @return
	 */
	private static PersistentClass getPersistentClass(Class clazz) {
		PersistentClass pc = getHibernateConf()
				.getClassMapping(clazz.getName());
		if (pc == null) {
			hibernateConf = getHibernateConf().addClass(clazz);
			pc = getHibernateConf().getClassMapping(clazz.getName());

		}
		return pc;
	}

	/**
	 * @Description: 获取域名
	 * @Author: yuliangmei
	 * @CreateDate: 2015-6-17
	 * @param urlText
	 * @param linkClass
	 * @return
	 */
	public static String getDomain(String urlText, String linkClass) {
		String regExp = "(((http|ftp|https|file)://)|((?<!((http|ftp|https|file)://))www\\.))"
				+ ".*?" // 中间为任意内容，惰性匹配
				+ "(?=(&nbsp;|\\s|　|<br />|$|[<>]|[\u4E00-\u9FA5]))"; // 结束条件
		// String regExp = "^((https|http|ftp|rtsp|mms)?://)"
		// + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?"
		// //ftp的user@
		// + "(([0-9]{1,3}\\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
		// + "|" // 允许IP和DOMAIN（域名）
		// + "([0-9a-z_!~*'()-]+\\.)*" // 域名- www.
		// + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\\." // 二级域名
		// + "[a-z]{2,6})" // first level domain- .com or .museum
		// + "(:[0-9]{1,5})?" // 端口- :80
		// + "((/?)|" // a slash isn't required if there is no file name
		// + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";

		urlText = urlText.replaceAll("<", "&lt;");
		urlText = urlText.replaceAll(">", "&gt;");
		urlText = urlText.replaceAll(" ", "&nbsp;");
		Pattern p = Pattern.compile(regExp, Pattern.CASE_INSENSITIVE);
		Matcher matcher = p.matcher(urlText);

		StringBuffer stringbuffer = new StringBuffer();
		if (linkClass == null) {
			linkClass = "";
		}
		while (matcher.find()) {
			String domain = matcher.group();
			String url = domain.indexOf("://") < 0 ? "http://" + domain
					: domain;
			String tempString = "<a href=\"" + url + "\" class='" + linkClass
					+ "' target='_blank'>" + domain + "</a>";
			// 这里对tempString中的"\"和"$"进行一次转义，因为下面对它替换的过程中appendReplacement将"\"和"$"作为特殊字符处理
			int tempLength = tempString.length();
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < tempLength; ++i) {
				char c = tempString.charAt(i);
				if (c == '\\' || c == '$') {
					sb.append("\\").append(c);
				} else {
					sb.append(c);
				}
			}
			tempString = sb.toString();
			matcher.appendReplacement(stringbuffer, tempString);
		}
		matcher.appendTail(stringbuffer);
		urlText = stringbuffer.toString();
		urlText = urlText.replaceAll("\n", "<br/>");
		return urlText;
	}

	/**
	 * @Description: 获取用户名的宽度
	 * @Author: xuzhengwei
	 * @CreateDate: 2015-6-17
	 * @param userName
	 * @return
	 */
	public static int getUserNameWidth(String userName) {
		int width = 36;
		if (Utils.notEmpty(userName)) {
			Pattern pattern = Pattern.compile("[\u4E00-\u9FA5]");
			Matcher m = pattern.matcher(userName);
			int num = 0;
			while (m.find()) {
				num++;
			}
			width = (userName.length() - num) * 6 + num * 12;
		}
		return width;
	}

	/**
	 * @Description: 判断是否是内网地址
	 * @Author: huangjunyang
	 * @CreateDate: 2015-6-17
	 * @param request
	 * @return
	 */
	public static boolean isInternalAccess(HttpServletRequest request) {
		// if (filter == null) {
		// String ip = ItaskHelper.getSystemConfig(
		// Constants.ITASK_INTERNAL_IP, "*.*.*.*");
		// String[] ips = ip.split("\n");
		// ip = "";
		// for (String i : ips) {
		// ip = ip + i + ";";
		// }
		// ip = ip.replace("-", ";");
		// filter = new IPv4Filter(ip);
		// }
		if (filter != null) {
			try {
				return filter.match(FrameworkHelper.getIpAddr(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return true;
	}

	public static boolean classOfSrc(Object source, Object target) {
		if (source == null || target == null) {
			return false;
		}
		Class<?> srcClass = source.getClass();
		Field[] fields = srcClass.getDeclaredFields();
		for (Field field : fields) {
			String nameKey = field.getName();
			String srcValue = getClassValue(source, nameKey) == null ? ""
					: getClassValue(source, nameKey).toString();
			String tarValue = getClassValue(target, nameKey) == null ? ""
					: getClassValue(target, nameKey).toString();
			if (!srcValue.equals(tarValue)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 根据字段名称取值
	 * 
	 * @param obj
	 * @param fieldName
	 * @return
	 */
	public static Object getClassValue(Object obj, String fieldName) {
		if (obj == null) {
			return null;
		}
		try {
			Class beanClass = obj.getClass();
			Method[] ms = beanClass.getMethods();
			for (int i = 0; i < ms.length; i++) {
				// 非get方法不取
				if (!ms[i].getName().startsWith("get")) {
					continue;
				}
				Object objValue = null;
				try {
					objValue = ms[i].invoke(obj, new Object[] {});
				} catch (Exception e) {
					System.out.println("反射取值出错：" + e.toString());
					continue;
				}
				if (objValue == null) {
					continue;
				}
				if (ms[i].getName().toUpperCase().equals(
						fieldName.toUpperCase())
						|| ms[i].getName().substring(3).toUpperCase().equals(
								fieldName.toUpperCase())) {
					return objValue;
				} else if (fieldName.toUpperCase().equals("SID")
						&& (ms[i].getName().toUpperCase().equals("ID") || ms[i]
								.getName().substring(3).toUpperCase().equals(
										"ID"))) {
					return objValue;
				}
			}
		} catch (Exception e) {
			// logger.info("取方法出错！" + e.toString());
		}
		return null;
	}

	/**
	 * 检验分页信息的合法性(大数据保护)
	 * 
	 * @return 分页信息
	 */
	public static Page checkPage(Page page) {
		if (page == null) {
			page = new Page();
			page.setCurrentPage(1);
			page.setPageSize(Constants.MAX_PAGE_SIZE);
		} else {
			if (page.getCurrentPage() <= 0) {
				page.setCurrentPage(1);
			}
			if (page.getPageSize() == 0
					|| page.getPageSize() > Constants.MAX_PAGE_SIZE) {
				page.setPageSize(Constants.MAX_PAGE_SIZE);
			}
		}
		return page;
	}

	/**
	 * 翻页size
	 * 
	 * @param request
	 * @return
	 */
	public static Page getPage(HttpServletRequest request) {
		String cp = request.getParameter("cp");
		Page page = new Page();
		page.setPageSize(8);
		int curPage = 1;
		try {
			curPage = Integer.parseInt(cp);
		} catch (Exception ex) {
			curPage = 1;
		}
		page.setCurrentPage(curPage);
		return page;
	}
	public static Page getPage(HttpServletRequest request,int pageSize) {
		String cp = request.getParameter("cp");
		Page page = new Page();
		page.setPageSize(pageSize);
		int curPage = 1;
		try {
			curPage = Integer.parseInt(cp);
		} catch (Exception ex) {
			curPage = 1;
		}
		page.setCurrentPage(curPage);
		return page;
	}

	/***************************************************************************
	 * 获取申请单号 35+yyyy+6位
	 * 
	 * @return
	 */
	private static Random random = new Random();

	public static String getNewRegId(String orgCode) {

		int r = random.nextInt(32);
		return (new StringBuilder().append(orgCode).append(
				Constants.DF_SDATEFORMAT.format(new Date())).append(Integer
				.toString(r, 32))).toString();
	}

	private static String LOGIN_ORG_KEY = "com.rongji.dfish.loginOrg";

	/***************************************************************************
	 * 获得登录人员
	 * 
	 * @return
	 */
	public static String getLoginOrg(HttpServletRequest request) {

		return (String) request.getSession().getAttribute(LOGIN_ORG_KEY);
	}

	/***************************************************************************
	 * 设置登录人员
	 * 
	 * @param request
	 * @param loginOrg
	 */
	public static void setLoginOrg(HttpServletRequest request, String loginOrg) {

		request.getSession().setAttribute(LOGIN_ORG_KEY, loginOrg);
	}

	public static String getServAddr(HttpServletRequest request){
		return request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
	}
	
    /** 
	* 产生一个32位的UUID 
	* @return 
	*/ 
	public static String getUuid(){ 
	UUID uuid = UUID.randomUUID(); 
	return uuid.toString().replace("-", ""); 
	} 

	
}
package com.rongji.dfish.commons;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.ButtonContainer;
import com.rongji.dfish.engines.xmltmpl.Panel;
import com.rongji.dfish.engines.xmltmpl.VAlign;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.button.ExpandableButton;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.HtmlPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.XBox;
import com.rongji.system.pub.service.Services;


public class Constants {

 
	
//	public static String JUDGE_USER_NAME_REPEAT=FrameworkHelper.getSystemConfig("system.user_name_repeat","1");
	
	
			
	public static final int QUICK_SEARCH_PAGE_SIZE = 10;
	public static int MAX_PAGE_SIZE = 512;
	public static final String TYPE_EXCEL = "xls";
	
	/**
	 * 精确时间格式,在I-TASK中时间最高精确到秒
	 */
	public static final SimpleDateFormat DEFAULT_DATEFORMAT = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");

	/**
	 * 精确到分钟的时间格式,多处设置显示用该格式.
	 */
	public static final SimpleDateFormat MINUTE_DATEFORMAT = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm");

	/**
	 * 精确到分钟的时间格式,多处设置显示用该格式.
	 */
	public static final SimpleDateFormat HM_DATEFORMAT = new SimpleDateFormat(
			"HH:mm");

	/**
	 * 精确到天的时间格式,多处设置显示用该格式.
	 */
	public static final SimpleDateFormat MD_DATEFORMAT = new SimpleDateFormat(
			"M-d");

	/**
	 * 精确到年的时间格式,多处设置显示用该格式.
	 */
	public static final SimpleDateFormat YEAR_DATEFORMAT = new SimpleDateFormat(
			"yyyy");

	/**
	 * 简短时间格式,精确到天
	 */
	public static final SimpleDateFormat SHORT_DATEFORMAT = new SimpleDateFormat(
			"yyyy-MM-dd");
	
	/**
	 * 仅月日格式,MM-dd
	 */
	public static final SimpleDateFormat DF_MONTHDAY = new SimpleDateFormat(
			"MM-dd");
	
	/**
	 * 仅月日格式,MM-dd
	 */
	public static final SimpleDateFormat DF_SDATEFORMAT = new SimpleDateFormat(
			"yyMMdd");

	
	/**
	 * 登录人员信息在session中的名字
	 */
	public static final String LOGIN_USER_KEY = "com.rongji.dfish.LOGIN_USER_KEY";

	private static Map<String, String> pageStyleMap = null;
	
	
	
	
	
	/**   
	 *@Description: 获取列表的显示设置
	 *@Author: linshaozhong
	 *@CreateDate: 2015-6-17
	 *@return
	 */
	public static Map<String, String> getPageStyleMap() {
		if (Utils.notEmpty(pageStyleMap)) {
			return pageStyleMap;
		} else {
			pageStyleMap = new LinkedHashMap<String, String>();
			pageStyleMap.put("loose", "宽松");
			pageStyleMap.put("moderate", "适中");
			pageStyleMap.put("compact", "紧凑");
			return pageStyleMap;
		}
	}

	/**   
	 *@Description: 获取列表的显示设置列表的行高
	 *@Author: linshaozhong
	 *@CreateDate: 2015-6-17
	 *@param style
	 *@return
	 */
	public static int getPageLineHeight(String style) {
		if ("loose".equals(style)) {
			return 45;
		} else if ("compact".equals(style)) {
			return 35;
		} else {
			return 40;
		}
	}

	/**   
	 *@Description: 获取列表的显示设置列表的字体大小
	 *@Author: linshaozhong
	 *@CreateDate: 2015-6-17
	 *@param style
	 *@param bold
	 *@return
	 */
	public static int getPageFontSize(String style, boolean bold) {
		if ("loose".equals(style)) {
			return bold ? 15 : 16;
		} else if ("compact".equals(style)) {
			return 12;
		} else {
			return bold ? 13 : 14;
		}
	}

	public static final String YES = "Y";
	
	public static final String NO = "N";

    /**   
     *@Description: 填充显示设置菜单
     *@Author: linshaozhong
     *@CreateDate: 2015-6-17
     *@param parent
     *@param style
     *@param size
     *@param styleAction
     *@param sizeAction
     */
    public static void fillConfigPageMenu(ButtonContainer parent, String style, int size, String styleAction, String sizeAction){
		ExpandableButton pageStyleConfig = new ExpandableButton("", "  显示设置  ", "");
		parent.addButton(pageStyleConfig);
		
		Map<String, String> pageStyleMap = getPageStyleMap();
		for(String key : pageStyleMap.keySet()){
			ClickButton button = new ClickButton(key.equals(style) ? "m/task/img/check.png" : "", "      " + pageStyleMap.get(key) + "     ", key.equals(style) ? "" : styleAction);
			pageStyleConfig.addButton(button);
			button.setId(key);
		}
		
		ExpandableButton pageSizeConfig = new ExpandableButton("", "  每页显示  ", "");
		parent.addButton(pageSizeConfig);
		
		ExpandableButton ten = new ExpandableButton(10 == size ? "m/task/img/check.png" : "", "       10      ", 10 == size ? "" : sizeAction);
		pageSizeConfig.addButton(ten);
		ten.setId(10 + "");
		
		for(int i = 11; i < 15; i++){
			ClickButton button = new ClickButton(i == size ? "m/task/img/check.png" : "", "       " + i + "      ", i == size ? "" : sizeAction);
			ten.addButton(button);
			button.setId(i + "");
		}
		
		ExpandableButton fifteen = new ExpandableButton(15 == size ? "m/task/img/check.png" : "", "       15      ", 15 == size ? "" : sizeAction);
		pageSizeConfig.addButton(fifteen);
		fifteen.setId(15 + "");
		
		for(int i = 16; i < 20; i++){
			ClickButton button = new ClickButton(i == size ? "m/task/img/check.png" : "", "       " + i + "      ", i == size ? "" : sizeAction);
			fifteen.addButton(button);
			button.setId(i + "");
		}
		
		for(int i = 2; i <= 8; i++){
			int count = i * 5 + 10;
			ClickButton button = new ClickButton(count == size ? "m/task/img/check.png" : "", "       " + count + "      ", count == size ? "" : sizeAction);
			pageSizeConfig.addButton(button);
			button.setId(count + "");
		}
	}
    
    /**
     * 人员头像 - 小
     */
    public static final int PHOTO_SIZE_SMALL = 40;
    /**
     * 人员头像 - 中等
     */
    public static final int PHOTO_SIZE_MEDIUM = 60;
    /**
     * 人员头像 - 大
     */
    public static final int PHOTO_SIZE_LARGE = 120;

	public static final String TASK_TYPE_MISSION = "mission";

	public static final String INDEX_TASK_NEW = "new";
	
	public static Panel getEmptyPage(){
		HtmlPanel emptyPage = new HtmlPanel("emptyPage", "<div style=\"background:url(m/index/img/empty-page.png) no-repeat center;width:655px;height:286px;margin:50px;\" ></div>");
		emptyPage.setAlign(Align.center);
		emptyPage.setVAlign(VAlign.middle);
		
		return emptyPage;
	}
	
	public static PagePanel getPagePanel(){
		PagePanel pagePanel = new PagePanel("f_page");
		pagePanel.setFace(PagePanel.FACE_OFFICE);
		pagePanel.setStyle("margin:0 15px 0 30px;");
		return pagePanel;
	}
	
	public static String simpleFormat(Date date){
		String result = "";
		Date now = new Date();
		Calendar compare = Calendar.getInstance();
		compare.setTime(date);
		
		Calendar curent = Calendar.getInstance();
		curent.setTime(now);
		
		Calendar pre = Calendar.getInstance();
		pre.setTime(now);
		pre.add(Calendar.DAY_OF_MONTH, -1);
		
		String compareDay = Constants.SHORT_DATEFORMAT.format(date);
		String today = Constants.SHORT_DATEFORMAT.format(now);
		String preDay = Constants.SHORT_DATEFORMAT.format(pre.getTime());
		
		if(today.equals(compareDay)){//当天
			result = Constants.HM_DATEFORMAT.format(date);
		} else if(preDay.equals(compareDay)){//昨天
			result = "昨天";
		} else if(curent.get(Calendar.YEAR) == compare.get(Calendar.YEAR)){
			result = Constants.MD_DATEFORMAT.format(date);
		} else {
			result = Constants.YEAR_DATEFORMAT.format(date);
		}
		
		return result;
	}
	
	
	
/*	public static Horizontalgroup getArea(String name,String title,String value, boolean readonly,boolean notNull){
		Horizontalgroup hg=new Horizontalgroup(name+"Sh", title);
		if(value==null){
			value="";
		}
		if(value.length()<6){
			value=(value+"000000").substring(0,6);
		}
		String pr=value.substring(0,2);
		String ci=value.substring(2,4);
		String co=value.substring(4,6);
		
		List<SysCodeXzqh> gqmcs=Services.getPubService().findSysCodeXzqhs();
		//确认省份是有效的 如果无效统一转换成35
		List <SysCodeXzqh> prOptions=new ArrayList<SysCodeXzqh>();
		List <SysCodeXzqh> ciOptions=new ArrayList<SysCodeXzqh>();
		List <SysCodeXzqh> coOptions=new ArrayList<SysCodeXzqh>();
		boolean findPr=false;
		for(SysCodeXzqh gqmc:gqmcs){
			if(!gqmc.getXzqhCode().endsWith("0000")){
				continue;
			}
			prOptions.add(gqmc);
			if(gqmc.getXzqhCode().startsWith(pr)){
				findPr=true;
			}
		}
//		if(!findPr){pr="35";}
		//确认ci是有效的如果无效 转化成第一个
		boolean findCi=false;
		for(SysCodeXzqh xzqh:gqmcs){
			if(!xzqh.getXzqhCode().startsWith(pr)||!xzqh.getXzqhCode().endsWith("00")){
				continue;
			}
			if(xzqh.getXzqhCode().substring(2, 4).equals("00")){
				continue;
			}
			ciOptions.add(xzqh);
			if(xzqh.getXzqhCode().substring(2, 4).equals(ci)){
				findCi=true;
			}
		}
		if(!findCi&&Utils.notEmpty(ciOptions)){
			ci=ciOptions.get(0).getXzqhCode().substring(2, 4);
		}
		//确认co是有效的如果无效转化成第一个
		boolean findCo=false;
		String prefix=pr+ci;
		for(SysCodeXzqh xzqh:gqmcs){
			if(!xzqh.getXzqhCode().startsWith(prefix)){
				continue;
			}
			if(xzqh.getXzqhCode().substring(4,6).equals("00")){
				continue;
			}
			coOptions.add(xzqh);
			if(xzqh.getXzqhCode().substring(4,6).equals(co)){
				findCo=true;
			}
		}
		if(!findCo&&Utils.notEmpty(coOptions)){co=coOptions.get(0).getXzqhCode().substring(4, 6);}
		
		hg.add(getPrSelect(name,pr,prOptions).setDisabled(readonly).setNotnull(notNull));
		hg.add(getCiSelect(name,pr+ci,ciOptions).setDisabled(readonly).setNotnull(notNull));
		hg.add(getCoSelect(name,pr+ci+co,coOptions).setDisabled(readonly).setNotnull(notNull));
		if (readonly) {
			hg.add(new Hidden(name, value));
		}
		return hg;
	}
	
	public static Horizontalgroup getArea(String name,String title,String value, boolean prReadOnly,boolean ciReadOnly,boolean coReadOnly){
		Horizontalgroup hg=new Horizontalgroup(name+"Sh", title);
		if(value==null){
			value="";
		}
		if(value.length()<6){
			value=(value+"000000").substring(0,6);
		}
		String pr=value.substring(0,2);
		String ci=value.substring(2,4);
		String co=value.substring(4,6);
		
		List<SysCodeXzqh> gqmcs=Services.getPubService().findSysCodeXzqhs();
		//确认省份是有效的 如果无效统一转换成35
		List <SysCodeXzqh> prOptions=new ArrayList<SysCodeXzqh>();
		List <SysCodeXzqh> ciOptions=new ArrayList<SysCodeXzqh>();
		List <SysCodeXzqh> coOptions=new ArrayList<SysCodeXzqh>();
		boolean findPr=false;
		for(SysCodeXzqh xzqh:gqmcs){
			if(!xzqh.getXzqhCode().endsWith("0000")){
				continue;
			}
			prOptions.add(xzqh);
			if(xzqh.getXzqhCode().startsWith(pr)){
				findPr=true;
			}
		}
//		if(!findPr){pr="35";}
		//确认ci是有效的如果无效 转化成第一个
		boolean findCi=false;
		for(SysCodeXzqh xzqh:gqmcs){
			if(!xzqh.getXzqhCode().startsWith(pr)||!xzqh.getXzqhCode().endsWith("00")){
				continue;
			}
			if(xzqh.getXzqhCode().substring(2, 4).equals("00")){
				continue;
			}
			ciOptions.add(xzqh);
			if(xzqh.getXzqhCode().substring(2, 4).equals(ci)){
				findCi=true;
			}
		}
		if(!findCi&&Utils.notEmpty(ciOptions)){
			ci=ciOptions.get(0).getXzqhCode().substring(2, 4);
		}
		//确认co是有效的如果无效转化成第一个
		boolean findCo=false;
		String prefix=pr+ci;
		for(SysCodeXzqh gqmc:gqmcs){
			if(!gqmc.getXzqhCode().startsWith(prefix)){
				continue;
			}
			if(gqmc.getXzqhCode().substring(4,6).equals("00")){
				continue;
			}
			coOptions.add(gqmc);
			if(gqmc.getXzqhCode().substring(4,6).equals(co)){
				findCo=true;
			}
		}
		if(!findCo&&Utils.notEmpty(coOptions)){co=coOptions.get(0).getXzqhCode().substring(4, 6);}
		
		hg.add(getPrSelect(name,pr,prOptions).setDisabled(prReadOnly));
		hg.add(getCiSelect(name,pr+ci,ciOptions).setDisabled(ciReadOnly));
		hg.add(getCoSelect(name,pr+ci+co,coOptions).setDisabled(coReadOnly));
		if (prReadOnly||ciReadOnly||coReadOnly) {
			hg.add(new Hidden(name, value));
		}
		return hg;
	}
	
	
	public static Horizontalgroup getArea(String name,String title,String value){
		return getArea(name, title, value, false,false);
	}

	public static Select getPrSelect(String name,  String pr,
			List<SysCodeXzqh> prOptions) {
		List<Object[]> options=new ArrayList<Object[]>();
		options.add(new String[]{"", "-请选择-"});
		for(SysCodeXzqh xzqh:prOptions){
			options.add(new String[]{xzqh.getXzqhCode().substring(0,2),xzqh.getXzqhCname()});
		}
		Select sel= new Select(name+"pr","省份",getValue4Select(pr).toArray(),options).setRemark("&nbsp;");
		sel.setOnchange(
				"var provId=VM(this).fv('"+name+"pr');" +
				"var selCity=VM(this).f('"+name+"ci');" +
				"var selCountry=VM(this).f('"+name+"');" +
				"var prov=M.xzqh.findProvById(provId);" +
				"M.xzqh.fillSelCity(selCity,prov,null);" +
				"var city=M.xzqh.findCityById(provId,selCity.value.substring(2,4));" +
				"M.xzqh.fillSelCountry(selCountry,city,null,provId);");
		return sel;
	}
	public static Select getCiSelect(String name,  String ci,
			List<SysCodeXzqh> ciOptions) {
		List<Object[]> options=new ArrayList<Object[]>();
		options.add(new String[]{"", "-请选择-"});
		for(SysCodeXzqh xzqh:ciOptions){
			options.add(new String[]{xzqh.getXzqhCode().substring(0,4),xzqh.getXzqhCname()});
		}
		Select sel=  new Select(name+"ci","地市",getValue4Select(ci).toArray(),options).setRemark("&nbsp;");
		sel.setOnchange(
				"var orgcityId=VM(this).fv('"+name+"ci');" +
				"var provId=orgcityId.substring(0,2);" +
				"var cityId=orgcityId.substring(2,4);" +
				"var selCountry=VM(this).f('"+name+"');" +
				"var city=M.xzqh.findCityById(provId,cityId);" +
				"M.xzqh.fillSelCountry(selCountry,city,null,provId);");
		return sel;
	}
	public static Select getCoSelect(String name,  String co,
			List<SysCodeXzqh> coOptions) {
		List<Object[]> options=new ArrayList<Object[]>();
		options.add(new String[]{"", "-请选择-"});
		for(SysCodeXzqh xzqh:coOptions){
			options.add(new String[]{xzqh.getXzqhCode(),xzqh.getXzqhCname()});
		}
		Select sel = new Select(name,"县区",getValue4Select(co).toArray(),options).setRemark("&nbsp;");
		return sel;
	}*/
	public static List<Object> getValue4Select(Object value) {
		if (value == null) {
			return new ArrayList<Object>();
		}
		return Arrays.asList(new Object[]{ value });
	}

	
}

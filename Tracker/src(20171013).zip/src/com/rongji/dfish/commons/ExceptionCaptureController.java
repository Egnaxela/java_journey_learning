﻿package com.rongji.dfish.commons;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.DfishException;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.framework.FrameworkHelper;

/**
 * 所有ActionController的基类,该类主要完成系统异常错误捕捉处理
 * <p>
 * MultiActionController 继承该方法的类 可以在类中写多个方法，实现Controller的类中默认实行的方法是
 * handleRequest，MultiActionController相当于多个Controller 比较常用。 在配置的时候需要注意
 * 该类需要客户端传递个参数 1.参数值对应的值就是MultiActionController中想对应的方法
 * 2.参数名在ApplicationContext.xml中的ParameterMethodNameResoler中定义
 * </p>
 * <p>
 * Title: 榕基RJ-ITASK
 * </p>
 * <p>
 * Description: 所有ActionController的基类,该类主要完成系统异常错误捕捉处理
 * </p>
 * <p>
 * Copyright: Copyright (c) 2009
 * </p>
 * <p>
 * Company: 榕基软件开发有限公司
 * </p>
 * 
 * @author HQJ / LinLW
 * @version 1.2
 * @since 1.0.0 HQJ 2009-12-01
 */

public class ExceptionCaptureController extends MultiActionController {
	
	
	
	protected HttpServletRequest getRequest() {
		RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
		Assert.isInstanceOf(ServletRequestAttributes.class, attrs);
		ServletRequestAttributes servletAttrs = (ServletRequestAttributes) attrs;
		return servletAttrs.getRequest();
	}

	@ExceptionHandler
	@ResponseBody
    public Object exception(Exception e) {
		
		// FIXME 异常处理
		Object obj = null;
		FrameworkHelper.LOG.error("==========异常==========", e);
		if (e instanceof DfishException) {
			obj = new AlertCommand("alert", e.getMessage(), "img/p/alert-warn.gif", DialogPosition.middle, -1);
		} else {
			obj = buildErrorView(e);
		}
		return obj;
	}
	
	public static void saveLog(String loginUser, String url, String methodName, Date beginTime, long length) {
		// TODO
	}

	public static void saveException(Date time, String logContent, String logUser, String url, String methodName) {
		// TODO
	}

	/**
	 * 对
	 */
	@Override
	protected ModelAndView handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex,
	        HttpServletRequest request, HttpServletResponse response) throws Exception {
		// FIXME 这个方法注解该怎么处理??
		// ex.getMethodName();
		String parmString = getParmString(request);
		parmString = parmString.replace("\r", "\\r").replace("\n", "\\n");
		outPutXML(response, new JSCommand("", "DFish.alert('你所请求的动作不存在\\r\\n" + "类名 : " + getClass().getName()
		        + "\\r\\n动作 : " + ex.getMethodName() + "\\r\\n页面提交的参数如下:\\r\\n" + parmString + "')"));
		return null;
	}

	public DialogCommand buildErrorView(Throwable t) {
		BaseView view = buildDlgView4Error(t);
		DialogCommand error = new DialogCommand("error", "f_std", "系统提示信息", "error_dlg",
		        DialogCommand.WIDTH_MEDIUM, DialogCommand.HEIGHT_MEDIUM, DialogPosition.middle, null);
		error.setView(view);
		error.setCover(true);
		return error;
	}

	public BaseView buildDlgView4Error(Throwable t) {
		// String errNum = ""; // 错误编号
		String errType = null; // 错误类型
		String errMsg = null; // 错误信息

		// errNum = ItaskException.UNKNOWN_EXCEPTION;
		errType = "未知";
		errMsg = "未知错误！";
		Throwable cause = t;
		while (cause.getCause() != null) {
			cause = cause.getCause();
		}
		errMsg = cause.getClass().getName();
		String errDetail = cause.getMessage();

		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel form = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
		form.setStyle("padding:10px 30px;");
		form.setStyleClass("mx");
		form.setScroll(Scroll.miniscroll);

		// form.add(new Label("", "",
		// "<font color=\"#000000\"><b>错误编号：</b></font>" + errNum + "",
		// false, false, true));
		form.add(new Label("", "", "<font color=\"#000000\"><b>错误类型：</b></font>" + errType + "").setFullLine(true)
		        .setFilter(false));
		form.add(new Label("", "", "<font color=\"#000000\"><b>错误信息：</b></font>" + errMsg + "").setFullLine(true)
		        .setFilter(false));
		form.add(new Label("", "",
		        "<font color=\"#000000\"><b>详细信息：</b></font><br><font style='font-family:Arial'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
		                + errDetail + "</span></font>").setFullLine(true).setFilter(false));

		ButtonBarPanel bbp = (ButtonBarPanel) view.findPanelById(ViewTemplate.P_POP_BTN);
		bbp.addButton(new ClickButton(null, "  取消  ", "DFish.g_dialog(this).close()"));
		return view;
	}

	public static String getParmString(HttpServletRequest request) {
		StringBuilder sb = new StringBuilder();
		Enumeration<?> e = request.getParameterNames();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			String[] value = request.getParameterValues(key);
			if (value == null || value.length == 0) {
				sb.append(key + " : [null]");
			} else if (value.length == 1) {
				sb.append(key + " : " + value[0]);
			} else {
				sb.append(key + " : " + Arrays.asList(value));
			}
			sb.append("\r\n");
		}
		return sb.toString();
	}

	@Override
	protected void bind(HttpServletRequest request, Object obj) throws Exception {
		if (obj == null) {
			return;
		}
		// 时间类型特殊处理
		Convertor adptor = getConvertor(obj.getClass());
		adptor.bind(request, obj);
	}

	private static Convertor getConvertor(Class<?> clz) {
		Convertor addpator = formatMap.get(clz);
		if (addpator == null) {
			addpator = buildConvertor(clz);
			formatMap.put(clz, addpator);
		}
		return addpator;
	}

	private static Convertor buildConvertor(Class<?> clz) {
		Convertor c = new Convertor();
		// System.out.println("building convertor for "+clz.getName());
		for (Method method : clz.getMethods()) {
			if (method.getName().startsWith("set") && method.getParameterTypes().length == 1) {
				Format f = new Format();
				f.m = method;
				f.name = method.getName().substring(3);
				f.type = method.getParameterTypes()[0];
				if (f.name.charAt(0) <= 'Z') {
					f.name = ((char) (f.name.charAt(0) + 32)) + f.name.substring(1);
				}
				// System.out.println(" get prop "+f.name);
				c.formats.add(f);
			}
		}
		return c;
	}

	protected static HashMap<Class<?>, Convertor> formatMap = new HashMap<Class<?>, Convertor>();

	private static class Convertor {
		List<Format> formats = new ArrayList<Format>();

		void bind(HttpServletRequest request, Object obj) throws Exception {
			for (Format f : formats) {
				f.bind(request, obj);
			}
		}
	}

	private static class Format {
		String name;
		Method m;
		Class<?> type;

		void bind(HttpServletRequest request, Object obj) throws Exception {
			Object value = null;
			String str = Utils.getParameter(request, name);
			if (str == null || str.equals("")) {
				//FIXME 临时解决方式。可以将表单中存在的key所对应的属性置空
				if(request.getParameterMap().containsKey(name)){
					m.invoke(obj, new Object[] { value });
				}
				return;
			}
			if (type == String.class) {
				value = str;
			} else if (type == Integer.class) {
				value = new Integer(str);
			} else if (type == Long.class) {
				value = new Long(str);
			} else if (type == Double.class) {
				value = new Double(str);
			} else if (type == java.util.Date.class) {
				if (str.length() <= 10) {
					value = DateUtil.parse(str, "yyyy-MM-dd");
				} else if (str.length() <= 16) {
					value = DateUtil.parse(str, "yyyy-MM-dd HH:mm");
				} else {
					value = DateUtil.parse(str, "yyyy-MM-dd HH:mm:ss");
				}
			} else {
				throw new java.lang.UnsupportedOperationException("Can not bind value for " + name + " ("
				        + type.getName() + ")");
			}
			m.invoke(obj, new Object[] { value });
		}
	}

}

package com.rongji.dfish.commons;

import java.util.HashMap;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.system.entity.PubInitConfig;

public class FrameworkSettingAdaptor implements 
com.rongji.dfish.framework.SystemConfigHolder{

	
	/**
	 * 取得系统配置，
	 * 
	 * @param key
	 *            关键字 如sysarg.attach.freetaskAttachPath等
	 * @param defaultValue
	 *            默认值。如果系统配置信息没有的时候，则显示默认值
	 * @return
	 */
	private static HashMap<String,String> configMap = new HashMap<String, String>(); 
	public static String getSystemConfig(String key,String defaultValue){
		
		String result=null;
		if(Utils.isEmpty(configMap.get(key)) ){
			PubCommonDAO dao=FrameworkHelper.getDAO();
			PubInitConfig cfg=(PubInitConfig)dao.queryAsAnObject("FROM PubInitConfig t WHERE t.cfgKey=?",key);
			if(cfg!=null){
				result=cfg.getCfgValue();
			}
			if(result!=null){
				configMap.put(key, result);
				return result;
			} 
		}else{
			return configMap.get(key);
		}
		return defaultValue;
	}

	/**
	 * 将系统配置保存至配置文件中（xml）
	 * 
	 * @param key
	 * @param value
	 */
	public static void setSystemConfig(String key,String value){
		
		if(value==null||value.equals("")){
//			removeCachedContent(userId+"."+argKey);
			// 删除数据库信息
			PubCommonDAO dao=FrameworkHelper.getDAO();
			PubInitConfig cfg=(PubInitConfig)dao.queryAsAnObject("FROM PubInitConfig t WHERE t.cfgKey=?",key);
			if(cfg!=null){
				dao.delete(cfg);
			}
			configMap.put(key, value);
		}else{
			//保存数据库信息
			PubCommonDAO dao=FrameworkHelper.getDAO();
			PubInitConfig cfg=(PubInitConfig)dao.queryAsAnObject("FROM PubInitConfig t WHERE t.cfgKey=?",key);
			if(cfg!=null){
				cfg.setCfgValue(value);
				dao.updateObject(cfg);
			}else{
				cfg=new PubInitConfig();
//				PubPersonCfgId id=new PubPersonCfgId();
				cfg.setCfgId(FrameworkHelper.getNewId("PubInitConfig", "cfgId", "0000000000000001"));
				cfg.setCfgKey(key);
				cfg.setCfgValue(value);
				dao.saveObject(cfg);
			}
			configMap.put(key, value);
		}
	}
	public String getProperty(String key) {
		return getSystemConfig(key,"");
	}

	public void setProperty(String key, String value) {
		setSystemConfig(key,value);
	}
	public void reset() {
		// do noting because no cache
	}
	
}

package com.rongji.dfish.commons;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.framework.SystemData;

/**
 * 长期积累的通用方法类。
 * 
 * @author ITASK-team
 * 
 */
public class JdbcTemplateHelper {
	
	public static JdbcTemplate getJdbcTemplate() {
		return (JdbcTemplate) SystemData.getInstance().getBeanFactory().getBean("jdbcTemplate");
	}

	/**
	 * 数据库执行方法 注意;为分隔符号，SQL里面常量如果有;将会出错。
	 * 
	 * @param sql
	 */
	public static void execute(String sql) {
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		try {
			if (Utils.notEmpty(sql)) {
				for (String item : sql.split(";")) {
					if (Utils.notEmpty(item)) {
						jdbcTemplate.execute(item);
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * 数据库查询方法
	 * 
	 * @param sql
	 * @return
	 */
	public static List<?> query(String sql) {
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		try {
			return jdbcTemplate.queryForList(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}
	
	public static List<?> query(String sql, Object... params) {
		if (params == null) {
			return Collections.emptyList();
		}
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		List<?> dataList = jdbcTemplate.queryForList(sql, params);
		if (dataList == null) {
			return Collections.emptyList();
		}
		return dataList;
	}
	
	public static List<?> query(String sql, Page page, Object... params) {
		if (params == null) {
			return Collections.emptyList();
		}
		if (page == null) {
			return query(sql, params);
		} else {
			if (page.getCurrentPage() < 1) {
				page.setCurrentPage(1);
			}
			if (page.getPageSize() < 1) {
				// 当无分页数时默认每页15条记录
				page.setPageSize(15);
			}
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
			int endIndex = page.getCurrentPage() * page.getPageSize();
			int beginIndex = endIndex - page.getPageSize() + 1;
			Object[] args = new Object[params.length + 2];
			int i = 0;
			for (Object param : params) {
				args[i++] = param;
			}
			args[i++] = endIndex;
			args[i++] = beginIndex;
			List<?> dataList = jdbcTemplate.queryForList(getPreSqlWithPageOracle(sql), args);
			if (dataList == null) {
				return Collections.emptyList();
			}
			return dataList;
		}
	}

	/**
	 * 数据库查询片段截取方法
	 * 
	 * @param sql
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	public static List<?> query(String sql, int startIndex, int endIndex) {
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		try {
			StringBuilder paginationSQL = new StringBuilder(" SELECT * FROM ( ");
			paginationSQL.append(" SELECT temp.* ,ROWNUM num FROM ( ");
			paginationSQL.append(sql);
			paginationSQL.append("  ) temp where ROWNUM <= ").append(endIndex);
			paginationSQL.append(" ) WHERE  num >= ").append(startIndex);
			return jdbcTemplate.queryForList(paginationSQL.toString());
		} catch (Exception ex) {

		}
		return null;
	}
	
	public static String getPreSqlWithPageOracle(String sql) {
		if (Utils.isEmpty(sql)) {
			return "";
		}
		StringBuilder paginationSQL = new StringBuilder(" SELECT * FROM ( ");
		paginationSQL.append(" SELECT temp.* ,ROWNUM num FROM ( ");
		paginationSQL.append(sql);
		paginationSQL.append("  ) temp where ROWNUM <= ?");
		paginationSQL.append(" ) WHERE  num >= ?");
		return paginationSQL.toString();
	}

	/**
	 * 数据库批量更新操作
	 * 
	 * @param sql
	 * @param dataList
	 */
	public static void batchUpdate(String sql, final List<Object[]> dataList) {
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					Object[] item = dataList.get(i);
					if (Utils.notEmpty(item)) {
						for (int j = 0; j < item.length; j++) {
							Object param = item[j];
							if (param instanceof Date) {
								param = new java.sql.Date(((Date) param).getTime());
							}
							ps.setObject(j + 1, param);
						}
					}
				}

				public int getBatchSize() {
					return dataList.size();
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
    public static void executeTransaction(final List<String> sqls, final List<Object[]> paramsList) {
		if (Utils.isEmpty(sqls) || Utils.isEmpty(paramsList) || sqls.size() != paramsList.size()) {
			return;
		}
		JdbcTemplate jdbcTemplate = getJdbcTemplate();
		jdbcTemplate.execute(new ConnectionCallback() {
			public Object doInConnection(Connection conn) throws SQLException, DataAccessException {
				boolean autoCommit = conn.getAutoCommit();
				try {
					conn.setAutoCommit(false);
					for (int i=0; i < sqls.size(); i++) {
						String sql = sqls.get(i);
						Object[] params = paramsList.get(i);
						PreparedStatement pstmt = conn.prepareStatement(sql);
						if (Utils.notEmpty(params)) {
							int paramIndex = 1;
							for (Object param : params) {
								if (param instanceof Date) {
									param = new java.sql.Date(((Date) param).getTime());
								}
								pstmt.setObject(paramIndex++, param);
							}
						}
						pstmt.execute();
					}
					conn.commit();
                } catch (Exception e) {
	                e.printStackTrace();
	                conn.rollback();
                } finally {
                	conn.setAutoCommit(autoCommit);
                	conn.close();
                }
				return null;
			}
		});
	}
}

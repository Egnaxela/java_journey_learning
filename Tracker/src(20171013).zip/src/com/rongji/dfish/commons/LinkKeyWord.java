package com.rongji.dfish.commons;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * LinkKeyWord 为ITASK V7.x中使用链接关键字的格式
 * <p>LinkKeyWord作为链接定位符，在ITASK5当中就是一个简单的字符串。
 * 在做集成的时候发现一些不妥。比如说 任务附件的如果提供链接我们可能 任务编号_A附件编号
 * 而反馈附件是 任务编号_F反馈编号_A附件编号。
 * 这样在任务模块可以进行定位。但，如果这位文件做统一处理的时候。获取附件编号将会变成一个繁琐的过程。
 * 现统一改成{"taskId":"任务编号","feedbkId":"反馈编号","resId":"附件编号"}
 * 那么这个链接地址将在多处可被识别。并且扩展了其他属性也不受影响</p>
 * @author ITASK-TEAM  v1.0-LinLW
 * @since 2011-11-09
 * @version 1.0
 *
 */
public class LinkKeyWord implements java.lang.Cloneable{
	LinkedHashMap<String,String> map;
	public LinkKeyWord(){
		map=new LinkedHashMap<String,String>();
	}
	/**
	 * 根据字符串格式生成LinkKeyWord
	 * @param str
	 */
	@SuppressWarnings("unchecked")
	public LinkKeyWord(String str){
		Gson gson=new Gson();
		Type tt=new TypeToken<LinkedHashMap<String,String>>(){}.getType();
		map=gson.fromJson(str, tt);
	}
	@Override
	public String toString(){
		Gson gson=new Gson();
		return gson.toJson(map);
	}
	/**
	 * 增加一个属性，如果这个属性已经存在将会报错
	 * @param key
	 * @param value
	 * @throws IllegalArgumentException
	 */
	public void addProperty(String key,String value)throws IllegalArgumentException{
		if(map.containsKey(key)){
			throw new IllegalArgumentException("duplicate key:"+key);
		}
		map.put(key, value);
	}
	/**
	 * 增加或替换一个属性，如果这个属性不存在则增加，否则替换它。
	 * @param key
	 * @param value
	 */
	public void addOrReplaceProperty(String key,String value){
		map.put(key, value);
	}
	/**
	 * 替换一个属性，如果这个属性不存在则增加，则没有动作。
	 * @param key
	 * @param value
	 */
	public void replaceProperty(String key,String value){
		if(map.containsKey(key)){
			map.put(key, value);
		}
	}
	/**
	 * 判定一个属性是否存在
	 * @param key
	 * @return
	 */
	public boolean isPropertyExsits(String key){
		return map.containsKey(key);
	}
	/**
	 * 删除一个属性
	 * @param key
	 * @param value
	 */
	public void removeProperty(String key,String value){
		map.remove(key);
	}
	/**
	 * 
	 * @param key
	 * @return
	 */
	public String getProperty(String key){
		return map.get(key);
	}
	public List<String> getKeys(){
		return new ArrayList<String>(map.keySet());
	}
	public static void main(String[] args){
		LinkKeyWord key=new LinkKeyWord();
		System.out.println(key);
		key=new LinkKeyWord("{\"taskId\":\"xxxxx\"}");
		System.out.println(key);
		key.addProperty("resId", "0009");
		
		key.addProperty("A002", "0009");
		key.addProperty("A003", "0009");
		key.addProperty("A001", "0009");
		key.addProperty("A004", "0009");
		System.out.println(key);
		System.out.println(key.getKeys());
	}
	@Override
	@SuppressWarnings("unchecked")
	public LinkKeyWord clone(){
		LinkKeyWord c=new LinkKeyWord();
		c.map=(LinkedHashMap<String, String>) this.map.clone();
		return c;
	}
	
	
}

package com.rongji.dfish.commons;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import com.rongji.dfish.base.Utils;

/**
 * ReaderDomain 读者域
 * <p>该读者域可能有多个元素分别表示某个角色(机构)的所有人员，某个角色(机构)的直属人员，以及人员</p>
 * <p>比如说如果一格文档的读者域是<code>RC信息化部,RD网优中心,UD张总</code>
 * 表示信息化部的所有人都可以看到这个文档，包括其下属的BI项目组，MSS项目组的成员
 * 网优中心的直属人员也可以看到这个文档，
 * 额外的，张总也可以看到这个文档</p>
 * <p>在ITASK7中UD RC的前缀后面放的是这些角色或人员的ID。是定长8位的,比如 UD00000658</p>
 * <p>读者域各个段不一定互斥.比如说读者域中包含了RC信息化部，同时也可以有 UD王五，
 * 这个王五现在是信息化部的，可以看见，人事变动到市场部，那他也能看见。
 * 同理 有信息化部也可同时有它下属的BI项目组。
 * 但有可能业务需要会把这些情况进行排除。本类不负责进行这些逻辑数据的排除</p>
 * <p>但一种情况，就是如果包含了RC信息化部，同时还有RD信息化部。
 * 默认情况下你还是可以同时添加这两个项。但，通常这是无效的，本类会提供一个快捷操作，ignoreDirectWithCascade方法。
 * 它可以把已经存在RC又同时存在RD情况的RD部分删除掉。建议文档的读者域在入库前调用，以优化</p>
 * <p>一般判断张三有那些可阅读的文档的时候， 如果他在 信息化部下的BI项目组。那么可能和他有关的读者域是
 * <code>UD张三,RDBI项目组,RCBI项目组,RC信息化部</code>这时候会有RD和RC同时出现</p>
 * @author ITASK-TEAM V1.0 LinLW
 *
 */
public class ReaderDomain implements Cloneable{
	LinkedHashSet<String> udSet=new LinkedHashSet<String>();
	LinkedHashSet<String> rdSet=new LinkedHashSet<String>();
	LinkedHashSet<String> rcSet=new LinkedHashSet<String>();
	@Override
	public String toString(){
		StringBuilder sb=new StringBuilder();
		boolean begin=true;
		for(String str :rcSet){
			if(!begin)sb.append(',');
			sb.append("RC");
			sb.append(str);
			begin=false;
		}
		for(String str :rdSet){
			if(!begin)sb.append(',');
			sb.append("RD");
			sb.append(str);
			begin=false;
		}
		for(String str :udSet){
			if(!begin)sb.append(',');
			sb.append("UD");
			sb.append(str);
			begin=false;
		}
		return sb.toString();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public ReaderDomain clone(){
		ReaderDomain instance=new ReaderDomain();
		instance.rcSet=(LinkedHashSet<String>) rcSet.clone();
		instance.rdSet=(LinkedHashSet<String>) rdSet.clone();
		instance.udSet=(LinkedHashSet<String>) udSet.clone();
		return instance;
	}
	
	@Override
	public boolean equals(Object o){
		if(o==null)return false;
		if(o==this)return true;
		if(!(o instanceof ReaderDomain))return false;
		ReaderDomain cast=(ReaderDomain)o;
		
		return cast.rcSet.equals(rcSet)&&
		cast.rdSet.equals(rdSet)&&
		cast.udSet.equals(udSet);
	}
	@Override
	public int hashCode(){
		return rcSet.hashCode() ^ rdSet.hashCode() ^ udSet.hashCode();
	}
	/**
	 * 并集
	 * @param rd1
	 * @param rd2
	 * @return
	 */
	public static ReaderDomain union(ReaderDomain... readerDomains){
		ReaderDomain r=new ReaderDomain();
		for(ReaderDomain rd:readerDomains){
			r.rcSet.addAll(rd.rcSet);
			r.rdSet.addAll(rd.rdSet);
			r.udSet.addAll(rd.udSet);
		}
		return r;
	}
	/**
	 * 交集
	 * @param rd1
	 * @param rd2
	 * @return
	 */
	public static ReaderDomain intersection(ReaderDomain... readerDomains){
		if(readerDomains==null||readerDomains.length==0)return new ReaderDomain();
		ReaderDomain r=readerDomains[0].clone();
		for(int i=1;i<readerDomains.length;i++){
			ReaderDomain rd=readerDomains[i];
			r.rcSet.retainAll(rd.rcSet);
			r.rdSet.retainAll(rd.rdSet);
			r.udSet.retainAll(rd.udSet);
		}
		return r;
	}

	public ReaderDomain(String str){
		if(str==null)return;
		for(String token:str.split(",")){
			if(token==null||token.equals(""))continue;
			if(token.startsWith("UD")){
				udSet.add(token.substring(2));
			}else if(token.startsWith("RC")){
				rcSet.add(token.substring(2));
			}else if(token.startsWith("RD")){
				rdSet.add(token.substring(2));
			}
		}
	}
	
	/**
	 * 增加读者域
	 * @param reader
	 * @author ITask-team YLM
	 * @return
	 */
	public ReaderDomain addReader(String reader) {
	    if (Utils.isEmpty(reader)) {
	        return this;
	    }
	    for(String token:reader.split(",")){
            if(Utils.isEmpty(token)) {
                continue;
            }
            if(token.startsWith("RC")){
                rcSet.add(token.substring(2));
            } else if(token.startsWith("RD")){
                rdSet.add(token.substring(2));
            } else if(token.startsWith("UD")){
                udSet.add(token.substring(2));
            } else {
                udSet.add(token);
            }
        }
	    return this;
	}
	
	public ReaderDomain(){}
	
	/**
	 * 如果这个ReaderDomain中含了UCxxx那么将会把对应的UDxxx去除
	 * <p>大部分情况下，作为和业务数据一起存储的ReaderDomain都可以调用这个方法，以节省空间。</p>
	 * <p>这个方法不适用于当前人员可见的ReaderDomain</p>
	 */
	public void ignoreDirectWithCascade(){
		rdSet.removeAll(rcSet);
	}
	
	public void addRoleCascade(String roleId){
		if(Utils.isEmpty(roleId)){
			return;
		}
		if(roleId.startsWith("RC")){
			rcSet.add(roleId.substring(2));
		} else {
			rcSet.add(roleId);
		}
	}
	public void addRoleDirect(String roleId){
		if(Utils.isEmpty(roleId)){
			return;
		}
		if(roleId.startsWith("RD")){
			rdSet.add(roleId.substring(2));
		} else {
			rdSet.add(roleId);
		}
	}
	public void addUser(String userId){
		if(Utils.isEmpty(userId)){
			return;
		}
		if(userId.startsWith("UD")){
			udSet.add(userId.substring(2));
		} else {
			udSet.add(userId);
		}
	}
	public void removeRoleCascade(String roleId){
		rcSet.remove(roleId);
	}
	public void removeRoleDirect(String roleId){
		rdSet.remove(roleId);
	}
	public void removeUser(String userId){
		udSet.remove(userId);
	}
	public List<String> getUsers(){
		return new ArrayList<String>(this.udSet);
	}
	public List<String> getRoleCascade(){
		return new ArrayList<String>(this.rcSet);
	}
	public List<String> getRoleDirect(){
		return new ArrayList<String>(this.rdSet);
	}
}

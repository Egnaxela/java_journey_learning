package com.rongji.dfish.commons;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseDialogTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.DialogTemplate;
import com.rongji.dfish.engines.xmltmpl.Panel;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.Skin;
import com.rongji.dfish.engines.xmltmpl.VAlign;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.HorizontalPanel;
import com.rongji.dfish.engines.xmltmpl.component.HtmlPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.engines.xmltmpl.component.SourcePanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;

public class Style {
	
	/**
	 * 垂直间距
	 */
	public static final int VERTICAL_MARGIN = 10;
	
	/**
	 * 横向间距
	 */
	public static final int HORIZONTAL_MARGIN = 20;
	
	/**
	 * 框架面板ID
	 */
	public static final String PANEL_FRAME = "frame";

	
	/**
	 * 作区内容面板ID
	 */
	public static final String PANEL_WORK_ROOT = "workRoot";

	/**
	 * 工作区面板ID
	 */
	public static final String PANEL_WORKVP = "workVP";

	/**
	 * 工作区标题栏切割面板ID
	 */
	public static final String PANEL_WORK_TITLEHP = "workTitleHP";

	/**
	 * 工作区标题面板ID
	 */
	public static final String PANEL_WORK_TITLE = "workTitle";

	/**
	 * 工作区操作按钮面板ID
	 */
	public static final String PANEL_WORK_OPER = "workOper";

	/**
	 * 作区内容面板ID
	 */
	public static final String PANEL_WORK_CONTENT = "workContent";

	/**
	 * 弹窗根面板ID
	 */
	public static final String PANEL_POPVP = "popVP";

	/**
	 * 弹窗表单面板ID
	 */
	public static final String PANEL_POP_FORM = "popForm";

	/**
	 * 弹窗操作按钮面板ID
	 */
	public static final String PANEL_POP_OPER = "popOper";
	
	public static final String PANEL_TOOL = "tool";
	
	public static final String PANEL_TOOLVP = "toolVP";
	
	public static final String PANEL_TOOL_TOPHP = "topHP";
	
	public static final String PANEL_TOOL_TITLE = "toolTitle";
	
	public static final String PANEL_TOOL_OPER = "toolOper";
	
	public static final String PANEL_TOOL_SEARCHVP = "toolSearchVP";
	
	public static final String PANEL_TOOL_SEARCHHP = "toolSearchHP";
	
	public static final String PANEL_TOOL_SEARCH = "toolSearch";
	
	public static final String PANEL_TOOL_CONTENT = "toolContent";
	
	
	
	
	public static Panel getWorkPanel(){
		
		VerticalPanel workVP =  new VerticalPanel(PANEL_WORKVP, "36,*");
		
		HorizontalPanel workTitleHP = new HorizontalPanel(PANEL_WORK_TITLEHP, "*,300");
		workVP.addSubPanel(workTitleHP);
		//workTitleHP.setStyle("margin:0px 20px;");
		//workTitleHP.setStyleClass("bd-title bd-onlybottom");//bg-title 
		//workTitleHP.setVerticalMinus(1);
		//workTitleHP.setHorizontalMinus(40);
		
		HtmlPanel workTitle = new HtmlPanel(PANEL_WORK_TITLE, "工作区标题");
		workTitleHP.addSubPanel(workTitle);
		//workTitle.setAlign(Align.left);
		//workTitle.setVAlign(VAlign.middle);
		
	    ButtonBarPanel workOper = new ButtonBarPanel(PANEL_WORK_OPER);
	    workTitleHP.addSubPanel(workOper);
	    workTitleHP.setStyleClass("bg-low");
	    workOper.setAlign(Align.right);
	    
	    FlowPanel workContent = new FlowPanel(PANEL_WORK_CONTENT);
	    workVP.addSubPanel(workContent);
	    workContent.setStyle("padding:0px 20px;");
	    workContent.setHorizontalMinus(40);
	    workContent.setScroll(Scroll.miniscroll);
	    
	    return workVP;
	}
	
	public BaseView getPopFormView()throws Exception{
		
		BaseView view = new BaseView();
    	
		VerticalPanel popVP = new VerticalPanel(PANEL_POPVP, "*,42");
		view.setRootPanel(popVP);
		
		FormPanel popForm = new FormPanel(PANEL_POP_FORM);
		popVP.addSubPanel(popForm);
		popForm.setStyle("padding:20px 15px 0px 2px;");
		popForm.setScroll(Scroll.miniscroll);
		
		ButtonBarPanel popOper = new ButtonBarPanel(PANEL_POP_OPER);
	    popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
	    popOper.setFace(ButtonFace.office);
	    popOper.setStyleClass("d-foot");
	    popOper.setStyle("padding:0px 35px");
		
		return view;
	}
	
	public BaseView getToolView(HttpServletRequest request) throws Exception{
		
		BaseView view = new BaseView();
    	
    	VerticalPanel tool = new VerticalPanel(PANEL_TOOL, "*");
    	view.setRootPanel(tool);
    	tool.setStyleClass("tool bd-title bd-onlyleft bg-white");
    	tool.setHorizontalMinus(1);
    	
		VerticalPanel toolVP = new VerticalPanel(PANEL_TOOLVP, "49,30,*");
		tool.addSubPanel(toolVP);
		
		HorizontalPanel topHP = new HorizontalPanel(PANEL_TOOL_TOPHP, "*,36");
		toolVP.addSubPanel(topHP);
        topHP.setStyleClass("bg-portal");
        topHP.setStyle("padding-left:10px;");
        topHP.setHorizontalMinus(10);
        
        HtmlPanel toolTitle = new HtmlPanel(PANEL_TOOL_TITLE, "标题");
        topHP.addSubPanel(toolTitle);
        toolTitle.setStyle("font-size:16px;");
        toolTitle.setVAlign(VAlign.middle);
        
		HtmlPanel close = new HtmlPanel("close", "<div class=\"tool-close\" title=\"关闭\" " +
								" onclick=\"VM().find('topMenu').getSelected().clk();\" " +
								" onmouseover=\"$.class_add(this, 'over');\" " +
								" onmouseout=\"$.class_del(this, 'over');\" ></div>");
		topHP.addSubPanel(close);
		close.setAlign(Align.center);
		close.setVAlign(VAlign.middle);
		
		VerticalPanel searchVP = new VerticalPanel(PANEL_TOOL_SEARCHVP, "*");
		toolVP.addSubPanel(searchVP);
		
		HorizontalPanel searchHP = new HorizontalPanel(PANEL_TOOL_SEARCHHP, "*");
		searchVP.addSubPanel(searchHP);
		searchHP.setStyleClass("bd-tool bd-noleft bd-noright");
		searchHP.setVerticalMinus(2);
		
		HtmlPanel search = new HtmlPanel(PANEL_TOOL_SEARCH, "搜索");
		searchHP.addSubPanel(search);
		search.setVAlign(VAlign.middle);
		
		VerticalPanel contentVP = new VerticalPanel("toolContentVP", "*");
		toolVP.addSubPanel(contentVP);
		HtmlPanel toolContent = new HtmlPanel(PANEL_TOOL_CONTENT, "内容");
		contentVP.addSubPanel(toolContent);
		toolContent.setAlign(Align.center);
		toolContent.setVAlign(VAlign.middle);
		
		return view;
	}
	
	public DialogTemplate getDialogTemplate(HttpServletRequest request, String id){
		
		String shadow = Utils.getParameter(request, "shadow");
		if("1".equals(shadow)){
			if("f_std".equals(id)){
				return TMPL_STD;
			} else if("f_std_x".equals(id)){
				return TMPL_CLOSE;
			}
		} else {
			if("f_std".equals(id)){
				return TMPL_STD_BORDER;
			} else if("f_std_x".equals(id)){
				return TMPL_CLOSE_BORDER;
			}
		}
		return null;
	}
	
	
	String ID_TITLE_MAIN="f_title_main";
	String ID_BUTTONBAR_TOP_RIGHT="f_btn_top_right";
	String ID_MAIN_CONTENT = "f_main_content";
	String ID_CHECKBOX_PANEL ="f_checkbox";
	String ID_BUTTONBAR_BOTTOM = "f_btn_bottom";
	String ID_PAGEPANEL_BOTTOM = "f_page_bottom";
	String ID_BUTTONBAR_NAVIGATION="f_title_mav";
	String ID_MAIN_TITLE_SHELL="f_main_title_shell";
	String ID_MAIN_CONTENT_SHELL="f_main_content_shell";
	String ID_BUTTONBAR_TOP_LEFT = "f_btn_left";
	String ID_CHECKBOX_BATCH = "f_checkbox_batch";
	
	public int getButtonBarHeight() {
		return 57;
	}

	public int getOutterPadding() {
		return 0;
	}

	public String getOutterPaddingClass() {
		return "bg-gray";
	}


	public String getMainBorderClass() {
		return "bd-main bd-noleft bg-white";
	}

	public String getMainTitleClass() {
		return "tt-main bd-form bd-onlybottom";
	}

	public int getMainTitleHeight() {
		return 51;
	}
	public int getLiftTitleHeight() {
		return 51;
	}
	
	public int getPageHeight() {
		return 51;
	}

	public String getPageClass() {
		return "bd-form bd-onlytop";
	}
	
	public int getContentCellspacing() {
        return 25;
    }
	
	private Locale locale;
	public Locale getLocale() {
		if(locale==null){
			return Locale.getDefault();
		}
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale=locale;
	}
	
	
	
private static BaseDialogTemplate TMPL_STD = new BaseDialogTemplate("f_std");
	
	private static BaseDialogTemplate TMPL_CLOSE = new BaseDialogTemplate("f_std_x");
	
	private static BaseDialogTemplate TMPL_STD_BORDER = new BaseDialogTemplate("f_std");
	
	private static BaseDialogTemplate TMPL_CLOSE_BORDER = new BaseDialogTemplate("f_std_x");
	
	static{
		SourcePanel CONTENT = new SourcePanel("dlg-src","");
		
		SourcePanel CONTENT_BD = new SourcePanel("dlg-src","");
		CONTENT_BD.setStyleClass("d-bd");
		CONTENT_BD.setHorizontalMinus(2);
		CONTENT_BD.setVerticalMinus(1);
		
		HtmlPanel DLG_TITLE = new HtmlPanel("dlg-tt",null);
		DLG_TITLE.setStyleClass("d-tt");
		
		HtmlPanel DLG_MAX_BTN = new HtmlPanel("dlg-max",null);
		DLG_MAX_BTN.setStyleClass("d-b-max");
		
		HtmlPanel DLG_CLOSE_BTN = new HtmlPanel("dlg-x",null);
		DLG_CLOSE_BTN.setStyleClass("d-b-x");
		
		VerticalPanel stdRoot = new VerticalPanel(null,"36,*");
		stdRoot.setStyleClass("d-bg");
		
		VerticalPanel stdTop = new VerticalPanel(null,"*");
		stdTop.setStyleClass("d-bg-top");
		stdTop.setStyle("border-width:0px;");
		
		HorizontalPanel stdTopTitle = new HorizontalPanel(null,"*,36,36");
		stdTop.addSubPanel(stdTopTitle);
		stdTopTitle.setStyleClass("d-tc-r");
		stdTopTitle.addSubPanel(DLG_TITLE,DLG_MAX_BTN,DLG_CLOSE_BTN);
		
		stdRoot.addSubPanel(stdTop, CONTENT);
		
		TMPL_STD.addSubPanel(stdRoot);
		TMPL_STD.setFace("dlg-std");
		
		VerticalPanel stdBdRoot = new VerticalPanel(null,"37,*");
		stdBdRoot.setStyleClass("d-bg");
		
		VerticalPanel stdBdTop = new VerticalPanel(null,"*");
		stdBdTop.setStyleClass("d-bg-top");
		stdBdTop.setHorizontalMinus(2);
		stdBdTop.setVerticalMinus(1);
		
		HorizontalPanel stdBdTopTitle = new HorizontalPanel(null,"*,36,36");
		stdBdTop.addSubPanel(stdBdTopTitle);
		stdBdTopTitle.setStyleClass("d-tc-r");
		stdBdTopTitle.addSubPanel(DLG_TITLE,DLG_MAX_BTN,DLG_CLOSE_BTN);
		
		stdBdRoot.addSubPanel(stdBdTop, CONTENT_BD);
		
		TMPL_STD_BORDER.addSubPanel(stdBdRoot);
		TMPL_STD_BORDER.setFace("dlg-std");

		VerticalPanel closeRoot = new VerticalPanel(null,"36,*");
		closeRoot.setStyleClass("d-bg");
		
		VerticalPanel closeTop = new VerticalPanel(null,"*");
		closeTop.setStyleClass("d-bg-top");
		closeTop.setStyle("border-width:0px;");

		HorizontalPanel closeTopTitle = new HorizontalPanel(null,"*,36");
		closeTop.addSubPanel(closeTopTitle);
		closeTopTitle.setStyleClass("d-tc-r");
		closeTopTitle.addSubPanel(DLG_TITLE, DLG_CLOSE_BTN);
		
		closeRoot.addSubPanel(closeTop,CONTENT);
		TMPL_CLOSE.addSubPanel(closeRoot);
		TMPL_CLOSE.setFace("dlg-std");

		VerticalPanel closeBdRoot = new VerticalPanel(null,"37,*");
		closeBdRoot.setStyleClass("d-bg");
		
		VerticalPanel closeBdTop = new VerticalPanel(null,"*");
		closeBdTop.setStyleClass("d-bg-top");
		closeBdTop.setHorizontalMinus(2);
		closeBdTop.setVerticalMinus(1);

		HorizontalPanel closeBdTopTitle = new HorizontalPanel(null,"*,36");
		closeBdTop.addSubPanel(closeBdTopTitle);
		closeBdTopTitle.setStyleClass("d-tc-r");
		closeBdTopTitle.addSubPanel(DLG_TITLE, DLG_CLOSE_BTN);
		
		closeBdRoot.addSubPanel(closeBdTop,CONTENT_BD);
		TMPL_CLOSE_BORDER.addSubPanel(closeBdRoot);
		TMPL_CLOSE_BORDER.setFace("dlg-std");
	}
}

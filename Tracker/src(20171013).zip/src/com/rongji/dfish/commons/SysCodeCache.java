﻿package com.rongji.dfish.commons;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import com.rongji.dfish.base.Utils;
import com.rongji.system.entity.SysCode;
import com.rongji.system.entity.SysCodeType;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

/**
 * 人员姓名的缓存
 * @author Administrator
 *
 */
public class SysCodeCache {
	private SysCodeCache(){}
	private static SysCodeCache instance;
	public static SysCodeCache getInstance(){
		if(instance==null){
			synchronized(SysCodeCache.class){
				if(instance==null)instance=new SysCodeCache();
			}
		}
		return instance;
	}

	/**
	 * 清除缓存，供管理维护用
	 */
	public void clearCache(){
		//获得缓冲的数据，供管理维护使用。
		this.flowNodeNames=null;
		this.loaded=false;
	}

	





	private List<Object[]> flowNodeNames;
	private List<String> endTimeNotNullCertificates ;
	private List<String[]> flowTypes;
	private List<String[]> flowCategoryNames;
	private List<SysCode> flowCategory;
	
	private long lastLoaded;
	private boolean loaded;
	private static final Object LOADING_LOCK = new Object();
	
	public void loadCache(){
		loaded=false;
		lastLoaded=System.currentTimeMillis();
		synchronized(LOADING_LOCK){
			if(!loaded){//防止并发的load
				try {
					loadCacheFromLoader();
					loaded=true;
				} catch (RemoteException e) {
					e.printStackTrace();
				}		
			}
		}
	}


	private void loadCacheFromLoader() throws RemoteException{
		CodeManService manService = Services.getService(CodeManService.class);
		List<SysCodeType> sysCodeTypes = manService.findCodeTypes();
		List<Object[]> flowNodeNameResult = new ArrayList<Object[]>();
		List<String> endTimeNotNullResult = new ArrayList<String>();
		List<String[]> flowTypeResult = new ArrayList<String[]>();
		List<String[]> flowCategoryNameResult = new ArrayList<String[]>();
		
		for (SysCodeType sysCodeType : sysCodeTypes) {
			if (sysCodeType.getTypeId().startsWith("FLOW_NODE_TYPE")) {
				List<SysCode> flows = manService.findCodes(sysCodeType
						.getTypeId(), true);
				for (SysCode code : flows) {
					flowNodeNameResult.add(new Object[] { code.getId().getCodeValue(),
							code.getCodeName() });
				}
			}
			if(sysCodeType.getTypeId().startsWith("ENDTIME_NOT_NULL")){
				List<SysCode> flows = manService.findCodes(sysCodeType
						.getTypeId(), false);
				for (SysCode code : flows) {
					endTimeNotNullResult.add(code.getId().getCodeValue());
				}
			}
			if(sysCodeType.getTypeId().startsWith("NEW_LICENSE_CODE")){
				List<SysCode> flows = manService.findCodes(sysCodeType
						.getTypeId(), false);
				for (SysCode code : flows) {
					flowTypeResult.add(new String[] { code.getId().getCodeValue(),
							code.getCodeName() });
				}
			}
			if (sysCodeType.getTypeId().startsWith("FLOW_CATEGORY")) {
				List<SysCode> flows = manService.findCodes(sysCodeType
						.getTypeId(), true);
				for (SysCode code : flows) {
					flowCategoryNameResult.add(new String[] { code.getId().getCodeValue(),
							code.getCodeName() });
				}
				flowCategory = flows;
			}
			
		}
		// 准备完毕后，把本地在用的数据替换
		this.flowNodeNames = flowNodeNameResult;
		this.endTimeNotNullCertificates = endTimeNotNullResult;
		this.flowTypes = flowTypeResult;
		this.flowCategoryNames = flowCategoryNameResult;
	}
	private void ensureCacheLoaded() {
		if (flowNodeNames == null) {
			loadCache();
		}else if(System.currentTimeMillis()-lastLoaded>5*60*1000L){
			new Thread(){
				public void run(){
					SysCodeCache.getInstance().loadCache();
				}
			}.start();
		}
	}

	public String getFlowNodeName(String flowNode) {
		ensureCacheLoaded();
		for(Object[] row :flowNodeNames){
			if(row[0].equals(flowNode)){
				return String.valueOf(row[1]);
			}
		}
		return null;
	}

	public List<String> findEndTimeNotNullCertificates() {
		ensureCacheLoaded();
		return endTimeNotNullCertificates;
	}
	/**
	 * 获取可用的流程类型
	 * [0]:标识 [1]:名称
	 * @return
	 */
	public List<String[]> flowTypes() {
		ensureCacheLoaded();
		return flowTypes;
	}
	
	public String getFlowTypeNameByFlowType(String flowType) {
		ensureCacheLoaded();
		for(String[] row :flowTypes){
			if(row[0].equals(flowType)){
				return String.valueOf(row[1]);
			}
		}
		return null;
	}
	
	
	public String getApplyTypeName(String applyType){
		ensureCacheLoaded();
		for(String[] row :flowCategoryNames){
			if(row[0].equals(applyType)){
				return String.valueOf(row[1]);
			}
		}
		return null;
	}
	/**
	 * 取得申请类别名称
	 * @param containDisabled true取得所有的申请类别包含禁用的  false 取得非禁用的申请类别
	 * @return [0] id  [1] codeName
	 */
	public List<Object[]> findFlowCategoryNames(boolean containDisabled){ 
		ensureCacheLoaded();
		List<Object[]> flowCategoryNames = new ArrayList<Object[]>();
		if(Utils.notEmpty(flowCategory)){
			for (SysCode sysCode : flowCategory) {
				if(!containDisabled && !"0".equals(sysCode.getFlag())){
					continue;
				}
				flowCategoryNames.add(new String[]{ sysCode.getId().getCodeValue(),
						sysCode.getCodeName()});
			}
		}
		return flowCategoryNames;
	}
}


package com.rongji.dfish.commons;

public class TimedValue<T extends Object> {
	T v;
	public T getV() {
		return v;
	}
	public void setV(T v) {
		this.v = v;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	long time;
	public TimedValue(T v){
		this.v=v;
		this.time=System.currentTimeMillis();
	}
	
	public static final long LIFE_TIME=9999999999999L; 
}

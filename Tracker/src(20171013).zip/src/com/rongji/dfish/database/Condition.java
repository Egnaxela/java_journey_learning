package com.rongji.dfish.database;

/**
 * Condition 表示页面提交的一个查询字段
 * @author LinLW
 *
 */
public class Condition {
	private String seriesNo;
	private String name;
	private String oper;
	private String[] value;
	private boolean isHidden;
	private boolean isRemove;

	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * 名称
	 * @param fieldName
	 */
	public void setName(String fieldName) {
		this.name = fieldName;
	}
	/**
	 * 操作符
	 * @return
	 */
	public String getOper() {
		return oper;
	}
	/**
	 * 操作符
	 * @param oper
	 */
	public void setOper(String oper) {
		this.oper = oper;
	}
	/**
	 * 值
	 * @return
	 */
	public String[] getValue() {
		return value;
	}
	/**
	 * 
	 * @param value
	 */
	public void setValue(String[] value) {
		this.value = value;
	}
	/**
	 * 序列号
	 * @return 
	 * @see {@link AdvanceSearchTemplate#getSeriesNo()}
	 */
	public String getSeriesNo() {
		return seriesNo;
	}
	/**
	 * 序列号
	 * @param seriesNo
	 * @see {@link AdvanceSearchTemplate#getSeriesNo()}
	 */
	public void setSeriesNo(String seriesNo) {
		this.seriesNo = seriesNo;
	}
	/**
	 * 判断条件是否隐藏
	 * @return
	 */
	public boolean isHidden() {
		return isHidden;
	}
	
	/**
	 * 设置条件是否隐藏
	 * @param isHidden
	 */
	public void setHidden(boolean isHidden) {
		this.isHidden = isHidden;
	}
	/**
	 * 是否在查询中移除
	 * @return
	 */
	public boolean isRemove() {
		return isRemove;
	}
	/**
	 * 设置 是否在查询中移除
	 * @param isRemove
	 */
	public void setRemove(boolean isRemove) {
		this.isRemove = isRemove;
	}
	
	

}

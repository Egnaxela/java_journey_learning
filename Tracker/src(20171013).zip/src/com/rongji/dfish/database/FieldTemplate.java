package com.rongji.dfish.database;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


/**
 * FieldTemplate 为字段的模板。
 * 字段的模板可以知道字段的作用
 * @author LinLW
 */
public interface FieldTemplate<T extends FieldTemplate<T>> {
	/**
	 * 获取字段标示符(一般和数据库字段一致)
	 * @return
	 */
	public String getFieldName();
	
	/**
	 * 获取字段显示的中文名称
	 * @return
	 */
	public String getFieldCname();
	/**
	 * 获取字段显示的中文名称
	 * @return
	 */
	public String getConfig();
	
	/**
	 * 获取字段标示符(一般和数据库字段一致)
	 * @return
	 */
	public T setFieldName(String fieldName);
	
	
	/**
	 * 获取字段显示的中文名称
	 * @return
	 */
	public T setFieldCname(String fieldCname);
	/**
	 * 获取字段显示的中文名称
	 * @return
	 */
	public T setConfig(String config);
	

	/**
	 * 是否可以当列表显示字段
	 * @return
	 */
	public Boolean getShowField();

	/**
	 * 是否可以当列表显示字段
	 * @param showField
	 * @return
	 */
	public T setShowField(Boolean showField);

	/**
	 * 是否可以当查询条件
	 * @return
	 */
	public Boolean getCondition() ;

	/**
	 * 是否可以当查询条件
	 * @param condition
	 * @return
	 */
	public T setCondition(Boolean condition) ;
	
	

	/**
	 * 获取值对应的名称。如果是字典值，数据库里面1可能显示为男。否则可能是原值显示
	 * @param code
	 * @param context
	 * @return
	 */
	public String getShowName(Object value,Map<String,Object> context);

	/**
	 * 获取字典数据
	 * 不是所有字典型的数据都支持该方法。
	 * 部分数据量太多的也不适合使用该方法。
	 * @param fieldName 字段名称
	 * @param codeType 字典类型
	 * @param context 缓存
	 * @return
	 */
	public List<Object []> getOptions(Map<String,Object> context);
	
	/**
	 * 设置字段的额外属性
	 * @param key
	 * @return
	 */
	public String getProperty(String key);
	
	/**
	 * 设置字段的额外属性
	 * @param key
	 * @param value
	 */
	public T setProperty(String key, String value);



}

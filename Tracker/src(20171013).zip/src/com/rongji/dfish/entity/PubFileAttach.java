package com.rongji.dfish.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * PubFileAttach entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="PUB_FILE_ATTACH")
public class PubFileAttach implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
    private static final long serialVersionUID = 7917134411182082638L;
    @Id
    @Column(name="ATTACH_ID")
	private String attachId;
    @Column(name="CREATE_USER")
	private String createUser;
    @Column(name="MODIFY_TIME")
	private Date modifyTime;
    @Column(name="ATTACH_NAME")
	private String attachName;
    @Column(name="ATTACH_URL")
	private String attachUrl;
    @Column(name="ATTACH_SIZE")
	private Long attachSize;
    @Column(name="LINK_TYPE")
	private String linkType;
    @Column(name="LINK_KEYWORD")
	private String linkKeyword;

	// Constructors

	/** default constructor */
	public PubFileAttach() {
	}

	/** minimal constructor */
	public PubFileAttach(String attachId) {
		this.attachId = attachId;
	}

	/** full constructor */
	public PubFileAttach(String attachId, String createUser, Date modifyTime,
			String attachName, String attachUrl, Long attachSize,
			String linkType, String linkKeyword) {
		this.attachId = attachId;
		this.createUser = createUser;
		this.modifyTime = modifyTime;
		this.attachName = attachName;
		this.attachUrl = attachUrl;
		this.attachSize = attachSize;
		this.linkType = linkType;
		this.linkKeyword = linkKeyword;
	}

	public String getAttachId() {
		return this.attachId;
	}

	public void setAttachId(String attachId) {
		this.attachId = attachId;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getAttachName() {
		return this.attachName;
	}

	public void setAttachName(String attachName) {
		this.attachName = attachName;
	}

	public String getAttachUrl() {
		return this.attachUrl;
	}

	public void setAttachUrl(String attachUrl) {
		this.attachUrl = attachUrl;
	}

	public Long getAttachSize() {
		return this.attachSize;
	}

	public void setAttachSize(Long attachSize) {
		this.attachSize = attachSize;
	}

	public String getLinkType() {
		return this.linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	public String getLinkKeyword() {
		return this.linkKeyword;
	}

	public void setLinkKeyword(String linkKeyword) {
		this.linkKeyword = linkKeyword;
	}

}
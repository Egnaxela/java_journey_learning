package com.rongji.dfish.framework;

import java.util.List;

/**
 * DFish 中用到的键值对缓存。
 * 为了方便所有值都是String
 * 注意缓存中的值不保证都不会丢失，可能会根据缓存的大小，
 * 数据的新旧部分数据会被清理，具体缓存的实现将会指定是清理最旧的数据还是清理不经常使用的数据，或是其他规范。
 * @author LinLW
 */
public interface Cache {
	/**
	 * 取得一个值
	 * @param key String
	 * @return String
	 */
	String get(String key);
	/**
	 * 取得多个值，一次性取得多个值，可以触发批量，提高性能
	 * @param key String[]
	 * @return List&lt;String&gt;
	 */
	List<String> gets(String... key);
	/**
	 * 设置一个值。
	 * 设置这个值的时候，<strong>有可能</strong>把旧的值置放出来。
	 * @param key String
	 * @param value String
	 * @return String
	 */
	String put(String key, String value);
	/**
	 * 删除一个值。
	 * 删除这个值的时候，<strong>有可能</strong>把旧的值置放出来。
	 * @param key String
	 * @return  String
	 */
	String remove(String key);
	/**
	 * 判定是否包含本关键字
	 * @param key String
	 * @return boolean
	 */
	boolean contians(String key);
	/**
	 * 如果这个缓存支持size的话，应该返回这个缓存现在已经缓存了多少对键值对。
	 * 如果不支持的话，返回-1
	 * @return int
	 */
	int size();
	/**
	 * 清空缓存
	 */
	void clear();

}

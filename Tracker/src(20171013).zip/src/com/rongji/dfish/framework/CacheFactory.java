package com.rongji.dfish.framework;

public interface CacheFactory {
	/**
	 * 取得cache
	 * @param name
	 * @return
	 */
	Cache getCache(String name);
	/**
	 * 删除cache
	 * @param name
	 */
	void deleteCache(String name);
}

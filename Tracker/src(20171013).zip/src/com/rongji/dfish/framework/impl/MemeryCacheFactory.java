package com.rongji.dfish.framework.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.rongji.dfish.framework.Cache;
import com.rongji.dfish.framework.CacheFactory;

public class MemeryCacheFactory implements CacheFactory{
	
	public static class MemeryCache extends java.util.LinkedHashMap<String,String>  implements Cache{
		private static final long serialVersionUID = 1L;
		private static final int MAX_ENTRIES = 65535;
		private static final Object mutex=new Object();
		@Override
		protected boolean removeEldestEntry(Entry<String, String> eldest) {
			return size()>MAX_ENTRIES;
		}
		
		@Override
		public boolean contians(String key) {
			 synchronized(mutex) {return containsKey(key);}
		}

		@Override
		public  String get(String key) {
			 synchronized(mutex) {return super.get(key);}
		}

		@Override
		public String remove(String key) {
			 synchronized(mutex) {return super.remove(key);}
		}

		@Override
		public void clear() {
			 synchronized(mutex) {super.clear();}
		}

		@Override
		public int size() {
			 synchronized(mutex) {return super.size();}
		}

		@Override
		public String put(String key, String value) {
			 synchronized(mutex) {return super.put(key, value);}
		}

		@Override
		public List<String> gets(String... keys) {
			synchronized(mutex) {
				List<String> result=new ArrayList<String>();
				for(String key:keys){
					result.add(get(key));
				}
				return result;
			 }
		}
		
	}
	private Map<String,Cache> caches=Collections.synchronizedMap(new HashMap<String,Cache>());
	@Override
	public Cache getCache(String name) {
		Cache c=caches.get(name);
		if(c!=null){
			return c;
		}
		c=new MemeryCache();
		caches.put(name, c);
		return c;
	}
	@Override
	public void deleteCache(String name) {
		Cache c=caches.remove(name);
		if(c!=null){
			//内存缓存如果被清空的话，会调用clear方法帮助内存释放
			c.clear();
		}
	}
}

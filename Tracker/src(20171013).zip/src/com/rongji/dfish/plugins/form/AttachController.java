package com.rongji.dfish.plugins.form;

import static com.rongji.dfish.framework.FrameworkHelper.outPutTEXT;
import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.rongji.dfish.base.FileUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.entity.PubFileAttach;
import com.rongji.dfish.framework.FrameworkHelper;

@Controller
@RequestMapping("/attach")
public class AttachController extends ExceptionCaptureController{
	@RequestMapping("/deleteTempFile")
	public void deleteTempFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String deleteId = request.getParameter("deleteId");
		if(Utils.isEmpty(deleteId)){
			outPutXML(response, new JSCommand("",""));
			return ;
		}
		String id = AttachService.decId(deleteId);
		String attachId = id.indexOf("A") != -1 ? id.substring(1) : id;
		PubFileAttach attach = AttachService.getFileAttachById(attachId);
		AttachService.deleteFileAttach(attach,false);
		
		outPutXML(response,new JSCommand("",""));
	}
	/**
	 * 文件下载
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/fileDownload")
	public void fileDownload(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String encAttachId = request.getParameter("encAttachId");
		String contentType = "application/octet-stream";// 如果不是直接在页面打开。那么下载都当成是二进制流。
		if (Utils.isEmpty(encAttachId)) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return ;
		}
		String attachId = AttachService.decId(encAttachId);
		if (Utils.isEmpty(attachId)) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return ;
		}
		if(attachId.indexOf("A")==0){
			attachId = attachId.substring(1);
		}
		PubFileAttach attach = AttachService.getFileAttachById(attachId);
		if(attach != null){
			String fileName = attach.getAttachName();
			String attachUrl = attach.getAttachUrl();
			if(!FileUtil.getFileExtName(attachUrl).equals(FileUtil.getFileExtName(fileName))){
				fileName = fileName+FileUtil.getFileExtName(attachUrl);
			}
			String rootUrl = FrameworkHelper.getSystemConfig(
					AttachService.MOD_RES_ATTACHURL,
						AttachService.getServPath());//SystemConfigMethods.MOD_RES_ATTACHURL
			rootUrl = rootUrl.replace('\\', '/');
			if (!rootUrl.endsWith("/")){
					rootUrl += "/";
			}
			String fileUrl = rootUrl
						+ (attach.getAttachUrl().startsWith("/") ? attach
								.getAttachUrl().substring(1) : attach
								.getAttachUrl());
			File file = new File(fileUrl);
			FileUtil.downLoadFile(request, response, file, fileName,
					contentType);
		}
	}
	/**
	 * 选择文件后自动调用该方法。 该方法用户 保存文件基本信息如编号。名称等。 文件上传图片显示
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/uploadImageStep")
	public void uploadImageStep(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String loginUser = FrameworkHelper.getLoginUser(request);
		String fileName = null;
		String wd = request.getParameter("wd");
		String hg = request.getParameter("hg");
//		String secretFlag = request.getParameter("isSecret");
//		boolean isSecret = false;
//		if("1".equals(secretFlag)){
//			isSecret = true;
//		}
		int w = 96;
		int h = 96;
		try {
			w = Integer.valueOf(wd).intValue();
			h = Integer.valueOf(hg).intValue();
		} catch (Exception e) {
			w = 96;
			h = 96;
		}
		if (request instanceof MultipartHttpServletRequest) {
			MultipartHttpServletRequest mreq = (MultipartHttpServletRequest) request;
			MultipartFile fileData = mreq.getFile("Filedata");
			fileName = fileData.getOriginalFilename();
			fileName = fileName.replace(" ", "");
			SimpleDateFormat SDF = new SimpleDateFormat("yyyy/MM/dd");
			String filePath = SDF.format(new Date());
			String attachId = AttachService.attachUploadFile(fileData, filePath,
					loginUser, w, h);
//			DfishImageSelector img = new DfishImageSelector("img", "上传图片");
			String enAttachId = AttachService.encId(attachId);
			UploadItem item = new UploadItem();
			item.setId(enAttachId);
			item.setName(fileData.getOriginalFilename());
			item.setType(UploadItem.TYPE_IMAGE);
			item.setUrl("attach/thumbnailUrl?attachId=" + enAttachId);
			item.setThumbnailUrl("attach/thumbnailUrl?attachId=" + enAttachId);
			item.setMsg("1");
//			img.setUploadItems(new UploadItem[] { item });

			outPutTEXT(response, item.toString());
		}
	}
	
	@RequestMapping("/thumbnailUrl")
	public void thumbnailUrl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String attachId = request.getParameter("attachId");
		attachId = AttachService.decId(attachId);
		PubFileAttach fileAttach = AttachService.getFileAttachById(attachId);
		FileUtil.downLoadFile(response, AttachService.getAttachDir() + fileAttach.getAttachUrl(), fileAttach.getAttachName());
	}
	
}

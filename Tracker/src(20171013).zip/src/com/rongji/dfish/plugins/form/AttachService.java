package com.rongji.dfish.plugins.form;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rongji.common.mfile.FileManager;
import com.rongji.common.mfile.FileManagerHolder;
import com.rongji.dfish.base.FileUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.base.crypt.CryptFactory;
import com.rongji.dfish.base.crypt.StringCryptor;
import com.rongji.dfish.dao.HibernateCallback;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.entity.PubFileAttach;
import com.rongji.dfish.framework.ClusterIdGetter;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.framework.SystemData;


public class AttachService {

	public static final String MOD_RES_FILESIZELIMIT = "plugins.attach.fileSizeLimit";
	public static final String MOD_RES_ATTACHURL = "plugins.attach.attachUrl";

	public static List<UploadItem> getUploadItems(String linkType, String linkKeyword) {
		List<PubFileAttach> resList = findAttachByLink(linkType, linkKeyword);
		return parseUploadItems(resList);
	}
	public static List<UploadItem> getUploadItem(String attachId) {
		List<PubFileAttach> resList = findAttachById(attachId);
		return parseUploadItems(resList);
	}
	public static List<UploadItem> getUploadItem(String[] attachIds) {
		List<PubFileAttach> resList = findAttachByIds(attachIds);
		return parseUploadItems(resList);
	}
	
	private static List<UploadItem> parseUploadItems(List<PubFileAttach>  resList){
		if(Utils.isEmpty(resList)){
			return Collections.emptyList();
		}
		List<UploadItem> data = new ArrayList<UploadItem>();
		for (PubFileAttach attach : resList) {
			UploadItem item = new UploadItem();
			String encAttachId = encId(attach.getAttachId());
			item.setId(encAttachId);
			String fileName = attach.getAttachName();
			int index = attach.getAttachUrl().lastIndexOf(".");
			if (index != -1) {
				String ext = attach.getAttachUrl().substring(index);
				if (fileName.length() < ext.length()
						|| !ext.equals(fileName.substring(fileName.length()
								- ext.length(), fileName.length()))) {
					fileName += ext;
				}
				item.setSuffix(ext.substring(1));
			}
			item.setName(Utils.escapeXMLword(attach.getAttachName()));
			item.setSize(UploadItem.statisticsSize(attach.getAttachSize()));
			item.setUrl("attach/thumbnailUrl?attachId=" + encAttachId);
			item.setThumbnailUrl("attach/thumbnailUrl?attachId=" + encAttachId);
			item.setMsg("1");
			
			data.add(item);
		}
		return data;
	}
	
	
	@SuppressWarnings("unchecked")
	public static List<PubFileAttach> findAttachByLink(String linkType,
			String linkKeyword) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		if (Utils.isEmpty(linkType) && Utils.isEmpty(linkKeyword)) {
			return new ArrayList<PubFileAttach>();
		}
		List<Object> args = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder();
		sb.append("FROM DspFileManage t WHERE t.linkType = ?");
		args.add(linkType);
		if (Utils.notEmpty(linkKeyword)) {
			sb.append(" AND t.linkKeyword = ?");
			args.add(linkKeyword);
		}
		sb.append(" ORDER BY t.attachId asc");
		List<PubFileAttach> data = dao.getQueryList(sb.toString(), args
				.toArray());
		if (Utils.isEmpty(data)) {
			data = new ArrayList<PubFileAttach>();
		}
		return data;
	}
	@SuppressWarnings("unchecked")
	public static List<PubFileAttach> findAttachByIds(String[] attachIds) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		if (Utils.isEmpty(attachIds)) {
			return new ArrayList<PubFileAttach>();
		}
		List<Object> args = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder();
		StringBuilder inSb = new StringBuilder();
		for(String id:attachIds){
			inSb.append(",'");
			inSb.append(id);
			inSb.append("'");
		}
		
		sb.append("FROM PubFileAttach t WHERE t.attachId in (");
		sb.append(inSb.substring(1));
		sb.append(") ORDER BY t.attachId asc");
		List<PubFileAttach> data = dao.getQueryList(sb.toString(), args
				.toArray());
		if (Utils.isEmpty(data)) {
			data = new ArrayList<PubFileAttach>();
		}
		return data;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PubFileAttach> findAttachById(String attachId) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		if (Utils.isEmpty(attachId)) {
			return new ArrayList<PubFileAttach>();
		}
		List<Object> args = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder();
		sb.append("FROM PubFileAttach t WHERE t.attachId = ?");
		args.add(attachId);
		sb.append(" ORDER BY t.attachId asc");
		List<PubFileAttach> data = dao.getQueryList(sb.toString(), args
				.toArray());
		if (Utils.isEmpty(data)) {
			data = new ArrayList<PubFileAttach>();
		}
		return data;
	}
	
	private static StringCryptor CRY = CryptFactory.getStringCryptor(
			CryptFactory.BLOWFISH, CryptFactory.UTF8,
			CryptFactory.URL_SAFE_BASE64, "DFISH");
	/**
	 * 加密文件编号
	 * 
	 * @param id
	 *            文件编号
	 * @return 加密的文件编号
	 */
	public static String encId(String id) {
		return CRY.encrypt(id);
	}

	/**
	 * 解密编号
	 * 
	 * @param encAttachId
	 *            加密的编号
	 * @return 编号
	 */
	public static String decId(String encId) {
		try {
			return CRY.decrypt(encId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String getServPath(){
		return SystemData.getInstance().getServletInfo().getServletContext().getRealPath("/");
	}

	public static PubFileAttach getFileAttachById(String attachId) {
		if (Utils.isEmpty(attachId)) {
			return null;
		}
		PubCommonDAO dao = FrameworkHelper.getDAO();
		return (PubFileAttach) dao.queryAsAnObject(
				"FROM PubFileAttach t WHERE t.attachId=?", attachId);
	}
	
//	public static List<UploadItem> getUploadItemsByAttachIds(String... attachIds) {
//		if (Utils.isEmpty(attachIds)) {
//			return Collections.emptyList();
//		}
//		PubCommonDAO dao = FrameworkHelper.getDAO();
//		StringBuilder sql = new StringBuilder();
//		sql.append("FROM PubFileAttach t WHERE t.attachId IN(" + PubService.getParamStr(attachIds.length) + ")");
//		List<PubFileAttach> result = dao.getQueryList(sql.toString(), attachIds);
//		return parseUploadItems(result);
//	}
	
	public static void deleteFileAttach2(PubFileAttach fileAttach,
			boolean isSecret) {
		if (fileAttach != null) {
			PubCommonDAO dao = FrameworkHelper.getDAO();
			String rootUrl = FrameworkHelper.getSystemConfig(
					AttachService.MOD_RES_ATTACHURL, AttachService.getServPath());// SystemConfigMethods.MOD_RES_ATTACHURL
			rootUrl = rootUrl.replace('\\', '/');
			if (!rootUrl.endsWith("/")) {
				rootUrl += "/";
			}
			String fileUrl = rootUrl
					+ (fileAttach.getAttachUrl().startsWith("/") ? fileAttach
							.getAttachUrl().substring(1)
							: fileAttach.getAttachUrl());
			FileUtil.deleteFile(fileUrl);
			dao.delete(fileAttach);
		}
	}
	
	public static void deleteFileAttach(PubFileAttach fileAttach,
			boolean isSecret) throws Exception {
		if (fileAttach != null) {
			FileManager fm = FileManagerHolder.getFileManager();
			int c = fm.deleteFile(fileAttach.getAttachId());
			System.out.println(c);
		}
	}

	/**
	 * 王惠峰修改
	 * 
	 * @param file
	 * @param filePath
	 * @param userId
	 * @param width
	 * @param height
	 * @return
	 * @throws Exception
	 */
	public static String attachUploadFile(MultipartFile file, String filePath,
			String userId, int width, int height) throws Exception {
		
		filePath = (filePath.startsWith("/") ? filePath.substring(1) : filePath);
		String originalFileName = file.getOriginalFilename();
		String ext = FileUtil.getFileExtName(originalFileName);
		
		InputStream is = file.getInputStream();
		int b = 1024;
		byte[] buff = new byte[b];
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int len;
		while((len=is.read(buff))!=-1){
			baos.write(buff, 0, len);
		}
		
		FileManager fm = FileManagerHolder.getFileManager();
		String id = fm.upload(baos.toByteArray(), ext);
		return id;
	}
	
	
	public static String attachUploadFile2(MultipartFile file, String filePath,
			String userId, int width, int height) throws IOException {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		
		filePath = (filePath.startsWith("/") ? filePath.substring(1) : filePath);
		String attachId = ClusterIdGetter.getInstance().getNewId();
		String originalFileName = file.getOriginalFilename();
		String ext = FileUtil.getFileExtName(originalFileName);
		String fileName = attachId + ext;
		FileUtil.saveFile(file.getInputStream(), getAttachDir() + filePath, fileName);		

		PubFileAttach attach = new PubFileAttach();
		long fileSize = file.getSize();
		attach.setAttachId(attachId);
		attach.setCreateUser(userId);
		attach.setModifyTime(new Date());
		attach.setAttachName(originalFileName);
		attach.setAttachUrl(filePath + "/" + fileName);
		attach.setAttachSize(fileSize);
		attach.setLinkType("FILE");
		attach.setLinkKeyword(attachId);
		
		dao.saveObject(attach);

		return attachId;
	}
	
	public static String getAttachDir() {
		String url = FrameworkHelper.getSystemConfig(MOD_RES_ATTACHURL, getServPath());
		url = url.replace('\\', '/');
		if (!url.endsWith("/")) {
			url += "/";
		}
		return url;
	}
	
	@SuppressWarnings("unchecked")
    public static String getAttachFullName(String attachId) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List<String> result = dao.getQueryList("SELECT t.attachUrl FROM PubFileAttach t WHERE t.attachId=?", attachId);
		if (Utils.notEmpty(result)) {
			return getAttachDir() + result.get(0);
		}
		
		return "";
	}
	
	/**
	 * 保存提交的数据
	 * 
	 * @param attachs
	 *            页面提交的数据 JSON格式，
	 * @param linkType
	 * @param linkKeyword
	 * @param loginUser
	 *            指定登陆人。如果某个文件是当前人员的临时文件，那么将被剪切到正式目录
	 * @int   文件个数
	 */
    public static int saveUploadItems(String attachs, String linkType,
			String linkKeyWord) {

//		UploadId[] uploads = parseAttachJson(attachs);
//		HashSet<String> retainIds = new HashSet<String>();
////		final List<PubFileAttach> addAttachs = new ArrayList<PubFileAttach>();
//		final List<PubFileAttach> updateAttachs = new ArrayList<PubFileAttach>();
//		final List<PubFileAttach> deleteAttachs = new ArrayList<PubFileAttach>();
//		if (Utils.notEmpty(uploads)) {
//			for (UploadId row : uploads) {
//				String encryptId = row.getId();
//				String attachId = decId(encryptId);
//				PubFileAttach attach = getFileAttachById(attachId);
//				if (attach != null) {
//					attach.setLinkKeyword(linkKeyWord);
//					attach.setLinkType(linkType);
//					attach.setAttachName(row.getName());
//					updateAttachs.add(attach);
//					retainIds.add(attachId);
//				} 
//			}
//		}
//		// 没有被选中的需要删除
//		List<PubFileAttach> resList = findAttachByLink(linkType, linkKeyWord);
//		for (PubFileAttach attach : resList) {
//			if (!retainIds.contains(attach.getAttachId())) {
//				deleteAttachs.add(attach);
//			}
//		}
//		PubCommonDAO dao = FrameworkHelper.getDAO();
//		dao.execute(new HibernateCallback<Object>() {
//			public Object doInHibernate(Session session)
//					throws HibernateException, SQLException {
//				if (Utils.notEmpty(updateAttachs)) {
//					for (PubFileAttach resAttach : updateAttachs) {
//						session.update(resAttach);
//					}
//				}
//				if (Utils.notEmpty(deleteAttachs)) {
//					for (PubFileAttach resAttach : updateAttachs) {
//						session.delete(resAttach);
//					}
//				}
//				return null;
//			}
//		});
		return saveUploadItems(attachs, linkType, linkKeyWord,null);
	}
	
    public static int saveUploadItems(String attachs, String linkType,
			String linkKeyWord,String toSystem) {
		UploadId[] uploads = parseAttachJson(attachs);
		HashSet<String> retainIds = new HashSet<String>();
//		final List<PubFileAttach> addAttachs = new ArrayList<PubFileAttach>();
		final List<PubFileAttach> updateAttachs = new ArrayList<PubFileAttach>();
		final List<PubFileAttach> deleteAttachs = new ArrayList<PubFileAttach>();
		if (Utils.notEmpty(uploads)) {
			for (UploadId row : uploads) {
				String encryptId = row.getId();
				String attachId = decId(encryptId);
				PubFileAttach attach = getFileAttachById(attachId);
				if (attach != null) {
					attach.setLinkKeyword(linkKeyWord);
					attach.setLinkType(linkType);
					attach.setAttachName(row.getName());
					updateAttachs.add(attach);
					retainIds.add(attachId);
				} 
			}
		}
		// 没有被选中的需要删除
		List<PubFileAttach> resList = findAttachByLink(linkType, linkKeyWord);
		for (PubFileAttach attach : resList) {
			if (!retainIds.contains(attach.getAttachId())) {
				deleteAttachs.add(attach);
			}
		}
		PubCommonDAO dao = FrameworkHelper.getDAO();
		dao.execute(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session)
					throws HibernateException, SQLException {
				if (Utils.notEmpty(updateAttachs)) {
					for (PubFileAttach resAttach : updateAttachs) {
						session.update(resAttach);
					}
				}
				if (Utils.notEmpty(deleteAttachs)) {
					for (PubFileAttach resAttach : updateAttachs) {
						session.delete(resAttach);
					}
				}
				return null;
			}
		});
		if(Utils.notEmpty(toSystem)){
//			SyncManager syncManager = SyncManager.getInstance();
//			if (Utils.notEmpty(updateAttachs)) {
//				List<SyncMessage> msgs = new ArrayList<SyncMessage>();
//				for (PubFileAttach resAttach : updateAttachs) {
//					msgs.add(syncManager.generateSyncMessage(PubFileAttach.class.getName(), resAttach.getAttachId(), JSONUtils.toJson(resAttach), "", "", toSystem, PubFileAttach.class.getSimpleName()));
//				}
//				syncManager.addSyncMessage(msgs.toArray(new SyncMessage[]{}));
//			}
//			if (Utils.notEmpty(deleteAttachs)) {
//				List<SyncMessage> msgs = new ArrayList<SyncMessage>();
//				FileDelSyncUtil fileDelSyncUtil = new FileDelSyncUtil();
//				String module = fileDelSyncUtil.getModule();
//				for (PubFileAttach resAttach : deleteAttachs) {
//					msgs.add(syncManager.generateSyncMessage(PubFileAttach.class.getName(), resAttach.getAttachId(), resAttach.getAttachId(), "", "", toSystem, module));
//				}
//				syncManager.addSyncMessage(msgs.toArray(new SyncMessage[]{}));
//			}
		}
		return uploads==null? 0:uploads.length;
	}
    
    
	public static class UploadId {
		private String id;
		private String name;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}
	/**
	 * 将attachsJson转为UploadId数组
	 * 
	 * @param attachsJson
	 * @return
	 */
	public static UploadId[] parseAttachJson(String attachsJson) {
		if (attachsJson == null || attachsJson.equals("")) {
			return null;
		}
		Gson gson = new Gson();
		UploadId[] o = gson.fromJson(attachsJson, new TypeToken<UploadId[]>() {}.getType());
		return o;
	}
	
	public static String parseAttachIdStr(String attachsJson) {
		UploadId[] o = parseAttachJson(attachsJson);
		StringBuilder sb = new StringBuilder();
		if (o != null) {
			boolean isFirst = true;
			for (UploadId item : o) {
				if (isFirst) {
					isFirst = false;
				} else {
					sb.append(',');
				}
				sb.append(decId(item.getId()));
			}
		}
		return sb.toString();
	}
	
	public static void saveAttach(PubFileAttach attach){
		PubCommonDAO dao = FrameworkHelper.getDAO();
		dao.saveObject(attach);
		
		
	}
	
}

package com.rongji.dfish.plugins.form;

import com.rongji.dfish.engines.xmltmpl.form.Plugin;

public class BaiduEditor extends Plugin{
	private static String[] JS_SOURCES={
		"pl/ueditor1_4_3/ueditor.config.js",
		"pl/ueditor1_4_3/ueditor.all.min.js",
		"pl/ueditor1_4_3/ueditor.dfish.js"};
//	"pl/ueditor1_4_3/ueditor.config.js",
//	"pl/ueditor1_4_3/ueditor.all.min.js",
//	"pl/ueditor1_4_3/ueditor.dfish.js"};

//	private static String CSS_SOURCES = "pl/ueditor1_3_6/themes/default/css/ueditor.css";
//	private static String CSS_SOURCES = "pl/ueditor1_4_3/themes/default/css/ueditor.css";
//	private static String toolbars ="[['FullScreen', 'Undo', 'Redo', '|',"+
//					"'Bold', 'Italic', 'Underline','|','FontFamily', 'FontSize', " +
//					"'|','forecolor', 'backcolor','InsertOrderedList', 'InsertUnorderedList',"+
//					"'|','JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyJustify'" +
//				    "]]";
	
	
	/**
	 * 
	 * @param name  姓名
	 * @param title 标题
	 * @param value 内容
	 */
	public BaiduEditor(String name, String title, String value) {
		
		super(name, title, false, false, JS_SOURCES, false, null, "new PL.UEditor(this, {" +
				"initialFrameHeight:200,maximumWords:1000000});");
		//super.addCssSrc(CSS_SOURCES);
		setValue(value);
		
	}
	
	private boolean simple; //是否显示最简窗口
	private int initialFrameHeight = 200;//编辑框高度
	private boolean autoHeightEnabled = true;//编辑框高度
	private int maximumWords = 10000;//编辑框输入最大字符数
	private boolean elementPathEnabled; //是否启用elementPath
	private boolean wordCount; //是否开启字数统计
	
	public boolean isSimple() {
		return simple;
	}
	
	/*
	 * 设置是否显示最简窗口
	 */
	public void setSimple(boolean simple) {
		if (simple) {		
			setJsCodeOnLoad("new PL.UEditor(this);");
			this.simple = simple;
		}
	}
	public int getinitialFrameHeight() {
		return initialFrameHeight;
	}
	
	/*
	 * 设置编辑框高度
	 */
	public void setinitialFrameHeight(int initialFrameHeight) {
		setJsCodeOnLoad("new PL.UEditor(this, {" +"initialFrameHeight:"+initialFrameHeight+"," +"maximumWords:"+maximumWords+"});");
		this.initialFrameHeight = initialFrameHeight;
	}
	
//	/*
//	 * 设置编辑框高度
//	 */
//	public void setautoHeightEnabled(boolean autoHeightEnabled) {
//		setJsCodeOnLoad("new PL.UEditor(this, {" +"autoHeightEnabled:"+autoHeightEnabled+"," +"maximumWords:"+maximumWords+"});");
//		this.autoHeightEnabled = autoHeightEnabled;
//	}
	
	public int getMaximumWords() {
		return maximumWords;
	}
	
	/*
	 * 设置编辑框输入最大字符数
	 */
	public void setMaximumWords(int maximumWords) {
		setJsCodeOnLoad("new PL.UEditor(this, {" +"initialFrameHeight:"+initialFrameHeight+"," +"maximumWords:"+maximumWords+"});");
		this.maximumWords = maximumWords;
	}
	public boolean isElementPathEnabled() {
		return elementPathEnabled;
	}
	
	
	/**
	 * baiduSimple方法
	 * @param simple 				是否显示最简窗口
	 * @param initialFrameHeight 		编辑框高度
	 * @param maximumWords 			编辑框输入最大字符数
	 * @param elementPathEnabled   	是否启用elementPath
	 * @param wordCount  			是否开启字数统计
	 */
	public void baiduSimple(boolean simple,int initialFrameHeight,int maximumWords,boolean elementPathEnabled,boolean wordCount){
		if (simple) {
			setJsCodeOnLoad("new PL.UEditor(this, {" +"initialFrameHeight:"+initialFrameHeight+"," +"maximumWords:"+maximumWords+"});");	
		}
		else {
			setJsCodeOnLoad("new PL.UEditor(this, {advanceMode:true," +"initialFrameHeight:"+initialFrameHeight+"," +"maximumWords:"+maximumWords+"});");			
		}
	}
	
	@java.lang.Deprecated
	public BaiduEditor(java.lang.String name,
			java.lang.String title,
			boolean notnull,
			boolean fullLine,
			java.lang.String[] jsSrcs,
			boolean sync,
			java.lang.String extXml,
			java.lang.String jsCodeOnLoad) {
		super(name, title, notnull, fullLine, jsSrcs, sync, extXml, jsCodeOnLoad);
	}
	
	
	public static void main(String[] args){
		BaiduEditor e=new BaiduEditor("taskContent","任务内容","<b>一些内容..</b>");
		System.out.println(new com.rongji.dfish.engines.xmltmpl.XMLDecorator(e.toString(),false,false));
	}

	public boolean isAutoHeightEnabled() {
		return autoHeightEnabled;
	}

	public void setAutoHeightEnabled(boolean autoHeightEnabled) {
		setJsCodeOnLoad("new PL.UEditor(this, {" +"autoHeightEnabled:"+autoHeightEnabled+"," +"maximumWords:"+maximumWords+"});");
		this.autoHeightEnabled = autoHeightEnabled;
	}
}

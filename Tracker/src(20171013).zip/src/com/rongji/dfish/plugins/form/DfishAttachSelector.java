package com.rongji.dfish.plugins.form;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.XMLFrag;
import com.rongji.dfish.engines.xmltmpl.form.InputFrag;
import com.rongji.dfish.framework.FrameworkHelper;

public class DfishAttachSelector extends InputFrag<DfishAttachSelector> {
	private static final Gson GSON=new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
	public DfishAttachSelector(String name, String title, String linkType, String linkKeyword) {
		this.name = name;
		this.title = title;
		this.uploaded = AttachService.getUploadItems(linkType, linkKeyword);
		fileSizeLimit = FrameworkHelper.getSystemConfig(AttachService.MOD_RES_FILESIZELIMIT, "2") + "GB";
		fileType = "*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.zip;*.rar;*.jpg;*.png;*.mp4;*.flv";
		fileTypeDescription = "办公文件";
		titleWidth = 138;
	}
	public DfishAttachSelector(String name, String title, String attachIds,Boolean multiple) {
		this.name = name;
		this.title = title;
		if(!multiple)
		this.fileUploadLimit = 1;  //只允许上传一个文件
		if(Utils.notEmpty(attachIds)){
			String[] attachIdArr = GSON.fromJson(attachIds, String[].class);
			this.uploaded = AttachService.getUploadItem(attachIdArr);
		}
		fileSizeLimit = FrameworkHelper.getSystemConfig(AttachService.MOD_RES_FILESIZELIMIT, "2") + "GB";
		fileType = "*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.zip;*.rar;*.jpg;*.png;*.mp4;*.flv";
		fileTypeDescription = "办公文件";
		titleWidth = 138;
	}

	public DfishAttachSelector(String name, String title, List<UploadItem> uploaded) {
		this.name = name;
		this.title = title;
		this.uploaded = uploaded;
		fileSizeLimit = FrameworkHelper.getSystemConfig(AttachService.MOD_RES_FILESIZELIMIT, "2") + "GB";
		fileType = "*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.zip;*.rar;*.jpg;*.png;*.mp4;*.flv";
		fileTypeDescription = "办公文件";
		titleWidth = 138;
	}

	public DfishAttachSelector(String name, String title, String attachIds,Boolean multiple,Boolean notDeleteFiles) {
		this.name = name;
		this.title = title;
		if(!multiple)
		this.fileUploadLimit = 1;  //只允许上传一个文件
		if(Utils.notEmpty(attachIds)){
			String[] attachIdArr = GSON.fromJson(attachIds, String[].class);
			this.uploaded = AttachService.getUploadItem(attachIdArr);
		}
		fileSizeLimit = FrameworkHelper.getSystemConfig(AttachService.MOD_RES_FILESIZELIMIT, "2") + "GB";
		fileType = "*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.zip;*.rar;*.jpg;*.png;*.mp4;*.flv";
		fileTypeDescription = "办公文件";
		titleWidth = 138;
		this.notDeleteFiles = notDeleteFiles;
	}
	public static final String FACE_SMALL = "small";
	public static final String FACE_MEDIUM = "medium";

	private List<UploadItem> uploaded;
	private String fileSizeLimit;
	private int fileUploadLimit;
	private String fileType;
	private String fileTypeDescription;
	private int titleWidth;
	private String buttonHtml;
	private int buttonWidth;
	private int buttonHeight;
	private String onFileSelected;
	private boolean hidDelete;
	private String face; // small,medium
	private String buttonJson;
	private boolean notDeleteFiles;

	public String getButtonJson() {
		return buttonJson;
	}

	public DfishAttachSelector setButtonJson(String buttonJson) {
		this.buttonJson = buttonJson;
		return this;
	}

	public String getFace() {
		return face;
	}

	public DfishAttachSelector setFace(String face) {
		this.face = face;
		return this;
	}

	public String getButtonHtml() {
		return buttonHtml;
	}

	public DfishAttachSelector setButtonHtml(String buttonHtml) {
		this.buttonHtml = buttonHtml;
		return this;
	}

	public int getButtonWidth() {
		return buttonWidth;
	}

	public DfishAttachSelector setButtonWidth(int buttonWidth) {
		this.buttonWidth = buttonWidth;
		return this;
	}

	public int getButtonHeight() {
		return buttonHeight;
	}

	public DfishAttachSelector setButtonHeight(int buttonHeight) {
		this.buttonHeight = buttonHeight;
		return this;
	}

	public String getOnFileSelected() {
		return onFileSelected;
	}

	public DfishAttachSelector setOnFileSelected(String onFileSelected) {
		this.onFileSelected = onFileSelected;
		return this;
	}

	public boolean isHidDelete() {
		return hidDelete;
	}

	public DfishAttachSelector setHidDelete(boolean hidDelete) {
		this.hidDelete = hidDelete;
		return this;
	}
	
	protected String uploadUrl = "files/upload";
	protected String downloadUrl = "files/downLoad?fileId=$id";
	protected String deleteUrl = "files/deleteFile?fileId=$id";

	public void buildXML(StringBuilder sb) {
		String remark = "";// "最大("+fileSizeLimit+")";

		sb.append("<i tp=\"plugin\" n=\"");
		escapeAttributNode(sb, name);
		if (this.fullLine) {
			sb.append("\" fu=\"1");
		}
		if(this.star){
			sb.append("\" star=\"1");
		}
		sb.append("\" t=\"");
		escapeAttributNode(sb, title);
		sb.append("\" valign=\"top\">");
		sb.append("<js sync=\"0\">");
		sb.append("<src>js/pl/swfupload/swfupload.js</src>");
		sb.append("<src>js/pl/swfupload/handlers.js</src>");
		sb.append("</js>");
		sb.append("<css><src>js/pl/swfupload/upload.css</src></css>");
		sb.append("<beforeload><![CDATA[return 'loading...';]]></beforeload>");
		sb.append("<load><![CDATA[");
		sb.append("var imgu=new PL.FileUpload(this,");

		sb.append("{upload_url:'"+uploadUrl+"',");
		sb.append("file_size_limit:'").append(getFileSizeLimit()).append("',");
		sb.append("file_upload_limit:").append(getFileUploadLimit()).append(',');
		sb.append("file_types:'").append(getFileType()).append("',");
		sb.append("title_width:").append(titleWidth).append(',');
		sb.append("face:'").append(Utils.notEmpty(getFace()) ? getFace() : "").append("',");
		sb.append("down_url:'"+downloadUrl+"',");
		sb.append("button_disabled:").append(this.disabled).append(',');
		if (getButtonWidth() > 0) {
			sb.append("button_width:").append(getButtonWidth()).append(',');
		}
		if (getButtonHeight() > 0) {
			sb.append("button_height:").append(getButtonHeight()).append(',');
		}
		if (Utils.notEmpty(getButtonHtml())) {
			sb.append("button_html:'").append(getButtonHtml()).append("',");
		}

		sb.append("file_types_description:'").append(fileTypeDescription).append("',");
		sb.append("custom_settings:{");
		sb.append(" star:").append((this.star ? "1" : "0")).append(',');
		//sb.append(" notnull:").append((this.star ? "1" : "0")).append(',');
		sb.append(" readonly:").append(readonly).append(',');
		sb.append(" remark:'").append(remark).append("',");
		if (Utils.notEmpty(getOnFileSelected())) {
			sb.append(" file_selected: '").append(getOnFileSelected()).append("',");
		}
//		if(this.fileUploadLimit == 1){
//			sb.append(" validate: function( file ) { if ( file.name.split('.')[0] != '"+title+"' ) return '文件名不对' },");
//		}

		// 只读设置文件选择动作时隐藏删除
		boolean hidDelete = readonly || isHidDelete();
		if (Utils.isEmpty(getButtonJson())) {
			setButtonJson(getDefaultButtonJson(hidDelete));
		}
		sb.append("buttons:").append(getButtonJson());
		sb.append("}});");// alert('发送邮件$id')

		/*
		 * DialogCommand sendMail = new DialogCommand("sendMail_dlg", "f_std",
		 * " 邮件发送", "showdata", , , DialogPosition.middle,
		 * "vm:|knowledgeBase.sp?act=sendMailView&resIds=$0");
		 * sendMail.setCover(true);
		 */

		/*
		 * down_url : 'a.sp?id=$id', more : [ { t : "发送", ic : "", clk :
		 * "VM(this).cmd({tagName:'alert',cn:'发送文件: $name'})" }, { split : 1 },
		 * { t : "呵呵", ic : "", clk :
		 * "VM(this).cmd({tagName:'alert',cn:'haha'})", ds : 1 }, { t : "内啥", ic
		 * : "", clk : "VM(this).cmd({tagName:'alert',cn:'haha'})", childNodes :
		 * [ { t : "文件ID", ic : "", clk :
		 * "VM(this).cmd({tagName:'alert',cn:'文件ID: $id'})" }, { t : "文件名", ic :
		 * "", clk : "VM(this).cmd({tagName:'alert',cn:'文件名: $name'})" } ] } ]
		 * }});
		 */

		sb.append(" ]]></load>");
		sb.append("<unload><![CDATA[this.handler.destroy();]]></unload>");
		sb.append("<value><![CDATA[[");
		boolean begin = true;
		if (uploaded != null) {
			for (UploadItem item : uploaded) {
				if (begin) {
					begin = false;
				} else {
					sb.append(',');
				}
				sb.append(item);
			}
		}
		sb.append("]]]></value><vlds><v vld='default' ntn='"+(this.star ? "1" : "0")+"'/><v vld='none' ntn='0'/></vlds>");
		if (jsCodeOnChange != null) {
			sb.append("<change>");
			XMLFrag.escapeForCDATA(sb, jsCodeOnChange);
			sb.append("</change>");
			// sb.append(jsCodeOnChange)
		}
		sb.append("</i>");
	}

	public String getDefaultButtonJson(boolean hidDelete) {
//		: "{\"title\" : \"删除\",\"click\" : \"debugger;this.remove();"+((notDeleteFiles)?"":"if('$msg'){VM(this).cmd({tagName:'ajax',src:'"+deleteUrl+"'});}")+"\"},")
		return "["
		        + (hidDelete ? ""
		                : "{\"title\" : \"删除\",\"click\" : \";this.remove();"+((notDeleteFiles)?"":"VM(this).cmd({tagName:'ajax',src:'"+deleteUrl+"'});")+"\"},")
		        + " {\"title\" : \"下载\", \"click\" : \"DFish.download('"+downloadUrl+"')\""
		        +
		        // " {\"t\":\"预览\",\"bold\":1,\"icon\":\"\",\"clk\":\"attachPicker.open('preview','$id','$id')\"},"
		        // +
		        //" {\"t\":\"下载\",\"icon\":\"\",\"clk\":\"DFish.download('attach/fileDownload?encAttachId=$id')\"},"
		        // +
		        // " {\"t\":\"分享\",\"ic\":\"\",\"clk\":\"VM(this).cmd( { tagName : 'ajax',   src : 'attach.sp?act=shareView&encIds=$id' } );\"},"
		        // +
		        // " {\"t\":\"收藏\",\"ic\":\"\",\"clk\":\"favor.favorAction(attachPicker.getIcon('$name'), \\\"attachPicker.open(\'preview\', \'$id\', \'$id\')\\\", '$name', 'FILE', '$id','{\\\"attachId\\\":\\\"$id\\\",\\\"attachName\\\":\\\"$name\\\"}')\"}"
		        // +"]"
		        "}]";
		
	}

	public List<UploadItem> getUploaded() {
		return uploaded;
	}

	public DfishAttachSelector setUploaded(List<UploadItem> uploaded) {
		this.uploaded = uploaded;
		return this;
	}

	public String getFileSizeLimit() {
		return fileSizeLimit;
	}

	public DfishAttachSelector setFileSizeLimit(String fileSizeLimit) {
		this.fileSizeLimit = fileSizeLimit;
		return this;
	}

	public String getFileType() {
		return fileType;
	}

	public DfishAttachSelector setFileType(String fileType) {
		this.fileType = fileType;
		return this;
	}

	public String getFileTypeDescription() {
		return fileTypeDescription;
	}

	public DfishAttachSelector setFileTypeDescription(String fileTypeDescription) {
		this.fileTypeDescription = fileTypeDescription;
		return this;
	}

	public int getFileUploadLimit() {
		return fileUploadLimit;
	}

	public DfishAttachSelector setFileUploadLimit(int fileUploadLimit) {
		this.fileUploadLimit = fileUploadLimit;
		return this;
	}

	private String jsCodeOnChange;

	public String getJsCodeOnChange() {
		return jsCodeOnChange;
	}

	public DfishAttachSelector setJsCodeOnChange(String jsCodeOnChange) {
		this.jsCodeOnChange = jsCodeOnChange;
		return this;
	}

	public DfishAttachSelector setTitleWidth(int width) {
		this.titleWidth = width;
		return this;
	}

	public int getTitleWidth() {
		return titleWidth;
	}
	public boolean isNotDeleteFiles() {
		return notDeleteFiles;
	}
	public void setNotDeleteFiles(boolean notDeleteFiles) {
		this.notDeleteFiles = notDeleteFiles;
	}

}

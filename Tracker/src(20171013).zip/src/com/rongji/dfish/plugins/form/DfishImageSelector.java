package com.rongji.dfish.plugins.form;

import com.google.gson.Gson;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.form.Plugin;

public class DfishImageSelector extends Plugin{
	private static final String[] JS_SOURCE={"js/pl/swfupload/swfupload.js","js/pl/swfupload/handlers.js"};
	public DfishImageSelector(String name, String title) {
		super(name, title, false, false, JS_SOURCE, false, null, null);
		super.setJsCodeOnUnload("this.imgu.destroy();");
		super.addCssSrc("js/pl/swfupload/upload.css");
		this.setFileSizeLimit(2);
		this.setUploadUrl("attach/uploadImageStep");
	}
	private String uploadUrl;
	private boolean isSecret = true;
	private int fileUploadLimit;
	private int fileSizeLimit;
	private String uploadSuccess = ""; 
	private String uploadComplete = "";
	private UploadItem[] uploadItems;
	private int thumbWidth;
	private int thumbHeight;
	
	@Override
	public void buildXML(StringBuilder sb){
		//计算初始的value和onloadJS
//		String extXML="<v><![CDATA[";
//		if(uploadedItems!=null){
//			Gson gson=new Gson();
//			extXML+=gson.toJson(uploadedItems);
//		}
//		extXML+="]]></v>";
//		super.setExtXml(extXML);
		if(this.getJsCodeOnLoad()==null){
			String whStr = "";
			if (thumbWidth>0) {
				whStr += "thumb_width:"+thumbWidth+",";
			}
			if (thumbHeight>0) {
				whStr += "thumb_height:"+thumbHeight+",";
			}
			super.setJsCodeOnLoad("this.imgu=new PL.ImageUpload(this,{upload_url:'"+uploadUrl+"',file_size_limit:'"+fileSizeLimit+"MB',file_upload_limit:"+fileUploadLimit+",custom_settings:{" + whStr + "handler:{upload_success:function(r){"+uploadSuccess+"},upload_complete:function(r){"+uploadComplete+"}}}});");
		}
		
		if(Utils.notEmpty(uploadItems)){
			Gson gson=new Gson();
			this.setValue(gson.toJson(uploadItems));
		}
		
		super.buildXML(sb);
	}
	public String getUploadUrl() {
		return uploadUrl;
	}
	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}
	public int getFileUploadLimit() {
		return fileUploadLimit;
	}
	public void setFileUploadLimit(int fileUploadLimit) {
		this.fileUploadLimit = fileUploadLimit;
	}
	public int getFileSizeLimit() {
		return fileSizeLimit;
	}
	public void setFileSizeLimit(int fileSizeLimit) {
		this.fileSizeLimit = fileSizeLimit;
	}
	public UploadItem[] getUploadItems() {
		return uploadItems;
	}
	public void setUploadItems(UploadItem[] uploadItems) {
		this.uploadItems = uploadItems;
	}
	public String getUploadSuccess() {
		return uploadSuccess;
	}
	public void setUploadSuccess(String uploadSuccess) {
		this.uploadSuccess = uploadSuccess;
	}
	public boolean isSecret() {
		return isSecret;
	}
	public void setSecret(boolean isSecret) {
		this.isSecret = isSecret;
	}
	public String getUploadComplete() {
		return uploadComplete;
	}
	public void setUploadComplete(String uploadComplete) {
		this.uploadComplete = uploadComplete;
	}
	public int getThumbWidth() {
		return thumbWidth;
	}
	public void setThumbWidth(int thumbWidth) {
		this.thumbWidth = thumbWidth;
	}
	public int getThumbHeight() {
		return thumbHeight;
	}
	public void setThumbHeight(int thumbHeight) {
		this.thumbHeight = thumbHeight;
	}
	
	
}

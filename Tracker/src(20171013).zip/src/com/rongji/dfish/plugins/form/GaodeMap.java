package com.rongji.dfish.plugins.form;

import com.google.gson.Gson;
import com.rongji.dfish.engines.xmltmpl.form.InputFrag;

public class GaodeMap extends InputFrag<GaodeMap>{
	private Integer height;
	
	public Integer getHeight() {
		return height;
	}
	public GaodeMap setHeight(Integer height) {
		this.height = height;
		return this;
	}
	public GaodeMap(String name,String title,Position value){
		this.setName(name);
		this.setTitle(title);
		this.setValue(value);
	}
	public GaodeMap setWidth(Integer width){
		if(width==null){
			this.width=null;
		}else{
			this.width=String.valueOf(width);
		}
		return this;
	}


	@Override
	public void buildXML(StringBuilder sb) {
		sb.append("<i tp=\"plugin\" n=\"");
		sb.append(name);
		sb.append("\" t=\"");
		escapeAttributNode(sb, title);
		sb.append("\">");
		
		sb.append("<js sync=\"0\"><src>pl/amap/amap.js</src></js>");
		sb.append("<beforeload>return 'loading..'</beforeload>");
		sb.append("<load>new PL.AMap.Picker(this, {width:");
		sb.append(width==null?"300":width);
		sb.append(",height:");
		sb.append(height==null?300:height);
		sb.append("})</load>");
		if(value==null ||!(value instanceof Position)){
			value=new Position();
		}
		sb.append("<value>").append(new Gson().toJson(value)).append("</value>");
//		sb.append("<value>{\"lng\":119.30817,\"lat\":26.075244,\"zoom\":16}</value>");
		sb.append("</i>");
		
	}
	public static class Position{
		public Position(){
			
		}
		public Position(double lng,double lat,int zoom,String address){
			this.lng=lng;
			this.lat=lat;
			this.zoom=zoom;
			this.address=address;
		}
		private double lng;
		public double getLng() {
			return lng;
		}
		public void setLng(double lng) {
			this.lng = lng;
		}
		public double getLat() {
			return lat;
		}
		public void setLat(double lat) {
			this.lat = lat;
		}
		public int getZoom() {
			return zoom;
		}
		public void setZoom(int zoom) {
			this.zoom = zoom;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		private double lat;
		private int zoom;
		private String address;
	}
}

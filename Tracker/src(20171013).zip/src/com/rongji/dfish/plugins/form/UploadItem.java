package com.rongji.dfish.plugins.form;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.rongji.dfish.base.FileUtil;

public class UploadItem {
	/**
	 * 表示返回状态OK
	 */
	public static final int STATUS_OK = 0;
	/**
	 * 这个文件类型是 图片
	 * <p>该类型文件，推荐提供预览
	 */
	public static final String TYPE_IMAGE = "IMAGE";
	/**
	 * 这个文件类型是 文档
	 * <p>该类型文件，推荐提供预览
	 */
	public static final String TYPE_DOCUMENT = "DOCUMENT";
	/**
	 * 这个文件类型是 视频
	 * <p>该类型文件，推荐提供播放
	 */
	public static final String TYPE_VIDEO = "VIDEO";
	/**
	 * 这个文件类型是 音频
	 * <p>该类型文件，推荐提供播放
	 */
	public static final String TYPE_AUDIO = "AUDIO";
	/**
	 * 这个文件类型是 其他 
	 * <p>该类型文件，一般只提供下载
	 */
	public static final String TYPE_OTHER = "OTHER";
	
//	public static final String 
	private int ret;
	private String msg;
	private String id;
	private String name;
	private String url;
	private String suffix;
	private String thumbnailUrl;
	private String type;
	private String size;
	private int length;
	private String action;
	Map<String, ExtPart> datas;

	public void removeData(String name){
		datas.remove(name);
	}
	public void addData(ExtPart part){
		datas.put(part.getType(), part);
	}
	public void addData(String name,ExtPart part){
		datas.put(name, part);
	}
	public UploadItem() {
		datas = new HashMap<String, ExtPart>();
		ret = STATUS_OK;
	}
	public static UploadItem parser(String jsonString) {
		Gson gson=new Gson();
		return gson.fromJson(jsonString, UploadItem.class);
	}
	
	public static  UploadItem[] parser2(String jsonString) {
		Gson gson=new Gson();
		return gson.fromJson(jsonString, UploadItem[].class);
	}
	
	@Override
	public String toString(){
		Gson gson=new Gson();
		return gson.toJson(this);
	}
	public static class ExtPart {
		public ExtPart(){}
		public ExtPart(String type, String url, int status) {
			this.type=type;
			this.url=url;
			this.status=status;
		}
		private String type;
		private String url;
		private int status;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}
	}

	public static class FlvPart extends ExtPart {
		public FlvPart(){}
		public FlvPart(String type, String url, int status, String queryCode) {
			super(type, url, status);
			this.queryCode = queryCode;
		}

		private String queryCode;

		public String getQueryCode() {
			return queryCode;
		}

		public void setQueryCode(String queryCode) {
			this.queryCode = queryCode;
		}
	}

	public int getRet() {
		return ret;
	}

	public void setRet(int ret) {
		this.ret = ret;
	}

	public String getId() {
		return id;
	}
	/**
	 * 这个文件对象的ID
	 * @param fileId
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	/**
	 * 文件对象的文件夹名
	 * @return
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	/**
	 * 文件对象的下载地址
	 * @return
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	public String getSuffix() {
		return suffix;
	}

	/**
	 * 后缀名
	 * @return
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}
	
	/**
	 * 缩略图的下载地址
	 * @param thumbnailUrl
	 */
	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getType() {
		return type;
	}
	
	
	public String getAction() {
		return action;
	}
	/**
	 * 文件的动作
	 * @param action
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * 文件类型
	 * @param type
	 * @see TYPE_IMAGE
	 * @see TYPE_DOCUMENT
	 * @see TYPE_VIDEO
	 * @see TYPE_AUDIO
	 * @see TYPE_OTHER
	 */
	public void setType(String type) {
		this.type = type;
	}

	public String getSize() {
		return size;
	}

	/**
	 * 文件大小(字节)
	 * @param size
	 */
	public void setSize(String size) {
		this.size = size;
	}

	public int getLength() {
		return length;
	}

	/**
	 * 可播放文件的时间长短(秒)
	 * @param length
	 */
	public void setLength(int length) {
		this.length = length;
	}
	
	public String getMsg() {
		return msg;
	}
	
	/**
	 * 错误信息
	 * @param msg
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public static String statisticsSize(long size){
//		DecimalFormat format = new DecimalFormat("####.00");
//		String sSize = "";
//		if(size > 999){
//			sSize = format.format(size/1000.0);
//			sSize += "KB";
//		}else if(size > 999999){
//			sSize = format.format(size/1000000.0);
//			sSize += "MB";
//		}
		return FileUtil.getHumanSize(size);
	}
}

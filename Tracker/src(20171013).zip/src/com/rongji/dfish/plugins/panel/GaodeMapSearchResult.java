package com.rongji.dfish.plugins.panel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rongji.dfish.engines.xmltmpl.component.PluginPanel;
import com.rongji.dfish.engines.xmltmpl.form.InputFrag;
import com.rongji.dfish.plugins.form.GaodeMap.Position;

public class GaodeMapSearchResult extends PluginPanel{
	private static Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
	List<Node> nodes=new ArrayList<Node>();
	public GaodeMapSearchResult(String id) {
		super(id);
		super.addJsSrc("pl/amap/amap.js");
		super.setJsCodeOnBeforeLoad("return 'loading..';");
		super.setJsCodeOnLoad("new PL.AMap(this);");
	}
	public GaodeMapSearchResult add(Node node){
		nodes.add(node);
		return this;
	}


	@Override
	public void buildXML(StringBuilder sb) {
		HashMap<String,List<Node>> value=new HashMap<String,List<Node>>();
		value.put("address", nodes);
		super.setValue(gson.toJson(value));
		super.buildXML(sb);
	}
	
//	@Override
//	public void buildXML(StringBuilder sb) {
//		sb.append("<fr tp=\"plugin\" id=\"");
//		sb.append(id);
////		sb.append("\" t=\"");
////		escapeAttributNode(sb, title);
//		sb.append("\">");
//		
//		sb.append("<js sync=\"0\"><src>pl/amap/amap.js</src></js>");
//		sb.append("<beforeload>return 'loading..'</beforeload>");
//		sb.append("<load>new PL.AMap.Picker(this, {width:");
////		sb.append(width==null?"300":width);
//		sb.append(",height:");
////		sb.append(height==null?300:height);
//		sb.append("})</load>");
////		if(value==null ||!(value instanceof Position)){
////			value=new Position();
////		}
////		sb.append("<value>").append(new Gson().toJson(value)).append("</value>");
////		sb.append("<value>{\"lng\":119.30817,\"lat\":26.075244,\"zoom\":16}</value>");
//		sb.append("</i>");
//		
//	}
	
//	<fr type="plugin" id="amap">
//	  <js sync="0">
//	    <src>pl/amap/amap.js</src>
//	  </js>
//	  <beforeload>return 'loading..'</beforeload>
//	  <load>new PL.AMap(this)</load>
//	  <value><![CDATA[{"address":[
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>福建省</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>福建省人民政府</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>省委办公厅</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>福州市人民政府</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>中共福建省委员会</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>福建省委组织部</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>中共福州市委员会</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>中共福州市委组织部</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>中共鼓楼区委员会</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>中共鼓楼区委组织部</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//		{"lng":"119.28976","lat":"26.134496","zoom":16,"tip":"<b>中共福州软件园党委</b><br>福建省福州市晋安区新店镇赤星路86"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>福州市</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//	  	{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>鼓楼区</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"},
//		{"lng":"119.372157","lat":"26.134496","zoom":8,"tip":"<b>榕基软件党委</b><br>福建省福州市晋安区宦溪镇恩顶村卫生所"},
//		{"lng":"119.294866","lat":"26.100895","zoom":15,"tip":"<b>省纪律检查委员会机关（省监察厅）</b><br>福建省福州市鼓楼区华大街道中共福建省委员会"}
//	  	]}
//	  ]]></value>
//	</fr>

}

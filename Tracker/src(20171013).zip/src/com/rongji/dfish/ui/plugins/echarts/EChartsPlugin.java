package com.rongji.dfish.ui.plugins.echarts;

import java.util.Arrays;

import com.google.gson.Gson;
import com.rongji.dfish.engines.xmltmpl.component.PluginPanel;
import com.rongji.dfish.ui.plugins.echarts.json.EChartEvent;
import com.rongji.dfish.ui.plugins.echarts.json.EChartSize;
import com.rongji.dfish.ui.plugins.echarts.json.Option;


/**   
 *@Product: iTask v7.0
 *@Company: 榕基软件
 *@Copyright: Copyright  2014-2020
 *@Description: echart图表插件
 *@Author: chenwei
 *@CreateDate: 2015-7-6
 *@Version: v1.0
 */
public class EChartsPlugin extends PluginPanel {
	private static final Gson GSON = new Gson(); 
	private Option option;
	private EChartEvent[] events;
	private EChartSize size;
	
	public EChartsPlugin(String id, Option option) {
		this(id, option, new EChartEvent[]{}, null);
	}
	
	public EChartsPlugin(String id, Option option, EChartEvent[] events, EChartSize size) {
		super(id);
		super.setJsSrcs(Arrays.asList(new String[]{
			"js/pl/echart/echarts-dfish.js",
			"js/pl/echart/echarts-all.js"
		}));
		this.option = option;
		this.events = events;
		this.size = size;
	}
	@Override
	public void buildXML(StringBuilder sb) { 
		super.setJsCodeOnLoad("new PL.Echart( this, " + (this.option!=null?GSON.toJson(this.option):"{}") + ","+ 
				(this.events!=null? GSON.toJson(this.events):"''")+"," +
				(this.size!=null? GSON.toJson(this.size):"''")+");");
		super.buildXML(sb);
	}

	public Option getOption() {
		return option;
	}

	public EChartsPlugin setOption(Option option) {
		this.option = option;
		return this;
	}

	public EChartSize getSize() {
		return size;
	}

	public EChartsPlugin setSize(EChartSize size) {
		this.size = size;
		return this;
	}

//	public EChartEvent[] getEvents() {
//		return this.events;
//	}

	public void setEvents(EChartEvent[] events) {
		this.events = events;
	}

}

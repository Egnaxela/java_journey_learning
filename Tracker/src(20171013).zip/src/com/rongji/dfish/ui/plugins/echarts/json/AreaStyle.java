package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 区域填充样式
 * 
 */
public class AreaStyle {
	private String color;
	private String type;

	public AreaStyle() {
	}
	
	public AreaStyle(String color, String type) {
		super();
		this.color = color;
		this.type = type;
	}

	/**
	 * 颜色
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 填充样式，目前仅支持'default'(实填充)
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	public String getColor() {
		return color;
	}
	public String getType() {
		return type;
	}
	
}

package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 字体大小自动计算配置，默认开启自动计算，程序会根据每个数据的 value 大小以及
 * 画布的大小控制字体大小以达到最佳的显示效果。minSize 可以强制最小字体。 关闭的时候字体大小
 * 取 itemStyle.normal.textStyle.fontSize，建议开启。
 * @author Administrator
 *
 */
public class AutoSize {
public boolean isEnable() {
		return enable;
	}
	/**
	 * 字体大小自动计算配置，默认开启自动计算，程序会根据每个数据的 value 
	 * 大小以及画布的大小控制字体大小以达到最佳的显示效果
	 * @param enable
	 */
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	public Double getMinSize() {
		return minSize;
	}
	/**
	 * minSize 可以强制最小字体。关闭的时候字体大小
	 * 取 itemStyle.normal.textStyle.fontSize，建议开启。
	 * @param minSize
	 */
	public void setMinSize(Double minSize) {
		this.minSize = minSize;
	}
private boolean enable;
private Double minSize;
}

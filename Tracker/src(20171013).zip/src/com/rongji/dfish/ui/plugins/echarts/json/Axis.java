package com.rongji.dfish.ui.plugins.echarts.json;

public class Axis {
	private String type;
	private boolean show;
	private double zlevel;
	private double z;
	private String position;
	private String name;
	private String nameLocation;
	private String[] nameTextStyle;  
	private double[] boundaryGap; 
	private Double min;
	private Double max;
	private boolean scale;
	private double splitNumber;
	private double logLabelBase;
	private boolean logPositive; 
	private AxisLine axisLine;
	private AxisTick axisTick;
	private AxisLabel axisLabel;
	private SplitLine splitLine;
	private SplitArea splitArea;
	private String[] data;
	public String getType() {
		return type;
	}
	
	/**
	 * 坐标轴类型，横轴默认为类目型'category'，纵轴默认为数值型'value'
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public String getPosition() {
		return position;
	}
	
	/**
	 * 坐标轴类型，横轴默认为类目型'bottom'，纵轴默认为数值型'left'，可选为：'bottom' | 'top' | 'left' | 'right'
	 * @param position
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	public String getName() {
		return name;
	}
	
	/**
	 * 坐标轴名称，默认为空
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	public String getNameLocation() {
		return nameLocation;
	}
	
	/**
	 * 坐标轴名称位置，默认为'end'，可选为：'start' | 'end'
	 * @param nameLocation
	 */
	
	public void setNameLocation(String nameLocation) {
		this.nameLocation = nameLocation;
	}
	public String[] getNameTextStyle() {
		return nameTextStyle;
	}
	
	/**
	 * 坐标轴名称文字样式，默认取全局配置，颜色跟随axisLine主色，可设
	 * @param nameTextStyle
	 */
	public void setNameTextStyle(String[] nameTextStyle) {
		this.nameTextStyle = nameTextStyle;
	}
	public double[] getBoundaryGap() {
		return boundaryGap;
	}
	
	/**
	 * 坐标轴两端空白策略，数组内数值代表百分比，[原始数据最小值与最终最小值之间的差额，原始数据最大值与最终最大值之间的差额]
	 * 这里暂不支持时间类型
	 * @param boundaryGap
	 */
	public void setBoundaryGap(double[] boundaryGap) {
		this.boundaryGap = boundaryGap;
	}
	public Double getMin() {
		return min;
	}
	
	/**
	 * 指定的最小值，eg: 0，默认无，会自动根据具体数值调整，指定后将忽略boundaryGap[0]
	 * @param min
	 */
	public void setMin(Double min) {
		this.min = min;
	}
	public Double getMax() {
		return max;
	}
	
	/**
	 * 指定的最大值，eg: 100，默认无，会自动根据具体数值调整，指定后将忽略boundaryGap[1]
	 * @param max
	 */
	public void setMax(Double max) {
		this.max = max;
	}
	public boolean isScale() {
		return scale;
	}
	
	/**
	 * 脱离0值比例，放大聚焦到最终_min，_max区间
	 * @param scale
	 */
	public void setScale(boolean scale) {
		this.scale = scale;
	}
	public double getSplitNumber() {
		return splitNumber;
	}
	
	/**
	 * 分割段数，不指定时根据min、max算法调整
	 * @param splitNumber
	 */
	public void setSplitNumber(double splitNumber) {
		this.splitNumber = splitNumber;
	}
	public double getLogLabelBase() {
		return logLabelBase;
	}
	
	/**
	 * axis.type = 'log'时生效。指定时，axisLabel显示为指数形式，如指定为4时，axisLabel可显示为4的2次方、4的3次方。不指定时，显示为普通形式，如 1000000
	 * @param logLabelBase
	 */
	public void setLogLabelBase(double logLabelBase) {
		this.logLabelBase = logLabelBase;
	}
	public boolean isLogPositive() {
		return logPositive;
	}
	
	/**
	 * axis.type === 'log'时生效。指明是否使用反向log数轴（从而支持value为负值）。默认自适应，即如果value全为负值，则logPositive自动设为false，否则为true
	 * @param logPositive
	 */
	public void setLogPositive(boolean logPositive) {
		this.logPositive = logPositive;
	}
	public AxisLine getAxisLine() {
		return axisLine;
	}
	
	/**
	 * 坐标轴线，默认显示，详见下方
	 * @param axisLine
	 */
	public void setAxisLine(AxisLine axisLine) {
		this.axisLine = axisLine;
	}
	public AxisTick getAxisTick() {
		return axisTick;
	}
	
	/**
	 * 坐标轴小标记，默认不显示，详见下方
	 * @param axisTick
	 */
	public void setAxisTick(AxisTick axisTick) {
		this.axisTick = axisTick;
	}
	public AxisLabel getAxisLabel() {
		return axisLabel;
	}
	
	/**
	 * 坐标轴文本标签，详见下方
	 * @param axisLabel
	 */
	public void setAxisLabel(AxisLabel axisLabel) {
		this.axisLabel = axisLabel;
	}
	public SplitLine getSplitLine() {
		return splitLine;
	}
	
	/**
	 * 分隔线，默认显示，，详见下方
	 * @param splitLine
	 */
	public void setSplitLine(SplitLine splitLine) {
		this.splitLine = splitLine;
	}
	public SplitArea getSplitArea() {
		return splitArea;
	}
	
	/**
	 * 分隔区域，默认不显示，详见下方
	 * @param splitArea
	 */
	public void setSplitArea(SplitArea splitArea) {
		this.splitArea = splitArea;
	}
	public String[] getData() {
		return data;
	}
	
	/**
	 * 类目列表，同时也是label内容，详见axis.data
	 * @param data
	 */
	public void setData(String[] data) {
		this.data = data;
	}
	
	
	
	
	
	
}

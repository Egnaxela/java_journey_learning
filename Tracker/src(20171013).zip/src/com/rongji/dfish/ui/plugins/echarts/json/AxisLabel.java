package com.rongji.dfish.ui.plugins.echarts.json;

public class AxisLabel {
	private boolean show;
	private String interval;
	private double rotate;
	private double margin;
	private boolean clickable;
	private String formatter;
	private TextStyle textStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，默认为true，设为false后下面都没意义了
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public String getInterval() {
		return interval;
	}
	
	/**
	 * 标签显示挑选间隔，默认为'auto'，可选为： 
       'auto'（自动隐藏显示不下的） | 0（全部显示） | 
       {number}（用户指定选择间隔） 
       {function}函数回调，传递参数[index，data[index]]，返回true显示，返回false隐藏
	 * @param interval
	 */
	public void setInterval(String interval) {
		this.interval = interval;
	}
	public double getRotate() {
		return rotate;
	}
	
	/**
	 * 标签旋转角度，默认为0，不旋转，正值为逆时针，负值为顺时针，可选为：-90 ~ 90
	 * @param rotate
	 */
	public void setRotate(double rotate) {
		this.rotate = rotate;
	}
	public double getMargin() {
		return margin;
	}
	
	/**
	 * 坐标轴文本标签与坐标轴的间距，默认为8，单位px
	 * @param margin
	 */
	public void setMargin(double margin) {
		this.margin = margin;
	}
	public boolean isClickable() {
		return clickable;
	}
	
	/**
	 * 坐标轴文本标签是否可点击
	 * @param clickable
	 */
	public void setClickable(boolean clickable) {
		this.clickable = clickable;
	}
	public String getFormatter() {
		return formatter;
	}
	
	/**
	 * 间隔名称格式器：{string}（Template） | {Function}
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	
	/**
	 * 文本样式（详见textStyle），其中当坐标轴为数值型和时间型时，color接受方法回调，实现个性化的颜色定义，support #226
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}

}

package com.rongji.dfish.ui.plugins.echarts.json;

public class AxisLine {
	private boolean show;
	private boolean onZero;
	private LineStyle lineStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，默认为true，设为false后下面都没意义了
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public boolean isOnZero() {
		return onZero;
	}
	
	/**
	 * 定位到垂直方向的0值坐标上
	 * @param onZero
	 */
	public void setOnZero(boolean onZero) {
		this.onZero = onZero;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	
	/**
	 * 属性lineStyle控制线条样式，（详见lineStyle）
	 * @param lineStyle
	 */
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}
	
	
}

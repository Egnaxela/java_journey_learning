package com.rongji.dfish.ui.plugins.echarts.json;

public class AxisPointer {
	
	private String type;
	private LineStyle lineStyle;
	private LineStyle crossStyle;
	private AreaStyle shadowStyle;
	public String getType() {
		return type;
	}
	
	/**
	 * 坐标轴指示器，默认type为line，可选为：'line' | 'cross' | 'shadow' | 'none'(无)，指定type后对应style生效，见下 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	
	/**
	 * lineStyle设置直线指示器（详见lineStyle）
	 * @param lineStyle
	 */
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}
	public LineStyle getCrossStyle() {
		return crossStyle;
	}
	
	/**
	 * crossStyle设置十字准星指示器（详见lineStyle）, 
	 * @param crossStyle
	 */
	public void setCrossStyle(LineStyle crossStyle) {
		this.crossStyle = crossStyle;
	}
	public AreaStyle getShadowStyle() {
		return shadowStyle;
	}
	
	/**
	 * hadowStyle设置阴影指示器（详见areaStyle），areaStyle.size默认为'auto'自动计算，可指定具体宽度
	 * @param shadowStyle
	 */
	public void setShadowStyle(AreaStyle shadowStyle) {
		this.shadowStyle = shadowStyle;
	}
	
	
	

}

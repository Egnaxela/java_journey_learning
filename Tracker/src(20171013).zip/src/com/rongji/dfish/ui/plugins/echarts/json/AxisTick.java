package com.rongji.dfish.ui.plugins.echarts.json;

public class AxisTick {
	private boolean show;
	private String interval;
	private boolean onGap;
	private boolean inside;
	private double length;
	private LineStyle lineStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 
	 * false（数值轴和时间轴）
       true（类目轴）
	 * 是否显示，默认为false，设为true后下面为默认样式
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public String getInterval() {
		return interval;
	}
	
	/**
	 * 小标记显示挑选间隔，默认为'auto'，可选为： 
       'auto'（随axisLabel，自动隐藏显示不下的） | 0（全部显示） | 
        {number}（用户指定选择间隔） 
        {function}函数回调，传递参数[index，data[index]]，返回true显示，返回false隐藏
	 * @param interval
	 */
	public void setInterval(String interval) {
		this.interval = interval;
	}
	public boolean isOnGap() {
		return onGap;
	}
	
	/**
	 * 小标记是否显示为间隔，默认等于boundaryGap
	 * @param onGap
	 */
	public void setOnGap(boolean onGap) {
		this.onGap = onGap;
	}
	public boolean isInside() {
		return inside;
	}
	
	/**
	 * 小标记是否显示为在grid内部，默认在外部
	 * @param inside
	 */
	public void setInside(boolean inside) {
		this.inside = inside;
	}
	public double getLength() {
		return length;
	}
	
	/**
	 * 属性length控制线长
	 * @param length
	 */
	public void setLength(double length) {
		this.length = length;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	
	/**
	 * 属性lineStyle控制线条样式，（详见lineStyle）
	 * @param lineStyle
	 */
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}
	

}

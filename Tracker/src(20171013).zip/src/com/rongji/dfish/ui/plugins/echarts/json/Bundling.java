package com.rongji.dfish.ui.plugins.echarts.json;

public class Bundling {
public boolean isEnable() {
		return enable;
	}
	/**
	 * enable 是否使用边捆绑，默认关闭 
	 * @param enable
	 */
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	public Double getMaxTurningAngle() {
		return maxTurningAngle;
	}
	/**
	 * maxTurningAngle 边捆绑算法参数，可选 [0, 90] 的角度，配置捆绑后的边最大拐角, 默认为 45 度 
	 * @param maxTurningAngle
	 */
	public void setMaxTurningAngle(Double maxTurningAngle) {
		this.maxTurningAngle = maxTurningAngle;
	}
private boolean enable;
private Double maxTurningAngle;
}

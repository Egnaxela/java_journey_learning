package com.rongji.dfish.ui.plugins.echarts.json;

public class CartesianSeries extends Series{
public String getStack() {
	return stack;
}
/**
 * 组合名称，双数值轴时无效，多组数据的堆积图时使用，eg：stack:'group1'，则series数组中stack值等于'group1'的数据做堆积计算
 * @param stack
 */
public void setStack(String stack) {
	this.stack = stack;
}
public Number getxAxisIndex() {
	return xAxisIndex;
}
/**
 * xAxis坐标轴数组的索引，指定该系列数据所用的横坐标轴
 * @param xAxisIndex
 */
public void setxAxisIndex(Number xAxisIndex) {
	this.xAxisIndex = xAxisIndex;
}
public Number getyAxisIndex() {
	return yAxisIndex;
}
/**
 * yAxis坐标轴数组的索引，指定该系列数据所用的纵坐标轴
 * @param yAxisIndex
 */
public void setyAxisIndex(Number yAxisIndex) {
	this.yAxisIndex = yAxisIndex;
}
public String getBarGap() {
	return barGap;
}
/**
 * 柱间距离，默认为柱形宽度的30%，可设固定值
 * @param barGap
 */
public void setBarGap(String barGap) {
	this.barGap = barGap;
}
public String getBarCategoryGap() {
	return barCategoryGap;
}
/**
 * 类目间柱形距离，默认为类目间距的20%，可设固定值
 * @param barCategoryGap
 */
public void setBarCategoryGap(String barCategoryGap) {
	this.barCategoryGap = barCategoryGap;
}
public Number getBarMinHeight() {
	return barMinHeight;
}
/**
 * 柱条最小高度，可用于防止某item的值过小而影响交互
 * @param barMinHeight
 */
public void setBarMinHeight(Number barMinHeight) {
	this.barMinHeight = barMinHeight;
}
public Number getBarWidth() {
	return barWidth;
}
/**
 * 柱条（K线蜡烛）宽度，不设时自适应
 * @param barWidth
 */
public void setBarWidth(Number barWidth) {
	this.barWidth = barWidth;
}
public Number getBarMaxWidth() {
	return barMaxWidth;
}
/**
 * 柱条（K线蜡烛）最大宽度，不设时自适应
 * @param barMaxWidth
 */
public void setBarMaxWidth(Number barMaxWidth) {
	this.barMaxWidth = barMaxWidth;
}
public String getSymbol() {
	return symbol;
}
/**
 * 标志图形类型，默认自动选择（8种类型循环使用，不显示标志图形可设为'none'），默认循环选择类型有：
'circle' | 'rectangle' | 'triangle' | 'diamond' |
'emptyCircle' | 'emptyRectangle' | 'emptyTriangle' | 'emptyDiamond' 
另外，还支持五种更特别的标志图形'heart'（心形）、'droplet'（水滴）、'pin'（标注）、'arrow'（箭头）和'star'（五角星），这并不出现在常规的8类图形中，但无论是在系列级还是数据级上你都可以指定使用，同时，'star' + n（n>=3)可变化出N角星，如指定为'star6'则可以显示6角星 
自1.3.5起支持symbol为自定义图片，格式为'image://' + '图片路径'， 如'image://../asset/ico/favicon.png' 
 * @param symbol
 */
public void setSymbol(String symbol) {
	this.symbol = symbol;
}
public Double[] getSymbolSize() {
	return symbolSize;
}
/**
 * 标志图形大小，可计算特性启用情况建议增大以提高交互体验。可以是单个值，如果在 symbol 为图片的时候想要分别设置宽高防止图片被拉伸，可以使用数组，其中数组第一个值是高，第二个值是宽。 实现气泡图时symbolSize需为Function，气泡大小取决于该方法返回值，传入参数为当前数据项（value数组）。
 * @param symbolSize
 */
public void setSymbolSize(Double[] symbolSize) {
	this.symbolSize = symbolSize;
}
public Number getSymbolRotate() {
	return symbolRotate;
}
/**
 * 	 标志图形旋转角度[-180,180]
 * @param symbolRotate
 */
public void setSymbolRotate(Number symbolRotate) {
	this.symbolRotate = symbolRotate;
}
public boolean isShowAllSymbol() {
	return showAllSymbol;
}
/**
 * 标志图形默认只有主轴显示（随主轴标签间隔隐藏策略），如需全部显示可把showAllSymbol设为true
 * @param showAllSymbol
 */
public void setShowAllSymbol(boolean showAllSymbol) {
	this.showAllSymbol = showAllSymbol;
}
public boolean isSmooth() {
	return smooth;
}
/**
 * 平滑曲线显示，smooth为true时lineStyle不支持虚线
 * @param smooth
 */
public void setSmooth(boolean smooth) {
	this.smooth = smooth;
}
public boolean isDataFilter() {
	return dataFilter;
}
/**
 * ECharts 会在折线图的数据数量大于实际显示的像素宽度（高度）的时候会启用优化，对显示在一个像素宽度内的数据做筛选，该选项是指明数据筛选的策略。

可选 'nearest', 'min', 'max', 'average'。或者是使用自定义的筛选函数
 * @param dataFilter
 */
public void setDataFilter(boolean dataFilter) {
	this.dataFilter = dataFilter;
}
public boolean isLarge() {
	return large;
}
/**
 * 启动大规模散点图
 * @param large
 */
public void setLarge(boolean large) {
	this.large = large;
}
public Number getLargeThreshold() {
	return largeThreshold;
}
/**
 * 大规模散点图自动切换阀值，large为true下有效
 * @param largeThreshold
 */
public void setLargeThreshold(Number largeThreshold) {
	this.largeThreshold = largeThreshold;
}
public boolean isLegendHoverLink() {
	return legendHoverLink;
}
/**
 * 是否启用图例（legend）hover时的联动响应（高亮显示）
 * @param legendHoverLink
 */
public void setLegendHoverLink(boolean legendHoverLink) {
	this.legendHoverLink = legendHoverLink;
}

public static final String SYMBOL_NONE="none";
public static final String SYMBOL_CIRCLE="circle";
public static final String SYMBOL_RECTANGLE="rectangle";
public static final String SYMBOL_TRIANGLE="triangle";
public static final String SYMBOL_DIAMOND="diamond";
public static final String SYMBOL_EMPTY_CIRCLE="emptyCircle";
public static final String SYMBOL_EMPTY_RECTANGLE="emptyRectangle";
public static final String SYMBOL_EMPTY_TRIANGLE="emptyTriangle";
public static final String SYMBOL_EMPTY_DIAMOND="emptyDiamond";
public static final String SYMBOL_HEART="heart";
public static final String SYMBOL_DROPLET="droplet";
public static final String SYMBOL_PIN="pin";
public static final String SYMBOL_ARROW="arrow";
public static final String SYMBOL_STAR="star";
private String stack;
private Number xAxisIndex;
private Number yAxisIndex;
private String barGap;
private String barCategoryGap;
private Number barMinHeight;
private Number barWidth;
private Number barMaxWidth;
private String symbol;
private Double[] symbolSize;
private Number symbolRotate;
private boolean showAllSymbol;
private boolean smooth;
private boolean dataFilter;
private boolean large;
private Number largeThreshold;
private boolean legendHoverLink;
}

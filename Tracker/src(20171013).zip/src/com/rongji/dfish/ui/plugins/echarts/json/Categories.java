package com.rongji.dfish.ui.plugins.echarts.json;

public class Categories {

	private String name;
	private String symbol;
	private Double[] symbolSize;
	private ItemStyle itemStyle;
	
	public Categories() {
	}

	public Categories(String name, String symbol, Double[] symbolSize,
			ItemStyle itemStyle) {
		super();
		this.name = name;
		this.symbol = symbol;
		this.symbolSize = symbolSize;
		this.itemStyle = itemStyle;
	}
	
	/**
	 * 类目名称
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * 同series（直角系）
	 * @param symbol
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	/**
	 * 所有该类目的节点的大小
	 * @param symbolSize
	 */
	public void setSymbolSize(Double[] symbolSize) {
		this.symbolSize = symbolSize;
	}
	
	/**
	 * 详见 itemStyle，注意力导向图单个 category 的 itemStyle 中没有 nodeStyle 的配置项，
	 * 而是直接使用 normal(emphasis) 下的 color, borderWidth 和 borderColor
	 * @param itemStyle
	 */
	public void setItemStyle(ItemStyle itemStyle) {
		this.itemStyle = itemStyle;
	}

	public String getName() {
		return name;
	}

	public String getSymbol() {
		return symbol;
	}

	public Double[] getSymbolSize() {
		return symbolSize;
	}

	public ItemStyle getItemStyle() {
		return itemStyle;
	}

}

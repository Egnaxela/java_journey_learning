package com.rongji.dfish.ui.plugins.echarts.json;

public class CharacterSeries extends Series{
private String[] center;
public String[] getCenter() {
	return center;
}
/**
 * 字符云中心位置，支持绝对值（px）和百分比
 * @param center
 */
public void setCenter(String[] center) {
	this.center = center;
}
public String[] getSize() {
	return size;
}
/**
 * 字符云大小，支持绝对值（px）和百分比
 * @param size
 */

public void setSize(String[] size) {
	this.size = size;
}
public Double[] getTextRotation() {
	return textRotation;
}
/**
 * 文字旋转角度可选列表，默认会随机从水平（0）和垂直（90）两个方向中选择，可以设置多个可选角度，例如 [0, -45, 45, 90]
 * @param textRotation
 */
public void setTextRotation(Double[] textRotation) {
	this.textRotation = textRotation;
}
public AutoSize getAutoSize() {
	return autoSize;
}
/**
 * 字体大小自动计算配置，默认开启自动计算，程序会根据每个数据的 value 大小以及画布的大小控制字体大小以达到最佳的显示效果。minSize 可以强制最小字体。 关闭的时候字体大小取 itemStyle.normal.textStyle.fontSize，建议开启。
 * @param autoSize
 */
public void setAutoSize(AutoSize autoSize) {
	this.autoSize = autoSize;
}
private String[] size;
private Double[] textRotation;
private AutoSize autoSize;
}

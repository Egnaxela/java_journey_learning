package com.rongji.dfish.ui.plugins.echarts.json;

public class CheckPointStyle {
	private String symbol ;
	private String symbolSize  ;
	private String color ;
	private String borderColor;
	private double borderWidth ;
	private Label label;
	public String getSymbol() {
		return symbol;
	}
	
	/**
	 * 当前点symbol，默认随轴上的symbol 
	 * @param symbol
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getSymbolSize() {
		return symbolSize;
	}
	
	/**
	 * 当前点symbol大小，默认随轴上symbol大小 
	 * @param symbolSize
	 */
	public void setSymbolSize(String symbolSize) {
		this.symbolSize = symbolSize;
	}
	public String getColor() {
		return color;
	}
	
	/**
	 * 当前点symbol颜色，默认为随当前点颜色，可指定具体颜色，如无则为'#1e90ff'
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 当前点symbol边线颜色 
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public double getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 当前点symbol边线宽度 
	 * @param borderWidth
	 */
	public void setBorderWidth(double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public Label getLabel() {
		return label;
	}
	
	/**
	 * 详情请看Label，如下
	 * label: {
        show: false,
        textStyle: {
            color: 'auto'
        }
    }
	 * 
	 * @param label
	 */
	public void setLabel(Label label) {
		this.label = label;
	}
	
	
	
	

}

package com.rongji.dfish.ui.plugins.echarts.json;

public class ChordSeries extends Series{
	public Categories[] getCategories() {
		return categories;
	}
	/**
	 * 节点分类, 详见图数据结构表示中的categories
	 * @param categories
	 */
	public void setCategories(Categories[] categories) {
		this.categories = categories;
	}
	public Links[] getLinks() {
		return links;
	}
	/**
	 * 和弦图的边数据, 和matrix二选一 详见图数据结构表示中的links
	 * @param links
	 */
	public void setLinks(Links[] links) {
		this.links = links;
	}
	public Double[][] getMatrix() {
		return matrix;
	}
	/**
	 * 和弦图的邻接矩阵, 和links二选一 详见图数据结构表示中的matrix
	 * @param matrix
	 */
	public void setMatrix(Double[][]  matrix) {
		this.matrix = matrix;
	}
	public String getSymbol() {
		return symbol;
	}
	/**
	 * 同series（直角系）, ribbonType为false时有效
	 * @param symbol
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public boolean isRibbonType() {
		return ribbonType;
	}
	/**
	 * ribbonType的和弦图节点使用扇形绘制，边使用有大小端的ribbon绘制，可以表示出边的权重，图的节点边之间必须是双向边，非ribbonType的和弦图节点使用symbol绘制，边使用贝塞尔曲线，不能表示边的权重，但是可以使用单向边
	 * @param ribbonType
	 */
	public void setRibbonType(boolean ribbonType) {
		this.ribbonType = ribbonType;
	}
	public Number getSymbolSize() {
		return symbolSize;
	}
	/**
	 * 节点的大小, ribbonType为false时有效
	 * @param symbolSize
	 */
	public void setSymbolSize(Number symbolSize) {
		this.symbolSize = symbolSize;
	}
	public Number getMinRadius() {
		return minRadius;
	}
	/**
	 * 顶点数据映射成symbol半径后的最小半径, ribbonType为false时有效
	 * @param minRadius
	 */
	public void setMinRadius(Number minRadius) {
		this.minRadius = minRadius;
	}
	public Number getMaxRadius() {
		return maxRadius;
	}
	/**
	 * 顶点数据映射成symbol半径后的最大半径, ribbonType为false时有效
	 * @param maxRadius
	 */
	public void setMaxRadius(Number maxRadius) {
		this.maxRadius = maxRadius;
	}
	public boolean isShowScale() {
		return showScale;
	}
	/**
	 * 是否显示刻度, ribbonType为true时有效
	 * @param showScale
	 */
	public void setShowScale(boolean showScale) {
		this.showScale = showScale;
	}
	public boolean isShowScaleText() {
		return showScaleText;
	}
	/**
	 * 是否显示刻度文字, ribbonType为true时有效
	 * @param showScaleText
	 */
	public void setShowScaleText(boolean showScaleText) {
		this.showScaleText = showScaleText;
	}
	public Number getPadding() {
		return padding;
	}
	/**
	 * 每个sector之间的间距(用角度表示)
	 * @param padding
	 */
	public void setPadding(Number padding) {
		this.padding = padding;
	}
	public String getSort() {
		return sort;
	}
	/**
	 * 数据排序， 可以取none, ascending, descending
	 * @param sort
	 */
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getSortSub() {
		return sortSub;
	}
	/**
	 * 数据排序（弦）， 可以取none, ascending, descending
	 * @param sortSub
	 */
	public void setSortSub(String sortSub) {
		this.sortSub = sortSub;
	}
	public boolean isClockWise() {
		return clockWise;
	}
	/**
	 * 显示是否顺时针
	 * @param clockWise
	 */
	public void setClockWise(boolean clockWise) {
		this.clockWise = clockWise;
	}
	public Data[] getData() {
		return data;
	}
	/**
	 * 和弦图的顶点数据, 详见图数据结构表示中的nodes(data)
	 * @param data
	 */
	public void setData(Data[] data) {
		this.data = data;
	}
	private Categories[] categories;
	private Data[] data;
	private Links[] links;
	private Double[][] matrix;
	private String symbol;
	private boolean ribbonType;
//	private 
	private Number symbolSize;
	private Number minRadius;
	private Number maxRadius;
	private boolean showScale;
	private boolean showScaleText;
	private Number padding;
	private String sort;
	private String sortSub;
	private boolean clockWise;
}

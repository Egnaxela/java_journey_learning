package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 和弦图中的弦样式
 * 
 */
public class ChordStyle {
	private Double width;
	private String color;
	private String borderWidth;
	private String borderColor;
	
	
	public ChordStyle() {
	}
	
	public ChordStyle(Double width, String color, String borderWidth,
			String borderColor) {
		super();
		this.width = width;
		this.color = color;
		this.borderWidth = borderWidth;
		this.borderColor = borderColor;
	}
	/**
	 * 贝塞尔曲线的线宽, ribbonType是false时有效
	 * @param width
	 */
	public void setWidth(Double width) {
		this.width = width;
	}
	/**
	 * 贝塞尔曲线的颜色, ribbonType是false时有效
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * ribbon的描边线宽, ribbonType是true时有效
	 * @param borderWidth
	 */
	public void setBorderWidth(String borderWidth) {
		this.borderWidth = borderWidth;
	}
	/**
	 * ribbon的描边颜色, ribbonType是true时有效
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	
	public Double getWidth() {
		return width;
	}
	public String getColor() {
		return color;
	}
	public String getBorderWidth() {
		return borderWidth;
	}
	public String getBorderColor() {
		return borderColor;
	}

}

package com.rongji.dfish.ui.plugins.echarts.json;

import java.util.Map;

public class ControlStyle {
	private double itemSize;
	private double itemGap;
	private Map normal;
	private Map emphasis ;
	public double getItemSize() {
		return itemSize;
	}
	
	/**
	 * 指定itemSize按钮大小
	 * @param itemSize
	 */
	public void setItemSize(double itemSize) {
		this.itemSize = itemSize;
	}
	public double getItemGap() {
		return itemGap;
	}
	
	/**
	 * itemGap按钮间隔
	 * @param itemGap
	 */
	public void setItemGap(double itemGap) {
		this.itemGap = itemGap;
	}
	public Map getNormal() {
		return normal;
	}
	
	/**
	 * normal.color正常
	 * @param normal
	 */
	public void setNormal(Map normal) {
		this.normal = normal;
	}
	public Map getEmphasis() {
		return emphasis;
	}
	
	/**
	 * emphasis.color高亮颜色
	 * @param emphasis
	 */
	public void setEmphasis(Map emphasis) {
		this.emphasis = emphasis;
	}
	
	
	

}

package com.rongji.dfish.ui.plugins.echarts.json;

public class Data {
public String getName() {
		return name;
	}
	/**
	 * 节点名称
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}

	/**
	 * 节点标签名称，默认显示name作为标签
	 * @param label
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	public Number getValue() {
		return value;
	}
	/**
	 * 节点值，如果不设置会取所有边的权重(weight)和
	 * @param value
	 */
	public void setValue(Number value) {
		this.value = value;
	}
	public Boolean isIgnore() {
		return ignore;
	}
	/**
	 * 是否忽略该节点
	 * @param ignore
	 */
	public void setIgnore(Boolean ignore) {
		this.ignore = ignore;
	}
	public String getSymbol() {
		return symbol;
	}
	/**
	 * 同series（直角系）
	 * @param symbol
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Number[] getSymbolSize() {
		return symbolSize;
	}
	/**
	 * 强制指定节点的大小
	 * @param symbolSize
	 */
	public void setSymbolSize(Number[] symbolSize) {
		this.symbolSize = symbolSize;
	}
	public Number getCategory() {
		return category;
	}
	/**
	 * 节点的 category index
	 * @param category
	 */
	public void setCategory(Number category) {
		this.category = category;
	}
	public ItemStyle getItemStyle() {
		return itemStyle;
	}
	/**
	 * 详见 itemStyle，注意力导向图单个节点的 itemStyle 中没有 nodeStyle 的配置项，而是直接使用 normal(emphasis) 下的 color, borderWidth 和 borderColor
	 * @param itemStyle
	 */
	public void setItemStyle(ItemStyle itemStyle) {
		this.itemStyle = itemStyle;
	}
private String name;
private String label;
private Number value;
private Boolean ignore;
private String symbol;
private Number[] symbolSize;
private Number category;
private ItemStyle itemStyle;
}

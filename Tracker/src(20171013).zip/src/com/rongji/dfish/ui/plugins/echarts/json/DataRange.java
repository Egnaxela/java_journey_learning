package com.rongji.dfish.ui.plugins.echarts.json;


public class DataRange {
	private boolean show;
	private double zlevel;
	private double z;
	private String orient;
	private String x;
	private String y;
	private String backgroundColor;
	private String borderColor;
	private double borderWidth;
	private double padding;
	private double itemGap;
	private double itemWidth;
	private double itemHeight;
	private Double min;
	private Double max;
	private double  precision;
	private double splitNumber;
	private SplitList splitList;
	private Range range;
	private boolean selectedMode;
	private boolean calculable;
	private boolean hoverLink;
	private boolean realtime;
	private String[] color;
	private String formatter;
	private String[] text;
	private TextStyle textStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public String getOrient() {
		return orient;
	}
	
	/**
	 * 布局方式，默认为垂直布局，可选为：'horizontal' | 'vertical'
	 * @param orient
	 */
	public void setOrient(String orient) {
		this.orient = orient;
	}
	public String getX() {
		return x;
	}
	
	/**
	 * 水平安放位置，默认为全图左对齐，可选为：'center' | 'left' | 'right' | {number}（x坐标，单位px）
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	
	/**
	 * 垂直安放位置，默认为全图底部，可选为：'top' | 'bottom' | 'center' | {number}（y坐标，单位px）
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 值域控件背景颜色，默认透明
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 值域控件边框颜色
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public double getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 值域控件边框线宽，单位px，默认为0（无边框）
	 * @param borderWidth
	 */
	public void setBorderWidth(double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public double getPadding() {
		return padding;
	}
	
	/**
	 * 值域控件内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css，见下图
	 * @param padding
	 */
	public void setPadding(double padding) {
		this.padding = padding;
	}
	public double getItemGap() {
		return itemGap;
	}
	
	/**
	 * 各个item之间的间隔，单位px，默认为10，横向布局时为水平间隔，纵向布局时为纵向间隔，见下图
	 * @param itemGap
	 */
	public void setItemGap(double itemGap) {
		this.itemGap = itemGap;
	}
	public double getItemWidth() {
		return itemWidth;
	}
	
	/**
	 * 值域控件图形宽度
	 * @param itemWidth
	 */
	public void setItemWidth(double itemWidth) {
		this.itemWidth = itemWidth;
	}
	public double getItemHeight() {
		return itemHeight;
	}
	
	/**
	 * 值域控件图形高度
	 * @param itemHeight
	 */
	public void setItemHeight(double itemHeight) {
		this.itemHeight = itemHeight;
	}
	public Double getMin() {
		return min;
	}
	
	/**
	 * 指定的最小值，eg: 0，默认无，必须参数，唯有指定了splitList时可缺省min。
	 * @param min
	 */
	public void setMin(Double min) {
		this.min = min;
	}
	public Double getMax() {
		return max;
	}
	
	/**
	 * 指定的最大值，eg: 100，默认无，必须参数，唯有指定了splitList时可缺省max
	 * @param max
	 */
	public void setMax(Double max) {
		this.max = max;
	}
	public double getPrecision() {
		return precision;
	}
	
	/**
	 * 小数精度，默认为0，无小数点，当 min ~ max 间在当前精度下无法整除splitNumber份时，精度会自动提高以满足均分，不支持不等划分
	 * @param precision
	 */
	public void setPrecision(double precision) {
		this.precision = precision;
	}
	public double getSplitNumber() {
		return splitNumber;
	}
	
	/**
	 * 分割段数，默认为5，为0时为线性渐变，calculable为true是默认均分100份
	 * @param splitNumber
	 */
	public void setSplitNumber(double splitNumber) {
		this.splitNumber = splitNumber;
	}
	public SplitList getSplitList() {
		return splitList;
	}
	
	/**
	 * 自定义分割方式，支持不等距分割。splitList被指定时，splitNumber将被忽略。
     splitList是一个（不可为空的）Array，Array的每一项为一个Object.(详情请看SplitList)
	 * @param splitList
	 */
	public void setSplitList(SplitList splitList) {
		this.splitList = splitList;
	}
	public Range getRange() {
		return range;
	}
	
	/**
	 * 用于设置dataRange的初始选中范围。calculable为true时有效。(详情请看Range)
	 * @param range
	 */
	public void setRange(Range range) {
		this.range = range;
	}
	public boolean isSelectedMode() {
		return selectedMode;
	}
	
	/**
	 * 选择模式，默认开启值域开关，可选single，multiple
	 * @param selectedMode
	 */
	public void setSelectedMode(boolean selectedMode) {
		this.selectedMode = selectedMode;
	}
	public boolean isCalculable() {
		return calculable;
	}
	
	/**
	 * 是否启用值域漫游，启用后无视splitNumber和splitList，值域显示为线性渐变
	 * @param calculable
	 */
	public void setCalculable(boolean calculable) {
		this.calculable = calculable;
	}
	public boolean isHoverLink() {
		return hoverLink;
	}
	
	/**
	 * 是否启用地图hover时的联动响应（详情披露）
	 * @param hoverLink
	 */
	public void setHoverLink(boolean hoverLink) {
		this.hoverLink = hoverLink;
	}
	public boolean isRealtime() {
		return realtime;
	}
	
	/**
	 * 值域漫游是否实时显示，在不支持Canvas的浏览器中该值自动强制置为false。
	 * @param realtime
	 */
	public void setRealtime(boolean realtime) {
		this.realtime = realtime;
	}
	public String[] getColor() {
		return color;
	}
	
	/**
	 * 值域颜色标识，颜色数组长度必须>=2，颜色代表从数值高到低的变化，即颜色数组低位代表数值高的颜色标识 ，支持Alpha通道上的变化（rgba）
	 * @param color
	 */
	public void setColor(String[] color) {
		this.color = color;
	}
	public String getFormatter() {
		return formatter;
	}
	
	/**
	 * 内容格式器：{string}（Template） | {Function}，模板变量为'{value}'和'{value2}'，
	 * 代表数值起始值和结束值，函数参数两个，含义同模板变量，当calculable为true时模板变量仅有'{value}'
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	public String[] getText() {
		return text;
	}
	
	/**
	 * 值域文字显示，splitNumber生效时默认以计算所得数值作为值域文字显示，可指定长度为2的文本数组显示简介的值域文本，如['高', '低']，'\n'指定换行
	 * @param text
	 */
	public void setText(String[] text) {
		this.text = text;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	
	/**
	 * 默认只设定了值域控件文字颜色（详见textStyle）
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
	
	
	

}

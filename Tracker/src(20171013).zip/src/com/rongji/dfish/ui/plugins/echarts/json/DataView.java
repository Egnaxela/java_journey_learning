package com.rongji.dfish.ui.plugins.echarts.json;

public class DataView {

	private boolean show;
	private boolean readOnly;

	public boolean isShow() {
		return show;
	}

	public void setShow(boolean show) {
		this.show = show;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

}

package com.rongji.dfish.ui.plugins.echarts.json;


public class DataZoom {
	private boolean show;
	private double zlevel;
	private double z;
	private String orient;
	private String x;
	private String y;
	private double Width;
	private double height;
	private String backgroundColor;
	private String dataBackgroundColor;
	private String fillerColor;
	private String handleColor;
	private double handleSize;
	private String[] xAxisIndex;
	private String[] yAxisIndex;
	private double start;
	private double end;
	private boolean showDetail;
	private boolean realtime;
	private boolean zoomLock;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，当show为true时则接管使用指定类目轴的全部系列数据，如不指定则接管全部直角坐标系数据。
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public String getOrient() {
		return orient;
	}
	
	/**
	 * 布局方式，默认为水平布局，可选为：'horizontal' | 'vertical'
	 * @param orient
	 */
	public void setOrient(String orient) {
		this.orient = orient;
	}
	public String getX() {
		return x;
	}
	
	/**
	 * 水平安放位置，默认为根据grid参数适配，纵向布局默认左侧，可指定 {number}（左上角x坐标，单位px）
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	
	/**
	 * 垂直安放位置，默认为根据grid参数适配，纵向布局默认下方，可指定 {number}（左上角y坐标，单位px）
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	public double getWidth() {
		return Width;
	}
	
	/**
	 * 指定宽度，横向布局时默认为根据grid参数适配，纵向布局是默认为30，可指定 {number}（宽度，单位px）
	 * @param width
	 */
	public void setWidth(double width) {
		Width = width;
	}
	public double getHeight() {
		return height;
	}
	
	/**
	 * 指定高度，纵向布局时默认为根据grid参数适配，横向布局是默认为30，可指定 {number}（高度，单位px）
	 * @param height
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 背景颜色，默认透明
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public String getDataBackgroundColor() {
		return dataBackgroundColor;
	}
	
	/**
	 * 数据缩略背景颜色，仅以第一个系列的数据作为缩量图显示
	 * @param dataBackgroundColor
	 */
	public void setDataBackgroundColor(String dataBackgroundColor) {
		this.dataBackgroundColor = dataBackgroundColor;
	}
	public String getFillerColor() {
		return fillerColor;
	}
	
	/**
	 * 选择区域填充颜色
	 * @param fillerColor
	 */
	public void setFillerColor(String fillerColor) {
		this.fillerColor = fillerColor;
	}
	public String getHandleColor() {
		return handleColor;
	}
	
	/**
	 * 控制手柄颜色
	 * @param handleColor
	 */
	public void setHandleColor(String handleColor) {
		this.handleColor = handleColor;
	}
	public double getHandleSize() {
		return handleSize;
	}
	
	/**
	 * 控制手柄大小
	 * @param handleSize
	 */
	public void setHandleSize(double handleSize) {
		this.handleSize = handleSize;
	}
	public String[] getxAxisIndex() {
		return xAxisIndex;
	}
	
	/**
	 * 当不指定时默认控制所有横向类目，可通过数组指定多个需要控制的横向类目坐标轴Index，仅一个时可直接为数字
	 * @param xAxisIndex
	 */
	public void setxAxisIndex(String[] xAxisIndex) {
		this.xAxisIndex = xAxisIndex;
	}
	public String[] getyAxisIndex() {
		return yAxisIndex;
	}
	
	/**
	 * 当不指定时默认控制所有纵向类目，可通过数组指定多个需要控制的纵向类目坐标轴Index，仅一个时可直接为数字
	 * @param yAxisIndex
	 */
	public void setyAxisIndex(String[] yAxisIndex) {
		this.yAxisIndex = yAxisIndex;
	}
	public double getStart() {
		return start;
	}
	
	/**
	 * 数据缩放，选择起始比例，默认为0（%），从首个数据起选择。
	 * @param start
	 */
	public void setStart(double start) {
		this.start = start;
	}
	public double getEnd() {
		return end;
	}
	
	/**
	 * 数据缩放，选择结束比例，默认为100（%），到最后一个数据选择结束
	 * @param end
	 */
	public void setEnd(double end) {
		this.end = end;
	}
	public boolean isShowDetail() {
		return showDetail;
	}
	
	/**
	 * 缩放变化是否显示定位详情。
	 * @param showDetail
	 */
	public void setShowDetail(boolean showDetail) {
		this.showDetail = showDetail;
	}
	public boolean isRealtime() {
		return realtime;
	}
	
	/**
	 * 缩放变化是否实时显示，在不支持Canvas的浏览器中该值自动强制置为false。
	 * @param realtime
	 */
	public void setRealtime(boolean realtime) {
		this.realtime = realtime;
	}
	public boolean isZoomLock() {
		return zoomLock;
	}
	
	/**
	 * 数据缩放锁，默认为false，当设置为true时选择区域不能伸缩，即(end - start)值保持不变，仅能做数据漫游。
	 * @param zoomLock
	 */
	public void setZoomLock(boolean zoomLock) {
		this.zoomLock = zoomLock;
	}
	
}

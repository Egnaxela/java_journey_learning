package com.rongji.dfish.ui.plugins.echarts.json;

public class Detail {
public boolean isShow() {
		return show;
	}
	/**
	 * 属性show控制显示与否， 
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	/**
	 * 属性backgroundColor控制边框颜色，，如'rgba(0,0,0,0)'
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public Double getBorderWidth() {
		return borderWidth;
	}
	/**
	 * 属性borderWidth控制边框线宽， 
	 * @param borderWidth
	 */
	public void setBorderWidth(Double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public String getBorderColor() {
		return borderColor;
	}
	/**
	 * 属性borderColor控制边框颜色 '#ccc'
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public Double getWidth() {
		return width;
	}
	/**
	 * 属性width控制详情宽度， 
	 * @param width
	 */
	public void setWidth(Double width) {
		this.width = width;
	}
	public Double getHeight() {
		return height;
	}
	/**
	 * 属性height控制详情高度
	 * @param height
	 */
	public void setHeight(Double height) {
		this.height = height;
	}
	public String getOffsetCenter() {
		return offsetCenter;
	}
	/**
	 * 属性offsetCenter用于详情定位，数组为横纵相对仪表盘圆心坐标偏移，支持百分比（相对外半径）如 [0, '40%']
	 * @param offsetCenter
	 */
	public void setOffsetCenter(String offsetCenter) {
		this.offsetCenter = offsetCenter;
	}
	public boolean isFormatter() {
		return formatter;
	}
	/**
	 * 属性formatter可以格式化文本， 
	 * @param formatter
	 */
	public void setFormatter(boolean formatter) {
		this.formatter = formatter;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	/**
	 * 属性textStyle（详见textStyle）控制文本样式
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
private boolean show;
private String backgroundColor;
private Double borderWidth;
private String borderColor;
private Double width;
private Double height;
private String offsetCenter;
private boolean formatter;
private TextStyle textStyle;
}

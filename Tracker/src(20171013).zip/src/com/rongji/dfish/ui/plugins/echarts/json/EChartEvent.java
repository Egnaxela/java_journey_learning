package com.rongji.dfish.ui.plugins.echarts.json;

public class EChartEvent {

	public static final String EVENT_CLICK = "CLICK";
	public static final String EVENT_DBLCLICK = "DBLCLICK";
	
	private String eventName;
	private String eventListener;

	public EChartEvent() {
	    super();
    }
	
	public EChartEvent(String eventName, String eventListener) {
	    super();
	    this.eventName = eventName;
	    this.eventListener = eventListener;
    }

	public String getEventName() {
		return eventName;
	}

	public EChartEvent setEventName(String eventName) {
		this.eventName = eventName;
		return this;
	}

	public String getEventListener() {
		return eventListener;
	}

	public EChartEvent setEventListener(String eventListener) {
		this.eventListener = eventListener;
		return this;
	}

}

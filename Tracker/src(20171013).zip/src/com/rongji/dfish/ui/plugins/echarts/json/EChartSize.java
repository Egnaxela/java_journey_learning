package com.rongji.dfish.ui.plugins.echarts.json;

public class EChartSize {

	private String height;
	private String width;

	public String getHeight() {
		return height;
	}

	public EChartSize setHeight(String height) {
		this.height = height;
		return this;
	}

	public String getWidth() {
		return width;
	}

	public EChartSize setWidth(String width) {
		this.width = width;
		return this;
	}

}

package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 标注图形炫光特效:
 * @author Administrator
 *
 */
public class Effect {
public boolean isShow() {
		return show;
	}
	/**
	 * show 是否开启，默认关闭 
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public String getType() {
		return type;
	}
	/**
	 * type 特效类型，默认为'scale'（放大），可选还有'bounce'（跳动） 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	public boolean isLoop() {
		return loop;
	}
	/**
	 * loop 循环动画，默认开启, 
	 * @param loop
	 */
	public void setLoop(boolean loop) {
		this.loop = loop;
	}
	public Double getPeriod() {
		return period;
	}
	/**
	 * period 运动周期，无单位，值越大越慢，默认为15 
	 * @param period
	 */
	public void setPeriod(Double period) {
		this.period = period;
	}
	public Double getScaleSize() {
		return scaleSize;
	}
	/**
	 * scaleSize 放大倍数，以markPoint symbolSize为基准，type为scale时有效 
	 * @param scaleSize
	 */
	public void setScaleSize(Double scaleSize) {
		this.scaleSize = scaleSize;
	}
	public Double getBounceDistance() {
		return bounceDistance;
	}
	/**
	 * bounceDistance 跳动距离，单位为px，type为bounce时有效 
	 * @param bounceDistance
	 */
	public void setBounceDistance(Double bounceDistance) {
		this.bounceDistance = bounceDistance;
	}
	public String getColor() {
		return color;
	}
	/**
	 * color 炫光颜色，默认跟随markPoint itemStyle定义颜色, 
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	public String getShadowColor() {
		return shadowColor;
	}
	/**
	 * shadowColor 光影颜色，默认跟随color 
	 * @param shadowColor
	 */
	public void setShadowColor(String shadowColor) {
		this.shadowColor = shadowColor;
	}
	public Double getShadowBlur() {
		return shadowBlur;
	}
	/**
	 * shadowBlur 光影模糊度，默认为0 
	 * @param shadowBlur
	 */
	public void setShadowBlur(Double shadowBlur) {
		this.shadowBlur = shadowBlur;
	}
private	boolean show;
private String type;
private boolean loop;
private Double period;
private Double scaleSize;
private Double bounceDistance;
private String color;
private String shadowColor;
private Double shadowBlur;
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class EvolutionDetail {
	public String getLink() {
		return link;
	}
	/**
	 * 该事件报道的新闻链接
	 * @param link
	 */
	public void setLink(String link) {
		this.link = link;
	}
	public String getText() {
		return text;
	}
	/**
	 * 该事件的文字描述
	 * @param text
	 */
	public void setText(String text) {
		this.text = text;
	}
	public String getImg() {
		return img;
	}
	/**
	 * 该事件的图片链接
	 * @param img
	 */
	public void setImg(String img) {
		this.img = img;
	}
	private String link;
	private String text;
	private String img;
}

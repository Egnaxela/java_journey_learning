package com.rongji.dfish.ui.plugins.echarts.json;

public class Feature {
	private boolean show;
	private LineStyle lineStyle ;
	
	
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class ForceSeries extends Series{
	public Categories[] getCategories() {
		return categories;
	}
	/**
	 * 节点分类, 详见图数据结构表示中的categories
	 * @param categories
	 */
	public void setCategories(Categories[] categories) {
		this.categories = categories;
	}
	public Links[] getLinks() {
		return links;
	}
	/**
	 * 力导向图的边数据, 和matrix二选一 详见图数据结构表示中的links
	 * @param links
	 */
	public void setLinks(Links[] links) {
		this.links = links;
	}
	public Double[][] getMatrix() {
		return matrix;
	}
	/**
	 * 力导向图的邻接矩阵, 和links二选一 详见图数据结构表示中的matrix
	 * @param matrix
	 */
	public void setMatrix(Double[][] matrix) {
		this.matrix = matrix;
	}
	public Data[] getData() {
		return data;
	}
	/**
	 * 力导向图的顶点数据, 详见图数据结构表示中的data
	 * @param data
	 */
	public void setData(Data[] data) {
		this.data = data;
	}
	public Number getSize() {
		return size;
	}
	/**
	 * 布局大小，可以是绝对值或者相对百分比
	 * @param size
	 */
	public void setSize(Number size) {
		this.size = size;
	}
	public Number getMinRadius() {
		return minRadius;
	}
	/**
	 * 顶点数据映射成圆半径后的最小半径
	 * @param minRadius
	 */
	public void setMinRadius(Number minRadius) {
		this.minRadius = minRadius;
	}
	public Number getMaxRadius() {
		return maxRadius;
	}
	/**
	 * 顶点数据映射成圆半径后的最大半径
	 * @param maxRadius
	 */
	public void setMaxRadius(Number maxRadius) {
		this.maxRadius = maxRadius;
	}
	public Number getScaling() {
		return scaling;
	}
	/**
	 * 布局缩放系数，并不完全精确, 效果跟布局大小类似
	 * @param scaling
	 */
	public void setScaling(Number scaling) {
		this.scaling = scaling;
	}
	public Number getGravity() {
		return gravity;
	}
	/**
	 * 向心力系数，系数越大则节点越往中心靠拢
	 * @param gravity
	 */
	public void setGravity(Number gravity) {
		this.gravity = gravity;
	}
	public Number getSteps() {
		return steps;
	}
	/**
	 * 每一帧布局计算的迭代次数，因为每一帧绘制的时间经常会比布局时间长很多，所以在使用 web worker 的时候可以把 steps 调大来平衡两者的时间从而达到效率最优化
	 * @param steps
	 */
	public void setSteps(Number steps) {
		this.steps = steps;
	}
	public boolean isDraggable() {
		return draggable;
	}
	/**
	 * 节点是否能被拖拽
	 * @param draggable
	 */
	public void setDraggable(boolean draggable) {
		this.draggable = draggable;
	}
	public boolean isLarge() {
		return large;
	}
	/**
	 * 在 500+ 顶点的图上建议设置 large 为 true, 会使用 Barnes-Hut simulation, 同时开启 useWorker 并且把 steps 值调大
	 * @param large
	 */
	public void setLarge(boolean large) {
		this.large = large;
	}
	public boolean isUseWorker() {
		return useWorker;
	}
	/**
	 * 是否在浏览器支持 web worker 的时候把布局计算放入 web worker 中
	 * @param useWorker
	 */
	public void setUseWorker(boolean useWorker) {
		this.useWorker = useWorker;
	}
	public String getLinkSymbol() {
		return linkSymbol;
	}
	/**
	 * 力导向图的边两端图形样式，可指定为'arrow', 详见symbolList
	 * @param linkSymbol
	 */
	public void setLinkSymbol(String linkSymbol) {
		this.linkSymbol = linkSymbol;
	}
	public String getRoam() {
		return roam;
	}
	/**
	 * 是否开启滚轮缩放和拖拽漫游，默认为false（关闭），其他有效输入为true（开启），'scale'（仅开启滚轮缩放），'move'（仅开启拖拽漫游）
	 * @param roam
	 */
	public void setRoam(String roam) {
		this.roam = roam;
	}
	public String getSymbol() {
		return symbol;
	}
	/**
	 * 同series（直角系）
	 * @param symbol
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Double[] getSymbolSize() {
		return symbolSize;
	}
	/**
	 * 节点的大小
	 * @param symbolSize
	 */
	public void setSymbolSize(Double[] symbolSize) {
		this.symbolSize = symbolSize;
	}
	public Double[] getLinkSymbolSize() {
		return linkSymbolSize;
	}
	/**
	 * 力导向图的边两端图形大小
	 * @param linkSymbolSize
	 */
	public void setLinkSymbolSize(Double[] linkSymbolSize) {
		this.linkSymbolSize = linkSymbolSize;
	}
	public String[] getCenter() {
		return center;
	}
	/**
	 * 布局中心，可以是绝对值或者相对百分比
	 * @param center
	 */
	public void setCenter(String[] center) {
		this.center = center;
	}
private Categories[] categories;
private Links[] links;
private Double[][] matrix;
private String[] center;
private Data[] data;
private Number size;
private Number minRadius;
private Number maxRadius;
private Number scaling;
private Number gravity;
private Number steps;
private boolean draggable;
private boolean large;
private boolean useWorker;
private String linkSymbol;
private String roam;
private String symbol;
private Double[] symbolSize;
private Double[] linkSymbolSize;

}

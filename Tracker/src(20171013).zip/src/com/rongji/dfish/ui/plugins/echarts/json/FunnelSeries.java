package com.rongji.dfish.ui.plugins.echarts.json;

public class FunnelSeries extends Series{
	public String getX() {
		return x;
	}
	/**
	 * 左上角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	/**
	 * 左上角纵坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域纵向中心)
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	public String getX2() {
		return x2;
	}
	/**
	 * 右下角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
	 * @param x2
	 */
	public void setX2(String x2) {
		this.x2 = x2;
	}
	public String getY2() {
		return y2;
	}
	/**
	 * 右下角纵坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域纵向中心)
	 * @param y2
	 */
	public void setY2(String y2) {
		this.y2 = y2;
	}
	public String getWidth() {
		return width;
	}
	/**
	 * 总宽度，默认为绘图区总宽度 - x - x2，数值单位px，指定width后将忽略x2，支持百分比（字符串），如'50%'(显示区域一半的宽度)
	 * @param width
	 */
	public void setWidth(String width) {
		this.width = width;
	}
	public String getHeight() {
		return height;
	}
	/**
	 * 总高度，默认为绘图区总高度 - y - y2，数值单位px，指定height后将忽略y2，支持百分比（字符串），如'50%'(显示区域一半的高度)
	 * @param height
	 */
	public void setHeight(String height) {
		this.height = height;
	}
	public String getFunnelAlign() {
		return funnelAlign;
	}
	/**
	 * 水平方向对齐布局类型，默认居中对齐，可用选项还有：'left' | 'right' | 'center'
	 * @param funnelAlign
	 */
	public void setFunnelAlign(String funnelAlign) {
		this.funnelAlign = funnelAlign;
	}
	public String getMinSize() {
		return minSize;
	}
	/**
	 * 最小值min映射到总宽度的比例，如果需要最小值的图形并不是尖端三角，可设置minSize实现
	 * @param minSize
	 */
	public void setMinSize(String minSize) {
		this.minSize = minSize;
	}
	public String getMaxSize() {
		return maxSize;
	}
	/**
	 * 最大值max映射到总宽度的比例
	 * @param maxSize
	 */
	public void setMaxSize(String maxSize) {
		this.maxSize = maxSize;
	}
	public String getSort() {
		return sort;
	}
	/**
	 * 数据排序， 可以取ascending, descending
	 * @param sort
	 */
	public void setSort(String sort) {
		this.sort = sort;
	}
	public Number getMin() {
		return min;
	}
	/**
	 * 指定的最小值
	 * @param min
	 */
	public void setMin(Number min) {
		this.min = min;
	}
	public Number getMax() {
		return max;
	}
	/**
	 * 指定的最大值
	 * @param max
	 */
	public void setMax(Number max) {
		this.max = max;
	}
	public Number getGap() {
		return gap;
	}
	/**
	 * 数据图形间距
	 * @param gap
	 */
	public void setGap(Number gap) {
		this.gap = gap;
	}
	public boolean isLegendHoverLink() {
		return legendHoverLink;
	}
	/**
	 * 是否启用图例（legend）hover时的联动响应（高亮显示）
	 * @param legendHoverLink
	 */
	public void setLegendHoverLink(boolean legendHoverLink) {
		this.legendHoverLink = legendHoverLink;
	}

	private String x;
	private String y;
	private String x2;
	private String y2;
	private String width;
	private String height;
	private String funnelAlign;
	private String minSize;
	private String maxSize;
	private String sort;
	private Number min;
	private Number max;
	private Number gap;
	private boolean legendHoverLink;
}

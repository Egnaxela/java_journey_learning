package com.rongji.dfish.ui.plugins.echarts.json;

public class GaugeSeries extends Series{

	public Number getStartAngle() {
		return startAngle;
	}
	/**
	 * 开始角度, 饼图（90）、仪表盘（225），有效输入范围：[-360,360]
	 * @param startAngle
	 */
	public void setStartAngle(Number startAngle) {
		this.startAngle = startAngle;
	}
	public Number getEndAngle() {
		return endAngle;
	}
	/**
	 * 结束角度,有效输入范围：[-360,360]，保证startAngle - endAngle为正值
	 * @param endAngle
	 */
	public void setEndAngle(Number endAngle) {
		this.endAngle = endAngle;
	}
	public Number getMin() {
		return min;
	}
	/**
	 * 指定的最小值
	 * @param min
	 */
	public void setMin(Number min) {
		this.min = min;
	}
	public Number getMax() {
		return max;
	}
	/**
	 * 指定的最大值
	 * @param max
	 */
	public void setMax(Number max) {
		this.max = max;
	}
	public Number getSplitNumber() {
		return splitNumber;
	}
	/**
	 * 分割段数，默认为10
	 * @param splitNumber
	 */
	public void setSplitNumber(Number splitNumber) {
		this.splitNumber = splitNumber;
	}
	public AxisLine getAxisLine() {
		return axisLine;
	}
	/**
	 * 坐标轴线，默认显示 
	属性show控制显示与否， 
	属性lineStyle（详见lineStyle）控制线条样式， 
	比较特殊的是这里的lineStyle.color是一个二维数组，用于把仪表盘轴线分成若干份， 
	并且可以给每一份指定具体的颜色，格式为:[[百分比, 颜色值], [...]]
	 * @param axisLine
	 */
	public void setAxisLine(AxisLine axisLine) {
		this.axisLine = axisLine;
	}
	public AxisTick getAxisTick() {
		return axisTick;
	}
	/**
	 * 坐标轴小标记，默认显示 
	属性show控制显示与否， 
	属性lineStyle（详见lineStyle）控制线条样式， 
	属性splitNumber控制每份split细分多少段 
	属性length控制线长
	 * @param axisTick
	 */
	public void setAxisTick(AxisTick axisTick) {
		this.axisTick = axisTick;
	}
	public AxisLabel getAxisLabel() {
		return axisLabel;
	}
	/**
	 * 坐标轴文本标签（详见axis.axislabel） 
	属性formatter可以格式化文本标签， 
	属性textStyle（详见textStyle）控制文本样式
	 * @param axisLabel
	 */
	public void setAxisLabel(AxisLabel axisLabel) {
		this.axisLabel = axisLabel;
	}
	public SplitLine getSplitLine() {
		return splitLine;
	}
	/**
	 * 主分隔线，默认显示 
	属性show控制显示与否， 
	属性length控制线长 
	属性lineStyle（详见lineStyle）控制线条样式，
	 * @param splitLine
	 */
	public void setSplitLine(SplitLine splitLine) {
		this.splitLine = splitLine;
	}
	public Pointer getPointer() {
		return pointer;
	}
	/**
	 * 指针样式 
	属性length控制线长，百分比相对的是仪表盘的外半径 
	属性width控制指针最宽处， 
	属性color控制指针颜色
	 * @param pointer
	 */
	public void setPointer(Pointer pointer) {
		this.pointer = pointer;
	}
	public Title getTitle() {
		return title;
	}
	/**
	 * 仪表盘标题 
	属性show控制显示与否， 
	属性offsetCenter用于标题定位，数组为横纵相对仪表盘圆心坐标偏移，支持百分比（相对外半径）， 
	属性textStyle（详见textStyle）控制文本样式
	 * @param title
	 */
	public void setTitle(Title title) {
		this.title = title;
	}
	public Detail getDetail() {
		return detail;
	}
	/**
	 * 仪表盘详情 
	属性show控制显示与否， 
	属性backgroundColor控制边框颜色， 
	属性borderWidth控制边框线宽， 
	属性borderColor控制边框颜色， 
	属性width控制详情宽度， 
	属性height控制详情高度， 
	属性offsetCenter用于详情定位，数组为横纵相对仪表盘圆心坐标偏移，支持百分比（相对外半径）， 
	属性formatter可以格式化文本， 
	属性textStyle（详见textStyle）控制文本样式
	 * @param detail
	 */
	public void setDetail(Detail detail) {
		this.detail = detail;
	}
	public boolean isLegendHoverLink() {
		return legendHoverLink;
	}
	/**
	 * 是否启用图例（legend）hover时的联动响应（高亮显示）
	 * @param legendHoverLink
	 */
	public void setLegendHoverLink(boolean legendHoverLink) {
		this.legendHoverLink = legendHoverLink;
	}

	/**
	 * 圆心坐标，支持绝对值（px）和百分比，百分比计算min(width, height) * 50%
	 *如['50%', '50%']
	 * @param center
	 */
	public void setCenter(String[] center) {
		this.center = center;
	}
	/**
	 * 半径，支持绝对值（px）和百分比，百分比计算比，min(width, height) / 2 * 75%， 
传数组实现环形图，如['50%', '50%']
	 * @param radius
	 */
	public void setRadius(String[] radius) {
		this.radius = radius;
	}
	public String[] getCenter() {
		return center;
	}
	public String[] getRadius() {
		return radius;
	}
private String [] center;
private String [] radius;
private Number startAngle;
private Number endAngle;
private Number min;
private Number max;
private Number splitNumber;
private AxisLine axisLine;
private AxisTick axisTick;
private AxisLabel axisLabel;
private SplitLine splitLine;
private Pointer pointer;
private Title title;
private Detail detail;
private boolean legendHoverLink;
}

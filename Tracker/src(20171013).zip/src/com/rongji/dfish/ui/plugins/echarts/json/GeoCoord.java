package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 通过绝对经纬度指定地区的名称文本位置，如{'Islands':[113.95, 22.26]}，香港离岛区名称显示定位到东经113.95，北纬22.26上
 * @author Administrator
 *
 */
public class GeoCoord {
public String getName() {
		return name;
	}
	/**
	 * name表示地区名称
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	public Double getX() {
		return x;
	}
	/**
	 * x表示绝对经度
	 * @param x
	 */
	public void setX(Double x) {
		this.x = x;
	}
	public Double getY() {
		return y;
	}
	/**
	 * y表示绝对纬度
	 * @param y
	 */
	public void setY(Double y) {
		this.y = y;
	}
private String name;
private Double x;
private Double y;
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class Grid {
	private double zlevel;
	private double z;
	private double x;
	private double y;
	private double x2;
	private double y2;
	private double width;
	private double height;
	private String backgroundColor;
	private double borderWidth;
	private String borderColor;
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public double getX() {
		return x;
	}
	
	/**
	 * 直角坐标系内绘图网格左上角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
	 * @param x
	 */
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	
	/**
	 * 直角坐标系内绘图网格左上角纵坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域纵向中心)
	 * @param y
	 */
	public void setY(double y) {
		this.y = y;
	}
	public double getX2() {
		return x2;
	}
	
	/**
	 * 直角坐标系内绘图网格右下角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
	 * @param x2
	 */
	public void setX2(double x2) {
		this.x2 = x2;
	}
	public double getY2() {
		return y2;
	}
	
	/**
	 * 直角坐标系内绘图网格右下角纵坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域纵向中心)
	 * @param y2
	 */
	public void setY2(double y2) {
		this.y2 = y2;
	}
	public double getWidth() {
		return width;
	}
	
	/**
	 * 直角坐标系内绘图网格（不含坐标轴）宽度，默认为总宽度 - x - x2，数值单位px，指定width后将忽略x2，见下图。 
                  支持百分比（字符串），如'50%'(显示区域一半的宽度)
	 * @param width
	 */
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	
	/**
	 * 直角坐标系内绘图网格（不含坐标轴）高度，默认为总高度 - y - y2，数值单位px，指定height后将忽略y2，见下图。
                  支持百分比（字符串），如'50%'(显示区域一半的高度)
	 * @param height
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 背景颜色，默认透明
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public double getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 边框线宽
	 * @param borderWidth
	 */
	public void setBorderWidth(double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 边框颜色。
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	
}

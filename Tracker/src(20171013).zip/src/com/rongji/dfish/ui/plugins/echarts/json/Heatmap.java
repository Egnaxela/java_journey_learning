package com.rongji.dfish.ui.plugins.echarts.json;

public class Heatmap {
public Double getBlurSize() {
		return blurSize;
	}
	/**
	 * 一个热力图数据点的模糊范围，单位是像素
	 * @param blurSize
	 */
	public void setBlurSize(Double blurSize) {
		this.blurSize = blurSize;
	}
	public String[] getGradientColors() {
		return gradientColors;
	}
	/**
	 * 可以是一个包含 offset 和 color 的 Object 的数组，如 [{ offset: 0.2, color: 'blue' }, { offset 0.8, color: 'cyan' }]；也可以是一个颜色字符串的数组如 ['blue', 'cyan', 'lime', 'yellow', 'red']，颜色将均匀分布。
	 * @param gradientColors
	 */
	public void setGradientColors(String[] gradientColors) {
		this.gradientColors = gradientColors;
	}
	public Double getMinAlpha() {
		return minAlpha;
	}
	/**
	 * 当均一化后的数据点的值小于这个值时，将被设为该值。该值保证了数据值很小的数据也能在地图上展示。
	 * @param minAlpha
	 */
	public void setMinAlpha(Double minAlpha) {
		this.minAlpha = minAlpha;
	}
	public Double getValueScale() {
		return valueScale;
	}
	/**
	 * 所有数据点的值将乘以这个值再进行绘制。
	 * @param valueScale
	 */
	public void setValueScale(Double valueScale) {
		this.valueScale = valueScale;
	}
	public Double getOpacity() {
		return opacity;
	}
	/**
	 * 整个热力图的不透明度。
	 * @param opacity
	 */
	public void setOpacity(Double opacity) {
		this.opacity = opacity;
	}
private Double blurSize;
private String[] gradientColors;
private Double minAlpha;
private Double valueScale;
private Double opacity;
}

package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * Series.Data的内容格式之一
 * @author Administrator
 *
 */
public class Item {
public double getValue() {
	return value;
}
public void setValue(double value) {
	this.value = value;
}
public Tooltip getTooltip() {
	return tooltip;
}
public void setTooltip(Tooltip tooltip) {
	this.tooltip = tooltip;
}
public ItemStyle getItemStyle() {
	return itemStyle;
}
public void setItemStyle(ItemStyle itemStyle) {
	this.itemStyle = itemStyle;
}
public boolean isSelected() {
	return selected;
}
public void setSelected(boolean selected) {
	this.selected = selected;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
private String name;
private double value;
private Tooltip tooltip;
private ItemStyle itemStyle;
private boolean selected ;
}

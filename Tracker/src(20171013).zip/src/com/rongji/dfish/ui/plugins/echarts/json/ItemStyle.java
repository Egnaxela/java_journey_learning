package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 图形样式，可设置图表内图形的默认样式和强调样式（悬浮时样式）
 * 
 */
public class ItemStyle {

	private Normal normal;
	private Emphasis emphasis;

	public Normal getNormal() {
		return normal;
	}

	public void setNormal(Normal normal) {
		this.normal = normal;
	}

	public Emphasis getEmphasis() {
		return emphasis;
	}

	public void setEmphasis(Emphasis emphasis) {
		this.emphasis = emphasis;
	}

}

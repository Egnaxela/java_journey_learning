package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 标签
 * 
 */
public class Label {
	
	/**
	 * 饼图可选：外部
	 */
	public static final String POSITION_OUTER="outer";
	/**
	 * 饼图可选：内部
	 * 漏斗图可选：内部
	 */
	public static final String POSITION_INNER="inner";
	/**
	 * 折线图，柱形图，K线图，散点图，漏斗可选：左边
	 */
	public static final String POSITION_LEFT="left";
	/**
	 * 折线图，柱形图，K线图，散点图，漏斗可选：右边
	 */
	public static final String POSITION_RIGHT="right";
	/**
	 * 折线图，柱形图，K线图，散点图可选：上边
	 */
	public static final String POSITION_TOP="top";
	/**
	 * 折线图，柱形图，K线图，散点图可选：下边
	 */
	public static final String POSITION_BOTTOM="bottom";
	/**
	 * 折线图，柱形图，K线图，散点图可选：内部
	 */
	public static final String POSITION_INSIDE="inside";
	/**
	 * 柱形图可选：内部左边
	 */
	public static final String POSITION_INSIDELEFT="insideLeft";
	/**
	 * 柱形图可选：内部右边
	 */
	public static final String POSITION_INSIDERIGHT="insideRight";
	/**
	 * 柱形图可选：内部下边
	 */
	public static final String POSITION_INSIDETOP="insideTop";
	/**
	 * 柱形图可选：内部上边
	 */
	public static final String POSITION_INSIDEBOTTOM="insideBottom";
	
	
	private Boolean show;
	private String interval;
	private String position;
	private Boolean rotate;
	private Double distance;
	private String formatter;
	private TextStyle textStyle;
	private Double x;
	private Double y;
	
	public Label() {
	}

	public Label(Boolean show, String interval, String position,
			Boolean rotate, Double distance, String formatter,
			TextStyle textStyle, Double x, Double y) {
		super();
		this.show = show;
		this.interval = interval;
		this.position = position;
		this.rotate = rotate;
		this.distance = distance;
		this.formatter = formatter;
		this.textStyle = textStyle;
		this.x = x;
		this.y = y;
	}



	/**
	 * 标签显示策略，可选为：true（显示） | false（隐藏）
	 * @param show
	 */
	public void setShow(Boolean show) {
		this.show = show;
	}
	/**
	 * 标签显示位置，地图标签不可指定位置 
	 * 饼图可选为：'outer'（外部） | 'inner'（内部）， 
	 * 漏斗图可选为：'inner'（内部）| 'left' | 'right'（默认）， 
	 * 折线图，柱形图，K线图，散点图默认根据布局自适应为'top'或者'right'，
	 * 可选的还有：'inside' | 'left' | 'bottom' 
	 * 柱形图可选的还有，'insideLeft' | 'insideRight' | 'insideTop' | 'insideBottom'
	 * @param position
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * 和弦图有效，文本标签自动旋转
	 * @param rotate
	 */
	public void setRotate(Boolean rotate) {
		this.rotate = rotate;
	}
	/**
	 * 和弦图: 文本标签旋转后于弦的间隔 
	 * 饼图: 当label position为inner时有效，
	 * 为label位置到圆心的距离与圆半径(环状图为内外半径和)的比例系数，默认为0.5。
	 * @param distance
	 */
	public void setDistance(Double distance) {
		this.distance = distance;
	}
	/**
	 * 标签文本格式器，通用，同Tooltip.formatter，支持模板、方法回调，不支持异步回调
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	/**
	 * 标签的文本样式（详见textStyle）
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
	/**
	 * 仅矩形树图使用，标签横坐标
	 * @param x
	 */
	public void setX(Double x) {
		this.x = x;
	}
	/**
	 * 仅矩形树图使用，标签纵坐标
	 * @param y
	 */
	public void setY(Double y) {
		this.y = y;
	}
	
	/**
	 * 注：该属性仅在 【时间轴标签文本】 可用
	 * 挑选间隔，默认为'auto'，可选为：'auto'（自动隐藏显示不下的） | 0（全部显示） | {number} 
	 * @param interval
	 */
	public void setInterval(String interval) {
		this.interval = interval;
	}

	public Boolean getShow() {
		return show;
	}
	public String getPosition() {
		return position;
	}
	public Boolean getRotate() {
		return rotate;
	}
	public Double getDistance() {
		return distance;
	}
	public String getFormatter() {
		return formatter;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	public Double getX() {
		return x;
	}
	public Double getY() {
		return y;
	}

	public String getInterval() {
		return interval;
	}
	
}

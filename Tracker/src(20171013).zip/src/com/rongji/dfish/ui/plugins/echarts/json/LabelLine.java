package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 标签视觉引导线
 * 
 */
public class LabelLine {
	private Boolean show;
	private Double length;
	private LineStyle lineStyle;
	
	public LabelLine() {
	}
	
	public LabelLine(Boolean show, Double length, LineStyle lineStyle) {
		super();
		this.show = show;
		this.length = length;
		this.lineStyle = lineStyle;
	}
	
	/**
	 * 饼图标签视觉引导线显示策略，可选为：true（显示） | false（隐藏）
	 * @param show
	 */
	public void setShow(Boolean show) {
		this.show = show;
	}
	/**
	 * 线长 ，从图形外边缘起计算，可为负值。漏斗图支持'auto'
	 * @param length
	 */
	public void setLength(Double length) {
		this.length = length;
	}
	/**
	 * 线条样式，详见lineStyle
	 * @param lineStyle
	 */
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}
	
	public Boolean getShow() {
		return show;
	}
	public Double getLength() {
		return length;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	
}

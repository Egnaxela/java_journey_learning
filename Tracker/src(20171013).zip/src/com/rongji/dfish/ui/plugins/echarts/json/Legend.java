package com.rongji.dfish.ui.plugins.echarts.json;

import java.util.Map;

public class Legend {
	private Boolean show;
	private Number zlevel;
	private Number z;
	private String orient;
	private String x;
	private String y;
	private String backgroundColor;
	private String borderColor;
	private Number borderWidth;
	private Number padding;
	private Number itemGap;
	private Number itemWidth;
	private Number itemHeight;
	private TextStyle textStyle;
	private String formatter;
	private Boolean  selectedMode;
	private Map<Object, Object> selected;      //不确定
	private String[] data;
	public Boolean isShow() {
		return show;
	}
	
	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）
	 * @param show
	 */
	public void setShow(Boolean show) {
		this.show = show;
	}
	public Number getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(Number zlevel) {
		this.zlevel = zlevel;
	}
	public Number getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(Number z) {
		this.z = z;
	}
	public String getOrient() {
		return orient;
	}
	
	/**
	 * 布局方式，默认为水平布局，可选为：'horizontal' | 'vertical'
	 * @param orient
	 */
	public void setOrient(String orient) {
		this.orient = orient;
	}
	public String getX() {
		return x;
	}
	
	/**
	 * 水平安放位置，默认为全图居中，可选为：'center' | 'left' | 'right' | {number}（x坐标，单位px）s
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	
	/**
	 * 垂直安放位置，默认为全图顶端，可选为：'top' | 'bottom' | 'center' | {number}（y坐标，单位px）
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 图例背景颜色，默认透明
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 图例边框颜色
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public Number getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 图例边框线宽，单位px，默认为0（无边框）
	 * @param borderWidth
	 */
	public void setBorderWidth(Number borderWidth) {
		this.borderWidth = borderWidth;
	}
	public Number getPadding() {
		return padding;
	}
	
	/**
	 * 图例内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css，见下图
	 * @param padding
	 */
	public void setPadding(Number padding) {
		this.padding = padding;
	}
	public Number getItemGap() {
		return itemGap;
	}
	
	/**
	 * 各个item之间的间隔，单位px，默认为10，横向布局时为水平间隔，纵向布局时为纵向间隔，见下图
	 * @param itemGap
	 */
	public void setItemGap(Number itemGap) {
		this.itemGap = itemGap;
	}
	public Number getItemWidth() {
		return itemWidth;
	}
	
	/**
	 * 图例图形宽度
	 * @param itemWidth
	 */
	public void setItemWidth(Number itemWidth) {
		this.itemWidth = itemWidth;
	}
	public Number getItemHeight() {
		return itemHeight;
	}
	
	/**
	 * 图例图形高度
	 * @param itemHeight
	 */
	public void setItemHeight(Number itemHeight) {
		this.itemHeight = itemHeight;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	
	/**
	 * 默认只设定了图例文字颜色（详见textStyle） ，更个性化的是，要指定文字颜色跟随图例，可设color为'auto'
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
	public String getFormatter() {
		return formatter;
	}
	
	/**
	 * 文本格式器：{string}（Template） | {Function}，模板变量为'{name}'，函数回调参数为name
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	public Boolean isSelectedMode() {
		return selectedMode;
	}
	
	/**
	 * 选择模式，默认开启图例开关，可选single，multiple
	 * @param selectedMode
	 */
	public void setSelectedMode(Boolean selectedMode) {
		this.selectedMode = selectedMode;
	}
	
	
	
	public Map<Object, Object> getSelected() {
		return selected;
	}

	/**
	 * 
	 * 配置默认选中状态，可配合LEGEND.SELECTED事件做动态数据载入
	 *  selected: {
            '降水量' : false
        },
	 * @param selected
	 */
	public void setSelected(Map<Object, Object> selected) {
		this.selected = selected;
	}

	public String[] getData() {
		return data;
	}
	
	/**
	 * 图例内容数组，数组项通常为{string}，每一项代表一个系列的name，默认布局到达边缘会自动分行（列），传入空字符串''可实现手动分行（列）。 
                 使用根据该值索引series中同名系列所用的图表类型和itemStyle，如果索引不到，该item将默认为没启用状态。 
               如需个性化图例文字样式，可把数组项改为{Object}，指定文本样式和个性化图例icon，格式为 
     {
      name : {string}, 
      textStyle : {Object}, 
      icon : {string}
      }
	 * @param data
	 */
	public void setData(String[] data) {
		this.data = data;
	}

	
	
}

package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 线条（线段）样式
 * 
 */
public class LineStyle {
	
	/**
	 * 线条样式 : 实线
	 */
	public static final String TYPE_SOLID = "solid";
	/**
	 * 线条样式 : 点线
	 */
	public static final String TYPE_DOTTED = "dotted";
	/**
	 * 线条样式 : 虚线
	 */
	public static final String TYPE_DASHED = "dashed";
	/**
	 * 线条样式 : 树图可以选 : 弧线
	 */
	public static final String TYPE_CURVE = "curve";
	/**
	 * 线条样式 : 树图可以选 : 折线
	 */
	public static final String TYPE_BROKEN = "broken";
	
	private String color;
	private String type;
	private Double width;
	private String shadowColor;
	private Double shadowBlur;
	private Double shadowOffsetX;
	private Double shadowOffsetY;
	
	public LineStyle() {
	}
	
	public LineStyle(String color, String type, Double width,
			String shadowColor, Double shadowBlur, Double shadowOffsetX,
			Double shadowOffsetY) {
		super();
		this.color = color;
		this.type = type;
		this.width = width;
		this.shadowColor = shadowColor;
		this.shadowBlur = shadowBlur;
		this.shadowOffsetX = shadowOffsetX;
		this.shadowOffsetY = shadowOffsetY;
	}
	/**
	 * 颜色
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 线条样式，可选为：'solid' | 'dotted' | 'dashed'， 树图还可以选：'curve' | 'broken'
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * 线宽
	 * @param width
	 */
	public void setWidth(Double width) {
		this.width = width;
	}
	/**
	 * 折线主线(IE8+)有效，阴影色彩，支持rgba
	 * @param shadowColor
	 */
	public void setShadowColor(String shadowColor) {
		this.shadowColor = shadowColor;
	}
	/**
	 * 折线主线(IE8+)有效，阴影模糊度，大于0有效
	 * @param shadowBlur
	 */
	public void setShadowBlur(Double shadowBlur) {
		this.shadowBlur = shadowBlur;
	}
	/**
	 * 折线主线(IE8+)有效，阴影横向偏移，正值往右，负值往左
	 * @param shadowOffsetX
	 */
	public void setShadowOffsetX(Double shadowOffsetX) {
		this.shadowOffsetX = shadowOffsetX;
	}
	/**
	 * 折线主线(IE8+)有效，阴影纵向偏移，正值往下，负值往上
	 * @param shadowOffsetY
	 */
	public void setShadowOffsetY(Double shadowOffsetY) {
		this.shadowOffsetY = shadowOffsetY;
	}
	public String getColor() {
		return color;
	}
	public String getType() {
		return type;
	}
	public Double getWidth() {
		return width;
	}
	public String getShadowColor() {
		return shadowColor;
	}
	public Double getShadowBlur() {
		return shadowBlur;
	}
	public Double getShadowOffsetX() {
		return shadowOffsetX;
	}
	public Double getShadowOffsetY() {
		return shadowOffsetY;
	}
	
	
}

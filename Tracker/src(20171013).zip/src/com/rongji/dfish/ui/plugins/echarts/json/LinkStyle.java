package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 力导向图中的边样式
 * 
 */
public class LinkStyle {
	
	/**
	 * 曲线
	 */
	public static final String TYPE_CURVE = "curve";
	
	/**
	 * 直线
	 */
	public static final String TYPE_LINE = "line";
	
	private String type;
	private String color;
	private Double width;
	
	
	/**
	 * 线条类型，可选为：'curve'（曲线） | 'line'（直线）
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * 线条颜色
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 线宽
	 * @param width
	 */
	public void setWidth(Double width) {
		this.width = width;
	}
	
	public String getType() {
		return type;
	}
	public String getColor() {
		return color;
	}
	public Double getWidth() {
		return width;
	}

}

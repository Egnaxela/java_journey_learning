package com.rongji.dfish.ui.plugins.echarts.json;

public class Links {
	private String source;
	private String target;
	private Double weight;
	private ItemStyle itemStyle;
	
	public Links() {
	}

	public Links(String source, String target, Double weight,
			ItemStyle itemStyle) {
		super();
		this.source = source;
		this.target = target;
		this.weight = weight;
		this.itemStyle = itemStyle;
	}
	
	/**
	 * 源节点的index或者源节点的name
	 * @param source
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * 目标节点的index或者目标节点的name
	 * @param target
	 */
	public void setTarget(String target) {
		this.target = target;
	}

	/**
	 * 边的权重
	 * @param weight
	 */
	public void setWeight(Double weight) {
		this.weight = weight;
	}

	/**
	 * see linkStyle
	 * @param itemStyle
	 */
	public void setItemStyle(ItemStyle itemStyle) {
		this.itemStyle = itemStyle;
	}

	public String getSource() {
		return source;
	}

	public String getTarget() {
		return target;
	}

	public Double getWeight() {
		return weight;
	}

	public ItemStyle getItemStyle() {
		return itemStyle;
	}
	
}

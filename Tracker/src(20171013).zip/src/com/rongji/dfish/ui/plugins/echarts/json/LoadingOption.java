package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 过渡显示，loading（读取中）的选项。
 * 
 */
public class LoadingOption {
	
	/**
	 * 水平安放位置 : 居中
	 */
	public static final String X_CENTER = "center";
	/**
	 * 水平安放位置 : 左边
	 */
	public static final String X_LEFT = "left";
	/**
	 * 水平安放位置 : 右边
	 */
	public static final String X_RIGHT = "right";
	
	/**
	 * 垂直安放位置  : 居中
	 */
	public static final String Y_CENTER = "center";
	/**
	 * 垂直安放位置  : 上方
	 */
	public static final String Y_BOTTOM = "bottom";
	/**
	 * 垂直安放位置  : 下方
	 */
	public static final String Y_TOP = "top";
	
	/**
	 * loading效果 : 旋转
	 */
	public static final String EFFECT_SPIN = "spin";
	/**
	 * loading效果 : 条形
	 */
	public static final String EFFECT_BAR = "bar";
	/**
	 * loading效果 : 环形
	 */
	public static final String EFFECT_RING = "ring";
	/**
	 * loading效果 : 涡流
	 */
	public static final String EFFECT_WHIRLING = "whirling";
	/**
	 * loading效果 : 动态线条
	 */
	public static final String EFFECT_DYNAMICLINE = "dynamicLine";
	/**
	 * loading效果 : 冒泡
	 */
	public static final String EFFECT_BUBBLE = "bubble";
	
	private String Text;
	private String x;
	private String y;
	private TextStyle textStyle;
	private String effect;
	private Double progress;
	
	public LoadingOption() {
	}

	public LoadingOption(String text, String x, String y, TextStyle textStyle,
			String effect, Double progress) {
		super();
		Text = text;
		this.x = x;
		this.y = y;
		this.textStyle = textStyle;
		this.effect = effect;
		this.progress = progress;
	}


	/**
	 * 显示话术 ，'\n'指定换行
	 * @param text
	 */
	public void setText(String text) {
		Text = text;
	}
	/**
	 * 水平安放位置，默认为全图居中，可选为：'center' | 'left' | 'right' | {number}（x坐标，单位px）
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	/**
	 * 垂直安放位置，默认为全图居中，可选为：'center' | 'bottom' | 'top' | {number}（y坐标，单位px）
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	/**
	 * 显示话术的文本样式（详见textStyle）
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
	/**
	 * loading效果，可选为：'spin' | 'bar' | 'ring' | 'whirling' | 'dynamicLine' | 'bubble'，支持外部装载
	 * @param effect
	 */
	public void setEffect(String effect) {
		this.effect = effect;
	}
	/**
	 * 指定当前进度[0~1]，个别效果有效。
	 * @param progress
	 */
	public void setProgress(Double progress) {
		this.progress = progress;
	}

	public String getText() {
		return Text;
	}

	public String getX() {
		return x;
	}

	public String getY() {
		return y;
	}

	public TextStyle getTextStyle() {
		return textStyle;
	}

	public String getEffect() {
		return effect;
	}

	public Double getProgress() {
		return progress;
	}

}

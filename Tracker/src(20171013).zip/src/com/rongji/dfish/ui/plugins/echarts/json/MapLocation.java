package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 地图位置设置，默认只适应上下左右居中'center'可配x，y，width，height，任意参数为空都将根据其他参数自适应
 * @author Administrator
 *
 */
public class MapLocation {
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	private String x;
	private String y;
	private String width;
	private String height;
}

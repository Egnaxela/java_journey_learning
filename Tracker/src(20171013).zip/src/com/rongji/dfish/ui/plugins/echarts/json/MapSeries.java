package com.rongji.dfish.ui.plugins.echarts.json;


public class MapSeries extends Series{
public String getSelectedMode() {
		return selectedMode;
	}
	/**
	 * 选中模式，默认关闭，可选single，multiple
	 * @param selectedMode
	 */
	public void setSelectedMode(String selectedMode) {
		this.selectedMode = selectedMode;
	}
	public String getMapType() {
		return mapType;
	}
	/**
	 * 地图类型，支持world，china及全国34个省市自治区。省市自治区的mapType直接使用简体中文： 
		新疆， 西藏， 内蒙古， 青海， 四川， 黑龙江， 甘肃， 云南， 广西， 湖南， 陕西， 
		广东，吉林， 河北， 湖北， 贵州， 山东， 江西， 河南， 辽宁， 山西， 安徽， 福建， 
		浙江， 江苏，重庆， 宁夏， 海南， 台湾， 北京， 天津， 上海， 香港， 澳门' 
		支持子区域模式，通过主地图类型扩展出所包含的子区域地图，格式为'主地图类型|子区域名称'，如 
		'world|Brazil'，'china|广东'，详见例子 this 》
	 * @param mapType
	 */
	public void setMapType(String mapType) {
		this.mapType = mapType;
	}
	public String getMapValueCalculation() {
		return mapValueCalculation;
	}
	/**
	 * 地图数值计算方式，默认为加和，可选为：'sum'（总数） | 'average'（均值）
	 * @param mapValueCalculation
	 */
	public void setMapValueCalculation(String mapValueCalculation) {
		this.mapValueCalculation = mapValueCalculation;
	}
	public String getRoam() {
		return roam;
	}
	/**
	 * 是否开启滚轮缩放和拖拽漫游，默认为false（关闭），其他有效输入为true（开启），'scale'（仅开启滚轮缩放），'move'（仅开启拖拽漫游）
	 * @param roam
	 */
	public void setRoam(String roam) {
		this.roam = roam;
	}
	public boolean isHoverable() {
		return hoverable;
	}
	/**
	 * 非数值显示（如仅用于显示标注标线时），可以通过hoverable:false关闭区域悬浮高亮
	 * @param hoverable
	 */
	public void setHoverable(boolean hoverable) {
		this.hoverable = hoverable;
	}
	public boolean isDataRangeHoverLink() {
		return dataRangeHoverLink;
	}
	/**
	 * 是否启用值域漫游组件（dataRange）hover时的联动响应（详情披露）
	 * @param dataRangeHoverLink
	 */
	public void setDataRangeHoverLink(boolean dataRangeHoverLink) {
		this.dataRangeHoverLink = dataRangeHoverLink;
	}
	public boolean isShowLegendSymbol() {
		return showLegendSymbol;
	}
	/**
	 * 显示图例颜色标识（系列标识的小圆点），存在legend时生效
	 * @param showLegendSymbol
	 */
	public void setShowLegendSymbol(boolean showLegendSymbol) {
		this.showLegendSymbol = showLegendSymbol;
	}
	public Number getMapValuePrecision() {
		return mapValuePrecision;
	}
	/**
	 * 地图数值计算结果小数精度，mapValueCalculation为average时有效，默认为取整，需要小数精度时设置大于0的整数
	 * @param mapValuePrecision
	 */
	public void setMapValuePrecision(Number mapValuePrecision) {
		this.mapValuePrecision = mapValuePrecision;
	}
	public MapLocation getMapLocation() {
		return mapLocation;
	}
	/**
	 * 地图位置设置，默认只适应上下左右居中可配x，y，width，height，任意参数为空都将根据其他参数自适应
	 * @param mapLocation
	 */
	public void setMapLocation(MapLocation mapLocation) {
		this.mapLocation = mapLocation;
	}
	public ScaleLimit getScaleLimit() {
		return scaleLimit;
	}
	/**
	 * 滚轮缩放的极限控制，可指定{max:number, min:number}，其中max为放大系数，有效值应大于1，min为缩小系数，有效值应小于1
	 * @param scaleLimit
	 */
	public void setScaleLimit(ScaleLimit scaleLimit) {
		this.scaleLimit = scaleLimit;
	}

	public NameMap getNameMap() {
		return nameMap;
	}
	/**
	 * 自定义地区的名称映射，如{'China' : '中国'}
	 * @param nameMap
	 */
	public void setNameMap(NameMap nameMap) {
		this.nameMap = nameMap;
	}
	public TextFixed getTextFixed() {
		return textFixed;
	}
	/**
	 * 地区的名称文本位置修正，数值单位为px，正值为左下偏移，负值为右上偏移，如{'China' : [10, -10]}
	 * @param textFixed
	 */
	public void setTextFixed(TextFixed textFixed) {
		this.textFixed = textFixed;
	}
	public GeoCoord getGeoCoord() {
		return geoCoord;
	}
	/**
	 * 通过绝对经纬度指定地区的名称文本位置，如{'Islands':[113.95, 22.26]}，香港离岛区名称显示定位到东经113.95，北纬22.26上
	 * @param geoCoord
	 */
	public void setGeoCoord(GeoCoord geoCoord) {
		this.geoCoord = geoCoord;
	}
	public Heatmap getHeatmap() {
		return heatmap;
	}
	/**
	 * 叠加在地图上的热力图，数据位置为经纬度。配置同 series（热力图）
	 * @param heatmap
	 */
	public void setHeatmap(Heatmap heatmap) {
		this.heatmap = heatmap;
	}

	private NameMap nameMap;
	private	String selectedMode;
	private	String mapType;
	private	String mapValueCalculation;
	private	String roam;
	private	boolean hoverable;
	private	boolean dataRangeHoverLink;
	private	boolean showLegendSymbol;
	private	Number mapValuePrecision;
	private MapLocation mapLocation;
	private ScaleLimit scaleLimit;
	private TextFixed textFixed;
	private GeoCoord geoCoord;
	private Heatmap heatmap;
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class Mark {
	private boolean show;
	private LineStyle lineStyle;

	public boolean isShow() {
		return show;
	}

	public void setShow(boolean show) {
		this.show = show;
	}

	public LineStyle getLineStyle() {
		return lineStyle;
	}

	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}

}

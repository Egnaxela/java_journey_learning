package com.rongji.dfish.ui.plugins.echarts.json;

public class MarkItem extends Item{
public Double getX() {
	return x;
}
public void setX(Double x) {
	this.x = x;
}
public Double getY() {
	return y;
}
public void setY(Double y) {
	this.y = y;
}
public Double getxAxis() {
	return xAxis;
}
public void setxAxis(Double xAxis) {
	this.xAxis = xAxis;
}
public Double getyAxis() {
	return yAxis;
}
public void setyAxis(Double yAxis) {
	this.yAxis = yAxis;
}
private Double x;
private Double y;
private Double xAxis;
private Double yAxis;
}

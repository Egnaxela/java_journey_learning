package com.rongji.dfish.ui.plugins.echarts.json;

import java.util.List;

public class MarkPoint {
private boolean clickable;
public boolean isClickable() {
	return clickable;
}
/**
 * 数据图形是否可点击，默认开启，如果没有click事件响应可以关闭
 * @param clickable
 */
public void setClickable(boolean clickable) {
	this.clickable = clickable;
}
public String[] getSymbol() {
	return symbol;
}
/**
 * 标注类型，同series中的symbol
 * @param symbol
 */
public void setSymbol(String[] symbol) {
	this.symbol = symbol;
}
public Double[] getSymbolSize() {
	return symbolSize;
}
/**
 * 标注大小，同series中的symbolSize
 * @param symbolSize
 */
public void setSymbolSize(Double[] symbolSize) {
	this.symbolSize = symbolSize;
}
public Double[] getSymbolRotate() {
	return symbolRotate;
}
/**
 * 标注图形旋转角度，同series中的symbolRotate
 * @param symbolRotate
 */
public void setSymbolRotate(Double[] symbolRotate) {
	this.symbolRotate = symbolRotate;
}
public boolean isLarge() {
	return large;
}
/**
 * 是否启动大规模标注模式
 * @param large
 */
public void setLarge(boolean large) {
	this.large = large;
}

public Effect getEffect() {
	return effect;
}
/**
 * 标注图形炫光特效: 
show 是否开启，默认关闭 
type 特效类型，默认为'scale'（放大），可选还有'bounce'（跳动） 
loop 循环动画，默认开启, 
period 运动周期，无单位，值越大越慢，默认为15 
scaleSize 放大倍数，以markPoint symbolSize为基准，type为scale时有效 
bounceDistance 跳动距离，单位为px，type为bounce时有效 
color 炫光颜色，默认跟随markPoint itemStyle定义颜色, 
shadowColor 光影颜色，默认跟随color 
shadowBlur 光影模糊度，默认为0 
 * @param effect
 */
public void setEffect(Effect effect) {
	this.effect = effect;
}
public ItemStyle getItemStyle() {
	return itemStyle;
}
/**
 * 标注图形样式属性，同series中的itemStyle
 * @param itemStyle
 */
public void setItemStyle(ItemStyle itemStyle) {
	this.itemStyle = itemStyle;
}
public Object getData() {
	return data;
}
public void setData(Object data) {
	this.data = data;
}
/**
 * 标注图形数据，可能的类型如下:
data : [
    {name: '标注1', value: 100, x: 50, y: 20},
    {name: '标注2', value: 200, x: 150, y: 120},
    ...
]
data : [
    {name: '标注1', value: 100, xAxis: 1, yAxis: 20},      // 当xAxis为类目轴时，数值1会被理解为类目轴的index
    {name: '标注2', value: 100, xAxis: '周三', yAxis: 20}, // 当xAxis为类目轴时，字符串'周三'会被理解为与类目轴的文本进行匹配
    {name: '标注3', value: 200, xAxis: 10, yAxis: 20},     // 当xAxis或yAxis为数值轴时，不管传入是什么，都被理解为数值后做空间位置换算
    ...
]
data : [
    {type : 'max', name: '自定义名字'},    // 最大值
    {type : 'min', name: '自定义名字'}     // 最小值
]
data : [
    {name: '北京', value: 100},
    {name: '上海', value: 200},
    ...
],
geoCoord : {
    "北京":[116.46,39.92],           // 支持数组[经度，维度]
    "上海": {x: 121.48, y: 31.22},   // 支持对象{x:经度,y:纬度}
    ...
}
 * @param data
 */
public void setData(List<?> data) {
	this.data = data;
}
private String[] symbol;
private Double[] symbolSize;
private Double[] symbolRotate;
private boolean large;
private Effect effect;
private ItemStyle itemStyle;
private Object data;
}

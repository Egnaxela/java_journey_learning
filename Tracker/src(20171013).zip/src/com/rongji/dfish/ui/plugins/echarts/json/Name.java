package com.rongji.dfish.ui.plugins.echarts.json;

public class Name {
	private boolean show;
	private String formatter;
	private TextStyle TextStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，默认为true，设为false后下面都没意义了
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public String getFormatter() {
		return formatter;
	}
	
	/**
	 * 文本格式器：{string}（Template） | {Function}，模板变量为'{name}'，函数回调参数为name
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	public TextStyle getTextStyle() {
		return TextStyle;
	}
	
	/**
	 * 文本样式（详见textStyle
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		TextStyle = textStyle;
	}
	

}

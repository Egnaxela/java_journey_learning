package com.rongji.dfish.ui.plugins.echarts.json;


public class NameMap {

	public String getKey() {
		return key;
	}
	/**
	 * 自定义地区对应的键
	 * @param key
	 */
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	/**
	 * 自定义地区对应的值
	 * @param value
	 */
	public void setValue(String value) {
		this.value = value;
	}
	private String key;
	private String value;
}

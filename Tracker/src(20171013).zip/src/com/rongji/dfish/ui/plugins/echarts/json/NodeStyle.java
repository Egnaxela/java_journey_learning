package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 力导向图中的节点样式
 * 
 */
public class NodeStyle {
	private String color;
	private String borderColor;
	private Number borderWidth;
	
	public NodeStyle() {
	}
	
	public NodeStyle(String color, String borderColor, Double borderWidth) {
		super();
		this.color = color;
		this.borderColor = borderColor;
		this.borderWidth = borderWidth;
	}
	/**
	 * 填充颜色
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 描边颜色
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	/**
	 * 描边线宽
	 * @param borderWidth
	 */
	public void setBorderWidth(Number borderWidth) {
		this.borderWidth = borderWidth;
	}
	
	public String getColor() {
		return color;
	}
	public String getBorderColor() {
		return borderColor;
	}
	public Number getBorderWidth() {
		return borderWidth;
	}
}

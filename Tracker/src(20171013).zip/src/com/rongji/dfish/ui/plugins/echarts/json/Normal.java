package com.rongji.dfish.ui.plugins.echarts.json;

public class Normal {
	private String color;
	private LineStyle lineStyle;
	private AreaStyle areaStyle;
	private ChordStyle chordStyle;
	private NodeStyle nodeStyle;
	private LinkStyle linkStyle;
	private String borderColor;
	private Double borderWidth;
	private String barBorderColor;
	private Double[] barBorderRadius;
	private Double barBorderWidth;
	private Label label;
	private LabelLine labelLine;
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}
	public AreaStyle getAreaStyle() {
		return areaStyle;
	}
	public void setAreaStyle(AreaStyle areaStyle) {
		this.areaStyle = areaStyle;
	}
	public ChordStyle getChordStyle() {
		return chordStyle;
	}
	public void setChordStyle(ChordStyle chordStyle) {
		this.chordStyle = chordStyle;
	}
	public NodeStyle getNodeStyle() {
		return nodeStyle;
	}
	public void setNodeStyle(NodeStyle nodeStyle) {
		this.nodeStyle = nodeStyle;
	}
	public LinkStyle getLinkStyle() {
		return linkStyle;
	}
	public void setLinkStyle(LinkStyle linkStyle) {
		this.linkStyle = linkStyle;
	}
	public String getBorderColor() {
		return borderColor;
	}
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public Double getBorderWidth() {
		return borderWidth;
	}
	public void setBorderWidth(Double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public String getBarBorderColor() {
		return barBorderColor;
	}
	public void setBarBorderColor(String barBorderColor) {
		this.barBorderColor = barBorderColor;
	}
	public Double[] getBarBorderRadius() {
		return barBorderRadius;
	}
	public void setBarBorderRadius(Double[] barBorderRadius) {
		this.barBorderRadius = barBorderRadius;
	}
	public Double getBarBorderWidth() {
		return barBorderWidth;
	}
	public void setBarBorderWidth(Double barBorderWidth) {
		this.barBorderWidth = barBorderWidth;
	}
	public Label getLabel() {
		return label;
	}
	public void setLabel(Label label) {
		this.label = label;
	}
	public LabelLine getLabelLine() {
		return labelLine;
	}
	public void setLabelLine(LabelLine labelLine) {
		this.labelLine = labelLine;
	}
	
}

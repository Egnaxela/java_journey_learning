package com.rongji.dfish.ui.plugins.echarts.json;

public class Option {
	private String backgroundColor;
	private String[] color;
	private Boolean renderAsImage;
	private Boolean calculable;
	private Boolean animation;
	private Timeline timeline;
	private Title title;
	private Toolbox toolbox;
	private Tooltip tooltip;
	private Legend legend;
	private DataRange dataRange;
	private DataZoom dataZoom;
	private RoamController roamController;
	private Grid grid;
	private XAxis[] xAxis;
	private YAxis[] yAxis;
	private Series[] series;

	public String getBackgroundColor() {
		return backgroundColor;
	}

	/**
	 * 全图默认背景，（详见backgroundColor），支持rgba，默认为无，透明
	 * 
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public String[] getColor() {
		return color;
	}

	/**
	 * 数值系列的颜色列表，（详见color），可配数组，eg：['#87cefa',
	 * 'rgba(123,123,123,0.5)','...']，当系列数量个数比颜色列表长度大时将循环选取
	 * 
	 * @param color
	 */
	public void setColor(String[] color) {
		this.color = color;
	}

	public Boolean isRenderAsImage() {
		return renderAsImage;
	}

	/**
	 * 非IE8-支持渲染为图片，（详见renderAsImage）
	 * 
	 * @param renderAsImage
	 */
	public void setRenderAsImage(Boolean renderAsImage) {
		this.renderAsImage = renderAsImage;
	}

	public Boolean isCalculable() {
		return calculable;
	}

	/**
	 * 是否启用拖拽重计算特性，默认关闭，（详见calculable，相关的还有 calculableColor，
	 * calculableHolderColor， nameConnector， valueConnector）
	 * 
	 * @param calculable
	 */
	public void setCalculable(Boolean calculable) {
		this.calculable = calculable;
	}

	public Boolean isAnimation() {
		return animation;
	}

	/**
	 * 是否开启动画，默认开启，（详见 animation，相关的还有 addDataAnimation， animationThreshold，
	 * animationDuration， animationDurationUpdate ， animationEasing）
	 * 
	 * @param animation
	 */
	public void setAnimation(Boolean animation) {
		this.animation = animation;
	}

	public Timeline getTimeline() {
		return timeline;
	}

	/**
	 * 时间轴（详见timeline），每个图表最多仅有一个时间轴控件
	 * 
	 * @param timeline
	 */
	public void setTimeline(Timeline timeline) {
		this.timeline = timeline;
	}

	public Title getTitle() {
		return title;
	}

	/**
	 * 标题（详见title），每个图表最多仅有一个标题控件
	 * 
	 * @param title
	 */
	public void setTitle(Title title) {
		this.title = title;
	}

	public Toolbox getToolbox() {
		return toolbox;
	}

	/**
	 * 工具箱（详见toolbox），每个图表最多仅有一个工具箱
	 * 
	 * @param toolbox
	 */
	public void setToolbox(Toolbox toolbox) {
		this.toolbox = toolbox;
	}

	public Tooltip getTooltip() {
		return tooltip;
	}

	/**
	 * 提示框（详见tooltip），鼠标悬浮交互时的信息提示
	 * 
	 * @param tooltip
	 */
	public void setTooltip(Tooltip tooltip) {
		this.tooltip = tooltip;
	}

	public Legend getLegend() {
		return legend;
	}

	/**
	 * 图例（详见legend），每个图表最多仅有一个图例，混搭图表共享
	 * 
	 * @param legend
	 */
	public void setLegend(Legend legend) {
		this.legend = legend;
	}

	public DataRange getDataRange() {
		return dataRange;
	}

	/**
	 * 值域选择（详见dataRange）,值域范围
	 * 
	 * @param dataRange
	 */
	public void setDataRange(DataRange dataRange) {
		this.dataRange = dataRange;
	}

	public DataZoom getDataZoom() {
		return dataZoom;
	}

	/**
	 * 数据区域缩放（详见dataZoom）,数据展现范围选择
	 * 
	 * @param dataZoom
	 */
	public void setDataZoom(DataZoom dataZoom) {
		this.dataZoom = dataZoom;
	}

	public RoamController getRoamController() {
		return roamController;
	}

	/**
	 * 漫游缩放组件（详见roamController）,搭配地图使用
	 * 
	 * @param roamController
	 */
	public void setRoamController(RoamController roamController) {
		this.roamController = roamController;
	}

	public Grid getGrid() {
		return grid;
	}

	/**
	 * 直角坐标系内绘图网格（详见grid）
	 * 
	 * @param grid
	 */
	public void setGrid(Grid grid) {
		this.grid = grid;
	}

	public XAxis[] getxAxis() {
		return xAxis;
	}

	/**
	 * 直角坐标系中横轴数组（详见xAxis），数组中每一项代表一条横轴坐标轴，标准（1.0）中规定最多同时存在2条横轴
	 * 
	 * @param xAxis
	 */
	public void setxAxis(XAxis[] xAxis) {
		int maxCount = 2;
		if (xAxis != null && xAxis.length > maxCount) {
			throw new UnsupportedOperationException("横轴不能超过" + maxCount + "条");
		}
		this.xAxis = xAxis;
	}

	public YAxis[] getyAxis() {
		return yAxis;
	}

	/**
	 * 直角坐标系中纵轴数组（详见yAxis），数组中每一项代表一条纵轴坐标轴，标准（1.0）中规定最多同时存在2条纵轴
	 *
	 * @param yAxis
	 */
	public void setyAxis(YAxis[] yAxis) {
		int maxCount = 2;
		if (yAxis != null && yAxis.length > maxCount) {
			throw new UnsupportedOperationException("纵轴不能超过" + maxCount + "条");
		}
		this.yAxis = yAxis;
	}

	public Series[] getSeries() {
		return series;
	}

	/**
	 * 驱动图表生成的数据内容（详见series），数组中每一项代表一个系列的特殊选项及数据
	 * 
	 * @param series
	 */
	public void setSeries(Series[] series) {
		this.series = series;
	}

}

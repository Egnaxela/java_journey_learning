package com.rongji.dfish.ui.plugins.echarts.json;

public class PieSeries extends Series{
public Object[] getCenter() {
	return center;
}
/**
 * 圆心坐标，支持绝对值（px）和百分比，百分比计算min(width, height) * 50%
 * @param center
 */
public void setCenter(Object[] center) {
	this.center = center;
}
public Object[] getRadius() {
	return radius;
}
/**
 * 半径，支持绝对值（px）和百分比，百分比计算比，min(width, height) / 2 * 75%， 传数组实现环形图，[内半径，外半径]
 * @param radius
 */
public void setRadius(Object[] radius) {
	this.radius = radius;
}
public Number getStartAngle() {
	return startAngle;
}
/**
 * 开始角度, 饼图（90）、仪表盘（225），有效输入范围：[-360,360]
 * @param startAngle
 */
public void setStartAngle(Number startAngle) {
	this.startAngle = startAngle;
}
public Number getMinAngle() {
	return minAngle;
}
/**
 * 最小角度，可用于防止某item的值过小而影响交互
 * @param minAngle
 */
public void setMinAngle(Number minAngle) {
	this.minAngle = minAngle;
}
public Boolean isClockWise() {
	return clockWise;
}
/**
 * 显示是否顺时针
 * @param clockWise
 */
public void setClockWise(Boolean clockWise) {
	this.clockWise = clockWise;
}
public String getRoseType() {
	return roseType;
}
/**
 * 南丁格尔玫瑰图模式，'radius'（半径） | 'area'（面积）
 * @param roseType
 */
public void setRoseType(String roseType) {
	this.roseType = roseType;
}
public Number getSelectedOffset() {
	return selectedOffset;
}
/**
 * 选中是扇区偏移量
 * @param selectedOffset
 */
public void setSelectedOffset(Number selectedOffset) {
	this.selectedOffset = selectedOffset;
}
public Object getSelectedMode() {
	return selectedMode;
}
/**
 * 选中模式，默认关闭，可选single，multiple
 * @param selectedMode
 */
public void setSelectedMode(String selectedMode) {
	this.selectedMode = selectedMode;
}
public Boolean isLegendHoverLink() {
	return legendHoverLink;
}
/**
 * 
 * @param legendHoverLink
 */
public void setLegendHoverLink(Boolean legendHoverLink) {
	this.legendHoverLink = legendHoverLink;
}
private Object[] center;
private Object[] radius;
private Number startAngle;
private Number minAngle;
private Boolean clockWise;
private String roseType;
private Number selectedOffset;
public static final String SELECTED_MODE_SINGLE="single";
public static final String SELECTED_MODE_MULTIPLE="multiple";
private Object selectedMode;
private Boolean legendHoverLink;
}

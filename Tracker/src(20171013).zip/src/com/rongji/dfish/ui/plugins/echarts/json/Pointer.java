package com.rongji.dfish.ui.plugins.echarts.json;

public class Pointer {
public String getLength() {
		return length;
	}
	/**
	 * 属性length控制线长，如'8%'百分比相对的是仪表盘的外半径 
	 * @param length
	 */
	public void setLength(String length) {
		this.length = length;
	}
	public Double getWidth() {
		return width;
	}
	/**
	 * 属性width控制指针最宽处， 
	 * @param width
	 */
	public void setWidth(Double width) {
		this.width = width;
	}
	public String getColor() {
		return color;
	}
	/**
	 * 属性color控制指针颜色如'auto'
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
private String length;
private Double width;
private String color;
}

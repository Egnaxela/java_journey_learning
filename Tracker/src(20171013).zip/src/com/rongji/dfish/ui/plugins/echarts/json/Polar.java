package com.rongji.dfish.ui.plugins.echarts.json;

public class Polar {
	private double zlevel;
	private double z;
	private double[] center;
	private double radius;
	private double startAngle;
	private double splitNumber;
	private Name name; 
	private double[] boundaryGap;
	private boolean scale;
	private AxisLine axisLine;
	private AxisLabel axisLabel;
	private SplitLine splitLine;
	private SplitArea splitArea;
	private String type;
	private String[] indicator;
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public double[] getCenter() {
		return center;
	}
	
	/**
	 * 圆心坐标，支持绝对值（px）和百分比，百分比计算min(width, height) * 50%
	 * @param center
	 */
	public void setCenter(double[] center) {
		this.center = center;
	}
	public double getRadius() {
		return radius;
	}
	
	/**
	 * 半径，支持绝对值（px）和百分比，百分比计算min(width, height) / 2 * 75%,
	 * @param radius
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getStartAngle() {
		return startAngle;
	}
	
	/**
	 * 开始角度, 有效输入范围：[-180,180]
	 * @param startAngle
	 */
	public void setStartAngle(double startAngle) {
		this.startAngle = startAngle;
	}
	public double getSplitNumber() {
		return splitNumber;
	}
	
	/**
	 * 分割段数，默认为5
	 * @param splitNumber
	 */
	public void setSplitNumber(double splitNumber) {
		this.splitNumber = splitNumber;
	}
	public Name getName() {
		return name;
	}
	
	/**
	 * 坐标轴名称(详情请看Name)
	 * @param name
	 */
	public void setName(Name name) {
		this.name = name;
	}
	public double[] getBoundaryGap() {
		return boundaryGap;
	}
	
	/**
	 * 数值轴两端空白策略，数组内数值代表百分比，[原始数据最小值与最终最小值之间的差额，原始数据最大值与最终最大值之间的差额]
	 * @param boundaryGap
	 */
	public void setBoundaryGap(double[] boundaryGap) {
		this.boundaryGap = boundaryGap;
	}
	public boolean isScale() {
		return scale;
	}
	
	/**
	 * 脱离0值比例，放大聚焦到最终_min，_max区间
	 * @param scale
	 */
	public void setScale(boolean scale) {
		this.scale = scale;
	}
	public AxisLine getAxisLine() {
		return axisLine;
	}
	
	/**
	 * 坐标轴线，默认显示，属性show控制显示与否，属性lineStyle（详见lineStyle）控制线条样式
	 * @param axisLine
	 */
	public void setAxisLine(AxisLine axisLine) {
		this.axisLine = axisLine;
	}
	public AxisLabel getAxisLabel() {
		return axisLabel;
	}
	
	/**
	 * 坐标轴文本标签，详见axis.axisLabel
	 * @param axisLabel
	 */
	public void setAxisLabel(AxisLabel axisLabel) {
		this.axisLabel = axisLabel;
	}
	public SplitLine getSplitLine() {
		return splitLine;
	}
	
	/**
	 * 分隔线，默认显示，属性show控制显示与否，属性lineStyle（详见lineStyle）控制线条样式
	 * @param splitLine
	 */
	public void setSplitLine(SplitLine splitLine) {
		this.splitLine = splitLine;
	}
	public SplitArea getSplitArea() {
		return splitArea;
	}
	
	/**
	 * 分隔区域，默认不显示，属性show控制显示与否，属性areaStyle（详见areaStyle）控制区域样式
	 * @param splitArea
	 */
	public void setSplitArea(SplitArea splitArea) {
		this.splitArea = splitArea;
	}
	public String getType() {
		return type;
	}
	
	/**
	 * 极坐标的形状，'polygon'|'circle' 多边形|圆形
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	public String[] getIndicator() {
		return indicator;
	}
	
	/**
	 * 雷达指标列表，同时也是label内容，例子见下
	 * indicator : [
        {text : '外观'},
        {text : '拍照', min : 0},
       {text : '系统', min : 0, max : 100},
       {text : '性能', axisLabel: {...}},
       {text : '屏幕'}
    ]
	 * @param indicator
	 */
	public void setIndicator(String[] indicator) {
		this.indicator = indicator;
	}
	
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class RadarSeries extends Series{
public Number getPolarIndex() {
	return polarIndex;
}
/**
 * 极坐标索引
 * @param polarIndex
 */
public void setPolarIndex(Number polarIndex) {
	this.polarIndex = polarIndex;
}
public String getSymbol() {
	return symbol;
}
/**
 * 同series（直角系）
 * @param symbol
 */
public void setSymbol(String symbol) {
	this.symbol = symbol;
}
public Double[] getSymbolSize() {
	return symbolSize;
}
/**
 * 同series（直角系）
 * @param symbolSize
 */
public void setSymbolSize(Double[] symbolSize) {
	this.symbolSize = symbolSize;
}
public Number getSymbolRotate() {
	return symbolRotate;
}
/**
 * 同series（直角系）
 * @param symbolRotate
 */
public void setSymbolRotate(Number symbolRotate) {
	this.symbolRotate = symbolRotate;
}
public boolean isLegendHoverLink() {
	return legendHoverLink;
}
/**
 * 是否启用图例（legend）hover时的联动响应（高亮显示）
 * @param legendHoverLink
 */
public void setLegendHoverLink(boolean legendHoverLink) {
	this.legendHoverLink = legendHoverLink;
}
private	Number polarIndex;
private String symbol;
private Double[] symbolSize;
private Number symbolRotate;
private boolean legendHoverLink;

}

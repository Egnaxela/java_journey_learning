package com.rongji.dfish.ui.plugins.echarts.json;

public class Range {
	private double start;
	private double end;
	public double getStart() {
		return start;
	}
	
	/**
	 * 数据缩放，选择结束比例，默认为100（%），到最后一个数据选择结束。
	 * @param start
	 */
	public void setStart(double start) {
		this.start = start;
	}
	public double getEnd() {
		return end;
	}
	
	/**
	 * 数据缩放，选择起始比例，默认为0（%），从首个数据起选择。
	 * @param end
	 */
	public void setEnd(double end) {
		this.end = end;
	}
	

}

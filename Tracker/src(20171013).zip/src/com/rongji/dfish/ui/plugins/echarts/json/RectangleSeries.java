package com.rongji.dfish.ui.plugins.echarts.json;

public class RectangleSeries extends Series{
public String[] getCenter() {
	return center;
}
/**
 * 中心坐标，支持绝对值（px）和百分比
 * @param center
 */
public void setCenter(String[] center) {
	this.center = center;
}
public String[] getSize() {
	return size;
}
/**
 * 大小，支持绝对值（px）和百分比
 * @param size
 */
public void setSize(String[] size) {
	this.size = size;
}
public String getRoot() {
	return root;
}
/**
 * 当前显示的根节点的名字
 * @param root
 */
public void setRoot(String root) {
	this.root = root;
}
private String[] center;
private String[] size;
private String root;
}

package com.rongji.dfish.ui.plugins.echarts.json;

import java.util.Map;

public class RoamController {
	private boolean show;
	private double zlevel;
	private double z;
	private String x;
	private String y;
	private double Width;
	private double height;
	private String backgroundColor;
	private String borderColor;
	private double borderWidth;
	private double padding;
	private String fillerColor;
	private String handleColor;
	private double step;
	private Map mapTypeControl;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）。
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public double getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 */
	public void setZlevel(double zlevel) {
		this.zlevel = zlevel;
	}
	public double getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	public String getX() {
		return x;
	}
	
	/**
	 * 水平安放位置，默认为左侧，可选为：'center' | 'left' | 'right' | {number}（x坐标，单位px）
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	
	/**
	 * 垂直安放位置，默认为全图顶端，可选为：'top' | 'bottom' | 'center' | {number}（y坐标，单位px）
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
	public double getWidth() {
		return Width;
	}
	
	/**
	 * 指定宽度，决定4向漫游圆盘大小，可指定 {number}（宽度，单位px）
	 * @param width
	 */
	public void setWidth(double width) {
		Width = width;
	}
	public double getHeight() {
		return height;
	}
	
	/**
	 * 指定高度，缩放控制键默认会在指定高度的最下方最大化显示，可指定 {number}（高度，单位px）
	 * @param height
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 缩放漫游组件背景颜色，默认透明
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 缩放漫游组件边框颜色
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public double getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 缩放漫游组件边框线宽，单位px，默认为0（无边框）
	 * @param borderWidth
	 */
	public void setBorderWidth(double borderWidth) {
		this.borderWidth = borderWidth;
	}
	public double getPadding() {
		return padding;
	}
	
	/**
	 * 缩放漫游组件内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css，见下图
	 * @param padding
	 */
	public void setPadding(double padding) {
		this.padding = padding;
	}
	public String getFillerColor() {
		return fillerColor;
	}
	
	/**
	 * 漫游组件文字填充颜色
	 * @param fillerColor
	 */
	public void setFillerColor(String fillerColor) {
		this.fillerColor = fillerColor;
	}
	public String getHandleColor() {
		return handleColor;
	}
	
	/**
	 * 控制手柄主体颜色
	 * @param handleColor
	 */
	public void setHandleColor(String handleColor) {
		this.handleColor = handleColor;
	}
	public double getStep() {
		return step;
	}
	
	/**
	 * 4向漫游移动步伐，单位px
	 * @param step
	 */
	public void setStep(double step) {
		this.step = step;
	}
	
	public Map getMapTypeControl() {
		return mapTypeControl;
	}
	
	/**必须，指定漫游组件可控地图类型，如：{ china: true }
	 * 当同一图表内同时呈现多个地图时，可以单独指定所需控制地图类型，如：{ china: false, '北京': true}
	 * @param mapTypeControl
	 */
	public void setMapTypeControl(Map mapTypeControl) {
		this.mapTypeControl = mapTypeControl;
	}
	

}

package com.rongji.dfish.ui.plugins.echarts.json;

public class RootLocation {
public String getX() {
		return x;
	}
	/**
	 * 根节点坐标x，支持绝对值（px）、字符和百分比: 'center' | 'left' | 'right' | 'x%' | {number},
	 * @param x
	 */
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	/**
	 * 根节点坐标y，支持绝对值（px）、字符和百分比: 'center' | 'top' | 'bottom' | 'y%' | {number}
	 * @param y
	 */
	public void setY(String y) {
		this.y = y;
	}
private String x;
private String y;
}

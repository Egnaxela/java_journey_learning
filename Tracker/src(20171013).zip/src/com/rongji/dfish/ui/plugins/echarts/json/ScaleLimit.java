package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 滚轮缩放的极限控制，可指定{max:number, min:number}，其中max为放大系数，有效值应大于1，min为缩小系数，有效值应小于1
 * @author Administrator
 *
 */
public class ScaleLimit {
public Double getMax() {
		return max;
	}
	/**
	 * max为放大系数，有效值应大于1
	 * @param max
	 */
	public void setMax(Double max) {
		this.max = max;
	}
	public Double getMin() {
		return min;
	}
	/**
	 * min为缩小系数，有效值应小于1
	 * @param min
	 */
	public void setMin(Double min) {
		this.min = min;
	}
private Double max;
private Double min;
}

package com.rongji.dfish.ui.plugins.echarts.json;

import java.util.List;

public class Series {
	
	/**
	 * 折线图
	 */
	public static final String TYPE_LINE = "line";
	/**
	 * 柱状图
	 */
	public static final String TYPE_BAR = "bar";
	/**
	 * 散点图
	 */
	public static final String TYPE_SCATTER = "scatter";
	/**
	 * K线图
	 */
	public static final String TYPE_K = "k";
	/**
	 * 饼图
	 */
	public static final String TYPE_PIE = "pie";
	/**
	 * 雷达图
	 */
	public static final String TYPE_RADAR = "radar";
	/**
	 * 和弦图
	 */
	public static final String TYPE_CHORD = "chord";
	/**
	 * 力导向布局图
	 */
	public static final String TYPE_FORCE = "force";
	/**
	 * 地图
	 */
	public static final String TYPE_MAP = "map";
	
	private Number zlevel;
	private Number z;
	private String type;
	private String name;
	private Tooltip tooltip;
	private Boolean clickable;
	private ItemStyle itemStyle;
	private Object[] data;
	private MarkPoint markPoint;
	private MarkLine markLine;
	// FIXME 这个属性文档中没出现,但是在json数据中看见,是否保留待研究
	private String stack;
	
	public Number getZlevel() {
		return zlevel;
	}
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制
	 * @param zlevel
	 */
	public void setZlevel(Number zlevel) {
		this.zlevel = zlevel;
	}
	public Number getZ() {
		return z;
	}
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(Number z) {
		this.z = z;
	}
	public String getType() {
		return type;
	}
	/**
	 * 图表类型，必要参数！如为空或不支持类型，则该系列数据不被显示。可选为： 
'line'（折线图） | 'bar'（柱状图） | 'scatter'（散点图） | 'k'（K线图） 
'pie'（饼图） | 'radar'（雷达图） | 'chord'（和弦图） | 'force'（力导向布局图） | 'map'（地图）
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	/**
	 * 系列名称，如启用legend，该值将被legend.data索引相关
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	public Tooltip getTooltip() {
		return tooltip;
	}
	/**
	 * 提示框样式，仅对本系列有效，如不设则用option.tooltip（详见tooltip）,鼠标悬浮交互时的信息提示
	 * @param tooltip
	 */
	public void setTooltip(Tooltip tooltip) {
		this.tooltip = tooltip;
	}
	public Boolean isClickable() {
		return clickable;
	}
	/**
	 * 数据图形是否可点击，默认开启，如果没有click事件响应可以关闭
	 * @param clickable
	 */
	public void setClickable(Boolean clickable) {
		this.clickable = clickable;
	}
	public ItemStyle getItemStyle() {
		return itemStyle;
	}
	/**
	 * 图形样式（详见itemStyle）
	 * @param itemStyle
	 */
	public void setItemStyle(ItemStyle itemStyle) {
		this.itemStyle = itemStyle;
	}
	public Object[] getData() {
		return data;
	}
	/**
	 * 数据（详见series.data）
	 * @param data
	 */
	/**
	 * 可能的格式如下：
data：[12, 34, 56, ..., 10, 23]
data：[12, '-', 56, ..., 10, 23]
 data：[
    12, 34,
    {
        value : 56,
        tooltip:{},             //自定义特殊tooltip，仅对该item有效，详见tooltip
        itemStyle:{}            //自定义特殊itemStyle，仅对该item有效，详见itemStyle
    },
    ..., 10, 23
	]
data：[
    {
        value : [10, 25, 5]     //[xValue, yValue, rValue]，数组内依次为横值，纵值，大小(可选)
    },
    [12, 15, 1]
    ...
]
data：[
    {
        value : [2190.1, 2148.35, 2126.22, 2190.1] // // 开盘，收盘，最低，最高
    },
    [2242.26, 2210.9, 2205.07, 2250.63],
    ...
]
data：[
    {
        value : 12，
        name : 'apple'          //每部分数据的名称
    },
    ...
]
data：[
    {
        name: '北京',
        value: 1234,
        selected: true
    },
    {
        name: '天津',
        value: 321
    },
    ...
]
	 * @param data
	 */
	public void setData(Object[] data) {
		this.data = data;
	}
	public MarkPoint getMarkPoint() {
		return markPoint;
	}
	/**
	 * 标注（详见series.markPoint）
	 * @param markPoint
	 */
	public void setMarkPoint(MarkPoint markPoint) {
		this.markPoint = markPoint;
	}
	public MarkLine getMarkLine() {
		return markLine;
	}
	/**
	 * 标线（详见series.markLine）
	 * @param markLine
	 */
	public void setMarkLine(MarkLine markLine) {
		this.markLine = markLine;
	}
	public String getStack() {
		return stack;
	}
	public void setStack(String stack) {
		this.stack = stack;
	}
}

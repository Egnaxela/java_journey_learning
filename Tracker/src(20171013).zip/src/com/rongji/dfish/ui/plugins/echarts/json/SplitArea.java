package com.rongji.dfish.ui.plugins.echarts.json;

public class SplitArea {
	private boolean show;
	private boolean onGap;
	private AreaStyle areaStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，默认为false，设为true后带如下默认样式
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public boolean isOnGap() {
		return onGap;
	}
	
	/**
	 * 分隔区域是否显示为间隔，默认等于boundaryGap
	 * @param onGap
	 */
	public void setOnGap(boolean onGap) {
		this.onGap = onGap;
	}
	public AreaStyle getAreaStyle() {
		return areaStyle;
	}
	
	/**
	 * 属性areaStyle（详见areaStyle）控制区域样式，颜色数组实现间隔变换。
	 * @param areaStyle
	 */
	public void setAreaStyle(AreaStyle areaStyle) {
		this.areaStyle = areaStyle;
	}
  

}

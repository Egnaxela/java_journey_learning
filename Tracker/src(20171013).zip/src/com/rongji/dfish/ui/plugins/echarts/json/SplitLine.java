package com.rongji.dfish.ui.plugins.echarts.json;

public class SplitLine {
	private boolean show;
	private boolean onGap;
	private LineStyle lineStyle;
	public boolean isShow() {
		return show;
	}
	
	/**
	 * 是否显示，默认为true，设为false后下面都没意义了
	 * @param show
	 */
	public void setShow(boolean show) {
		this.show = show;
	}
	public boolean isOnGap() {
		return onGap;
	}
	
	/**
	 * 分隔线是否显示为间隔，默认等于boundaryGap
	 * @param onGap
	 */
	public void setOnGap(boolean onGap) {
		this.onGap = onGap;
	}
	public LineStyle getLineStyle() {
		return lineStyle;
	}
	
	/**
	 * 属性lineStyle控制线条样式，（详见lineStyle）
	 * @param lineStyle
	 */
	public void setLineStyle(LineStyle lineStyle) {
		this.lineStyle = lineStyle;
	}

}

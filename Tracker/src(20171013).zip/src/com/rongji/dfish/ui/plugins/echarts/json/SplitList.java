package com.rongji.dfish.ui.plugins.echarts.json;

public class SplitList {
	
	private double start;
	private double end;
	private String label;
	private String color;
	public double getStart() {
		return start;
	}
	
	/**
	 * 本项的数据范围起点（>=），如果不设置表示负无穷
	 * @param start
	 */
	public void setStart(double start) {
		this.start = start;
	}
	public double getEnd() {
		return end;
	}
	
	/**
	 * 本项的数据范围终点（<=），如果不设置表示正无穷。
	 * @param end
	 */
	public void setEnd(double end) {
		this.end = end;
	}
	public String getLabel() {
		return label;
	}
	
	/**
	 * 项的显示标签，缺省则自动生成label 
	 * @param label
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	public String getColor() {
		return color;
	}
	
	/**
	 * 本项的颜色，缺省则自动计算color 
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	
	

}

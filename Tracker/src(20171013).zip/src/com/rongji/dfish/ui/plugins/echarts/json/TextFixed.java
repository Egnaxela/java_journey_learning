package com.rongji.dfish.ui.plugins.echarts.json;
/**
 * 地区的名称文本位置修正，数值单位为px，正值为左下偏移，负值为右上偏移，如{'China' : [10, -10]}
 * @author Administrator
 *
 */
public class TextFixed {
public String getName() {
		return name;
	}
	/**
	 * 要修正位置的地区名文本
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	public Double[] getOffset() {
		return offset;
	}
	/**
	 * 偏移量数组，数值单位为px，正值为左下偏移，负值为右上偏移，如{'China' : [10, -10]}
	 * @param offset
	 */
	public void setOffset(Double[] offset) {
		this.offset = offset;
	}
	private String name;
	private Double[] offset;
}

package com.rongji.dfish.ui.plugins.echarts.json;

/**
 * 
 * 文字样式
 * 
 */
public class TextStyle {
	
	/**
	 * 水平对齐方式
	 */
	public static final String ALIGN_LEFT = "left";
	public static final String ALIGN_RIGHT = "right";
	public static final String ALIGN_CENTER = "center";
	
	/**
	 * 垂直对齐方式
	 */
	public static final String BASELINE_TOP = "top";
	public static final String BASELINE_BOTTOM = "bottom";
	public static final String BASELINE_MIDDLE = "middle";
	
	/**
	 * 样式
	 */
	public static final String FONTSTYLE_NORMAL = "normal";
	public static final String FONTSTYLE_ITALIC = "italic";
	public static final String FONTSTYLE_OBLIQUE = "oblique";
	
	/**
	 * 粗细
	 */
	public static final String FONTWEIGHT_NORMAL = "normal";
	public static final String FONTWEIGHT_BOLD = "bold";
	public static final String FONTWEIGHT_BOLDER = "bolder";
	public static final String FONTWEIGHT_LIGHTER = "lighter";
	public static final String FONTWEIGHT_100 = "100";
	public static final String FONTWEIGHT_200 = "200";
	public static final String FONTWEIGHT_300 = "300";
	public static final String FONTWEIGHT_400 = "400";
	public static final String FONTWEIGHT_500 = "500";
	public static final String FONTWEIGHT_600 = "600";
	public static final String FONTWEIGHT_700 = "700";
	public static final String FONTWEIGHT_800 = "800";
	public static final String FONTWEIGHT_900 = "900";
	
	private String color;
	private String decoration;
	private String align;
	private String baseline;
	private String fontFamily;
	private Number fontSize;
	private String fontStyle;
	private String fontWeight;
	
	public TextStyle() {
	}
	
	public TextStyle(String color, String decoration, String align,
			String baseline, String fontFamily, Double fontSize,
			String fontStyle, String fontWeight) {
		super();
		this.color = color;
		this.decoration = decoration;
		this.align = align;
		this.baseline = baseline;
		this.fontFamily = fontFamily;
		this.fontSize = fontSize;
		this.fontStyle = fontStyle;
		this.fontWeight = fontWeight;
	}


	/**
	 * 颜色
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 修饰，仅对tooltip.textStyle生效
	 * @param decoration
	 */
	public void setDecoration(String decoration) {
		this.decoration = decoration;
	}
	/**
	 * 水平对齐方式，可选为：'left' | 'right' | 'center'
	 * @param dalign
	 */
	public void setAlign(String align) {
		this.align = align;
	}
	/**
	 * 垂直对齐方式，可选为：'top' | 'bottom' | 'middle'
	 * @param baseline
	 */
	public void setBaseline(String baseline) {
		this.baseline = baseline;
	}
	/**
	 * 字体系列
	 * @param fontFamily
	 */
	public void setFontFamily(String fontFamily) {
		this.fontFamily = fontFamily;
	}
	/**
	 * 字号 ，单位px
	 * @param fontSize
	 */
	public void setFontSize(Number fontSize) {
		this.fontSize = fontSize;
	}
	/**
	 * 样式，可选为：'normal' | 'italic' | 'oblique'
	 * @param fontStyle
	 */
	public void setFontStyle(String fontStyle) {
		this.fontStyle = fontStyle;
	}
	/**
	 * 粗细，可选为：'normal' | 'bold' | 'bolder' | 'lighter' | 100 | 200 |... | 900
	 * @param fontWeight
	 */
	public void setFontWeight(String fontWeight) {
		this.fontWeight = fontWeight;
	}
	
	public String getColor() {
		return color;
	}
	public String getDecoration() {
		return decoration;
	}
	public String getAlign() {
		return align;
	}
	public String getBaseline() {
		return baseline;
	}
	public String getFontFamily() {
		return fontFamily;
	}
	public Number getFontSize() {
		return fontSize;
	}
	public String getFontStyle() {
		return fontStyle;
	}
	public String getFontWeight() {
		return fontWeight;
	}

}

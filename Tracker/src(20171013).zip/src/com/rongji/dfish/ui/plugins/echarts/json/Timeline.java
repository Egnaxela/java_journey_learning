package com.rongji.dfish.ui.plugins.echarts.json;


public class Timeline {
private boolean show;
private double zlevel;
private double  z;
private String type;
private boolean notMerge;
private boolean realtime;
private double  x;  //可接受数组和字符串型的
private double  y;
private double  x2;
private double  y2;
private double  width;
private double  height;
private String backgroundColor;
private double borderWidth;
private String borderColor;
private double padding;  //可接受数组和number型的
private String controlPosition;
private boolean autoPlay;
private boolean loop;
private double playInterval;
private LineStyle lineStyle;
private Label label;
private CheckPointStyle checkpointStyle;
private ControlStyle ControlStyle;
private String symbol;
private double symbolSize;
private double currentIndex;
private  String[] data;
public boolean isShow() {
	return show;
}

/**
 * 显示策略，可选为：true（显示） | false（隐藏）
 * @param show
 */
public void setShow(boolean show) {
	this.show = show;
}
public double getZlevel() {
	return zlevel;
}

/**
 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
 * @param zlevel
 */
public void setZlevel(double zlevel) {
	this.zlevel = zlevel;
}
public double getZ() {
	return z;
}

/**
 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
 * @param z
 */
public void setZ(double z) {
	this.z = z;
}
public String getType() {
	return type;
}

/**
 * 模式是时间类型，时间轴间隔根据时间跨度自动计算，可选为：'number'
 * @param type
 */
public void setType(String type) {
	this.type = type;
}
public boolean isNotMerge() {
	return notMerge;
}
/**
 * 时间轴上多个option切换时是否进行merge操作，同setOption第二个参数（详见实例方法）
 * @param notMerge
 */
public void setNotMerge(boolean notMerge) {
	this.notMerge = notMerge;
}
public boolean isRealtime() {
	return realtime;
}

/**
 * 拖拽或点击改变时间轴是否实时显示，在不支持Canvas的浏览器中该值自动强制置为false
 * @param realtime
 */
public void setRealtime(boolean realtime) {
	this.realtime = realtime;
}
public double getX() {
	return x;
}

/**
 * 时间轴左上角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
 * @param x
 */
public void setX(double x) {
	this.x = x;
}
public double getY() {
	return y;
}

/**
 * 时间轴左上角纵坐标，数值单位px，支持百分比（字符串），默认无，随y2定位，如'50%'(显示区域纵向中心)
 * @param y
 */
public void setY(double y) {
	this.y = y;
}
public double getX2() {
	return x2;
}

/**
 * 时间轴右下角横坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域横向中心)
 * @param x2
 */
public void setX2(double x2) {
	this.x2 = x2;
}
public double getY2() {
	return y2;
}

/**
 * 时间轴右下角纵坐标，数值单位px，支持百分比（字符串），如'50%'(显示区域纵向中心)
 * @param y2
 */
public void setY2(double y2) {
	this.y2 = y2;
}
public double getWidth() {
	return width;
}

/**
 * 时间轴宽度，默认为总宽度 - x - x2，数值单位px，指定width后将忽略x2。见下图。 
支持百分比（字符串），如'50%'(显示区域一半的宽度)
 * @param width
 */
public void setWidth(double width) {
	this.width = width;
}
public double getHeight() {
	return height;
}

/**
 * 时间轴高度，数值单位px，支持百分比（字符串），如'50%'(显示区域一半的高度)
 * @param height
 */
public void setHeight(double height) {
	this.height = height;
}
public String getBackgroundColor() {
	return backgroundColor;
}

/**
 * 背景颜色，默认透明。
 * @param backgroundColor
 */
public void setBackgroundColor(String backgroundColor) {
	this.backgroundColor = backgroundColor;
}
public double getBorderWidth() {
	return borderWidth;
}

/**
 * 边框线宽
 * @param borderWidth
 */
public void setBorderWidth(double borderWidth) {
	this.borderWidth = borderWidth;
}
public String getBorderColor() {
	return borderColor;
}

/**
 * 边框颜色
 * @param borderColor
 */
public void setBorderColor(String borderColor) {
	this.borderColor = borderColor;
}
public double getPadding() {
	return padding;
}

/**
 * 内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css，见下图
 * @param padding
 */
public void setPadding(double padding) {
	this.padding = padding;
}
public String getControlPosition() {
	return controlPosition;
}

/**
 * 播放控制器位置，可选为：'left' | 'right' | 'none'
 * @param controlPosition
 */
public void setControlPosition(String controlPosition) {
	this.controlPosition = controlPosition;
}
public boolean isAutoPlay() {
	return autoPlay;
}

/**
 * 是否自动播放
 * @param autoPlay
 */
public void setAutoPlay(boolean autoPlay) {
	this.autoPlay = autoPlay;
}
public boolean isLoop() {
	return loop;
}

/**
 * 是否循环播放
 * @param loop
 */
public void setLoop(boolean loop) {
	this.loop = loop;
}
public double getPlayInterval() {
	return playInterval;
}

/**
 * 播放时间间隔，单位ms
 * @param playInterval
 */
public void setPlayInterval(double playInterval) {
	this.playInterval = playInterval;
}
public LineStyle getLineStyle() {
	return lineStyle;
}

/**
 * 时间轴轴线样式，lineStyle控制线条样式，（详见lineStyle）
 * @param lineStyle
 */
public void setLineStyle(LineStyle lineStyle) {
	this.lineStyle = lineStyle;
}
public Label getLabel() {
	return label;
}

/**
 * 时间轴标签文本（详见Label）
 * @param label
 */
public void setLabel(Label label) {
	this.label = label;
}
public CheckPointStyle getCheckpointStyle() {
	return checkpointStyle;
}

/**
 * 时间轴当前点（详见CheckPointStyle）
 * @param checkpointStyle
 */
public void setCheckpointStyle(CheckPointStyle checkpointStyle) {
	this.checkpointStyle = checkpointStyle;
}
public ControlStyle getControlStyle() {
	return ControlStyle;
}

/**
 * 时间轴控制器样式（详见ControlStyle）
 * @param controlStyle
 */
public void setControlStyle(ControlStyle controlStyle) {
	ControlStyle = controlStyle;
}
public String getSymbol() {
	return symbol;
}

/**
 * 轴点symbol，同serie.symbol
 * @param symbol
 */
public void setSymbol(String symbol) {
	this.symbol = symbol;
}
public double getSymbolSize() {
	return symbolSize;
}

/**
 * 轴点symbol，同serie.symbolSizes
 * @param symbolSize
 */
public void setSymbolSize(double symbolSize) {
	this.symbolSize = symbolSize;
}
public double getCurrentIndex() {
	return currentIndex;
}

/**
 * 当前索引位置，对应options数组，用于指定显示特定系列
 * @param currentIndex
 */
public void setCurrentIndex(double currentIndex) {
	this.currentIndex = currentIndex;
}
public String[] getData() {
	return data;
}

/**
 * 间轴列表，同时也是轴label内容
 * @param data
 */
public void setData(String[] data) {
	this.data = data;
}



}

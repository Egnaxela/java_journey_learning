package com.rongji.dfish.ui.plugins.echarts.json;

public class Title {
private boolean show;
private double zlevel;
private double z;
private String text;
private String link;
private String target;
private String subtext;
private String sublink;
private String subtarget;
private String x;
private String y;
private String textAlign;
private String backgroundColor;
private String borderColor;
private double borderWidth;
private double padding;
private double itemGap;
private TextStyle textStyle;
private TextStyle subtextStyle;
public boolean isShow() {
	return show;
}

/**
 * 显示策略，可选为：true（显示） | false（隐藏）
 * @param show
 */
public void setShow(boolean show) {
	this.show = show;
}
public double getZlevel() {
	return zlevel;
}

/**
 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
 * @param zlevel
 */
public void setZlevel(double zlevel) {
	this.zlevel = zlevel;
}
public double getZ() {
	return z;
}

/**
 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
 * @param z
 */
public void setZ(double z) {
	this.z = z;
}
public String getText() {
	return text;
}

/**
 * 主标题文本，'\n'指定换行
 * @param text
 */
public void setText(String text) {
	this.text = text;
}
public String getLink() {
	return link;
}

/**
 * 主标题文本超链接
 * @param link
 */
public void setLink(String link) {
	this.link = link;
}
public String getTarget() {
	return target;
}

/**
 * 指定窗口打开主标题超链接，支持'self' | 'blank'，不指定等同为'blank'（新窗口）
 * @param target
 */
public void setTarget(String target) {
	this.target = target;
}
public String getSubtext() {
	return subtext;
}

/**
 * 副标题文本，'\n'指定换行
 * @param subtext
 */
public void setSubtext(String subtext) {
	this.subtext = subtext;
}
public String getSublink() {
	return sublink;
}

/**
 * 副标题文本超链接
 * @param sublink
 */
public void setSublink(String sublink) {
	this.sublink = sublink;
}
public String getSubtarget() {
	return subtarget;
}

/**
 * 指定窗口打开副标题超链接，支持'self' | 'blank'，不指定等同为'blank'（新窗口）
 * @param subtarget
 */
public void setSubtarget(String subtarget) {
	this.subtarget = subtarget;
}
public String getX() {
	return x;
}

/**
 * 水平安放位置，默认为左侧，可选为：'center' | 'left' | 'right' | {number}（x坐标，单位px）
 * @param x
 */
public void setX(String x) {
	this.x = x;
}
public String getY() {
	return y;
}

/**
 * 垂直安放位置，默认为全图顶端，可选为：'top' | 'bottom' | 'center' | {number}（y坐标，单位px）
 * @param y
 */
public void setY(String y) {
	this.y = y;
}
public String getTextAlign() {
	return textAlign;
}

/**
 * 水平对齐方式，默认根据x设置自动调整，可选为： left' | 'right' | 'center
 * @param textAlign
 */
public void setTextAlign(String textAlign) {
	this.textAlign = textAlign;
}
public String getBackgroundColor() {
	return backgroundColor;
}

/**
 * 标题背景颜色，默认透明
 * @param backgroundColor
 */
public void setBackgroundColor(String backgroundColor) {
	this.backgroundColor = backgroundColor;
}
public String getBorderColor() {
	return borderColor;
}

/**
 * 标题边框颜色
 * @param borderColor
 */
public void setBorderColor(String borderColor) {
	this.borderColor = borderColor;
}
public double getBorderWidth() {
	return borderWidth;
}

/**
 * 标题边框线宽，单位px，默认为0（无边框）
 * @param borderWidth
 */
public void setBorderWidth(double borderWidth) {
	this.borderWidth = borderWidth;
}
public double getPadding() {
	return padding;
}

/**
 * 标题内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css，见下图
 * @param padding
 */
public void setPadding(double padding) {
	this.padding = padding;
}
public double getItemGap() {
	return itemGap;
}

/**
 * 主副标题纵向间隔，单位px，默认为10
 * @param itemGap
 */
public void setItemGap(double itemGap) {
	this.itemGap = itemGap;
}
public TextStyle getTextStyle() {
	return textStyle;
}

/**
 * 主标题文本样式（详见textStyle）
 * @param textStyle
 */
public void setTextStyle(TextStyle textStyle) {
	this.textStyle = textStyle;
}
public TextStyle getSubtextStyle() {
	return subtextStyle;
}

/**
 * 副标题文本样式（详见textStyle）
 * @param subtextStyle
 */
public void setSubtextStyle(TextStyle subtextStyle) {
	this.subtextStyle = subtextStyle;
}





}

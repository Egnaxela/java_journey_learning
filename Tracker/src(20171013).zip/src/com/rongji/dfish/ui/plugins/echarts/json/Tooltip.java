package com.rongji.dfish.ui.plugins.echarts.json;

public class Tooltip {
	private Boolean show;
	private Number zlevel;
	private Number z;
	private Boolean showContent;
	private String trigger;
	private String[] position;
	private String formatter;
	private String islandFormatter;
	private Number showDelay;
	private Number hideDelay;
	private Number transitionDuration;
	private Boolean enterable;
	private String backgroundColor;
	private String borderColor;
	private Number borderRadius;
	private Number borderWidth;
	private Number padding;
	private AxisPointer axisPointer;
	private TextStyle textStyle;
	public Boolean isShow() {
		return show;
	}
	
	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）s
	 * @param show
	 */
	public void setShow(Boolean show) {
		this.show = show;
	}
	public Number getZlevel() {
		return zlevel;
	}
	
	/**
	 * 一级层叠控制。每一个不同的zlevel将产生一个独立的canvas，相同zlevel的组件或图标将在同一个canvas上渲染。
	 * zlevel越高越靠顶层，canvas对象增多会消耗更多的内存和性能，并不建议设置过多的zlevel，大部分情况可以通过二级层叠控制z实现层叠控制。
	 * @param zlevel
	 */
	public void setZlevel(Number zlevel) {
		this.zlevel = zlevel;
	}
	public Number getZ() {
		return z;
	}
	
	/**
	 * 二级层叠控制，同一个canvas（相同zlevel）上z越高约靠顶层。
	 * @param z
	 */
	public void setZ(Number z) {
		this.z = z;
	}
	public Boolean isShowContent() {
		return showContent;
	}
	
	/**
	 * tooltip主体内容显示策略，只需tooltip触发事件或显示axisPointer而不需要显示内容时可配置该项为false，
                   可选为：true（显示） | false（隐藏）
	 * @param showContent
	 */
	public void setShowContent(Boolean showContent) {
		this.showContent = showContent;
	}
	public String getTrigger() {
		return trigger;
	}
	
	/**
	 * 触发类型，默认数据触发，见下图，可选为：'item' | 'axis'
	 * @param trigger
	 */
	public void setTrigger(String trigger) {
		this.trigger = trigger;
	}
	public String[] getPosition() {
		return position;
	}
	
	/**
	 * 位置指定，传入{Array}，如[x, y]， 固定位置[x, y]
	 * @param position
	 */
	public void setPosition(String[] position) {
		this.position = position;
	}
	public String getFormatter() {
		return formatter;
	}
	
	/**
	 * 内容格式器：{string}（Template） | {Function}，支持异步回调见表格下方
	 * @param formatter
	 */
	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	public String getIslandFormatter() {
		return islandFormatter;
	}
	
	/**
	 * 拖拽重计算独有，数据孤岛内容格式器：{string}（Template） | {Function}，见表格下方
	 * @param islandFormatter
	 */
	public void setIslandFormatter(String islandFormatter) {
		this.islandFormatter = islandFormatter;
	}
	public Number getShowDelay() {
		return showDelay;
	}
	
	/**
	 * 显示延迟，添加显示延迟可以避免频繁切换，特别是在详情内容需要异步获取的场景，单位ms
	 * @param showDelay
	 */
	public void setShowDelay(Number showDelay) {
		this.showDelay = showDelay;
	}
	public Number getHideDelay() {
		return hideDelay;
	}
	
	/**
	 * 隐藏延迟，单位ms
	 * @param hideDelay
	 */
	public void setHideDelay(Number hideDelay) {
		this.hideDelay = hideDelay;
	}
	public Number getTransitionDuration() {
		return transitionDuration;
	}
	
	/**
	 * 动画变换时长，单位s，如果你希望tooltip的跟随实时响应，showDelay设置为0是关键，同时transitionDuration设0也会有交互体验上的差别。
	 * @param transitionDuration
	 */
	public void setTransitionDuration(Number transitionDuration) {
		this.transitionDuration = transitionDuration;
	}
	public Boolean isEnterable() {
		return enterable;
	}
	
	/**
	 * 鼠标是否可进入详情气泡中，默认为false，如需详情内交互，如添加链接，按钮，可设置为true。
	 * @param enterable
	 */
	public void setEnterable(Boolean enterable) {
		this.enterable = enterable;
	}
	public String getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * 提示背景颜色，默认为透明度为0.7的黑色
	 * @param backgroundColor
	 */
	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public String getBorderColor() {
		return borderColor;
	}
	
	/**
	 * 提示边框颜色
	 * @param borderColor
	 */
	public void setBorderColor(String borderColor) {
		this.borderColor = borderColor;
	}
	public Number getBorderRadius() {
		return borderRadius;
	}
	
	/**
	 * 提示边框圆角，单位px，默认为4
	 * @param borderRadius
	 */
	public void setBorderRadius(Number borderRadius) {
		this.borderRadius = borderRadius;
	}
	public Number getBorderWidth() {
		return borderWidth;
	}
	
	/**
	 * 提示边框线宽，单位px，默认为0（无边框）
	 * @param borderWidth
	 */
	public void setBorderWidth(Number borderWidth) {
		this.borderWidth = borderWidth;
	}
	public Number getPadding() {
		return padding;
	}
	
	/**
	 * 提示内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距，同css
	 * @param padding
	 */
	public void setPadding(Number padding) {
		this.padding = padding;
	}
	public AxisPointer getAxisPointer() {
		return axisPointer;
	}
	
	/**
	 * 坐标轴指示器（详细请看AxisPointer）
	 * @param axisPointer
	 */
	public void setAxisPointer(AxisPointer axisPointer) {
		this.axisPointer = axisPointer;
	}
	public TextStyle getTextStyle() {
		return textStyle;
	}
	
	/**
	 * 文本样式，默认为白色字体（详见textStyle）
	 * @param textStyle
	 */
	public void setTextStyle(TextStyle textStyle) {
		this.textStyle = textStyle;
	}
	
	
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class TreeSeries extends Series{
public RootLocation getRootLocation() {
	return rootLocation;
}
public void setRootLocation(RootLocation rootLocation) {
	this.rootLocation = rootLocation;
}
public Double getLayerPadding() {
	return layerPadding;
}
public void setLayerPadding(Double layerPadding) {
	this.layerPadding = layerPadding;
}
public Double getNodePadding() {
	return nodePadding;
}
public void setNodePadding(Double nodePadding) {
	this.nodePadding = nodePadding;
}
public String getOrient() {
	return orient;
}
public void setOrient(String orient) {
	this.orient = orient;
}
public String getDirection() {
	return direction;
}
public void setDirection(String direction) {
	this.direction = direction;
}
public String getRoam() {
	return roam;
}
public void setRoam(String roam) {
	this.roam = roam;
}
public String getSymbol() {
	return symbol;
}
public void setSymbol(String symbol) {
	this.symbol = symbol;
}
public Double[] getSymbolSize() {
	return symbolSize;
}
public void setSymbolSize(Double[] symbolSize) {
	this.symbolSize = symbolSize;
}
private RootLocation rootLocation;
private Double layerPadding;
private Double nodePadding;
private String orient;
private String direction;
private String roam;
private String symbol;
private Double[] symbolSize;
}

package com.rongji.dfish.ui.plugins.echarts.json;

public class VennSeries extends Series{

}

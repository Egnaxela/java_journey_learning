package com.rongji.dfish.ui.plugins.echarts.json;

public class XAxis {

	private String type;
	private Object[] data;
	private Boolean splitLine;
	private AxisTick axisTick;
	private AxisLine axisLine;
	private boolean boundaryGap;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Object[] getData() {
		return data;
	}
	public void setData(Object[] data) {
		this.data = data;
	}
	
	public Boolean getSplitLine() {
		return splitLine;
	}
	public void setSplitLine(Boolean splitLine) {
		this.splitLine = splitLine;
	}
	public AxisTick getAxisTick() {
		return axisTick;
	}
	public void setAxisTick(AxisTick axisTick) {
		this.axisTick = axisTick;
	}
	public AxisLine getAxisLine() {
		return axisLine;
	}
	public void setAxisLine(AxisLine axisLine) {
		this.axisLine = axisLine;
	}
	public boolean isBoundaryGap() {
		return boundaryGap;
	}
	public void setBoundaryGap(boolean boundaryGap) {
		this.boundaryGap = boundaryGap;
	}
}

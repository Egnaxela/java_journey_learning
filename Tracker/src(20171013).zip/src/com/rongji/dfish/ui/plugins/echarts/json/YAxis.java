package com.rongji.dfish.ui.plugins.echarts.json;

public class YAxis {

	private String type;
	private Boolean splitLine;
	private Boolean show;
	private AxisLabel axisLabel;
	private AxisLine axisLine;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Boolean getSplitLine() {
		return splitLine;
	}
	public void setSplitLine(Boolean splitLine) {
		this.splitLine = splitLine;
	}
	public AxisLabel getAxisLabel() {
		return axisLabel;
	}
	public void setAxisLabel(AxisLabel axisLabel) {
		this.axisLabel = axisLabel;
	}
	public Boolean getShow() {
		return show;
	}
	public void setShow(Boolean show) {
		this.show = show;
	}
	public AxisLine getAxisLine() {
		return axisLine;
	}
	public void setAxisLine(AxisLine axisLine) {
		this.axisLine = axisLine;
	}
}

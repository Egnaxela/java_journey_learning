﻿package com.rongji.dfish.util;

import com.rongji.dfish.engines.xmltmpl.component.TreeItem;

public class TreeTest {
	private static final String ICON = "img/p/playr.gif";

	public static TreeItem getRoot() {
		// 添加演示树。用于演示JS命令
		TreeItem deRoot = new TreeItem("deroot", "用于演示JS的TREE系列命令",
				"demo.do?act=open&id=deroot", "void(0);", ICON, ICON, null);
		return deRoot;
	}

	private static final String[][] DATA = { { "10", "北京(10****)", "deroot" },
			{ "1000", "北京市(1000**)", "10" },
			{ "100000", "海淀区(100000)", "1000" },
			{ "100095", "北安河(100095)", "1000" },
			{ "1011", "通县(1011**)", "10" },
			{ "101100", "通州镇(101100)", "1011" },
			{ "101108", "郎府(101108)", "1011" },
			{ "35", "福建省(35****)", "deroot" }, { "3500", "福州(3500**)", "35" },
			{ "350000", "鼓楼区(350000)", "3500" },
			{ "350012", "新店(350012)", "3500" },
			{ "350014", "鼓山(350014)", "3500" },
			{ "350015", "马尾(350015)", "3500" }, { "3530", "南平(3530**)", "35" },
			{ "353000", "延平区(353000)", "3530" },
			{ "353001", "沙溪口(353001)", "3530" }, };

	public static TreeItem openTree(String id) {
		try {
			Thread.sleep(500L);
			// 延迟一秒，用于模拟网络状况，正式使用时不能随意暂停当前线程
		} catch (InterruptedException ex) {
		}
		// 添加演示树。用于演示JS命令
		TreeItem container = new TreeItem();
		for (int i = 0; i < DATA.length; i++) {
			if (!id.equals(DATA[i][2])) {
				continue;
			}
			String hitid = DATA[i][0];
			boolean hasSon = hasSon(hitid);
			TreeItem hit = new TreeItem(hitid, DATA[i][1],
					hasSon ? "panelShow.sp?act=openTree&id=" + hitid : null, "void(0);",
					ICON, ICON, null);
			container.addTreeItem(hit);
		}
		return container;
	}

	private static boolean hasSon(String hitid) {
		for (int i = 0; i < DATA.length; i++) {
			if (hitid.equals(DATA[i][2])) {
				return true;
			}
		}
		return false;
	}

}

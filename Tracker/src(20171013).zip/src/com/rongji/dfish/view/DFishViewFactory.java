/**
 * File:ViewFactory.java
 * company:rongji
 * @version 1.0 
 * Date 2015-5-28
 */
package com.rongji.dfish.view;

import java.util.ArrayList;
import java.util.List;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.Button;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.Command;
import com.rongji.dfish.engines.xmltmpl.LogicComponent;
import com.rongji.dfish.engines.xmltmpl.Panel;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.View;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.ComplexGridPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanelPubInfo;
import com.rongji.dfish.engines.xmltmpl.component.HorizontalPanel;
import com.rongji.dfish.engines.xmltmpl.component.HtmlPanel;
import com.rongji.dfish.engines.xmltmpl.component.ImagePanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.engines.xmltmpl.component.PortalPanel;
import com.rongji.dfish.engines.xmltmpl.component.TreePanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.XBox;
import com.rongji.dfish.engines.xmltmpl.resources.PropertyHandler;
import com.rongji.dfish.engines.xmltmpl.skin.ItaskViewFactory;

/** 
 *
 * @author 吉兵
 * @since 1.0
 */
public class DFishViewFactory extends ItaskViewFactory{
	public static final String ID_PANEL_ROOT = "fp_root";
	public static final String ID_PANEL_TOP = "fp_top";
	public static final String ID_PANEL_MIDDLE = "fp_middle";
	public static final String ID_PANEL_LEFT = "fp_left";
	public static final String ID_PANEL_LEFT_TOP = "fp_left_top";
	public static final String ID_PANEL_LEFT_MIDDLE = "fp_left_middle";
	public static final String ID_PANEL_RIGHT_TOP = "fp_right_top";
	public static final String ID_PANEL_RIGHT = "fp_right";
	public static final String ID_PANEL_RIGHT_MIDDLE = "fp_right_middle";
	public static final String ID_PANEL_TITLE = "f_title";
	public static final String ID_PANEL_BUTTON_BAR = "f_btn";
	public static final String ID_PANEL_FORM = "f_form";
	public static final String ID_PANEL_GRID = "f_grid";
	public static final String ID_PANEL_PAGE = "f_page";
	public static final String ID_PANEL_TREE = "f_tree";
	public static final String ID_PANEL_PORTAL = "f_portal";
	public static final String ID_PANEL_IMG = "f_img";
	public static final String ID_PANEL_INFO = "f_info";
	public static final String ID_CMD_PAGE = "c_page";
	public static final String ID_DIALOG_STANDARD = "f_std";
	public static final String PANEL_TITLE_HEIGHT="40";//标题栏，按钮栏高度
	public static final String PANEL_PAGE_HEIGHT="35";//分页栏高度
	/**
	 * 重写ItaskViewFactory的方法，
	 * 	方法返回视图中没有信息栏，可以有标题栏或者按钮栏，只会有一个，并且，有按钮栏则不再添加信息栏
	 * 	该方法中，分页栏和grid在同一个面板中
	 * @return 返回一个Grid面板
	 */
	public BaseView buildGridView(boolean hasTitle, boolean hasOper, boolean hasInfo, boolean hasPage)
    {
		List<String> list = new ArrayList<String>();
		if(hasOper){
			list.add(PANEL_TITLE_HEIGHT);
		}else{
			if(hasTitle){
				list.add(PANEL_TITLE_HEIGHT);
			}
		}
		list.add("*");
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel(ID_PANEL_ROOT, getRow(list));
		rootPanel.setStyleClass("bd-gray");
		view.setRootPanel(rootPanel);
		//顶部面板
		if(hasOper||hasTitle){
			HorizontalPanel buttonBar = new HorizontalPanel(ID_PANEL_TOP,"*");
			rootPanel.addSubPanel(buttonBar);
			buttonBar.setStyle("padding:0px 4px;");
			buttonBar.setStyleClass("bg-lowest");
			if(hasOper){
				//按钮栏
				ButtonBarPanel workOper = new ButtonBarPanel(ID_PANEL_BUTTON_BAR);
				buttonBar.addSubPanel(workOper);
				workOper.setAlign(Align.left);
			}else{
				HtmlPanel title=new HtmlPanel(ID_PANEL_TITLE,"");
				title.setStyleClass("bg-lowest");
				title.setStyle("font-size:18px;line-height:36px");
				buttonBar.addSubPanel(title);
			}
		}
		//中部面板
		FlowPanel workContent = new FlowPanel(ID_PANEL_MIDDLE);
		rootPanel.addSubPanel(workContent);
		workContent.setAlign(Align.center);
		workContent.setScroll(Scroll.miniscroll);
		//GridPanel 中部面板中添加grid面板
		GridPanel gridPanel = new GridPanel(ID_PANEL_GRID);
		gridPanel.pub().setStyleClass("pub_row");
		gridPanel.setFilter(false);
		gridPanel.setRowHeight(36);
		gridPanel.setScroll(Scroll.miniscroll);
		gridPanel.setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		workContent.addSubPanel(gridPanel);
		
		if(hasPage){
			//PagePanel 中部面板中添加pagePanel面板
			PagePanel pg = new PagePanel(ID_PANEL_PAGE);
			pg.setFace(PagePanel.FACE_OFFICE);
			pg.setStyle("padding:10px 30px 10px 30px;");
			pg.setAlign(Align.center);
			pg.setClickCommand(new AjaxCommand(ViewFactory.ID_CMD_PAGE,""));
			workContent.addSubPanel(pg);
		}
		return view;
    }
	
	/**
	 * 方法返回视图中没有信息栏，可以有标题栏或者按钮栏，只会有一个，并且，有按钮栏则不再添加信息栏
	 * 	该方法中，分页栏和grid在同一个面板中，且丢弃了搜索栏
	 */
	public BaseView buildGridAndFormView2(boolean hasTitle, boolean hasOper, boolean hasInfo, boolean hasPage, boolean hasSearch){
		List<String> list = new ArrayList<String>();
		if(hasOper){
			list.add(PANEL_TITLE_HEIGHT);
		}else{
			if(hasTitle){
				list.add(PANEL_TITLE_HEIGHT);
			}
		}
		list.add("*");
		BaseView view = new BaseView();
		HorizontalPanel root = new HorizontalPanel(ID_PANEL_ROOT, "25%,3,*");
		view.setRootPanel(root);

		//左边面板，包括grid和分页栏
		VerticalPanel vpleft = new VerticalPanel(ID_PANEL_LEFT, "5,*");
		root.addSubPanel(vpleft);
		vpleft.setStyleClass("bd-gray");
		vpleft.setHorizontalMinus(2);
		vpleft.setVerticalMinus(2);
		
		//左侧面板顶部区域
		HtmlPanel pad=new HtmlPanel("","");
		pad.setStyleClass("bg-lowest");
		vpleft.addSubPanel(pad);

		//左侧是一个flow面板，包含grid面板和page面板
		FlowPanel workContent = new FlowPanel(ID_PANEL_LEFT_MIDDLE);
		vpleft.addSubPanel(workContent);
		workContent.setAlign(Align.center);
		workContent.setScroll(Scroll.miniscroll);
		//GridPanel 中部面板中添加grid面板
		GridPanel gridPanel = new GridPanel(ID_PANEL_GRID);
		gridPanel.pub().setHeaderClass("bg-lowest position_fixed fixed");
		gridPanel.setFilter(false);
		gridPanel.setRowHeight(32);
		gridPanel.setScroll(Scroll.miniscroll);
		gridPanel.setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		workContent.addSubPanel(gridPanel);
		
		if(hasPage){
			//PagePanel 中部面板中添加pagePanel面板
			PagePanel pg = new PagePanel(ID_PANEL_PAGE);
			pg.setFace(PagePanel.FACE_OFFICE);
			pg.setStyle("padding:10px 30px 10px 30px;");
			pg.setAlign(Align.center);
			pg.setClickCommand(new AjaxCommand(ViewFactory.ID_CMD_PAGE,""));
			workContent.addSubPanel(pg);
		}
		
		//调整页面大小功能面板
		HtmlPanel splitor = new HtmlPanel(null, null);
		root.addSubPanel(splitor);
		splitor.setHorizontalResize("10,50");

		//右侧面板--顶部按钮栏或者信息栏，下面为form面板
		VerticalPanel vpright = new VerticalPanel(ID_PANEL_RIGHT, "36,*");
		root.addSubPanel(vpright);
		vpright.setStyleClass("bd-gray");
		vpright.setHorizontalMinus(2);
		vpright.setVerticalMinus(2);

		//右侧顶部面板
		if(hasOper||hasTitle){
			HorizontalPanel buttonBar = new HorizontalPanel(ID_PANEL_RIGHT_TOP,"*");
			vpright.addSubPanel(buttonBar);
			buttonBar.setStyle("padding:0px 4px;");
			buttonBar.setStyleClass("bg-lowest");
			if(hasOper){
				//按钮栏
				ButtonBarPanel workOper = new ButtonBarPanel(ID_PANEL_BUTTON_BAR);
				buttonBar.addSubPanel(workOper);
				workOper.setAlign(Align.left);
				workOper.setHorizontalMinus(6);
			}else{
				HtmlPanel title=new HtmlPanel(ID_PANEL_TITLE,"");
				title.setStyleClass("bg-lowest");
				title.setStyle("font-size:18px;line-height:36px");
				buttonBar.addSubPanel(title);
			}
		}
		
		//form面板
		FormPanel form=new FormPanel(ID_PANEL_FORM);
		form.setStyle("padding:10px 10px 0px 2px;");
    	form.setScroll(Scroll.miniscroll);
		vpright.addSubPanel(form);
		return view;
	}
	
	/**
	 * 重写buildTreeView视图
	 * 	改为，左侧为树面板，右侧为form面板
	 * 	信息栏在树面板上面，按钮栏在form面板上面,丢掉了info栏
	 */
	public BaseView buildTreeView(boolean hasTitle, boolean hasOper, boolean hasInfo){
		BaseView view = new BaseView();
		HorizontalPanel root = new HorizontalPanel(ID_PANEL_ROOT, "25%,3,*");
		view.setRootPanel(root);

		//左边面板，包括grid和分页栏
		String left = "*";
		if(hasTitle){left="36,*";}
		VerticalPanel vpleft = new VerticalPanel(ID_PANEL_LEFT, left);
		root.addSubPanel(vpleft);
		vpleft.setStyleClass("bd-gray");
		vpleft.setHorizontalMinus(2);
		vpleft.setVerticalMinus(2);
		
		//tree面板上方标题栏
		if(hasTitle){
			HtmlPanel pad=new HtmlPanel(ID_PANEL_TITLE,"");
			pad.setStyleClass("bg-lowest");
			pad.setStyle("font-size:18px;line-height:36px;padding-left:5px;");
			vpleft.addSubPanel(pad);
		}

		//左侧是一个tree面板
		TreePanel tree=new TreePanel(ID_PANEL_TREE);
		vpleft.addSubPanel(tree);
		tree.setScroll(Scroll.miniscroll);
		
		//调整页面大小功能面板
		HtmlPanel splitor = new HtmlPanel(null, null);
		root.addSubPanel(splitor);
		splitor.setHorizontalResize("10,50");

		//右侧面板--顶部按钮栏或者信息栏，下面为form面板
		String right="*";
		if(hasOper){right="36,*";}
		VerticalPanel vpright = new VerticalPanel(ID_PANEL_RIGHT, right);
		root.addSubPanel(vpright);
		vpright.setStyleClass("bd-gray");
		vpright.setHorizontalMinus(2);
		vpright.setVerticalMinus(2);

		//右侧顶部面板
		if(hasOper){
			HorizontalPanel buttonBar = new HorizontalPanel(ID_PANEL_RIGHT_TOP,"*");
			vpright.addSubPanel(buttonBar);
			buttonBar.setStyle("padding:0px 4px;");
			buttonBar.setStyleClass("bg-lowest");
			//按钮栏
			ButtonBarPanel workOper = new ButtonBarPanel(ID_PANEL_BUTTON_BAR);
			buttonBar.addSubPanel(workOper);
			workOper.setAlign(Align.left);
			workOper.setHorizontalMinus(6);
		}
		
		//form面板
		FormPanel form=new FormPanel(ID_PANEL_FORM);
		form.setStyle("padding:10px 10px 0px 2px;");
    	form.setScroll(Scroll.miniscroll);
		vpright.addSubPanel(form);
		return view;
	}
	
	/**
	 * 重写FormView视图
	 * 	修改：丢掉标题栏和信息栏,将按钮栏置于视图的下方
	 * 	
	 */
	public BaseView buildFormView(boolean hasTitle, boolean hasOper, boolean hasInfo){
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(ID_PANEL_ROOT, "*,45");
		view.setRootPanel(popVP);

		FormPanel popForm = new FormPanel(ID_PANEL_FORM);
		popVP.addSubPanel(popForm);
		popForm.setStyle("padding:10px 10px 0px 2px;");
		popForm.setScroll(Scroll.miniscroll);

		ButtonBarPanel popOper = new ButtonBarPanel(ID_PANEL_BUTTON_BAR);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.left);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop bg-lowest");
		popOper.setStyle("padding:0 30px");

		return view;
	}
	
	/**
	 * 重写XBoxPairView
	 * 	hasTitle:标题栏
	 * 	hasOper:默认为false，设置为任何值不影响
	 * 	修改：丢弃视图中XBox下面的搜索栏
	 */
	public BaseView buildXBoxPairView(boolean hasTitle, boolean hasOper){
		List<String> list = new ArrayList<String>();
		if(hasOper){
			list.add(ID_PANEL_TITLE);
		}
		list.add("*");
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel(ID_PANEL_ROOT, getRow(list));
		rootPanel.setStyleClass("bd-gray");
		view.setRootPanel(rootPanel);
		
		//标题栏
		if(hasTitle){
			HtmlPanel pad=new HtmlPanel(ID_PANEL_TITLE,"");
			pad.setStyleClass("bg-lowest");
			pad.setStyle("font-size:18px;line-height:36px;padding-left:5px;");
			rootPanel.addSubPanel(pad);
		}
	    
	    //中部
		Object localObject3 = (JSCommand)getAttribute(LogicComponent.CMD_XBOXPAIR_LEFT);
		Object localObject4a = (JSCommand)getAttribute(LogicComponent.CMD_XBOXPAIR_RIGHT);
		Object localObject5a = ((JSCommand)localObject3).getJs();
		Object localObject1 = ((JSCommand)localObject4a).getJs();
	     ((JSCommand)localObject3).setJs((String)localObject1);
	     ((JSCommand)localObject4a).setJs((String)localObject5a);
	     localObject1 = localObject3;
	    Object localObject2 = localObject4a;
	    
		localObject3 = (Command)getAttribute(LogicComponent.CMD_SELECTOR_COMFIRM);
	    view.addCommand((Command)localObject1).addCommand((Command)localObject2).addCommand((Command)localObject3);
	    HorizontalPanel localObject4 = new HorizontalPanel("p_hori_xbox", (String)getAttribute(LogicComponent.LAYOUT_COLS_XBOXPAIR));
	    ButtonBarPanel localObject5 = new ButtonBarPanel(getId(LogicComponent.PANEL_BUTTON_BAR));
	    localObject5.setAlign(Align.center);
	    localObject5.setFace(ButtonFace.classic);
	    localObject5.setCellspacing(12);
		
	    localObject1 = new ClickButton(PropertyHandler.getMsg(this.loc, "p.url.leftarrow", new Object[0]), null, "VM(this).cmd('" + ((Command)localObject1).getId() + "')");
	    localObject2 = new ClickButton(PropertyHandler.getMsg(this.loc, "p.url.rightarrow", new Object[0]), null, 
	      "VM(this).cmd('" + ((Command)localObject2).getId() + "')");
	    localObject3 = new ClickButton(null, PropertyHandler.getMsg(this.loc, "p.btn.confirm", new Object[0]), "VM(this).cmd('" + ((Command)localObject3).getId() + "')");
	    ((ButtonBarPanel)localObject5).setDirectionVertical(true);
	    ((ButtonBarPanel)localObject5).addButton((Button)localObject1).addButton((Button)localObject2);
	   
	    ((ButtonBarPanel)localObject5).addButton((Button)localObject3);
	    ((ClickButton)localObject3).setTitle("确定");
	    
	    localObject1 = buildXBoxSelector(view, 
	      getId(LogicComponent.PANEL_FORM_SELECTOR_LEFT), 
	      getName(LogicComponent.PANEL_FORM_SELECTOR_LEFT), 
	      getId(LogicComponent.PANEL_TITLE_SELECTOR_LEFT), 
	      getName(LogicComponent.PANEL_SEARCH_SELECTOR_LEFT));
	    localObject2 = buildXBoxSelector(view, 
	      getId(LogicComponent.PANEL_FORM_SELECTOR_CANDIDATE), 
	      getName(LogicComponent.PANEL_FORM_SELECTOR_CANDIDATE), 
	      getId(LogicComponent.PANEL_TITLE_SELECTOR_CANDIDATE), 
	      getName(LogicComponent.PANEL_SEARCH_SELECTOR_CANDIDATE));
	    localObject4a = (XBox)((FormPanel)((VerticalPanel)localObject1).findPanelById(getId(LogicComponent.PANEL_FORM_SELECTOR_LEFT)))
	      .findSingleElementByName(getName(LogicComponent.PANEL_FORM_SELECTOR_LEFT));
	    localObject5a = (XBox)((FormPanel)((VerticalPanel)localObject2).findPanelById(getId(LogicComponent.PANEL_FORM_SELECTOR_CANDIDATE)))
	      .findSingleElementByName(getName(LogicComponent.PANEL_FORM_SELECTOR_CANDIDATE));
	     
	    
	    ((XBox)localObject5a).setDbclick("VM(this).cmd('" + getId(LogicComponent.CMD_XBOXPAIR_RIGHT) + "')");
	    ((XBox)localObject4a).setDbclick("VM(this).cmd('" + getId(LogicComponent.CMD_XBOXPAIR_LEFT) + "')");
	     ((HorizontalPanel)localObject4).addSubPanel(new Panel[] { HtmlPanel.EMPTY, (VerticalPanel)localObject2, localObject5,(VerticalPanel)localObject1, 
	        HtmlPanel.EMPTY });
	    view.addSubPanel(localObject4);
	    return view;
	}
	
	/**
	 * 重写ViewFactory的buildXBoxSelector方法
	 * 	方法返回一个不带搜索栏的XBox
	 */
	protected VerticalPanel buildXBoxSelector(View paramView, String paramString1, String paramString2, String paramString3, String paramString4)
	{
	    VerticalPanel localVerticalPanel = new VerticalPanel(null, (String)getAttribute(LogicComponent.LAYOUT_ROWS_XBOXSELECT));
	    VerticalPanel vp = new VerticalPanel(null, 
	      getRows(new LogicComponent[] {LogicComponent.PANEL_TITLE_SELECTOR, LogicComponent.MAIN_PANEL }), getStyleClass(LogicComponent.BORDER_MID), 
	      null, getVMinus(LogicComponent.BORDER_MID), getHMinus(LogicComponent.BORDER_MID));
	    localVerticalPanel.setRows("6%,*,6%");
	    localVerticalPanel.addSubPanel(new Panel[] { HtmlPanel.EMPTY, vp, HtmlPanel.EMPTY});
	    
	    vp.setStyleClass("bd-gray");
	    HtmlPanel hm = new HtmlPanel(paramString3, null, 
	      getStyleClass(LogicComponent.PANEL_TITLE_SELECTOR), null, 0, 0);
	    hm.setStyleClass("bg-lowest");
	    hm.setAlign(Align.center);
	    
	    FormPanel form = new FormPanel(paramString1);
	    form.setCellspacing(0);
	    form.setCellpadding(0);
	    form.setScroll(Scroll.miniscroll);
	    XBox box = new XBox(paramString2, null, null, null, null, 0, -1, false, false, -1, null, null, null);
	    box.setAlwaysChecked(true);
	    box.setMulti(true);
	    form.add(box);
	    box.setFullLine(true);
	    box.setHasBorder(false);
	    vp.addSubPanel(new Panel[] { hm, form });
	    return localVerticalPanel;
	}
	
	/**
	 * 重写buildXBoxAndTreeView方法
	 * 	修改样式和按钮不显示中文
	 */
	public BaseView buildXBoxAndTreeView(boolean paramBoolean1, boolean paramBoolean2)
	{
	    Object localObject1 = new ArrayList();
	    if (paramBoolean1) {
	      ((ArrayList)localObject1).add(LogicComponent.PANEL_TITLE);
	    }
	    ((ArrayList)localObject1).add(LogicComponent.MAIN_PANEL);
	    localObject1 = new VerticalPanel(getId(LogicComponent.VIEW_ROOT), 
	      getRows((List)localObject1), 
	      getStyleClasses(new LogicComponent[] { LogicComponent.VIEW_SELECTOR, LogicComponent.BORDER_DEEP }), null, 
	      getVMinus(LogicComponent.BORDER_DEEP), 
	      getHMinus(LogicComponent.BORDER_DEEP));
	    
	    ((VerticalPanel)localObject1).setStyleClass("bd-gray");
	    BaseView localBaseView;
	    (localBaseView = new BaseView()).setRootPanel((Panel)localObject1);
	    if (paramBoolean1)
	    {
	    	HtmlPanel hm = new HtmlPanel(getId(LogicComponent.PANEL_TITLE), 
	        null, getStyleClass(LogicComponent.PANEL_TITLE), null, 0, 0);
	    	((VerticalPanel)localObject1).addSubPanel(hm);
	    	hm.setStyleClass("bg-lowest");
	    	hm.setAlign(Align.center);
	    }
	    Object localObject2 = null;
	    Object localObject5 = null;
	    if (!this.selectedinLeft)
	    {
	    	JSCommand jscommand = (JSCommand)getAttribute(LogicComponent.CMD_XBOXTREE_LEFT);
	    	JSCommand jscommand1 = (JSCommand)getAttribute(LogicComponent.CMD_XBOXTREE_RIGHT);
	    	localObject5 = ((JSCommand)jscommand).getJs();
	    	localObject2 = ((JSCommand)jscommand1).getJs();
	    	((JSCommand)jscommand).setJs((String)localObject2);
	    	((JSCommand)jscommand1).setJs((String)localObject5);
	    	localObject5 = jscommand;
	    	localObject2 = jscommand1;
	    }
	    else
	    {
	    	localObject5 = (Command)getAttribute(LogicComponent.CMD_XBOXTREE_LEFT);
	    	localObject2 = (Command)getAttribute(LogicComponent.CMD_XBOXTREE_RIGHT);
	    }
	    Object localObject3 = (Command)getAttribute(LogicComponent.CMD_SELECTOR_COMFIRM);
	    localBaseView.addCommand((Command)localObject5).addCommand((Command)localObject2).addCommand((Command)localObject3);
	    Object localObject4 = new HorizontalPanel(null, 
	      (String)getAttribute(LogicComponent.LAYOUT_COLS_XBOXPAIR));
	    //
	    ((HorizontalPanel)localObject4).setCols("12%,*,110,*,12%");
	    
	    ButtonBarPanel bum = new ButtonBarPanel(getId(LogicComponent.PANEL_BUTTON_BAR));
	    bum.setAlign(Align.center);
	    bum.setFace(ButtonFace.classic);
	    bum.setCellspacing(12);
	    localObject5 = new ClickButton(PropertyHandler.getMsg(this.loc, "p.url.leftarrow", new Object[0]), 
	      null, "VM(this).cmd('" + ((Command)localObject5).getId() + "')");
	    localObject2 = new ClickButton(PropertyHandler.getMsg(this.loc, "p.url.rightarrow", new Object[0]), 
	      null, "VM(this).cmd('" + ((Command)localObject2).getId() + "')");
	    localObject3 = new ClickButton(null, PropertyHandler.getMsg(this.loc, "p.btn.confirm", new Object[0]), 
	      "VM(this).cmd('" + ((Command)localObject3).getId() + "')");
	    ((ClickButton)localObject3).setTitle("确定");
	    
	    bum.setDirectionVertical(true);
	    bum.addButton((Button)localObject5).addButton((Button)localObject2);
	    bum.addButton((Button)localObject3);
	    
	    VerticalPanel vp = buildXBoxSelector(localBaseView, 
	      getId(LogicComponent.PANEL_FORM_SELECTOR_LEFT), 
	      getName(LogicComponent.PANEL_FORM_SELECTOR_LEFT), 
	      getId(LogicComponent.PANEL_TITLE_SELECTOR_LEFT), 
	      getName(LogicComponent.PANEL_SEARCH_SELECTOR_LEFT));
	    VerticalPanel vp2 = buildTreeSelector(getId(LogicComponent.PANEL_TITLE_SELECTOR_CANDIDATE));
	    localObject2 = (XBox)((FormPanel)vp
	      .findPanelById(getId(LogicComponent.PANEL_FORM_SELECTOR_LEFT)))
	      .findSingleElementByName(getName(LogicComponent.PANEL_FORM_SELECTOR_LEFT));
	    localObject3 = (TreePanel)vp2.findPanelById(getId(LogicComponent.PANEL_TREE));
	    ((TreePanel)localObject3).setMultiSelection(true);
	    if (this.selectedinLeft)
	    {
	      ((TreePanel)localObject3).setDefaultValue(
	        "dbl", "VM(this).cmd('" + getId(LogicComponent.CMD_XBOXPAIR_LEFT) + "')");
	      ((XBox)localObject2).setDbclick("VM(this).cmd('" + 
	        getId(LogicComponent.CMD_XBOXPAIR_RIGHT) + "')");
	      ((HorizontalPanel)localObject4).addSubPanel(new Panel[] { HtmlPanel.EMPTY, vp, bum, vp2, 
	        HtmlPanel.EMPTY });
	    }
	    else
	    {
	      ((TreePanel)localObject3).setDefaultValue(
	        "dbl","VM(this).cmd('" + getId(LogicComponent.CMD_XBOXPAIR_RIGHT) + "')");
	      ((XBox)localObject2).setDbclick("VM(this).cmd('" + 
	        getId(LogicComponent.CMD_XBOXPAIR_LEFT) + "')");
	      ((HorizontalPanel)localObject4).addSubPanel(new Panel[] { HtmlPanel.EMPTY, vp2, bum, vp, 
	        HtmlPanel.EMPTY });
	    }
	    ((VerticalPanel)localObject1).addSubPanel((Panel)localObject4);
	    
	    return localBaseView;
	}
	
	/**
	 * 重写buildTreeSelector方法
	 * 	修改TreeSelector的样式
	 */
	protected VerticalPanel buildTreeSelector(String paramString)
	  {
	    VerticalPanel localVerticalPanel1 = new VerticalPanel(null, (String)getAttribute(LogicComponent.LAYOUT_ROWS_TREESELECT));
	    VerticalPanel localVerticalPanel2 = new VerticalPanel(null, 
	      getRows(new LogicComponent[] { LogicComponent.PANEL_TITLE_SELECTOR_CANDIDATE, LogicComponent.MAIN_PANEL }), getStyleClass(LogicComponent.BORDER_MID), 
	      null, getVMinus(LogicComponent.BORDER_MID), getHMinus(LogicComponent.BORDER_MID));
	    localVerticalPanel1.addSubPanel(new Panel[] { HtmlPanel.EMPTY, localVerticalPanel2, HtmlPanel.EMPTY });
	    HtmlPanel hm = new HtmlPanel(paramString, null, 
	      getStyleClass(LogicComponent.PANEL_TITLE_SELECTOR_CANDIDATE), null, 0, 0);
	    hm.setStyleClass("bg-lowest");
	    hm.setAlign(Align.center);
	    
	    TreePanel localTreePanel;
	    (localTreePanel = new TreePanel(getId(LogicComponent.PANEL_TREE))).setStyle(getStyle(LogicComponent.BG_WHITE));
	    localVerticalPanel2.addSubPanel(new Panel[] { hm, localTreePanel });
	    localVerticalPanel2.setStyleClass("bd-gray");
	    return localVerticalPanel1;
	  }
	
	public HtmlPanel findTitlePanel(BaseView baseview)
    {
        return (HtmlPanel)baseview.findPanelById(ID_PANEL_TITLE);
    }

    public GridPanel findGridPanel(BaseView baseview)
    {
        return (GridPanel)baseview.findPanelById(ID_PANEL_GRID);
    }

    public PortalPanel findPortalPanel(BaseView baseview)
    {
        return (PortalPanel)baseview.findPanelById(ID_PANEL_PORTAL);
    }

    public PagePanel findPagePanel(BaseView baseview)
    {
        return (PagePanel)baseview.findPanelById(ID_PANEL_PAGE);
    }

    public FormPanel findFormPanel(BaseView baseview)
    {
        return (FormPanel)baseview.findPanelById(ID_PANEL_FORM);
    }

    public TreePanel findTreePanel(BaseView baseview)
    {
        return (TreePanel)baseview.findPanelById(ID_PANEL_TREE);
    }

    public ImagePanel findImagePanel(BaseView baseview)
    {
        return (ImagePanel)baseview.findPanelById(ID_PANEL_IMG);
    }

    public ComplexGridPanel findComplexGridPanel(BaseView baseview)
    {
        return (ComplexGridPanel)baseview.findPanelById(ID_PANEL_GRID);
    }

    public HtmlPanel findInfoPanel(BaseView baseview)
    {
        return (HtmlPanel)baseview.findPanelById(ID_PANEL_INFO);
    }

    public ButtonBarPanel findBttonPanel(BaseView baseview)
    {
        return (ButtonBarPanel)baseview.findPanelById(ID_PANEL_BUTTON_BAR);
    }
    
    /**
     * 返回一个默认样式的Grid面板
     */
    public GridPanel getDefaultGridPanel(){
    	GridPanel gridPanel = new GridPanel(ID_PANEL_GRID);
    	gridPanel.pub().setFace(GridPanelPubInfo.FACE_DOT);
		gridPanel.pub().setStyleClass("pub_row");
		gridPanel.setHorizontalMinus(0);
		gridPanel.setVerticalMinus(0);
//		gridPanel.pub().setHeaderClass("bg-lowest");
		gridPanel.setFilter(false);
		gridPanel.setRowHeight(36);
		gridPanel.setScroll(Scroll.miniscroll);
		gridPanel.setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		return gridPanel;
    }
    
    /**
     * 返回一个默认样式的分页栏
     */
    public static PagePanel getDefaultPagePanel(){
    	PagePanel pagePanel = new PagePanel(ID_PANEL_PAGE);
		pagePanel.setFace(PagePanel.FACE_OFFICE);
		pagePanel.setStyle("padding:10px 30px 10px 30px;");
		pagePanel.setAlign(Align.center);
		pagePanel.setClickCommand(new AjaxCommand(ViewFactory.ID_CMD_PAGE,""));
		return pagePanel;
    }
    
    /**
     * 返回一个默认样式的按钮栏
     */
    public static ButtonBarPanel getDefaultButtonBarPanel(){
    	ButtonBarPanel popOper = new ButtonBarPanel(ID_PANEL_BUTTON_BAR);
		popOper.setAlign(Align.left);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop bg-lowest");
		return popOper;
    }
    
    /**
     * 返回一个默认样式的标题栏
     */
    public static HtmlPanel getDefaultTitlePanel(){
    	HtmlPanel title=new HtmlPanel(ID_PANEL_TITLE,"");
		title.setStyleClass("bg-lowest");
		title.setStyle("font-size:18px;line-height:36px");
		return title;
    }
    
    /**
     * 返回一个默认样式的form面板
     */
    public FormPanel getDefaultFormPanel(){
    	FormPanel form = new FormPanel(ID_PANEL_FORM);
    	form.setStyle("padding:10px 10px 0px 2px;");
    	form.setScroll(Scroll.miniscroll);
		return form;
    }
    
    /**
     * 返回一个默认样式的tree面板
     */
    public TreePanel getDefaultTreePanel(){
    	TreePanel tree=new TreePanel(ID_PANEL_TREE);
		tree.setScroll(Scroll.miniscroll);
		return tree;
    }
    
    public String getRow(List<String> list){
    	if(Utils.isEmpty(list)){
    		return "*";
    	}
    	StringBuilder build = new StringBuilder();
    	for(String s:list){
    		if(Utils.notEmpty(s)){
    			build.append(s);
    			build.append(",");
    		}
    	}
    	if(build.lastIndexOf(",")>0){
    		build.deleteCharAt(build.lastIndexOf(","));
    	}
    	return build.toString();
    }
    
	private static DFishViewFactory factory;
	public static DFishViewFactory getInstance(){
		return factory;
	}
	
	static
	{
		factory = new DFishViewFactory();
	}
}
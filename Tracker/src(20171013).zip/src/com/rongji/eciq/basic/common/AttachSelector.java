package com.rongji.eciq.basic.common;

import java.util.List;

import com.rongji.dfish.plugins.form.DfishAttachSelector;
import com.rongji.dfish.plugins.form.UploadItem;

/**
 * 文件选择控件
 * 
 * @author whf
 * 
 */
public class AttachSelector extends DfishAttachSelector {

	public AttachSelector(String name, String title, String attachIds,
			Boolean multiple) {
		super(name, title, attachIds, multiple);
		initUrls();
	}

	public AttachSelector(String name, String title, List<UploadItem> uploaded) {
		super(name, title, uploaded);
		initUrls();
	}

	public AttachSelector(String name, String title, String attachIds,
			Boolean multiple, Boolean notDeleteFiles) {
		super(name, title, attachIds, multiple, notDeleteFiles);
		initUrls();
	}

	public AttachSelector(String name, String title, String linkType,
			String linkKeyword) {
		super(name, title, linkType, linkKeyword);
		initUrls();
	}

	private void initUrls() {
		uploadUrl = "files/upload";
		downloadUrl = "files/download?fileId=$id";
		deleteUrl = "files/deleteFile?fileId=$id";
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	public void setDownloadUrl(String downLoadUrl) {
		this.downloadUrl = downLoadUrl;
	}

	public void setDeleteUrl(String deleteUrl) {
		this.deleteUrl = deleteUrl;
	}
}

package com.rongji.eciq.basic.common;

import java.lang.annotation.*;


@Retention(RetentionPolicy.RUNTIME) // 注解会在class字节码文件中存在，在运行时可以通过反射获取到
@Target(ElementType.FIELD)//定义注解的作用目标**作用范围字段、枚举的常量/方法
public @interface FieldMeta {
	/**
	 * 添加使用字段
	 * @return
	 */
	boolean create() default false;
	/**
	 * 编辑使用字段
	 * @return
	 */
	boolean edit() default false;
	/**
	 * 详细信息使用字段
	 * @return
	 */
	boolean detail() default true;
	/**
	 * 查找使用字段
	 * @return
	 */
	boolean search() default false;
	/**
	 * 界面列表展示使用字段使用字段
	 * @return
	 */
	boolean gridShow() default false;
	/**
	 * 数据库字段长度
	 * @return
	 */
	int length() default 50;
	/**
	 * 控件类型
	 * @return
	 */
	String type() default "Text";
	/**
	 * 中文名称
	 * @return
	 */
	String CName() default "";
	/**
	 * 字段名称(控件ID)
	 * @return
	 */
	String name() default "";
	/**
	 * select选框值
	 * @return
	 */
	String selectValue() default "1=福建#2=厦门#3=福州#4=莆田";

}
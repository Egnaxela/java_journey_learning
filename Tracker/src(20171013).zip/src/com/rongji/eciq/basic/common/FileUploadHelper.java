/**  
 * FileName: FileUploadHelper.java    
 * @Description: 系统文件上传辅助工具类
 * Company       rongji
 * @version      1.0
 * @author:      黄庆炬
 * @version:     1.0
 * Createdate:   2017-5-06 3:12:14  
 *  
 */  
package com.rongji.eciq.basic.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rongji.dfish.plugins.form.UploadItem;

/**  
 * Description: 系统文件上传辅助工具类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     黄庆炬 
 * @version:    1.0  
 * Create at:   2017-5-06 下午3:12:14  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-06    黄庆炬                      1.0        创建系统文件上传辅助工具类
 */
public class FileUploadHelper {
	
	/**
	 * 将文件转换为byte数组
	 * @param file
	 * @return
	 */
	public static byte[] getFileToBytes(File file) {
		byte[] buffer = null;
		try {
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
			byte[] b = new byte[1000];
			int n;
			while ((n = fis.read(b)) != -1) {
				bos.write(b, 0, n);
			}
			fis.close();
			bos.close();
			buffer = bos.toByteArray();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer;
	}
	/**
	 * 存储文件以及获取文件ID（即存储文件名）
	 * @param fileIDs
	 * @param request
	 */
	public static void saveToFileSystem(List<String> fileIDs,
			HttpServletRequest request) {
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		
		String ufiles = request.getParameter("ufiles");
		// 获取已经存在的文件
		UploadItem[] items = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		for (UploadItem item : items) {
			try {
				fileIDs.add(item.getId());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
//	/**
//	 * 存储文件以及获取文件ID（即存储文件名,老式方法）
//	 * @param fileIDs
//	 * @param request
//	 */
//	public static void getFileIDS(List<String> fileIDs,
//			HttpServletRequest request) {
//		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
//		Map<String, MultipartFile> files = null;
//		try {
//			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
//			// 获得文件：
//			files = multipartRequest.getFileMap();
//		} catch (Exception e) {
//			System.out.println("获取文件失败-----FileUploadHelper--【getFileIDS】");
//		}
//		Set<Entry<String, MultipartFile>> sets = files.entrySet();
//		Iterator<Entry<String, MultipartFile>> itr = sets.iterator();
//		MultipartFile file = null;
//		fileIDs = new ArrayList<String>();// 上传文件ID
//
//		while (itr.hasNext()) {
//			file = itr.next().getValue();
//			file.getContentType();
//			String pre = UUID.randomUUID().toString().replaceAll("-", "");
//			String suffix = file.getOriginalFilename().substring(
//					file.getOriginalFilename().lastIndexOf("."));// 文件后缀名
//			File f = null;
//			try {
//				f = File.createTempFile(pre, suffix);
//				file.transferTo(f);
//				FileManager fm = FileManagerHolder.getFileManager();
//				byte[] fileByte = getFileToBytes(f);
//				try {
//					fileIDs.add(fm.upload(fileByte, suffix));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			} catch (IOException e1) {
//				e1.printStackTrace();
//			}
//
//		}
//
//	}

}

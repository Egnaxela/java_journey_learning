/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     黄国海  
 * @version:    1.0
 * Createdate:   2016-12-30 上午10:04:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2016-12-30   黄国海      1.0         1.0 Version  
 */  


package com.rongji.eciq.basic.common;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hwpf.usermodel.Fields;

import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.View;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.engines.xmltmpl.form.Textarea;
import com.rongji.eciq.basic.persistence.DspBasicCompHandleLog;

  
    /**        
 * Title: PopupPanelHelper.java    
 * Description: 描述
 * @author huangguohai       
 * @created 2016-12-30 上午10:04:55    
 */

public class PopupPanelHelper {
	public static final String P_ROOT = "p_root";
	public static final String P_TOP = "p_top";
	public static final String P_TITLE = "p_title";
	public static final String P_BTN = "p_btn";
	public static final String P_BBTN = "p_bbtn";
	public static final String P_CENTER_BTN = "p_center_btn";
	public static final String P_CONTENT = "p_content";
	public static final String P_SEARCH = "p_search";
	public static final String P_GRID = "p_grid";
	public static final String P_PAGE = "p_page";
	public static final String P_FORM = "p_form";
	public static final String P_LEFT_PAGE = "p_left_page";
	public static final String P_TAB_BTN = "p_tab_btn";
	public static final String P_FILM = "p_film";
	
	/**
	 * 
	     * @discription 新建弹出框
	     * @author huangguohai       
	     * @created 2016-12-30 上午11:43:29     
	     * @param object
	     * @param title
	     * @param pvf
	     * @return
	     * @throws ClassNotFoundException
	 */
	public View createPopupView(String title,Object obj) throws ClassNotFoundException{
		BaseView view = new BaseView();
		Field[] fs = obj.getClass().getDeclaredFields();
		VerticalPanel rootPanel = createVerticalPanel(view,fs);
		return view;
	}
	
//	/**
//	 * 
//	     * @discription 查询弹出框
//	     * @author huangguohai       
//	     * @created 2016-12-30 上午11:43:29     
//	     * @param object
//	     * @param title
//	     * @param pvf
//	     * @return
//	     * @throws ClassNotFoundException
//	 */
//	public View searchPopupView(String title,PopVFields pvf){
//		BaseView view = new BaseView();
//		String[] searchS= pvf.searchFields();
//		VerticalPanel rootPanel = createVerticalPanel(view,searchS);
//		return view;
//	}
//	
//	/**
//	 * 
//	     * @discription 详细信息弹出框
//	     * @author huangguohai       
//	     * @created 2016-12-30 上午11:43:29     
//	     * @param object
//	     * @param title
//	     * @param pvf
//	     * @return
//	     * @throws ClassNotFoundException
//	 */
//	public View detailPopupView(String title,PopVFields pvf){
//		BaseView view = new BaseView();
//		String[] detailS= pvf.detailFields();
//		VerticalPanel rootPanel = createVerticalPanel(view,detailS);
//		return view;
//	}
//	
//	/**
//	 * 
//	     * @discription 编辑弹出框
//	     * @author huangguohai       
//	     * @created 2016-12-30 上午11:43:29     
//	     * @param object
//	     * @param title
//	     * @param pvf
//	     * @return
//	     * @throws ClassNotFoundException
//	 */
//	public View editPopupView(String title,PopVFields pvf){
//		BaseView view = new BaseView();
//		String[] detailS= pvf.editFields();
//		VerticalPanel rootPanel = createVerticalPanel(view,detailS);
//		return view;
//	}
	
	/**
	 * 
	     * @discription 创建verticalpanel
	     * @author huangguohai       
	     * @created 2016-12-30 上午11:53:47     
	     * @param view
	     * @param createS
	     * @return
	 */
	public VerticalPanel createVerticalPanel(BaseView view,Field[] fs){
		VerticalPanel rootPanel = new VerticalPanel(P_ROOT,"*,40");
		view.setRootPanel(rootPanel);
		FormPanel formPanel = new FormPanel(P_FORM);
		int line=0;
		for(Field d : fs){
//			String[] elements = createS[i].split("|");
			String type = ((FieldMeta)d.getAnnotation(FieldMeta.class)).type();
			boolean create = ((FieldMeta)d.getAnnotation(FieldMeta.class)).create();
			int length = ((FieldMeta)d.getAnnotation(FieldMeta.class)).length();
			String CName = ((FieldMeta)d.getAnnotation(FieldMeta.class)).CName();
			String name = ((FieldMeta)d.getAnnotation(FieldMeta.class)).name();
			String value = ((FieldMeta)d.getAnnotation(FieldMeta.class)).selectValue();
			if(create){
				if(type.equals("Text")){
					Text eleName = new Text(name, CName, "", length);
					eleName.setShortcutInputSupported(false);
					eleName.setNotnull(true);
					formPanel.add(eleName);
				}else if (type.equals("Textarea")){
					Textarea eleName = new Textarea(name, CName, "", length);
					eleName.setNotnull(true);
					eleName.setRowHeight(5);
					formPanel.add(eleName);
				}else if (type.equals("Select")){
					String[] va = value.split("#");
					List<Object[]> options = new ArrayList<Object[]>();
					
					for(int i=0;i<va.length;i++){
						if(va[i].contains("=")){
							String[] lv = va[i].split("=");
							options.add(new Object[]{lv[0],lv[1]});
						}else{
							options.add(new Object[]{i,va[i]});
						}
					}
					Select eleName = new Select(name, CName,
							 new Object[] { null } , options);
					eleName.setWidth("200");
					formPanel.add(eleName);
				}
				
			}
			
		}
		rootPanel.addSubPanel(formPanel);
		ButtonBarPanel popOper = new ButtonBarPanel(P_BBTN);

		ClickButton clk = new ClickButton(null, "  确定  ",
				"VM(this).cmd('create')");
		clk.setMain(true);
		ClickButton close = new ClickButton(null, "  取消  ",
				"DFish.close(this);");
		popOper.addButton(clk).addButton(close);
		rootPanel.addSubPanel(popOper);
		return rootPanel;
	}

}

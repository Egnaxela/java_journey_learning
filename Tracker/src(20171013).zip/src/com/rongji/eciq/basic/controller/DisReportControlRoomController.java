package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicWorkReport;
import com.rongji.eciq.basic.service.DisReportControlRoomService;
import com.rongji.eciq.basic.view.DisreportControlRoomView;
import com.rongji.eciq.basic.view.ViewTemplateControlRoom;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.PubService;

@Controller
@RequestMapping("/controlRoom")
public class DisReportControlRoomController extends ExceptionCaptureController{
	@Autowired
	private DisReportControlRoomService controlRoomService;

	@RequestMapping("/doubleClick")
	@ResponseBody
	public void doubleClick(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reporterId = request.getParameter("reporterId");
		DspBasicWorkReport dwr=controlRoomService.getReportDetailById(reporterId);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		dwr.setReporterDateString(sdf.format(dwr.getReporterDate()));
//		dwr.setReporterYear(dwr.getReporterYear());
		List<UploadItem> items=controlRoomService.getItemsByReporterId(reporterId);
		HttpSession session=request.getSession();
		boolean isReturn=(Boolean)session.getAttribute("isReturn");
		BaseView view =DisreportControlRoomView.buildCheckView(dwr,items,isReturn);
		outPutXML(response, view);
	}
	/**
	 * 报告审批通过
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/marlboro")
	@ResponseBody
	public Object marlboro(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reporterId = request.getParameter("reporterId");
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		
		DspBasicWorkReport dwr=controlRoomService.getReportDetailById(reporterId);
		
		if(dwr.getReporterStatus().trim()=="1"||dwr.getReporterStatus().trim().equals("1")){
			outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return null;
		}
		dwr.setReturnPerson(curUser.getUserId());
		dwr.setReturnTime(new Date());
		dwr.setReporterReturnReason("");
		controlRoomService.saveMarlboro(dwr);
	
		
		Page page = PubService.getPage(request);
		page.setPageSize(10);
		List<DspBasicWorkReport> datas = controlRoomService.findReportList(page,FrameworkHelper.getLoginUser(request));
		
		
		
		
	   BaseView view=ViewTemplateControlRoom.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisreportControlRoomView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"controlRoom/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisreportControlRoomView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplateControlRoom.getInfoAlert("审批通过成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
		
	}
	/**
	 * 报告退回原因
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/reportReturn")
	@ResponseBody
	public void reportReturn(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reporterId = request.getParameter("reporterId");
		DspBasicWorkReport dwr=controlRoomService.getReportDetailById(reporterId);
		
		if(dwr.getReporterStatus()=="1"||dwr.getReporterStatus().equals("1")){
			outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return ;
		}
		
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		
		cg.add(new DialogCommand("reportReturn", ViewFactory.ID_DIALOG_STANDARD,
		"请填写退回原因", "f_reportReturn", DialogCommand.WIDTH_MEDIUM,
		DialogCommand.HEIGHT_MEDIUM, DialogCommand.POSITION_MIDDLE,
		"vm:|controlRoom/reportReturnView?reporterId="+dwr.getReporterId()));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	@RequestMapping("/reportReturnView") 
	@ResponseBody
	public void reportReturnView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =DisreportControlRoomView.buildReposrtReturnView(request);
		outPutXML(response, view);
	}
	/**
	 * 保存退回原因
	* <p>描述:</p>
	* @return
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/saveReportReturnReason")
	@ResponseBody
	public Object saveReportReturnReason() throws Exception {
		HttpServletRequest request = getRequest();
		String reporterReturnReason = request.getParameter("reportReturnReason");
		String reporterId=request.getParameter("reporterId");
		String returnPerson = request.getParameter("returnPerson");
		String returnTimeString = request.getParameter("returnTimeString");
		Date returnTime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(returnTimeString);
		
		DspBasicWorkReport dwr=controlRoomService.getReportDetailById(reporterId);
		dwr.setReporterReturnReason(reporterReturnReason);
		dwr.setReturnPerson(returnPerson);
		dwr.setReturnTime(returnTime);
		dwr.setReporterStatus("1");
		controlRoomService.saveReportReturnReason(dwr);
		
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		
		List<DspBasicWorkReport> datas = controlRoomService.findReportListBySession(request,page);
		BaseView view=ViewTemplateControlRoom.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisreportControlRoomView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"controlRoom/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisreportControlRoomView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_controlRoom");
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
	
	@RequestMapping("/search")
	@ResponseBody
	public Object search(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession session=request.getSession();
		session.setAttribute("reportName", request.getParameter("reportName").replace(",", ""));
		session.setAttribute("reporterUnitName", request.getParameter("unitName").replace(",", ""));
		session.setAttribute("fromtime", request.getParameter("fromtime"));
		session.setAttribute("totime", request.getParameter("totime"));
		session.setAttribute("reporterStatus", request.getParameter("reporterStatus"));
		
		Page page = PubService.getPage(request);
		page.setPageSize(10);
		List<DspBasicWorkReport> datas = controlRoomService.findReportListBySearch(request,page);
		BaseView view=ViewTemplateControlRoom.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisreportControlRoomView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"controlRoom/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisreportControlRoomView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_controlRoom");
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}


	@RequestMapping("/turnPage")
	@ResponseBody
	public Object turnPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Page page = CommonsHelper.getPage(request);
		page.setPageSize(10);
	
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
      
		List<DspBasicWorkReport> datas = controlRoomService.findReportListBySession(request, page);
		
        BaseView view = ViewTemplateControlRoom.buildIndexHasBtnView(false);
        GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_GRID);
        UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisreportControlRoomView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"controlRoom/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisreportControlRoomView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_controlRoom");
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
	
}

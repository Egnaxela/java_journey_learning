package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicWorkReport;
import com.rongji.eciq.basic.service.DisReportControlRoomService;
import com.rongji.eciq.basic.service.DisReportService;
import com.rongji.eciq.basic.view.DisReportView;
import com.rongji.eciq.basic.view.DisreportControlRoomView;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.system.common.util.AuthorityHelper;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.PubService;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;
@Controller
@RequestMapping("/disreport")
public class DisReportController extends ExceptionCaptureController {
	@Autowired
	private DisReportService disreportService;
	
	
	private static final Logger LOG = Logger.getLogger(DisReportController.class);
	boolean isFlag=true;//是否具有监审室权限的标志
	@RequestMapping("/index")
	@ResponseBody
	public void  index(HttpServletRequest request,HttpServletResponse response){
		
		HttpSession session=request.getSession();
		session.setAttribute("reportName", request.getParameter(""));
		session.setAttribute("reporterUnitName", request.getParameter(""));
		session.setAttribute("fromtime", request.getParameter(""));
		session.setAttribute("totime", request.getParameter(""));
		session.setAttribute("reporterStatus", request.getParameter(""));
		
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicWorkReport> datas = disreportService.findReportList(page,curUser.getUserId());
		isFlag=AuthorityHelper.searchUserBtnExist(curUser.getUserId(),"001");
		BaseView view =DisReportView.buildeNewIndexView(datas,page,true,isFlag);
		outPutXML(response, view);
	}

	@RequestMapping("/showEdit")
	@ResponseBody
	public void showEdit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
	
		BaseView view =DisReportView.buildShowEditView(curUser);
		LOG.info("进入新建界面");
		outPutXML(response, view);
	}
	/**
	 * 保存报告
	* <p>描述:</p>
	* @return
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/saveReport")
	@ResponseBody
	public Object saveReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reportBrief = request.getParameter("reportBrief");
		String reportTitle = request.getParameter("reportTitleText");
		String reporterUnit = request.getParameter("reporterUnitText");
		String reporterContent = request.getParameter("reporterContent");
		String reporterDate = request.getParameter("reporterDateText");
		String yearSelect = request.getParameter("yearSelect");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=sdf.parse(reporterDate);
		String year=yearSelect.substring(0,yearSelect.length()-1);
		if(reporterContent.trim()==""){
			CommandGroup cg = new CommandGroup("");
			CommandGroup cg1 = new CommandGroup("");
			cg1.setPath("/f_main");
			cg.add(cg1);
			cg.add(ViewTemplate.getTipAlert("对不起！报告内容不能为空",DialogPosition.middle));
			return cg;	
		}
		if(disreportService.exitReport(curUser, year)){
			CommandGroup cg = new CommandGroup("");
			CommandGroup cg1 = new CommandGroup("");
			cg1.setPath("/f_main");
			cg.add(cg1);
			cg.add(ViewTemplate.getTipAlert("对不起！该报告已经上传",DialogPosition.middle));
			return cg;	
		}
         
		String ufiles = request.getParameter("ufiles");
		if (ufiles == null || "".equals(ufiles)) {
			FrameworkHelper.outPutXML(response, new CommandGroup("123"));
			return null;
		}
		// 获取已经存在的文件
		UploadItem[] items = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		List<String> itemId=new ArrayList<String>();
		for (UploadItem item : items) {
			itemId.add(item.getId());
		}
		
		DspBasicWorkReport dwr=new DspBasicWorkReport();
		String reporterId = UUID.randomUUID().toString().replaceAll("-", "");
		dwr.setReporterCode(curUser.getUserId());
	
//		SimpleDateFormat dateFormater=new SimpleDateFormat("yyyy-MM-dd");
		dwr.setReporterDate(date);
		dwr.setReporterId(reporterId);
		dwr.setReporterName(curUser.getUserName());
		dwr.setReporterStatus("0");
		dwr.setReporterUnit(reporterUnit);
		dwr.setReporterUnitCode(curUser.getDeptNo());
		dwr.setReportFileId(UUID.randomUUID().toString().replaceAll("-", ""));
//		dwr.setReportTitle(yearSelect+curUser.getUserName()+"的述职报告");
		dwr.setReportTitle(curUser.getUserName()+"年度述职报告("+year+")");
		dwr.setReportBrief(reportBrief);
		dwr.setReporterContent(reporterContent);
		dwr.setReporterYear(year);
		
		disreportService.saveReport(dwr,itemId,curUser.getUserId());
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicWorkReport> datas = disreportService.findReportList(page,FrameworkHelper.getLoginUser(request));
		
//		BaseView view =DisReportView.buildeNewIndexView(datas,page,false);
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,isFlag));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;	
	}
	/**
	 * 暂存报告上交
	* <p>描述:</p>
	* @return
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/saveTemporaryStorage")
	@ResponseBody
	public Object saveTemporaryStorage(HttpServletRequest request, HttpServletResponse response) throws Exception {
         String reporterId = request.getParameter("reporterId");
         String reportBrief = request.getParameter("reportBrief");
         
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		dwr.setReporterStatus("0");
	    disreportService.updateReport(dwr);
	
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		
		List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request,page);
		BaseView view=ViewTemplate.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplate.getInfoAlert("提交成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
		/**
	 * 暂存报告
	* <p>描述:</p>
	* @return
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/temporaryStorage")
	@ResponseBody
	public Object temporaryStorage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reportBrief = request.getParameter("reportBrief");
		String reportTitle = request.getParameter("reportTitleText");
		String reporterUnit = request.getParameter("reporterUnitText");
		String reporterContent = request.getParameter("reporterContent");
		String reporterDate = request.getParameter("reporterDateText");
		String yearSelect = request.getParameter("yearSelect");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=sdf.parse(reporterDate);
		String year=yearSelect.substring(0,yearSelect.length()-1);
		if(reporterContent.trim()==""){
			CommandGroup cg = new CommandGroup("");
			CommandGroup cg1 = new CommandGroup("");
			cg1.setPath("/f_main");
			cg.add(cg1);
			cg.add(ViewTemplate.getTipAlert("对不起！报告内容不能为空",DialogPosition.middle));
			return cg;	
		}
		if(disreportService.exitReport(curUser, year)){
			CommandGroup cg = new CommandGroup("");
			CommandGroup cg1 = new CommandGroup("");
			cg1.setPath("/f_main");
			cg.add(cg1);
			cg.add(ViewTemplate.getTipAlert("对不起！该报告已经上传",DialogPosition.middle));
			return cg;	
		}
         
		String ufiles = request.getParameter("ufiles");
		if (ufiles == null || "".equals(ufiles)) {
			FrameworkHelper.outPutXML(response, new CommandGroup("123"));
			return null;
		}
		// 获取已经存在的文件
		UploadItem[] items = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		List<String> itemId=new ArrayList<String>();
		for (UploadItem item : items) {
			itemId.add(item.getId());
		}
		
		DspBasicWorkReport dwr=new DspBasicWorkReport();
		String reporterId = UUID.randomUUID().toString().replaceAll("-", "");
		dwr.setReporterCode(curUser.getUserId());
	
//		SimpleDateFormat dateFormater=new SimpleDateFormat("yyyy-MM-dd");
		dwr.setReporterDate(date);
		dwr.setReporterId(reporterId);
		dwr.setReporterName(curUser.getUserName());
		dwr.setReporterStatus("2");
		dwr.setReporterUnit(reporterUnit);
		dwr.setReporterUnitCode(curUser.getDeptNo());
		dwr.setReportFileId(UUID.randomUUID().toString().replaceAll("-", ""));
//		dwr.setReportTitle(yearSelect+curUser.getUserName()+"的述职报告");
		dwr.setReportTitle(curUser.getUserName()+"年度述职报告("+year+")");
		dwr.setReportBrief(reportBrief);
		dwr.setReporterContent(reporterContent);
		dwr.setReporterYear(year);
		
		disreportService.saveReport(dwr,itemId,curUser.getUserId());
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicWorkReport> datas = disreportService.findReportList(page,FrameworkHelper.getLoginUser(request));
		
//		BaseView view =DisReportView.buildeNewIndexView(datas,page,false);
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,isFlag));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;	
	}
	
/*	*//**
	 * 查看报告的详细信息
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 *//*
	@RequestMapping("/check")
	@ResponseBody
	public void check(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userId = Utils.getParameter(request, "userId");
		String reporterId = request.getParameter("reporterId");
//		DspBasicWorkReport dwr=new DspBasicWorkReport();
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		List<UploadItem> items=disreportService.getItemsByReporterId(reporterId);
		BaseView view =DisReportView.buildCheckView(dwr,items);
		outPutXML(response, view);
	}*/
	@RequestMapping("/doubleClick")
	@ResponseBody
	public void doubleClick(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reporterId = request.getParameter("reporterId");
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		dwr.setReporterDateString(sdf.format(dwr.getReporterDate()));
		List<UploadItem> items=disreportService.getItemsByReporterId(reporterId);
		BaseView view =DisReportView.buildCheckView(dwr,items,curUser.getUserId());
		outPutXML(response, view);
	}
	/**
	 * 修改界面
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/updateReport")
	@ResponseBody
	public void showUpdate(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reporterId = request.getParameter("reporterId");
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		List<UploadItem> items=disreportService.getItemsByReporterId(reporterId);
		BaseView view =DisReportView.buildUpdateView(dwr,items,curUser);
		LOG.info("进入修改界面");
		outPutXML(response, view);
	}
	/**
	 * 保存修改
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/saveUpdate")
	@ResponseBody
	public Object showSaveUpdate(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reporterId = request.getParameter("reporterId");
		String reportBrief = request.getParameter("reportBrief");
		String reporterContent = request.getParameter("reporterContent");
		String reporterDate = request.getParameter("reporterDateText");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=sdf.parse(reporterDate);
		
		
		String ufiles = request.getParameter("ufiles");
		if (ufiles == null || "".equals(ufiles)) {
			FrameworkHelper.outPutXML(response, new CommandGroup("123"));
			return null;
		}
		// 获取已经存在的文件
		UploadItem[] items = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		List<String> itemId=new ArrayList<String>();
		for (UploadItem item : items) {
			itemId.add(item.getId());
		}
		
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		dwr.setReporterStatus("0");
		dwr.setReporterContent(reporterContent);
		dwr.setReportBrief(reportBrief);
		dwr.setReporterDate(date);
		disreportService.updateReport(dwr);
		List<DspFileManage> dfms=disreportService.findDspFileManageByBizid(dwr.getReportFileId());
		for(int i=0;i<dfms.size();i++){
			disreportService.deleteObject(dfms.get(i));
		}
		
		
		Iterator<String> it=itemId.iterator();
	    while(it.hasNext()){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileId(it.next());
			fileManage.setBizId(dwr.getReportFileId());
			fileManage.setOperTime(dwr.getReporterDate());
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setUserId(curUser.getUserId());
//			fileManage.setFileContent("zhangyang"+new Date());
			disreportService.saveObject(fileManage);
		}
		
		
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request,page);;
		
//		BaseView view =DisReportView.buildeNewIndexView(datas,page,false);
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,isFlag));
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;	
	}
	/**
	 * 报告审批通过
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/marlboro")
	@ResponseBody
	public Object marlboro(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reporterId = request.getParameter("reporterId");
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		
		 if(dwr.getReporterStatus().trim()=="1"||dwr.getReporterStatus().trim().equals("1")){
			outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return null;
		}
		dwr.setReturnPerson(curUser.getUserId());
		dwr.setReturnTime(new Date());
		dwr.setReporterReturnReason("");
		disreportService.saveMarlboro(dwr);
	
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		
		List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request,page);
		BaseView view=ViewTemplate.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplate.getInfoAlert("审批通过成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
//		List<DspBasicWorkReport> datas = disreportService.findReportList(page,FrameworkHelper.getLoginUser(request));
//		
//		CommandGroup cg = new CommandGroup("");
//		CommandGroup cg1 = new CommandGroup("");
//		cg1.setPath("/f_main");
//		
//		UpdateCommand up = new UpdateCommand("");
//		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,true));
//		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
//		cg1.add(up);
//		cg.add(cg1);
//		cg.add(ViewTemplate.getInfoAlert("审批通过成功"));
//		return cg;	
	}
	/**
	 * 报告退回原因
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/reportReturn")
	@ResponseBody
	public void reportReturn(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reporterId = request.getParameter("reporterId");
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		
		 if(dwr.getReporterStatus()=="1"||dwr.getReporterStatus().equals("1")){
			outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return ;
		}
		
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		
		cg.add(new DialogCommand("reportReturn", ViewFactory.ID_DIALOG_STANDARD,
		"请填写退回原因", "f_reportReturn", DialogCommand.WIDTH_MEDIUM,
		DialogCommand.HEIGHT_MEDIUM, DialogCommand.POSITION_MIDDLE,
		"vm:|disreport/reportReturnView?reporterId="+dwr.getReporterId()));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	@RequestMapping("/reportReturnView") 
	@ResponseBody
	public void reportReturnView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =DisReportView.buildReposrtReturnView(request);
		outPutXML(response, view);
	}
	/**
	 * 保存退回原因
	* <p>描述:</p>
	* @return
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/saveReportReturnReason")
	@ResponseBody
	public Object saveReportReturnReason() throws Exception {
		HttpServletRequest request = getRequest();
		String reporterReturnReason = request.getParameter("reportReturnReason");
		String reporterId=request.getParameter("reporterId");
		String returnPerson = request.getParameter("returnPerson");
		String returnTimeString = request.getParameter("returnTimeString");
		Date returnTime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(returnTimeString);
		
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		dwr.setReporterReturnReason(reporterReturnReason);
		dwr.setReturnPerson(returnPerson);
		dwr.setReturnTime(returnTime);
		dwr.setReporterStatus("2");
		disreportService.saveReportReturnReason(dwr);
		
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		
		List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request,page);
		BaseView view=ViewTemplate.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
//		List<DspBasicWorkReport> datas = disreportService.findReportList(page,FrameworkHelper.getLoginUser(request));
//		
//		CommandGroup cg = new CommandGroup("");
//		CommandGroup cg1 = new CommandGroup("");
//		cg1.setPath("/f_main");
//		
//		UpdateCommand up = new UpdateCommand("");
//		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,true));
//		cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
//		cg1.add(up);
//		cg.add(cg1);
//		cg.add(ViewTemplate.getInfoAlert("保存成功"));
//		return cg;	
		
	}
	/**
	 * 删除报告
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author zhangyang
	 */
	@RequestMapping("/reportDelete")
	@ResponseBody
	public Object reportDelete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String[] ids = request.getParameterValues("selectItem");
		disreportService.deleteReportByIds(ids);
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		
		
		List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request,page);
		BaseView view=ViewTemplate.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		cg.add(ViewTemplate.getInfoAlert("删除成功"));
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
//		List<DspBasicWorkReport> datas = disreportService.findReportList(page,curUser.getUserId());
//		
//		CommandGroup cg = new CommandGroup("");
//		CommandGroup cg1 = new CommandGroup("");
//		cg1.setPath("/f_main");
//		
//		UpdateCommand up = new UpdateCommand("");
//		up.setContent(DisReportView.buildeNewIndexView(datas,page,true,true));
//		cg1.add(up);
//		cg.add(cg1);
//		cg.add(ViewTemplate.getInfoAlert("删除成功"));
//		return cg;	
	}
	@RequestMapping("/search")
	@ResponseBody
	public Object search(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession session=request.getSession();
 
//		session.setAttribute("reporterUnitName", request.getParameter("unitName").replace(",", ""));
//		session.setAttribute("fromtime", request.getParameter("fromtime"));
		session.setAttribute("reporterUnitName", request.getParameter(""));
		session.setAttribute("fromtime", request.getParameter(""));
		session.setAttribute("totime", request.getParameter("totime"));
		session.setAttribute("reporterStatus", request.getParameter("reporterStatus"));
		
		
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicWorkReport> datas = disreportService.findReportListBySearch(request,page);
		BaseView view=ViewTemplate.buildIndexHasBtnView(false);
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}


	@RequestMapping("/turnPage")
	@ResponseBody
	public Object turnPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Page page = CommonsHelper.getPage(request);
		page.setPageSize(8);
		
		HttpSession session=request.getSession();
		
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
//        List<DspBasicWorkReport> datas = disreportService.findReportList(page,curUser.getUserId());
      
		 List<DspBasicWorkReport> datas = disreportService.findReportListBySession(request, page);
		
        BaseView view = ViewTemplate.buildIndexHasBtnView(false);
        GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
        UpdateCommand ucP = new UpdateCommand("");
		ucP.setContent(DisReportView.updatePagepanel(view, page,datas));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"disreport/turnPage?cp=$0");

		UpdateCommand up = new UpdateCommand("");
		up.setContent(DisReportView.buildGrid(grid, datas));// 设置内容
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(turnPage);
		CommandGroup cg = new CommandGroup("up");
		cg.setPath("/f_main");
		cg.add(up);
		cg.add(ucP);
		cg.add(cd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
	
/*	@RequestMapping("/delete")
	@ResponseBody
	public Object delete() throws Exception {
		HttpServletRequest request = getRequest();
		String loginUser = FrameworkHelper.getLoginUser(request);
		FilterParam fp = UserView.getFilterParam(request);
//		String encOrgCode = filterParam.getValueAsString("orgCodeQuery");
		String orgCode=request.getParameter("orgCode");
		String cp = request.getParameter("cp");
		Integer count = 1;
		if (Utils.isNumber(cp)) {
			count = Integer.parseInt(cp);
		}
		Page page = CommonsHelper.getPage(request);
		page.setCurrentPage(count);

		SysUser user = null;
		String[] idToDelete = request.getParameterValues("selectItem");
		if (idToDelete != null) {
			for (String usersId : idToDelete) {
				
				disreportService.deleteUser(usersId, loginUser);			
			}
		}
		String userId = request.getParameter("userId");
		if (Utils.notEmpty(userId)) {
//			user = userService.getUserById(userId);
			disreportService.deleteUser(userId, loginUser);
		}
		if (Utils.isEmpty(userId) && idToDelete == null) {
			return ViewTemplate.getWarnAlert("请选择需要删除的数据!");
		}
		CommandGroup cg = new CommandGroup("cg");
		Panel panel4update=null;
//		FilterParam filterParam = UserView.getFilterParam(request);
//		panel4update=UserView.bulidEditContent(orgCode,page,fp,loginUser);
		UpdateCommand up=new UpdateCommand(null);
		List<Object []> datas = disreportService.findUserList(page,loginUser);
		up.setContent(UserView.buildeNewIndexView(datas,fp,page));
		UpdateCommand uc2 = new UpdateCommand("");	
	    cg.add(up);
		cg.add(ViewTemplate.getInfoAlert("删除成功"));

		return cg;
		HttpServletRequest request = getRequest();
		String reporterCode = request.getParameter("reporterCode");
		String cp = request.getParameter("cp");
		
		return null;
	}*/
	
	@RequestMapping("/controlRoom")
	@ResponseBody
	public void controlRoom(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session=request.getSession();
		session.setAttribute("reportName", request.getParameter(""));
		session.setAttribute("reporterUnitName", request.getParameter(""));
		session.setAttribute("fromtime", request.getParameter(""));
		session.setAttribute("totime", request.getParameter(""));
		session.setAttribute("reporterStatus", request.getParameter(""));
		
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		Page page = PubService.getPage(request);
		page.setPageSize(10);
	
		 DisReportControlRoomService controlRoomService=new DisReportControlRoomService();
		List<DspBasicWorkReport> datas = controlRoomService.findReportList(page,curUser.getUserId());
		
		boolean isReturn=AuthorityHelper.searchUserBtnExist(curUser.getUserId(),"002");
		session.setAttribute("isReturn", isReturn);
		BaseView view =DisreportControlRoomView.buildeNewIndexView1(datas,page);
		outPutXML(response, view);
	}
	
	@RequestMapping("/downloadModel")
	@ResponseBody
	public void downloadModel(HttpServletRequest request,HttpServletResponse response){
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("TEMPLATE_UPLOAD");
		List<UploadItem> items = disreportService.getDownloadItems(String.valueOf(status.get(4)[0]));
		BaseView view = DisReportView.buildDownloadView(items, String.valueOf(status.get(4)[1])+"的模板文件");
		outPutXML(response, view);
	}
}

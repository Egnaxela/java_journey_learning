package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicReportStat;
import com.rongji.eciq.basic.service.DspBasicReportStatControlRoomService;
import com.rongji.eciq.basic.view.DspBasicReportStatControlRoomView;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.PubService;
@Controller
@RequestMapping("/dspBasicReportStatControlRoom")
public class DspBasicReportStatControlRoomController extends ExceptionCaptureController{
	@Autowired
	private DspBasicReportStatControlRoomService dspBasicReportStatService;
//	@RequestMapping("/index")
//	@ResponseBody
//	public void  index(HttpServletRequest request,HttpServletResponse response){	
//		HttpSession session=request.getSession();
//		session.setAttribute("reportEmpCode", request.getAttribute(""));
//		session.setAttribute("higherCode", request.getAttribute(""));
//		session.setAttribute("fromtime", request.getAttribute(""));
//		session.setAttribute("totime", request.getAttribute(""));
//		session.setAttribute("reportStatus",request.getAttribute(""));
//	   Page page = PubService.getPage(request);
//	   SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
//	   List<DspBasicReportStat> datas=dspBasicReportStatService.findReportList(page, curUser.getUserId());	  
//	   
//	   BaseView view=DspBasicReportStatView.buildeNewIndexView(datas, page,true,true);
//       
//	   outPutXML(response, view);
//	}
	/**
	 * 新建上传汇报
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 朱世平
	 */
//	@RequestMapping("/showEdit")
//	@ResponseBody
//	public void showEdit(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
//		
//		BaseView view =DspBasicReportStatView.buildShowEditView(curUser);
//		outPutXML(response, view);
//	}
	
//	@RequestMapping("/saveReport")
//	@ResponseBody
//	public Object saveReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
//		List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
//		/**
//		 * 如果报告已经存在 则不保存显示提示
//		 */
//	    String time = request.getParameter("time");
//		String reportType = request.getParameter("reportType");
//		String title =time.replace("-", "年")+"月"+curUser.getUserName()+"的"+status1.get(Integer.parseInt(reportType.trim()))[1];
//		if("2".equals(reportType)||"3".equals(reportType)){
//			String [] rods=time.split("-");
//			int month=Integer.parseInt(rods[1]);
//			String quarter=String.valueOf(month/4+1);
//			title=rods[0]+"年"+quarter+"季度"+curUser.getUserName()+"的"+status1.get(Integer.parseInt(reportType.trim()))[1];
//		}
//		if(dspBasicReportStatService.isExitReport(curUser.getUserId(), title)){
//			CommandGroup cg = new CommandGroup("");
//			CommandGroup cg1 = new CommandGroup("");
//			cg1.setPath("/f_main");
//			cg.add(cg1);
//			cg.add(ViewTemplate.getTipAlert("对不起！该报告已经上传!",DialogPosition.middle));
//			return cg;	
//		}
//		
//		dspBasicReportStatService.saveNewReport(request, response);
//		Page page = PubService.getPage(request);
//		List<DspBasicReportStat> datas=dspBasicReportStatService.findReportList(page, curUser.getUserId());
//		CommandGroup cg = new CommandGroup("");
//		CommandGroup cg1 = new CommandGroup("");
//		cg1.setPath("/f_main");
//		
//		UpdateCommand up = new UpdateCommand("");
//		up.setContent(DspBasicReportStatView.buildeNewIndexView(datas, page,true,true));
//		cg.add(new JSCommand("", "DFish.close(this);"));
//		cg1.add(up);
//		cg.add(cg1);
//		cg.add(ViewTemplate.getInfoAlert("保存成功"));
//		return cg;	
//	}
	
	/**
	 * 删除报告
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author zhangyang
	 */
//	@RequestMapping("/reportDelete")
//	@ResponseBody
//	public Object reportDelete(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		String[] ids = request.getParameterValues("selectItem");
//		dspBasicReportStatService.deleteReportByIds(ids);
//		SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
//		Page page = PubService.getPage(request);
//		List<DspBasicReportStat> datas = dspBasicReportStatService.findReportListBySession(request,page);
//		
////		CommandGroup cg = new CommandGroup("");
////		CommandGroup cg1 = new CommandGroup("");
////		cg1.setPath("/f_main");
////		
////		UpdateCommand up = new UpdateCommand("");
////		up.setContent(DspBasicReportStatView.buildeNewIndexView(datas,page));
////		cg1.add(up);
////		cg.add(cg1);
////		cg.add(ViewTemplate.getInfoAlert("删除成功"));
////		return cg;	
//		 BaseView view=ViewTemplate.buildIndexHasBtnView(false);
//			
//			GridPanel grid = (GridPanel) view
//					.findPanelById(ViewTemplate.P_MAIN_GRID); 
//			UpdateCommand ucP = new UpdateCommand("");
//			ucP.setContent(DspBasicReportStatView.updatePagepanel(view, page,datas));
//			AjaxCommand turnPage = new AjaxCommand("turnPage",
//					"DataStatisticsReport/turnPage?cp=$0");
//
//			UpdateCommand up = new UpdateCommand("");
//			up.setContent(DspBasicReportStatView.buildGrid(grid, datas));// 设置内容
//			
//			UpdateCommand cd = new UpdateCommand("cd");
//			cd.setContent(turnPage);
//			CommandGroup cg = new CommandGroup("up");
//			cg.setPath("/f_main");
//			cg.add(up);
//			cg.add(ucP);
//			cg.add(cd);
//			CommandGroup cg2 = new CommandGroup(null);
//			cg2.add(cg);
//			cg.add(ViewTemplate.getInfoAlert("删除成功"));
//			return cg2;
//	}
	/**
	 * 双击事件
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/doubleClick")
	@ResponseBody
	public void doubleClick(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String workReportId = request.getParameter("workReportId");
		DspBasicReportStat dwr=dspBasicReportStatService.getReportDetailById(workReportId);
		List<UploadItem> items=dspBasicReportStatService.getItemsByReporterId(workReportId);
		BaseView view =DspBasicReportStatControlRoomView.buildCheckView(dwr,items);
		outPutXML(response, view);
	}
	/**
	 * 汇报退回
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 张扬
	 */
	@RequestMapping("/reportReturn") 
	@ResponseBody
	public void reportReturn(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String workReportId = request.getParameter("workReportId");
		DspBasicReportStat dwr=dspBasicReportStatService.getReportDetailById(workReportId);
		
		if(dwr.getReportStatus().trim()=="3"||dwr.getReportStatus().trim().equals("3")){
			outPutXML(response, new AlertCommand("dgfail", "已审批通过的报告不能退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return ;
		}else if(dwr.getReportStatus().trim()=="2"||dwr.getReportStatus().trim().equals("2")){
			outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return ;
		}
		
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_controlRoom");
		
		UpdateCommand up = new UpdateCommand("");
		
		cg.add(new DialogCommand("reportReturn", ViewFactory.ID_DIALOG_STANDARD,
		"请填写退回原因", "f_reportReturn", DialogCommand.WIDTH_MEDIUM,
		DialogCommand.HEIGHT_MEDIUM, DialogCommand.POSITION_MIDDLE,
		"vm:|dspBasicReportStatControlRoom/reportReturnView?workReportId="+dwr.getWorkReportId()));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	/**
	 * 汇报退回界面
	* <p>描述:</p>
	* @param request
	* @param response
	* @throws Exception
	* @author zhangyang
	 */
	@RequestMapping("/reportReturnView") 
	@ResponseBody
	public void reportReturnView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =DspBasicReportStatControlRoomView.buildReposrtReturnView(request);
		outPutXML(response, view);
	}
	/* * 保存退回原因
		* <p>描述:</p>
		* @return
		* @throws Exception
		* @author 张扬
		 */
		@RequestMapping("/saveReportReturnReason")
		@ResponseBody
		public Object saveReportReturnReason() throws Exception {
			HttpServletRequest request = getRequest();
			String returnReason = request.getParameter("returnReason");
			String workReportId=request.getParameter("workReportId");
			String returnPerson = request.getParameter("returnPerson");
			String returnTimeString = request.getParameter("returnTimeString");
			Date returnTime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(returnTimeString);
			
			DspBasicReportStat dwr=dspBasicReportStatService.getReportDetailById(workReportId);
			dwr.setReturnReason(returnReason);
			dwr.setReturnPerson(returnPerson);
			dwr.setReturnTime(returnTime);
			dwr.setReportStatus("2");
			dspBasicReportStatService.saveReport(dwr);
			
			
		    Page page = PubService.getPage(request);
		    page.setPageSize(10);
			List<DspBasicReportStat> datas = dspBasicReportStatService.findReportListBySession(request,page);
//			
//			CommandGroup cg = new CommandGroup("");
//			CommandGroup cg1 = new CommandGroup("");
//			cg1.setPath("/f_main");
//			
//			UpdateCommand up = new UpdateCommand("");
//			up.setContent(DspBasicReportStatView.buildeNewIndexView(datas,page));
//			cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
//			cg1.add(up);
//			cg.add(cg1);
//			cg.add(ViewTemplate.getInfoAlert("保存成功"));
//			return cg;	
			
			    BaseView view=ViewTemplate.buildIndexHasBtnView(false);
				
				GridPanel grid = (GridPanel) view
						.findPanelById(ViewTemplate.P_MAIN_GRID); 
				UpdateCommand ucP = new UpdateCommand("");
				ucP.setContent(DspBasicReportStatControlRoomView.updatePagepanel(view, page,datas));
				AjaxCommand turnPage = new AjaxCommand("turnPage",
						"DspBasicReportStatControlRoom/turnPage?cp=$0");

				UpdateCommand up = new UpdateCommand("");
				up.setContent(DspBasicReportStatControlRoomView.buildGrid(grid, datas));// 设置内容
				
				UpdateCommand cd = new UpdateCommand("cd");
				cd.setContent(turnPage);
				CommandGroup cg = new CommandGroup("up");
				cg.setPath("/f_controlRoom");
				cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
				cg.add(up);
				cg.add(ucP);
				cg.add(cd);
				CommandGroup cg2 = new CommandGroup(null);
				cg2.add(cg);
				cg.add(ViewTemplate.getInfoAlert("审批通过成功"));
				return cg2;
		}
		
		/**
		 * 报告审批通过
		* <p>描述:</p>
		* @param request
		* @param response
		* @throws Exception
		* @author 张扬
		 */
//		@RequestMapping("/marlboro")
//		@ResponseBody
//		public Object marlboro(HttpServletRequest request, HttpServletResponse response) throws Exception {
//			String workReportId = request.getParameter("workReportId");
//			
//			DspBasicReportStat dwr=dspBasicReportStatService.getReportDetailById(workReportId);
//			
//			if(dwr.getReportStatus().trim()=="3"||dwr.getReportStatus().trim().equals("3")){
//				outPutXML(response, new AlertCommand("dgfail", "该报告已经审批通过",
//						"img/p/alert-crack.gif", DialogPosition.middle, 5));
//				return null;
//			}else if(dwr.getReportStatus().trim()=="2"||dwr.getReportStatus().trim().equals("2")){
//				outPutXML(response, new AlertCommand("dgfail", "该报告已经被退回",
//						"img/p/alert-crack.gif", DialogPosition.middle, 5));
//				return null;
//			}
//			dwr.setReturnReason("");
//			dwr.setReportStatus("3");
//			dspBasicReportStatService.saveReport(dwr);
//		
//			
//			Page page = PubService.getPage(request);
//			List<DspBasicReportStat> datas = dspBasicReportStatService.findReportListBySession(request,page);
//			
////			CommandGroup cg = new CommandGroup("");
////			CommandGroup cg1 = new CommandGroup("");
////			cg1.setPath("/f_main");
////			
////			UpdateCommand up = new UpdateCommand("");
////			up.setContent(DspBasicReportStatView.buildeNewIndexView(datas,page));
////			cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
////			cg1.add(up);
////			cg.add(cg1);
////			cg.add(ViewTemplate.getInfoAlert("审批通过成功"));
////			return cg;	
//			
//			
//            BaseView view=ViewTemplate.buildIndexHasBtnView(false);
//			
//			GridPanel grid = (GridPanel) view
//					.findPanelById(ViewTemplate.P_MAIN_GRID); 
//			UpdateCommand ucP = new UpdateCommand("");
//			ucP.setContent(DspBasicReportStatView.updatePagepanel(view, page,datas));
//			AjaxCommand turnPage = new AjaxCommand("turnPage",
//					"DataStatisticsReport/turnPage?cp=$0");
//
//			UpdateCommand up = new UpdateCommand("");
//			up.setContent(DspBasicReportStatView.buildGrid(grid, datas));// 设置内容
//			
//			UpdateCommand cd = new UpdateCommand("cd");
//			cd.setContent(turnPage);
//			CommandGroup cg = new CommandGroup("up");
//			cg.setPath("/f_main");
//			cg.add(new JSCommand("", "DFish.close('f_doubleClick');"));
//			cg.add(up);
//			cg.add(ucP);
//			cg.add(cd);
//			CommandGroup cg2 = new CommandGroup(null);
//			cg2.add(cg);
//			cg.add(ViewTemplate.getInfoAlert("审批通过成功"));
//			return cg2;
//		}
	/**
	 * 查询	
	* <p>描述:</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 张扬
	 */
		@RequestMapping("/search")
		@ResponseBody
		public Object search(HttpServletRequest request, HttpServletResponse response) throws Exception {
			Page page = PubService.getPage(request);	
			page.setPageSize(10);
			List<DspBasicReportStat> datas = dspBasicReportStatService.findReportListBySearch(request,page);
			BaseView view=ViewTemplate.buildIndexHasBtnView(false);
			
			GridPanel grid = (GridPanel) view
					.findPanelById(ViewTemplate.P_MAIN_GRID); 
			UpdateCommand ucP = new UpdateCommand("");
			ucP.setContent(DspBasicReportStatControlRoomView.updatePagepanel(view, page,datas));
			AjaxCommand turnPage = new AjaxCommand("turnPage",
					"DspBasicReportStatControlRoom/turnPage?cp=$0");

			UpdateCommand up = new UpdateCommand("");
			up.setContent(DspBasicReportStatControlRoomView.buildGrid(grid, datas));// 设置内容
			
			UpdateCommand cd = new UpdateCommand("cd");
			cd.setContent(turnPage);
			CommandGroup cg = new CommandGroup("up");
			cg.setPath("/f_controlRoom");
			cg.add(up);
			cg.add(ucP);
			cg.add(cd);
			CommandGroup cg2 = new CommandGroup(null);
			cg2.add(cg);
			return cg2;
		}
		@RequestMapping("/turnPage")
		@ResponseBody
		public Object turnPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
			Page page = CommonsHelper.getPage(request);
			page.setPageSize(10);
			SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
	        List<DspBasicReportStat> datas = dspBasicReportStatService.findReportList(page,curUser.getUserId());
	       
	        BaseView view = ViewTemplate.buildIndexHasBtnView(false);
	        GridPanel grid = (GridPanel) view
					.findPanelById(ViewTemplate.P_MAIN_GRID);
	        UpdateCommand ucP = new UpdateCommand("");
			ucP.setContent(DspBasicReportStatControlRoomView.updatePagepanel(view, page,datas));
			AjaxCommand turnPage = new AjaxCommand("turnPage",
					"DspBasicReportStatControlRoom/turnPage?cp=$0");

			UpdateCommand up = new UpdateCommand("");
			up.setContent(DspBasicReportStatControlRoomView.buildGrid(grid, datas));// 设置内容
			
			UpdateCommand cd = new UpdateCommand("cd");
			cd.setContent(turnPage);
			CommandGroup cg = new CommandGroup("up");
			cg.setPath("/f_controlRoom");
			cg.add(up);
			cg.add(ucP);
			cg.add(cd);
			CommandGroup cg2 = new CommandGroup(null);
			cg2.add(cg);
			return cg2;
		}
}

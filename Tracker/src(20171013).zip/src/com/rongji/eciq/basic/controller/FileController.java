package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutTEXT;
import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.rongji.common.mfile.FileManager;
import com.rongji.common.mfile.FileManagerHolder;
import com.rongji.dfish.base.FileUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.service.FileService;
import com.rongji.eciq.entity.DspFileAttach;

@Controller
@RequestMapping("/files")
public class FileController {

	@Autowired
	private FileService fileServie;

	private static final Logger LOG = Logger.getLogger(FileController.class);

	/**
	 * 上传文件
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/upload")
	public void upload(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		if (!(request instanceof MultipartHttpServletRequest)) {
			return;
		}
		MultipartHttpServletRequest mreq = (MultipartHttpServletRequest) request;
		MultipartFile fileData = mreq.getFile("Filedata");
		String originalFileName = fileData.getOriginalFilename();
		String ext = FileUtil.getFileExtName(originalFileName);
		if (ext != null && ext.length() > 1) {// dfish提供的工具生成的带.，这里将他去掉
			ext = ext.substring(1);
		}
		byte[] fileBytes = fileData.getBytes();
		long len = fileData.getSize();
		String attachId = uploadFile(fileBytes, ext);
		String enAttachId = uuid();

		DspFileAttach dfa = new DspFileAttach();
		dfa.setFileAttachId(enAttachId);
		dfa.setFileExt(ext);
		dfa.setFileName(originalFileName);
		dfa.setFileSize(new BigDecimal(len));
		dfa.setFileId(attachId);
		fileServie.saveFileInfo(dfa);

		UploadItem item = new UploadItem();
		item.setId(enAttachId);
		item.setName(fileData.getOriginalFilename());
		item.setType(UploadItem.TYPE_DOCUMENT);
		item.setUrl("files/download?fileId=" + enAttachId);
		item.setMsg("1");
		outPutTEXT(response, item.toString());
	}

	private String uuid() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	/**
	 * 执行文件上传
	 * 
	 * @param file
	 *            文件对象
	 * @return
	 * @throws Exception
	 */
	private static String uploadFile(byte[] fileBytes, String ext)
			throws Exception {
		FileManager fm = FileManagerHolder.getFileManager();
		String id = fm.upload(fileBytes, ext);
		return id;
	}

	/**
	 * 文件下载
	 * 
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/download")
	public void fileDownload(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String fileId = request.getParameter("fileId");
		if (Utils.isEmpty(fileId)) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		DspFileAttach dfa = fileServie.getFileAttach(fileId);
		if (dfa == null) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		FileManager fm = FileManagerHolder.getFileManager();
		byte[] fi = fm.download(dfa.getFileId());
		if (fi == null || fi.length < 0) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		downLoadFile(request, response, fi, dfa);
	}

	public static void downLoadFile(HttpServletRequest request,
			HttpServletResponse response, byte[] file, DspFileAttach dfa)
			throws IOException {
		String fileName = dfa.getFileName();
		fileName = safeFileName(fileName);
		String contentType = "application/octet-stream";
		response.setHeader("Accept-Charset", "ISO8859-1");
		response.setHeader("Content-type", contentType);
		response.setHeader("Content-Length", String.valueOf(file.length));
		response.setHeader("Content-Disposition", "attachment; filename="
				+ fileName);
		try {
			response.getOutputStream().write(file);
			response.getOutputStream().flush();
		} catch (IOException e) {
			LOG.error("文件下载失败", e);
		}
	}

	@RequestMapping("/deleteFile")
	public void deleteFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String deleteId = request.getParameter("fileId");
		if (Utils.isEmpty(deleteId)) {
			outPutXML(response, new JSCommand("123", "文件ID为空"));
			return;
		}
		DspFileAttach dfa = fileServie.getFileAttach(deleteId);
		if (dfa == null) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		FileManager fm = FileManagerHolder.getFileManager();
		fm.deleteFile(dfa.getFileId());

		fileServie.deleteFile(deleteId);
		outPutXML(response, new JSCommand("", ""));
	}

	public static String safeFileName(String saveAs) {
		try {
			return new String(saveAs.getBytes("GBK"), "ISO8859-1");
		} catch (UnsupportedEncodingException e) {
			try {
				return new String(saveAs.getBytes(), "ISO8859-1");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
		}
		return saveAs;
	}

}

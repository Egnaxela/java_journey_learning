package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.LoadingCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.FileUploadHelper;
import com.rongji.eciq.basic.persistence.DspBasicCompReport;
import com.rongji.eciq.basic.service.ReportComplaintsService;
import com.rongji.eciq.basic.view.ReportComplaintsView;
import com.rongji.system.pub.service.PubService;

/**
 * Description: 举报投诉办理控制层 
 * Copyright: Copyright (c)2016 
 * Company: rongji
 * 
 * @author:  侯小全
 * @version: 1.0  Create at:2017-1-11 上午11:30:24
 * 
 * Modification History: 
 * Date Author Version Description
 * ------------------------------------------------------------------
 * 2017-1-3 侯小全 1.0 1.0 Version
 */

@Controller
@RequestMapping("/reportComplaints")
public class ReportComplaintsController extends ExceptionCaptureController{
	@Autowired
	ReportComplaintsService service = new ReportComplaintsService();
	
	/**
	 * <p>描述:首页</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/index")
	@ResponseBody
	public void index(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = ReportComplaintsService.getPage(request);
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		BaseView view =ReportComplaintsView.buildeIndexView(datas, fp, page);
		outPutXML(response, view);
	}
	
	/**
	 * <p>新建举报录入弹出框</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/newReportComplaints")
	@ResponseBody
	public void newReportRecord(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =ReportComplaintsView.buildShowEditView(new DspBasicCompReport(),request);
		outPutXML(response, view);
	}
	
	/**
	 * <p>保存举报录入信息</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/saveReport")
	@ResponseBody
	public Object saveReport(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		String temp = request.getParameter("temp");
		FilterParam f = ReportComplaintsService.getDeletebizId(request);
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");// 存储文件表ID
		
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		DspBasicCompReport DBReport = new DspBasicCompReport();
		try {
			this.bind(request, DBReport);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Page page = ReportComplaintsService.getPage(request);
		//获取系统当前时间
		Date date=new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time=format.format(date);
		DBReport.setReportDate(time);
		//执行保存
		service.saveReport(DBReport,filetTableId,fileIDs,request,temp);
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;
	}
	
	/**
	 * <p>查询信息弹出框</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/searchEdit")
	@ResponseBody
	public void searchEdit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = ReportComplaintsService.getPage(request);
		List<DspBasicCompReport> datas = service.getListByFp(page, fp);
  		BaseView view = ReportComplaintsView.buildShowEditViews(datas, fp, page);
		outPutXML(response, view);
	}
	
	/**
	 * <p>修改录入信息并保存</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/updateReport")
	@ResponseBody
	public Object updateReport(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		String temp = request.getParameter("temp");
		String recordId = request.getParameter("recordId");
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");// 存储文件表ID
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = ReportComplaintsService.getPage(request);
		
		DspBasicCompReport report = new DspBasicCompReport();
		try {
			this.bind(request, report);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String handleResult = report.getHandleResult();
		Date handleDate = report.getHandleDate();
		
		//根据ID找数据
		DspBasicCompReport DBReport = service.getReportByID(recordId);
		String bizId = DBReport.getBizId();
		//根据id删除该条记录
		service.delete(DBReport);
		if(temp.equals("5")){
			DBReport.setHandleResult(handleResult);
			DBReport.setHandleDate(handleDate);
		}
		report.setBizId(bizId);
		DBReport.setBizId(bizId);
		//执行保存
		if(temp.equals("2") || temp.equals("1")){
			service.saveReport(report,filetTableId,fileIDs,request,temp);
		}else{
			service.saveReport(DBReport,filetTableId,fileIDs,request,temp);
		}
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("操作成功"));
		return cg;
	}
	
	/**
	 * 提交审核
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/submitReport")
	@ResponseBody
	public Object submitReport(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		String[] ids = request.getParameterValues("selectItem");
		for(int i=0;i<ids.length;i++){
			//根据ID找数据
			DspBasicCompReport DBReport = service.getReportByID(ids[i]);
			CommandGroup cg = new CommandGroup("cg");
			if(!("1".equals(DBReport.getHandleStatus()))){
				CommandGroup cg1 = new CommandGroup("cg1");
				cg1.setPath("/f_main");
				cg.add(cg1);
				String message= null;
				if(DBReport.getHandleStatus().equals("2")){
					message="该信息正在：“待审核”，不能重复提交！";
				}else if(DBReport.getHandleStatus().equals("3")){
					message="该信息正在：“办理中”，不能重复提交！";
				}else if(DBReport.getHandleStatus().equals("4")){
					message="该信息正在：“转办中”，不能重复提交！";
				}else if(DBReport.getHandleStatus().equals("5")){
					message="该信息：“已办理结束”，不能重复提交！";
				}
				cg.add(ViewTemplate.getInfoAlert(message));
				return cg;
			}else{
				DBReport.setHandleStatus("2");
				service.update(DBReport);
			}
		}
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = ReportComplaintsService.getPage(request);
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		up.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("提交成功"));
		return cg;
	}
	
	/**
	 * 审核
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/auditReport")
	@ResponseBody
	public void auditReport(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		String[] ids = request.getParameterValues("selectItem");
		for(int i=0;i<ids.length;i++){
			//根据ID找数据
			DspBasicCompReport DBReport = service.getReportByID(ids[i]);
			if(("1".equals(DBReport.getHandleStatus())) || ("5".equals(DBReport.getHandleStatus()))){
				CommandGroup cg = new CommandGroup("cg");
				CommandGroup cg1 = new CommandGroup("cg1");
				cg1.setPath("/f_main");
				cg.add(cg1);
				String message= null;
				if(DBReport.getHandleStatus().equals("1")){
					message="该信息：“待提交”，请先提交此信息！";
				}else if(DBReport.getHandleStatus().equals("5")){
					message="该信息：“已办理结束”，不能重复审核！";
				}
				cg.add(ViewTemplate.getInfoAlert(message));
				outPutXML(response, cg);
			}else{
				String id = ids[i];
				CommandGroup cg = new CommandGroup("");
				CommandGroup cg1 = new CommandGroup("");
				cg1.setPath("/f_main");
				
				UpdateCommand up = new UpdateCommand("");
				cg.add(new DialogCommand("check", ViewFactory.ID_DIALOG_STANDARD, "查看详情", 
						"check_dspRiskLib_dio", 830, 550, DialogPosition.middle, "vm:|reportComplaints/checkDetail?flag=$1&complaintsReportId="+id));
				cg1.add(up);
				cg.add(cg1);
				outPutXML(response, cg);
			}
		}
	}
	
	/**
	 * <p>根据条件查询录入信息</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/search")
	@ResponseBody
	public Object search()throws Exception{
		HttpServletRequest request = getRequest();
		Page page = CommonsHelper.getPage(request);
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		List<DspBasicCompReport> datas = service.getListByFp(page, fp);
		
		UpdateCommand uc = new UpdateCommand("uc");
		uc.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		AjaxCommand turnPage = new AjaxCommand("turnPage","reportComplaints/turnPage?cp=$0" + fp);
		UpdateCommand udCmd = new UpdateCommand("udCmd");
		udCmd.setContent(turnPage);
		
		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		cg.add(udCmd);
		CommandGroup cg1 = new CommandGroup(null);
		cg1.add(cg);
		cg1.add(new JSCommand("", "DFish.g_dialog(this).close();"));
		return cg1;
	}
	
	/**
	 * <p>删除录入信息</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/deleteReport")
	@ResponseBody 
	public void deleteReport(HttpServletRequest request,HttpServletResponse response)throws Exception{
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = CommonsHelper.getPage(request);
		int currentpage = 1;
		if (request.getSession().getAttribute("currentpage")!=null) {
			currentpage=Integer.valueOf(request.getSession().getAttribute("currentpage")+"") ;
		}
		
		String[] ids = request.getParameterValues("selectItem");
		for(int i=0;i<ids.length;i++){
			service.deleteReport(ids[i]);
		}
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("删除成功"));
		outPutXML(response, cg);
	}
	
	/**
	 * 查看详情弹出框
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/checkDetail")
	@ResponseBody
	public Object checkDetail(HttpServletRequest request,HttpServletResponse response)throws Exception{
		String complaintsReportId = request.getParameter("complaintsReportId");
		boolean flag = Boolean.valueOf(request.getParameter("flag"));
		if(Utils.isEmpty(complaintsReportId)){
			CommandGroup cg = new CommandGroup("cg");
			cg.add(new LoadingCommand("", false));
			outPutXML(response, cg);
		}
		DspBasicCompReport dspBasicCompReport = service.getReportByID(complaintsReportId);
		BaseView view = ReportComplaintsView.checkDetail(dspBasicCompReport, flag,request);
		return view;
	}
	
	/**
	 * <p>转办功能实现</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/transReport")
	@ResponseBody
	public void transReport(HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");// 存储文件表ID
		
		DspBasicCompReport DBReport = new DspBasicCompReport();
		try {
			this.bind(request, DBReport);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//删除数据
		service.delete(DBReport);
		//保存数据
		service.saveReport(DBReport,filetTableId,fileIDs,request,"4");
		String id = DBReport.getComplaintsReportId();
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		cg.add(new DialogCommand("transReport", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"转至转办单位", "f_transReport", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_MEDIUM+140, DialogCommand.POSITION_MIDDLE,
				"vm:|reportComplaints/transReportView?recordId="+id));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	
	/**
	 * 转办单位弹出框
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/transReportView") 
	@ResponseBody
	public void transReportView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = request.getParameter("recordId");
		BaseView view =ReportComplaintsView.showTransferView(request,id);
		outPutXML(response, view);
	}
	
	/**
	 * <p>转办功能实现</p>
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/trans")
	@ResponseBody
	public Object trans(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String temp = request.getParameter("temp");
		String id = request.getParameter("recordId");
		DspBasicCompReport DB = ReportComplaintsService.getRecordById(id);
		String bizId = DB.getBizId();
		String deptName = request.getParameter("deptName");
		DB.setDeptName(deptName);
		String deptNo = request.getParameter("deptNo");
		DB.setDeptNo(deptNo);
		ReportComplaintsService.transfer(id,DB,temp);
		//logger.info("转办成功,并已写入日志");
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = PubService.getPage(request);
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		
		BaseView view =ReportComplaintsView.buildeIndexView(datas, fp, page);
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		PagePanel pagePanel = (PagePanel) view
				.findPanelById(ViewTemplate.P_MAIN_PAGE);
		UpdateCommand up = new UpdateCommand("cp");
		up.setContent(grid);
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(pagePanel);
		CommandGroup cg = new CommandGroup("up");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		cg1.add(up);
		cg1.add(cd);
		cg.add(cg1);
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg.add(new JSCommand("", "DFish.close('check_dspRiskLib_dio');"));
		return cg;
	}
	
	/**
	 * <p>转办时取消功能</p>
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 侯小全
	 */
	@RequestMapping("/cancel")
	@ResponseBody
	public Object cancel(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String temp = request.getParameter("temp");
		String recordId = request.getParameter("recordId");
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		Page page = ReportComplaintsService.getPage(request);
		//根据ID找数据
		DspBasicCompReport DBReport = service.getReportByID(recordId);
		//根据id删除该条记录
		service.delete(DBReport);
		//执行保存
		DBReport.setApprovalComments("");
		DBReport.setHandleStatus(temp);
		service.save(DBReport);
		List<DspBasicCompReport> datas = service.findReportCompList(page,fp,FrameworkHelper.getLoginUser(request));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(ReportComplaintsView.buildeIndexView(datas, fp, page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg.add(new JSCommand("", "DFish.close('check_dspRiskLib_dio');"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("操作成功"));
		return cg;
	}
	
	/**
	 * <p>下载模板功能实现</p>
	 * @param request
	 * @param response
	 * @author 侯小全
	 */
	@RequestMapping("/downloadTmp")
	@ResponseBody
	public void downloadTmp(HttpServletRequest request,HttpServletResponse response) {	
		String type = "3";
		List<UploadItem> items = ReportComplaintsService.getDownloadItems(type);
		BaseView view = ReportComplaintsView.buildDownloadView(items);
		outPutXML(response, view);
	}
	
}

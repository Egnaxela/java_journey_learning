/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     黄国海  
 * @version:    1.0
 * Createdate:   2017-1-3 上午11:51:00  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-3   黄国海      1.0         1.0 Version  
 */  


package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.LoadingCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.framework.FrameworkConstants;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.FileUploadHelper;
import com.rongji.eciq.basic.persistence.DspBasicReportRecord;
import com.rongji.eciq.basic.service.ReportRecordService;
import com.rongji.eciq.basic.view.ReportRecordView;
import com.rongji.system.pub.service.PubService;

/**
 * @author HuangGuoHai
 *
 */
@Controller
@RequestMapping("/reportRecord")
public class ReportRecordController  extends ExceptionCaptureController{
	
	@Autowired
	ReportRecordService service = new ReportRecordService();
	ReportRecordView view = new ReportRecordView();
	
	/**
	 * 
	* <p>功能入口</p>
	* @param request
	* @param response
	* @author 黄国海
	 */
	@RequestMapping("/index")
	@ResponseBody
	public void index(HttpServletRequest request,HttpServletResponse response){
		//筛选：如果人员不是领导，则只查自己的，如果人员是领导，则可查直属下属的，如果是监审室，则可以查所有的
		String type = request.getParameter("tableType");
		FilterParam fp = ReportRecordService.getMainFilterParam(request);
		Page page = PubService.getPage(request);
		//普通员工只能查询自己的，某单位领导可以查询该单位下的所有提交记录
		List<DspBasicReportRecord> datas = service.findDataList(page,fp,FrameworkHelper.getLoginUser(request),type);
		BaseView view =ReportRecordView.buildeIndexView(datas, fp, page,type,request);
		outPutXML(response, view);
	}
	
	/**
	 * 
	* <p>翻页功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/turnPage")
	@ResponseBody
	public Object turnPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		FilterParam fp=ReportRecordService.getSearchParam(request);
		String type = request.getParameter("tableType");
		Page page = CommonsHelper.getPage(request);
		String loginUser = FrameworkHelper.getLoginUser(request);
		List<DspBasicReportRecord> datas = service.findDataList(page,fp,loginUser,type);
		UpdateCommand uc = new UpdateCommand("");
		uc.setContent(ReportRecordView.buildeIndexView(datas, fp, page,type,request));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"reportRecord/turnPage?cp=$0" + fp);
		UpdateCommand udCmd = new UpdateCommand("udCmd");
		udCmd.setContent(turnPage);

		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		cg.add(udCmd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		cg2.add(new JSCommand("", "DFish.g_dialog(this).close();"));
		return cg2;
		
	}
	
	/**
	 * 
	* <p>翻页功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/search")
	@ResponseBody
	public Object search(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Page page = PubService.getPage(request);
		FilterParam fp = ReportRecordService.getSearchParam(request);
		List<DspBasicReportRecord> datas = ReportRecordService.mainSearch(fp,page);
		String tableType = request.getParameter("tableType");
		BaseView view = ReportRecordView.buildeIndexView(datas, fp, page,tableType,request);
		UpdateCommand uc = new UpdateCommand("");
		uc.setContent(view);
		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
	
	/**
	 * 
	* <p>新建功能实现</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/newReportRecord")
	@ResponseBody
	public void newReportRecord(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =ReportRecordView.buildShowEditView(new DspBasicReportRecord(),request);
		outPutXML(response, view);
	}
	
	/**
	 * 
	* <p>审批退回功能实现</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/showAuditFrame")
	@ResponseBody
	public void showAuditFrame(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String action = request.getParameter("actionType");
		if(action.equals("button")){
			String[] ids = request.getParameterValues("selectItem");
			DspBasicReportRecord record = ReportRecordService.getRecordById(ids[0]);
			if(record.getReportStatus().equals("4")){
				outPutXML(response, new AlertCommand("dgfail", "暂存状态不可审批",
						"img/p/alert-crack.gif", DialogPosition.middle, 5));
				return;
			}
			BaseView view =ReportRecordView.buildShowAuditView(request);
			DialogCommand dio = new DialogCommand("showAuditFrame",
					ViewFactory.ID_DIALOG_STANDARD, "审核表格备案", "showAuditFrame",  DialogCommand.WIDTH_LARGE,
					DialogCommand.HEIGHT_LARGE+80,  DialogPosition.middle, "");
			dio.setCover(true);
			dio.setView(view);
			outPutXML(response, dio);
		}else{
			BaseView view =ReportRecordView.buildTempSaveView(request);
			outPutXML(response, view);
		}
	}
	
	/**
	 * 
	* <p>上报备案功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws ParseException
	* @author 黄国海
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/reportTReport")
	@ResponseBody
	public Object reportTReport(HttpServletRequest request, HttpServletResponse response) throws ParseException, UnsupportedEncodingException{
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		String name = request.getParameter("reportDate");
		String temp = request.getParameter("temp");
		String recordId = request.getParameter("recordId");
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		ReportRecordService.deleteFileAttachBeforeAdd(recordId,fileIDs);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");//存储文件表ID
		//获取其他参数
		String auditor = request.getParameter("leader");
		FilterParam fp = ReportRecordService.getSaveParam(request);
		Page page = PubService.getPage(request);
		String type = request.getParameter("tableType");
		String title = java.net.URLDecoder.decode(fp.getValueAsString("title"), "UTF-8");
		if(fp!=null&&Utils.notEmpty(fp.getValueAsString("title"))){
			if(type.equals("01")&&!java.net.URLDecoder.decode(fp.getValueAsString("title"),"UTF-8").contains("礼品礼金")){
				outPutXML(response, new AlertCommand("dgfail", "请规范命名（年份+上报人+礼品礼金表格备案）",
						"img/p/alert-crack.gif", DialogPosition.middle, 5));
				return null;
			}else if(type.equals("02")&&!java.net.URLDecoder.decode(fp.getValueAsString("title"),"UTF-8").contains("婚丧喜庆")){
				outPutXML(response, new AlertCommand("dgfail", "请规范命名（年份+上报人+婚丧喜庆表格备案）",
						"img/p/alert-crack.gif", DialogPosition.middle, 5));
				return null;
			}
		}
		if(Utils.isEmpty(request.getParameter("brief"))){
				outPutXML(response, new AlertCommand("dgfail", "简要内容不可为空",
						"img/p/alert-crack.gif", DialogPosition.middle, 5));
				return null;
		}
		service.saveReportRecord(fp,filetTableId,fileIDs,request,temp,FrameworkHelper.getLoginUser(request));
		
		List<DspBasicReportRecord> datas = service.findDataList(page,fp,FrameworkHelper.getLoginUser(request),type);
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		
		up.setContent(ReportRecordView.buildeIndexView(datas, fp, page,type,request));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;
	}
	
	/**
	 * 
	* <p>下载模板功能实现</p>
	* @param request
	* @param response
	* @author 黄国海
	 */
	@RequestMapping("/downloadTmp")
	@ResponseBody
	public void downloadTmp(HttpServletRequest request,
			HttpServletResponse response) {	
		String type = request.getParameter("tableType");
		List<UploadItem> items = ReportRecordService.getDownloadItems(type);
		String title = Utils.notEmpty(type)?type.trim().equals("lp")?"礼品礼金模板文件":"婚丧喜庆模板文件":"";
		BaseView view =ReportRecordView.buildDownloadView(items,title);
		outPutXML(response, view);
	}
	
	/**
	 * 
	* <p>删除功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/delete")
	@ResponseBody
	public Object delete(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] ids = request.getParameterValues("selectItem");
		
		//检测session
		String userid = (String) request.getSession().getAttribute(
				FrameworkConstants.LOGIN_USER_KEY);
		if(Utils.isEmpty(userid)){
			outPutXML(response, new AlertCommand("dgfail", "检测到Session已过期，需重新登录。",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return null;
		}
		//判断是否提交了数据
		if(Utils.isEmpty(ids)){
			CommandGroup cg = new CommandGroup("cg");
			cg.add(new LoadingCommand("", false));
			cg.add(new AlertCommand("dgfail", "请选择一条数据",
					"img/p/alert-info.gif", DialogPosition.middle,5));
			FrameworkHelper.outPutXML(response, cg);
			return null;
		}
		//执行删除
		ReportRecordService.deleteRecordAndFileId(ids);
		//修改页面
		// 获得分页信息
		Page page = PubService.getPage(request);
		//修改页面信息
		FilterParam fp = ReportRecordService.getSearchParam(request);
		String type = request.getParameter("tableType");
		List<DspBasicReportRecord> datas = service.mainSearch(fp,page);
		
		BaseView view =ReportRecordView.buildeIndexView(datas, fp, page,type,request);
		UpdateCommand up = new UpdateCommand("cp");
		up.setContent(view);// 设置内容
		
		CommandGroup cg = new CommandGroup("up");
		cg.add(up);
		
		return cg;
	}
	
	
	/**
	 * 审批通过
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/auditReport")
	@ResponseBody
	public Object auditReport(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String id = request.getParameter("recordId");
		String propose = request.getParameter("auditPropose");
		String statusJ = request.getParameter("reportStatus");//退回状态2  审批通过1
		//检测session
		String userid = (String) request.getSession().getAttribute(
				FrameworkConstants.LOGIN_USER_KEY);
		if(Utils.isEmpty(userid)){
			outPutXML(response, new AlertCommand("dgfail", "检测到Session已过期，需重新登录。",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return null;
		}
		String status = ReportRecordService.getReportStatus(id);
		if(status!=null&&statusJ.equals("2")&&status.trim().equals("1")){
			outPutXML(response, new AlertCommand("dgfail", "已审批通过的备案不能退回",
					"img/p/alert-crack.gif", DialogPosition.middle, 5));
			return null;
		}
		//执行操作
		ReportRecordService.auditOrForceReportRecord(id,propose,FrameworkHelper.getLoginUser(request),statusJ);
		
		// 获得分页信息
		Page page = PubService.getPage(request);
		//获取页面数据
		FilterParam fp = ReportRecordService.getMainFilterParam(request);
		String type = request.getParameter("tableType");
		List<DspBasicReportRecord> datas = service.findDataList(page,fp,FrameworkHelper.getLoginUser(request),type);
		
		BaseView view =ReportRecordView.buildeIndexView(datas, fp, page,type,request);
		// 添加列表及分页栏
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		PagePanel pagePanel = (PagePanel) view
				.findPanelById(ViewTemplate.P_MAIN_PAGE);
		UpdateCommand up = new UpdateCommand("cp");
		up.setContent(grid);
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(pagePanel);
		CommandGroup cg = new CommandGroup("up");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		cg1.add(up);
		cg1.add(cd);
		cg.add(cg1);
		cg.add(new JSCommand("", "DFish.close(this);"));
		
		return cg;
	}
	
	/**
	 * 
	* <p>转办功能实现</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/transReport")
	@ResponseBody
	public void transReport(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String id = request.getParameter("recordId");
		String type = request.getParameter("tableType");
//		BaseView view =ReportRecordView.showTransferView(request);
		String auditPropose =Utils.getParameter(request, "auditPropose");
		if(Utils.notEmpty(auditPropose)){
			auditPropose = "&auditPropose="+java.net.URLEncoder.encode(auditPropose, "UTF-8");
		}
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		
		cg.add(new DialogCommand("transReport", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"转至转办人", "f_transReport", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_MEDIUM+140, DialogCommand.POSITION_MIDDLE,
				"vm:|reportRecord/transReportView?recordId="+id+"&tableType="+type+auditPropose));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	
	/**
	 * 
	* <p>转办功能实现</p>
	* @param request
	* @param response
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/transTempReport")
	@ResponseBody
	public void transTempReport(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String id = request.getParameter("recordId");
		String type = request.getParameter("tableType");
//		BaseView view =ReportRecordView.showTransferView(request);
		String auditPropose =Utils.getParameter(request, "auditPropose");
		if(Utils.notEmpty(auditPropose)){
			auditPropose = "&auditPropose="+java.net.URLEncoder.encode(auditPropose, "UTF-8");
		}
		CommandGroup cg = new CommandGroup("");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		
		UpdateCommand up = new UpdateCommand("");
		FilterParam fp = ReportRecordService.getReSaveParam(request);
		cg.add(new DialogCommand("transReport", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"转至转办人", "f_transReport", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_MEDIUM+140, DialogCommand.POSITION_MIDDLE,
				"vm:|reportRecord/transReportView?recordId="+id+"&tableType="+type+auditPropose+"&operate=saveTrans"));
		cg1.add(up);
		cg.add(cg1);
		outPutXML(response, cg);
	}
	
	@RequestMapping("/transReportView") 
	@ResponseBody
	public void transReportView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		BaseView view =ReportRecordView.showTransferView(request);
		outPutXML(response, view);
	}
	
	/**
	 * 
	* <p>转办功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/trans")
	@ResponseBody
	public Object trans(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String id = request.getParameter("recordId");
		String trans = request.getParameter("transferCode");
		String auditPropose = Utils.getParameter(request, "auditPropose");
		String operate = Utils.getParameter(request, "operate");
		ReportRecordService.transfer(id,trans,auditPropose,operate,FrameworkHelper.getLoginUser(request));
		logger.info("转办成功,并已写入日志");
		FilterParam fp = ReportRecordService.getMainFilterParam(request);
		Page page = PubService.getPage(request);
		String type = request.getParameter("tableType");
		List<DspBasicReportRecord> datas = service.findDataList(page,fp,FrameworkHelper.getLoginUser(request),type);
		
		BaseView view =ReportRecordView.buildeIndexView(datas, fp, page,type,request);
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		PagePanel pagePanel = (PagePanel) view
				.findPanelById(ViewTemplate.P_MAIN_PAGE);
		UpdateCommand up = new UpdateCommand("cp");
		up.setContent(grid);
		
		UpdateCommand cd = new UpdateCommand("cd");
		cd.setContent(pagePanel);
		CommandGroup cg = new CommandGroup("up");
		CommandGroup cg1 = new CommandGroup("");
		cg1.setPath("/f_main");
		cg1.add(up);
		cg1.add(cd);
		cg.add(cg1);
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg.add(new JSCommand("", "DFish.close('f_auditFrame');"));
		return cg;
	}
	

	/**
	 * 
	* <p>查询主功能实现</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 黄国海
	 */
	@RequestMapping("/mainSearch")
	@ResponseBody
	public Object mainSearch(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Page page = PubService.getPage(request);
		FilterParam fp = ReportRecordService.getSearchParam(request);
		List<DspBasicReportRecord> datas = ReportRecordService.mainSearch(fp,page);
		String tableType = request.getParameter("tableType");
		BaseView view = ReportRecordView.buildeIndexView(datas, fp, page,tableType,request);
		UpdateCommand uc = new UpdateCommand("");
		uc.setContent(view);
		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}
}

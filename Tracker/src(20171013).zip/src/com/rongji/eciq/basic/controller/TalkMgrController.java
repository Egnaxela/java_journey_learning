package com.rongji.eciq.basic.controller;

import static com.rongji.dfish.framework.FrameworkHelper.outPutXML;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.CommonsHelper;
import com.rongji.dfish.commons.ExceptionCaptureController;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.LoadingCommand;
import com.rongji.dfish.engines.xmltmpl.command.UpdateCommand;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.framework.FrameworkConstants;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.FileUploadHelper;
import com.rongji.eciq.basic.persistence.DspBasicTalkmgr;
import com.rongji.eciq.basic.service.TalkMgrService;
import com.rongji.eciq.basic.view.TalkMgrView;
import com.rongji.system.pub.service.PubService;

	/**
	 * Description: 谈话记录管理控制层 
	 * Copyright: Copyright (c)2016 
	 * Company: rongji
	 * 
	 * @author: 米亦磊
	 * @version: 1.0 
	 * Create at: 2017-1-3 下午2:37:17
	 * 
	 * Modification History:
	 * Date 	Author 		Version   Description
	 * ------------------------------------------------------------------
	 * 2017-1-3    米亦磊              1.0 1.0 Version
	 */

@Controller
@RequestMapping("/talk")
@SuppressWarnings("unchecked")
public class TalkMgrController extends ExceptionCaptureController {
	@Autowired
	private TalkMgrService talkMgrService;

	/**
	 * <p>
	 * 描述:首页
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/index")
	@ResponseBody
	public void index(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		FilterParam fp = TalkMgrService.getParams(request);
		Page page = talkMgrService.getPage(request);
		List<Object[]> statDatas = new ArrayList<Object[]>();
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		List<DspBasicTalkmgr> datas = talkMgrService.findTalkMgrList(page);
		datas = TalkMgrView.filterData(datas);
		BaseView view = TalkMgrView.buildNewIndexView2(datas, statDatas, fp,
				page);
		outPutXML(response, view);
	}

	/**
	 * <p>
	 * 描述:查询及分页栏
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/search")
	@ResponseBody
	public Object search() throws Exception {

		HttpServletRequest request = getRequest();
		Page page = talkMgrService.getPage(request);
		List<Object[]> statDatas = new ArrayList<Object[]>();
		FilterParam fp = TalkMgrService.getParams(request);
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		String type = request.getParameter("type");// 详细信息查询翻页detail 统计信息查询差别翻页
													// stat
		List<DspBasicTalkmgr> datas = null;
		datas = talkMgrService.findTalkMgrListByParam(page, fp);
		datas = TalkMgrView.filterData(datas);
		UpdateCommand uc = new UpdateCommand("");
		BaseView view = TalkMgrView.buildNewIndexView2(datas, statDatas, fp,
				page);
		uc.setContent(view);
		String param = TalkMgrService.fp2String(fp);
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"talk/turnPage?cp=$0" + param);
		UpdateCommand udCmd = new UpdateCommand("udCmd");
		udCmd.setContent(turnPage);
		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		cg.add(udCmd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		return cg2;
	}

	/**
	 * <p>
	 * 描述:双击统计查询
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/selectStat")
	@ResponseBody
	public Object selectStat() throws Exception {
		HttpServletRequest request = getRequest();
		String params = request.getParameter("clickA");

		Page page = talkMgrService.getPage(request);
		page.setPageSize(8);
		List<Object[]> statDatas = new ArrayList<Object[]>();
		FilterParam fp = TalkMgrService.getParams(request);
		statDatas = TalkMgrService.getTalkLevelCount(fp);

		List<DspBasicTalkmgr> datas = talkMgrService.findDataByClick(params,
				page);
		List<DspBasicTalkmgr> newDatas = TalkMgrView.filterData(datas);
		UpdateCommand uc = new UpdateCommand("");
		BaseView view = TalkMgrView.buildNewIndexView2(newDatas, statDatas, fp,
				page);
		uc.setContent(view);
		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);

		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);

		return cg;
	}

	/**
	 * <p>
	 * 描述:弹出录入框
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/showEntry")
	@ResponseBody
	public void showEntry(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// SysUser curUser = BaseUtil.getSessionUser(request);
		DspBasicTalkmgr talkMgr = null;
		talkMgr = talkMgrService.selectByState(request);
		if (null == talkMgr) {
			talkMgr = new DspBasicTalkmgr();
			BaseView view = TalkMgrView.buildShowEntryView(talkMgr, request);
			outPutXML(response, view);
		} else {
			String talkMgrId = talkMgr.getTalkMgrId();
			talkMgr = talkMgrService.getTalkMgr(talkMgrId);
			BaseView view = TalkMgrView.buildShowEntryView(talkMgr, request);
			outPutXML(response, view);
		}
	}

	/**
	 * <p>
	 * 描述:弹出查询框
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/showSelect")
	@ResponseBody
	public void showSelect(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DspBasicTalkmgr talkmgr = new DspBasicTalkmgr();
		BaseView view = TalkMgrView.buildShowSelectView(talkmgr, request);
		outPutXML(response, view);
	}

	/**
	 * <p>
	 * 描述:统计界面显示
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/statSearch")
	@ResponseBody
	public void statSearch(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		BaseView view = TalkMgrView.buildStatView(null, request);
		outPutXML(response, view);
	}

	/**
	 * <p>
	 * 描述:双击查看谈话记录
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/doubleClick")
	@ResponseBody
	public void doubleClick(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String talkMgrId = request.getParameter("talkMgrId");
		if (Utils.isEmpty(talkMgrId)) {
			CommandGroup cg = new CommandGroup("up");
			cg.add(new LoadingCommand("", false));
			outPutXML(response, cg);
		}
		DspBasicTalkmgr talkMgr = talkMgrService.getTalkMgr(talkMgrId);
		// DspBasicTalkmgr talkMgr = new DspBasicTalkmgr();
		BaseView view = TalkMgrView.buildShowDoubleClickView(talkMgr, request);
		outPutXML(response, view);

	}

	/**
	 * <p>
	 * 描述:统计查询结果
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/statSResult")
	@ResponseBody
	public Object statSResult(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		FilterParam fp = TalkMgrView.getSearchParam(request);
		// String talkMgrId = Utils.getParameter(request, "talkMgrId");
		List<Object[]> statDatas = new ArrayList<Object[]>();
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		List<DspBasicTalkmgr> datas = talkMgrService.findTalkMgrList(page);
		List<DspBasicTalkmgr> newDatas = talkMgrService.filterData(datas);
		UpdateCommand up = new UpdateCommand("");
		up.setContent(TalkMgrView.buildNewIndexView2(newDatas, statDatas, fp,
				page));
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");

		cg1.add(up);
		cg.add(cg1);
		cg.add(new JSCommand("", "DFish.close(this);"));
		return cg;

	}

	/**
	 * <p>
	 * 描述:添加谈话记录
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/saveTalkMgr")
	@ResponseBody
	public Object saveTalkMgr(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		FilterParam f = TalkMgrService.getDeletebizId(request);
//		talkMgrService.deleteByBizId(f);
		
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");// 存储文件表ID

		FilterParam fp = TalkMgrView.getFilterParam(request);
		// String talkMgrId = Utils.getParameter(request, "talkMgrId");
		DspBasicTalkmgr talkMgr = new DspBasicTalkmgr();
		// List<String> talkMgrIds = talkMgrService.getStr();

		try {
			this.bind(request, talkMgr);
		} catch (Exception e) {

			e.printStackTrace();
		}
		if (Utils.isEmpty(talkMgr.getTalkMgrId())) {
			talkMgr.setTalkMgrId(UUID.randomUUID().toString()
					.replaceAll("-", ""));
		}
		String talkType = fp.getValueAsString("talkType");
		talkMgr.setTalkType(talkMgrService.type(talkType));

		String talkLevel = fp.getValueAsString("talkLevel");
		talkMgr.setTalkLevel(talkMgrService.level(talkLevel));
		List<Object[]> statDatas = new ArrayList<Object[]>();
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		// 执行保存
		// 如果状态是2(暂存)，则更新
		if ("2".equals(talkMgr.getTalkState())) {
			talkMgr.setTalkState("1");
			talkMgrService.updateTalk(request, talkMgr, filetTableId, fileIDs);
		} else {
			talkMgrService.saveTalkMgr(talkMgr, filetTableId, fileIDs, request);
		}

		List<DspBasicTalkmgr> datas = talkMgrService.findTalkMgrList(page);
		List<DspBasicTalkmgr> newDatas = talkMgrService.filterData(datas);
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(TalkMgrView.buildNewIndexView2(newDatas, statDatas, fp,
				page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		cg.add(ViewTemplate.getInfoAlert("保存成功"));
		return cg;

	}

	/**
	 * <p>
	 * 描述:暂存
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/tempSaveTalkMgr")
	@ResponseBody
	public Object tempSaveTalkMgr(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		FilterParam f = TalkMgrService.getDeletebizId(request);
//		talkMgrService.deleteByBizId(f);
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		List<String> fileIDs = new ArrayList<String>();
		FileUploadHelper.saveToFileSystem(fileIDs, request);
		String filetTableId = UUID.randomUUID().toString().replaceAll("-", "");// 存储文件表ID

		FilterParam fp = TalkMgrView.getFilterParam(request);
		// String talkMgrId = Utils.getParameter(request, "talkMgrId");
		DspBasicTalkmgr talkMgr = new DspBasicTalkmgr();
		try {
			this.bind(request, talkMgr);
		} catch (Exception e) {

			e.printStackTrace();
		}
		if (Utils.isEmpty(talkMgr.getTalkMgrId())) {
			talkMgr.setTalkMgrId(UUID.randomUUID().toString()
					.replaceAll("-", ""));
		}
		String talkType = fp.getValueAsString("talkType");
		talkMgr.setTalkType(talkMgrService.type(talkType));

		String talkLevel = fp.getValueAsString("talkLevel");
		talkMgr.setTalkLevel(talkMgrService.level(talkLevel));
		List<Object[]> statDatas = new ArrayList<Object[]>();
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		// 执行暂存
		// 如果是已经暂存的信息，继续暂存，则更新
		if ("2".equals(talkMgr.getTalkState())) {
			talkMgrService.updateTalk(request, talkMgr, filetTableId, fileIDs);
		} else {
			// 第一次暂存
			talkMgrService.tempSaveTalkMgr(talkMgr, filetTableId, fileIDs,
					request);
		}
		List<DspBasicTalkmgr> datas = talkMgrService.findTalkMgrList(page);
		List<DspBasicTalkmgr> newDatas = talkMgrService.filterData(datas);
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_main");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(TalkMgrView.buildNewIndexView2(newDatas, statDatas, fp,
				page));
		cg.add(new JSCommand("", "DFish.close(this);"));
		cg1.add(up);
		cg.add(cg1);
		return cg;
	}

	/**
	* <p>描述:统计界面变化</p>
	* @param request
	* @param response
	* @return
	* @throws Exception
	* @author 米亦磊
	*/
	
	@RequestMapping("/updateType")
	@ResponseBody
	public Object updateType(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String q = request.getParameter("quarter");
		List<Object[]> month = new ArrayList<Object[]>();
		if (q == null || q.equals("")) {
			month.add(new Object[] { "", "请选择" });
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		} else if (q.equals("1")) {
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
		} else if (q.equals("2")) {
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
		} else if (q.equals("3")) {
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
		} else if (q.equals("4")) {
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		}
		// BaseView view = TalkMgrView.buildStatView(quarter);
		CommandGroup cg = new CommandGroup("cg");
		CommandGroup cg1 = new CommandGroup("cg1");
		cg1.setPath("/f_statSearch");
		UpdateCommand up = new UpdateCommand("");
		up.setContent(new Select("month", "月", null, month).setWidth("100"));
		cg1.add(up);
		cg.add(cg1);
		return cg;
	}

	/**
	 * <p>
	 * 描述:条件查询
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/detailSearch")
	@ResponseBody
	public Object detailSearch(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Page page = PubService.getPage(request);
		page.setPageSize(8);
		// 检测session
		String userid = (String) request.getSession().getAttribute(
				FrameworkConstants.LOGIN_USER_KEY);
		if (Utils.isEmpty(userid)) {
			outPutXML(response, new AlertCommand("dgfail",
					"检测到Session已过期，需重新登录。", "img/p/alert-crack.gif",
					DialogPosition.middle, 5));
			return null;
		}
		// 获取详细信息查询翻页参数
		FilterParam fp = TalkMgrService.getParams(request);
		List<DspBasicTalkmgr> datas = talkMgrService.detailSearch(fp, page);
		List<DspBasicTalkmgr> newDatas = talkMgrService.filterData(datas);
		List<Object[]> statDatas = new ArrayList<Object[]>();
		// 这个地方不能用 DspBasicTalkmgr
		statDatas = TalkMgrService.getTalkLevelCount(fp);
		BaseView view = TalkMgrView.buildNewIndexView2(newDatas, statDatas, fp,
				page);
		UpdateCommand up = new UpdateCommand("cp");
		up.setContent(view);// 设置内容

		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(up);
		CommandGroup cg1 = new CommandGroup(null);
		cg1.add(cg);
		cg1.add(new JSCommand("", "DFish.g_dialog(this).close();"));
		return cg1;
	}

	/**
	 * <p>
	 * 描述:翻页功能实现
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @author 米亦磊
	 */

	@RequestMapping("/turnPage")
	@ResponseBody
	public Object turnPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String type = request.getParameter("type");
		String params = null;
		FilterParam fp = null;
		List<Object[]> statDatas = new ArrayList<Object[]>();
		if (type.equals("stat")) {
			// 统计翻页参数
			fp = TalkMgrService.getParams(request);
			params = TalkMgrService.fp2String(fp);
			// 双击后的翻页，需要获取查询统计数据量时的参数
			statDatas = TalkMgrService.getTalkLevelCount(fp);
		} else {
			// 详细信息翻页参数
			fp = TalkMgrService.getParams(request);
			params = TalkMgrService.fp2String(fp);
			// 查询详细信息时，统计部分默认为全部
			statDatas = TalkMgrService.getTalkLevelCount(new FilterParam());
		}
		Page page = CommonsHelper.getPage(request);
		page.setPageSize(8);

		List<DspBasicTalkmgr> datas = talkMgrService.findTalkMgrList(page);
		datas = TalkMgrView.filterData(datas);
		UpdateCommand uc = new UpdateCommand("");
		uc.setContent(TalkMgrView
				.buildNewIndexView2(datas, statDatas, fp, page));
		AjaxCommand turnPage = new AjaxCommand("turnPage",
				"talk/turnPage?cp=$0" + params + "&type=" + type);
		UpdateCommand udCmd = new UpdateCommand("udCmd");
		udCmd.setContent(turnPage);

		CommandGroup cg = new CommandGroup(null);
		cg.setPath("/f_main");
		cg.add(uc);
		cg.add(udCmd);
		CommandGroup cg2 = new CommandGroup(null);
		cg2.add(cg);
		cg2.add(new JSCommand("", "DFish.g_dialog(this).close();"));
		return cg2;
	}
	
	/**
	* <p>描述:模板下载功能</p>
	* @param request
	* @param response
	* @author 米亦磊
	*/
	
	@RequestMapping("/downloadTmp")
	@ResponseBody
	public void downloadTmp(HttpServletRequest request,
			HttpServletResponse response) {	
		String type = "5";
		List<UploadItem> items = TalkMgrService.getDownloadItems(type);
		BaseView view =TalkMgrView.buildDownloadView(items);
		outPutXML(response, view);
	}

}

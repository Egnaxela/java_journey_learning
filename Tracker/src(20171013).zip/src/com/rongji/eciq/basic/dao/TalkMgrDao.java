package com.rongji.eciq.basic.dao;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.eciq.basic.persistence.DspBasicReportRecord;
import com.rongji.eciq.basic.persistence.DspBasicTalkmgr;
import com.rongji.eciq.common.util.BaseUtil;
import com.rongji.system.entity.SysUser;

	/**
	 * Description: 谈话记录管理数据处理层 
	 * Copyright: Copyright (c)2016 
	 * Company: rongji
	 * 
	 * @author: 米亦磊
	 * @version: 1.0 Create at: 2017-1-3 下午6:33:55
	 * 
	 *   Modification History: 
	 *   Date Author Version Description
	 *   ------------------------------------------------------------------
	 *   2017-1-3 米亦磊 1.0 1.0 Version
	 */
@SuppressWarnings("unchecked")
public class TalkMgrDao {

	/**
	 * 
	 * <p>
	 * 描述:根据id获取DspBasicTalkmgr
	 * </p>
	 * 
	 * @param talkMgrId
	 * @return
	 * @author 米亦磊
	 */
	public DspBasicTalkmgr getTalkMgr(String talkMgrId) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		return (DspBasicTalkmgr) dao.queryAsAnObject(
				"FROM DspBasicTalkmgr t WHERE t.talkMgrId=?", talkMgrId);

	}

	/**
	 * <p>
	 * 描述:全部谈话记录
	 * </p>
	 * 
	 * @param page
	 * @return
	 * @author 米亦磊
	 */

	public List<DspBasicTalkmgr> findTalkMgrList(Page page) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspBasicTalkmgr t WHERE 1=1 ");
		sql.append(" ORDER BY t.talkStartTime DESC");
		List<String> param = new ArrayList<String>();
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List<DspBasicTalkmgr> datas = dao.getQueryList(sql.toString(), page,param.toArray());
		return datas;
	}

	public List<Object[]> findTalkMgrListByCondition(Page page, FilterParam fp) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t.talkMgrId,t.talkType,t.talkTargetId,t.talkTargetId,t.talkStartTime FROM DspBasicTalkmgr t WHERE 1=1  ");
		List<String> param = new ArrayList<String>();

		if (fp != null) {
			String year = fp.getValueAsString("year");
			String month = fp.getValueAsString("month");
			String quarter = fp.getValueAsString("quarter");
			// String talkTargetDep = fp.getValueAsString("talkTargetDep");
			// String talkPersonDep = fp.getValueAsString("talkPersonDep");
			// talkTargetDep = TalkMgrService.type(talkTargetDep);
			if (Utils.notEmpty(year)) {
				sql.append(" and t.title like ? ");
				param.add("%" + year + "%");
			}
			if (Utils.notEmpty(month)) {
				sql.append(" and t.month like ? ");
				param.add(month);
			}
			if (Utils.notEmpty(quarter)) {
				sql.append(" and t.quarter like ? ");
				param.add("%" + quarter + "%");
			}
		}
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List<Object[]> datas = dao.getQueryList(sql.toString(), page,
				param.toArray());
		return datas;
	}

	/**
	 * <p>
	 * 描述:录入谈话记录
	 * </p>
	 * 
	 * @param talkmgr
	 * @author 米亦磊
	 */

	public void saveTalkMgr(DspBasicTalkmgr talkmgr) {
		PubCommonDAO dao = FrameworkHelper.getDAO();
		dao.saveObject(talkmgr);
	}

	/**
	* <p>描述:查询暂存数据</p>
	* @param request
	* @return
	* @author 米亦磊
	*/
	
	public DspBasicTalkmgr selectByState(HttpServletRequest request) {
		SysUser curUser = BaseUtil.getSessionUser(request);
		String userName = curUser.getUserName();
		DspBasicTalkmgr talkMgr = null;
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicTalkmgr t WHERE 1=1  and t.talkEntryPerson=? ");
		sql.append(" and t.talkState = ? ");
		List<String> param=new ArrayList<String>();
		param.add(userName);
		param.add("2");
		PubCommonDAO dao =FrameworkHelper.getDAO();
//		talkMgr=(DspBasicTalkmgr) dao.getQueryList(sql.toString(), param.toArray());
		talkMgr = (DspBasicTalkmgr) dao.queryAsAnObject(sql.toString(), param.toArray());
//		if (talkMgr == null) {
//			talkMgr = new DspBasicTalkmgr();
//		}
		return talkMgr;
	}

	/**
	* <p>描述:更新暂存</p>
	* @param request
	* @return
	* @author 米亦磊
	*/
	
	public void updateTalk(HttpServletRequest request,DspBasicTalkmgr talkMgr){
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.updateObject(talkMgr);
	}

}

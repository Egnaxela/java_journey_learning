package com.rongji.eciq.basic.persistence;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.rongji.eciq.basic.common.FieldMeta;

/**
 * DspBasicCompHandleLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_COMP_HANDLE_LOG")
public class DspBasicCompHandleLog implements java.io.Serializable{

	// Fields
	@FieldMeta(search=true,detail=true,CName="举办投诉办理日志ID",name="handleLogId",type="Text",length=40)
	private String handleLogId;
	@FieldMeta(search=true,detail=true,CName="举报投诉办理ID",name="complaintHandleId",type="Text",length=40)
	private String complaintHandleId;
	@FieldMeta(search=true,detail=true,CName="原始办理单位代码",name="oriUnitCode",type="Text",length=40)
	private String oriUnitCode;
	@FieldMeta(search=true,detail=true,CName="原始办理人员代码",name="oriPerCode",type="Text",length=40)
	private String oriPerCode;
	@FieldMeta(search=true,detail=true,CName="转办单位代码",name="dilvUnitCode",type="Text",length=40)
	private String dilvUnitCode;
	@FieldMeta(search=true,detail=true,CName="转办人员代码",name="dilvPerCode",type="Text",length=40)
	private String dilvPerCode;
	@FieldMeta(search=true,detail=true,CName="办理状态",name="handleStatus",type="Select")
	private String handleStatus;
	@FieldMeta(search=true,detail=true,CName="办结时间",name="handleEndDate",type="DatePicker")
	private Date handleEndDate;

	// Constructors

	/** default constructor */
	public DspBasicCompHandleLog() {
	}
	
	/** minimal constructor */
	public DspBasicCompHandleLog(String handleLogId) {
		this.handleLogId = handleLogId;
	}

	/** full constructor */
	public DspBasicCompHandleLog(String handleLogId, String complaintHandleId,
			String oriUnitCode, String oriPerCode, String dilvUnitCode,
			String dilvPerCode, String handleStatus, Date handleEndDate) {
		this.handleLogId = handleLogId;
		this.complaintHandleId = complaintHandleId;
		this.oriUnitCode = oriUnitCode;
		this.oriPerCode = oriPerCode;
		this.dilvUnitCode = dilvUnitCode;
		this.dilvPerCode = dilvPerCode;
		this.handleStatus = handleStatus;
		this.handleEndDate = handleEndDate;
	}

	// Property accessors
	@Id
	@Column(name = "HANDLE_LOG_ID", unique = true, nullable = false, length = 32)
	public String getHandleLogId() {
		return this.handleLogId;
	}

	public void setHandleLogId(String handleLogId) {
		this.handleLogId = handleLogId;
	}

	@Column(name = "COMPLAINT_HANDLE_ID", length = 32)
	public String getComplaintHandleId() {
		return this.complaintHandleId;
	}

	public void setComplaintHandleId(String complaintHandleId) {
		this.complaintHandleId = complaintHandleId;
	}

	@Column(name = "ORI_UNIT_CODE", length = 20)
	public String getOriUnitCode() {
		return this.oriUnitCode;
	}

	public void setOriUnitCode(String oriUnitCode) {
		this.oriUnitCode = oriUnitCode;
	}

	@Column(name = "ORI_PER_CODE", length = 20)
	public String getOriPerCode() {
		return this.oriPerCode;
	}

	public void setOriPerCode(String oriPerCode) {
		this.oriPerCode = oriPerCode;
	}

	@Column(name = "DILV_UNIT_CODE", length = 20)
	public String getDilvUnitCode() {
		return this.dilvUnitCode;
	}

	public void setDilvUnitCode(String dilvUnitCode) {
		this.dilvUnitCode = dilvUnitCode;
	}

	@Column(name = "DILV_PER_CODE", length = 20)
	public String getDilvPerCode() {
		return this.dilvPerCode;
	}

	public void setDilvPerCode(String dilvPerCode) {
		this.dilvPerCode = dilvPerCode;
	}

	@Column(name = "HANDLE_STATUS", length = 2)
	public String getHandleStatus() {
		return this.handleStatus;
	}

	public void setHandleStatus(String handleStatus) {
		this.handleStatus = handleStatus;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "HANDLE_END_DATE", length = 7)
	public Date getHandleEndDate() {
		return this.handleEndDate;
	}

	public void setHandleEndDate(Date handleEndDate) {
		this.handleEndDate = handleEndDate;
	}

}
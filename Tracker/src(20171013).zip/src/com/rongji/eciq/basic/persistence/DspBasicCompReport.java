package com.rongji.eciq.basic.persistence;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspBasicCompReport entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_COMP_REPORT")
public class DspBasicCompReport implements java.io.Serializable {

	// Fields

	private String complaintsReportId;
	private String reportFileId;
	private String reportUnitCode;
	private String reportDate;
	private String complainantName;
	private String sex;
	private String idNumber;
	private String telephone;
	private String email;
	private String company;
	private String contactAddress;
	private String complaintReason;
	private String disposalIdea;
	private String approvalComments;
	private String handleResult;
	private Date handleDate;
	private String handleStatus;
	private String deptName;
	private String bizId;
	private String deptNo;
	private String position;
	private String source;
	private String recordPerson;
	private String dates;

	// Constructors
	/** default constructor */
	public DspBasicCompReport() {
	}

	/** minimal constructor */
	public DspBasicCompReport(String complaintsReportId) {
		this.complaintsReportId = complaintsReportId;
	}

	/** full constructor */
	public DspBasicCompReport(String complaintsReportId, String reportFileId,
			String reportUnitCode, String reportDate, String complainantName,
			String sex, String idNumber, String telephone, String email,
			String company, String contactAddress, String complaintReason,
			String disposalIdea, String approvalComments, String handleResult,
			Date handleDate, String handleStatus,String deptName,String bizId,
			String deptNo,String position,String source,String recordPerson,
			String dates) {
		this.complaintsReportId = complaintsReportId;
		this.reportFileId = reportFileId;
		this.reportUnitCode = reportUnitCode;
		this.reportDate = reportDate;
		this.complainantName = complainantName;
		this.sex = sex;
		this.idNumber = idNumber;
		this.telephone = telephone;
		this.email = email;
		this.company = company;
		this.contactAddress = contactAddress;
		this.complaintReason = complaintReason;
		this.disposalIdea = disposalIdea;
		this.approvalComments = approvalComments;
		this.handleResult = handleResult;
		this.handleDate = handleDate;
		this.handleStatus = handleStatus;
		this.deptName = deptName;
		this.bizId = bizId;
		this.deptNo = deptNo;
		this.position = position;
		this.source = source;
		this.recordPerson = recordPerson;
		this.dates = dates;
	}

	// Property accessors
	@Id
	@Column(name = "COMPLAINTS_REPORT_ID", unique = true, nullable = false, length = 32)
	public String getComplaintsReportId() {
		return this.complaintsReportId;
	}

	public void setComplaintsReportId(String complaintsReportId) {
		this.complaintsReportId = complaintsReportId;
	}

	@Column(name = "REPORT_FILE_ID", length = 40)
	public String getReportFileId() {
		return this.reportFileId;
	}

	public void setReportFileId(String reportFileId) {
		this.reportFileId = reportFileId;
	}

	@Column(name = "REPORT_UNIT_CODE", length = 200)
	public String getReportUnitCode() {
		return this.reportUnitCode;
	}

	public void setReportUnitCode(String reportUnitCode) {
		this.reportUnitCode = reportUnitCode;
	}

	//@Temporal(TemporalType.DATE)
	@Column(name = "REPORT_DATE", length = 50)
	public String getReportDate() {
		return this.reportDate;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	@Column(name = "COMPLAINANT_NAME", length = 50)
	public String getComplainantName() {
		return this.complainantName;
	}

	public void setComplainantName(String complainantName) {
		this.complainantName = complainantName;
	}

	@Column(name = "SEX", length = 2)
	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	@Column(name = "ID_NUMBER", length = 30)
	public String getIdNumber() {
		return this.idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	@Column(name = "TELEPHONE", length = 20)
	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	@Column(name = "EMAIL", length = 100)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "COMPANY", length = 200)
	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@Column(name = "CONTACT_ADDRESS", length = 500)
	public String getContactAddress() {
		return this.contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	@Column(name = "COMPLAINT_REASON", length = 500)
	public String getComplaintReason() {
		return this.complaintReason;
	}

	public void setComplaintReason(String complaintReason) {
		this.complaintReason = complaintReason;
	}

	@Column(name = "DISPOSAL_IDEA", length = 500)
	public String getDisposalIdea() {
		return this.disposalIdea;
	}

	public void setDisposalIdea(String disposalIdea) {
		this.disposalIdea = disposalIdea;
	}

	@Column(name = "APPROVAL_COMMENTS", length = 500)
	public String getApprovalComments() {
		return this.approvalComments;
	}

	public void setApprovalComments(String approvalComments) {
		this.approvalComments = approvalComments;
	}

	@Column(name = "HANDLE_RESULT", length = 2000)
	public String getHandleResult() {
		return this.handleResult;
	}

	public void setHandleResult(String handleResult) {
		this.handleResult = handleResult;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "HANDLE_DATE", length = 7)
	public Date getHandleDate() {
		return this.handleDate;
	}

	public void setHandleDate(Date handleDate) {
		this.handleDate = handleDate;
	}

	@Column(name = "HANDLE_STATUS", length = 20)
	public String getHandleStatus() {
		return this.handleStatus;
	}

	public void setHandleStatus(String handleStatus) {
		this.handleStatus = handleStatus;
	}

	@Column(name = "COMPLAINT_PERSON", length = 50)
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Column(name = "BIZ_ID", length = 100)
	public String getBizId() {
		return bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}
	
	@Column(name = "DEPT_NO", length = 50)
	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}
	
	@Column(name = "POSITION", length = 200)
	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	@Column(name = "SOURCE", length = 200)
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	
	@Column(name = "RECORD_PERSON", length = 200)
	public String getRecordPerson() {
		return recordPerson;
	}

	public void setRecordPerson(String recordPerson) {
		this.recordPerson = recordPerson;
	}

	@Column(name = "DATES", length = 7)
	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}
}
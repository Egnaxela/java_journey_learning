package com.rongji.eciq.basic.persistence;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspBasicHandleComp entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_HANDLE_COMP")
public class DspBasicHandleComp implements java.io.Serializable {

	// Fields

	private String complaintsHandleId;
	private String complaintsReportId;
	private String directUnitCode;
	private String directPerCode;
	private String deliverUnitCode;
	private String deliverPerCode;
	private Date handleDate;
	private String handleStatus;

	// Constructors

	/** default constructor */
	public DspBasicHandleComp() {
	}

	/** minimal constructor */
	public DspBasicHandleComp(String complaintsHandleId) {
		this.complaintsHandleId = complaintsHandleId;
	}

	/** full constructor */
	public DspBasicHandleComp(String complaintsHandleId,
			String complaintsReportId, String directUnitCode,
			String directPerCode, String deliverUnitCode,
			String deliverPerCode, Date handleDate, String handleStatus) {
		this.complaintsHandleId = complaintsHandleId;
		this.complaintsReportId = complaintsReportId;
		this.directUnitCode = directUnitCode;
		this.directPerCode = directPerCode;
		this.deliverUnitCode = deliverUnitCode;
		this.deliverPerCode = deliverPerCode;
		this.handleDate = handleDate;
		this.handleStatus = handleStatus;
	}

	// Property accessors
	@Id
	@Column(name = "COMPLAINTS_HANDLE_ID", unique = true, nullable = false, length = 32)
	public String getComplaintsHandleId() {
		return this.complaintsHandleId;
	}

	public void setComplaintsHandleId(String complaintsHandleId) {
		this.complaintsHandleId = complaintsHandleId;
	}

	@Column(name = "COMPLAINTS_REPORT_ID", length = 32)
	public String getComplaintsReportId() {
		return this.complaintsReportId;
	}

	public void setComplaintsReportId(String complaintsReportId) {
		this.complaintsReportId = complaintsReportId;
	}

	@Column(name = "DIRECT_UNIT_CODE", length = 20)
	public String getDirectUnitCode() {
		return this.directUnitCode;
	}

	public void setDirectUnitCode(String directUnitCode) {
		this.directUnitCode = directUnitCode;
	}

	@Column(name = "DIRECT_PER_CODE", length = 50)
	public String getDirectPerCode() {
		return this.directPerCode;
	}

	public void setDirectPerCode(String directPerCode) {
		this.directPerCode = directPerCode;
	}

	@Column(name = "DELIVER_UNIT_CODE", length = 20)
	public String getDeliverUnitCode() {
		return this.deliverUnitCode;
	}

	public void setDeliverUnitCode(String deliverUnitCode) {
		this.deliverUnitCode = deliverUnitCode;
	}

	@Column(name = "DELIVER_PER_CODE", length = 50)
	public String getDeliverPerCode() {
		return this.deliverPerCode;
	}

	public void setDeliverPerCode(String deliverPerCode) {
		this.deliverPerCode = deliverPerCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "HANDLE_DATE", length = 7)
	public Date getHandleDate() {
		return this.handleDate;
	}

	public void setHandleDate(Date handleDate) {
		this.handleDate = handleDate;
	}

	@Column(name = "HANDLE_STATUS", length = 2)
	public String getHandleStatus() {
		return this.handleStatus;
	}

	public void setHandleStatus(String handleStatus) {
		this.handleStatus = handleStatus;
	}

}
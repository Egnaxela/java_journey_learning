package com.rongji.eciq.basic.persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DspBasicProcessLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_PROCESS_LOG")
public class DspBasicProcessLog implements java.io.Serializable {

	// Fields

	private String processLogId;
	private String reportId;
	private String reportStatus;

	// Constructors

	/** default constructor */
	public DspBasicProcessLog() {
	}

	/** minimal constructor */
	public DspBasicProcessLog(String processLogId) {
		this.processLogId = processLogId;
	}

	/** full constructor */
	public DspBasicProcessLog(String processLogId, String reportId,
			String reportStatus) {
		this.processLogId = processLogId;
		this.reportId = reportId;
		this.reportStatus = reportStatus;
	}

	// Property accessors
	@Id
	@Column(name = "PROCESS_LOG_ID", unique = true, nullable = false, length = 40)
	public String getProcessLogId() {
		return this.processLogId;
	}

	public void setProcessLogId(String processLogId) {
		this.processLogId = processLogId;
	}

	@Column(name = "REPORT_ID", length = 40)
	public String getReportId() {
		return this.reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	@Column(name = "REPORT_STATUS", length = 2)
	public String getReportStatus() {
		return this.reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}

}
package com.rongji.eciq.basic.persistence;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * DspBasicReportRecord entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_REPORT_RECORD")
public class DspBasicReportRecord implements java.io.Serializable {

	// Fields

	private String recordId;
	private String reportPerName;
	private String reportPerCode;
	private String reportUnitCode;
	private String reportUnitName;
	private String reportType;
	private String company;
	private String duty;
	private String brief;
	private Date reportDate;
	private String reportDateString;
	private String bizId;
    private String remark;
    private String auditPropose;
    private String reportStatus;
    private String transferCode;
    private String directCode;
    private String title;
    private String reporter;
    private String reporterName;
    private String auditor;
	// Constructors

	/** default constructor */
	public DspBasicReportRecord() {
	}

	/** minimal constructor */
	public DspBasicReportRecord(String recordId) {
		this.recordId = recordId;
	}

	/** full constructor */
	public DspBasicReportRecord(String recordId, String reportPerName,
			String reportPerCode, String reportUnitCode, String reportType,
			String company, String duty, String brief, Date reportDate,
			String bizId,String remark,String auditPropose,String reportStatus,String transferCode,String directCode) {
		this.recordId = recordId;
		this.reportPerName = reportPerName;
		this.reportPerCode = reportPerCode;
		this.reportUnitCode = reportUnitCode;
		this.reportType = reportType;
		this.company = company;
		this.duty = duty;
		this.brief = brief;
		this.reportDate = reportDate;
		this.bizId = bizId;
		this.remark=remark;
		this.auditPropose=auditPropose;
		this.reportStatus=reportStatus;
		this.directCode=directCode;
		this.transferCode=transferCode;
	}

	// Property accessors
	@Id
	@Column(name = "RECORD_ID", unique = true, nullable = false, length = 32)
	public String getRecordId() {
		return this.recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	@Column(name = "REPORT_PER_NAME", length = 100)
	public String getReportPerName() {
		return this.reportPerName;
	}

	public void setReportPerName(String reportPerName) {
		this.reportPerName = reportPerName;
	}

	@Column(name = "REPORT_PER_CODE", length = 32)
	public String getReportPerCode() {
		return this.reportPerCode;
	}

	public void setReportPerCode(String reportPerCode) {
		this.reportPerCode = reportPerCode;
	}

	@Column(name = "REPORT_UNIT_CODE", length = 10)
	public String getReportUnitCode() {
		return this.reportUnitCode;
	}

	public void setReportUnitCode(String reportUnitCode) {
		this.reportUnitCode = reportUnitCode;
	}

	@Column(name = "REPORT_TYPE", length = 2)
	public String getReportType() {
		return this.reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	@Column(name = "COMPANY", length = 200)
	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@Column(name = "DUTY", length = 200)
	public String getDuty() {
		return this.duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	@Column(name = "BRIEF", length = 2000)
	public String getBrief() {
		return this.brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REPORT_DATE", length = 7)
	public Date getReportDate() {
		return this.reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	@Column(name = "BIZ_ID", length = 32)
	public String getBizId() {
		return this.bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}
	@Column(name = "REMARK", length = 200)
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Column(name = "AUDIT_PROPOSE", length = 200)
	public String getAuditPropose() {
		return auditPropose;
	}

	public void setAuditPropose(String auditPropose) {
		this.auditPropose = auditPropose;
	}
	@Column(name = "REPORT_STATUS", length = 1)
	public String getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	@Column(name = "TRANSFER_CODE", length = 50)
	public String getTransferCode() {
		return transferCode;
	}

	public void setTransferCode(String transferCode) {
		this.transferCode = transferCode;
	}
	@Column(name = "DIRECT_CODE", length = 50)
	public String getDirectCode() {
		return directCode;
	}

	public void setDirectCode(String directCode) {
		this.directCode = directCode;
	}
	@Column(name = "TITLE", length = 50)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name = "REPORTER", length = 50)
	public String getReporter() {
		return reporter;
	}

	public void setReporter(String reporter) {
		this.reporter = reporter;
	}
	@Column(name = "AUDITOR", length = 50)
	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}
	@Column(name = "REPORTER_NAME", length = 200)
	public String getReporterName() {
		return reporterName;
	}

	public void setReporterName(String reporterName) {
		this.reporterName = reporterName;
	}
	@Column(name = "REPORT_UNIT_NAME", length = 200)
	public String getReportUnitName() {
		return reportUnitName;
	}

	public void setReportUnitName(String reportUnitName) {
		this.reportUnitName = reportUnitName;
	}
	@Transient
	public String getReportDateString() {
		return reportDateString;
	}

	public void setReportDateString(String reportDateString) {
		this.reportDateString = reportDateString;
	}

}
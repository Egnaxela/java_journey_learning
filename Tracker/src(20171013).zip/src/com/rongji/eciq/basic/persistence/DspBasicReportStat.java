package com.rongji.eciq.basic.persistence;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * DspBasicReportStat entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_REPORT_STAT")
public class DspBasicReportStat implements java.io.Serializable {

	// Fields

	private String workReportId;
	private String reportEmpName;
	private String reportEmpCode;
	private String higherName;
	private String higherCode;
	private Date reportDate;
	private Date reportOfDate;
	private String reportStatus;
	private String reportFileId;
	private String returnPerson;
	private String returnReason;
	private Date returnTime;
	private String reportBrief;
	private String reportTitle;
	private String reportType;
	
	private String reportDateString;
	private String returnTimeString;
	private String reportOfDateString;
    
	// Constructors

	/** default constructor */
	public DspBasicReportStat() {
	}

	/** minimal constructor */
	public DspBasicReportStat(String workReportId) {
		this.workReportId = workReportId;
	}

	/** full constructor */
	public DspBasicReportStat(String workReportId, String reportEmpName,
			String reportEmpCode, String higherName, String higherCode,
			Date reportDate, String reportStatus, String reportFileId) {
		this.workReportId = workReportId;
		this.reportEmpName = reportEmpName;
		this.reportEmpCode = reportEmpCode;
		this.higherName = higherName;
		this.higherCode = higherCode;
		this.reportDate = reportDate;
		this.reportStatus = reportStatus;
		this.reportFileId = reportFileId;
	}

	// Property accessors
	@Id
	@Column(name = "WORK_REPORT_ID", unique = true, nullable = false, length = 32)
	public String getWorkReportId() {
		return this.workReportId;
	}

	public void setWorkReportId(String workReportId) {
		this.workReportId = workReportId;
	}

	@Column(name = "REPORT_EMP_NAME", length = 100)
	public String getReportEmpName() {
		return this.reportEmpName;
	}

	public void setReportEmpName(String reportEmpName) {
		this.reportEmpName = reportEmpName;
	}

	@Column(name = "REPORT_EMP_CODE", length = 20)
	public String getReportEmpCode() {
		return this.reportEmpCode;
	}

	public void setReportEmpCode(String reportEmpCode) {
		this.reportEmpCode = reportEmpCode;
	}

	@Column(name = "HIGHER_NAME", length = 100)
	public String getHigherName() {
		return this.higherName;
	}

	public void setHigherName(String higherName) {
		this.higherName = higherName;
	}

	@Column(name = "HIGHER_CODE", length = 200)
	public String getHigherCode() {
		return this.higherCode;
	}

	public void setHigherCode(String higherCode) {
		this.higherCode = higherCode;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REPORT_DATE", length = 7)
	public Date getReportDate() {
		return this.reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}
    
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REPORT_OF_TIME", length = 7)
	public Date getReportOfDate() {
		return reportOfDate;
	}

	public void setReportOfDate(Date reportOfDate) {
		this.reportOfDate = reportOfDate;
	}

	@Column(name = "REPORT_STATUS", length = 1)
	public String getReportStatus() {
		return this.reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}

	@Column(name = "FILE_ID", length = 32)
	public String getReportFileId() {
		return this.reportFileId;
	}

	public void setReportFileId(String reportFileId) {
		this.reportFileId = reportFileId;
	}
	@Column(name = "RETURN_PERSON", length = 50)
	public String getReturnPerson() {
		return returnPerson;
	}

	public void setReturnPerson(String returnPerson) {
		this.returnPerson = returnPerson;
	}
	@Column(name = "RETURN_REASON", length = 500)
	public String getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(String returnReason) {
		this.returnReason = returnReason;
	}
	@Column(name="REPORT_TYPE",length=1)
	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "RETURN_TIME")
	public Date getReturnTime() {
		return returnTime;
	}

	public void setReturnTime(Date returnTime) {
		this.returnTime = returnTime;
	}
	@Column(name = "REPORT_BRIEF", length = 500)
	public String getReportBrief() {
		return reportBrief;
	}

	public void setReportBrief(String reportBrief) {
		this.reportBrief = reportBrief;
	}
	@Column(name = "REPORT_TITLE", length = 200)
	public String getReportTitle() {
		return reportTitle;
	}

	public void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}
	@Transient 
	public String getReportDateString() {
		return reportDateString;
	}

	public void setReportDateString(String reportDateString) {
		this.reportDateString = reportDateString;
	}
	@Transient 
	public String getReturnTimeString() {
		return returnTimeString;
	}

	public void setReturnTimeString(String returnTimeString) {
		this.returnTimeString = returnTimeString;
	}
	@Transient 
	public String getReportOfDateString() {
		return reportOfDateString;
	}

	public void setReportOfDateString(String reportOfDateString) {
		this.reportOfDateString = reportOfDateString;
	}
     
	
	
}
package com.rongji.eciq.basic.persistence;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspBasicTalkmgr entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_TALKMGR")
public class DspBasicTalkmgr implements java.io.Serializable {

	// Fields

	private String talkMgrId;// 谈话记录id
	private Date talkStartTime;// 谈话开始时间
	private String talkTime;// 谈话用时
	private Date talkEntryTime;// 谈话录入时间（填表时间）
	private String talkSite;// 谈话地点
	private String talkContent;// 谈话内容
	private String talkState;// 谈话状态
	private String talkTargetId;// 谈话对象id
	private String talkPersonId;// 谈话人id
	private String bizId;// 附件id(附件表中业务ID) 一个Id对应一次业务操作
	private String talkType;// 谈话类型
	private String talkLevel;// 谈话等级
	private String targetUnitCode;// 谈话对象部门编号
	private String targetUnitName;// 谈话对象部门名称
	private String excuteUnitCode;// 谈话执行部门编号
	private String excuteUnitName;// 谈话执行部门名称
	private String talkTitle;// 谈话标题
	private String talkEntryPerson;// 谈话记录录入人（填表人）
	private String talkTargetName;// 谈话对象姓名
	private String talkPersonName;// 谈话人姓名
	private String talkTargetDetailUnit;// 谈话对象详细部门（职务）
	private String talkPersonDetailUnit;// 谈话人详细部门（职务）
	private String politicalStatus;// 谈话对象政治面貌
	private Date talkOfficeTime;// 谈话对象任职时间
	private String talkTargetSuggestion;// 谈话对象意见
	private String talkPersonSuggestion;// 谈话人意见
	private String admonishReason;// 诫勉谈话原因
	private String talkRemark;// 备注

	// Constructors

	/** default constructor */
	public DspBasicTalkmgr() {
	}

	/** minimal constructor */
	public DspBasicTalkmgr(String talkMgrId) {
		this.talkMgrId = talkMgrId;
	}

	/** full constructor */
	public DspBasicTalkmgr(String talkMgrId, Date talkStartTime,
			String talkTime, Date talkEntryTime, String talkSite,
			String talkContent, String talkState, String talkTargetId,
			String talkPersonId, String talkType, String talkLevel,
			String targetUnitCode, String excuteUnitCode, String bizId,
			String talkEntryPerson, String talkTitle, String talkTargetName,
			String talkPersonName, String targetUnitName,
			String excuteUnitName, String talkTargetDetailUnit,
			String talkPersonDetailUnit, String politicalStatus,
			Date talkOfficeTime, String talkTargetSuggestion,
			String talkPersonSuggestion, String admonishReason,
			String talkRemark) {

		this.talkMgrId = talkMgrId;
		this.talkStartTime = talkStartTime;
		this.talkTime = talkTime;
		this.talkEntryTime = talkEntryTime;
		this.talkSite = talkSite;
		this.talkContent = talkContent;
		this.talkState = talkState;
		this.talkTargetId = talkTargetId;
		this.talkPersonId = talkPersonId;
		this.talkType = talkType;
		this.talkLevel = talkLevel;
		this.targetUnitCode = targetUnitCode;
		this.excuteUnitCode = excuteUnitCode;
		this.bizId = bizId;
		this.talkTitle = talkTitle;
		this.talkEntryPerson = talkEntryPerson;
		this.talkTargetName = talkTargetName;
		this.talkPersonName = talkPersonName;
		this.targetUnitName = targetUnitName;
		this.excuteUnitName = excuteUnitName;
		this.talkTargetDetailUnit = talkTargetDetailUnit;
		this.talkPersonDetailUnit = talkPersonDetailUnit;
		this.politicalStatus = politicalStatus;
		this.talkOfficeTime = talkOfficeTime;
		this.talkTargetSuggestion = talkTargetSuggestion;
		this.talkPersonSuggestion = talkPersonSuggestion;
		this.admonishReason = admonishReason;
		this.talkRemark = talkRemark;

	}

	// Property accessors
	@Id
	@Column(name = "TALK_MGR_ID", unique = true, nullable = false, length = 40)
	public String getTalkMgrId() {
		return this.talkMgrId;
	}

	public void setTalkMgrId(String talkMgrId) {
		this.talkMgrId = talkMgrId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "TALK_START_TIME", length = 7)
	public Date getTalkStartTime() {
		return this.talkStartTime;
	}

	public void setTalkStartTime(Date talkStartTime) {
		this.talkStartTime = talkStartTime;
	}

	@Column(name = "TALK_TIME", length = 20)
	public String getTalkTime() {
		return this.talkTime;
	}

	public void setTalkTime(String talkTime) {
		this.talkTime = talkTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "TALK_ENTRY_TIME", length = 7)
	public Date getTalkEntryTime() {
		return this.talkEntryTime;
	}

	public void setTalkEntryTime(Date talkEntryTime) {
		this.talkEntryTime = talkEntryTime;
	}

	@Column(name = "TALK_SITE", length = 50)
	public String getTalkSite() {
		return this.talkSite;
	}

	public void setTalkSite(String talkSite) {
		this.talkSite = talkSite;
	}

	@Column(name = "TALK_CONTENT")
	public String getTalkContent() {
		return this.talkContent;
	}

	public void setTalkContent(String talkContent) {
		this.talkContent = talkContent;
	}

	@Column(name = "TALK_STATE", length = 1)
	public String getTalkState() {
		return this.talkState;
	}

	public void setTalkState(String talkState) {
		this.talkState = talkState;
	}

	@Column(name = "TALK_TARGET_ID", length = 40)
	public String getTalkTargetId() {
		return this.talkTargetId;
	}

	public void setTalkTargetId(String talkTargetId) {
		this.talkTargetId = talkTargetId;
	}

	@Column(name = "TALK_PERSON_ID", length = 40)
	public String getTalkPersonId() {
		return this.talkPersonId;
	}

	public void setTalkPersonId(String talkPersonId) {
		this.talkPersonId = talkPersonId;
	}

	@Column(name = "TALK_TYPE", length = 1)
	public String getTalkType() {
		return this.talkType;
	}

	public void setTalkType(String talkType) {
		this.talkType = talkType;
	}

	@Column(name = "TALK_LEVEL", length = 1)
	public String getTalkLevel() {
		return talkLevel;
	}

	public void setTalkLevel(String talkLevel) {
		this.talkLevel = talkLevel;
	}

	@Column(name = "TARGET_UNIT_CODE", length = 40)
	public String getTargetUnitCode() {
		return targetUnitCode;
	}

	public void setTargetUnitCode(String targetUnitCode) {
		this.targetUnitCode = targetUnitCode;
	}

	@Column(name = "EXCUTE_UNIT_CODE", length = 40)
	public String getExcuteUnitCode() {
		return excuteUnitCode;
	}

	public void setExcuteUnitCode(String excuteUnitCode) {
		this.excuteUnitCode = excuteUnitCode;
	}

	@Column(name = "BIZ_ID", length = 32)
	public String getBizId() {
		return this.bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}

	@Column(name = "Talk_Title", length = 50)
	public String getTalkTitle() {
		return this.talkTitle;
	}

	public void setTalkTitle(String talkTitle) {
		this.talkTitle = talkTitle;
	}

	@Column(name = "Talk_Entry_Person", length = 40)
	public String getTalkEntryPerson() {
		return this.talkEntryPerson;
	}

	public void setTalkEntryPerson(String talkEntryPerson) {
		this.talkEntryPerson = talkEntryPerson;
	}

	@Column(name = "Talk_Target_Name", length = 40)
	public String getTalkTargetName() {
		return this.talkTargetName;
	}

	public void setTalkTargetName(String talkTargetName) {
		this.talkTargetName = talkTargetName;
	}

	@Column(name = "Talk_Person_Name", length = 40)
	public String getTalkPersonName() {
		return this.talkPersonName;
	}

	public void setTalkPersonName(String talkPersonName) {
		this.talkPersonName = talkPersonName;
	}

	@Column(name = "Excute_Unit_Name", length = 40)
	public String getExcuteUnitName() {
		return this.excuteUnitName;
	}

	public void setExcuteUnitName(String excuteUnitName) {
		this.excuteUnitName = excuteUnitName;
	}

	@Column(name = "Target_Unit_Name", length = 40)
	public String getTargetUnitName() {
		return this.targetUnitName;
	}

	public void setTargetUnitName(String targetUnitName) {
		this.targetUnitName = targetUnitName;
	}

	@Column(name = "TALK_TARGET_DETAILUNIT", length = 50)
	public String getTalkTargetDetailUnit() {
		return this.talkTargetDetailUnit;
	}

	public void setTalkTargetDetailUnit(String talkTargetDetailUnit) {
		this.talkTargetDetailUnit = talkTargetDetailUnit;
	}

	@Column(name = "TALK_PERSON_DETAILUNIT", length = 50)
	public String getTalkPersonDetailUnit() {
		return this.talkPersonDetailUnit;
	}

	public void setTalkPersonDetailUnit(String talkPersonDetailUnit) {
		this.talkPersonDetailUnit = talkPersonDetailUnit;
	}

	@Column(name = "POLITICAL_STATUS", length = 50)
	public String getPoliticalStatus() {
		return this.politicalStatus;
	}

	public void setPoliticalStatus(String politicalStatus) {
		this.politicalStatus = politicalStatus;
	}

	@Column(name = "TAKEOFFICE_TIME", length = 40)
	public Date getTalkOfficeTime() {
		return this.talkOfficeTime;
	}

	public void setTalkOfficeTime(Date talkOfficeTime) {
		this.talkOfficeTime = talkOfficeTime;
	}

	@Column(name = "TALK_TARGET_SUGGESTION", length = 50)
	public String getTalkTargetSuggestion() {
		return this.talkTargetSuggestion;
	}

	public void setTalkTargetSuggestion(String talkTargetSuggestion) {
		this.talkTargetSuggestion = talkTargetSuggestion;
	}

	@Column(name = "TALK_PERSON_SUGGESTION", length = 50)
	public String getTalkPersonSuggestion() {
		return this.talkPersonSuggestion;
	}

	public void setTalkPersonSuggestion(String talkPersonSuggestion) {
		this.talkPersonSuggestion = talkPersonSuggestion;
	}

	@Column(name = "ADMONISH_REASON", length = 50)
	public String getAdmonishReason() {
		return this.admonishReason;
	}

	public void setAdmonishReason(String admonishReason) {
		this.admonishReason = admonishReason;
	}

	@Column(name = "TALK_REMARK", length = 50)
	public String getTalkRemark() {
		return this.talkRemark;
	}

	public void setTalkRemark(String talkRemark) {
		this.talkRemark = talkRemark;
	}
}
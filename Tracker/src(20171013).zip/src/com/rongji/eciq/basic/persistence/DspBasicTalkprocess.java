package com.rongji.eciq.basic.persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DspBasicTalkprocess entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_TALKPROCESS")
public class DspBasicTalkprocess implements java.io.Serializable {

	// Fields

	private String talkProcessId;
	private String talkMgrId;
	private String reportState;
	private String reviewState;

	// Constructors

	/** default constructor */
	public DspBasicTalkprocess() {
	}

	/** minimal constructor */
	public DspBasicTalkprocess(String talkProcessId) {
		this.talkProcessId = talkProcessId;
	}

	/** full constructor */
	public DspBasicTalkprocess(String talkProcessId, String talkMgrId,
			String reportState, String reviewState) {
		this.talkProcessId = talkProcessId;
		this.talkMgrId = talkMgrId;
		this.reportState = reportState;
		this.reviewState = reviewState;
	}

	// Property accessors
	@Id
	@Column(name = "TALK_PROCESS_ID", unique = true, nullable = false, length = 40)
	public String getTalkProcessId() {
		return this.talkProcessId;
	}

	public void setTalkProcessId(String talkProcessId) {
		this.talkProcessId = talkProcessId;
	}

	@Column(name = "TALK_MGR_ID", length = 40)
	public String getTalkMgrId() {
		return this.talkMgrId;
	}

	public void setTalkMgrId(String talkMgrId) {
		this.talkMgrId = talkMgrId;
	}

	@Column(name = "REPORT_STATE", length = 1)
	public String getReportState() {
		return this.reportState;
	}

	public void setReportState(String reportState) {
		this.reportState = reportState;
	}

	@Column(name = "REVIEW_STATE", length = 1)
	public String getReviewState() {
		return this.reviewState;
	}

	public void setReviewState(String reviewState) {
		this.reviewState = reviewState;
	}

}
package com.rongji.eciq.basic.persistence;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * DspBasicWorkReport entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_WORK_REPORT")
public class DspBasicWorkReport implements java.io.Serializable {

	// Fields

	private String reporterId;
	private String reporterCode;
	private String reporterName;
	private String reporterUnitCode;
	private String reporterUnit;
	private String reporterContent;
	private Date reporterDate;
	private String reporterStatus;
	private String reporterReturnReason;
	private String reportFileId;
	private String reportTitle;
	private Date returnTime;
	private String reportBrief;
	private String returnPerson;
	private String reporterYear;

	private String reporterDateString;

	// Constructors

	/** default constructor */
	public DspBasicWorkReport() {
	}

	/** minimal constructor */
	public DspBasicWorkReport(String reporterId) {
		this.reporterId = reporterId;
	}

	/** full constructor */
	public DspBasicWorkReport(String reporterId, String reporterCode,
			String reporterName, String reporterUnitCode, String reporterUnit,
			String reporterContent, Date reporterDate, String reporterStatus,
			String reporterReturnReason, String reportFileId) {
		this.reporterId = reporterId;
		this.reporterCode = reporterCode;
		this.reporterName = reporterName;
		this.reporterUnitCode = reporterUnitCode;
		this.reporterUnit = reporterUnit;
		this.reporterContent = reporterContent;
		this.reporterDate = reporterDate;
		this.reporterStatus = reporterStatus;
		this.reporterReturnReason = reporterReturnReason;
		this.reportFileId = reportFileId;
	}

	// Property accessors
	@Id
	@Column(name = "REPORTER_ID", unique = true, nullable = false, length = 40)
	public String getReporterId() {
		return this.reporterId;
	}

	public void setReporterId(String reporterId) {
		this.reporterId = reporterId;
	}

	@Column(name = "REPORTER_CODE", length = 30)
	public String getReporterCode() {
		return this.reporterCode;
	}

	public void setReporterCode(String reporterCode) {
		this.reporterCode = reporterCode;
	}

	@Column(name = "REPORTER_NAME", length = 100)
	public String getReporterName() {
		return this.reporterName;
	}

	public void setReporterName(String reporterName) {
		this.reporterName = reporterName;
	}

	@Column(name = "REPORTER_UNIT_CODE", length = 30)
	public String getReporterUnitCode() {
		return this.reporterUnitCode;
	}

	public void setReporterUnitCode(String reporterUnitCode) {
		this.reporterUnitCode = reporterUnitCode;
	}

	@Column(name = "REPORTER_UNIT", length = 100)
	public String getReporterUnit() {
		return this.reporterUnit;
	}

	public void setReporterUnit(String reporterUnit) {
		this.reporterUnit = reporterUnit;
	}

	@Column(name = "REPORTER_CONTENT")
	public String getReporterContent() {
		return this.reporterContent;
	}

	public void setReporterContent(String reporterContent) {
		this.reporterContent = reporterContent;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REPORTER_DATE", length = 7)
	public Date getReporterDate() {
		return this.reporterDate;
	}

	public void setReporterDate(Date reporterDate) {
		this.reporterDate = reporterDate;
	}

	@Column(name = "REPORTER_STATUS", length = 30)
	public String getReporterStatus() {
		return this.reporterStatus;
	}

	public void setReporterStatus(String reporterStatus) {
		this.reporterStatus = reporterStatus;
	}

	@Column(name = "REPORTER_RETURN_REASON", length = 1000)
	public String getReporterReturnReason() {
		return this.reporterReturnReason;
	}

	public void setReporterReturnReason(String reporterReturnReason) {
		this.reporterReturnReason = reporterReturnReason;
	}

	@Column(name = "FILE_ID", length = 50)
	public String getReportFileId() {
		return this.reportFileId;
	}

	public void setReportFileId(String reportFileId) {
		this.reportFileId = reportFileId;
	}

	@Column(name = "REPORT_TITLE", length = 100)
	public String getReportTitle() {
		return reportTitle;
	}

	public void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "RERURN_TIME")
	public Date getReturnTime() {
		return returnTime;
	}

	public void setReturnTime(Date returnTime) {
		this.returnTime = returnTime;
	}

	@Column(name = "REPORT_BRIEF", length = 500)
	public String getReportBrief() {
		return reportBrief;
	}

	public void setReportBrief(String reportBrief) {
		this.reportBrief = reportBrief;
	}

	@Column(name = "RETURN_PERSON", length = 50)
	public String getReturnPerson() {
		return returnPerson;
	}

	public void setReturnPerson(String returnPerson) {
		this.returnPerson = returnPerson;
	}

	@Column(name = "REPORTER_YEAR", length = 10)
	public String getReporterYear() {
		return reporterYear;
	}

	public void setReporterYear(String reporterYear) {
		this.reporterYear = reporterYear;
	}

	@Transient
	public String getReporterDateString() {
		return reporterDateString;
	}

	public void setReporterDateString(String reporterDateString) {
		this.reporterDateString = reporterDateString;
	}

}
/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     黄国海  
 * @version:    1.0
 * Createdate:   2017-1-3 上午10:18:00  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-3   黄国海      1.0         1.0 Version  
 */  


package com.rongji.eciq.basic.persistence;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

import com.rongji.eciq.basic.common.FieldMeta;

/**
 * @author HuangGuoHai
 *
 */
public class EntityTest {
	
	public static void main(String[] args){
//		DspBasicCompHandleLog log = new DspBasicCompHandleLog();
//		Field[] fs = log.getClass().getDeclaredFields();
//		for(Field d : fs)
//		{
//			System.out.println(((FieldMeta)d.getAnnotation(FieldMeta.class)).length());
//		}
		String value = "1=福建#2=厦门#3=福州#4=莆田";
		String[] va = value.split("#");
		for(String v : va){
			System.out.println(v);
		}
 
	}

}

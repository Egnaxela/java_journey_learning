package com.rongji.eciq.basic.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicWorkReport;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.entity.DspFileTemplate;
import com.rongji.system.entity.SysCode;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.AbstractService;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;
@Service
@Transactional
public class DisReportService extends AbstractService {
	
//	public static final String SYS_USER_NAME = "root";
	public SysUser2 getUser(String userId) {
		if(userId.equals("")||userId==""||userId==null||userId.equals(null)){
			return new SysUser2();	
		}
		PubCommonDAO dao =FrameworkHelper.getDAO();
		SysUser2 su=(SysUser2)dao.queryAsAnObject("FROM SysUser t WHERE t.userId=?", userId);
		if(su==null){
			return new SysUser2();
		}
		return su;
	}
	/**
	 * 查询的所有的包告
	* <p>描述:</p>
	* @param page
	* @param userId
	* @return
	* @author 张扬
	 */
	@Transactional(readOnly=true,propagation=Propagation.NOT_SUPPORTED)
	public List<DspBasicWorkReport> findReportList(Page page,String userId) {
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<String> param=new ArrayList<String>();
		
//		String sql="from DspBasicWorkReport t  where t.reportFileId in (select d.bizId from DspFileManage d  where  d.userId='"+userId+"') order by t.reporterDate desc";
		String sql="from DspBasicWorkReport t where t.reporterCode ='"+userId+"' order by t.reporterDate desc";
		
		List<DspBasicWorkReport> dwrList = dao.getQueryList(sql,page);
	
		List<DspBasicWorkReport> resultDatas = new ArrayList<DspBasicWorkReport>();

		Iterator<DspBasicWorkReport> it=dwrList.iterator();
    	SimpleDateFormat dateFormater=new SimpleDateFormat("yyyy-MM-dd");
		while(it.hasNext()){
			DspBasicWorkReport dwrIt=it.next();
			DspBasicWorkReport dwrIt1=new DspBasicWorkReport ();
			dwrIt1.setReportBrief(dwrIt.getReportBrief());
			dwrIt1.setReturnPerson(dwrIt.getReturnPerson());
			dwrIt1.setReturnTime(dwrIt.getReturnTime());
			dwrIt1.setReporterCode(dwrIt.getReporterCode());
			dwrIt1.setReporterContent(dwrIt.getReporterContent());
			dwrIt1.setReporterId(dwrIt.getReporterId());
			dwrIt1.setReporterName(dwrIt.getReporterName());
			dwrIt1.setReporterReturnReason(dwrIt.getReporterReturnReason());
			dwrIt1.setReporterStatus(dwrIt.getReporterStatus());
			dwrIt1.setReporterUnit(dwrIt.getReporterUnit());
			dwrIt1.setReporterUnitCode(dwrIt.getReporterUnitCode());
			dwrIt1.setReportFileId(dwrIt.getReportFileId());
			dwrIt1.setReportTitle(dwrIt.getReportTitle());
			dwrIt1.setReporterDate(dwrIt.getReporterDate());
			dwrIt1.setReporterDateString(dateFormater.format(dwrIt.getReporterDate()));
			dwrIt1.setReporterYear(dwrIt.getReporterYear());
			if(dwrIt.getReporterStatus()=="1"||dwrIt.getReporterStatus().equals("1")){
				//退回
				List<Object[]> status2 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status2.get(1)[1].toString());
			}else if(dwrIt.getReporterStatus()=="0"||dwrIt.getReporterStatus().equals("0")){
				//已提交
				List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status1.get(0)[1].toString());
			}else if(dwrIt.getReporterStatus()=="2"||dwrIt.getReporterStatus().equals("2")){
				//暂存
				List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status1.get(2)[1].toString());
			}
			
			resultDatas.add(dwrIt1);
		}
		return resultDatas;
	}
	/**
	 * 条件查询报告
	* <p>描述:</p>
	* @param request
	* @return
	* @author zhangyang 
	 */
	public List<DspBasicWorkReport> findReportListBySearch(HttpServletRequest request,Page page) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
//		String reportName = request.getParameter("reportName").replace(",", "");
//		String reporterUnitName = request.getParameter("unitName").replace(",", "");
		String reportName = request.getParameter("");
		String reporterUnitName = request.getParameter("");
		String fromtime = request.getParameter("fromtime");
		String totime = request.getParameter("totime");
		String reporterStatus = request.getParameter("reporterStatus");
		List<DspBasicWorkReport> datas = new ArrayList<DspBasicWorkReport>();
		List<String> param=new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		sb.append(" from DspBasicWorkReport t ");
		boolean condition = true;
		if(Utils.notEmpty(reportName)){ 
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterName like ? ");
			param.add("%"+reportName+"%");
			sb.append(" and t.reporterStatus !='2' ");
			condition=false;
		}else{
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterCode = ? ");
			param.add(curUser.getUserId());
			condition=false;
		}
		if(Utils.notEmpty(reporterUnitName)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterUnit like ? ");
			param.add("%"+reporterUnitName+"%");
			condition=false;
		}
		if(Utils.notEmpty(fromtime)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(fromtime);
			condition=false;
		}
		if(Utils.notEmpty(totime)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(totime);
			condition=false;
		}
		if(Utils.notEmpty(reporterStatus)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterStatus = ? ");
			param.add(reporterStatus);
			condition=false;
		}
		sb.append(" order by t.reporterDate desc ");
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sb.toString(), page,param.toArray());
		
		
		List<DspBasicWorkReport> resultDatas = new ArrayList<DspBasicWorkReport>();

		Iterator<DspBasicWorkReport> it=datas.iterator();
		SimpleDateFormat dateFormater=new SimpleDateFormat("yyyy-MM-dd");
		while(it.hasNext()){
			DspBasicWorkReport dwrIt=it.next();
			DspBasicWorkReport dwrIt1=new DspBasicWorkReport ();
			dwrIt1.setReporterCode(dwrIt.getReporterCode());
			dwrIt1.setReporterContent(dwrIt.getReporterContent());
			dwrIt1.setReporterId(dwrIt.getReporterId());
			dwrIt1.setReporterName(dwrIt.getReporterName());
			dwrIt1.setReporterReturnReason(dwrIt.getReporterReturnReason());
			dwrIt1.setReporterStatus(dwrIt.getReporterStatus());
			dwrIt1.setReporterUnit(dwrIt.getReporterUnit());
			dwrIt1.setReporterUnitCode(dwrIt.getReporterUnitCode());
			dwrIt1.setReportFileId(dwrIt.getReportFileId());
			dwrIt1.setReportTitle(dwrIt.getReportTitle());
			dwrIt1.setReporterDate(dwrIt.getReporterDate());
			dwrIt1.setReporterDateString(dateFormater.format(dwrIt.getReporterDate()));
			dwrIt1.setReporterYear(dwrIt.getReporterYear());
			if(dwrIt.getReporterStatus()=="1"||dwrIt.getReporterStatus().equals("1")){
				//退回
				List<Object[]> status2 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status2.get(1)[1].toString());
			}else if(dwrIt.getReporterStatus()=="0"||dwrIt.getReporterStatus().equals("0")){
				//已提交 
				List<Object[]> status0 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status0.get(0)[1].toString());
				
			}else if(dwrIt.getReporterStatus()=="2"||dwrIt.getReporterStatus().equals("2")){
				//暂存
				List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status1.get(2)[1].toString());
			}
			
			resultDatas.add(dwrIt1);
		}
		return resultDatas;
	}
	
	
	/**
	 *查询之后进行其他操作 再刷新界面用
	* <p>描述:</p>
	* @param request
	* @return
	* @author zhangyang 
	 */
	public List<DspBasicWorkReport> findReportListBySession(HttpServletRequest request,Page page) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		String reportName = (String)request.getSession().getAttribute("reportName");
		String reporterUnitName =  (String)request.getSession().getAttribute("reporterUnitName");
		String fromtime =  (String)request.getSession().getAttribute("fromtime");
		String totime = (String)request.getSession().getAttribute("totime");
		String reporterStatus =  (String)request.getSession().getAttribute("reporterStatus");
		List<DspBasicWorkReport> datas = new ArrayList<DspBasicWorkReport>();
		List<String> param=new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		sb.append(" from DspBasicWorkReport t ");
		boolean condition = true;
		if(Utils.notEmpty(reportName)){ 
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterName like ? ");
			param.add("%"+reportName+"%");
			sb.append(" and t.reporterStatus !='2' ");
			condition=false;
		}else{
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterCode = ? ");
			param.add(curUser.getUserId());
			condition=false;
		}
		if(Utils.notEmpty(reporterUnitName)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterUnit like ? ");
			param.add("%"+reporterUnitName+"%");
			condition=false;
		}
		if(Utils.notEmpty(fromtime)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(fromtime);
			condition=false;
		}
		if(Utils.notEmpty(totime)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(totime);
			condition=false;
		}
		if(Utils.notEmpty(reporterStatus)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reporterStatus = ? ");
			param.add(reporterStatus);
			condition=false;
		}
		sb.append(" order by t.reporterDate desc ");
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sb.toString(), page,param.toArray());
		
		
		List<DspBasicWorkReport> resultDatas = new ArrayList<DspBasicWorkReport>();

		Iterator<DspBasicWorkReport> it=datas.iterator();
		SimpleDateFormat dateFormater=new SimpleDateFormat("yyyy-MM-dd");
		while(it.hasNext()){
			DspBasicWorkReport dwrIt=it.next();
			DspBasicWorkReport dwrIt1=new DspBasicWorkReport ();
			dwrIt1.setReporterCode(dwrIt.getReporterCode());
			dwrIt1.setReporterContent(dwrIt.getReporterContent());
			dwrIt1.setReporterId(dwrIt.getReporterId());
			dwrIt1.setReporterName(dwrIt.getReporterName());
			dwrIt1.setReporterReturnReason(dwrIt.getReporterReturnReason());
			dwrIt1.setReporterStatus(dwrIt.getReporterStatus());
			dwrIt1.setReporterUnit(dwrIt.getReporterUnit());
			dwrIt1.setReporterUnitCode(dwrIt.getReporterUnitCode());
			dwrIt1.setReportFileId(dwrIt.getReportFileId());
			dwrIt1.setReportTitle(dwrIt.getReportTitle());
			dwrIt1.setReporterDate(dwrIt.getReporterDate());
			dwrIt1.setReporterDateString(dateFormater.format(dwrIt.getReporterDate()));
			dwrIt1.setReporterYear(dwrIt.getReporterYear());
			if(dwrIt.getReporterStatus()=="1"||dwrIt.getReporterStatus().equals("1")){
				//退回
				List<Object[]> status2 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status2.get(1)[1].toString());
			}else if(dwrIt.getReporterStatus()=="0"||dwrIt.getReporterStatus().equals("0")){
				//已提交
				List<Object[]> status0 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status0.get(0)[1].toString());
				
			}else if(dwrIt.getReporterStatus()=="2"||dwrIt.getReporterStatus().equals("2")){
				//暂存
				List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020201");
				dwrIt1.setReporterStatus(status1.get(2)[1].toString());
			}
			
			resultDatas.add(dwrIt1);
		}
		return resultDatas;
	}
	/**
	 * 通过报告id获取报告的详细信息
	* <p>描述:</p>
	* @param reporterId
	* @return
	* @author 张扬
	 */
	public DspBasicWorkReport getReportDetailById(String reporterId){
		PubCommonDAO dao =FrameworkHelper.getDAO();
//		DspBasicWorkReport dwr=new DspBasicWorkReport();
		String sql="from DspBasicWorkReport t where t.reporterId='"+reporterId+"'";
		DspBasicWorkReport dwr=(DspBasicWorkReport)dao.queryAsAnObject(sql);
		return dwr;
	}
/**
 * 根据id删除报告
* <p>描述:</p>
* @param ids
* @return
* @throws Exception
* @author 张扬
 */
	public void deleteReportByIds(String[] ids) throws Exception {
		List<DspBasicWorkReport> datas = null;
		List<String> paramM = null;
		String bizId = null;
		for(int i=0;i<ids.length;i++){
			String reporterId = ids[i];
			//取到fileId----对应filemanage中的bizid
			StringBuilder sql=new StringBuilder();
			 sql.append(" FROM DspBasicWorkReport t WHERE t.reporterId=?   ");
			List<String> param=new ArrayList<String>();
			param.add(reporterId);
			//判断
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sql.toString(), param.toArray());
			if(Utils.notEmpty(datas)){
				paramM=new ArrayList<String>();
				bizId = datas.get(0).getReportFileId();
				if(Utils.notEmpty(bizId)){
					paramM.add(bizId);
					dao.deleteSQL(" from DspFileManage t where t.bizId=?", paramM.toArray());
					System.out.println("删除附件表数据  bizid="+bizId);
					dao.deleteSQL(" from DspBasicWorkReport t where t.reporterId=?", param.toArray());
					System.out.println("删除表格上报表数据  recordId="+reporterId);
				}
			}
		}
	}
	/**
	 * 保存报告
	* <p>描述:</p>
	* @param dwr
	* @param itemId
	* @param userId
	* @author zhangyang 
	 */
	public void saveReport(DspBasicWorkReport dwr,List<String> itemId,String userId){
		
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.saveObject(dwr);
		Iterator<String> it=itemId.iterator();
	    while(it.hasNext()){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileId(it.next());
			fileManage.setBizId(dwr.getReportFileId());
			fileManage.setOperTime(dwr.getReporterDate());
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setUserId(userId);
//			fileManage.setFileContent("zhangyang"+new Date());
			dao.saveObject(fileManage);
		}
	} 
/**
 * 保存退回原因
* <p>描述:</p>
* @author 张扬
 */
	public void saveReportReturnReason(DspBasicWorkReport dwr){	
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.updateObject(dwr);	
	}
	
	
	/**
	 *更新报告
	* <p>描述:</p>
	* @author 张扬
	 */
public  void updateReport(DspBasicWorkReport dwr){
	PubCommonDAO dao =FrameworkHelper.getDAO();
	dao.updateObject(dwr);
}

public void updateObject(Object object){
	PubCommonDAO dao =FrameworkHelper.getDAO();
	dao.updateObject(object);
}
public void deleteObject(Object object){
	PubCommonDAO dao =FrameworkHelper.getDAO();
	dao.delete(object);
}

public void saveObject(Object object){
	PubCommonDAO dao =FrameworkHelper.getDAO();
	dao.saveObject(object);
}


public List<DspFileManage> findDspFileManageByBizid(String bizid){
	StringBuilder sql=new StringBuilder();
	 sql.append(" FROM DspFileManage t WHERE t.bizId=?   ");
	 List<String> param=new ArrayList<String>();
		param.add(bizid);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspFileManage> datas=dao.getQueryList(sql.toString(), param.toArray());
		return datas;
} 
	/**
	 * 保存审批通过
	* <p>描述:</p>
	* @author 张扬
	 */
public  void saveMarlboro(DspBasicWorkReport dwr){
	dwr.setReporterStatus("1");
	PubCommonDAO dao =FrameworkHelper.getDAO();
	dao.updateObject(dwr);
}
	public List<UploadItem> getItemsByReporterId(String reporterId){
		StringBuilder sql=new StringBuilder();
		sql.append("from DspFileAttach t where t.fileAttachId in" +
				" (select d.fileId  from DspFileManage d where d.bizId=" +
				"(select b.reportFileId from DspBasicWorkReport b where b.reporterId='");
		sql.append(reporterId);
		sql.append("'))");
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspFileAttach> dfa =dao.getQueryList(sql.toString());
		List<UploadItem> items=new ArrayList<UploadItem>();
		if(Utils.notEmpty(dfa)){
			Iterator<DspFileAttach> it=dfa.iterator();
			while(it.hasNext()){
				DspFileAttach df=it.next();
				UploadItem ui=new UploadItem();
				ui.setId(df.getFileAttachId());
				ui.setSuffix(df.getFileExt());
				ui.setSize(String.valueOf(df.getFileSize()));
				ui.setName(df.getFileName());
				items.add(ui);
			}
		}
		return items;
	}
/**
 * 通过部门id获取部门名称
* <p>描述:</p>
* @param deptNo
* @return
* @author zhangyang
 */
	public String getDeptNameByDeptNo(String deptNo){
		String dn="";
		
		if(deptNo==null||deptNo==""){
			return "";
		}
		dn=deptNo.trim();
	    String[] deptNos=deptNo.split(",");
		PubCommonDAO dao =FrameworkHelper.getDAO();
		String sql="";
	
		String deptName="";
		for(int i=0;i<deptNos.length;i++){
			sql="from SysDept t where t.deptNo='"+deptNos[i]+"'";
			SysDept sd=(SysDept)dao.queryAsAnObject(sql);
			if(sd==null){
				continue;
			}
			deptName=deptName+sd.getDeptName()+",";
		}
	   
//		List<SysDept> sd=dao.getQueryList(sql); 
//		if(sd.size()<1){
//			return "";
//		}
		return deptName.substring(0,deptName.length()-1);
	}
	
   public  boolean exitReport(SysUser2 curUser,String year){
//	   SimpleDateFormat sdf=new SimpleDateFormat("yyyy");
//	   String year=sdf.format(new Date());
	   String title=curUser.getUserName();
//	   String sql="from DspBasicWorkReport t where t.reporterCode='"+curUser.getUserId()+"' and t.reportTitle='"+title+"的述职报告'";
	   String sql="from DspBasicWorkReport t where t.reporterCode='"+curUser.getUserId()+"' and t.reportTitle='"+title+"年度述职报告("+year+")'";
	   PubCommonDAO dao =FrameworkHelper.getDAO();
	   DspBasicWorkReport dbr=(DspBasicWorkReport)dao.queryAsAnObject(sql);
	   if(dbr==null){
		   return false;  
	   }
	   return true;
   }
	/**
	 * 模板文件下载的方法
	* <p>描述:</p>
	* @param type
	* @return
	* @author 张扬
	 */
	public static List<UploadItem> getDownloadItems(String type){
		List<DspFileAttach> datas = null;
		List<DspFileTemplate> datam = null;
		List<UploadItem> items = new ArrayList<UploadItem>();
		List<String> paramM = new ArrayList<String>();
		
		paramM.add(type);
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspFileTemplate t WHERE t.templateType=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datam = dao.getQueryList(sql.toString(), paramM.toArray());
		for(DspFileTemplate m : datam){
			StringBuilder sqla = new StringBuilder();
			List<String> paramA = new ArrayList<String>();
			String fileId = m.getTemplateFileId();
			sqla.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
			paramA.add(fileId);
			datas = dao.getQueryList(sqla.toString(), paramA.toArray());
			for(DspFileAttach a : datas){
				DspFileAttach attach = datas.get(0);
				UploadItem it = new UploadItem();
				it.setId(attach.getFileAttachId());
				it.setSuffix(attach.getFileExt());
				it.setSize(String.valueOf(attach.getFileSize()));
				it.setName(attach.getFileName());
				items.add(it);
			}
		}
		return items;
	}
	
	public String getGenderNameByGender(String gender){
		String sql="from SysCode t where t.id.typeId='0303' and t.id.codeValue='"+gender+"'";
		 PubCommonDAO dao =FrameworkHelper.getDAO();
		 SysCode sc=(SysCode)dao.queryAsAnObject(sql);
		 return sc.getCodeName();
	}
}

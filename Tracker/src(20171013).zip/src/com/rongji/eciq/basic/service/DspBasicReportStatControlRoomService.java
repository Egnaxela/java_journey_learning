package com.rongji.eciq.basic.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicReportStat;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.system.entity.SysCode;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.AbstractService;
@Service
@Transactional
public class DspBasicReportStatControlRoomService extends AbstractService{
	public List<DspBasicReportStat> findReportList(Page page,String userId){
//		page.setPageSize(8);
		List<DspBasicReportStat> dbrs=new ArrayList<DspBasicReportStat>();
		String sql="from DspBasicReportStat t where t.reportStatus='3' or t.reportStatus='2' or t.reportStatus='4' order by t.reportDate desc";
		PubCommonDAO dao =FrameworkHelper.getDAO();
        
		List<DspBasicReportStat> dbrsList=dao.getQueryList(sql,page);
		return dbrsList;
	}
	
		/**
		 * 通过报告id获取报告的详细信息
		* <p>描述:</p>
		* @param reporterId
		* @return
		* @author 张扬
		 */
		public DspBasicReportStat getReportDetailById(String workReportId){
			PubCommonDAO dao =FrameworkHelper.getDAO();
//			DspBasicWorkReport dwr=new DspBasicWorkReport();
			String sql="from DspBasicReportStat t where t.workReportId='"+workReportId+"'";
			DspBasicReportStat dwr=(DspBasicReportStat)dao.queryAsAnObject(sql);
			return dwr;
		}

		
		public List<UploadItem> getItemsByReporterId(String reporterId){
			StringBuilder sql=new StringBuilder();
			sql.append("from DspFileAttach t where t.fileAttachId in" +
					" (select d.fileId  from DspFileManage d where d.bizId=" +
					"(select b.reportFileId from DspBasicReportStat b where b.workReportId='");
			sql.append(reporterId);
			sql.append("'))");
			PubCommonDAO dao =FrameworkHelper.getDAO();
			List<DspFileAttach> dfa =dao.getQueryList(sql.toString());
			List<UploadItem> items=new ArrayList<UploadItem>();
			if(Utils.notEmpty(dfa)){
				Iterator<DspFileAttach> it=dfa.iterator();
				while(it.hasNext()){
					DspFileAttach df=it.next();
					UploadItem ui=new UploadItem();
					ui.setId(df.getFileAttachId());
					ui.setSuffix(df.getFileExt());
					ui.setSize(String.valueOf(df.getFileSize()));
					ui.setName(df.getFileName());
					items.add(ui);
				}
			}
			return items;
		}
		/**
		 * 保存对象
		* <p>描述:</p>
		* @param dwr
		* @author 张扬
		 */
		public void saveReport(DspBasicReportStat dwr){	
			PubCommonDAO dao =FrameworkHelper.getDAO();
			dao.updateObject(dwr);	
		}
		
		/**
		 * 条件查询报告
		* <p>描述:</p>
		* @param request
		* @return
		* @author zhangyang 
		 */
		public List<DspBasicReportStat> findReportListBySearch(HttpServletRequest request,Page page) {
			page.setPageSize(10);
			String reportEmpCode = request.getParameter("reportEmpCode");
			String higherCode = request.getParameter("higherCode");
			String fromtime = request.getParameter("fromtime");
			String totime = request.getParameter("totime");
			String reportType = request.getParameter("reportType");
			String reportStatus=request.getParameter("reportStatus");
			
			HttpSession session=request.getSession();
			session.setAttribute("reportEmpCode", reportEmpCode);
			session.setAttribute("higherCode", higherCode);
			session.setAttribute("fromtime", fromtime);
			session.setAttribute("totime", totime);
			session.setAttribute("reportType",reportType);
			session.setAttribute("reportStatus",reportStatus);
			
			
			List<DspBasicReportStat> datas = new ArrayList<DspBasicReportStat>();
			List<String> param=new ArrayList<String>();
			StringBuilder sb = new StringBuilder();
			sb.append(" from DspBasicReportStat t where t.reportStatus !='0' and t.reportStatus !='1' ");
			boolean condition = true;
			if(Utils.notEmpty(reportEmpCode)){
//				sb.append(condition?" where ":" and ");
				sb.append("and  t.reportEmpName like ? ");
				param.add("%"+reportEmpCode+"%");
				condition=false;
			}
			if(Utils.notEmpty(higherCode)){
//				sb.append(condition?" where ":" and ");
				sb.append("and  t.higherCode = ? ");
				param.add(higherCode);
				condition=false;
			}
			if(Utils.notEmpty(reportStatus)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportStatus = ? ");
				param.add(reportStatus);
				condition=false;
			}
			if(Utils.notEmpty(fromtime)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(fromtime);
				condition=false;
			}
			if(Utils.notEmpty(totime)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(totime);
				condition=false;
			}
			if(Utils.notEmpty(reportType)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportType = ? ");
				param.add(reportType);
				condition=false;
			}
			sb.append(" order by t.reportDate desc ");
			System.out.println(sb.toString());
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sb.toString(), page,param.toArray());
			
			return datas;
		}
		/**
		 * session条件查询报告
		* <p>描述:</p>
		* @param request
		* @return
		* @author zhangyang 
		 */
		public List<DspBasicReportStat> findReportListBySession(HttpServletRequest request,Page page) {
			page.setPageSize(10);
			SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
			HttpSession session=request.getSession();
			String reportEmpCode = (String) session.getAttribute("reportEmpCode");
			String higherCode = (String) session.getAttribute("higherCode");
			String fromtime =  (String) session.getAttribute("fromtime");
			String totime =  (String) session.getAttribute("totime");
			String reportType =  (String) session.getAttribute("reportType");
			String reportStatus=(String) session.getAttribute("reportStatus");
						
			List<DspBasicReportStat> datas = new ArrayList<DspBasicReportStat>();
			List<String> param=new ArrayList<String>();
			StringBuilder sb = new StringBuilder();
			sb.append(" from DspBasicReportStat t  where t.reportStatus !='0' and t.reportStatus !='1' ");
			boolean condition = true;
			if(Utils.notEmpty(reportEmpCode)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportEmpName like ? ");
				param.add("%"+reportEmpCode+"%");
				condition=false;
			}else{
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportEmpCode = ? ");
				param.add(curUser.getUserId());
				condition=false;
			}
			if(Utils.notEmpty(higherCode)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.higherCode = ? ");
				param.add(higherCode);
				condition=false;
			}
			if(Utils.notEmpty(reportStatus)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportStatus = ? ");
				param.add(reportStatus);
				condition=false;
			}
			if(Utils.notEmpty(fromtime)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(fromtime);
				condition=false;
			}
			if(Utils.notEmpty(totime)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(totime);
				condition=false;
			}
			if(Utils.notEmpty(reportType)){
//				sb.append(condition?" where ":" and ");
				sb.append("and t.reportType = ? ");
				param.add(reportType);
				condition=false;
			}
			sb.append(" order by t.reportDate desc ");
		
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sb.toString(), page,param.toArray());
			
			return datas;
		}
		//通过人员的id获取人员的详细信息
		public SysUser2 getUser(String userId) {
			if(userId.equals("")||userId==""||userId==null||userId.equals(null)){
				return new SysUser2();	
			}
			PubCommonDAO dao =FrameworkHelper.getDAO();
			SysUser2 su=(SysUser2)dao.queryAsAnObject("FROM SysUser t WHERE t.userId=?", userId);
			if(su==null){
				return new SysUser2();
			}
			return su;
		}
		/**
		 * 通过职务编码获取职务名称
		* <p>描述:</p>
		* @param gender
		* @return
		* @author 张扬
		 */
		public String getGenderNameByGender(String gender){
			String sql="from SysCode t where t.id.typeId='0303' and t.id.codeValue='"+gender+"'";
			 PubCommonDAO dao =FrameworkHelper.getDAO();
			 SysCode sc=(SysCode)dao.queryAsAnObject(sql);
			 return sc.getCodeName();
		}
		
		/**
		 * 通过部门id获取部门名称
		* <p>描述:</p>
		* @param deptNo
		* @return
		* @author zhangyang
		 */
			public String getDeptNameByDeptNo(String deptNo){
				String dn="";
				
				if(deptNo==null||deptNo==""){
					return "";
				}
				dn=deptNo.trim();
			    String[] deptNos=deptNo.split(",");
				PubCommonDAO dao =FrameworkHelper.getDAO();
				String sql="";
			
				String deptName="";
				for(int i=0;i<deptNos.length;i++){
					sql="from SysDept t where t.deptNo='"+deptNos[i]+"'";
					SysDept sd=(SysDept)dao.queryAsAnObject(sql);
					if(sd==null){
						continue;
					}
					deptName=deptName+sd.getDeptName()+",";
				}
			   
//				List<SysDept> sd=dao.getQueryList(sql); 
//				if(sd.size()<1){
//					return "";
//				}
				return deptName.substring(0,deptName.length()-1);
			}
}

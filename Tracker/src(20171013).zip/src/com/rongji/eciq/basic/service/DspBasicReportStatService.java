package com.rongji.eciq.basic.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.engines.xmltmpl.command.CommandGroup;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicReportStat;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.entity.DspFileTemplate;
import com.rongji.system.entity.SysCode;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

@Service
@Transactional
public class DspBasicReportStatService {
 
	public List<DspBasicReportStat> findReportList(Page page,String userId){
		page.setPageSize(8);
		List<DspBasicReportStat> dbrs=new ArrayList<DspBasicReportStat>();
		String sql="from DspBasicReportStat t where t.reportEmpCode='"+userId+"' order by t.reportDate desc";
		PubCommonDAO dao =FrameworkHelper.getDAO();
        
		List<DspBasicReportStat> dbrsList=dao.getQueryList(sql,page);
		return dbrsList;
	}
	
	@SuppressWarnings("unused")
	public void saveNewReport(HttpServletRequest request, HttpServletResponse response) throws Exception{
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
	    List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
		String reportTitle = request.getParameter("reportTitleText");
		String reportBrief = request.getParameter("reportBrief");
//		String higherName = request.getParameter("higherNameText");
		String reportJob = request.getParameter("reportJobText");
		String reportEmpName = request.getParameter("reportEmpNameText");
		String reportDateText = request.getParameter("reportDateText");
		String reportType = request.getParameter("reportType");
		String time = request.getParameter("time");
		
		String title =time.replace("-", "年")+"月"+curUser.getUserName()+"的"+status1.get(Integer.parseInt(reportType.trim()))[1];
		if("2".equals(reportType)||"3".equals(reportType)){
			String [] rods=time.split("-");
			int month=Integer.parseInt(rods[1]);
			String quarter=String.valueOf(month/4+1);
			title=rods[0]+"年"+quarter+"季度"+curUser.getUserName()+"的"+status1.get(Integer.parseInt(reportType.trim()))[1];
		}
		
		String ufiles = request.getParameter("ufiles");
		if (ufiles == null || "".equals(ufiles)) {
			FrameworkHelper.outPutXML(response, new CommandGroup("123"));
			return ;
		}
		// 获取已经存在的文件
		UploadItem[] items = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		List<String> itemId=new ArrayList<String>();
		for (UploadItem item : items) {
			itemId.add(item.getId());
		}
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM");
		DspBasicReportStat dbrs=new DspBasicReportStat();
		dbrs.setWorkReportId(UUID.randomUUID().toString().replaceAll("-", ""));
		dbrs.setHigherCode(curUser.getLeader());
//		dbrs.setHigherName(higherName);
		dbrs.setReportBrief(reportBrief);
		dbrs.setReportDate(sdf.parse(reportDateText));
		dbrs.setReportOfDate(sdf1.parse(time));
	
		dbrs.setReportEmpCode(curUser.getUserId());
		dbrs.setReportEmpName(reportEmpName);
		dbrs.setReportFileId(UUID.randomUUID().toString().replaceAll("-", ""));
		dbrs.setReportStatus("1");
		dbrs.setReportTitle(title);
		dbrs.setReportType(reportType);
		
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.saveObject(dbrs);
		Iterator<String> it=itemId.iterator();
	    while(it.hasNext()){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileId(it.next());
			fileManage.setBizId(dbrs.getReportFileId());
			fileManage.setOperTime(dbrs.getReportDate());
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setUserId(curUser.getUserId());
//			fileManage.setFileContent("zhangyang"+new Date());
			dao.saveObject(fileManage);
		}
	}
	
	/**
	 * 根据id删除报告
	* <p>描述:</p>
	* @param ids
	* @return
	* @throws Exception
	* @author 朱世平
	 */
		public void deleteReportByIds(String[] ids) throws Exception {
			List<DspBasicReportStat> datas = null;
			List<String> paramM = null;
			String bizId = null;
			for(int i=0;i<ids.length;i++){
				String reporterId = ids[i];
				//取到fileId----对应filemanage中的bizid
				StringBuilder sql=new StringBuilder();
				 sql.append(" FROM DspBasicReportStat t WHERE t.workReportId=?   ");
				List<String> param=new ArrayList<String>();
				param.add(reporterId);
				//判断
				PubCommonDAO dao =FrameworkHelper.getDAO();
				datas=dao.getQueryList(sql.toString(), param.toArray());
				if(Utils.notEmpty(datas)){
					paramM=new ArrayList<String>();
					bizId = datas.get(0).getReportFileId();
					if(Utils.notEmpty(bizId)){
						paramM.add(bizId);
						dao.deleteSQL(" from DspFileManage t where t.bizId=?", paramM.toArray());
						System.out.println("删除附件表数据  bizid="+bizId);
						dao.deleteSQL(" from DspBasicReportStat t where t.workReportId=?", param.toArray());
						System.out.println("删除表格上报表数据  recordId="+reporterId);
					}
				}
			}
		}
		
		/**
		 * 通过报告id获取报告的详细信息
		* <p>描述:</p>
		* @param reporterId
		* @return
		* @author 张扬
		 */
		public DspBasicReportStat getReportDetailById(String workReportId){
			PubCommonDAO dao =FrameworkHelper.getDAO();
//			DspBasicWorkReport dwr=new DspBasicWorkReport();
			String sql="from DspBasicReportStat t where t.workReportId='"+workReportId+"'";
			DspBasicReportStat dwr=(DspBasicReportStat)dao.queryAsAnObject(sql);
			return dwr;
		}

		
		public List<UploadItem> getItemsByReporterId(String reporterId){
			StringBuilder sql=new StringBuilder();
			sql.append("from DspFileAttach t where t.fileAttachId in" +
					" (select d.fileId  from DspFileManage d where d.bizId=" +
					"(select b.reportFileId from DspBasicReportStat b where b.workReportId='");
			sql.append(reporterId);
			sql.append("'))");
			PubCommonDAO dao =FrameworkHelper.getDAO();
			List<DspFileAttach> dfa =dao.getQueryList(sql.toString());
			List<UploadItem> items=new ArrayList<UploadItem>();
			if(Utils.notEmpty(dfa)){
				Iterator<DspFileAttach> it=dfa.iterator();
				while(it.hasNext()){
					DspFileAttach df=it.next();
					UploadItem ui=new UploadItem();
					ui.setId(df.getFileAttachId());
					ui.setSuffix(df.getFileExt());
					ui.setSize(String.valueOf(df.getFileSize()));
					ui.setName(df.getFileName());
					items.add(ui);
				}
			}
			return items;
		}
//		/**
//		 * 保存对象
//		* <p>描述:</p>
//		* @param dwr
//		* @author 张扬
//		 */
//		public void saveReport(DspBasicReportStat dwr){	
//			PubCommonDAO dao =FrameworkHelper.getDAO();
//			dao.updateObject(dwr);	
//		}
		
		/**
		 * 更新对象
		* <p>描述:</p>
		* @param dwr
		* @author 张扬
		 */
		public void updateReport(DspBasicReportStat dwr){	
			PubCommonDAO dao =FrameworkHelper.getDAO();
			dao.updateObject(dwr);	
		}
		
		/**
		 * 条件查询报告
		* <p>描述:</p>
		* @param request
		* @return
		* @author zhangyang 
		 */
		public List<DspBasicReportStat> findReportListBySearch(HttpServletRequest request,Page page) {
			page.setPageSize(8);
			String reportEmpCode = request.getParameter("reportEmpCode");
			String higherCode = request.getParameter("higherCode");
			String fromtime = request.getParameter("fromtime");
			String totime = request.getParameter("totime");
			String reportType = request.getParameter("reportType");
			String reportStatus= request.getParameter("reportStatus");
			
			HttpSession session=request.getSession();
			session.setAttribute("reportEmpCode", reportEmpCode);
			session.setAttribute("higherCode", higherCode);
			session.setAttribute("fromtime", fromtime);
			session.setAttribute("totime", totime);
			session.setAttribute("reportType",reportType);
			session.setAttribute("reportStatus",reportStatus);
			
			
			List<DspBasicReportStat> datas = new ArrayList<DspBasicReportStat>();
			List<String> param=new ArrayList<String>();
			StringBuilder sb = new StringBuilder();
			sb.append(" from DspBasicReportStat t ");
			boolean condition = true;
			if(Utils.notEmpty(reportEmpCode)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportEmpName like ? ");
				param.add("%"+reportEmpCode+"%");
				condition=false;
			}
			if(Utils.notEmpty(higherCode)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.higherCode = ? ");
				param.add(higherCode);
				condition=false;
			}
			if(Utils.notEmpty(reportStatus)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportStatus = ? ");
				param.add(reportStatus);
				condition=false;
			}			
			if(Utils.notEmpty(fromtime)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(fromtime);
				condition=false;
			}
			if(Utils.notEmpty(totime)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(totime);
				condition=false;
			}
			if(Utils.notEmpty(reportType)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportType = ? ");
				param.add(reportType);
				condition=false;
			}
			sb.append(" order by t.reportDate desc ");
			System.out.println(sb.toString());
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sb.toString(), page,param.toArray());
			
			return datas;
		}
		/**
		 * session条件查询报告
		* <p>描述:</p>
		* @param request
		* @return
		* @author zhangyang 
		 */
		public List<DspBasicReportStat> findReportListBySession(HttpServletRequest request,Page page) {
			page.setPageSize(8);
			SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
			HttpSession session=request.getSession();
			String reportEmpCode = (String) session.getAttribute("reportEmpCode");
			String higherCode = (String) session.getAttribute("higherCode");
			String fromtime =  (String) session.getAttribute("fromtime");
			String totime =  (String) session.getAttribute("totime");
			String reportType =  (String) session.getAttribute("reportType");
			String reportStatus=  (String) session.getAttribute("reportStatus");
			
			List<DspBasicReportStat> datas = new ArrayList<DspBasicReportStat>();
			List<String> param=new ArrayList<String>();
			StringBuilder sb = new StringBuilder();
			sb.append(" from DspBasicReportStat t ");
			boolean condition = true;
			if(Utils.notEmpty(reportEmpCode)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportEmpName like ? ");
				param.add("%"+reportEmpCode+"%");
				condition=false;
			}else{
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportEmpCode = ? ");
				param.add(curUser.getUserId());
				condition=false;
			}
			if(Utils.notEmpty(higherCode)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.higherCode = ? ");
				param.add(higherCode);
				condition=false;
			}
			if(Utils.notEmpty(reportStatus)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportStatus = ? ");
				param.add(reportStatus);
				condition=false;
			}	
			if(Utils.notEmpty(fromtime)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportDate > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(fromtime);
				condition=false;
			}
			if(Utils.notEmpty(totime)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportDate < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(totime);
				condition=false;
			}
			if(Utils.notEmpty(reportType)){
				sb.append(condition?" where ":" and ");
				sb.append(" t.reportType = ? ");
				param.add(reportType);
				condition=false;
			}
			sb.append(" order by t.reportDate desc ");
			System.out.println(sb.toString());
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sb.toString(), page,param.toArray());
			
			return datas;
		}
		//通过人员的id获取人员的详细信息
		public SysUser2 getUser(String userId) {
			if(userId.equals("")||userId==""||userId==null||userId.equals(null)){
				return new SysUser2();	
			}
			PubCommonDAO dao =FrameworkHelper.getDAO();
			SysUser2 su=(SysUser2)dao.queryAsAnObject("FROM SysUser t WHERE t.userId=?", userId);
			if(su==null){
				return new SysUser2();
			}
			return su;
		}
		/**
		 * 模板文件下载的方法
		* <p>描述:</p>
		* @param type
		* @return
		* @author 张扬
		 */
		public static List<UploadItem> getDownloadItems(String type){
			List<DspFileAttach> datas = null;
			List<DspFileTemplate> datam = null;
			List<UploadItem> items = new ArrayList<UploadItem>();
			List<String> paramM = new ArrayList<String>();
			
			paramM.add(type);
			StringBuilder sql = new StringBuilder();
			sql.append(" FROM DspFileTemplate t WHERE t.templateType=?   ");
			PubCommonDAO dao = FrameworkHelper.getDAO();
			datam = dao.getQueryList(sql.toString(), paramM.toArray());
			for(DspFileTemplate m : datam){
				StringBuilder sqla = new StringBuilder();
				List<String> paramA = new ArrayList<String>();
				String fileId = m.getTemplateFileId();
				sqla.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
				paramA.add(fileId);
				datas = dao.getQueryList(sqla.toString(), paramA.toArray());
				for(DspFileAttach a : datas){
					DspFileAttach attach = datas.get(0);
					UploadItem it = new UploadItem();
					it.setId(attach.getFileAttachId());
					it.setSuffix(attach.getFileExt());
					it.setSize(String.valueOf(attach.getFileSize()));
					it.setName(attach.getFileName());
					items.add(it);
				}
			}
			return items;
		}
		
		/**
		 *根据报告的标题 和当前登录人的id 判断某个报告是否存在，存在则返回true
		* <p>描述:</p>
		* @param userId
		* @param title
		* @return
		* @author 张扬
		 */
		public boolean isExitReport(String userId,String title){
			String sql="from DspBasicReportStat t where t.reportTitle='"+title+"' and t.reportEmpCode='"+userId+"'";
		    PubCommonDAO dao =FrameworkHelper.getDAO();
		    DspBasicReportStat dbrs=(DspBasicReportStat)dao.queryAsAnObject(sql);
		    if(dbrs==null){
		    	return false;
		    }
			return true;
		}
		/**
		 * 通过职务编码获取职务
		* <p>描述:</p>
		* @param gender
		* @return
		* @author 张扬
		 */
		public String getGenderNameByGender(String gender){
			String sql="from SysCode t where t.id.typeId='0303' and t.id.codeValue='"+gender+"'";
			 PubCommonDAO dao =FrameworkHelper.getDAO();
			 SysCode sc=(SysCode)dao.queryAsAnObject(sql);
			 return sc.getCodeName();
		}
//		/**
//		 * 通过部门编码获取部门名称
//		* <p>描述:</p>
//		* @param deptNo
//		* @return
//		* @author 张扬
//		 */
//		public String getDeptNameByDeptNo(String deptNo){
//			String sql="from SysDept t where t.deptNo='"+deptNo+"'";
//			 PubCommonDAO dao =FrameworkHelper.getDAO();
//			 SysDept sd=(SysDept)dao.queryAsAnObject(sql);
//			 return sd.getDeptName();
//		}
		
		/**
		 * 通过部门id获取部门名称
		* <p>描述:</p>
		* @param deptNo
		* @return
		* @author zhangyang
		 */
			public String getDeptNameByDeptNo(String deptNo){
				String dn="";
				
				if(deptNo==null||deptNo==""){
					return "";
				}
				dn=deptNo.trim();
			    String[] deptNos=deptNo.split(",");
				PubCommonDAO dao =FrameworkHelper.getDAO();
				String sql="";
			
				String deptName="";
				for(int i=0;i<deptNos.length;i++){
					sql="from SysDept t where t.deptNo='"+deptNos[i]+"'";
					SysDept sd=(SysDept)dao.queryAsAnObject(sql);
					if(sd==null){
						continue;
					}
					deptName=deptName+sd.getDeptName()+",";
				}
			   
//				List<SysDept> sd=dao.getQueryList(sql); 
//				if(sd.size()<1){
//					return "";
//				}
				return deptName.substring(0,deptName.length()-1);
			}
}

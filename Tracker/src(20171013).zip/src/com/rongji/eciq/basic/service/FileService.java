package com.rongji.eciq.basic.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.eciq.entity.DspFileAttach;

@Service
public class FileService {

	public void saveFileInfo(DspFileAttach dfa) {
		FrameworkHelper.getDAO().saveObject(dfa);
	}

	public void deleteFile(String fileAttachId) {
		FrameworkHelper.getDAO().deleteSQL(
				"from DspFileAttach t where t.fileAttachId=?",
				fileAttachId);
	}

	public DspFileAttach getFileAttach(String fileAttachId) {
		DspFileAttach dfa = (DspFileAttach) FrameworkHelper.getDAO()
				.queryAsAnObject("from DspFileAttach a where a.fileAttachId=?",
						fileAttachId);
		return dfa;
	}

	public List<DspFileAttach> getFileAttachs(String bizId) {
		return null;
	}

}

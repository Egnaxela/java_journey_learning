package com.rongji.eciq.basic.service;

import static com.rongji.dfish.framework.FrameworkHelper.getDAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicCompReport;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.entity.DspFileTemplate;
import com.rongji.system.pub.service.PubService;

/**
 * Description: 举报投诉办理服务层 
 * 
 * @author  作者 : 侯小全
 * @version 创建时间：2017-1-11 上午11:37:17
 */

@Service
@Transactional
public class ReportComplaintsService extends PubService{
	/**
	 * 获取主页面及查询时的参数
	 * @param request
	 * @return
	 */
	public static FilterParam getMainFilterParam(
			HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("complaintsReportId");
		fp.registerKey("complainantName");
		fp.registerKey("telephone");
		fp.registerKey("company");
		fp.registerKey("reportDate");
		fp.registerKey("handleStatus");
		fp.registerKey("handleDate");
		fp.registerKey("deptName");
		fp.registerKey("reportStartDate");
		fp.registerKey("reportEndDate");
		fp.registerKey("position");
		fp.registerKey("source");
		fp.registerKey("dates");
		fp.registerKey("recordPerson");
		fp.registerKey("bizId");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	 * 获取全部举报投诉信息记录
	 * @param page
	 * @param fp
	 * @param operId
	 * @return
	 */
	public List<DspBasicCompReport> findReportCompList(Page page,
			FilterParam fp, String loginUser) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicCompReport t WHERE 1=1 order by t.reportDate desc");
		List<String> param=new ArrayList<String>();
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspBasicCompReport> datas = new ArrayList<DspBasicCompReport>();
		datas=dao.getQueryList(sql.toString(), page, param.toArray());
		return datas;
	}

	/**
	* <p>描述:保存举报录入信息</p>
	* @param dBReport
	* @author 侯小全
	* @throws ParseException 
	*/
	public void saveReport(DspBasicCompReport dBReport, String filetTableId,
			List<String> fileIDs, HttpServletRequest request,String temp) throws ParseException {
		
		FilterParam fp = ReportComplaintsService.getMainFilterParam(request);
		String reportDate = dBReport.getReportDate();
		String dstr=fp.getValueAsString("dates");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date rdate=sdf.parse(reportDate);
		dBReport.setBizId(filetTableId);
		dBReport.setDates(dstr);
		for(int i=0;i<fileIDs.size();i++){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setFileId(fileIDs.get(i));
			fileManage.setBizId(filetTableId);
			fileManage.setOperTime(rdate);
			getDAO().saveObject(fileManage);
		}
		PubCommonDAO dao = FrameworkHelper.getDAO();
		if (Utils.notEmpty(temp) && temp.equals("1")) {
			dBReport.setHandleStatus("1");
			dao.saveObject(dBReport);
		} else if(Utils.notEmpty(temp)&& temp.equals("2")){
			dBReport.setHandleStatus("2");
			dao.saveObject(dBReport);
		} else if(Utils.notEmpty(temp)&& temp.equals("3")){
			dBReport.setHandleStatus("3");
			dao.saveObject(dBReport);
		}else if(Utils.notEmpty(temp)&& temp.equals("4")){
			dBReport.setHandleStatus("4");
			dao.saveObject(dBReport);
		}else if(Utils.notEmpty(temp)&& temp.equals("5")){
			dBReport.setHandleStatus("5");
			dao.saveObject(dBReport);
		}
		
	}

	/**
	 * 根据条件查询录入信息
	 * @param fp
	 * @param page
	 * @return
	 */
	public List<DspBasicCompReport> getListByFp(Page page,FilterParam fp){
		StringBuilder sql=new StringBuilder();
		//先写一个查询的主句
		sql.append("FROM DspBasicCompReport d WHERE 1=1");
		//获取参数
		List<String> param=new ArrayList<String>();
		if (fp!=null) {
			String complaintsReportId = fp.getValueAsString("complaintsReportId");
			String complainantName = fp.getValueAsString("complainantName");
			String deptName = fp.getValueAsString("deptName"); 
			String handleStatus = fp.getValueAsString("handleStatus");
			String reportStartDate = fp.getValueAsString("reportStartDate");
			String reportEndDate = fp.getValueAsString("reportEndDate");
			
			//拼sql，设置参数
			if(Utils.notEmpty(complaintsReportId))
			{
				sql.append(" and d.complaintsReportId like ? ");
				param.add("%"+complaintsReportId+"%");
			}
			if(Utils.notEmpty(complainantName))
			{
				sql.append(" and d.complainantName like ? ");
				param.add("%"+complainantName+"%");
			}
			if(Utils.notEmpty(deptName)){
				sql.append(" and d.deptName like ? ");
				param.add("%"+deptName+"%");  
			}
			if(Utils.notEmpty(reportStartDate)){
				sql.append(" and to_date(d.reportDate,'yyyy-MM-dd HH24:mi:ss') > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(reportStartDate);
			}
			if(Utils.notEmpty(reportEndDate)){
				sql.append(" and to_date(d.reportDate,'yyyy-MM-dd HH24:mi:ss') < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
				param.add(reportEndDate);
			}
			if(Utils.notEmpty(handleStatus)){
				sql.append(" and d.handleStatus like ? ");
				param.add("%"+handleStatus+"%");
			}
		}
		sql.append(" ORDER BY d.reportDate desc");
		List<DspBasicCompReport> datas= pubCommonDAO.getQueryList(sql.toString(), page, param.toArray());
		return datas;
	}

	/**
	 * 根据ID删除一个对象
	 * @param workId
	 */
	public void deleteReport(String comId){
		DspBasicCompReport dspBasicCompReport = getReportByID(comId);
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.delete(dspBasicCompReport);
	}
	
	/**
	 * 根据主键id获得对象
	 * @param workId
	 * @return
	 */
	public DspBasicCompReport getReportByID(String complaintsReportId){
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspBasicCompReport> list = dao.getQueryList("from DspBasicCompReport t where t.complaintsReportId = ?", complaintsReportId);
		if(list!=null){
			return list.get(0);
		}
		return null;
	}

	/**
	 * 根据ID获取举报信息录入表记录
	 * @param recordId
	 * @return
	 */
	public static DspBasicCompReport getRecordById(String recordId){
		List<DspBasicCompReport> datas = null;
		List<String> paramM = new ArrayList<String>();
		paramM.add(recordId);
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspBasicCompReport t WHERE t.complaintsReportId=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), paramM.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0);
		}
		return new DspBasicCompReport();
	}
	
	/**
	 * 获取所有登记表序号
	 * @param workId
	 * @return
	 * @author 侯小全
	 */
	public static List<String> getIdList() {
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<String> li = dao.getQueryList("select d.complaintsReportId from DspBasicCompReport d");
		return li;
	}
	
	/**
	 * <p>描述:分页</p>
	 * @param request
	 * @return
	 * @author 侯小全
	 */
	public static Page getPage(HttpServletRequest request) {
		String cp = request.getParameter("cp");
		Page page = new Page();
		page.setPageSize(8);
		int curPage = 1;
		try {
			curPage = Integer.parseInt(cp);
		} catch (Exception ex) {
			curPage = 1;
		}
		page.setCurrentPage(curPage);
		return page;
	}
	
	/**
	 * <p>下载模板功能实现</p>
	 * @param request
	 * @param response
	 * @author 侯小全
	 */
	public static List<UploadItem> getDownloadItems(String type){
		List<DspFileAttach> datas = null;
		List<DspFileTemplate> datam = null;
		List<UploadItem> items = new ArrayList<UploadItem>();
		List<String> paramM = new ArrayList<String>();
		
		paramM.add(type);
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspFileTemplate t WHERE t.templateType=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datam = dao.getQueryList(sql.toString(), paramM.toArray());
		
		for(DspFileTemplate m : datam){
			StringBuilder sqla = new StringBuilder();
			List<String> paramA = new ArrayList<String>();
			String fileId = m.getTemplateFileId();
			sqla.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
			paramA.add(fileId);
			datas = dao.getQueryList(sqla.toString(), paramA.toArray());
			for(DspFileAttach a : datas){
				DspFileAttach attach = datas.get(0);
				UploadItem it = new UploadItem();
				it.setId(attach.getFileAttachId());
				it.setSuffix(attach.getFileExt());
				it.setSize(String.valueOf(attach.getFileSize()));
				it.setName(attach.getFileName());
				items.add(it);
			}
			
		}
		return items;
	}

	/**
	 * 转办时保存的数据
	 * @param request
	 * @return
	 * @author 侯小全
	 */
	public void saveReports(DspBasicCompReport dBReport) {
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.saveObject(dBReport);
	}

	/**
	 * 删除数据
	 * @param request
	 * @return
	 * @author 侯小全
	 */
	public static void deleteReports(DspBasicCompReport dBReport) {
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.delete(dBReport);
	}
	
	/**
	 * 转办逻辑实现
	 * @param id
	 * @param transfer
	 */
	public static void transfer(String id, DspBasicCompReport db, String temp) {
		deleteReports(db);
		db.setHandleStatus(temp);
		PubCommonDAO dao =FrameworkHelper.getDAO();
		dao.saveObject(db);
	}
	
	/**
	* <p>描述:按照ID获取附件信息</p>
	* @param complaintsReportId1
	* @return
	* @author 侯小全
	*/
	public static List<UploadItem> getItemsById(String complaintsReportId){
		List<UploadItem> item = new ArrayList<UploadItem>();
		//fileId   bizId    attach_id
		List<DspBasicCompReport> datas = null;
		String bizId = null;
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicCompReport t WHERE t.complaintsReportId=?   ");
		List<String> param=new ArrayList<String>();
		param.add(complaintsReportId);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			param=new ArrayList<String>();
			bizId = datas.get(0).getBizId();//bizId   可能对应多个fileManageId
			List<DspFileManage> dataM = null;
			List<String> paramM = new ArrayList<String>();
			StringBuilder sqlM=new StringBuilder();
			sqlM.append(" FROM DspFileManage t WHERE t.bizId=?   ");
			paramM.add(bizId);
			dataM=dao.getQueryList(sqlM.toString(), paramM.toArray());
			if(Utils.notEmpty(dataM)){
				for(DspFileManage fileM:dataM){
					String fileId = fileM.getFileId();
					List<DspFileAttach> dataA = null;
					List<String> paramA = new ArrayList<String>();
					StringBuilder sqlA=new StringBuilder();
					sqlA.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
					paramA.add(fileId);
					dataA=dao.getQueryList(sqlA.toString(), paramA.toArray());
					if(Utils.notEmpty(dataA)){
						DspFileAttach attach = dataA.get(0);
						UploadItem it = new UploadItem();
						it.setId(attach.getFileAttachId());
						it.setSuffix(attach.getFileExt());
						it.setSize(String.valueOf(attach.getFileSize()));
						it.setName(attach.getFileName());
						item.add(it);
					}
				}
			}
		}
		return item;
	}
	
	/**
	 * 删除附件：获取参数
	 * @param request
	 * @return
	 */
	public static FilterParam getDeletebizId(HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("bizId");
		fp.registerKey("items");
		fp.registerKey("ufiles");
		fp.bindRequest(request);
		return fp;
	}
	
}

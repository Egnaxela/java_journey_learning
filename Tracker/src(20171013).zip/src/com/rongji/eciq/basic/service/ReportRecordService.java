/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     黄国海  
 * @version:    1.0
 * Createdate:   2017-1-3 下午12:02:43  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-3   黄国海      1.0         1.0 Version  
 */  


package com.rongji.eciq.basic.service;


import static com.rongji.dfish.framework.FrameworkHelper.getDAO;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.persistence.DspBasicReportRecord;
import com.rongji.eciq.entity.DspBasicReportRecordLog;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.entity.DspFileTemplate;
import com.rongji.system.entity.SysDept;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.PubService;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

/**
 * @author HuangGuoHai
 *
 */
@Service
@Transactional
public class ReportRecordService extends PubService{
	
	
	public static String getLeaderNameById(String leaderId){
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SysUser t WHERE 1=1  and t.userId=? ");
		List<String> param=new ArrayList<String>();
		param.add(leaderId);
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<SysUser2> datas = new ArrayList<SysUser2>();
		datas=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0).getUserName();
		}
		return null;
		
	}
	
	/**
	 * 获取查询参数
	 * @param request
	 * @return
	 */
	public static FilterParam getMainFilterParam(
			HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("recordId");
		fp.registerKey("reportPerName");
		fp.registerKey("reportPerCode");
		fp.registerKey("reportUnitCode");
		fp.registerKey("reportType");
		fp.registerKey("tableType");
		fp.registerKey("company");
		fp.registerKey("duty");
		fp.registerKey("brief");
		fp.registerKey("reportDate");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	 * 获取查询参数
	 * @param request
	 * @return
	 */
	public static FilterParam getSaveParam(
			HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		String operate = request.getParameter("operate");
		if(Utils.notEmpty(operate)){
			fp= getReSaveParam(request);
			return fp;
		}else{
			fp.registerKey("reporter");
			fp.registerKey("reporterName");
			fp.registerKey("reporterName1");
			fp.registerKey("recordId");
			fp.registerKey("reporter1");
			fp.registerKey("directCode");
			fp.registerKey("transferCode");
			fp.registerKey("tableType");
			fp.registerKey("brief");
			fp.registerKey("remark");
			fp.registerKey("brief");
			fp.registerKey("title");
			fp.registerKey("auditor");
			fp.registerKey("leader");
			fp.bindRequest(request);
			return fp;
		}
	}
	
	/**
	 * 获取查询参数
	 * @param request
	 * @return
	 */
	public static FilterParam getReSaveParam(
			HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("recordId");
		fp.registerKey("auditor");
		fp.registerKey("reportPerName");
		fp.registerKey("reportPerCode");
		fp.registerKey("duty");
		fp.registerKey("reporter");
		fp.registerKey("reporter1");
		fp.registerKey("transferCode");
		fp.registerKey("directCode");
		fp.registerKey("title");
		fp.registerKey("brief");
		fp.registerKey("remark");
		fp.registerKey("title");
		fp.registerKey("brief");
		fp.registerKey("remark");
		fp.registerKey("reportDate");
		fp.registerKey("ufiles");
		fp.registerKey("tableType");
		fp.bindRequest(request);
		return fp;
	}
	
	public static String getDirectorExcute(String directCode){
		if(Utils.notEmpty(directCode)){
			StringBuilder sql=new StringBuilder();
			sql.append(" FROM SysUser t WHERE t.userId=? ");
			List<String> param=new ArrayList<String>();
			param.add(directCode.contains(",")?directCode.substring(0,directCode.indexOf(",")):directCode);
			//判断
			PubCommonDAO dao =FrameworkHelper.getDAO();
			List<SysUser2> datas = new ArrayList<SysUser2>();
			datas=dao.getQueryList(sql.toString(),  param.toArray());
			if(Utils.notEmpty(datas)){
				return datas.get(0).getUserName();
			}
		}
		return null;
	}
	
	/**
	 * 获取全部记录
	 * @param page
	 * @param fp
	 * @param operId
	 * @return
	 */
	public List<DspBasicReportRecord> findDataList(Page page, FilterParam fp,String operId,String reportType) {

		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicReportRecord t WHERE 1=1  and t.reportType=? and (( t.reportPerCode=? ) or");
		sql.append("  ( (t.transferCode=? or t.directCode=? or t.reportPerCode=? or t.auditor=?) )) order by t.reportDate desc ");
		List<String> param=new ArrayList<String>();
		param.add(reportType);
		param.add(operId);
		param.add(operId);
		param.add(operId);
		param.add(operId);
		param.add(operId);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
		datas=dao.getQueryList(sql.toString(), page, param.toArray());
		return datas;
	
//		String reportType=null;
//		if(type.equals("lplj")){
//			reportType="01";
//		}else{
//			reportType="02";
//		}
//		StringBuilder sql=new StringBuilder();
//		sql.append(" FROM DspBasicReportRecord t WHERE 1=1  and t.reportType=? ");
//		sql.append(" and t.reportPerCode in (select a.reportPerCode from DspBasicReportRecord a ");
//		sql.append(" where (( a.transferCode=? or a.directCode=?) and a.reportStatus!=?) or a.reportPerCode=?) ");
//		List<String> param=new ArrayList<String>();
//		param.add(reportType);
//		param.add(operId);
//		param.add(operId);
//		param.add("4");
//		param.add(operId);
//		//判断
//		PubCommonDAO dao =FrameworkHelper.getDAO();
//		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
//		datas=dao.getQueryList(sql.toString(), page, param.toArray());
//		return datas;
	}
	
	/**
	 * 获取全部记录
	 * @param page
	 * @param fp
	 * @param operId
	 * @return
	 */
	public List<DspBasicReportRecord> findOwnDataList(Page page, FilterParam fp,String operId,String reportType) {

		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicReportRecord t WHERE 1=1  and t.reportType=? and t.reportPerCode=? ");
		sql.append(" order by t.reportDate desc ");
		List<String> param=new ArrayList<String>();
		param.add(reportType);
		param.add(operId);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
		datas=dao.getQueryList(sql.toString(), page, param.toArray());
		return datas;
	
//		String reportType=null;
//		if(type.equals("lplj")){
//			reportType="01";
//		}else{
//			reportType="02";
//		}
//		StringBuilder sql=new StringBuilder();
//		sql.append(" FROM DspBasicReportRecord t WHERE 1=1  and t.reportType=? ");
//		sql.append(" and t.reportPerCode in (select a.reportPerCode from DspBasicReportRecord a ");
//		sql.append(" where (( a.transferCode=? or a.directCode=?) and a.reportStatus!=?) or a.reportPerCode=?) ");
//		List<String> param=new ArrayList<String>();
//		param.add(reportType);
//		param.add(operId);
//		param.add(operId);
//		param.add("4");
//		param.add(operId);
//		//判断
//		PubCommonDAO dao =FrameworkHelper.getDAO();
//		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
//		datas=dao.getQueryList(sql.toString(), page, param.toArray());
//		return datas;
	}
	
	/**
	 * 保存数据
	 * @param fp
	 * @param bizId
	 * @param fileIDs
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	public void saveReportRecord(FilterParam fp, String bizId,
			List<String> fileIDs, HttpServletRequest request, String temp,String userId) {
		try {
			SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
			
			//添加进通知信息-----结束
			// 保存业务表-------开始
			DspBasicReportRecord record = getRecordById(fp.getValueAsString("recordId"));
			if(Utils.isEmpty(record.getRecordId())){
				record.setRecordId(UUID.randomUUID().toString().replaceAll("-", ""));
			}
			record.setReportPerName(curUser.getUserName());
			record.setReportPerCode(curUser.getUserId());
			String deptNo = getDeptNoById(fp.getValueAsString("reporter"));
			record.setReportUnitCode(deptNo);
			record.setReportUnitName(getUnitNameById(deptNo));
			record.setCompany(getUnitNameById(deptNo));
			record.setReportType(fp.getValueAsString("tableType"));
			record.setTransferCode(fp.getValueAsString("transferCode"));
			record.setDirectCode(fp.getValueAsString("directCode"));
			record.setReporter(fp.getValueAsString("reporter"));
			record.setReporterName(fp.getValueAsString("reporter1"));
			record.setRemark(fp.getValueAsString("remark"));
			record.setTitle(fp.getValueAsString("title"));
			record.setDuty(curUser.getUserTitle());
			record.setBrief(fp.getValueAsString("brief"));
			record.setAuditor(fp.getValueAsString("auditor"));
			record.setDirectCode(fp.getValueAsString("leader"));
			Date date = new Date();
			record.setReportDate(date);
			record.setBizId(bizId);
			
			if (Utils.notEmpty(temp) && temp.equals("4")&&existObject(record.getRecordId())) {
				record.setReportStatus("4");
				getDAO().updateObject(record);
			}else if (Utils.notEmpty(temp) && temp.equals("4")&&!existObject(record.getRecordId())) {
				record.setReportStatus("4");
				getDAO().saveObject(record);
			} else if(Utils.notEmpty(temp)&& temp.equals("0")&&existObject(record.getRecordId())){
				record.setReportStatus("0");
				getDAO().updateObject(record);
			}else if(Utils.notEmpty(temp)&& temp.equals("0")&&!existObject(record.getRecordId())){
				record.setReportStatus("0");
				getDAO().saveObject(record);
			}else {
				record.setReportStatus("0");
				record.setReporter(fp.getValueAsString("reporter"));
				record.setReporterName(fp.getValueAsString("reporter1"));
				getDAO().updateObject(record);
			}
			
			// 保存业务表-------结束
			// 保存进日志表------开始
			DspBasicReportRecordLog log = new DspBasicReportRecordLog();
			log.setReportRecordLogId(UUID.randomUUID().toString()
					.replaceAll("-", ""));
			log.setReportRecordId(record.getRecordId());
			log.setOperateDate(new Date());
			log.setReportType(record.getReportType());
			log.setOperatorId(userId);
			log.setReportStatus(record.getReportStatus());
			getDAO().saveObject(log);
			// 保存进日志表------结束
			// 关联附件表-------开始
			for (int i = 0; i < fileIDs.size(); i++) {
				DspFileManage fileManage = new DspFileManage();
				fileManage.setFileManageId(UUID.randomUUID().toString()
						.replaceAll("-", ""));
				fileManage.setFileId(fileIDs.get(i));
				fileManage.setBizId(bizId);
				fileManage.setOperTime(date);
				fileManage.setFileBizStyle("06");// 礼品礼金 type=lplj
				fileManage.setUserId(String.valueOf(((SysUser2) request
						.getSession().getAttribute("loginUser")).getUserId()));
				getDAO().saveObject(fileManage);
			}
			// 关联附件表-------结束
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public  boolean existObject(String recordId){
		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
		String sql = " from DspBasicReportRecord t where t.recordId=? ";
		List<String> param=new ArrayList<String>();
		param.add(recordId);
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sql.toString(),param.toArray());
		if(Utils.notEmpty(datas)){
			return true;
		}else{
			return false;
		}
	}
	
	
	public static void deleteFileAttachBeforeAdd(String recordId,List<String> fileIDs){
		if(Utils.notEmpty(recordId)){
			List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
			List<String> param=new ArrayList<String>();
			StringBuilder sb = new StringBuilder();
			sb.append(" from DspBasicReportRecord t where t.recordId=? ");
			param.add(recordId);
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sb.toString(),param.toArray());
			if(Utils.notEmpty(datas)){
				String bizId = datas.get(0).getBizId();
				if(Utils.notEmpty(bizId)){
					List<DspFileManage> ss = new ArrayList<DspFileManage>();
					StringBuilder selectS = new StringBuilder();
					List<String> paramS=new ArrayList<String>();
					selectS.append(" from DspFileManage t where t.bizId = ?");
					paramS.add(bizId);
					ss=dao.getQueryList(selectS.toString(),paramS.toArray());
					if(Utils.notEmpty(ss)){
						boolean condition = false;
						for(DspFileManage mm : ss){//历史
							for(String s : fileIDs){//当前
								if(mm.getFileId().equals(s)){
									condition=true;
								}
							}
							if(condition){
								StringBuilder sss = new StringBuilder();
								sss.append(" from DspFileManage t where t.fileId=?");
								List<String> paramD=new ArrayList<String>();
								paramD.add(mm.getFileId());
								condition = false;
								dao.deleteSQL(sss.toString(), paramD.toArray());
							}
						}
					}
				}
			}
		}
	}
	
//	public static void saveFileAttach(List<String> fileIDs){
//		for(String s : fileIDs){
//			DspFileAttach a = new DspFileAttach();
//			a.setFileAttachId(s);
//			
//		}
//		
//		
//	}
	/**
	 * 转办逻辑实现
	 * @param id
	 * @param transfer
	 */
	public static void transfer(String id,String transfer,String auditPropose,String operate,String userId){
		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
		List<String> param=new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
//		if(Utils.notEmpty("transfer")&&transfer.contains(",")){
//			transfer=transfer.substring(0, transfer.indexOf(","));
//		}
		sb.append(" from DspBasicReportRecord t where t.recordId=? ");
		param.add(id);
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sb.toString(),param.toArray());
		if(Utils.notEmpty(datas)){
			DspBasicReportRecord record = datas.get(0);
			if(Utils.notEmpty(operate)){
				record.setReportStatus("4");
			}else{
				record.setReportStatus("3");
			}
			
			record.setTransferCode(transfer);
			record.setAuditPropose(auditPropose);
			getDAO().updateObject(record);
			DspBasicReportRecordLog log = new DspBasicReportRecordLog();
			log.setReportRecordLogId(UUID.randomUUID().toString()
					.replaceAll("-", ""));
			log.setReportRecordId(record.getRecordId());
			log.setReportType(record.getReportType());
			log.setOperateDate(new Date());
			log.setOperatorId(userId);
			log.setReportStatus("3");
			getDAO().saveObject(log);
		}
	}
	
	/**
	 * 获取查询参数
	 * @param request
	 * @return
	 */
	public static FilterParam getSearchParam(HttpServletRequest request){
		FilterParam fp = new FilterParam();
		fp.registerKey("reportUnitCode1");
		fp.registerKey("reportUnitCode");
		fp.registerKey("reportStartDate");
		fp.registerKey("reportEndDate");
		fp.registerKey("reportStatus");
		fp.registerKey("tableType");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	 * 获取查询参数
	 * @param request
	 * @return
	 */
	public static String appendParam(FilterParam fp){
		StringBuilder sb = new StringBuilder();
		String reportUnitCode = "";
		String reportStatus = "";
		String reportStartDate = "";
		String reportEndDate = "";
		if(fp!=null){
			reportUnitCode = fp.getValueAsString("reportUnitCode");
			reportStatus = fp.getValueAsString("reportStatus");
			reportStartDate = fp.getValueAsString("reportStartDate");
			reportEndDate = fp.getValueAsString("reportEndDate");
			if(Utils.notEmpty(reportUnitCode)&&!reportUnitCode.equals("null")){
				sb.append("&reportUnitCode="+reportUnitCode);
			}
			if(Utils.notEmpty(reportStatus)&&!reportStatus.equals("null")){
				sb.append("&reportStatus="+reportStatus);
			}
			if(Utils.notEmpty(reportStartDate)&&!reportStartDate.equals("null")){
				sb.append("&reportStartDate="+reportStartDate);
			}
			if(Utils.notEmpty(reportEndDate)&&!reportEndDate.equals("null")){
				sb.append("&reportEndDate="+reportEndDate);
			}
		}
		return sb.toString();
	}
	
	/**
	 * 编码  名称替换
	 * @param datas
	 * @return
	 */
	public static List<DspBasicReportRecord> filterData(List<DspBasicReportRecord> datas){
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020102");
		List<Object[]> repotType = Services.getService(CodeManService.class).getCodeData("020101");

		for (DspBasicReportRecord record : datas) {
			if (Utils.notEmpty(status)) {
				for (Object[] o : status) {
					if (Utils.notEmpty(record.getReportStatus())) {
						if (record.getReportStatus().equals(
								String.valueOf(o[0]))) {
							record.setReportStatus(String.valueOf(o[1]));
						}
					}
				}
			}
			if (Utils.notEmpty(repotType)) {
				for (Object[] o : repotType) {
					if (Utils.notEmpty(record.getReportType())) {
						if (record.getReportType().equals(String.valueOf(o[0]))) {
							record.setReportType(String.valueOf(o[1]));
						}
					}
				}
			}
			
		}
		return datas;
	}
	
	/**
	 * 主查询实现
	 * @param fp
	 * @param page
	 * @return
	 */
	public static List<DspBasicReportRecord> mainSearch(FilterParam fp,Page page){
		String reportUnitCode = fp.getValueAsString("reportUnitCode1");
		String unitName = fp.getValueAsString("reportUnitCode");
		String reportType = fp.getValueAsString("tableType");
		String reportStartDate = fp.getValueAsString("reportStartDate");
		String reportEndDate = fp.getValueAsString("reportEndDate");
		String reportStatus = fp.getValueAsString("reportStatus");
		List<DspBasicReportRecord> datas = new ArrayList<DspBasicReportRecord>();
		List<String> param=new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		sb.append(" from DspBasicReportRecord t ");
		boolean condition = true;
		if(Utils.notEmpty(reportUnitCode)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportUnitCode = ? ");
			param.add(reportUnitCode);
			condition = false;
		}
		if(Utils.notEmpty(reportType)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportType = ? ");
			param.add(reportType);
			condition=false;
		}
		
		if(Utils.notEmpty(unitName)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportUnitName like ? ");
			param.add("%"+unitName+"%");
			condition=false;
		}
		
		if(Utils.notEmpty(reportStartDate)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportDate >= to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(reportStartDate);
			condition=false;
		}
		if(Utils.notEmpty(reportEndDate)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportDate <= to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(reportEndDate);
			condition=false;
		}
		if(Utils.notEmpty(reportStatus)){
			sb.append(condition?" where ":" and ");
			sb.append(" t.reportStatus = ? ");
			param.add(reportStatus);
			condition=false;
		}
		sb.append(" order by t.reportDate desc ");
		 
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sb.toString(), page,param.toArray());
		return datas;
	}
	
	/**
	 * 按照ID获取附件信息
	 * @param recordId
	 * @return
	 */
	public static List<UploadItem> getItemsByRecordId(String recordId){
		List<UploadItem> item = new ArrayList<UploadItem>();
		//fileId   bizId    attach_id
		List<DspBasicReportRecord> datas = null;
		String bizId = null;
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicReportRecord t WHERE t.recordId=?   ");
		List<String> param=new ArrayList<String>();
		param.add(recordId);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			param=new ArrayList<String>();
			bizId = datas.get(0).getBizId();//bizId   可能对应多个fileManageId
			List<DspFileManage> dataM = null;
			List<String> paramM = new ArrayList<String>();
			StringBuilder sqlM=new StringBuilder();
			sqlM.append(" FROM DspFileManage t WHERE t.bizId=?   ");
			paramM.add(bizId);
			dataM=dao.getQueryList(sqlM.toString(), paramM.toArray());
			if(Utils.notEmpty(dataM)){
				for(DspFileManage fileM:dataM){
					String fileId = fileM.getFileId();
					List<DspFileAttach> dataA = null;
					List<String> paramA = new ArrayList<String>();
					StringBuilder sqlA=new StringBuilder();
					sqlA.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
					paramA.add(fileId);
					dataA=dao.getQueryList(sqlA.toString(), paramA.toArray());
					if(Utils.notEmpty(dataA)){
						DspFileAttach attach = dataA.get(0);
						UploadItem it = new UploadItem();
						it.setId(attach.getFileAttachId());
						it.setSuffix(attach.getFileExt());
						it.setSize(String.valueOf(attach.getFileSize()));
						it.setName(attach.getFileName());
						item.add(it);
					}
				}
			}
		}
		return item;
	}
	
	public static List<UploadItem> getDownloadItems(String type){
		List<DspFileAttach> datas = null;
		List<DspFileTemplate> datam = null;
		List<UploadItem> items = new ArrayList<UploadItem>();
		List<String> paramM = new ArrayList<String>();
		
		paramM.add(type);
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspFileTemplate t WHERE t.templateType=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datam = dao.getQueryList(sql.toString(), paramM.toArray());
		for(DspFileTemplate m : datam){
			StringBuilder sqla = new StringBuilder();
			List<String> paramA = new ArrayList<String>();
			String fileId = m.getTemplateFileId();
			sqla.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
			paramA.add(fileId);
			datas = dao.getQueryList(sqla.toString(), paramA.toArray());
			for(DspFileAttach a : datas){
				DspFileAttach attach = datas.get(0);
				UploadItem it = new UploadItem();
				it.setId(attach.getFileAttachId());
				it.setSuffix(attach.getFileExt());
				it.setSize(String.valueOf(attach.getFileSize()));
				it.setName(attach.getFileName());
				items.add(it);
			}
		}
		return items;
	}
	
	/**
	 * 根据ID获取及业务表记录
	 * @param recordId
	 * @return
	 */
	public static DspBasicReportRecord getRecordById(String recordId){
		List<DspBasicReportRecord> datas = null;
		List<String> paramM = new ArrayList<String>();
		paramM.add(Utils.notEmpty(recordId)?recordId:"");
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspBasicReportRecord t WHERE t.recordId=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), paramM.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0);
		}
		return new DspBasicReportRecord();
	}
	
	/**
	 * 根据ID获取用户名
	 * @param recordId
	 * @return
	 */
	public static String getUserNameById(String recordId){
		List<SysUser2> datas = null;
		List<String> paramM = new ArrayList<String>();
		paramM.add(Utils.notEmpty(recordId)?recordId:"");
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysUser t WHERE t.userId=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), paramM.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0).getUserName();
		}
		return null;
	}
	
	/**
	 * 根据ID获取用户名
	 * @param recordId
	 * @return
	 */
	public static String getDeptNoById(String recordId){
		List<SysUser2> datas = null;
		List<String> paramM = new ArrayList<String>();
		paramM.add(Utils.notEmpty(recordId)?recordId:"");
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysUser t WHERE t.userId=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), paramM.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0).getDeptNo();
		}
		return null;
	}
	
	/**
	 * 根据ID获取用户名
	 * @param recordId
	 * @return
	 */
	public static String getUnitNameById(String recordId){
		List<SysDept> datas = null;
		List<String> paramM = new ArrayList<String>();
		paramM.add(Utils.notEmpty(recordId)?recordId:"");
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysDept t WHERE t.deptNo=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), paramM.toArray());
		if(Utils.notEmpty(datas)){
			return datas.get(0).getDeptName();
		}
		return null;
	}
	
	/**
	 * 删除记录逻辑实现
	 * @param ids
	 */
	public static void deleteRecordAndFileId(String[] ids) {
		List<DspBasicReportRecord> datas = null;
		List<String> paramM = null;
		String bizId = null;
		for(int i=0;i<ids.length;i++){
			String recordId = ids[i];
			//取到fileId----对应filemanage中的bizid
			StringBuilder sql=new StringBuilder();
			 sql.append(" FROM DspBasicReportRecord t WHERE t.recordId=?   ");
			List<String> param=new ArrayList<String>();
			param.add(recordId);
			//判断
			PubCommonDAO dao =FrameworkHelper.getDAO();
			datas=dao.getQueryList(sql.toString(), param.toArray());
			if(Utils.notEmpty(datas)){
				paramM=new ArrayList<String>();
				bizId = datas.get(0).getBizId();
				if(Utils.notEmpty(bizId)){
					paramM.add(bizId);
					dao.deleteSQL(" from DspFileManage t where t.bizId=?", paramM.toArray());
					System.out.println("删除附件表数据  bizid="+bizId);
					dao.deleteSQL(" from DspBasicReportRecord t where t.recordId=?", param.toArray());
					System.out.println("删除表格上报表数据  recordId="+recordId);
				}
			}
		}
	}
	
	/**
	 * 审批表格上报备案
	 * @param id
	 * @param propose
	 * @param type
	 */
	public static void auditOrForceReportRecord(String id,String propose,String userId,String type) {
		List<DspBasicReportRecord> datas = null;
		List<String> paramM = null;
		String bizId = null;

		StringBuilder sql = new StringBuilder();
		sql.append(" from DspBasicReportRecord t  WHERE t.recordId=?   ");
		List<String> param = new ArrayList<String>();
		param.add(id);
		// 判断
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			DspBasicReportRecord record = datas.get(0);
			record.setAuditPropose(propose);
			record.setReportStatus(type.trim());
			dao.updateObject(record);
			DspBasicReportRecordLog log = new DspBasicReportRecordLog();
			log.setReportRecordLogId(UUID.randomUUID().toString()
					.replaceAll("-", ""));
			log.setReportRecordId(record.getRecordId());
			log.setReportType(record.getReportType());
			log.setOperateDate(new Date());
			log.setOperatorId(userId);
			log.setReportStatus(type.trim());
			getDAO().saveObject(log);
		}
		
		
	}
	
	/**
	 * 根据ID获取当前备案状态
	 * @param id
	 * @return
	 */
	public static String getReportStatus(String id) {
		List<DspBasicReportRecord> datas = null;
		List<String> paramM = null;
		String bizId = null;

		String status = null;
		StringBuilder sql = new StringBuilder();
		sql.append(" from DspBasicReportRecord t  WHERE t.recordId=?   ");
		List<String> param = new ArrayList<String>();
		param.add(id);
		// 判断
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			status = datas.get(0).getReportStatus();
		}
		return status;
	}
	
}

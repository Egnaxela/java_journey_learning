package com.rongji.eciq.basic.service;

import static com.rongji.dfish.framework.FrameworkHelper.getDAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.dao.TalkMgrDao;
import com.rongji.eciq.basic.persistence.DspBasicTalkmgr;
import com.rongji.eciq.basic.view.TalkMgrView;
import com.rongji.eciq.common.util.BaseUtil;
import com.rongji.eciq.entity.DspFileManage;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.entity.DspFileTemplate;
import com.rongji.system.entity.SysUser;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

	/**  
	 * Description:   
	 * Copyright:   Copyright (c)2016 
	 * Company:     rongji  
	 * @author:     米亦磊 
	 * @version:    1.0  
	 * Create at:   2017-1-5 下午5:17:43  
	 *  
	 * Modification History:  
	 * Date         Author      Version     Description  
	 * ------------------------------------------------------------------  
	 * 2017-1-5   米亦磊    1.0         1.0 Version  
	 */  

@Service
@Transactional
@SuppressWarnings("unchecked")
public class TalkMgrService {

	static TalkMgrDao talkMgrDao = new TalkMgrDao();
	
	
	/**
	* <p>描述:序号获取</p>
	* @throws ParseException
	* @author 米亦磊
	 * @return 
	*/
	
	public static List<String> getStr() {
		List<String> list = new ArrayList<String>();
		String str = "THGL" + new SimpleDateFormat("yyyyMMdd").format(new Date());
		for (char c = 'A'; c <= 'Z'; c++)
			for (int j = 1; j <= 9999; j++){
				list.add(str + c + j);
			}
		return list;
	}
	
	/**
	* <p>描述:</p>
	* @param leaderId
	* @return
	* @author 米亦磊
	*/
	
	public static String getLeaderNameById(String leaderId) {

		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysUser t WHERE 1=1  and t.userCode=? ");
		List<String> param = new ArrayList<String>();
		param.add(leaderId);
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List<SysUser> datas = new ArrayList<SysUser>();
		datas = dao.getQueryList(sql.toString(), param.toArray());
		if (Utils.notEmpty(datas)) {
			return datas.get(0).getUserName();
		}
		return null;

	}
	
	/**
	* <p>描述:查询暂存数据</p>
	* @return
	* @author 米亦磊
	*/
	
	public static DspBasicTalkmgr selectByState(HttpServletRequest request){
		DspBasicTalkmgr talkMgr = talkMgrDao.selectByState(request);
//		if (talkMgr == null) {
//			return new DspBasicTalkmgr();
//		}
		return talkMgr;
	}
	
	/**
	* <p>描述:更新</p>
	* @param request
	* @param talkMgr
	* @param bizId
	* @param fileIDs
	* @throws ParseException
	* @author 米亦磊
	*/
	
	public void updateTalk(HttpServletRequest request,DspBasicTalkmgr talkMgr,String bizId,List<String> fileIDs) throws ParseException{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		FilterParam fp = TalkMgrView.getFilterParam(request);
		String dstr=fp.getValueAsString("talkStartTime");
		Date date=sdf.parse(dstr);
		talkMgr.setBizId(bizId);
		for(int i=0;i<fileIDs.size();i++){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setFileId(fileIDs.get(i));
			fileManage.setBizId(bizId);
			fileManage.setOperTime(date);
			getDAO().saveObject(fileManage);
		}
		talkMgrDao.updateTalk(request, talkMgr);
	}
	
	
	/**
	 * 
	* <p>统计查询参数:</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static FilterParam getStatParam(HttpServletRequest request){
		FilterParam fp = new FilterParam();
		fp.registerKey("year");
		fp.registerKey("quarter");
		fp.registerKey("month");
		fp.registerKey("targetUnitCode");
		fp.registerKey("excuteUnitCode");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	 * 
	* <p>统计查询参数:</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static FilterParam getParams(HttpServletRequest request){
		String type = request.getParameter("type");
		FilterParam fp = new FilterParam();
		if(Utils.notEmpty(type)&&type.equals("stat")){
			fp.registerKey("clickA");
			fp.registerKey("type");
			fp.bindRequest(request);
			String clickA = fp.getValueAsString("clickA");
			String[] c = clickA.split("_");
			if(!c[0].equals("a")){
				fp.registerKey("talkType");
				fp.setValueAsString("talkType", c[0]);
			}
			if(!c[1].equals("a")){
				fp.registerKey("talkTargetId");
				fp.setValueAsString("talkTargetId", c[1]);
			}
	        if(!c[2].equals("a")){
	        	fp.registerKey("talkPersonId");
	        	fp.setValueAsString("talkPersonId", c[2]);
			}
			if (!c[3].equals("a")) {
				fp.registerKey("year");
				fp.setValueAsString("year", c[3]);
			}
			if (!c[4].equals("a")) {
				fp.registerKey("quarter");
				fp.setValueAsString("quarter", c[4]);
			}
			if (!c[5].equals("a")) {
				fp.registerKey("month");
				fp.setValueAsString("month", c[5]);
			}
			return fp;
		}else if(Utils.notEmpty(type)&&type.equals("detail")){
			fp.registerKey("type");
			fp.registerKey("talkTargetId");
			fp.registerKey("talkPersonId");
			fp.registerKey("talkTargetName");
			fp.registerKey("talkPersonName");
			fp.registerKey("targetUnitName");
			fp.registerKey("excuteUnitName");
			fp.registerKey("targetUnitCode");
			fp.registerKey("excuteUnitCode");
			fp.registerKey("talkType");
			fp.registerKey("talkLevel");
			fp.registerKey("talkStartTime");
			fp.registerKey("talkEndTime");
			fp.registerKey("talkSite");
			fp.bindRequest(request);
			return fp;
		}else{
			return fp;
		}
	}
	
	public static String fp2String(FilterParam fp) {
		String type = fp.getValueAsString("type");
		StringBuilder sb = new StringBuilder();
		if (Utils.notEmpty(type) && type.equals("stat")) {
			if(Utils.notEmpty(fp.getValueAsString("type"))){
				sb.append("&type=").append(fp.getValueAsString("type"));
			}
			if(Utils.notEmpty(fp.getValueAsString("type"))){
				sb.append("&clickA=").append(fp.getValueAsString("clickA"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkType"))){
				sb.append("&talkType=").append(fp.getValueAsString("talkType"));
			}
			if(Utils.notEmpty(fp.getValueAsString("targetUnitCode"))){
				sb.append("&targetUnitCode=").append(
						fp.getValueAsString("targetUnitCode"));
			}
			if(Utils.notEmpty(fp.getValueAsString("type"))){
				sb.append("&excuteUnitCode=").append(
						fp.getValueAsString("excuteUnitCode"));
			}
			if(Utils.notEmpty(fp.getValueAsString("year"))){
				sb.append("&year=").append(fp.getValueAsString("year"));
			}
			if(Utils.notEmpty(fp.getValueAsString("quarter"))){
				sb.append("&quarter=").append(fp.getValueAsString("quarter"));
			}
			if(Utils.notEmpty(fp.getValueAsString("month"))){
				sb.append("&month=").append(fp.getValueAsString("month"));
			}
		} else if (Utils.notEmpty(type) && type.equals("detail")) {
			if(Utils.notEmpty(fp.getValueAsString("type"))){
				sb.append("&type=").append(fp.getValueAsString("type"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkTargetId"))){
				sb.append("&talkTargetId=").append(
						fp.getValueAsString("talkTargetId"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkPersonId"))){
				sb.append("&talkPersonId=").append(
						fp.getValueAsString("talkPersonId"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkType"))){
				sb.append("&talkType=").append(fp.getValueAsString("talkType"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkLevel"))){
				sb.append("&talkLevel=").append(fp.getValueAsString("talkLevel"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkStartTime"))){
				sb.append("&talkStartTime=").append(
						fp.getValueAsString("talkStartTime"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkEndTime"))){
				sb.append("&talkEndTime=").append(
						fp.getValueAsString("talkEndTime"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkSite"))){
				sb.append("&talkSite=").append(fp.getValueAsString("talkSite"));
			}
			
		}
		return sb.toString();
	}
	
	/**
	 * 
	* <p>双击后的参数添加:</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static FilterParam getDoubleClickParam(HttpServletRequest request){
		FilterParam fp = new FilterParam();
		fp.registerKey("clickA");
		fp.registerKey("type");
		fp.bindRequest(request);
		String clickA = fp.getValueAsString("clickA");
		String[] c = clickA.split("_");
		if(!c[0].equals("a")){
			fp.registerKey("talkType");
			fp.setValueAsString("talkType", c[0]);
		}
		if(!c[1].equals("a")){
			fp.registerKey("targetUnitCode");
			fp.setValueAsString("targetUnitCode", c[1]);
		}
        if(!c[2].equals("a")){
        	fp.registerKey("excuteUnitCode");
        	fp.setValueAsString("excuteUnitCode", c[2]);
		}
		if (!c[3].equals("a")) {
			fp.registerKey("year");
			fp.setValueAsString("year", c[3]);
		}
		if (!c[4].equals("a")) {
			fp.registerKey("quarter");
			fp.setValueAsString("quarter", c[4]);
		}
		if (!c[5].equals("a")) {
			fp.registerKey("month");
			fp.setValueAsString("month", c[5]);
		}
		return fp;
	}
	

	public static FilterParam getDetailParam(HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("talkTarget");
		fp.registerKey("talkPerson");
		fp.registerKey("talkType");
		fp.registerKey("talkLevel");
		fp.registerKey("talkStartTime");
		fp.registerKey("talkEndTime");
		fp.registerKey("talkSite");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	 * 
	* <p>详细信息查询参数:</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static String getDoubleClickParamAttach(FilterParam fp){
		
		StringBuilder sb = new StringBuilder();
		if(fp!=null){
			if(Utils.notEmpty(fp.getValueAsString("talkType"))){
				sb.append("&talkType=").append(fp.getValueAsString("talkType"));
			}
			if(Utils.notEmpty(fp.getValueAsString("targetUnitCode"))){
				sb.append("&targetUnitCode=").append(fp.getValueAsString("targetUnitCode"));
			}
			if(Utils.notEmpty(fp.getValueAsString("excuteUnitCode"))){
				sb.append("&excuteUnitCode=").append(fp.getValueAsString("excuteUnitCode"));
			}
			if(Utils.notEmpty(fp.getValueAsString("year"))){
				sb.append("&year=").append(fp.getValueAsString("year"));
			}
			if(Utils.notEmpty(fp.getValueAsString("quarter"))){
				sb.append("&quarter=").append(fp.getValueAsString("quarter"));
			}
			if(Utils.notEmpty(fp.getValueAsString("month"))){
				sb.append("&month=").append(fp.getValueAsString("month"));
			}
		}
		return sb.toString();
	}
	

	public static String getDetailParamAttach(FilterParam fp){
		StringBuilder sb = new StringBuilder();
		if(fp!=null){
			fp.registerKey("talkTargetId");
			fp.registerKey("talkPersonId");
			fp.registerKey("targetUnitCode");
			fp.registerKey("excuteUnitCode");
			fp.registerKey("talkType");
			fp.registerKey("talkLevel");
			fp.registerKey("talkStartTime");
			fp.registerKey("talkEndTime");
			fp.registerKey("talkSite");
			if(Utils.notEmpty(fp.getValueAsString("talkTargetId"))){
				sb.append("&talkTargetId=").append(fp.getValueAsString("talkTargetId"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkPersonId"))){
				sb.append("&talkPersonId=").append(fp.getValueAsString("talkPersonId"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkType"))){
				sb.append("&talkType=").append(fp.getValueAsString("talkType"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkLevel"))){
				sb.append("&talkLevel=").append(fp.getValueAsString("talkLevel"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkStartTime"))){
				sb.append("&talkStartTime=").append(fp.getValueAsString("talkStartTime"));
			}
			if(Utils.notEmpty(fp.getValueAsString("talkEndTime"))){
				sb.append("&talkEndTime=").append(fp.getValueAsString("talkEndTime"));
			}
		}
		return sb.toString();
	}
	

	/**
	* <p>描述:查询所有谈话记录</p>
	* @param page
	* @return
	* @author 米亦磊
	*/
	public List<DspBasicTalkmgr> findTalkMgrList(Page page){
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspBasicTalkmgr t WHERE talkState = 1");
		sql.append(" ORDER BY t.talkStartTime DESC");
		List<String> param = new ArrayList<String>();
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List<DspBasicTalkmgr> list = dao.getQueryList(sql.toString(), page,param.toArray());
		return list;
	}
	
	/**
	* <p>描述:</p>
	* @param page
	* @return
	* @author 米亦磊
	*/
	public List<DspBasicTalkmgr> findTalkMgrListByParam(Page page,FilterParam fp){
		List<DspBasicTalkmgr> list = null;
        if(fp!=null&&Utils.notEmpty(fp.getValueAsString("type"))&&fp.getValueAsString("type").equals("detail")){
        	list = detailSearch(fp,page);
        	return list;
		}else if(fp!=null&&Utils.notEmpty(fp.getValueAsString("type"))&&fp.getValueAsString("type").equals("stat")){
			list = findDataByClick(fp.getValueAsString("clickA"),page);
			return list;
		}else{
			StringBuilder sql = new StringBuilder();
			sql.append(" FROM DspBasicTalkmgr t WHERE talkState = 1 ");
			sql.append(" ORDER BY t.talkStartTime DESC");
			List<String> param = new ArrayList<String>();
			PubCommonDAO dao = FrameworkHelper.getDAO();
			list = dao.getQueryList(sql.toString(), page,param.toArray());
			return list;
		}
	}
	
	/**
	* <p>描述:</p>

	* @param page
	* @return
	* @author 米亦磊
	*/
	
	public List<DspBasicTalkmgr> findDataByClick(String paramS,Page page) {
		String[] params = paramS.split("_");
		String talkType = params[0].equals("a")?null:params[0];
		String target = params[1].equals("a")?null:params[1];
		String excute = params[2].equals("a")?null:params[2];
		String year = params[3].equals("a")?null:params[3];
		String quarter = params[4].equals("a")?null:params[4];
		String month = params[5].equals("a")?null:params[5];
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspBasicTalkmgr t  WHERE talkState = 1");
		
		List<String> param = new ArrayList<String>();

		sql.append(" and t.talkType = ? ");
		param.add(talkType);
		if(Utils.notEmpty(target)){
			sql.append(" and t.targetUnitCode = ? ");
			param.add(target);
		}
		if(Utils.notEmpty(excute)){
			sql.append(" and t.excuteUnitCode = ? ");
			param.add(excute);
		}
		
		if(Utils.notEmpty(year)){
			sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),1,4) = ? ");
			param.add(year);
		}
		if(Utils.notEmpty(quarter)){
			if("1".equals(quarter.trim())){
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='01' ");
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='03' ");
			}else if("2".equals(quarter.trim())){
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='04' ");
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='06' ");
			}else if("3".equals(quarter.trim())){
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='07' ");
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='09' ");
			}else if("4".equals(quarter.trim())){
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='10' ");
				sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='012' ");
			}
		}
		if(Utils.notEmpty(month)){
			sql.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) =? ");
			param.add(month);
		}
		sql.append(" ORDER BY t.talkStartTime DESC");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		List data = dao.getQueryList(sql.toString(),page,
				param.toArray());
		
		return data;
	}

	/**
	* <p>描述:根据id获取DspBasicTalkmgr </p>
	* @param talkMgrId
	* @return
	* @author 米亦磊
	*/
	
	public DspBasicTalkmgr getTalkMgr(String talkMgrId) {
		DspBasicTalkmgr talkMgr = talkMgrDao.getTalkMgr(talkMgrId);
		return talkMgr;

	}
	
	/**
	* <p>描述:获取谈话等级记录数量 </p>
	* @param talkMgrId
	* @return
	* @author 米亦磊
	*/
	
	public static List<Object[]> getTalkLevelCount(FilterParam fp) {
		List<Object[]> datas = new ArrayList<Object[]>();
		List<Object[]> talkType = Services.getService(CodeManService.class).getCodeData("020301");
		List<Object[]> talkLevel = Services.getService(CodeManService.class).getCodeData("020302");
		
		String targetUnitCode = fp.getValueAsString("targetUnitCode");
		String targetUnitName = fp.getValueAsString("targetUnitName");
		String excuteUnitCode = fp.getValueAsString("excuteUnitCode");
		String excuteUnitName = fp.getValueAsString("excuteUnitName");
		String year = fp.getValueAsString("year");
		year = "2017";
		String quarter = fp.getValueAsString("quarter");
		String month = fp.getValueAsString("month");
		StringBuilder moreA = new StringBuilder();
		moreA.append(Utils.notEmpty(targetUnitCode)?targetUnitCode:"a").append("_");
		moreA.append(Utils.notEmpty(excuteUnitCode)?excuteUnitCode:"a").append("_");
		moreA.append(Utils.notEmpty(year)?year:"a").append("_");
		moreA.append(Utils.notEmpty(quarter)?quarter:"a").append("_");
		moreA.append(Utils.notEmpty(month)?month:"a");
		
		List<Object> param = null;
		
		for(Object[] s : talkType){
			Object record[] = new Object[8];
			
			int count=0;
			record[count++]=s[0];
			for(Object[] s2 : talkLevel){
				param = new ArrayList<Object>();
				StringBuilder sb = new StringBuilder();
				sb.append(" select count(*) from DspBasicTalkmgr t WHERE t.talkState = 1");
				sb.append(" and t.talkLevel = ? ");
				param.add(s2[0]);
				sb.append(" and t.talkType = ? ");
				param.add(s[0]);
				if(Utils.notEmpty(targetUnitCode)){
					sb.append(" and t.targetUnitCode = ? ");
					param.add(targetUnitCode);
				}
				if(Utils.notEmpty(excuteUnitCode)){
					sb.append(" and t.excuteUnitCode = ? ");
					param.add(excuteUnitCode);
				}
				
				if(Utils.notEmpty(year)){
					sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),1,4) = ? ");
					param.add(year);
				}
				if(Utils.notEmpty(quarter)){
					if("1".equals(quarter.trim())){
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='01' ");
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='03' ");
					}else if("2".equals(quarter.trim())){
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='04' ");
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='06' ");
					}else if("3".equals(quarter.trim())){
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='07' ");
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='09' ");
					}else if("4".equals(quarter.trim())){
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) >='10' ");
						sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) <='012' ");
					}
				}
				if(Utils.notEmpty(month)){
					sb.append(" and substr(to_char(t.talkStartTime,'yyyy-MM'),6,2) =? ");
					param.add(month);
				}
				PubCommonDAO dao = FrameworkHelper.getDAO();
				List data = dao.getQueryList(sb.toString(),
						param.toArray());
				if(Utils.notEmpty(data)){
					Integer inte = ((Number) data.get(0)).intValue();
					record[count++]=inte;
				}else{
					record[count++]="0";
				}
				
			}
			record[6]=Integer.parseInt(String.valueOf(record[1]))+Integer.parseInt(String.valueOf(record[2]))+
					Integer.parseInt(String.valueOf(record[3]))+Integer.parseInt(String.valueOf(record[4]))+
					Integer.parseInt(String.valueOf(record[5]));
			record[7]=s[0]+"_"+moreA.toString();
			datas.add(record);
		}
		
		
		return datas;

	}

	/**
	* <p>描述:保存谈话记录</p>
	* @param talkmgr
	* @author 米亦磊
	 * @throws ParseException 
	*/
	
	public void saveTalkMgr(DspBasicTalkmgr talkMgr,String bizId,List<String> fileIDs,HttpServletRequest request) throws ParseException {
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		FilterParam fp = TalkMgrView.getFilterParam(request);
		String dstr=fp.getValueAsString("talkStartTime");
		Date date=sdf.parse(dstr);
		talkMgr.setBizId(bizId);
		for(int i=0;i<fileIDs.size();i++){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setFileId(fileIDs.get(i));
			fileManage.setBizId(bizId);
			fileManage.setOperTime(date);
			getDAO().saveObject(fileManage);
		}
		SysUser curUser = BaseUtil.getSessionUser(request);
		talkMgr.setTalkEntryPerson(curUser.getUserName());
		talkMgr.setTalkState("1");
		talkMgrDao.saveTalkMgr(talkMgr);
	}
	
	/**
	 * <p>
	 * 描述:暂存
	 * </p>
	 * 
	 * @param talkMgr
	 * @param bizId
	 * @param fileIDs
	 * @param request
	 * @throws ParseException
	 * @author 米亦磊
	 */

public void tempSaveTalkMgr(DspBasicTalkmgr talkMgr,String bizId,List<String> fileIDs,HttpServletRequest request) throws ParseException {
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		FilterParam fp = TalkMgrView.getFilterParam(request);
		String dstr=fp.getValueAsString("talkStartTime");
		Date date=sdf.parse(dstr);
		talkMgr.setBizId(bizId);
		for(int i=0;i<fileIDs.size();i++){
			DspFileManage fileManage = new DspFileManage();
			fileManage.setFileManageId(UUID.randomUUID().toString().replaceAll("-", ""));
			fileManage.setFileId(fileIDs.get(i));
			fileManage.setBizId(bizId);
			fileManage.setOperTime(date);
			getDAO().saveObject(fileManage);
		}
		SysUser curUser = BaseUtil.getSessionUser(request);
		talkMgr.setTalkEntryPerson(curUser.getUserName());
		talkMgr.setTalkState("2");
		talkMgrDao.saveTalkMgr(talkMgr);
	}
	

	/**
	* <p>描述:条件查询</p>
	* @param fp
	* @param page
	* @return
	* @author 米亦磊
	*/
	
	public List<DspBasicTalkmgr> detailSearch(FilterParam fp, Page page) {
		String talkTargetId = fp.getValueAsString("talkTargetId");
		String talkTargetName = fp.getValueAsString("talkTargetName");
		String talkPersonId = fp.getValueAsString("talkPersonId");
		String talkPersonName = fp.getValueAsString("talkPersonName");
		String talkType = fp.getValueAsString("talkType");
		String talkLevel = fp.getValueAsString("talkLevel");
		String talkStartTime = fp.getValueAsString("talkStartTime");
		String talkEndTime = fp.getValueAsString("talkEndTime");
		String talkSite = fp.getValueAsString("talkSite");
		
		List<DspBasicTalkmgr> datas = new ArrayList<DspBasicTalkmgr>();
		List<String> param = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();


		sql.append(" from DspBasicTalkmgr t ");
			boolean condition = true;
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkState = 1 ");
			condition = false;
		if (Utils.notEmpty(talkTargetId)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkTargetId = ? ");
			param.add(talkTargetId);
			condition = false;
		}
		if (Utils.notEmpty(talkPersonId)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkPersonId = ? ");
			param.add(talkPersonId);
			condition = false;
		}
		if (Utils.notEmpty(talkType)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkType = ? ");
			param.add(talkType);
			condition = false;
		}
		if (Utils.notEmpty(talkLevel)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkLevel = ? ");
			param.add(talkLevel);
			condition = false;
		}
		if (Utils.notEmpty(talkStartTime)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkStartTime > to_date(?,'yyyy-MM-dd HH24:mi:ss') ");

			param.add(talkStartTime);
			condition = false;
		}
		if (Utils.notEmpty(talkEndTime)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkStartTime < to_date(?,'yyyy-MM-dd HH24:mi:ss') ");
			param.add(talkEndTime);
			condition = false;
		}
		if (Utils.notEmpty(talkSite)) {
			sql.append(condition ? " where " : " and ");
			sql.append(" t.talkSite = ? ");
			param.add(talkSite);
			condition = false;
		}
		sql.append(" ORDER BY t.talkStartTime DESC");
	
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datas = dao.getQueryList(sql.toString(), page, param.toArray());
		return datas;
	}
	
	/**
	* <p>描述:数据字典取值</p>
	* @param datas
	* @return
	* @author 米亦磊
	*/
	
	public List<DspBasicTalkmgr> filterData(List<DspBasicTalkmgr> datas){
		List<Object[]> talkTypes = Services.getService(CodeManService.class).getCodeData("020301");
		List<Object[]> talkLevels = Services.getService(CodeManService.class).getCodeData("020302");
		for (DspBasicTalkmgr o : datas) {
			for (Object[] talkType : talkTypes) {
				if(o.getTalkType().equals(talkType[0])){
					o.setTalkType(String.valueOf(talkType[1]));
				}
			}
			for (Object[] talkLevel : talkLevels) {
				if(o.getTalkLevel().equals(talkLevel[0])){
					o.setTalkLevel(String.valueOf(talkLevel[1]));
				}
			}
		}

		return datas;
	}
	

	/**
	* <p>描述:按照ID获取附件信息</p>
	* @param talkMgrId
	* @return
	* @author 米亦磊
	*/
	
	public static List<UploadItem> getItemsByTalkMgrId(String talkMgrId){
		List<UploadItem> item = new ArrayList<UploadItem>();
		//fileId   bizId    attach_id
		List<DspBasicTalkmgr> datas = null;
		String bizId = null;
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DspBasicTalkmgr t WHERE t.talkMgrId=?   ");
		List<String> param=new ArrayList<String>();
		param.add(talkMgrId);
		//判断
		PubCommonDAO dao =FrameworkHelper.getDAO();
		datas=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(datas)){
			param=new ArrayList<String>();
			bizId = datas.get(0).getBizId();//bizId   可能对应多个fileManageId
			List<DspFileManage> dataM = null;
			List<String> paramM = new ArrayList<String>();
			StringBuilder sqlM=new StringBuilder();
			sqlM.append(" FROM DspFileManage t WHERE t.bizId=?   ");
			paramM.add(bizId);
			dataM=dao.getQueryList(sqlM.toString(), paramM.toArray());
			if(Utils.notEmpty(dataM)){
				for(DspFileManage fileM:dataM){
					String fileId = fileM.getFileId();
					List<DspFileAttach> dataA = null;
					List<String> paramA = new ArrayList<String>();
					StringBuilder sqlA=new StringBuilder();
					sqlA.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
					paramA.add(fileId);
					dataA=dao.getQueryList(sqlA.toString(), paramA.toArray());
					if(Utils.notEmpty(dataA)){
						DspFileAttach attach = dataA.get(0);
						UploadItem it = new UploadItem();
						it.setId(attach.getFileAttachId());
						it.setSuffix(attach.getFileExt());
						it.setSize(String.valueOf(attach.getFileSize()));
						it.setName(attach.getFileName());
						item.add(it);
					}
				}
			}
		}
		return item;
	}
	
	/**

	* <p>描述:类型转换</p>
	* @param string
	* @return
	* @author 米亦磊
	*/
	
	public static String type(String string) {
		String i = "4";
		if (string != null) {
			if ("诫勉谈话".equals(string)) {
				i = "1";
			} else if ("任职谈话".equals(string)) {
				i = "2";
			} else if ("廉政谈话".equals(string)) {
				i = "3";
			} else {
				i = "4";
			}
		}
		return i;
	}
	public static String type2(String string) {
		String i = "";
		if (string != null) {
			if ("1".equals(string)) {
				i = "诫勉谈话";
			} else if ("2".equals(string)) {
				i = "任职谈话";
			} else if ("3".equals(string)) {
				i = "廉政谈话";
			} else {
				i = "";
			}
		}
		return i;
	}

   public String level(String string) {
		String i = "6";
		if (string != null) {
			if ("省部级".equals(string)) {
				i = "1";
			} else if ("地厅级".equals(string)) {
				i = "2";
			} else if ("县处级".equals(string)) {
				i = "3";
			} else if ("乡科级".equals(string)) {
				i = "4";
			}else if ("其他".equals(string)) {
				i = "5";
			}else {
				i = "6";
			}
		}
		return i;
	}
   
   public static String level2(String string) {
		String i = "";
		if (string != null) {
			if ("1".equals(string)) {
				i = "省部级";
			} else if ("2".equals(string)) {
				i = "地厅级";
			} else if ("3".equals(string)) {
				i = "县处级";
			} else if ("4".equals(string)) {
				i = "乡科级";
			}else if ("5".equals(string)) {
				i = "其他";
			}else {
				i = "";
			}
		}
		return i;
	}
   
   public static Page getPage(HttpServletRequest request) {
		Page page = new Page();
		page.setPageSize(8);
		int curPage = 1;
		try {
			String cp = request.getParameter("cp");
			curPage = Integer.parseInt(cp);
		} catch (Exception ex) {
			curPage = 1;
		}
		page.setCurrentPage(curPage);
		return page;
	}
   
	/**
	* <p>描述:删除附件</p>
	* @param fp
	* @author 米亦磊
	*/
	
	public static void deleteByBizId(FilterParam fp) {
		String bizId = fp.getValueAsString("bizId");
		String items = fp.getValueAsString("items");
		String ufiles = fp.getValueAsString("ufiles");
		List<String> fileIDs = new ArrayList<String>();
		List<String> deleteIds = new ArrayList<String>();
		// 获取已经存在的文件
		UploadItem[] itemsU = UploadItem.parser2(ufiles);
		// 实际业务中，将文件的id存入业务和文件的关联表中
		for (UploadItem item : itemsU) {
			try {
				fileIDs.add(item.getId());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		String[] itemsS = items.split(",");
		for (String s : itemsS) {
			if (!fileIDs.contains(s)) {
				deleteIds.add(s);
			}
		}
		PubCommonDAO dao = FrameworkHelper.getDAO();
		for (String s : deleteIds) {
			StringBuilder sql = new StringBuilder();
			sql.append(" FROM DspFileTemplate t WHERE 1=1  and t.templateFileId=? ");
			List<String> param = new ArrayList<String>();
			param.add(s);

			dao.deleteSQL(sql.toString(), param.toArray());

			StringBuilder sqlD = new StringBuilder();
			sqlD.append(" FROM DspFileAttach t WHERE 1=1  and t.fileAttachId=? ");
			List<String> paramD = new ArrayList<String>();
			paramD.add(s);
			dao.deleteSQL(sqlD.toString(), paramD.toArray());
		}
	}
   
	/**
	 * 删除附件：获取参数
	 * 
	 * @param request
	 * @return
	 */
	public static FilterParam getDeletebizId(HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("bizId");
		fp.registerKey("items");
		fp.registerKey("ufiles");
		fp.bindRequest(request);
		return fp;
	}
	
	
	/**
	* <p>描述:模板下载功能</p>
	* @param type
	* @return
	* @author 米亦磊
	*/
	
	public static List<UploadItem> getDownloadItems(String type){
		List<DspFileAttach> datas = null;
		List<DspFileTemplate> datam = null;
		List<UploadItem> items = new ArrayList<UploadItem>();
		List<String> paramM = new ArrayList<String>();
		
		paramM.add(type);
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DspFileTemplate t WHERE t.templateType=?   ");
		PubCommonDAO dao = FrameworkHelper.getDAO();
		datam = dao.getQueryList(sql.toString(), paramM.toArray());
		for(DspFileTemplate m : datam){
			StringBuilder sqla = new StringBuilder();
			List<String> paramA = new ArrayList<String>();
			String fileId = m.getTemplateFileId();
			sqla.append(" FROM DspFileAttach t WHERE t.fileAttachId=?   ");
			paramA.add(fileId);
			datas = dao.getQueryList(sqla.toString(), paramA.toArray());
			for(DspFileAttach a : datas){
				DspFileAttach attach = datas.get(0);
				UploadItem it = new UploadItem();
				it.setId(attach.getFileAttachId());
				it.setSuffix(attach.getFileExt());
				it.setSize(String.valueOf(attach.getFileSize()));
				it.setName(attach.getFileName());
				items.add(it);
			}
		}
		return items;
	}
}

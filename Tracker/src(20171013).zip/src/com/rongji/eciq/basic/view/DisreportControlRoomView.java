package com.rongji.eciq.basic.view;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rongji.common.component.view.CommonUnitView;
import com.rongji.common.util.Constants;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.DatePicker;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.engines.xmltmpl.form.Textarea;
import com.rongji.dfish.plugins.form.BaiduEditor;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.AttachSelector;
import com.rongji.eciq.basic.persistence.DspBasicWorkReport;
import com.rongji.eciq.basic.service.DisReportService;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

public class DisreportControlRoomView {
	/**
	 * 构建监审室界面  
	* <p>描述:</p>
	* @param datas
	* @param fp
	* @param page
	* @param flag
	* @return
	* @author 张扬
	 */
	public static BaseView buildeNewIndexView1(List<DspBasicWorkReport> datas,
			Page page) {
		BaseView view = ViewTemplateControlRoom.buildIndexHasBtnView(false);

		VerticalPanel rootVP = (VerticalPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_ROOT);
		rootVP.setRows("90,40,*,40");

		ButtonBarPanel searchBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_BTN);
		searchBtn.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('search')"));
		searchBtn.addButton(new ClickButton("", "   刷新   ",
				"VM(this).reload();"));

		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_SEARCH);
		Text text1=new Text("reporterCode", "述职人编码", "", -1);
		text1.setDisabled(false);
		Text text2= new Text("reporterUnitCode", "单位编码", "", -1);
		text2.setDisabled(false);
		
		
		Onlinebox receiveUnit = CommonUnitView.getCommonBox("unitName", "",
				"单位", "pesonverCmd", Constants.COMBOX_TYPE_DEPT);
		DialogCommand deptNoDio = CommonUnitView.getDialogCommand(
				"pesonverCmd", "unitName", "选择单位", "userWindow",
				Constants.COMBOX_TYPE_DEPT, "orgCode", "f_controlRoom", "单位");
		receiveUnit.setDisabled(false);
//		publishPanel.add(receiveUnit);
		Hidden hid = new Hidden("orgCode", "");
//		publishPanel.add(hid);
		view.add(deptNoDio);
		
		Onlinebox receiveUnit1 = CommonUnitView.getCommonBox("reportName", "",
				"人员", "pesonverCmd1", Constants.COMBOX_TYPE_ORG);
		DialogCommand deptNoDio1 = CommonUnitView.getDialogCommand(
				"pesonverCmd1", "reportName", "选择单位", "userWindow1",
				Constants.COMBOX_TYPE_USER, "userid", "f_controlRoom", "单位");
		receiveUnit1.setDisabled(false);
//		publishPanel.add(receiveUnit);
		Hidden hid1 = new Hidden("userid", "");
//		publishPanel.add(hid);
		view.add(deptNoDio1);
		
		
		
		Horizontalgroup hg = new Horizontalgroup("hg", "时间：");
		DatePicker fromtime = new DatePicker("fromtime", "", "",
				DatePicker.DATE);
		fromtime.setDisabled(false);

		DatePicker totime = new DatePicker("totime", "", "",
				DatePicker.DATE);
		totime.setDisabled(false);

		hg.add(fromtime);
		hg.add(new Label("", "Lable", " --到-- "));
		hg.add(totime);
		hg.isFullLine();
		
	
		
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020201");
		status.remove(status.size()-1);
		status.add(0, new Object[]{"","--全部--"});
		
		Select reportStatus = new Select("reporterStatus", "状态",status.get(0), status);
		reportStatus.setWidth("200");
		
		searchForm.add(0, 0, receiveUnit);
		searchForm.add(hid);
		searchForm.add(0, 1, receiveUnit1);
		searchForm.add(hid1);
		searchForm.add(1, 0, hg);
		searchForm.add(1, 1, reportStatus);
	
		
		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_GRID);
//		grid.addSelectitem("reporterId", "40");
		grid.addColumn(GridColumn.hidden( "reporterId", "reporterId"));	
		grid.addColumn(GridColumn.text("reportTitle", "reportTitle", "报告名称", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterName", "reporterName", "报告人姓名", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterUnit", "reporterUnit", "单位名称", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterYear", "reporterYear", "所属年份",
				"*").setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterDateString", "reporterDateString", "报告上传时间", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterStatus", "reporterStatus", "报告状态",
				"*").setAlign(Align.center));
//		grid.addColumn(GridColumn.text("reportBrief", "reportBrief", "简要描述", "*")
//				.setAlign(Align.center));
	/*	grid.addColumn(GridColumn.text("id", "id", "操作", "160")
				.setParser("operPs").setAlign(Align.center));*/

		grid.setData(datas);

		/*view.addParser(new XMLParser(
				"operPs",
				"<a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('check','"
						+ "','$reporterId')  \"  >查看</a> |"
						+ " <a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('deleteConfirm','"
						+ "','$reporterId')\"  >删除</a> |"
						+ "<a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('reportReturn','"
						+ "','$reporterId')\"  >退回</a> |"
						+ "<a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('download','"
						+ "','$reporterId')\"  >下载</a>"));
*/
		grid.addDoubleClickAttach("VM(this).cmd('doubleClick', '$reporterId')");
		view.add(new DialogCommand("doubleClick", ViewFactory.ID_DIALOG_STANDARD,
				"报告信息", "f_doubleClick", DialogCommand.WIDTH_LARGE,
				DialogCommand.HEIGHT_LARGE+100, DialogCommand.POSITION_MIDDLE,
				"vm:|controlRoom/doubleClick?reporterId=$0"));
			
		ButtonBarPanel centerBbp = (ButtonBarPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_CENTER_BTN);
		centerBbp.setFace(ButtonFace.group);
		centerBbp.addButton(new ClickButton("", "发布",
				"VM(this).cmd('publish')"));
		centerBbp.addSplit();
//		centerBbp.addButton(new ClickButton("", "新建报告",
//				"VM(this).cmd('showEdit')"));
//		centerBbp.addButton(new ClickButton("", "删除报告",
//				"VM(this).cmd('delete')"));
       
		view.add(new DialogCommand("reportReturn", ViewFactory.ID_DIALOG_STANDARD,
				"请填写退回原因", "f_reportReturn", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_MEDIUM, DialogCommand.POSITION_MIDDLE,
				"vm:|controlRoom/reportReturn"));
		
		
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		ViewTemplateControlRoom.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('turnPage','$0')");
		view.add(new SubmitCommand("turnPage", "controlRoom/turnPage?cp=$0", null, false));
		view.add(new SubmitCommand("search", "controlRoom/search?cp=$0", null, false));
		
//		JSCommand delete = new JSCommand(
//				"delete",
//				"var sels=VM(this).fv('selectItem');if(sels){VM(this).cmd('deleteConfirm1');}else{DFish.alert('请至少选择一项')}");
//		view.add(delete);
//		ConfirmCommand deleteConfirm1 = new ConfirmCommand("deleteConfirm1",
//				"确认要删除选中报告吗？");
//		view.add(deleteConfirm1);
//		deleteConfirm1.add(new SubmitCommand("doDelete",
//				"controlRoomreportDelete", "p_m_grid", true));
//		view.add(deleteConfirm1);
		
		view.add(new DialogCommand("check", ViewFactory.ID_DIALOG_STANDARD,
				"报告详细信息", "f_check", DialogCommand.WIDTH_MAX,
				DialogCommand.HEIGHT_MAX, DialogCommand.POSITION_MIDDLE,
				"vm:|controlRoom/check?reporterId=$1"));
		
//		view.add(new DialogCommand("showEdit", ViewFactory.ID_DIALOG_STANDARD,
//				"新建报告", "f_showEdit", DialogCommand.WIDTH_LARGE+140,
//				DialogCommand.HEIGHT_LARGE+140, DialogCommand.POSITION_MIDDLE,
//				"vm:|controlRoomshowEdit"));
		return view;
	}
	public static FlowPanel updatePagepanel(BaseView view,Page page,List<DspBasicWorkReport> datas ){
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		ViewTemplateControlRoom.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('turnPage','$0')");
		return buttonFP;
	}
	
	public static GridPanel buildGrid(GridPanel grid,List<DspBasicWorkReport> datas){
		
		grid.addSelectitem("reporterId", "40");
		grid.addColumn(GridColumn.hidden( "reporterId", "reporterId"));	
		grid.addColumn(GridColumn.text("reportTitle", "reportTitle", "报告名称", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterName", "reporterName", "报告人姓名", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterUnit", "reporterUnit", "单位名称", "*")
				.setAlign(Align.center));

		grid.addColumn(GridColumn.text("reporterYear", "reporterYear", "所属年份",
				"*").setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterDateString", "reporterDateString", "报告上传时间", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterStatus", "reporterStatus", "报告状态",
				"*").setAlign(Align.center));
//		grid.addColumn(GridColumn.text("reportBrief", "reportBrief", "简要描述", "*")
//				.setAlign(Align.center));
//		
	
		grid.setData(datas);

		

		grid.addDoubleClickAttach("VM(this).cmd('doubleClick', '$reporterId')");
		return grid;
	}
	/**
	 * 查看报告详情界面
	* <p>描述:</p>
	* @param dwr
	* @return
	* @author 张扬
	 */
	public static  BaseView buildCheckView(DspBasicWorkReport dwr,List<UploadItem> items,boolean isReturn){
		BaseView view = ViewTemplate.buildPopupFormViewladr();
		GridLayoutFormPanel popFormPanel = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		DisReportService drs=new DisReportService();
	
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
	    Text text1=new Text("reportTitle", "报告标题", dwr.getReportTitle(), '*')
		.setDisabled(true);
//	    Text text2=new Text("reportCode", "报告人编码", dwr.getReporterCode(), '*')
//		.setDisabled(true);
	    Text text3=new Text("reportName", "报告人姓名", dwr.getReporterName(), '*')
		.setDisabled(true);
	    Text text4=new Text("reportDateString", "上传时间", dwr.getReporterDateString(), '*')
		.setDisabled(true);
	    Text text5=new Text("reporterYear", "所属年份", dwr.getReporterYear(), '*')
		.setDisabled(true);
//	    Text text6=new Text("reportUnitCode", "单位编码", dwr.getReporterUnitCode(), '*')
//		.setDisabled(true);
	    Text text7=new Text("reportName", "单位名称", dwr.getReporterUnit(), '*')
		.setDisabled(true);
	    Text text8=new Text("reportJob", "报告人职务", drs.getGenderNameByGender(drs.getUser(dwr.getReporterCode()).getGender()), '*')
		.setDisabled(true);
//	    Textarea Textarea1=new Textarea("reportBrief", "简要说明", dwr.getReportBrief(), '*').setHeight(7)
//				.setDisabled(true);
	    BaiduEditor Textarea1 = new BaiduEditor("reporterContent","报告内容",dwr.getReporterContent());
		Textarea1.setDisabled(true);
		Textarea1.setinitialFrameHeight(10);
		
//		popFormPanel.add(new Hidden("reporterId", dwr.getReporterId()));
		popFormPanel.add(0,0,0,1,text1);
		popFormPanel.add(1,0,1,1,text3);
//		popFormPanel.add(1,0,1,1,text2);
		popFormPanel.add(1,2,1,3,text8);
		popFormPanel.add(2,0,2,1,text5);
		popFormPanel.add(2,2,2,3,text4);
//		popFormPanel.add(3,0,3,1,text6);
		popFormPanel.add(0,2,0,3,text7);
		popFormPanel.add(4,0,4,3,Textarea1);
		int i=Integer.parseInt(dwr.getReporterStatus());
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020201");
		Text text9=new Text("reportStatus", "报告的状态", status.get(i)[1], '*')
		.setDisabled(true);
		popFormPanel.add(3,0,3,3,text9);
		
		AttachSelector das = new AttachSelector("ufiles", "报告：", items);
		das.setReadonly(true);
		das.setHidDelete(true);
		das.setDisabled(false);
		popFormPanel.add(5,0,5,3,das);
	
		
		if(dwr.getReporterStatus().equals("1")){
		DisReportService disreportService=new DisReportService();
		SysUser2 su=disreportService.getUser(dwr.getReporterCode());
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Text text10=new Text("returnTime", "退回时间", sdf.format(dwr.getReturnTime()), '*')
		.setDisabled(true);
		Text text11=new Text("returnPerson", "退回人", su.getUserName(), '*')
		.setDisabled(true);
		Text text12=new Text("returnPersonTitle", "退回人职务", disreportService.getGenderNameByGender(su.getGender()), '*')
		.setDisabled(true);
		Textarea Textarea2=new Textarea("reportReturnReason", "退回原因", dwr.getReporterReturnReason(), '*')
		.setDisabled(true);
		
		popFormPanel.add(6,0,6,1,text10);
		popFormPanel.add(6,2,6,3,text11);
		popFormPanel.add(7,0,7,3,text12);
		popFormPanel.add(8,0,8,3,Textarea2);
		}
		
	
		
		
//		popOper.addButton(new ClickButton(null, "审批通过", "VM(this).cmd('marlboro');"));
		view.add(new SubmitCommand("marlboro", "controlRoom/marlboro?reporterId="+dwr.getReporterId(), null, false));
		if(isReturn){
		popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('reportReturn1');"));
		view.add(new SubmitCommand("reportReturn1", "controlRoom/reportReturn?reporterId="+dwr.getReporterId(), null, false));
		}
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		
		return view;
	}
	/**
	 * 报告退回原因编写界面
	* <p>描述:</p>
	* @param dwr
	* @return
	* @author 张扬
	 */
	public static  BaseView buildReposrtReturnView(HttpServletRequest request){
		BaseView view = ViewTemplateControlRoom.buildPopupFormView();
		String reporterId = request.getParameter("reporterId");
		DisReportService disreportService=new DisReportService();
		DspBasicWorkReport dwr=disreportService.getReportDetailById(reporterId);
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplateControlRoom.P_POP_FORM);
		popFormPanel.add(new  Hidden("reporterId", dwr.getReporterId()));
		
		popFormPanel.add(new Label("returnPerson", "退回人", curUser.getUserName()));
		popFormPanel.add(new  Hidden("returnPerson",  curUser.getUserId()));
		Date date = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString=sdf.format(date);
//		popFormPanel.add(new Label("returnTimeString", "退回时间", dateString));
		popFormPanel.add(new  Hidden("returnTimeString",  dateString));
		
		
		popFormPanel.add(new Textarea("reportReturnReason", "退回原因", dwr.getReporterReturnReason(), 500).setNotnull(true)
		.setDisabled(false));
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplateControlRoom.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('saveReportReturnReason')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("saveReportReturnReason", "controlRoom/saveReportReturnReason", null, false));
		return view;
	}
//    /**
//     * 新建上传报告界面
//    * <p>描述:</p>
//    * @param dwr
//    * @return
//    * @author 张扬
//     */
//	public static BaseView buildShowEditView(SysUser curUser) {
//
//		BaseView view = ViewTemplateControlRoom.buildPopupFormView3();
//        DisReportService drs=new DisReportService();
//		String deptName=drs.getDeptNameByDeptNo(curUser.getDeptNo());
//        
//		FormPanel popFormPanel = (FormPanel) view
//				.findPanelById(ViewTemplateControlRoom.P_POP_FORM);
//		popFormPanel.setScroll(Scroll.auto);
//		FormPanel popFormPanelL = (FormPanel) view
//				.findPanelById(ViewTemplateControlRoom.P_POP_UP_LFORM);
//		FormPanel popFormPanelR = (FormPanel) view
//				.findPanelById(ViewTemplateControlRoom.P_POP_UP_RFORM);
//		Date date=new Date();
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyy");
//		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		
//		String dateYear=sdf.format(date);
//		String title=dateYear+curUser.getUserName()+"的述职报告";
//		popFormPanelL.add(new Label("reportTitle", "标题", title));
//		popFormPanel.add(new  Hidden("reportTitleText", title));
//		popFormPanelL.add(new Label("reporterName", "姓名", curUser.getUserName()));
//	
//		popFormPanelR.add(new Label("reporterUnit", "部门",deptName ));
//		popFormPanel.add(new  Hidden("reporterUnitText", deptName));
//		popFormPanelR.add(new Label("reportJob", "职务", curUser.getUserTitle()));
//		popFormPanelL.add(new Label("reporterDate", "上报时间", sdf1.format(date)));
//		popFormPanel.add(new  Hidden("reporterDateText", sdf1.format(date)));
//		
//		popFormPanel.add(new Textarea("reportBrief", "简要说明", "", '*').setHeight(10)
//		.setDisabled(false));
//
//		BaiduEditor be = new BaiduEditor("reporterContent","报告内容","");
//		be.setNotnull(true);
//		popFormPanel.add(be);
//		
//		AttachSelector das = new AttachSelector("ufiles", "上传", null);
//		das.setFileSizeLimit("50M");
//		das.setHidDelete(false);
//		popFormPanel.add(das);
//
//		ButtonBarPanel popOper = (ButtonBarPanel) view
//				.findPanelById(ViewTemplateControlRoom.P_POP_BTN);
//		popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('saveReport')"));
//		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
//		view.add(new SubmitCommand("saveReport", "controlRoom/saveReport", "f_form", true));
//		return view;
//	}

}

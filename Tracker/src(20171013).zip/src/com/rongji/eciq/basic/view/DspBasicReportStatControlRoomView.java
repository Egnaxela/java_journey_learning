package com.rongji.eciq.basic.view;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.DatePicker;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.engines.xmltmpl.form.Textarea;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.AttachSelector;
import com.rongji.eciq.basic.persistence.DspBasicReportStat;
import com.rongji.eciq.basic.service.DspBasicReportStatControlRoomService;
import com.rongji.eciq.basic.service.DspBasicReportStatService;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

public class DspBasicReportStatControlRoomView {
	/**
	 * 构建纪检人述职界面  flag当登录人为普通领导的时候 不能根据报告人姓名其他人的述职报告，当
	 * 登录人 为授予审查权限的领导的时候，能够使用根据报告人编码和单位编码查询其他人的述职报告功能,第二个flag时候具有监审室功能
	* <p>描述:</p>
	* @param datas
	* @param fp
	* @param page
	* @param flag
	* @return
	* @author 张扬
	 */
	public static BaseView buildeNewIndexView(List<DspBasicReportStat> datas,Page page){
		 List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020501");
		 List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
		 
		 Iterator<DspBasicReportStat> it=datas.iterator();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM");
			while(it.hasNext()){
				DspBasicReportStat dbrs1=it.next();
				dbrs1.setReportDateString(sdf.format(dbrs1.getReportDate()));
				int i=Integer.parseInt(dbrs1.getReportStatus().trim());
				dbrs1.setReportStatus((String)status.get(i)[1]);
				String reportOfDateString=sdf1.format(dbrs1.getReportOfDate());
				String [] rods=reportOfDateString.split("-");
				if("2".equals(dbrs1.getReportType())||"3".equals(dbrs1.getReportType())){
					int month=Integer.parseInt(rods[1]);
					String quarter=String.valueOf(month/4+1);
					dbrs1.setReportOfDateString(rods[0]+"年-"+quarter+"季度");
				}else{
					dbrs1.setReportOfDateString(reportOfDateString);
				}
				int j=Integer.parseInt(dbrs1.getReportType().trim());
				dbrs1.setReportType((String)status1.get(j)[1]);
			}
		BaseView view = ViewTemplate.buildIndexHasBtnView(false);
		VerticalPanel rootVP = (VerticalPanel) view
				.findPanelById(ViewTemplate.P_MAIN_ROOT);
		rootVP.setRows("90,40,*,40");

		ButtonBarPanel searchBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_BTN);
		searchBtn.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('search')"));
		searchBtn.addButton(new ClickButton("", "   刷新   ",
				"VM(this).reload();"));

		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_MAIN_SEARCH);
		Text text1=new Text("reportEmpCode", "汇报人: ", "", -1);
		 status1.add(0, new Object[]{"","---全部---"});
		Select reportType=new Select("reportType","类型 : ",status1.get(0),status1);
//		text2.setDisabled(flag);
		
		
		Horizontalgroup hg = new Horizontalgroup("hg", "汇报日期：");
		DatePicker fromtime = new DatePicker("fromtime", "", "",
				DatePicker.DATE);
		fromtime.setDisabled(false);

		DatePicker totime = new DatePicker("totime", "", "",
				DatePicker.DATE);
		totime.setDisabled(false);

		hg.add(fromtime);
		hg.add(new Label("", "Lable", " --到-- "));
		hg.add(totime);
		hg.isFullLine();
		
		status.add(0, new Object[]{"","---全部---"});
		status.remove(1);
		status.remove(1);
		status.remove(status.size()-1);
		Select reportStatus = new Select("reportStatus", "状态 : ",status.get(0), status);
		reportStatus.setWidth("200");
		
		searchForm.add(0, 0, text1);
		searchForm.add(1, 1, reportType);
		searchForm.add(1, 0, hg);
		searchForm.add(0, 1, reportStatus);

		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
//		grid.addSelectitem("workReportId", "40");
		grid.addColumn(GridColumn.hidden( "workReportId", "workReportId"));	
		grid.addColumn(GridColumn.text("reportTitle", "reportTitle", "汇报标题", "240")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportEmpName", "reportEmpName", "汇报人", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportType", "reportType", "报告类型", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportStatus", "reportStatus", "状态", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportOfDateString", "reportOfDate", "所属季/月", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportDateString", "reportDate", "汇报日期", "*")
				.setAlign(Align.center));
//		grid.addColumn(GridColumn.text("reportBrief", "reportBrief", "简要描述", "*")
//				.setAlign(Align.center));
	
		grid.setData(datas);

		grid.addDoubleClickAttach("VM(this).cmd('doubleClick', '$workReportId')");
		view.add(new DialogCommand("doubleClick", ViewFactory.ID_DIALOG_STANDARD,
				"汇报信息", "f_doubleClick", DialogCommand.WIDTH_LARGE,
				DialogCommand.HEIGHT_LARGE, DialogCommand.POSITION_MIDDLE,
				"vm:|dspBasicReportStatControlRoom/doubleClick?workReportId=$0"));
			
		ButtonBarPanel centerBbp = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_CENTER_BTN);
		centerBbp.setHorizontalMinus(6);
		centerBbp.addButton(new ClickButton("", "提示",
				"VM(this).cmd('prompt')"));
		centerBbp.addButton(new ClickButton("", "发布",
				"VM(this).cmd('publish')"));
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('turnPage','$0')");
		view.add(new SubmitCommand("turnPage", "dspBasicReportStatControlRoom/turnPage?cp=$0", null, false));
		view.add(new SubmitCommand("search", "dspBasicReportStatControlRoom/search?cp=$0", null, false));
		
		return view;
	}
	
	
	
	  /**
     * 新建上传报告界面
    * <p>描述:</p>
    * @param dwr
    * @return
    * @author 张扬
     */
	public static BaseView buildShowEditView(SysUser2 curUser) {

       BaseView view = ViewTemplate.buildComplexPopFormView1();
       List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
       
        GridLayoutFormPanel popFormPanel = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_COM_FROM);
		popFormPanel.setScroll(Scroll.auto);
		
		FormPanel popForm=(FormPanel)view.findPanelById(ViewTemplate.P_POP_FORM);
		
		Date date=new Date();
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		String title=curUser.getUserName()+"的工作汇报";
		popFormPanel.add(0,0,new Label("reportTitle", "标题 : ", title));
		
		
		DatePicker time = new DatePicker("time", "选泽月份 : ", new Date(),
				DatePicker.MONTH);
		popFormPanel.add(2,0,time);
		
		Select reportType=new Select("reportType","报告类型 : ",status1.get(0),status1);
		popFormPanel.add(2, 1, reportType);
		
		DspBasicReportStatControlRoomService dbrscrs=new DspBasicReportStatControlRoomService();
		
		popFormPanel.add(new  Hidden("reportTitleText", title));
		popFormPanel.add(1,0,new Label("reportEmpName", "姓名 : ", curUser.getUserName()));
		popFormPanel.add(new  Hidden("reportEmpNameText", curUser.getUserName()));
		popFormPanel.add(1,1,new Label("higherName", "上级姓名 : ", curUser.getDeptNo()));
		popFormPanel.add(new  Hidden("higherNameText", curUser.getDeptNo()));
		popFormPanel.add(0,1,new Label("reportJob", "职务 : ", dbrscrs.getGenderNameByGender(curUser.getGender())));
		popFormPanel.add(new  Hidden("reportJobText", curUser.getMarriage()));
//		popFormPanel.add(2,0,new Label("reportDate", "上报时间", sdf1.format(date)));
		popFormPanel.add(new  Hidden("reportDateText", sdf1.format(date)));
		
		popForm.add(new Textarea("reportBrief", "简要说明", "", 250)
		.setDisabled(false));
		
		AttachSelector das = new AttachSelector("ufiles", "上传", null);
		das.setFileSizeLimit("50M");
		das.setHidDelete(false);
		das.setNotnull(true);
		popForm.add(das);

		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('saveReport')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("saveReport", "dspBasicReportStatControlRoom/saveReport", null, false));
		return view;
	}
	
	/**
	 * 查看报告详情界面
	* <p>描述:</p>
	* @param dwr
	* @return
	* @author 张扬
	 */
	public static  BaseView buildCheckView( DspBasicReportStat dwr,List<UploadItem> items){
		BaseView view = ViewTemplate.buildPopupFormViewladr();
		GridLayoutFormPanel popFormPanel = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
//		popFormPanel.add(new Hidden("reporterId", dwr.getReporterId()));
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		DspBasicReportStatService sbrss = new DspBasicReportStatService();		
		
		int i=Integer.parseInt(dwr.getReportStatus().trim());
		int j=Integer.parseInt(dwr.getReportType().trim());
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020501");
		List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
		 
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM");
		 String reportOfDateString=sdf1.format(dwr.getReportOfDate());
			String [] rods=reportOfDateString.split("-");
		 if("2".equals(dwr.getReportType())||"3".equals(dwr.getReportType())){
				int month=Integer.parseInt(rods[1]);
				String quarter=String.valueOf(month/4+1);
				dwr.setReportOfDateString(rods[0]+"年-"+quarter+"季度");
			}else{
				dwr.setReportOfDateString(reportOfDateString);
			}
		
		Text text1=new Text("reportTitle", "汇报标题", dwr.getReportTitle(), '*')
		.setDisabled(true);
		Text text2=new Text("reportEmpName", "汇报人姓名", dwr.getReportEmpName(), '*')
		.setDisabled(true);
//		Text text3=new Text("reportCode", "汇报人编码", dwr.getReportEmpCode(), '*')
//		.setDisabled(true);
//		Text text4=new Text("higherName", "汇报人人上级", dwr.getHigherName(), '*')
//		.setDisabled(true);
//		Text text5=new Text("higherCode", "上级编码", dwr.getHigherCode(), '*')
//		.setDisabled(true); 
		Text text5=new Text("deptNo", "部门", sbrss.getDeptNameByDeptNo(sbrss.getUser(dwr.getReportEmpCode()).getDeptNo()), '*')
		.setDisabled(true);
		Text text6=new Text("reportJob", "职务", sbrss.getGenderNameByGender(sbrss.getUser(dwr.getReportEmpCode()).getGender()), '*')
		.setDisabled(true); 
		
		Textarea textarea1=new Textarea("reportBrief", "简要描述", dwr.getReportBrief(), '*').setHeight(10)
				.setDisabled(true);
		Text text7=new Text("reportDate", "汇报时间", sdf.format(dwr.getReportDate()), '*')
		.setDisabled(true);
		Text text8=new Text("reportStatus", "报告的状态", status.get(i)[1], '*')
		.setDisabled(true);
		Text text9=new Text("reportType", "报告类型", status1.get(j)[1], '*')
		.setDisabled(true);
		Text text10=new Text("reportOfDateString", "所属季/月", dwr.getReportOfDateString(), '*')
		.setDisabled(true);

		popFormPanel.add(0,0,0,1,text1);
		popFormPanel.add(0,2,0,3,text8);
		popFormPanel.add(1,0,1,1,text2);
		popFormPanel.add(1,2,1,3,text6);
//		popFormPanel.add(2,0,2,1,text3);
//		popFormPanel.add(2,2,2,3,text5);
		popFormPanel.add(2,0,2,1,text5);
		popFormPanel.add(2,2,2,3,text7);
		popFormPanel.add(3,0,3,1,text9);
		popFormPanel.add(3,2,3,3,text10);
		popFormPanel.add(4,0,4,3,textarea1);
		
		AttachSelector das = new AttachSelector("ufiles", "报告", items);
		das.setReadonly(true);
		das.setHidDelete(true);
		popFormPanel.add(5,0,5,3,das);
		
		
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		
		if(dwr.getReportStatus().trim().equals("2")){
			SysUser2 su=sbrss.getUser(dwr.getReturnPerson());
			//当报告退回的时候增加显示的一些退回信息
			Text text11=new Text("returnTime", "退回时间", sdf.format(dwr.getReturnTime()), '*')
			.setDisabled(true);
			Text text12=new Text("returnPerson", "退回人", su.getUserName(), '*')
			.setDisabled(true);
			Text text13=new Text("returnPersonJob", "退回人职务", sbrss.getGenderNameByGender(su.getGender()), '*')
			.setDisabled(true);
			Textarea textarea2=new Textarea("returnReason", "退回原因", dwr.getReturnReason(), '*')
			.setDisabled(true);
		popFormPanel.add(6,0,6,1,text12);
		popFormPanel.add(6,2,6,3,text13);
		popFormPanel.add(7,0,7,3,text11);
		popFormPanel.add(8,0,8,3,textarea2);
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		}else if(dwr.getReportStatus().trim().equals("3")){
		    popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		}else{
//			popOper.addButton(new ClickButton(null, "审批通过", "VM(this).cmd('marlboro');"));
//			view.add(new SubmitCommand("marlboro", "dspBasicReportStatControlRoom/marlboro?workReportId="+dwr.getWorkReportId(), null, false));
			
			popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('reportReturn1');"));
			view.add(new SubmitCommand("reportReturn1", "dspBasicReportStatControlRoom/reportReturn?workReportId="+dwr.getWorkReportId(), null, false));
			
			popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		}

		return view;
	}
	
	/**
	 * 报告退回原因编写界面
	* <p>描述:</p>
	* @param dwr
	* @return
	* @author 张扬
	 */
	public static  BaseView buildReposrtReturnView(HttpServletRequest request){
	
	    DspBasicReportStatService dspBasicReportStatService=new DspBasicReportStatService();
		BaseView view = ViewTemplate.buildPopupFormView();
		String workReportId = request.getParameter("workReportId");
		DspBasicReportStat dwr=dspBasicReportStatService.getReportDetailById(workReportId);
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		popFormPanel.add(new  Hidden("workReportId", dwr.getWorkReportId()));
		
		popFormPanel.add(new Label("returnPerson", "退回人", curUser.getUserName()));
		popFormPanel.add(new  Hidden("returnPerson",  curUser.getUserId()));
		Date date = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String dateString=sdf.format(date);
		popFormPanel.add(new Label("returnTimeString", "退回时间", dateString));
		popFormPanel.add(new  Hidden("returnTimeString",  dateString));
		
		
		popFormPanel.add(new Textarea("returnReason", "退回原因", dwr.getReturnReason(), 250).setNotnull(true)
		.setDisabled(false));
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('saveReportReturnReason')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("saveReportReturnReason", "dspBasicReportStatControlRoom/saveReportReturnReason", null, false));
		return view;
	}
	
	public static FlowPanel updatePagepanel(BaseView view,Page page,List<DspBasicReportStat> datas ){
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('search','$0')");
		return buttonFP;
	}
	
public static GridPanel buildGrid(GridPanel grid,List<DspBasicReportStat> datas){
	 List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020501");
	 List<Object[]> status1 = Services.getService(CodeManService.class).getCodeData("020502");
	 
	 Iterator<DspBasicReportStat> it=datas.iterator();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM");
		while(it.hasNext()){
			DspBasicReportStat dbrs1=it.next();
			dbrs1.setReportDateString(sdf.format(dbrs1.getReportDate()));
			int i=Integer.parseInt(dbrs1.getReportStatus().trim());
			dbrs1.setReportStatus((String)status.get(i)[1]);
			String reportOfDateString=sdf1.format(dbrs1.getReportOfDate());
			String [] rods=reportOfDateString.split("-");
			if("2".equals(dbrs1.getReportType())||"3".equals(dbrs1.getReportType())){
				int month=Integer.parseInt(rods[1]);
				String quarter=String.valueOf(month/4+1);
				dbrs1.setReportOfDateString(rods[0]+"年-"+quarter+"季度");
			}else{
				dbrs1.setReportOfDateString(reportOfDateString);
			}
			int j=Integer.parseInt(dbrs1.getReportType().trim());
			dbrs1.setReportType((String)status1.get(j)[1]);
		}
	
		grid.addSelectitem("workReportId", "40");
		grid.addColumn(GridColumn.hidden( "workReportId", "workReportId"));	
		grid.addColumn(GridColumn.text("reportTitle", "reportTitle", "汇报标题", "240")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportEmpName", "reportEmpName", "汇报人", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportType", "reportType", "报告类型", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("higherName", "higherName", "上级姓名", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportStatus", "reportStatus", "状态", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportOfDateString", "reportOfDate", "所属季/月", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportDateString", "reportDate", "汇报日期", "*")
				.setAlign(Align.center));
//		grid.addColumn(GridColumn.text("reportBrief", "reportBrief", "简要描述", "*")
//				.setAlign(Align.center));
	
		grid.setData(datas);

		grid.addDoubleClickAttach("VM(this).cmd('doubleClick', '$workReportId')");
		return grid;
	}

/**
 * 模板下载界面
* <p>描述:</p>
* @param items
* @param title
* @return
* @author 张扬
 */
public static BaseView buildDownloadView(List<UploadItem> items,String title){
	BaseView view = ViewTemplate.buildPopupFormView();
	FormPanel popFormPanel = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
	AttachSelector das = new AttachSelector("ufiles", title, items);
	das.setWidth("200");
	das.setTitleWidth(200);
	das.setReadonly(true);
	popFormPanel.add(das);
	return view;
}
}

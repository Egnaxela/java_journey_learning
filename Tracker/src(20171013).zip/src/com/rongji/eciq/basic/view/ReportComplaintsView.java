package com.rongji.eciq.basic.view;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.rongji.common.component.view.CommonUnitView;
import com.rongji.common.util.Constants;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.XMLParser;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.button.ExpandableButton;
import com.rongji.dfish.engines.xmltmpl.command.ConfirmCommand;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.DatePicker;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Radio;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.BaiduEditor;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.dfish.util.Utils;
import com.rongji.eciq.basic.common.AttachSelector;
import com.rongji.eciq.basic.persistence.DspBasicCompReport;
import com.rongji.eciq.basic.persistence.DspBasicReportRecord;
import com.rongji.eciq.basic.service.ReportComplaintsService;
import com.rongji.eciq.basic.service.ReportRecordService;
import com.rongji.eciq.basic.service.TalkMgrService;
//import com.rongji.system.entity.SysUser;
import com.rongji.system.entity.SysUser;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;
import com.rongji.system.sys.service.UserService;

/**
 * Description: 举报投诉办理视图层
 * 
 * @author  作者 : 侯小全
 * @version 创建时间：2017-1-11 上午11:36:51
 * 
 *  * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月19日      张颜士                       1.0         将sysuser改为sysuser2  
 */
public class ReportComplaintsView {

	/**
	 * 绘制主页面
	 * @param datas
	 * @param fp
	 * @param page
	 * @return
	 */
	public static BaseView buildeIndexView(List<DspBasicCompReport> datas,
			FilterParam fp, Page page) {
		if(Utils.notEmpty(datas)&&datas.size()>0){
			for(DspBasicCompReport dspBasicCompReport:datas){
				if("1".equals(dspBasicCompReport.getHandleStatus())){
					dspBasicCompReport.setHandleStatus("待提交");
				}else if("2".equals(dspBasicCompReport.getHandleStatus())){
					dspBasicCompReport.setHandleStatus("待审批");
				}else if("3".equals(dspBasicCompReport.getHandleStatus())){
					dspBasicCompReport.setHandleStatus("办理中");
				}else if("4".equals(dspBasicCompReport.getHandleStatus())){
					dspBasicCompReport.setHandleStatus("转办中");
			    }else if("5".equals(dspBasicCompReport.getHandleStatus())){
					dspBasicCompReport.setHandleStatus("已结束");
			    }
			}
		}
		
		//页面布局
		BaseView view = ViewTemplate.buildIndexHasBtnView(false);
		VerticalPanel rootVP = (VerticalPanel) view
				.findPanelById(ViewTemplate.P_MAIN_ROOT);
		rootVP.setRows("0,50,*,40");

		//列表面板
		GridPanel grid = (GridPanel) view.findPanelById(ViewTemplate.P_MAIN_GRID);
		
		//设置列表面板
		/*grid.setNobr(true);
		grid.setStyleClass("grid-odd");
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("height:100%;text-align:center");
		grid.setRowHeight(42);*/
		grid.addSelectitem("complaintsReportId", "40");
		grid.addColumn(GridColumn.text("complaintsReportId", "complaintsReportId","登记序号","*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("complainantName", "complainantName", "投诉人姓名", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportDate", "reportDate", "登记日期", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("deptName", "deptName", "转办单位","*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("handleStatus", "handleStatus", "事件状态", "*")
				.setAlign(Align.center));
		grid.setData(datas);
		
		//给每一行的列表添加一个单击动作
		grid.addClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){" +
				"VM(this).find('"+grid.getId()+"').checkRow({complaintsReportId:'$complaintsReportId'},false);" +
				"Q(this).removeClass('high');}" +
				"else{" +
				"VM(this).find('"+grid.getId()+"').checkAll(false);" +
				"Q(this).parent().first().children().removeClass('high');" +
				"VM(this).find('"+grid.getId()+"').checkRow({complaintsReportId:'$complaintsReportId'},true);" +
				"Q(this).addClass('high');}");
		
		//添加双击动作
		grid.addDoubleClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){"
				+"VM(this).find('"+grid.getId()+"').checkRow({complaintsReportId:'$complaintsReportId'},false);Q(this).removeClass('high');}"
				+"else{VM(this).find('"+grid.getId()+"').checkAll(false);"
				+"Q(this).parent().first().children().removeClass('high');"
				+"VM(this).find('"+grid.getId()+"').checkRow({complaintsReportId:'$complaintsReportId'},true);Q(this).addClass('high');}"
				+"VM(this).cmd('check','$complaintsReportId','true')");	
		
		//双击查看详情
		DialogCommand check = new DialogCommand("check", ViewFactory.ID_DIALOG_STANDARD, "查看详情", 
				"check_dspRiskLib_dio", 830, 550, DialogPosition.middle, "vm:|reportComplaints/checkDetail?complaintsReportId=$0&flag=$1");
		check.setCover(true);
		view.add(check);
		
		//按钮面板
		ButtonBarPanel centerBbp = (ButtonBarPanel) view.findPanelById(ViewTemplate.P_MAIN_CENTER_BTN);
		centerBbp.setHorizontalMinus(6);
		
		//举报录入按钮
		centerBbp.addButton(new ClickButton("", "举报录入",
				"VM(this).cmd('showEdit','" + page.getCurrentPage() + "','','lplj')"));
		view.add(new DialogCommand("showEdit", ViewFactory.ID_DIALOG_STANDARD,
				"举报投诉信息录入", "f_showEdit", 800,520, DialogCommand.POSITION_MIDDLE,
				"vm:|reportComplaints/newReportComplaints"));
		
		//模板文件下载按钮
		centerBbp.addButton(new ClickButton("","模板文件下载","VM(this).cmd('downloadTmplplj')"));
		view.add(new DialogCommand("downloadTmplplj", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"下载举报投诉相关模板", "f_downloadTmp", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_SMALL, DialogCommand.POSITION_MIDDLE,
				"vm:|reportComplaints/downloadTmp"));

		
		//提交审核
		ExpandableButton batchBtn = new ExpandableButton("", "提交审核", null);
		batchBtn.addButton(new ClickButton("img/b/delete.gif", "删除",
				"VM(this).cmd('delete')"));
		batchBtn.addButton(new ClickButton("img/b/submit.gif", "提交审核",
				"VM(this).cmd('examine')"));
		centerBbp.addButton(batchBtn);
		centerBbp.addSplit();
		
		//删除按钮
		JSCommand delete = new JSCommand("delete",
				"var sels=VM(this).fv('selectItem');if(sels){VM(this).cmd('delConfirm');}else{DFish.alert('请选择你要删除的选项！')}");
		view.add(delete);
		ConfirmCommand delConfirm = new ConfirmCommand("delConfirm", "确定要删除吗？");
		delConfirm.add(new SubmitCommand("doDelete", "reportComplaints/deleteReport?cp="+page.getCurrentPage(), ViewTemplate.P_MAIN_GRID, true));
		view.add(delConfirm);

		//提交审核按钮
		JSCommand examine = new JSCommand("examine", "var sels = VM(this).fv('selectItem');if(sels){" +
				"VM(this).cmd('exmConfirm');}else{" +
				"DFish.alert('至少选中一项进行提交审核')}");
		view.add(examine);
		ConfirmCommand exmConfirm = new ConfirmCommand("exmConfirm", "确定要提交吗？");
		exmConfirm.add(new SubmitCommand("doSubmit", "vm:|reportComplaints/submitReport?cp="+page.getCurrentPage(), ViewTemplate.P_MAIN_GRID, true));
		view.add(exmConfirm);
		
		//审核按钮
		centerBbp.addButton(new ClickButton("img/b/submit.gif", "审核","VM(this).cmd('examines')"));
		JSCommand examines = new JSCommand("examines", "var sels = VM(this).fv('selectItem');if(sels){" +
				"VM(this).cmd('doAudit');}else{" +
				"DFish.alert('至少选中一项进行审核')}");
		view.add(examines);
		ConfirmCommand exmConfirms = new ConfirmCommand("doAudit", "确定要审核吗？");
		exmConfirms.add(new SubmitCommand("doSubmit", "vm:|reportComplaints/auditReport?cp="+page.getCurrentPage(), ViewTemplate.P_MAIN_GRID, true));
		view.add(exmConfirms);
		
		//查询按钮
		centerBbp.addButton(new ClickButton("img/b/srch.gif", "查询","VM(this).cmd('searchEdit','"+page.getCurrentPage()+"','')"));
		view.add(new DialogCommand("searchEdit", ViewFactory.ID_DIALOG_STANDARD,
				"选择相关条件查询录入信息", "f_transReport", 630,310, DialogCommand.POSITION_MIDDLE,
				"vm:|reportComplaints/searchEdit?cp=$0"));
		
		//刷新按钮
		centerBbp.addButton(new ClickButton("img/b/refresh.gif", "刷新","VM(this).reload()"));
		
		//分页面板栏
		FlowPanel buttonFP = (FlowPanel) view.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,"VM(this).cmd('search','$0')");
		view.add(new SubmitCommand("search", "reportComplaints/search?cp=$0", null, false));
				
		return view;
	}

	/**
	 * 绘制新建举报录入弹出框
	* @param record
	* @param request
	* @return
	* @author 侯小全
	 */
	public static BaseView buildShowEditView(
			DspBasicCompReport record, HttpServletRequest request) {
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel("", "*,50");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		if (record == null)
			record = new DspBasicCompReport();
		
		String complaintsReportId1 = record.getComplaintsReportId();
		
		GridLayoutFormPanel popFormPanel = new GridLayoutFormPanel("mform");
		popFormPanel.setHighlightMouseover(false);
		popFormPanel.setScroll(Scroll.auto);
		rootPanel.addSubPanel(popFormPanel);

		//获取所有登记表号
		List<String> complaintsReportIds = ReportComplaintsService.getIdList();
		
		//获取系统当前时间
		Date date=new Date();
		DateFormat format=new SimpleDateFormat("yyyyMMdd");
		String time=format.format(date);
		String timex=format.format(date);
	    
		//默认的id标号
		String t = "TSJBA";
		String stime = t += timex += "A";
		String stimes = stime += "0001";
		
		List<String> idsa = new ArrayList<String>();
		//获取含有系统当前日期的id集合
		for (String comId : complaintsReportIds) {
			if(comId.indexOf(time)!=-1){
				idsa.add(comId);
			}
		}
		
		List<String> idLastA = new ArrayList<String>();
		List<String> idLastB = new ArrayList<String>();
		List<String> idLastC = new ArrayList<String>();
		List<String> idLastD = new ArrayList<String>();
		//获取idsa列表中后四位数字的集合以及后四位数前面的字符的集合
		for (String ids : idsa) {
			String idn = ids.substring(13);
			String n = (String) idn.subSequence(0, 1);
			String nf = idn.substring(1);
			if(n.equals("A")){
				idLastA.add(nf);
			}else if(n.equals("B")){
				idLastB.add(nf);
			}else if(n.equals("C")){
				idLastC.add(nf);
			}else if(n.equals("D")){
				idLastD.add(nf);
			}
		}
		
		int idMaxA = 0;
		int idMaxB = 0;
		int idMaxC = 0;
		int idMaxD = 0;
		//获取idLastA B C D集合后4位数的集合中最大的数
		for (String idm : idLastA) {
			if(Integer.parseInt(idm) > idMaxA){
				idMaxA = Integer.parseInt(idm);
			}
		}
		for (String idm : idLastB) {
			if(Integer.parseInt(idm) > idMaxB){
				idMaxB = Integer.parseInt(idm);
			}
		}
		for (String idm : idLastC) {
			if(Integer.parseInt(idm) > idMaxC){
				idMaxC = Integer.parseInt(idm);
			}
		}
		for (String idm : idLastD) {
			if(Integer.parseInt(idm) > idMaxD){
				idMaxD = Integer.parseInt(idm);
			}
		}
		
		String timea=format.format(date);
		String ta = "TSJBA";
		String stimea = ta += timea += "A";
		
		String timeb=format.format(date);
		String tb = "TSJBA";
		String stimeb = tb += timeb += "B";
		
		String timec=format.format(date);
		String tc = "TSJBA";
		String stimec = tc += timec += "C";
		
		String timed=format.format(date);
		String td = "TSJBA";
		String stimed = td += timed += "D";
		
		//进行判断
		if(idsa.size() != 0 && Utils.notEmpty(idsa)){
			for (String ids : idsa) {
				String idn = ids.substring(13);
				String n = (String) idn.subSequence(0, 1);
				String rid = null;
				if(n.equals("A") && idMaxA != 9999){
					if(idMaxA < 9){
						rid = stimea += "000";
					}else if(idMaxA >= 9 && idMaxA < 99){
						rid = stimea += "00";
					}else if(idMaxA >= 99 && idMaxA < 999){
						rid = stimea += "0";
					}else if(idMaxA >= 999 && idMaxA < 9999){
						rid = stimea;
					}
					String Rid =  rid += idMaxA+1;
					record.setComplaintsReportId(Rid);
					break;
				}else if(idMaxA == 9999){
					if(idMaxB == 0){
						rid = stimeb += "000";
						idMaxB = 0;
						String Rid =  rid += idMaxB+1;
						record.setComplaintsReportId(Rid);
						break;
					}
					if(idMaxB != 9999){
						if(idMaxB < 9){
							rid = stimeb += "000";
						}else if(idMaxB >= 9 && idMaxB < 99){
							rid = stimeb += "00";
						}else if(idMaxB >= 99 && idMaxB < 999){
							rid = stimeb += "0";
						}else if(idMaxB >= 999 && idMaxB < 9999){
							rid = stimeb;
						}else if(idMaxB == 9999){
							rid = stimec += "000";
							idMaxB = 0; 
						}
						String Rid =  rid += idMaxB+1;
						record.setComplaintsReportId(Rid);
						break;
					}else if(idMaxB == 9999){
						if(idMaxC == 0){
							rid = stimec += "000";
							idMaxC = 0;
							String Rid =  rid += idMaxC+1;
							record.setComplaintsReportId(Rid);
							break;
						}
						if(idMaxC != 9999){
							if(idMaxC < 9){
								rid = stimec += "000";
							}else if(idMaxC >= 9 && idMaxC < 99){
								rid = stimec += "00";
							}else if(idMaxC >= 99 && idMaxC < 999){
								rid = stimec += "0";
							}else if(idMaxC >= 999 && idMaxC < 9999){
								rid = stimec;
							}
							String Rid =  rid += idMaxC+1;
							record.setComplaintsReportId(Rid);
							break;
						}else if(idMaxC == 9999){
							if(idMaxD == 0){
								rid = stimed += "000";
								idMaxD = 0;
								String Rid =  rid += idMaxD+1;
								record.setComplaintsReportId(Rid);
								break;
							}
						}
					}
				}
			}
		}else{
			record.setComplaintsReportId(stimes);
		}
		
		//获取系统当前登录人
//		SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
		SysUser curUser = (SysUser) request.getSession().getAttribute("loginUser");
		
		//登记表序号
		Text complaintsReportId = new Text("complaintsReportId", "登记表序号",record.getComplaintsReportId(),50);
		popFormPanel.add(0, 0, complaintsReportId);
		complaintsReportId.setWidth("250");
		complaintsReportId.setReadonly(true);
		
		//录入人
		Text recordPerson = new Text("recordPerson", "录入人",curUser.getUserName(),50);
		popFormPanel.add(0, 1, recordPerson);
		recordPerson.setWidth("250");
		recordPerson.setReadonly(true);
		
		//投诉人姓名
		Text complainantName = new Text("complainantName", "投诉人姓名",record.getComplainantName(),20);
		popFormPanel.add(1, 0, complainantName);
		complainantName.setWidth("250");
		complainantName.setNotnull(true);
		
		//投诉人性别
		String [][]usableOptions ={{"男","男"},{"女","女"}};
		Radio sex = new Radio("sex", "性别",Utils.isEmpty(record.getSex())?"女":record.getSex(),Arrays.asList( usableOptions));
		popFormPanel.add(1,1,sex);
		
		//投诉人身份证号
		Text idNumber = new Text("idNumber", "身份证号",record.getIdNumber(),18);
		popFormPanel.add(2,0,idNumber);	
		idNumber.addPatternValidate("/^\\d{15}|\\d{18}$/");
		idNumber.setWidth("250");
		idNumber.setNotnull(true);

		//投诉人电话号
		Text telephone = new Text("telephone", "电话号码",record.getTelephone(),20);
		popFormPanel.add(2,1,telephone);	
		telephone.setWidth("250");

		//投诉人邮箱
		Text email = new Text("email", "电子邮箱",record.getEmail(),20);
		popFormPanel.add(3,0,email);
		email.setWidth("250");
		
		//投诉人工作单位
		Text company = new Text("company", "工作单位",record.getCompany(),200);
		popFormPanel.add(3,1,company);	
		company.setWidth("250");
		
		//投诉人职务
		Text position = new Text("position", "职务",record.getPosition(),200);
		popFormPanel.add(4,0,position);	
		position.setWidth("250");

		//投诉人联系地址
		Text contactAddress = new Text("contactAddress", "联系地址",record.getContactAddress(),200);
		popFormPanel.add(4,1,contactAddress);
		contactAddress.setWidth("250");
		
		//来源部门、方式
		Text source = new Text("source", "来源方式",record.getSource(),200);
		popFormPanel.add(5,0,source);	
		source.setWidth("250");
		
		//日期
		DatePicker dates = new DatePicker("dates", "日期", record.getDates(),DatePicker.DATE_TIME_FULL);
		popFormPanel.add(5, 1, dates);
		dates.setWidth("250");
		
		//投诉举报事由
		BaiduEditor complaintReason = new BaiduEditor("complaintReason","投诉事由",record.getComplaintReason());
		complaintReason.setNotnull(true);
		complaintReason.setAutoHeightEnabled(false);
		complaintReason.setinitialFrameHeight(110);
		popFormPanel.add(6,0,complaintReason);
		complaintReason.setWidth("700");
		
		//处理意见
		Text disposalIdea = new Text("disposalIdea", "处理意见",record.getDisposalIdea(),50);
		popFormPanel.add(7,0,disposalIdea);	
		disposalIdea.setWidth("700");
		
		//上传附件
		if (Utils.isEmpty(complaintsReportId1)) {
			AttachSelector das = new AttachSelector("ufiles", "上传附件:", null);
			das.setTitleWidth(100);
			das.setFileSizeLimit("50M");
			popFormPanel.add(8, 0, das);
		} else {
			List<UploadItem> items = new ArrayList<UploadItem>();
			popFormPanel.add(new Hidden("items",items));
			items = ReportComplaintsService.getItemsById(complaintsReportId1);
			AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
			das.setTitleWidth(100);
			das.setFileSizeLimit("50M");
			popFormPanel.add(8, 0, das);
		}
		
		ButtonBarPanel buttonBar = new ButtonBarPanel("");
		buttonBar.setAlign(Align.right);
		buttonBar.setFace(ButtonFace.office);
		buttonBar.setStyleClass("d-foot bd-onlytop");
		buttonBar.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(buttonBar);
		
		buttonBar.addButton(new ClickButton(null, "暂存", "VM(this).cmd('tempSaveReport')"));
		buttonBar.addButton(new ClickButton(null, "提交", "VM(this).cmd('reportTReport')"));
		buttonBar.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("tempSaveReport", "reportComplaints/saveReport?temp=1", null, false));//表格暂存
		view.add(new SubmitCommand("reportTReport", "reportComplaints/saveReport?temp=2", null, false));//表格上报
		
		return view;
	}
	
	/**
	 * 绘制查询录入信息条件弹出框
	 * @param record
	 * @param request
	 * @return
	 * @author 侯小全
	 */
	public static BaseView buildShowEditViews(List<DspBasicCompReport> datas,FilterParam fp,Page page){
		
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel("","*,50");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		
		GridLayoutFormPanel popFormPanel = new GridLayoutFormPanel("mform");
		popFormPanel.setHighlightMouseover(false);
		rootPanel.addSubPanel(popFormPanel);
		
		//根据登记表序号查询
		Text complaintsReportId = new Text("complaintsReportId", "登记序号：", "", 100);
		popFormPanel.add(0, 0, complaintsReportId);
		complaintsReportId.setWidth("540");
		
		//根据投诉人姓名查询
		Text  complainantName= new Text("complainantName", "投诉人姓名：", "", 30);
		popFormPanel.add(1, 0, complainantName);
		complainantName.setWidth("200");
		
		//根据转办单位查询
//		SysUser user = new SysUser();
		SysUser user = new SysUser();
		String deptNa="";
//		if(Utils.notEmpty(user.getDeptNo())){
//			 deptNa=UserService.getDeptName(user.getDeptNo());
//		}
		if(Utils.notEmpty(user.getOrgCode())){
			deptNa=UserService.getDeptName(user.getOrgCode());
		}
		Onlinebox deptName = CommonUnitView.getCommonBox("deptName", deptNa, "转办单位", "deptCmd", Constants.COMBOX_TYPE_DEPT);
		popFormPanel.add(1, 1, deptName);
		
		DialogCommand deptNoDio =CommonUnitView.getDialogCommand("deptCmd","deptName", "选择部门",
				"deptWindow", Constants.COMBOX_TYPE_DEPT,"deptNo","f_transReport","部门");
		view.add(deptNoDio);
		
		//根据登记时间查询
		Horizontalgroup rspGensgoup = new Horizontalgroup("", "上报时间：");
		rspGensgoup.add(new DatePicker("reportStartDate", "", "",
				DatePicker.DATE).setWidth("170"));
		rspGensgoup.add(new Label("", "到", " --到-- "));
		rspGensgoup.add(new DatePicker("reportEndDate", "", "",
				DatePicker.DATE).setWidth("170"));
		popFormPanel.add(2, 0,rspGensgoup);
		
		//根据事项状态查询
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020204");
		status.add(0, new Object[]{"","--请选择--"});
		Select handleStatus = new Select("handleStatus", "上报状态：",status.get(Utils.notEmpty(fp.getValueAsString("handleStatus"))?Integer.parseInt(fp.getValueAsString("handleStatus"))+1:0), status);
		popFormPanel.add(3, 0, handleStatus);
		handleStatus.setWidth("200");
		
		ButtonBarPanel buttonBar = new ButtonBarPanel("");
		buttonBar.setAlign(Align.right);
		buttonBar.setFace(ButtonFace.office);
		buttonBar.setStyleClass("d-foot bd-onlytop");
		buttonBar.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(buttonBar);
		buttonBar.addButton(new ClickButton(null, "搜索", "VM(this).cmd('search','" + page.getCurrentPage() + "','')"));
		buttonBar.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("search", "reportComplaints/search?cp=$0", null, false));
		return view;
		
	}
	
	/**
	 * 查看详情
	 * @param dspBasicCompReport
	 * @param flag
	 * @return
	 * @throws Exception
	 */
	public static BaseView checkDetail(DspBasicCompReport dspBasicCompReport,boolean flag,HttpServletRequest request)throws Exception{

		if("1".equals(dspBasicCompReport.getHandleStatus())){
			dspBasicCompReport.setHandleStatus("待提交");
		}else if("2".equals(dspBasicCompReport.getHandleStatus())){
			dspBasicCompReport.setHandleStatus("待审批");
		}else if("3".equals(dspBasicCompReport.getHandleStatus())){
			dspBasicCompReport.setHandleStatus("办理中");
		}else if("4".equals(dspBasicCompReport.getHandleStatus())){
			dspBasicCompReport.setHandleStatus("转办中");
	    }else if("5".equals(dspBasicCompReport.getHandleStatus())){
			dspBasicCompReport.setHandleStatus("已结束");
	    }
		
		String recordId = Utils.getParameter(request, "complaintsReportId");
		if(recordId == null){
			recordId = dspBasicCompReport.getComplaintsReportId();
		}
		DspBasicCompReport record = ReportComplaintsService.getRecordById(recordId);
		
		//状态为暂存，设置为可编辑
		boolean editable = true;
		if((record.getHandleStatus().equals("1"))){
			editable = false;
		}
		
		BaseView view = ViewTemplate.buildComplexPopFormView();
		GridLayoutFormPanel popFormPanel = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_COM_FROM);
		popFormPanel.setScroll(Scroll.auto);
		VerticalPanel rootPanel = new VerticalPanel("", "*,60");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		if (dspBasicCompReport == null)
			dspBasicCompReport = new DspBasicCompReport();
		
		popFormPanel.setHighlightMouseover(false);
		rootPanel.addSubPanel(popFormPanel);
		
		Text complaintsReportId = new Text("complaintsReportId", "登记表序号", dspBasicCompReport.getComplaintsReportId(), 700);
		popFormPanel.add(0, 0, complaintsReportId);
		complaintsReportId.setWidth("300");
		complaintsReportId.setReadonly(true);
		
		Text reportDate = new Text("reportDate", "登记日期",dspBasicCompReport.getReportDate(),30);
		popFormPanel.add(0, 1, reportDate);
		reportDate.setWidth("300");
		reportDate.setReadonly(true);
		
		Text complainantName = new Text("complainantName", "投诉人姓名",dspBasicCompReport.getComplainantName(),20);
		popFormPanel.add(1, 0, complainantName);
		complainantName.setWidth("300");
		complainantName.setReadonly(editable);
		
		String [][]usableOptions ={{"男","男"},{"女","女"}};
		Radio sex = new Radio("sex", "性别",Utils.isEmpty(dspBasicCompReport.getSex())?"女":dspBasicCompReport.getSex(),Arrays.asList( usableOptions));
		popFormPanel.add(1, 1, sex);
		sex.setWidth("300");
		sex.setReadonly(editable);
		
		Text idNumber = new Text("idNumber", "身份证号",dspBasicCompReport.getIdNumber(),18);
		popFormPanel.add(2, 0, idNumber);
		idNumber.setWidth("300");
		idNumber.addPatternValidate("/^\\d{15}|\\d{18}$/");
		idNumber.setReadonly(editable);
		
		Text telephone = new Text("telephone", "电话号码",dspBasicCompReport.getTelephone(),20);
		popFormPanel.add(2, 1, telephone);
		telephone.setWidth("300");
		telephone.setReadonly(editable);
		
		Text email = new Text("email", "电子邮箱",dspBasicCompReport.getEmail(),20);
		popFormPanel.add(3, 0, email);
		email.setWidth("300");
		email.setReadonly(editable);
		
		Text company = new Text("company", "工作单位",dspBasicCompReport.getCompany(),200);
		popFormPanel.add(3, 1, company);
		company.setWidth("300");
		company.setReadonly(editable);
		
		Text position = new Text("position", "职务",dspBasicCompReport.getPosition(),200);
		popFormPanel.add(4,0,position);	
		position.setWidth("300");
		position.setReadonly(editable);
		
		Text contactAddress = new Text("contactAddress", "联系地址",dspBasicCompReport.getContactAddress(),200);
		popFormPanel.add(4, 1, contactAddress);
		contactAddress.setWidth("300");
		contactAddress.setReadonly(editable);
		
		//来源部门、方式
		Text source = new Text("source", "来源方式",record.getSource(),200);
		popFormPanel.add(5,0,source);	
		source.setWidth("300");
		source.setReadonly(editable);
		
		//日期
		DatePicker dates = new DatePicker("dates", "日期", record.getDates(),DatePicker.DATE_TIME_FULL);
		popFormPanel.add(5, 1, dates);
		dates.setWidth("300");
		dates.setReadonly(editable);

		BaiduEditor complaintReason = new BaiduEditor("complaintReason","投诉事由",dspBasicCompReport.getComplaintReason());
		popFormPanel.add(6, 0, complaintReason);
		complaintReason.setAutoHeightEnabled(false);
		complaintReason.setinitialFrameHeight(85);
		complaintReason.setWidth("715");
		complaintReason.setNotnull(true);
		complaintReason.setReadonly(editable);
		
		Text handleStatus = new Text("handleStatus", "处理状态",dspBasicCompReport.getHandleStatus(),20);
		popFormPanel.add(7, 0, handleStatus);
		handleStatus.setWidth("300");
		handleStatus.setReadonly(true);
		
		ButtonBarPanel popOper = new ButtonBarPanel("");
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(popOper);
		
		if(record!=null&&Utils.notEmpty(record.getHandleStatus())){
			if(record.getHandleStatus().trim().equals("1")){
				//暂存待提交状态
				Text disposalIdea = new Text("disposalIdea", "处理意见",dspBasicCompReport.getDisposalIdea(),20);
				popFormPanel.add(7, 1, disposalIdea);
				disposalIdea.setWidth("300");
				disposalIdea.setReadonly(editable);
				
				Text recordPerson = new Text("recordPerson", "录入人",dspBasicCompReport.getRecordPerson(),50);
				popFormPanel.add(8, 0, recordPerson);
				recordPerson.setWidth("300");
				recordPerson.setReadonly(true);
				
				List<UploadItem> items = new ArrayList<UploadItem>();
				items= ReportComplaintsService.getItemsById(recordId);
				AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
				das.setTitleWidth(10);
				das.setFileSizeLimit("50M");
				popFormPanel.add(9,0,das);
				
				popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('reportTReport')"));
				popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			}else if (record.getHandleStatus().trim().equals("2")){
				//已提交待审批状态
				Text disposalIdea = new Text("disposalIdea", "处理意见",dspBasicCompReport.getDisposalIdea(),20);
				popFormPanel.add(6, 1, disposalIdea);
				disposalIdea.setWidth("300");
				disposalIdea.setReadonly(editable);
				
				Text approvalComments = new Text("approvalComments", "审批意见",dspBasicCompReport.getApprovalComments(),200);
				popFormPanel.add(7, 1, approvalComments);
				approvalComments.setWidth("300");
				
				Text recordPerson = new Text("recordPerson", "录入人",dspBasicCompReport.getRecordPerson(),50);
				popFormPanel.add(8, 0, recordPerson);
				recordPerson.setWidth("300");
				recordPerson.setReadonly(true);
				
				List<UploadItem> items = new ArrayList<UploadItem>();
				items= ReportComplaintsService.getItemsById(recordId);
				AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
				das.setTitleWidth(10);
				das.setFileSizeLimit("50M");
				popFormPanel.add(9,0,das);
				
				popOper.addButton(new ClickButton(null, "办理", "VM(this).cmd('auditReport')"));
				popOper.addButton(new ClickButton(null, "转办", "VM(this).cmd('transReport')"));
				popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('returnReport')"));
				popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			}else if (record.getHandleStatus().trim().equals("3")){
				//已审批处理中状态
				Text approvalComments = new Text("approvalComments", "审批意见",dspBasicCompReport.getApprovalComments(),20);
				popFormPanel.add(6, 1, approvalComments);
				approvalComments.setWidth("300");
				approvalComments.setReadonly(true);
				
				Text recordPerson = new Text("recordPerson", "录入人",dspBasicCompReport.getRecordPerson(),50);
				popFormPanel.add(7, 1, recordPerson);
				recordPerson.setWidth("300");
				recordPerson.setReadonly(true);
				
				Text handleResult = new Text("handleResult", "处理结果",dspBasicCompReport.getHandleResult(),20);
				popFormPanel.add(8, 0, handleResult);
				handleResult.setWidth("300");
				
				DatePicker handleDate = new DatePicker("handleDate", "办结日期", dspBasicCompReport.getHandleDate(),DatePicker.DATE_TIME_FULL);
				popFormPanel.add(8, 1, handleDate);
				handleDate.setWidth("300");
				
				List<UploadItem> items = new ArrayList<UploadItem>();
				items= ReportComplaintsService.getItemsById(recordId);
				AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
				das.setTitleWidth(10);
				das.setFileSizeLimit("50M");
				popFormPanel.add(9,0,das);
				
				popOper.addButton(new ClickButton(null, "通过", "VM(this).cmd('passReport')"));
				popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('returnReport')"));
				popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			}else if (record.getHandleStatus().trim().equals("4")){
				//转办状态
				Text disposalIdea = new Text("disposalIdea", "处理意见",dspBasicCompReport.getDisposalIdea(),20);
				popFormPanel.add(6, 1, disposalIdea);
				disposalIdea.setWidth("300");
				disposalIdea.setReadonly(editable);
				
				Text approvalComments = new Text("approvalComments", "审批意见",dspBasicCompReport.getApprovalComments(),20);
				popFormPanel.add(7, 1, approvalComments);
				approvalComments.setWidth("300");
				approvalComments.setReadonly(editable);
				
				Text recordPerson = new Text("recordPerson", "录入人",dspBasicCompReport.getRecordPerson(),50);
				popFormPanel.add(8, 0, recordPerson);
				recordPerson.setWidth("300");
				recordPerson.setReadonly(true);
				
				List<UploadItem> items = new ArrayList<UploadItem>();
				items= ReportComplaintsService.getItemsById(recordId);
				AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
				das.setTitleWidth(10);
				das.setFileSizeLimit("50M");
				popFormPanel.add(9,0,das);
				
				popOper.addButton(new ClickButton(null, "通过", "VM(this).cmd('passReport')"));
				popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('returnReport')"));
				popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			}else if (record.getHandleStatus().trim().equals("5")){
				//已结束状态
				Text handleResult = new Text("handleResult", "处理结果",dspBasicCompReport.getHandleResult(),20);
				popFormPanel.add(7, 1, handleResult);
				handleResult.setWidth("300");
				handleResult.setReadonly(true);
				
				Text recordPerson = new Text("recordPerson", "录入人",dspBasicCompReport.getRecordPerson(),50);
				popFormPanel.add(8, 0, recordPerson);
				recordPerson.setWidth("300");
				recordPerson.setReadonly(true);
				
				DatePicker handleDate = new DatePicker("handleDate", "办结日期", dspBasicCompReport.getHandleDate(),DatePicker.DATE_TIME_FULL);
				popFormPanel.add(8, 1, handleDate);
				handleDate.setWidth("300");
				handleDate.setReadonly(true);
				
				popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			}
		}
		view.add(new SubmitCommand("reportTReport", "reportComplaints/updateReport?temp=2&cp=$0&recordId="+recordId, null, false));//表格上报
		view.add(new SubmitCommand("auditReport", "reportComplaints/updateReport?temp=3&cp=$0&recordId="+recordId, null, false));//表格审批
		view.add(new SubmitCommand("passReport", "reportComplaints/updateReport?temp=5&cp=$0&recordId="+recordId, null, false));//表格办理
		view.add(new SubmitCommand("returnReport", "reportComplaints/updateReport?temp=1&cp=$0&recordId="+recordId, null, false));//表格办理
		view.add(new SubmitCommand("transReport", "reportComplaints/transReport?recordId="+recordId, null, false));//表格 转办
		return view;
	}

	/**
	 * 绘制转办界面
	 * <p>描述:</p>
	 * @param request
	 * @return
	 * @author 侯小全
	 */
	public static BaseView showTransferView(HttpServletRequest request,String recordId){
		
//		SysUser user = new SysUser();
		SysUser user = new SysUser();
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel panel = (FormPanel)view.findPanelById(ViewTemplate.P_POP_FORM);
		
		String deptNa="";
//		if(Utils.notEmpty(user.getDeptNo())){
//			 deptNa=UserService.getDeptName(user.getDeptNo());
//		}
		if(Utils.notEmpty(user.getOrgCode())){
			deptNa=UserService.getDeptName(user.getOrgCode());
		}
		Onlinebox deptName = CommonUnitView.getCommonBox("deptName", deptNa, "转办单位", "deptCmd", Constants.COMBOX_TYPE_DEPT);
		panel.add(deptName);
		
		DialogCommand deptNoDio =CommonUnitView.getDialogCommand("deptCmd","deptName", "选择部门",
				"deptWindow", Constants.COMBOX_TYPE_DEPT,"deptNo","f_transReport","部门");
		view.add(deptNoDio);
		
//		Hidden deptNo = new Hidden("deptNo",user.getDeptNo());
		Hidden deptNo = new Hidden("deptNo",user.getOrgCode());
		panel.add(deptNo);
		
		ButtonBarPanel popOper = (ButtonBarPanel) view.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "转办", "VM(this).cmd('trans')"));
		popOper.addButton(new ClickButton(null, "取消", "VM(this).cmd('cancel')"));
		//popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("trans", "reportComplaints/trans?temp=4&cp=$0&recordId="+recordId, null, false));//表格上报
		view.add(new SubmitCommand("cancel", "reportComplaints/cancel?temp=2&cp=$0&recordId="+recordId, null, false));//表格上报
		return view;
	}
	
	/**
	 * 描述:创建模板下载界面
	 * @param items
	 * @param title
	 * @return
	 * @author 侯小全
	 */
	public static BaseView buildDownloadView(List<UploadItem> items){
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel popFormPanel = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
		AttachSelector das = new AttachSelector("ufiles", "举报投诉模板", items);
		das.setWidth("200");
		das.setTitleWidth(200);
		das.setReadonly(true);
		popFormPanel.add(das);
		return view;
	}
	
}

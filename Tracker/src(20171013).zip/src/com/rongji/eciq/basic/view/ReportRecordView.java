/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:     黄国海  
 * @version:    1.0
 * Createdate:   2017-1-3 下午12:03:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-3   黄国海      1.0         1.0 Version  
 */  


package com.rongji.eciq.basic.view;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rongji.common.component.view.CommonUnitView;
import com.rongji.common.util.Constants;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.button.ExpandableButton;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.ConfirmCommand;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.DatePicker;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.engines.xmltmpl.form.Textarea;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.BaiduEditor;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.AttachSelector;
import com.rongji.eciq.basic.persistence.DspBasicReportRecord;
import com.rongji.eciq.basic.service.ReportRecordService;
import com.rongji.system.common.util.AuthorityHelper;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;


/**
 * @author HuangGuoHai
 *
 */
public class ReportRecordView {
	
	private static final String P_POP_COM_FROM = null;

	/**
	 * 绘制主页面
	 * @param datas
	 * @param fp
	 * @param page
	 * @return
	 */
	public static BaseView buildeIndexView(List<DspBasicReportRecord> datas,
			FilterParam fp, Page page,String type,HttpServletRequest request) {
		BaseView view = ViewTemplate.buildIndexHasBtnView(false);

		VerticalPanel rootVP = (VerticalPanel) view
				.findPanelById(ViewTemplate.P_MAIN_ROOT);

		ButtonBarPanel searchBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_BTN);
		searchBtn.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('mainSearch')"));
		searchBtn.addButton(new ClickButton("", "   刷新   ",
				"VM(this).reload();"));

		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_MAIN_SEARCH);
		Hidden leader = new Hidden("reportUnitCode1", fp.getValueAsString("reportUnitCode1"));
		searchForm.add(1,1,leader);
		Onlinebox leaderName = CommonUnitView.getCommonBox("reportUnitCode", fp.getValueAsString("reportUnitCode"), "上报单位：", "userCmd", Constants.COMBOX_TYPE_DEPT);
		searchForm.add(0, 0, leaderName);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("userCmd","reportUnitCode", "选择上报单位",
				"lmOrgSelector", Constants.COMBOX_TYPE_DEPT,"reportUnitCode1","f_main","上报单位：");
		view.add(leaderDio);
		List<Object[]> status = Services.getService(CodeManService.class).getCodeData("020102");
		status.add(0, new Object[]{"","--请选择--"});
		List<Object[]> repotType = Services.getService(CodeManService.class).getCodeData("020101");
		repotType.add(0, new Object[]{"","--请选择--"});
		Select reportStatus = new Select("reportStatus", "上报状态：",status.get(Utils.notEmpty(fp.getValueAsString("reportStatus"))?Integer.parseInt(fp.getValueAsString("reportStatus"))+1:0), status);
		reportStatus.setWidth("200");
		searchForm.add(1, 0, reportStatus.setWidth("300"));
		Horizontalgroup rspGensgoup = new Horizontalgroup("", "上报时间：");
		rspGensgoup.add(new DatePicker("reportStartDate", "", "",
				DatePicker.DATE).setWidth("170").setValue(fp.getValueAsString("reportStartDate")));
		rspGensgoup.add(new Label("", "到", " --到-- "));
		rspGensgoup.add(new DatePicker("reportEndDate", "", "",
				DatePicker.DATE).setWidth("170").setValue(fp.getValueAsString("reportEndDate")));
		searchForm.add(0, 1,rspGensgoup.setWidth("400"));

		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		grid.addSelectitem("recordId", "40");
		grid.setStyle("");
		grid.addColumn(GridColumn.hidden("recordId", "recordId"));
		grid.addColumn(GridColumn.text("title", "title", "上报标题", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterName", "reporterName", "上报人", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportUnitName", "reportUnitName", "上报单位", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportPerName", "reportPerName", "备案人", "*")
				.setAlign(Align.center));
		
		grid.addColumn(GridColumn.text("reportDateString", "reportDateString", "录入时间", "160")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportStatus", "reportStatus", "状态", "160")
				.setAlign(Align.center));

		datas = ReportRecordService.filterData(datas);
		filterData(datas);
		grid.setData(datas);
		grid.addDoubleClickAttach("VM(this).cmd('auditFrame', '$recordId')");
		view.add(new DialogCommand("auditFrame", ViewFactory.ID_DIALOG_STANDARD,
				"审批备案表", "f_auditFrame", DialogCommand.WIDTH_MEDIUM+300,
				DialogCommand.HEIGHT_LARGE+100, DialogCommand.POSITION_MIDDLE,
				"vm:|reportRecord/showAuditFrame?recordId=$0&tableType="+type+"&actionType=double"));
		grid.addClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){"
				+"VM(this).find('"+grid.getId()+"').checkRow({recordId:'$recordId'},false);Q(this).removeClass('high');}"
				+"else{VM(this).find('"+grid.getId()+"').checkAll(false);" +
					"Q(this).parent().first().children().removeClass('high');" +
				"VM(this).find('"+grid.getId()+"').checkRow({recordId:'$recordId'},true);Q(this).addClass('high');}");

		ButtonBarPanel centerBbp = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_CENTER_BTN);
		centerBbp.setHorizontalMinus(6);
		String title = null;
		if(type.equals("01")){
			title="    礼品礼金备案   ";
		}else{
			title = "    婚丧喜庆备案   ";
		}
		String id = FrameworkHelper.getLoginUser(request);
        if(AuthorityHelper.searchUserBtnExist(id,"0001")){
        	centerBbp.addButton(new ClickButton("", title,
    				"VM(this).cmd('showEdit','"+page.getCurrentPage()+"','','01')"));
        }
		
		if(type.equals("01")){
			centerBbp.addButton(new ClickButton("","模板文件下载","VM(this).cmd('downloadTmplplj')"));
			view.add(new DialogCommand("downloadTmplplj", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
					"下载礼品礼金相关模板", "f_downloadTmp", DialogCommand.WIDTH_MEDIUM,
					DialogCommand.HEIGHT_SMALL, DialogCommand.POSITION_MIDDLE,
					"vm:|reportRecord/downloadTmp?tableType=0"));
		}else{
			centerBbp.addButton(new ClickButton("","模板文件下载","VM(this).cmd('downloadTmphsxq')"));
			view.add(new DialogCommand("downloadTmphsxq", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
					"下载婚丧喜庆相关模板", "f_downloadTmp", DialogCommand.WIDTH_MEDIUM,
					DialogCommand.HEIGHT_SMALL, DialogCommand.POSITION_MIDDLE,
					"vm:|reportRecord/downloadTmp?tableType=1"));
		}
		
		JSCommand delete = new JSCommand(
				"delete",
				"var sels=VM(this).fv('selectItem');if(sels){VM(this).cmd('delConfirm');}else{DFish.alert('请至少选择一项')}");
		view.add(delete);
		ConfirmCommand delConfirm = new ConfirmCommand("delConfirm", "确定要删除吗？");
		String params = ReportRecordService.appendParam(fp);
		
		delConfirm.add(new SubmitCommand("doDelete",
				"reportRecord/delete?tableType="+type+params, "p_m_grid", true));
		view.add(delConfirm);
//		centerBbp.addButton(new ClickButton("img/b/delete.gif", "删除",
//				"VM(this).cmd('delete');"));
		
		view.addCommand(new SubmitCommand("mainSearch",
				"reportRecord/mainSearch?tableType="+type, null, true));
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('search','$0')");

		view.add(new SubmitCommand("search", "reportRecord/search?cp=$0&tableType="+type, null, false));
		view.add(new DialogCommand("showEdit", ViewFactory.ID_DIALOG_STANDARD,
				"新录入"+title, "f_showEdit", DialogCommand.WIDTH_MEDIUM+90,
				DialogCommand.HEIGHT_MEDIUM+260, DialogCommand.POSITION_MIDDLE,
				"vm:|reportRecord/newReportRecord?tableType="+type));
		//审核按钮即实现
		if(AuthorityHelper.searchUserBtnExist(id,"0002")){
			centerBbp.addButton(new ClickButton("img/b/check.gif", "审核","VM(this).cmd('auditFrame1')"));
			JSCommand update = new JSCommand("auditFrame1",
					"var sels=VM(this).fv('selectItem');if(sels){" +
					"if(sels.indexOf(',')>0){DFish.alert('只能选择一项进行修改')}else{VM(this).cmd('doupdate');}}");
			view.add(update);
			SubmitCommand doupdate = new SubmitCommand("doupdate",
					"reportRecord/showAuditFrame"+"?actionType=button", "p_m_grid", false);
			view.add(doupdate);
        }
		return view;
	}
	
	public static FlowPanel updatePagepanel(BaseView view,Page page,List<DspBasicReportRecord> datas ){
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('search','$0')");
		return buttonFP;
	}
	
	/**
	 * 绘制并填充数据信息
	 * @param view
	 * @param datas
	 * @return
	 */
	public static GridPanel buildGrid(BaseView view,List<DspBasicReportRecord> datas){
		
		datas = ReportRecordService.filterData(datas);

		GridPanel grid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		grid.addSelectitem("recordId", "40");
		grid.addColumn(GridColumn.hidden("recordId", "recordId"));
//		grid.addColumn(GridColumn.text("reportType", "reportType", "上报类型", "*")
//				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("title", "title", "上报标题", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reporterName", "reporterName", "上报人", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportUnitName", "reportUnitName", "上报单位", "*")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportPerName", "reportPerName", "备案人", "*")
				.setAlign(Align.center));
		
		grid.addColumn(GridColumn.text("reportDate", "reportDate", "录入时间", "160")
				.setAlign(Align.center));
		grid.addColumn(GridColumn.text("reportStatus", "reportStatus", "状态", "160")
				.setAlign(Align.center));
		grid.setData(datas);
		
		grid.addColumn(GridColumn.text("reportStatus", "reportStatus", "状态", "160")
				.setAlign(Align.center));
		
		grid.addDoubleClickAttach("VM(this).cmd('auditFrame', '$recordId')");
		grid
		.addClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){"
				+ "VM(this).find('"
				+ grid.getId()
				+ "').checkRow({recordId:'$recordId'},false);Q(this).removeClass('high');}"
				+ "else{VM(this).find('"
				+ grid.getId()
				+ "').checkAll(false);"
				+ "Q(this).parent().first().children().removeClass('high');"
				+ "VM(this).find('"
				+ grid.getId()
				+ "').checkRow({recordId:'$recordId'},true);Q(this).addClass('high');}");
		return grid;
	}
	
	/**
	 * 
	* <p>描述:绘制审批界面</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static BaseView buildShowAuditView(HttpServletRequest request) {
		String action = request.getParameter("actionType");
		String recordId = Utils.getParameter(request, "recordId");
		if(action.equals("button")){
			String[] ids = request.getParameterValues("selectItem");
			recordId=ids[0];
		}
		
		DspBasicReportRecord record = ReportRecordService.getRecordById(recordId);
		//上报人是当前登录用户，且状态为退回，那么设置为可编辑
		boolean editable = true;
		if((record.getReportStatus().equals("2")&&record.getReportPerCode().equals(FrameworkHelper.getLoginUser(request)))||record.getReportStatus().equals("4")){
			editable = false;
		}
		BaseView view = ViewTemplate.buildComplexPopFormView();
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		popFormPanel.setScroll(Scroll.miniscroll);
		GridLayoutFormPanel popFormPanelL = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_COM_FROM);
//		FormPanel popFormPanelR = (FormPanel) view
//				.findPanelById(ViewTemplate.P_POP_UP_RFORM);
		popFormPanel.add(new Hidden("recordId", record.getRecordId()));
		popFormPanel.add(new Hidden("reportPerCode", record.getReportPerCode()));
		popFormPanelL.add(0,0,new Text("reportPerName", "备案人：", record.getReportPerName(), 100).setReadonly(true));
		popFormPanelL.add(0,1,new Text("duty", "备案人职务：", record.getDuty(), 20).setReadonly(true));
		List<Object[]> repotType = Services.getService(CodeManService.class).getCodeData("020101");
		for(Object[] o : repotType){
			if(Utils.notEmpty(record.getReportType())&&record.getReportType().trim().equals(o[0])){
				record.setReportType(String.valueOf(o[1]));
			}
		}
		Hidden h = new Hidden("reporterName", record.getReporter());
		popFormPanelL.add(h);
		Onlinebox leaderName = CommonUnitView.getCommonBox("reporterName1", record
				.getReporterName(), "上报人：", "reporterNameCmd", Constants.COMBOX_TYPE_USER);
		popFormPanelL.add(1,0,leaderName);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("reporterNameCmd","reporterName1", "选择上报人",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"reporterName","f_auditFrame","上报人");
		view.add(leaderDio);
		popFormPanelL.add(2,0,new Text("transferCode", "转办人：", record
				.getTransferCode(), 200).setReadonly(editable));
		String auditor = ReportRecordService.getDirectorExcute(record
				.getAuditor());
		popFormPanelL.add(2,1,new Text("auditor", "审批人：", auditor, 200).setReadonly(editable));
		popFormPanelL.add(1,1,new Text("title", "上报标题：", record
				.getTitle(), 100).setReadonly(editable));
		
		BaiduEditor be = new BaiduEditor("brief","简要",record.getBrief());
		be.setDisabled(true);
		be.setinitialFrameHeight(100);
		popFormPanel.add(be);
		if(record.getReportDate() == null){
			record.setReportDate(new Date());
		}
		popFormPanel.add(new Textarea("remark", "事件说明", record.getRemark(), 200).setRowHeight(5).setReadonly(editable));
		popFormPanel.add(new Textarea("auditPropose", "审批意见", record.getAuditPropose(), 2000).setRowHeight(5).setNotnull(true).setReadonly(!editable));
		popFormPanel.add(new DatePicker("reportDate", "操作时间", record.getReportDate(),
				DatePicker.DATE).setReadonly(editable));
		List<UploadItem> items = new ArrayList<UploadItem>();
		items= ReportRecordService.getItemsByRecordId(recordId);
		AttachSelector das = new AttachSelector("ufiles", "附件", items);
		das.setReadonly(editable);
		popFormPanel.add(das);
		
		
		
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		if(record!=null&&Utils.notEmpty(record.getReportStatus())){
			if(record.getReportStatus().trim().equals("0")){
				//已提交
				popOper.addButton(new ClickButton(null, "转办", "VM(this).cmd('transReport')").setStyle(""));
				popOper.addButton(new ClickButton(null, "通过", "VM(this).cmd('auditReport')"));
				popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('forceReport')"));
			}else if (record.getReportStatus().trim().equals("1")){
				//审批通过
				popOper.addButton(new ClickButton(null, "已审批通过", "VM(this).cmd('auditReport')").setDisabled(true));
			}else if (record.getReportStatus().trim().equals("2")&&editable){
				//退回  非当前登录人
				popOper.addButton(new ClickButton(null, "转办", "VM(this).cmd('transReport')"));
				popOper.addButton(new ClickButton(null, "通过", "VM(this).cmd('auditReport')"));
				popOper.addButton(new ClickButton(null, "已退回", "VM(this).cmd('forceReport')").setDisabled(true));
			}
//				else if (record.getReportStatus().trim().equals("2")&&!editable){
//				//退回  当前登录人
//				popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('reportTReport')"));
//			}
			else if (record.getReportStatus().trim().equals("3")){
				//转办
				popOper.addButton(new ClickButton(null, "通过", "VM(this).cmd('auditReport')"));
				popOper.addButton(new ClickButton(null, "退回", "VM(this).cmd('forceReport')"));
			}else{
				//暂存
				popOper.addButton(new ClickButton(null, "未提交", "VM(this).cmd('reportTReport')").setDisabled(true));
			}
		}
		String type = request.getParameter("tableType");
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("reportTReport", "reportRecord/reportTReport?temp=0&tableType="+type/*+"&operate=reup"*/, null, false));//表格上报
		view.add(new SubmitCommand("auditReport", "reportRecord/auditReport?reportStatus=1&tableType="+type, null, false));//表格审核通过
		view.add(new SubmitCommand("forceReport", "reportRecord/auditReport?reportStatus=2&tableType="+type, null, false));//表格审核退回
		view.add(new SubmitCommand("transReport", "reportRecord/transReport?recordId="+recordId+"&tableType="+type, null, false));
		return view;
	}
	
	/**
	 * 
	* <p>描述:双击提交暂存转办
	* @param request
	* @return
	* @author 黄国海
	 */
	public static BaseView buildTempSaveView(HttpServletRequest request) {
		String recordId = Utils.getParameter(request, "recordId");
		DspBasicReportRecord record = ReportRecordService
				.getRecordById(recordId);
		// 上报人是当前登录用户，且状态为退回，那么设置为可编辑
//		boolean editable = true;
//		if ((record.getReportStatus().equals("2") && record.getReportPerCode()
//				.equals(FrameworkHelper.getLoginUser(request)))
//				|| record.getReportStatus().equals("4")) {
//			editable = false;
//		}
		BaseView view = ViewTemplate.buildComplexPopFormView();
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		popFormPanel.setScroll(Scroll.miniscroll);
		GridLayoutFormPanel popFormPanelL = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_COM_FROM);
		popFormPanel.add(new Hidden("recordId", record.getRecordId()));
		popFormPanel.add(new Hidden("reportPerCode", record.getReportPerCode()));			
		popFormPanelL.add(0, 0,new Text("reportPerName", "备案人：", record.getReportPerName(),100).setReadonly(true));
		popFormPanelL.add(0, 1,new Text("duty", "备案人职务：", record.getDuty(), 20).setReadonly(true));
		List<Object[]> repotType = Services.getService(CodeManService.class).getCodeData("020101");
		for (Object[] o : repotType) {
			if (Utils.notEmpty(record.getReportType())&& record.getReportType().trim().equals(o[0])) {
				record.setReportType(String.valueOf(o[1]));
			}
		}
		Hidden h = new Hidden("reporter", record.getReporter());
		popFormPanelL.add(h);
		Onlinebox leaderName = CommonUnitView.getCommonBox("reporter1",
				record.getReporterName(), "上报人：", "reporterNameCmd",
				Constants.COMBOX_TYPE_USER);
		popFormPanelL.add(1, 0, leaderName);
		DialogCommand leaderDio = CommonUnitView.getDialogCommand(
				"reporterCmd", "reporter1", "选择上报人", "lmOrgSelector",
				Constants.COMBOX_TYPE_USER, "reporter", "f_auditFrame",
				"上报人");
		view.add(leaderDio);
//		popFormPanelL.add(2, 0,new Text("transferCode", "转办人：", ReportRecordService.getUserNameById(record.getTransferCode()), 200).setReadonly(editable));
		
		//-----------
		Hidden transferCodeh = new Hidden("transferCode", record.getTransferCode());
		popFormPanelL.add(transferCodeh);
		Onlinebox transferCode = CommonUnitView.getCommonBox("transferCode1",
				ReportRecordService.getUserNameById(record.getTransferCode()), "转办人：", "transferCodeCmd",
				Constants.COMBOX_TYPE_USER);
		popFormPanelL.add(2, 0, transferCode);
		DialogCommand transferCodeDio = CommonUnitView.getDialogCommand(
				"transferCodeCmd", "transferCode1", "选择转办人", "lmOrgSelector",
				Constants.COMBOX_TYPE_USER, "transferCode", "f_auditFrame",
				"转办人");
		view.add(transferCodeDio);
		//-----------
		
		
		String auditor = ReportRecordService.getDirectorExcute(record.getAuditor());
		//----------
		Hidden auditorCodeh = new Hidden("auditor", record.getAuditor());
		popFormPanelL.add(auditorCodeh);
		Onlinebox auditorCode = CommonUnitView.getCommonBox("auditor1",
				auditor, "审批人：", "auditorCmd",
				Constants.COMBOX_TYPE_USER);
		popFormPanelL.add(2, 1, auditorCode);
		DialogCommand directCodeDio = CommonUnitView.getDialogCommand(
				"auditorCmd", "auditor1", "选择审批人", "lmOrgSelector",
				Constants.COMBOX_TYPE_USER, "auditor", "f_auditFrame",
				"审批人");
		view.add(directCodeDio);
		//-----------
		
//		popFormPanelL.add(2, 1, new Text("directCode", "审批人：", direct, 200).setReadonly(editable));
		popFormPanelL.add(1, 1, new Text("title", "上报标题：", record.getTitle(),100));

		BaiduEditor be = new BaiduEditor("brief", "简要", record.getBrief());
//		be.setDisabled(true);
		be.setAutoHeightEnabled(false);
		be.setinitialFrameHeight(200);
		
		popFormPanel.add(be);
		if (record.getReportDate() == null) {
			record.setReportDate(new Date());
		}
		popFormPanel.add(new Textarea("remark", "事件说明", record.getRemark(), 200).setRowHeight(5));
//		popFormPanel.add(new Textarea("auditPropose", "审批意见", record.getAuditPropose(), 2000).setRowHeight(5).setNotnull(true));
		popFormPanel.add(new DatePicker("reportDate", "操作时间", record.getReportDate(), DatePicker.DATE));
		List<UploadItem> items = new ArrayList<UploadItem>();
		items = ReportRecordService.getItemsByRecordId(recordId);
		AttachSelector das = new AttachSelector("ufiles", "附件", items);
//		das.setReadonly(editable);
		popFormPanel.add(das);

		ButtonBarPanel popOper = (ButtonBarPanel) view.findPanelById(ViewTemplate.P_POP_BTN);
		if(record.getReportStatus().equals("4")){
			popOper.addButton(new ClickButton(null, "转办","VM(this).cmd('transTempReport')"));
			popOper.addButton(new ClickButton(null, "提交","VM(this).cmd('reportTReport')"));
			popOper.addButton(new ClickButton(null, "暂存","VM(this).cmd('tempSaveReport')"));
//			das.setReadonly(true);
		}
		String type = request.getParameter("tableType");
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("reportTReport","reportRecord/reportTReport?temp=0&tableType=" + type+"&operate=reup", null,false));// 表格上报
		view.add(new SubmitCommand("transTempReport","reportRecord/transTempReport?recordId=" + recordId + "&tableType="+ type, null, false));
		view.add(new SubmitCommand("tempSaveReport", "reportRecord/reportTReport?temp=4&tableType="+type, null, false));//表格暂存
		return view;
	}
	
	public static BaseView buildDownloadView(List<UploadItem> items,String title){
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel popFormPanel = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
		AttachSelector das = new AttachSelector("ufiles", title, items);
		das.setWidth("200");
		das.setTitleWidth(200);
		das.setReadonly(true);
		popFormPanel.add(das);
		return view;
	}

	/**
	 * 
	* <p>绘制新增界面</p>
	* @param record
	* @param type
	* @param request
	* @return
	* @author 黄国海
	 */
	public static BaseView buildNewShowEditView(DspBasicReportRecord record,String type,HttpServletRequest request) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		
		BaseView view = ViewTemplate.buildPopupFormView();
		
		FormPanel popFormPanel = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
		view.add(new AjaxCommand("typeChange","reportRecord/updateType?type=$0"));
		List<Object[]> tableType = Services.getService(CodeManService.class).getCodeData("020101");
		Select reportType = new Select("reportType", "上报类型",tableType.get(0), tableType);
		reportType.setNotnull(true);
		reportType.setRemark("");
		popFormPanel.add(reportType);
		reportType.setOnchange("var usertype = VM( this ).fv('reportType'); VM(this).cmd('typeChange', reportType')");
		popFormPanel.add(new Label("", "上报人：", curUser.getUserName()));
		
		popFormPanel.add(new Textarea("brief", "简要", record.getBrief(), 1000).setNotnull(true).setRowHeight(5));
		popFormPanel.add(new Textarea("remark", "备注", record.getRemark(), 200).setRowHeight(5));
		AttachSelector das = new AttachSelector("ufiles", "上传附件:", null);
		das.setTitleWidth(10);
		das.setFileSizeLimit("50M");
		popFormPanel.add(das);
		return null;
	}
	
	/**
	 * 绘制转办界面
	* <p>描述:</p>
	* @param request
	* @return
	* @author 黄国海
	 */
	public static BaseView showTransferView(HttpServletRequest request){
		
		String recordId = request.getParameter("recordId");
		String type = request.getParameter("tableType");
		String operate = request.getParameter("operate");
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel panel = (FormPanel)view.findPanelById(ViewTemplate.P_POP_FORM);
//		Text transfer = new Text("transfer", "转办人", "", 100);
//		panel.add(transfer);
		panel.add(new Hidden("transferCode", ""));
		Onlinebox leaderName = CommonUnitView.getCommonBox("transfer", "", "转办人", "transCmd", Constants.COMBOX_TYPE_USER);
		panel.add(leaderName);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("transCmd","transfer", "选择转办人",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"transferCode","f_transReport","转办人");
		view.add(leaderDio);
		ButtonBarPanel popOper = (ButtonBarPanel) view.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "转办", "VM(this).cmd('trans')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		String auditPropose = Utils.getParameter(request, "auditPropose");
		if(Utils.notEmpty(auditPropose)){	
			try {
				auditPropose = "&auditPropose="+java.net.URLEncoder.encode(auditPropose, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		if(Utils.notEmpty(operate)){	
			try {
				operate = "&operate="+java.net.URLEncoder.encode(operate, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		view.add(new SubmitCommand("trans", "reportRecord/trans?recordId="+recordId+"&tableType="+type+auditPropose+operate, null, false));//表格上报
		
		return view;
		
	}

	/**
	 * 绘制新建界面
	* <p>描述:</p>
	* @param record
	* @param request
	* @return
	* @author 黄国海
	 */
	public static BaseView buildShowEditView(DspBasicReportRecord record,HttpServletRequest request) {
		List<Object[]> tableType = Services.getService(CodeManService.class).getCodeData("020101");
		String type = request.getParameter("tableType");
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		BaseView view = ViewTemplate.buildComplexPopFormView();
		if (record == null)
			record = new DspBasicReportRecord();
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		GridLayoutFormPanel LpopFormPanel = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_POP_COM_FROM);
		LpopFormPanel.add(0,0,new Label("reportPerName", "备案人:", curUser.getUserName()));
		
		
		String title = null;
		String grapTip = null;
		if(type.equals("01")){
			title="礼品礼金表格备案";
			grapTip="年份+上报人+礼品礼金表格备案";
		}else{
			title="婚丧喜庆表格备案";
			grapTip="年份+上报人+婚丧喜庆表格备案";
		}
		LpopFormPanel.add(0,1,new Label("reportType", "上报类型:", title));
		Hidden h = new Hidden("reporter","");
		popFormPanel.add(h);
		Onlinebox reporter = CommonUnitView.getCommonBox("reporter1", "", "上报人:", "reporterCmd", Constants.COMBOX_TYPE_USER);
		LpopFormPanel.add(1,0,reporter);
		DialogCommand reporterDio =CommonUnitView.getDialogCommand("reporterCmd","reporter1", "选择上报人",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"reporter","f_showEdit","上报人:");
		view.add(reporterDio);
		LpopFormPanel.add(1,1,new Text("title", "备案标题:", "", -1).setWidth("200").setNotnull(true).setGrayTip(grapTip));
		BaiduEditor be = new BaiduEditor("brief","简要",record.getBrief());
		be.setNotnull(true);
//		be.setAutoHeightEnabled(false);
		be.setinitialFrameHeight(150);
		popFormPanel.add(be);
		if(record.getReportDate() == null){
			record.setReportDate(new Date());
		}
		Hidden leader = new Hidden("auditor", "");
		popFormPanel.add(leader);
		popFormPanel.add(new Textarea("remark", "备注", record.getRemark(), 200));
		String usLeader = curUser.getLeader();
		usLeader = ReportRecordService.getLeaderNameById(usLeader);
		Onlinebox leaderName = CommonUnitView.getCommonBox("auditor1", usLeader, "直属领导", "userCmd", Constants.COMBOX_TYPE_USER);
		popFormPanel.add(leaderName.setNotnull(true));
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("userCmd","auditor1", "选择直属领导",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"auditor","f_showEdit","直属领导");
		view.add(leaderDio);
		AttachSelector das = new AttachSelector("ufiles", "上传附件:", null);
		das.setTitleWidth(10);
		das.setNotnull(true);
		das.setFileSizeLimit("50M");
		popFormPanel.add(das);
		
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "查看填表说明", "VM(this).cmd('tableIntro')"));
		popOper.addButton(new ClickButton(null, "查看纪律规定文件", "VM(this).cmd('disFile')"));
		popOper.addButton(new ClickButton(null, "暂存", "VM(this).cmd('tempSaveReport')"));
		popOper.addButton(new ClickButton(null, "上报", "VM(this).cmd('reportTReport')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("reportTReport", "reportRecord/reportTReport?temp=0&tableType="+type, null, false));//表格上报
		view.add(new SubmitCommand("tempSaveReport", "reportRecord/reportTReport?temp=4&tableType="+type, null, false));//表格暂存
		view.add(new DialogCommand("disFile", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"纪律规定文件", "f_disFile", DialogCommand.WIDTH_MEDIUM+200,
				DialogCommand.HEIGHT_MEDIUM+240, DialogCommand.POSITION_MIDDLE,
				"dspBasicFolder/dispFile.html"));
		view.add(new DialogCommand("tableIntro", ViewFactory.ID_DIALOG_STANDARD,//查看填表说明
				"填表事项说明", "f_tableIntro", DialogCommand.WIDTH_MEDIUM+200,
				DialogCommand.HEIGHT_MEDIUM+240, DialogCommand.POSITION_MIDDLE,
				"dspBasicFolder/tableIntro.html"));
		return view;
	}
	
	public static void filterData(List<DspBasicReportRecord> datas){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		for(DspBasicReportRecord record : datas){
			record.setReportDateString(sdf.format(record.getReportDate()));
		}
	}

}

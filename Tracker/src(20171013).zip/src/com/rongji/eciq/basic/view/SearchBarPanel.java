/*
 *File:SearchBarPanel.java
 *company:ECIQ
 *@version: 1.0
 *Date:2013-8-31
 */
package com.rongji.eciq.basic.view;

import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.button.FixedClickButton;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;

/**
 * 统一搜索按钮栏
 * 
 * @author 王惠峰
 * @since 1.0
 */
public class SearchBarPanel extends ButtonBarPanel {

	public static final String SEARCH_BAR_ID = "search_bar_id";

	private String searchCmd = "search";

	private String resetCmd = "reset";

	public SearchBarPanel() {
		super("123");
		init();
	}
	
	public SearchBarPanel(String ciq){
		super(null);
		if("ciq".equals(ciq)){
			init(ciq);
		}
		if("project".equals(ciq)){
			initProject();
		}
	}
	

	public SearchBarPanel(String searchCmd, String resetCmd) {
		super(null);
		this.searchCmd = searchCmd;
		this.resetCmd = resetCmd;
		if(searchCmd.equals("sub")){
			initSub();
		}else{
			init();
		}
		
	}
	
	private void initProject(){
		this.setFace(ButtonFace.classic);
		this.setAlign(Align.right);
		this.setCellspacing(10);
		FixedClickButton openSelect = new FixedClickButton(null, "展开节点",
				"VM(this).cmd('openSelect')");
		FixedClickButton btSearch = new FixedClickButton(null, "搜索",
				"VM(this).cmd('" + searchCmd + "')");
		
		FixedClickButton btReset = new FixedClickButton(null, "重置",
				"VM(this).cmd('" + resetCmd + "')");
		this.addButton(openSelect).addButton(btSearch).addButton(btReset);
	}
	
    private void init(String ciq){
    	this.setFace(ButtonFace.classic);
		this.setAlign(Align.right);
		this.setCellspacing(10);
		FixedClickButton openSelect = new FixedClickButton(null, "展开选中节点",
				"VM(this).cmd('openSelect')");
		FixedClickButton btSearch = new FixedClickButton(null, "搜索",
				"VM(this).cmd('" + searchCmd + "')");
		
		FixedClickButton btReset = new FixedClickButton(null, "重置",
				"VM(this).cmd('" + resetCmd + "')");
		this.addButton(openSelect).addButton(btSearch).addButton(btReset);
    }
	/**
	 * 初始化
	 */
	private void init() {
		this.setAlign(Align.right);
		this.setCellspacing(10);
		ClickButton btSearch = new ClickButton(null, "搜索",
				"VM(this).cmd('" + searchCmd + "')");
		
		ClickButton btReset = new ClickButton(null, "重置",
				"VM(this).cmd('" + resetCmd + "')");
		this.addButton(btSearch).addButton(btReset);
	}
	
	public void initSub(){
		this.setFace(ButtonFace.classic);
		this.setAlign(Align.right);
		this.setCellspacing(10);
		FixedClickButton btSearch = new FixedClickButton(null, "确定",
				"VM(this).cmd('" + searchCmd + "','$0')");
		FixedClickButton btReset = new FixedClickButton(null, "取消",
				"DFish.g_dialog(this).close()");
		this.addButton(btSearch).addButton(btReset);
	}
	
}

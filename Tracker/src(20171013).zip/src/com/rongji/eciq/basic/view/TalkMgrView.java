package com.rongji.eciq.basic.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rongji.common.component.view.CommonUnitView;
import com.rongji.common.util.Constants;
import com.rongji.common.util.Utils;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.ViewFactory;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.ConfirmCommand;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.JSCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridColumn;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.Horizontalgroup;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.DatePicker;
import com.rongji.dfish.engines.xmltmpl.form.Hidden;
import com.rongji.dfish.engines.xmltmpl.form.Label;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Select;
import com.rongji.dfish.engines.xmltmpl.form.Text;
import com.rongji.dfish.engines.xmltmpl.form.Textarea;
import com.rongji.dfish.misc.FilterParam;
import com.rongji.dfish.plugins.form.UploadItem;
import com.rongji.eciq.basic.common.AttachSelector;
import com.rongji.eciq.basic.persistence.DspBasicTalkmgr;
import com.rongji.eciq.basic.service.TalkMgrService;
import com.rongji.system.entity.SysUser2;
import com.rongji.system.pub.service.Services;
import com.rongji.system.sys.service.CodeManService;

	/**
	 * Description: 谈话记录管理视图层 
	 * Copyright: Copyright (c)2016 
	 * Company: rongji
	 * 
	 * @author: 米亦磊
	 * @version: 1.0 Create at: 2017-1-3 下午2:39:06
	 * 
	 * Modification History: Date Author Version Description
	 * ------------------------------------------------------------------
	 * 2017-1-3 米亦磊 1.0 1.0 Version
	 */

@SuppressWarnings("unchecked")
public class TalkMgrView {

	public static BaseView buildeNewIndexView(List<Object[]> datas,
			FilterParam fp, Page page) {
		BaseView view = ViewTemplate.buildIndexTwoGridView(false);

		// VerticalPanel rootVP = (VerticalPanel) view
		//		.findPanelById(ViewTemplate.P_MAIN_ROOT);

		ButtonBarPanel searchBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_BTN);
		searchBtn.setAlign(Align.center);
		searchBtn.setCellspacing(10);
		searchBtn.addButton(new ClickButton("", "   查询   ",
				"VM(this).cmd('statSearch')"));
		// searchBtn.addButton(new ClickButton("", "   刷新   ",
		// "VM(this).reload();"));

		GridLayoutFormPanel searchForm = (GridLayoutFormPanel) view
				.findPanelById(ViewTemplate.P_MAIN_SEARCH);
		// searchForm.add(1, 0, new Text("talkType", "谈话类别",
		// fp == null ? null : fp.getValueAsString("talkType"), -1));
		// searchForm.add(1, 1, new Text("talkStartTime", "谈话时间",
		// fp == null ? null : fp.getValueAsString("talkStartTime"), -1));
		List<String[]> p1 = null;
		List<String> p2 = new ArrayList<String>();
		List<String> p3 = new ArrayList<String>();
		List<String[]> p4 = null;
		List<String[]> p5 = null;
		p2.add("请选择");
		p2.add("第一季度");
		p2.add("第二季度");
		p2.add("第三季度");
		p2.add("第四季度");
		p3.add("请选择");
		for (int i = 0; i < 12; i++) {
			int month = i + 1;
			p3.add("第" + month + "月份");
		}

		searchForm.add(
				0,
				0,
				new Select("talkTargetDep", "谈话对象部门",
						new String[] { fp == null ? null : fp
								.getValueAsString("talkTargetDep") }, p4)
						.setWidth("120"));
		searchForm.add(
				0,
				1,
				new Select("talkDep", "谈话实施部门",
						new String[] { fp == null ? null : fp
								.getValueAsString("talkDep") }, p5)
						.setWidth("120"));
		searchForm.add(
				0,
				2,
				new Select("year", "年", new String[] { fp == null ? null : fp
						.getValueAsString("year") }, p1));
		searchForm.add(0, 3,
				new Select("quarte", "季度", new String[] { fp == null ? null
						: fp.getValueAsString("quarte") }, p2));
		searchForm.add(
				0,
				4,
				new Select("month", "月", new String[] { fp == null ? null : fp
						.getValueAsString("month") }, p3));

		int rowIndex1 = 0;
		GridPanel upGrid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);
		upGrid.addColumn(GridColumn
				.text(rowIndex1++, "talkType", "谈话类型", "20%").setAlign(
						Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "province", "省部级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "city", "地厅级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "county", "县处级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "township", "乡科级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "other", "其他", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "total", "合计", "15%")
				.setAlign(Align.center));

		// upGrid.setData(datas);

		GridPanel downGrid = (GridPanel) view
				.findPanelById(ViewTemplate.P_SECOND_GRID);
		int rowIndex = 0;
		downGrid.addColumn(GridColumn.text(rowIndex++, "rowNum", "序号", "5%")
				.setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkType", "谈话类型",
				"20%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkTargetName",
				"谈话对象姓名", "15%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkTargetUnit",
				"谈话对象单位", "30%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkStartTime", "谈话时间",
				"25%").setAlign(Align.center));
		downGrid.setData(datas);

		// 添加双击动作
		downGrid.addDoubleClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){"
				+ "VM(this).find('"
				+ downGrid.getId()
				+ "').checkRow({talkMgrId:'$talkMgrId'},false);Q(this).removeClass('high');}"
				+ "else{VM(this).find('"
				+ downGrid.getId()
				+ "').checkAll(false);"
				+ "Q(this).parent().first().children().removeClass('high');"
				+ "VM(this).find('"
				+ downGrid.getId()
				+ "').checkRow({talkMgrId:'$talkMgrId'},true);Q(this).addClass('high');}"
				+ "VM(this).cmd('check','$talkMgrId')");
		// 双击查看详情
		DialogCommand check = new DialogCommand("check",
				ViewFactory.ID_DIALOG_STANDARD, "双击查看谈话记录详情", "",
				DialogCommand.WIDTH_MEDIUM, DialogCommand.HEIGHT_MEDIUM,
				DialogPosition.middle, "vm:|talk/doubleClick?talkMgrId=$0");
		check.setCover(true);
		view.add(check);

		// view.addParser(new XMLParser(
		// "operPs",
		// "<a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('showEntry','"
		// + page.getCurrentPage()
		// + "','$id')  \"  >编辑</a> |"
		// +
		// " <a class='a-blue' href='javascript:;;' onclick=\"VM(this).cmd('deleteConfirm','"
		// + page.getCurrentPage() + "','$talkMgrid')\"  >删除</a> "));

		ButtonBarPanel centerBbp = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_MAIN_CENTER_BTN);
		centerBbp.setFace(ButtonFace.group);
		centerBbp
				.addButton(new ClickButton("img/b/new.gif", "   录入",
						"VM(this).cmd('showEntry','" + page.getCurrentPage()
								+ "','')"));

		centerBbp.addButton(new ClickButton("img/b/refresh.gif", "  刷新   ",
				"VM(this).reload();"));

		view.add(new DialogCommand("showEntry", ViewFactory.ID_DIALOG_STANDARD,
				"谈话记录管理信息录入", "f_showEntry", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_MEDIUM, DialogCommand.POSITION_MIDDLE,
				"vm:|talk/showEntry"));

		// 根据所选页数显示页面，参数为当前所选页数
		view.addCommand(new SubmitCommand("mainSearch", "talk/mainSearch",
				null, true));
		view.addCommand(new SubmitCommand("detailSearch","talk/detailSearch", null, true));

		view.add(new DialogCommand("statSearch",
				ViewFactory.ID_DIALOG_STANDARD, "查询统计", "f_statSearch",
				DialogCommand.WIDTH_MEDIUM, DialogCommand.HEIGHT_MEDIUM,
				DialogCommand.POSITION_MIDDLE, "vm:|talk/statSearch"));
		// 分页栏面板
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('search','$0')");
		// 根据所选页数显示页面，参数为当前所选页数
		view.add(new SubmitCommand("search", "talk/search?cp=$0", null, false));

		return view;
	}


	
	/**
	* <p>描述:主界面</p>
	* @param datas
	* @param statDatas
	* @param fp
	* @param page
	* @return
	* @author 米亦磊
	*/
	
	public static BaseView buildNewIndexView2(List<DspBasicTalkmgr> datas,
			List<Object[]> statDatas, FilterParam fp, Page page) {
		BaseView view = ViewTemplate.buildIndexStatView(false);

		ButtonBarPanel statBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_STAT_BTN);
		statBtn.setAlign(Align.left);
		statBtn.setStyle("padding-left:5px;background-color:#dfe0fa");
		statBtn.setCellspacing(10);
		statBtn.addButton(new ClickButton("img/b/status.gif", "   统计",
				"VM(this).cmd('statSearch')"));
		statBtn.addButton(new ClickButton("img/b/refresh.gif", "   刷新",
				"VM(this).reload();"));

		int rowIndex1 = 0;
		GridPanel upGrid = (GridPanel) view
				.findPanelById(ViewTemplate.P_MAIN_GRID);

		//统计部分谈话类型转换
		List<Object[]> talkType = Services.getService(CodeManService.class)
				.getCodeData("020301");
		for (Object[] o : statDatas) {
			for (Object[] o1 : talkType) {
				if (o[0].equals(o1[0])) {
					o[0] = o1[1];
				}
			}
		}

		upGrid.addColumn(GridColumn
				.text(rowIndex1++, "talkType", "谈话类型", "20%").setAlign(
						Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "province", "省部级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "city", "地厅级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "county", "县处级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "township", "乡科级", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "other", "其他", "*")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.text(rowIndex1++, "total", "合计", "15%")
				.setAlign(Align.center));
		upGrid.addColumn(GridColumn.hidden(rowIndex1++, "clickA"));
		upGrid.setData(statDatas);
		
		//统计面板添加双击事件
		upGrid.addClickAttach("VM(this).cmd('selectStat', '$clickA')");
		view.add(new AjaxCommand("selectStat", "talk/selectStat?clickA=$0&type=stat"));

		ButtonBarPanel detailBtn = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_DETAIL_BTN);
		detailBtn.setAlign(Align.left);
		detailBtn.setStyle("padding-left:5px;background-color:#dfe0fa");
		detailBtn.setCellspacing(10);
		detailBtn.addButton(new ClickButton("img/b/new.gif", "   录入",
						"VM(this).cmd('showEntry','" + page.getCurrentPage()+ "','')"));

		detailBtn.addButton(new ClickButton("img/b/srch.gif", "   查询 ",
						"VM(this).cmd('showSelect')"));
		
		detailBtn.addButton(new ClickButton("img/b/submit.gif","模板文件下载","VM(this).cmd('downloadTmplplj')"));
		view.add(new DialogCommand("downloadTmplplj", ViewFactory.ID_DIALOG_STANDARD,//查看纪律文件
				"下载谈话记录相关模板", "f_downloadTmp", DialogCommand.WIDTH_MEDIUM,
				DialogCommand.HEIGHT_SMALL, DialogCommand.POSITION_MIDDLE,
				"vm:|talk/downloadTmp"));
		
		GridPanel downGrid = (GridPanel) view
				.findPanelById(ViewTemplate.P_SECOND_GRID);
		int rowIndex = 0;

		downGrid.addColumn(GridColumn.text("talkTitle", "talkTitle", "谈话标题",
				"25%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text("talkType", "talkType", "谈话类型",
				"9%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text("talkLevel", "talkLevel", "谈话级别",
				"9%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text("talkTargetName", "talkTargetName",
				"谈话对象姓名", "8%").setAlign(Align.center));	
		downGrid.addColumn(GridColumn.text("targetUnitName", "targetUnitName",
				"谈话对象单位", "*").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text("talkSite", "talkSite", "谈话地点",
				"20%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text("talkStartTime", "talkStartTime", "谈话时间",
				"13%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.hidden("talkMgrId", "talkMgrId"));
		downGrid.setData(datas);

		// 添加双击动作
		downGrid.addDoubleClickAttach("var cl = Q(this).attr('class');if(cl.indexOf('high')>0){"
				+ "VM(this).find('"
				+ downGrid.getId()
				+ "').checkRow({talkMgrId:'$talkMgrId'},false);Q(this).removeClass('high');}"
				+ "else{VM(this).find('"
				+ downGrid.getId()
				+ "').checkAll(false);"
				+ "Q(this).parent().first().children().removeClass('high');"
				+ "VM(this).find('"
				+ downGrid.getId()
				+ "').checkRow({talkMgrId:'$talkMgrId'},true);Q(this).addClass('high');}"
				+ "VM(this).cmd('check','$talkMgrId')");
		// 双击查看详情
		DialogCommand check = new DialogCommand("check",
				ViewFactory.ID_DIALOG_STANDARD, "谈话记录详情", "",
				DialogCommand.WIDTH_LARGE, DialogCommand.HEIGHT_LARGE,
				DialogPosition.middle, "vm:|talk/doubleClick?talkMgrId=$0");
		check.setCover(true);
		view.add(check);


		view.add(new DialogCommand("showEntry", ViewFactory.ID_DIALOG_STANDARD,
				"谈话记录录入", "f_showEntry", DialogCommand.WIDTH_LARGE,
				DialogCommand.HEIGHT_LARGE, DialogCommand.POSITION_MIDDLE,
				"vm:|talk/showEntry"));

		view.add(new DialogCommand("statSearch",
				ViewFactory.ID_DIALOG_STANDARD, "查询统计", "f_statSearch",
				DialogCommand.WIDTH_MEDIUM, DialogCommand.HEIGHT_MEDIUM-200,
				DialogCommand.POSITION_MIDDLE, "vm:|talk/statSearch"));
		
		view.add(new DialogCommand("showSelect",
				ViewFactory.ID_DIALOG_STANDARD, "谈话记录查询", "f_showSelect",
				DialogCommand.WIDTH_MEDIUM-50, DialogCommand.HEIGHT_MEDIUM-80,
				DialogCommand.POSITION_MIDDLE, "vm:|talk/showSelect?type=detail"));
		

//		// 根据所选页数显示页面，参数为当前所选页数
//		view.addCommand(new SubmitCommand("detailSearch",
//				"talk/detailSearch?cp=$0&type=detail", null, true));

		// 分页栏面板
		FlowPanel buttonFP = (FlowPanel) view
				.findPanelById(ViewTemplate.P_MAIN_LEFT_PAGE);
		ViewTemplate.fillPagePanel(buttonFP, page, datas,
				"VM(this).cmd('search','$0')");
		// 根据所选页数显示页面，参数为当前所选页数
		String param = TalkMgrService.fp2String(fp);
		view.add(new SubmitCommand("search", "talk/search?cp=$0"+param, null, false));
		return view;
	}

	/**
	* <p>描述:详情面板</p>
	* @param downGrid
	* @param datas
	* @author 米亦磊
	*/
	
	public static void buildGridPanel(GridPanel downGrid, List<Object[]> datas) {
		int rowIndex = 0;
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkTitle", "谈话标题",
				"25%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkType", "谈话类型",
				"9%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkLevel", "谈话级别",
				"9%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkTargetName",
				"谈话对象姓名", "8%").setAlign(Align.center));	
		downGrid.addColumn(GridColumn.text(rowIndex++, "targetUnitName",
				"谈话对象单位", "*").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkSite", "谈话地点",
				"20%").setAlign(Align.center));
		downGrid.addColumn(GridColumn.text(rowIndex++, "talkStartTime", "谈话时间",
				"13%").setAlign(Align.center));
		downGrid.setData(datas);
//		
//		// 双击查看详情
//		DialogCommand check = new DialogCommand("check",
//				ViewFactory.ID_DIALOG_STANDARD, "谈话记录详情", "",
//				DialogCommand.WIDTH_LARGE, DialogCommand.HEIGHT_LARGE,
//				DialogPosition.middle, "vm:|talk/doubleClick?talkMgrId=$0");
//		check.setCover(true);
//		view.add(check);
	}

	/**
	 * <p>
	 * 描述:录入界面
	 * </p>
	 * 
	 * @param talkMgr
	 * @return
	 * @author 米亦磊
	 */

	public static BaseView buildShowEntryView(DspBasicTalkmgr talkMgr,HttpServletRequest request) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel("", "*,40");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		
		GridLayoutFormPanel layoutFormPanel = new GridLayoutFormPanel("layoutForm");
		layoutFormPanel.setHighlightMouseover(false);
		layoutFormPanel.setRowHeight(30);
		rootPanel.addSubPanel(layoutFormPanel);
		
		// List<String[]> talkTarget = null;
		// List<String[]> talkPerson = null;
		List<String[]> talkType = new ArrayList<String[]>();
		List<String[]> talkLevel = new ArrayList<String[]>();
		Collections.addAll(talkLevel, new String[]{"省部级"},new String[]{"地厅级"},new String[]{"县处级"},new String[]{"乡科级"},new String[]{"其他"});
		Collections.addAll(talkType, new String[]{"诫勉谈话"}, new String[]{"任职谈话"}, new String[]{"廉政谈话"});

		String talkMgrId = talkMgr.getTalkMgrId();
		
		layoutFormPanel.add(new Hidden("talkState",talkMgr.getTalkState()));
		layoutFormPanel.add(new Hidden("talkMgrId",talkMgr.getTalkMgrId()));
		layoutFormPanel.add(new Hidden("talkEntryPerson",talkMgr.getTalkEntryPerson()));
		layoutFormPanel.add(new Hidden("bizId",talkMgr.getBizId()));
		
		String talkTypeH = talkMgr.getTalkType();
		for (String[] string : talkType) {
			String talkTypeH2 = TalkMgrService.type2(talkTypeH);
			if (Utils.notEmpty(talkTypeH2) && string[0].equals(talkTypeH2)) {
				layoutFormPanel.add(0,0,0,1,new Select("talkType", "谈话类型:", string,
						talkType).setWidth("400").setNotnull(true));
				break;
			}else {
				layoutFormPanel.add(0,0,0,1,new Select("talkType", "谈话类型:", new String[]{},
						talkType).setWidth("400").setNotnull(true));
			}
		}
		
		String talkLevelL = talkMgr.getTalkLevel();
		for (String[] string : talkLevel) {
			String talkLevelL2 = TalkMgrService.level2(talkLevelL);
			if (Utils.notEmpty(talkLevelL) && string[0].equals(talkLevelL2)) {
				layoutFormPanel.add(0,2,0,3,new Select("talkLevel", "谈话等级:", string,
						talkLevel).setWidth("400").setNotnull(true));
				break;
			}else {
				layoutFormPanel.add(0,2,0,3,new Select("talkLevel", "谈话等级:", new String[] {},
						talkLevel).setWidth("400").setNotnull(true));
			}
		}
		
		
//		layoutFormPanel.add(1,0,new Select("talkTarget", "谈话对象:", new String[] {},
//				talkTarget).setWidth("200").setNotnull(false));
		Onlinebox leaderName = CommonUnitView.getCommonBox("talkTargetName", talkMgr.getTalkTargetName(), "谈话对象:", "talkTargetIdCmd", Constants.COMBOX_TYPE_USER);
		layoutFormPanel.add(1,0,1,1,leaderName.setWidth("400").setNotnull(false)); 
		Hidden talkTargetId = new  Hidden("talkTargetId", talkMgr.getTalkTargetId());
		layoutFormPanel.add(talkTargetId);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("talkTargetIdCmd","talkTargetName", "选择谈话对象",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"talkTargetId","f_showEntry","直属领导");
		view.add(leaderDio);
		
//		layoutFormPanel.add(1,1,new Select("talkPerson", "谈话人:", new String[] {},
//				talkPerson).setWidth("200").setNotnull(false));
		Onlinebox leaderName2 = CommonUnitView.getCommonBox("talkPersonName", talkMgr.getTalkPersonName(), "谈话人:", "talkPersonIdCmd", Constants.COMBOX_TYPE_USER);
		layoutFormPanel.add(2,0,2,1,leaderName2.setWidth("400").setNotnull(false));
		Hidden talkPersonId = new  Hidden("talkPersonId", talkMgr.getTalkPersonId());
		layoutFormPanel.add(talkPersonId);
		DialogCommand leaderDio2 =CommonUnitView.getDialogCommand("talkPersonIdCmd","talkPersonName", "选择谈话人",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"talkPersonId","f_showEntry","直属领导");
		view.add(leaderDio2);
		
		Onlinebox leaderName3 = CommonUnitView.getCommonBox("targetUnitName", talkMgr.getTargetUnitName(), "谈话对象部门:", "targetUnitCodeCmd", Constants.COMBOX_TYPE_DEPT);
		layoutFormPanel.add(1,2,leaderName3.setNotnull(false));
		Hidden targetUnitCode = new  Hidden("targetUnitCode", talkMgr.getTargetUnitCode());
		layoutFormPanel.add(targetUnitCode);
		DialogCommand leaderDio3 =CommonUnitView.getDialogCommand("targetUnitCodeCmd","targetUnitName", "选择部门",
				"lmOrgSelector", Constants.COMBOX_TYPE_DEPT,"targetUnitCode","f_showEntry","直属领导");
		view.add(leaderDio3);

		Onlinebox leaderName4 = CommonUnitView.getCommonBox("excuteUnitName", talkMgr.getExcuteUnitName(), "谈话实施部门:", "excuteUnitCodeCmd", Constants.COMBOX_TYPE_DEPT);
		layoutFormPanel.add(2,2,leaderName4.setNotnull(false));
		Hidden excuteUnitCode = new  Hidden("excuteUnitCode", talkMgr.getExcuteUnitCode());
		layoutFormPanel.add(excuteUnitCode);
		DialogCommand leaderDio4 =CommonUnitView.getDialogCommand("excuteUnitCodeCmd","excuteUnitName", "选择部门",
				"lmOrgSelector", Constants.COMBOX_TYPE_DEPT,"excuteUnitCode","f_showEntry","直属领导");
		view.add(leaderDio4);
		
		layoutFormPanel.add(1,3,new Text("talkTargetDetailUnit", "职务:", talkMgr.getTalkTargetDetailUnit(),100)
		.setNotnull(false));
		layoutFormPanel.add(2,3,new Text("talkPersonDetailUnit", "职务:", talkMgr.getTalkPersonDetailUnit(),100)
		.setNotnull(false));
		
		layoutFormPanel.add(3,0,3,3,new Text("talkTitle", "谈话标题:", talkMgr.getTalkTitle(),100)
		.setNotnull(true));
		layoutFormPanel.add(4,0,4,3,new Text("talkSite", "谈话地点:", talkMgr.getTalkSite(), 100)
						.setNotnull(true));
		layoutFormPanel.add(5,0,5,3,new Textarea("talkContent", "谈话内容:", talkMgr.getTalkContent(), 10000).setHeight(200).setNotnull(true));
		layoutFormPanel.add(6,0,new DatePicker("talkStartTime", "谈话时间:", talkMgr.getTalkStartTime(),
				DatePicker.DATE_TIME_FULL).setNotnull(true).setDisabled(false));
		
		
		if (Utils.isEmpty(talkMgrId)) {
			AttachSelector das = new AttachSelector("ufiles", "上传附件:", null);
			das.setTitleWidth(100);
			das.setFileSizeLimit("50M");
			layoutFormPanel.add(7, 0, das);
		} else {
			List<UploadItem> items = new ArrayList<UploadItem>();
			layoutFormPanel.add(new Hidden("items",items));
			items = TalkMgrService.getItemsByTalkMgrId(talkMgrId);
			AttachSelector das = new AttachSelector("ufiles", "上传附件:", items);
			das.setTitleWidth(100);
			das.setFileSizeLimit("50M");
			layoutFormPanel.add(7, 0, das);
		}
		
		// popFormPanel.add(new
		// BaiduEditor("talkContent","谈话主要内容","").setNotnull(true));

		ButtonBarPanel buttonBar = new ButtonBarPanel("");
		buttonBar.setAlign(Align.right);
		buttonBar.setFace(ButtonFace.office);
		buttonBar.setStyleClass("d-foot bd-onlytop");
		buttonBar.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(buttonBar);
		buttonBar.addButton(new ClickButton(null, "暂存", "VM(this).cmd('tempSave')"));
		buttonBar.addButton(new ClickButton(null, "提交", "VM(this).cmd('save')"));
		buttonBar.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		//录入提示
		JSCommand save = new JSCommand("save","VM(this).cmd('entryConfirm')");
		view.add(save);
		ConfirmCommand entryConfirm = new ConfirmCommand("entryConfirm",
				"确认要录入谈话记录吗？");
		view.add(entryConfirm);
		view.add(new SubmitCommand("tempSave","talk/tempSaveTalkMgr", null, false));
		entryConfirm.add(new SubmitCommand("doSave","talk/saveTalkMgr", null, false));
		view.add(entryConfirm);
//		view.add(new SubmitCommand("save", "talk/saveTalkMgr", null, false));
		return view;
	}
	
	
		public static BaseView buildShowEntryView2(DspBasicTalkmgr talkMgr) {
			BaseView view = ViewTemplate.buildPopupFormView();
			if (talkMgr == null)
				talkMgr = new DspBasicTalkmgr();
			
			FormPanel popFormPanel = (FormPanel) view
					.findPanelById(ViewTemplate.P_POP_FORM);
			List<String[]> talkTarget = null;
			List<String[]> talkPerson = null;
			List<String> talkType = new ArrayList<String>();
			List<String> talkLevel = new ArrayList<String>();
			Collections.addAll(talkLevel, "省部级", "地厅级", "县处级", "乡科级", "其他");
			Collections.addAll(talkType, "诫勉谈话", "任职谈话", "廉政谈话");
			
			// popFormPanel.add(new Hidden("talkMgrId",talkMgr.getTalkMgrId()));
			
			popFormPanel.add(new Select("talkType", "谈话类型", new String[] {},
					talkType).setWidth("100"));
			popFormPanel.add(new Select("talkLevel", "谈话等级", new String[] {},
					talkLevel).setWidth("100"));
			popFormPanel.add(new Select("talkTarget", "谈话对象", new String[] {},
					talkTarget).setWidth("100"));
			popFormPanel.add(new Select("talkPerson", "谈话人", new String[] {},
					talkPerson).setWidth("100"));
			popFormPanel.add(new DatePicker("talkStartTime", "谈话时间", new Date(),
					DatePicker.DATE_TIME_FULL).setNotnull(false).setDisabled(false));
			popFormPanel.add(new Text("talkTitle", "谈话标题", talkMgr.getTalkSite(),100)
			.setNotnull(false));
			popFormPanel.add(new Text("talkSite", "谈话地点", talkMgr.getTalkSite(), 100)
			.setNotnull(false));
			popFormPanel.add(new Textarea("talkContent", "谈话主要内容", "", 10000));
			AttachSelector das = new AttachSelector("ufiles", "上传附件:", null);
			das.setTitleWidth(10);
			das.setFileSizeLimit("50M");
			popFormPanel.add(das);
			// popFormPanel.add(new
			// BaiduEditor("talkContent","谈话主要内容","").setNotnull(true));
			
			ButtonBarPanel popOper = (ButtonBarPanel) view
					.findPanelById(ViewTemplate.P_POP_BTN);
			popOper.addButton(new ClickButton(null, "提交", "VM(this).cmd('save')"));
			popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
			//录入提示
			JSCommand save = new JSCommand("save","VM(this).cmd('entryConfirm')");
			view.add(save);
			ConfirmCommand entryConfirm = new ConfirmCommand("entryConfirm",
					"确认要录入谈话记录吗？");
			view.add(entryConfirm);
			entryConfirm.add(new SubmitCommand("doSave","talk/saveTalkMgr", null, false));
			view.add(entryConfirm);
//		view.add(new SubmitCommand("save", "talk/saveTalkMgr", null, false));
			return view;
	}

	/**
	 * <p>
	 * 描述:查询界面(新)
	 * </p>
	 * 
	 * 
	 * @param talkMgr
	 * @return
	 * @author 米亦磊
	 */

	public static BaseView buildShowSelectView(DspBasicTalkmgr talkMgr,HttpServletRequest request) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel("", "68,*,40");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		
		GridLayoutFormPanel layoutFormPanel = new GridLayoutFormPanel("layoutForm");
		layoutFormPanel.setHighlightMouseover(false);
		layoutFormPanel.setRowHeight(30);
		rootPanel.addSubPanel(layoutFormPanel);
		
		FormPanel popFormPanel = new FormPanel("popForm");
		rootPanel.addSubPanel(popFormPanel);
		
		List<Object[]> talkType = Services.getService(CodeManService.class)
				.getCodeData("020301");
		talkType.add(0, new Object[] { "", "--------------请选择-------------" });
		List<Object[]> talkLevel = Services.getService(CodeManService.class)
				.getCodeData("020302");
		talkLevel.add(0, new Object[] { "", "--------------请选择-------------" });
		
//		layoutFormPanel.add(0,0,new Select("talkTarget", "谈话对象:  ", new String[] {},
//				talkTarget).setWidth("150"));
		
//		String usLeader = curUser.getLeader();
//		usLeader = TalkMgrService.getLeaderNameById(usLeader);
		Onlinebox leaderName = CommonUnitView.getCommonBox("talkTargetId1", "", "谈话对象:", "talkTargetCmd", Constants.COMBOX_TYPE_USER);
		layoutFormPanel.add(0,0,leaderName.setWidth("200"));
		Hidden talkTargetId = new  Hidden("talkTargetId", "");
		layoutFormPanel.add(talkTargetId);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("talkTargetCmd","talkTargetId1", "选择谈话对象",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"talkTargetId","f_showSelect","直属领导");
		view.add(leaderDio);
		
//		layoutFormPanel.add(0,1,new Select("talkPerson", "谈话人:  ", new String[] {},
//				talkPerson).setWidth("150"));
		
		Onlinebox leaderName2 = CommonUnitView.getCommonBox("talkPersonId1", "", "谈话人:", "talkPersonCmd", Constants.COMBOX_TYPE_USER);
		layoutFormPanel.add(0,1,leaderName2.setWidth("200"));
		Hidden talkPersonId = new  Hidden("talkPersonId", "");
		layoutFormPanel.add(talkPersonId);
		DialogCommand leaderDio2 =CommonUnitView.getDialogCommand("talkPersonCmd","talkPersonId1", "选择谈话人",
				"lmOrgSelector", Constants.COMBOX_TYPE_USER,"leader","f_showSelect","直属领导");
		view.add(leaderDio2);
		
		layoutFormPanel.add(1,0,new Select("talkType", "谈话类型:  ", new String[] {},
				
				talkType).setWidth("200"));
		layoutFormPanel.add(1,1,new Select("talkLevel", "谈话等级:  ", new String[] {},
				talkLevel).setWidth("200"));
		
		Horizontalgroup rspGensgoup = new Horizontalgroup("", "上报时间");
		rspGensgoup.add(new DatePicker("talkStartTime", "", "",
				DatePicker.DATE).setWidth("216"));
		rspGensgoup.add(new Label("", "到", " --到-- "));
		rspGensgoup.add(new DatePicker("talkEndTime", "", "",
				DatePicker.DATE).setWidth("218"));

		popFormPanel.add(rspGensgoup);
		popFormPanel.add(new Text("talkSite", "谈话地点", talkMgr.getTalkSite(), 50)
						.setNotnull(false).setWidth("470"));
		
		ButtonBarPanel buttonBar = new ButtonBarPanel("");
		buttonBar.setAlign(Align.right);
		buttonBar.setFace(ButtonFace.office);
		buttonBar.setStyleClass("d-foot bd-onlytop");
		buttonBar.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(buttonBar);
		buttonBar.addButton(new ClickButton(null, "查询", "VM(this).cmd('detailSearch')"));
		buttonBar.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.addCommand(new SubmitCommand("detailSearch", "talk/detailSearch?cp=$0&type=detail",
				null, true));
		
		return view;
	}
	
	public static BaseView buildShowSelectView2(DspBasicTalkmgr talkMgr) {
		BaseView view = ViewTemplate.buildPopupFormView();
		if (talkMgr == null)
			talkMgr = new DspBasicTalkmgr();

		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		List<Object[]> talkTarget = null;
		List<Object[]> talkPerson = null;

		List<Object[]> talkType = Services.getService(CodeManService.class)
				.getCodeData("020301");
		talkType.add(0, new Object[] { "", "--请选择--" });
		List<Object[]> talkLevel = Services.getService(CodeManService.class)
				.getCodeData("020302");
		talkLevel.add(0, new Object[] { "", "--请选择--" });

		// popFormPanel.add(new Hidden("talkMgrId",talkMgr.getTalkMgrId()));
		popFormPanel.add(new Select("talkTarget", "谈话对象", new String[] {},
				talkTarget).setWidth("100"));
		popFormPanel.add(new Select("talkPerson", "谈话人", new String[] {},
				talkPerson).setWidth("100"));
		popFormPanel.add(new Select("talkType", "谈话类型", new String[] {},

		talkType).setWidth("100"));
		popFormPanel.add(new Select("talkLevel", "谈话等级", new String[] {},
				talkLevel).setWidth("100"));
		Horizontalgroup rspGensgoup = new Horizontalgroup("", "上报时间");
		rspGensgoup.add(new DatePicker("talkStartTime", "", "",
				DatePicker.DATE_TIME));
		rspGensgoup.add(new Label("", "到", " --到-- "));
		rspGensgoup.add(new DatePicker("talkEndTime", "", "",
				DatePicker.DATE_TIME));

		popFormPanel.add(rspGensgoup);
		popFormPanel.add(new Text("talkSite", "谈话地点", talkMgr.getTalkSite(), 50)
						.setNotnull(false));

		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);

		popOper.addButton(new ClickButton(null, "查询", "VM(this).cmd('select')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("select", "talk/detailSearch?cp=$0", null, false));

		return view;
	}

	/**
	 * 
	 * <p>
	 * 描述:统计界面
	 * </p>
	 * 
	 * @param talkMgr
	 * @return
	 * @author 米亦磊
	 */
	public static BaseView buildStatView(String q,HttpServletRequest request) {
		SysUser2 curUser = (SysUser2) request.getSession().getAttribute("loginUser");
		BaseView view = new BaseView();
		VerticalPanel rootPanel = new VerticalPanel("", "*,40");
		rootPanel.setStyleClass("bg-white");
		view.setRootPanel(rootPanel);
		
		GridLayoutFormPanel layoutFormPanel = new GridLayoutFormPanel("layoutForm");
		layoutFormPanel.setHighlightMouseover(false);
		layoutFormPanel.setRowHeight(30);
		rootPanel.addSubPanel(layoutFormPanel);
		
		List<Object[]> year = new ArrayList<Object[]>();
		List<Object[]> quarter = new ArrayList<Object[]>();
		List<Object[]> month = new ArrayList<Object[]>();

		Calendar now = Calendar.getInstance();
		int current = now.get(Calendar.YEAR);
		year.add(new Object[] { "0", current - 2 });
		year.add(new Object[] { "1", current - 1 });
		year.add(new Object[] { "2", current });
		year.add(new Object[] { "3", current + 1 });
		year.add(new Object[] { "4", current + 2 });
		quarter.add(new Object[] { "", "请选择" });
		quarter.add(new Object[] { "1", "第一季度" });
		quarter.add(new Object[] { "2", "第二季度" });
		quarter.add(new Object[] { "3", "第三季度" });
		quarter.add(new Object[] { "4", "第四季度" });
		if (q == null || q.equals("")) {
			month.add(new Object[] { "", "请选择" });
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		} else if (q.equals("1")) {
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
		} else if (q.equals("2")) {
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
		} else if (q.equals("3")) {
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
		} else if (q.equals("4")) {
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		}
//		layoutFormPanel.add(0,1,new Select("talkTargetDep", "谈话对象部门:", null, target)
//				.setWidth("150"));
		Onlinebox leaderName = CommonUnitView.getCommonBox("targetUnitName", "", "谈话对象部门:", "targetUnitNameCmd", Constants.COMBOX_TYPE_DEPT);
		layoutFormPanel.add(0,1,leaderName.setWidth("222"));
		Hidden targetUnitCode = new  Hidden("targetUnitCode", "");
		layoutFormPanel.add(targetUnitCode);
		DialogCommand leaderDio =CommonUnitView.getDialogCommand("targetUnitNameCmd","targetUnitName", "选择谈话对象",
				"lmOrgSelector", Constants.COMBOX_TYPE_DEPT,"targetUnitCode","f_statSearch","直属领导");
		view.add(leaderDio);
		
//		layoutFormPanel.add(1,1,new Select("talkDep", "谈话实施部门:", null, talk)
//				.setWidth("150"));
		Onlinebox leaderName2 = CommonUnitView.getCommonBox("excuteUnitName", "", "谈话实施部门:", "excuteUnitNameCmd", Constants.COMBOX_TYPE_DEPT);
		layoutFormPanel.add(1,1,leaderName2.setWidth("222").setReadonly(false));
		Hidden excuteUnitCode = new  Hidden("excuteUnitCode", "");
		layoutFormPanel.add(excuteUnitCode);
		DialogCommand leaderDio2 =CommonUnitView.getDialogCommand("excuteUnitNameCmd","excuteUnitName", "选择谈话人",
				"lmOrgSelector", Constants.COMBOX_TYPE_DEPT,"excuteUnitCode","f_statSearch","直属领导");
		view.add(leaderDio2);
		
		layoutFormPanel.add(0,0,new Select("year", "年:", year.get(2), year)
				.setWidth("100"));
		Select quarterS = new Select("quarter", "季度:", null, quarter)
				.setWidth("100");
		layoutFormPanel.add(1,0,quarterS);

		quarterS.setOnchange("var quarter = VM( this ).fv('quarter'); VM(this).cmd('typeChange', quarter)");

		layoutFormPanel.add(2,0,new Select("month", "月:", null, month).setWidth("100"));
		
		ButtonBarPanel buttonBar = new ButtonBarPanel("");
		buttonBar.setAlign(Align.right);
		buttonBar.setFace(ButtonFace.office);
		buttonBar.setStyleClass("d-foot bd-onlytop");
		buttonBar.setStyle("padding:0 12px;background:#D3E1EC");
		rootPanel.addSubPanel(buttonBar);
		buttonBar.addButton(new ClickButton(null, "统计查询",
				"VM(this).cmd('statSResult')"));
		buttonBar.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("statSResult", "talk/statSResult", null,
				false));
		view.add(new AjaxCommand("typeChange", "talk/updateType?quarter=$0"));
		return view;
	}

	public static BaseView buildStatView2(String q) {
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		List<Object[]> year = new ArrayList<Object[]>();
		List<Object[]> quarter = new ArrayList<Object[]>();
		List<Object[]> month = new ArrayList<Object[]>();
		
		List<Object[]> target = null;
		List<Object[]> talk = null;
		Calendar now = Calendar.getInstance();
		int current = now.get(Calendar.YEAR);
		year.add(new Object[] { "0", current - 2 });
		year.add(new Object[] { "1", current - 1 });
		year.add(new Object[] { "2", current });
		year.add(new Object[] { "3", current + 1 });
		year.add(new Object[] { "4", current + 2 });
		quarter.add(new Object[] { "", "请选择" });
		quarter.add(new Object[] { "1", "第一季度" });
		quarter.add(new Object[] { "2", "第二季度" });
		quarter.add(new Object[] { "3", "第三季度" });
		quarter.add(new Object[] { "4", "第四季度" });
		if (q == null || q.equals("")) {
			month.add(new Object[] { "", "请选择" });
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		} else if (q.equals("1")) {
			month.add(new Object[] { "01", "一月份" });
			month.add(new Object[] { "02", "二月份" });
			month.add(new Object[] { "03", "三月份" });
		} else if (q.equals("2")) {
			month.add(new Object[] { "04", "四月份" });
			month.add(new Object[] { "05", "五月份" });
			month.add(new Object[] { "06", "六月份" });
		} else if (q.equals("3")) {
			month.add(new Object[] { "07", "七月份" });
			month.add(new Object[] { "08", "八月份" });
			month.add(new Object[] { "09", "九月份" });
		} else if (q.equals("4")) {
			month.add(new Object[] { "10", "十月份" });
			month.add(new Object[] { "11", "十一月份" });
			month.add(new Object[] { "12", "十二月份" });
		}
		popFormPanel.add(new Select("talkTargetDep", "谈话对象部门", null, target)
		.setWidth("150"));
		popFormPanel.add(new Select("talkDep", "谈话实施部门", null, talk)
		.setWidth("150"));
		popFormPanel.add(new Select("year", "年", year.get(2), year)
		.setWidth("150"));
		Select quarterS = new Select("quarter", "季度", null, quarter)
		.setWidth("150");
		popFormPanel.add(quarterS);
		
		quarterS.setOnchange("var quarter = VM( this ).fv('quarter'); VM(this).cmd('typeChange', quarter)");
		
		popFormPanel.add(new Select("month", "月", null, month).setWidth("150"));
		
		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "统计查询",
				"VM(this).cmd('statSResult')"));
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		view.add(new SubmitCommand("statSResult", "talk/statSResult", null,
				false));
		view.add(new AjaxCommand("typeChange", "talk/updateType?quarter=$0"));
		return view;
	}

	/**
	 * <p>
	 * 描述:谈话详情页面
	 * </p>
	 * 
	 * @param talkMgr
	 * @return
	 * @author 米亦磊
	 */

	public static BaseView buildShowDoubleClickView(DspBasicTalkmgr talkMgr,HttpServletRequest request) {
		BaseView view = ViewTemplate.buildPopupFormView();
		String talkMgrId = request.getParameter("talkMgrId");
		if (talkMgr == null)
			talkMgr = new DspBasicTalkmgr();
		FormPanel popFormPanel = (FormPanel) view
				.findPanelById(ViewTemplate.P_POP_FORM);
		List<Object[]> talkType = Services.getService(CodeManService.class)
				.getCodeData("020301");
		talkType.add(0, new Object[] { "", "--请选择--" });
		List<Object[]> talkLevel = Services.getService(CodeManService.class)
				.getCodeData("020302");
		talkLevel.add(0, new Object[] { "", "--请选择--" });

		popFormPanel.add(new Text("talkMgrId", "talkMgrId", talkMgr
				.getTalkMgrId(), 100).setHidden(true));
//		 popFormPanel.add(new Text("talkType", "谈话类型", talkMgr.getTalkType(),
//		 10).setWidth("100").setReadonly(true));

//		 popFormPanel.add(new Text("talkLevel", "谈话级别",
//		 talkMgr.getTalkLevel(), 10).setWidth("100").setReadonly(true));
		popFormPanel.add(new Text("talkTitle", "谈话标题", talkMgr.getTalkTitle(), 50)
		.setNotnull(false).setReadonly(true));
		popFormPanel.add(new Text("targetUnitName", "谈话对象单位", talkMgr.getTargetUnitName(), 50)
		.setNotnull(false).setReadonly(true));
		popFormPanel.add(new Text("talkSite", "谈话地点", talkMgr.getTalkSite(), 50)
						.setNotnull(false).setReadonly(true));
		popFormPanel.add(new Textarea("talkContent", "谈话内容", talkMgr
				.getTalkContent(), 10000).setReadonly(true).setHeight(230));
		popFormPanel.add(new DatePicker("talkStartTime", "谈话时间", talkMgr
				.getTalkStartTime(), DatePicker.DATE_TIME_FULL).setNotnull(
						false).setReadonly(true));
		// popFormPanel.add(new
		// BaiduEditor("talkContent","谈话主要内容","").setNotnull(true));
		
		List<UploadItem> items = new ArrayList<UploadItem>();
		items= TalkMgrService.getItemsByTalkMgrId(talkMgrId);
		popFormPanel.add(new AttachSelector("ufiles", "附件", items).setReadonly(true));

		ButtonBarPanel popOper = (ButtonBarPanel) view
				.findPanelById(ViewTemplate.P_POP_BTN);
		popOper.addButton(new ClickButton(null, "取消", "DFish.close(this);"));
		return view;
	}

	/**
	 * <p>
	 * 描述:获取查询参数
	 * </p>
	 * 
	 * @param request
	 * @return
	 * @author 米亦磊
	 */

	public static FilterParam getFilterParam(HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("talkTargetId");
		fp.registerKey("talkPersonId");
		fp.registerKey("talkMgrId");
		fp.registerKey("talkMgrTitle");
		fp.registerKey("talkTargetName");
		fp.registerKey("talkPersonName");
		fp.registerKey("talkType");
		fp.registerKey("talkLevel");
		fp.registerKey("talkStartTime");
		fp.registerKey("talkEndTime");
		fp.registerKey("talkSite");
		fp.bindRequest(request);
		return fp;
	}

	/**
	 * <p>
	 * 描述:获取查询参数
	 * </p>
	 * 
	 * @param request
	 * @return
	 * @author 米亦磊
	 */

	public static FilterParam getSearchParam(HttpServletRequest request) {
		FilterParam fp = new FilterParam();
		fp.registerKey("targetUnitCode");
		fp.registerKey("targetUnitName");
		fp.registerKey("excuteUnitCode");
		fp.registerKey("excuteUnitName");
		fp.registerKey("year");
		fp.registerKey("quarter");
		fp.registerKey("month");
		fp.bindRequest(request);
		return fp;
	}
	
	/**
	* <p>描述:数据字典转换</p>
	* @param data
	* @return
	* @author 米亦磊
	*/
	
	public static List<DspBasicTalkmgr> filterData(List<DspBasicTalkmgr> data){
		List<Object[]> talkType = Services.getService(CodeManService.class).getCodeData("020301");
		List<Object[]> talkLevel = Services.getService(CodeManService.class).getCodeData("020302");
		
		for(DspBasicTalkmgr o : data){
			for(Object[] type:talkType){
				if(type[0].equals(o.getTalkType())){
					o.setTalkType(String.valueOf(type[1]));
				}
			}
            for(Object[] level:talkLevel){
            	if(level[0].equals(o.getTalkLevel())){
					o.setTalkLevel(String.valueOf(level[1]));
				}
			}
		}
		return data;
	}
	
	
	/**
	* <p>描述:创建模板下载界面</p>
	* @param items
	* @param title
	* @return
	* @author 米亦磊
	*/
	
	public static BaseView buildDownloadView(List<UploadItem> items){
		BaseView view = ViewTemplate.buildPopupFormView();
		FormPanel popFormPanel = (FormPanel) view.findPanelById(ViewTemplate.P_POP_FORM);
		AttachSelector das = new AttachSelector("ufiles", "谈话记录模板", items); 
		das.setWidth("200");
		das.setTitleWidth(200);
		das.setReadonly(true);
		popFormPanel.add(das);
		return view;
	}
}

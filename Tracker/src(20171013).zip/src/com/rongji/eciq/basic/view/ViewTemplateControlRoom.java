package com.rongji.eciq.basic.view;

import java.util.List;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.commons.Constants;
import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.Align;
import com.rongji.dfish.engines.xmltmpl.BaseDialogTemplate;
import com.rongji.dfish.engines.xmltmpl.BaseView;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.DialogPosition;
import com.rongji.dfish.engines.xmltmpl.DialogTemplate;
import com.rongji.dfish.engines.xmltmpl.Panel;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.VAlign;
import com.rongji.dfish.engines.xmltmpl.button.ClickButton;
import com.rongji.dfish.engines.xmltmpl.command.AjaxCommand;
import com.rongji.dfish.engines.xmltmpl.command.AlertCommand;
import com.rongji.dfish.engines.xmltmpl.command.DialogCommand;
import com.rongji.dfish.engines.xmltmpl.command.SubmitCommand;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.FilmPanel;
import com.rongji.dfish.engines.xmltmpl.component.FlowPanel;
import com.rongji.dfish.engines.xmltmpl.component.FormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridLayoutFormPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanelPubInfo;
import com.rongji.dfish.engines.xmltmpl.component.HorizontalPanel;
import com.rongji.dfish.engines.xmltmpl.component.HtmlPanel;
import com.rongji.dfish.engines.xmltmpl.component.PagePanel;
import com.rongji.dfish.engines.xmltmpl.component.SourcePanel;
import com.rongji.dfish.engines.xmltmpl.component.TreePanel;
import com.rongji.dfish.engines.xmltmpl.component.VerticalPanel;
import com.rongji.dfish.engines.xmltmpl.form.Combobox;
import com.rongji.dfish.engines.xmltmpl.form.Onlinebox;
import com.rongji.dfish.engines.xmltmpl.form.Text;

public class ViewTemplateControlRoom {
	// public static final AlertCommand
	// DIALOG_SUCCESS=com.rongji.dfish.framework.view.ViewTemplateControlRoom.DIALOG_SUCCESS;

	public static final AlertCommand DIALOG_SUCCESS = new AlertCommand("dgSuc",
			"操作成功", "img/p/alert-info.gif", DialogPosition.southeast, 5);

	public static DialogTemplate getDialogTemplate(String id) {
		if ("f_std".equals(id)) {
			return TMPL_STD;
		} else if ("f_std_mx".equals(id)) {
			return TMPL_MAX;
		} else if ("f_std_x".equals(id)) {
			return TMPL_CLOSE;
		} else if ("none".equals(id)) {
			return getNoneDialogTempate();
		} else if ("f_border_form".equals(id)) {
			return getBorderFormDialogTempate();
		} else {
			// 默认模板
			return TMPL_STD;
		}
	}

	private static DialogTemplate getNoneDialogTempate() {
		DialogTemplate dialog = new BaseDialogTemplate("none");
		VerticalPanel vp = new VerticalPanel("f_root", "*");
		vp.setStyleClass("bg-white");
		SourcePanel content = new SourcePanel("dlg-src", null);
		vp.addSubPanel(content);
		dialog.addSubPanel(vp);
		return dialog;
	}

	private static DialogTemplate getBorderFormDialogTempate() {
		DialogTemplate dialog = new BaseDialogTemplate("f_border_form");
		VerticalPanel vf = new VerticalPanel(null, "*", "bd-form white", "", 2,
				2);
		dialog.addSubPanel(vf);
		SourcePanel sf = new SourcePanel("dlg-src", "", false, null, null, 0, 0);
		vf.addSubPanel(sf);
		return dialog;
	}

	private static BaseDialogTemplate TMPL_STD = new BaseDialogTemplate("f_std");
	private static BaseDialogTemplate TMPL_MAX = new BaseDialogTemplate(
			"f_std_mx");
	private static BaseDialogTemplate TMPL_CLOSE = new BaseDialogTemplate(
			"f_std_x");
	static {
		SourcePanel CONTENT = new SourcePanel("dlg-src", "");
		CONTENT.setStyleClass("d-bd white");
		CONTENT.setHorizontalMinus(2);
		CONTENT.setVerticalMinus(1);
		HtmlPanel DLG_TOP_LEFT = new HtmlPanel(null, null);
		DLG_TOP_LEFT.setStyleClass("d-tl");
		HtmlPanel DLG_TITLE = new HtmlPanel("dlg-tt", null);
		DLG_TITLE.setStyleClass("d-tt");
		HtmlPanel DLG_MAX_BTN = new HtmlPanel("dlg-max", null);
		DLG_MAX_BTN.setStyleClass("d-b-max");
		HtmlPanel DLG_CLOSE_BTN = new HtmlPanel("dlg-x", null);
		DLG_CLOSE_BTN.setStyleClass("d-b-x");
		HtmlPanel DLG_TOP_RIGHT = new HtmlPanel(null, null);
		DLG_TOP_RIGHT.setStyleClass("d-tr");
		HtmlPanel DLG_BOTTOM_LEFT = new HtmlPanel(null, null);
		DLG_BOTTOM_LEFT.setStyleClass("d-bl");
		HtmlPanel DLG_BOTTOM_RIGHT = new HtmlPanel(null, null);
		DLG_BOTTOM_RIGHT.setStyleClass("d-br");
		HtmlPanel DLG_BOTTOM_CENTER = new HtmlPanel(null, null);
		DLG_BOTTOM_CENTER.setStyleClass("d-bc");

		VerticalPanel topCenter = new VerticalPanel(null, "*");
		topCenter.setStyleClass("d-tc");
		HorizontalPanel topTitle = new HorizontalPanel(null, "*,36,36");
		topTitle.setStyleClass("d-tc-r");
		topCenter.addSubPanel(topTitle);
		topTitle.addSubPanel(DLG_TITLE, DLG_MAX_BTN, DLG_CLOSE_BTN);

		VerticalPanel stdRoot = new VerticalPanel(null, "38,*,0");
		VerticalPanel stdTop = new VerticalPanel(null, "*");
		stdTop.setStyleClass("d-bg-top");
		HorizontalPanel stdHead = new HorizontalPanel(null, "1,*,1");
		stdHead.setStyleClass("d-top");
		stdTop.addSubPanel(stdHead);
		HorizontalPanel stdFoot = new HorizontalPanel(null, "2,*,2");
		stdRoot.addSubPanel(stdTop, CONTENT, stdFoot);
		stdHead.addSubPanel(DLG_TOP_LEFT, topCenter, DLG_TOP_RIGHT);
		stdFoot.addSubPanel(DLG_BOTTOM_LEFT, DLG_BOTTOM_CENTER,
				DLG_BOTTOM_RIGHT);
		TMPL_STD.addSubPanel(stdRoot);
		TMPL_STD.setFace("dlg-std");

		VerticalPanel maxTopCenter = new VerticalPanel(null, "*");
		maxTopCenter.setStyleClass("d-tc");
		HorizontalPanel maxTopTitle = new HorizontalPanel(null, "*,36");
		maxTopTitle.setStyleClass("d-tc-r");
		maxTopCenter.addSubPanel(maxTopTitle);
		maxTopTitle.addSubPanel(DLG_TITLE, DLG_MAX_BTN);

		VerticalPanel maxRoot = new VerticalPanel(null, "38,*,0");
		HorizontalPanel maxHead = new HorizontalPanel(null, "1,*,1");
		HorizontalPanel maxFoot = new HorizontalPanel(null, "2,*,2");
		maxRoot.addSubPanel(maxHead, CONTENT, maxFoot);
		maxHead.addSubPanel(DLG_TOP_LEFT, maxTopCenter, DLG_TOP_RIGHT);
		maxFoot.addSubPanel(DLG_BOTTOM_LEFT, DLG_BOTTOM_CENTER,
				DLG_BOTTOM_RIGHT);
		TMPL_MAX.addSubPanel(maxRoot);
		TMPL_MAX.setFace("dlg-std");

		VerticalPanel closeTopCenter = new VerticalPanel(null, "*");
		closeTopCenter.setStyleClass("d-tc");
		HorizontalPanel closeTopTitle = new HorizontalPanel(null, "*,36");
		closeTopTitle.setStyleClass("d-tc-r");
		closeTopCenter.addSubPanel(closeTopTitle);
		closeTopTitle.addSubPanel(DLG_TITLE, DLG_CLOSE_BTN);

		VerticalPanel closeRoot = new VerticalPanel(null, "38,*,0");
		VerticalPanel closeTop = new VerticalPanel(null, "*");
		closeTop.setStyleClass("d-bg-top");
		HorizontalPanel closeHead = new HorizontalPanel(null, "1,*,1");
		closeHead.setStyleClass("d-top");
		closeTop.addSubPanel(closeHead);
		HorizontalPanel closeFoot = new HorizontalPanel(null, "2,*,2");
		closeRoot.addSubPanel(closeTop, CONTENT, closeFoot);
		closeHead.addSubPanel(DLG_TOP_LEFT, closeTopCenter, DLG_TOP_RIGHT);
		closeFoot.addSubPanel(DLG_BOTTOM_LEFT, DLG_BOTTOM_CENTER,
				DLG_BOTTOM_RIGHT);
		TMPL_CLOSE.addSubPanel(closeRoot);
		TMPL_CLOSE.setFace("dlg-std");

	}

	public static void fillPagePanel(PagePanel pagePanel, Page page) {
		if (pagePanel == null || page == null) {
			return;
		}
		if (page.getCurrentPage() < 1) {
			page.setCurrentPage(1);
		}
		if (page.getPageSize() < 1) {
			page.setPageSize(15);
		}
		pagePanel.setCurrentPage(page.getCurrentPage());
		pagePanel.setMaxPage(page.getPageCount());
		pagePanel.setSumRecords(page.getRowCount());
		// FIXME 当前记录数以当前总共到了第几条记�?,若�?�数小于页面大小,按照总数大小显示
		int currentRecords = page.getCurrentPage() * page.getPageSize();
		if (currentRecords > page.getRowCount()) {
			currentRecords = page.getRowCount();
		}
		pagePanel.setCurrentRecords(currentRecords);

	}

	public static void fillPagePanel(FlowPanel hp, Page page, List<?> data,
			String clkCmd) {
		hp.setDirection("h");
		HtmlPanel htmlPanel = new HtmlPanel("", "页码：" + page.getCurrentPage()
				+ "/" + page.getPageCount() + " 记录：" + data.size() + "/"
				+ page.getRowCount() + "");
		htmlPanel.setStyle("margin:8px 15px 0 10px;");
		PagePanel pagePanel = Constants.getPagePanel();
		// pagePanel.setShowInfo(true);
		pagePanel.setCurrentPage(page.getCurrentPage());
		pagePanel.setCurrentRecords(data == null ? 0 : data.size());
		pagePanel.setMaxPage(page.getPageCount());
		pagePanel.setSumRecords(page.getRowCount());
		pagePanel.setStyle("margin:10px 0px 0 10px;");
		pagePanel.setClk(clkCmd);
		pagePanel.setAlign(Align.left);
		hp.setAlign(Align.right);
		hp.addSubPanel(htmlPanel).addSubPanel(
				pagePanel.setFace(PagePanel.FACE_DEFAULT));
	}

	public static ClickButton getButton(String title, String click) {
		return getButton("", title, click);
	}

	/**
	 * 获取统一宽度按钮
	 * 
	 * @param icon
	 * @param title
	 * @param click
	 * @return
	 */
	public static ClickButton getButton(String icon, String title, String click) {
		ClickButton btn = new ClickButton(icon, title, click);
		btn.setWidth(60);
		return btn;
	}

	private static final int DROP_WIDTH = 350;

	public static Combobox getCombobox(String name, String title, Object value,
			String src) {
		return getCombobox(name, title, value, src, true);
	}

	public static Combobox getCombobox(String name, String title, Object value,
			String src, boolean defaultWidth) {
		Combobox cbb = new Combobox(name, title, value, "loading..", src, null,
				null);
		if (defaultWidth) {
			cbb.setDropWidth(DROP_WIDTH);
		}
		cbb.setShowdrop(true);
		cbb.setNobr(true);
		return cbb;
	}

	public static Onlinebox getOnlinebox(String name, String title,
			Object value, String src) {
		Onlinebox olb = new Onlinebox(name, title, value, src, null, -1, false,
				false, false, null, false);
		olb.setDropw(DROP_WIDTH);
		olb.setNobr(true);
		return olb;
	}

	public static SubmitCommand getSubmitCommand(String id, String act,
			String formId, String btnId) {
		boolean hasBtnId = Utils.notEmpty(btnId);
		SubmitCommand submit = new SubmitCommand(id, act, formId, !hasBtnId);
		if (hasBtnId) {
			submit.setBeforeSend("VM(this).button('" + btnId
					+ "').setLoading(true);");
			submit.setError("VM(this).button('" + btnId
					+ "').setLoading(false);");
		}
		return submit;
	}

	public static AjaxCommand getAjaxCommand(String id, String act, String btnId) {
		AjaxCommand ajax = new AjaxCommand(id, act);
		boolean hasBtnId = Utils.notEmpty(btnId);
		if (hasBtnId) {
			ajax.setBeforeSend("VM(this).button('" + btnId
					+ "').setLoading(true);");
			ajax.setError("VM(this).button('" + btnId + "').setLoading(false);");
		}
		return ajax;
	}

	public static AlertCommand getInfoAlert(String alertMsg) {
		AlertCommand alert = new AlertCommand("alert", alertMsg,
				"img/p/alert-info.gif", DialogPosition.southeast, 5);
		return alert;
	}

	public static AlertCommand getWarnAlert(String alertMsg) {
		AlertCommand alert = new AlertCommand("alert", alertMsg,
				"img/p/alert-warn.gif", DialogPosition.middle, 5);
		return alert;
	}

	public static AlertCommand getTipAlert(String alertMsg, DialogPosition pos) {
		AlertCommand alert = new AlertCommand("alert", alertMsg,
				"img/p/alert-info.gif", pos, 5);
		return alert;
	}

	/**
	 * 弹窗根面板ID
	 */
	public static final String P_POP_ROOT = "pop_root";
	
	/**
	 * 弹窗根面板ID
	 */
	public static final String P_POP_UP_HP = "pop_up";

	/**
	 * 弹窗表单面板ID
	 */
	public static final String P_POP_FORM = "f_form";
	
	/**
	 * 弹窗表单面板ID
	 */
	public static final String P_POP_UP_LFORM = "f_form_l";
	
	/**
	 * 弹窗表单面板ID
	 */
	public static final String P_POP_UP_RFORM = "f_form_r";

	/**
	 * 弹窗操作按钮面板ID
	 */
	public static final String P_POP_BTN = "f_btn";

	public static BaseView buildPopupFormView() {
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		FormPanel popForm = new FormPanel(P_POP_FORM);
		popVP.addSubPanel(popForm);
		setPopupFormStyle(popForm);
		popForm.setScroll(Scroll.miniscroll);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");

		return view;
	}
	public static BaseView buildPopupFormViewladr() {
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		GridLayoutFormPanel popForm = new GridLayoutFormPanel(P_POP_FORM);
		popVP.addSubPanel(popForm);
		setPopupFormStyle(popForm);
		popForm.setScroll(Scroll.miniscroll);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");

		return view;
	}
	
	public static BaseView buildPopupFormView2() {
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "100,*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		HorizontalPanel upPanel = new HorizontalPanel(P_POP_UP_HP,"*,*");
		popVP.addSubPanel(upPanel);
		upPanel.setStyleClass("bg-white");
		
		FormPanel popFormL = new FormPanel(P_POP_UP_LFORM);
		popFormL.setScroll(Scroll.hidden);
		FormPanel popFormR = new FormPanel(P_POP_UP_RFORM);
		popFormR.setScroll(Scroll.hidden);
		setPopupFormStyle(popFormL);
		setPopupFormStyle(popFormR);
		upPanel.addSubPanel(popFormL);
		upPanel.addSubPanel(popFormR);
		FormPanel popForm = new FormPanel(P_POP_FORM);
		popVP.addSubPanel(popForm);
		
		setPopupFormStyle(popForm);
		
		popForm.setScroll(Scroll.miniscroll);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");

		return view;
	}
	public static BaseView buildPopupFormView3() {
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "130,*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		HorizontalPanel upPanel = new HorizontalPanel(P_POP_UP_HP,"*,*");
		popVP.addSubPanel(upPanel);
		upPanel.setStyleClass("bg-white");
		
		FormPanel popFormL = new FormPanel(P_POP_UP_LFORM);
		FormPanel popFormR = new FormPanel(P_POP_UP_RFORM);
		setPopupFormStyle(popFormL);
		setPopupFormStyle(popFormR);
		upPanel.addSubPanel(popFormL);
		upPanel.addSubPanel(popFormR);
		FormPanel popForm = new FormPanel(P_POP_FORM);
		popVP.addSubPanel(popForm);
		
		setPopupFormStyle(popForm);
		
		popForm.setScroll(Scroll.miniscroll);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");

		return view;
	}
	public static BaseView buildPopupFormView(boolean isComplex) {
		// FIXME 估计有很多弹出框都是用复杂表格做的,所以这个方法先临时封装
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		Panel popForm = null;
		if (isComplex) {
			GridLayoutFormPanel form = new GridLayoutFormPanel(P_POP_FORM);
			popForm = form;
			form.setScroll(Scroll.miniscroll);
			form.setStyleClass("bg-white");
			form.setHighlightMouseover(false);
			form.setFace(GridPanelPubInfo.FACE_NONE);
		} else {
			FormPanel form = new FormPanel(P_POP_FORM);
			popForm = form;
			form.setScroll(Scroll.miniscroll);
		}
		popVP.addSubPanel(popForm);
		setPopupFormStyle(popForm);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 30px;background:#D3E1EC");

		return view;
	}

	public static void setPopupFormStyle(Panel form) {
		if (form == null) {
			return;
		}
		// 设置弹出框表单块的样式
		form.setStyle("padding:20px 15px 0px 2px;");
		form.setStyleClass("");
	}

	public static ButtonBarPanel getButtonBarPanel() {
		ButtonBarPanel bbp = new ButtonBarPanel("f_right_top");
		bbp.setStyleClass("bg-low");
		bbp.setStyle("padding-right:6px;background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;");
		return bbp;
	}

	public static HtmlPanel getTitleHtmlPanel(String funcName) {
		HtmlPanel title = new HtmlPanel("f_left_top", funcName);
		title.setStyle("background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;padding-left:10px;color:#0982B9;line-height:37px;font-weight:bold;");
		return title;
	}

	public static BaseView buildLeftAndRightView() {
		return buildLeftAndRightView("25%");
	}
	
	public static BaseView buildLeftAndRightView(String leftPercent) {
		BaseView view = new BaseView();
		HorizontalPanel root = new HorizontalPanel("f_root", leftPercent+",1,*");
		view.setRootPanel(root);
		root.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;

		VerticalPanel vpleft = new VerticalPanel("f_left", "36,*");
		root.addSubPanel(vpleft);
		HtmlPanel title = new HtmlPanel("f_left_top",
				"这个面板一般用于菜单/导航，请替换它，他的ID为f_left_top");
		vpleft.addSubPanel(title);
		title.setStyle("font-size:14px;line-height:36px;background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;");
		vpleft.addSubPanel(new TreePanel("f_left_content")
				.setScroll(Scroll.miniscroll));

		HtmlPanel splitor = new HtmlPanel("split",
				"<div style='width:3px;height:36px;background-color:#FFFFFF;'></div>");
		root.addSubPanel(splitor);
		splitor.setStyle("background-color:#B7CBE3;");
		splitor.setHorizontalResize("10,50");

		VerticalPanel vpright = new VerticalPanel("f_right", "36,*");
		root.addSubPanel(vpright);

		ButtonBarPanel oper = new ButtonBarPanel("f_right_top");
		vpright.addSubPanel(oper);
		oper.setStyle("background-color:#2AA0D3;");

		vpright.addSubPanel(new GridLayoutFormPanel("f_right_content"));

		return view;
	}

	public static final String P_MAIN = "p_main_control";
	public static final String P_MAIN_TOP = "p_m_top_control";
	public static final String P_MAIN_TITLE = "p_m_title_control";
	public static final String P_MAIN_BTN = "p_m_btn_control";
	public static final String P_STAT_BTN = "p_stat_btn_control";
	public static final String P_DETAIL_BTN = "p_detial_btn_control";
	public static final String P_MAIN_CENTER_BTN = "p_m_center_btn_control";
	public static final String P_MAIN_CONTENT = "p_m_content_control";
	public static final String P_MAIN_SEARCH = "p_m_search_control";
	public static final String P_MAIN_GRID = "p_m_grid_control";
	public static final String P_SECOND_GRID = "p_s_grid_control";
	public static final String P_MAIN_PAGE = "p_m_page_control";
	public static final String P_MAIN_FORM = "p_m_form_control";
	public static final String P_MAIN_LEFT_PAGE = "p_m_left_page_control";
	public static final String P_MAIN_TAB_BTN = "p_m_tab_btn_control";
	public static final String P_MAIN_FILM = "p_m_film_control";
	public static final String P_MAIN_ROOT = "p_m_root_control";

	/**
	 * 构建office编辑界面
	 * 
	 * @return
	 */
	public static BaseView buildOfficeView() {
		BaseView view = new BaseView();
		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		HtmlPanel content = new HtmlPanel(P_MAIN_CONTENT, "");
		popVP.addSubPanel(content);

		ButtonBarPanel popOper = new ButtonBarPanel(P_MAIN_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background-color:#e5e6e8");

		view.addDialogTemplate(ViewTemplateControlRoom.getDialogTemplate("f_std"));
		view.addDialogTemplate(ViewTemplateControlRoom.getDialogTemplate("f_std_x"));
		view.addDialogTemplate(ViewTemplateControlRoom.getDialogTemplate("none"));
		view.addDialogTemplate(ViewTemplateControlRoom.getDialogTemplate("f_border_form"));

		return view;
	}

	public static BaseView buildMainView() {
		BaseView view = new BaseView();

		VerticalPanel shell = new VerticalPanel(P_MAIN, "36,*");
		view.setRootPanel(shell);
		shell.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;

		HorizontalPanel top = new HorizontalPanel(P_MAIN_TOP, "*,400");
		shell.addSubPanel(top);

		HtmlPanel title = new HtmlPanel(P_MAIN_TITLE, "请设置标题[面板ID:"
				+ P_MAIN_TITLE + "]");
		top.addSubPanel(title);
		title.setAlign(Align.left);
		title.setVAlign(VAlign.middle);
		title.setStyle("font-weight:bold;line-height:36px;background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;padding-left:10px;color:#0982B9;");

		ButtonBarPanel oper = new ButtonBarPanel(P_MAIN_BTN);
		top.addSubPanel(oper);
		oper.setAlign(Align.right);
		oper.setStyle("padding:0px 6px 0px 0;background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;");

		VerticalPanel content = new VerticalPanel(P_MAIN_CONTENT, "0,*,50");
		shell.addSubPanel(content);

		GridLayoutFormPanel search = new GridLayoutFormPanel(P_MAIN_SEARCH);
		content.addSubPanel(search);
		search.setHighlightMouseover(false);
		search.setFace(GridPanelPubInfo.FACE_NONE);

		GridPanel grid = new GridPanel(P_MAIN_GRID);
		content.addSubPanel(grid);
		grid.setStyleClass("grid-odd");
		grid.setNobr(true);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("margin:10px;margin-bottom:0;border:1px solid #B7CBE3;");
		grid.setRowHeight(40);

		PagePanel pPage = new PagePanel(P_MAIN_PAGE);
		content.addSubPanel(pPage);
		pPage.setFace(PagePanel.FACE_OFFICE);

		return view;
	}

	public static BaseView buildMainFormView() {
		BaseView view = new BaseView();

		VerticalPanel shell = new VerticalPanel(P_MAIN, "36,*");
		view.setRootPanel(shell);

		HorizontalPanel top = new HorizontalPanel(P_MAIN_TOP, "*,400");
		shell.addSubPanel(top);
		top.setStyle(";padding:0px 4px;");
		top.setStyleClass("bg-low");

		HtmlPanel title = new HtmlPanel(P_MAIN_TITLE, "请设置标题[面板ID:"
				+ P_MAIN_TITLE + "]");
		top.addSubPanel(title);
		title.setStyle("font-size:14px;line-height:36px;");
		title.setAlign(Align.left);
		title.setVAlign(VAlign.middle);
		title.setStyleClass("nobr fix");

		ButtonBarPanel oper = new ButtonBarPanel(P_MAIN_BTN);
		top.addSubPanel(oper);
		oper.setFace(ButtonFace.group);
		oper.setAlign(Align.right);

		FlowPanel content = new FlowPanel(P_MAIN_CONTENT);
		shell.addSubPanel(content);
		content.setScroll(Scroll.miniscroll);

		HorizontalPanel hp = new HorizontalPanel("", "*,"
				+ DialogCommand.WIDTH_LARGE + ",*");
		content.addSubPanel(hp);
		hp.addSubPanel(HtmlPanel.EMPTY);

		GridLayoutFormPanel form = new GridLayoutFormPanel(P_MAIN_FORM);
		hp.addSubPanel(form);
		form.setStyleClass("bg-white");
		form.setHighlightMouseover(false);
		form.setFace(GridPanelPubInfo.FACE_NONE);
		form.setScroll(Scroll.miniscroll);

		hp.addSubPanel(HtmlPanel.EMPTY);

		return view;
	}
	
	public static HorizontalPanel getSearchPanel(String clickAction,String grayTip,boolean enterSearch) {
		HorizontalPanel searchHP = new HorizontalPanel("searchHP", "*,30");
		searchHP.setStyle("margin:10px 9px 6px 9px;");
		searchHP.setStyleClass("bd-title");
		FormPanel searchForm = new FormPanel("orgSearchFP");
		searchHP.addSubPanel(searchForm);
		searchForm.setScroll(Scroll.hidden);
		searchForm.setCellpadding(0);
		searchForm.setCellspacing(0);
		searchForm.setStyle("padding:0px;margin-left:3px;");
		
		Text t = new Text("searchContext","searchContext",null,-1);
		t.setTransparent(true);
		t.setFullLine(true);
		t.setGrayTip(grayTip);
		searchForm.add(t);

		ButtonBarPanel searchBBP = new ButtonBarPanel("searchBBP");
		searchHP.addSubPanel(searchBBP);
		searchBBP.setAlign(Align.center);
		searchBBP.setFace(ButtonFace.link);

		ClickButton toolsSearch = new ClickButton("m/pub/img/task_search.png",
				"", clickAction);
		searchBBP.addButton(toolsSearch);
		return searchHP;
	}

	public static HorizontalPanel getSearchPanel() {
		HorizontalPanel searchHP = new HorizontalPanel("searchHP", "*,30");
		searchHP.setStyle("margin:10px 9px 6px 9px;");
		searchHP.setStyleClass("bd-title ");
		FormPanel searchForm = new FormPanel("orgSearchFP");
		searchHP.addSubPanel(searchForm);
		searchForm.setScroll(Scroll.hidden);
		searchForm.setCellpadding(0);
		searchForm.setCellspacing(0);
		searchForm.setStyle("padding:0px;margin-left:3px;");
		Combobox combobox = new Combobox("searchContent", "", "", "loding", "",
				null, null, 200, false, false, false, false, false, false);
		combobox.setTransparent(true);
		combobox.setGrayTip("搜索流程事项");
		combobox.setFullLine(true);
		combobox.setMaxLength(100);
		searchForm.add(combobox);

		ButtonBarPanel searchBBP = new ButtonBarPanel("searchBBP");
		searchHP.addSubPanel(searchBBP);
		searchBBP.setAlign(Align.center);
		searchBBP.setFace(ButtonFace.link);

		ClickButton toolsSearch = new ClickButton("m/pub/img/task_search.png",
				"", "");
		searchBBP.addButton(toolsSearch);
		return searchHP;
	}

	public static BaseView buildIndexView() {
		BaseView view = new BaseView();
		VerticalPanel vp = null;// FIXME 搜索栏不能有175的高度
		String firstPanelHeight = "86";// 搜索栏默认高度
		String secondPanelHeight = "40";// 按钮栏默认高度
		String thireePanelHeight = "*";// 表格栏默认高度
		String fourPanelHeight = "40";// 翻页栏默认高度

		// 搜索栏
		HorizontalPanel p = new HorizontalPanel("f_searchVP", "*,120");

		// VerticalPanel p = new VerticalPanel("f_searchVP",
		// "*,"+secondPanelHeight);
		p.setStyleClass("query-background");
		FlowPanel conditionPanel = new FlowPanel("condition");
		conditionPanel.setStyleClass("bd-onlybottom  bd-title");
		conditionPanel.setStyle("padding-top:5px;padding-right:5px;");
		conditionPanel.setScroll(Scroll.miniscroll);
		p.addSubPanel(conditionPanel);
		GridLayoutFormPanel form = new GridLayoutFormPanel(P_MAIN_SEARCH);
		form.setFace(GridPanelPubInfo.FACE_NONE);
		form.setStyleClass("");
		form.setHighlightMouseover(false);
		conditionPanel.addSubPanel(form);

		// 按钮栏
		ButtonBarPanel bbp = new ButtonBarPanel(P_MAIN_BTN);
		p.addSubPanel(bbp);
		bbp.setAlign(Align.center);
		bbp.setStyleClass("bd-onlybottom  bd-title");
		bbp.setCellspacing(10);
		bbp.setDirectionVertical(true);
		// 列表显示
		GridPanel grid = new GridPanel(P_MAIN_GRID);
		grid.setNobr(true);
		grid.setStyleClass("grid-odd");
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("margin:10px;margin-bottom:0;border:1px solid #B7CBE3;");
		grid.setRowHeight(40);

		vp = new VerticalPanel("f_root", firstPanelHeight + ","
				+ thireePanelHeight + "," + fourPanelHeight);
		vp.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;
		vp.addSubPanel(p);// 搜索栏
		vp.addSubPanel(grid);// 表格

		FlowPanel hp = new FlowPanel(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		hp.setDirection("h");
		vp.addSubPanel(hp);
		view.addSubPanel(vp);
		return view;
	}

	public static BaseView buildIndexHasBtnView(boolean isSpecialBtnPanel) {
		BaseView view = new BaseView();
		VerticalPanel vp = null;// FIXME 搜索栏不能有175的高度
		String firstPanelHeight = "86";// 搜索栏默认高度
		String secondPanelHeight = "40";// 按钮栏默认高度
		String thireePanelHeight = "*";// 表格栏默认高度
		String fourPanelHeight = "40";// 翻页栏默认高度

		// 搜索栏
		HorizontalPanel p = new HorizontalPanel("f_searchVP", "*,120");

		// VerticalPanel p = new VerticalPanel("f_searchVP",
		// "*,"+secondPanelHeight);
		p.setStyleClass("query-background");
		FlowPanel conditionPanel = new FlowPanel("condition");
		conditionPanel.setStyleClass("bd-onlybottom  bd-title");
		conditionPanel.setStyle("padding-top:5px;padding-right:5px;");
		conditionPanel.setScroll(Scroll.miniscroll);
		p.addSubPanel(conditionPanel);
		GridLayoutFormPanel form = new GridLayoutFormPanel(P_MAIN_SEARCH);
		form.setFace(GridPanelPubInfo.FACE_NONE);
		form.setStyleClass("");
		form.setHighlightMouseover(false);
		conditionPanel.addSubPanel(form);

		// 搜索按钮栏
		ButtonBarPanel bbp = new ButtonBarPanel(P_MAIN_BTN);
		p.addSubPanel(bbp);
		bbp.setAlign(Align.center);
		bbp.setStyleClass("bd-onlybottom  bd-title");
		bbp.setCellspacing(10);
		bbp.setDirectionVertical(true);

		// 列表显示
		GridPanel grid = new GridPanel(P_MAIN_GRID);
		grid.setNobr(true);
		grid.setStyleClass("grid-odd");
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("margin:10px;margin-bottom:0;border:1px solid #B7CBE3;");
		grid.setRowHeight(40);

		vp = new VerticalPanel(P_MAIN_ROOT, firstPanelHeight + ","
				+ secondPanelHeight + "," + thireePanelHeight + ","
				+ fourPanelHeight);
		vp.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;
		vp.addSubPanel(p);// 搜索栏
		// 按钮栏
		if (isSpecialBtnPanel) {// 中间按钮特殊处理，可以带表单等。
			HorizontalPanel centerhp = new HorizontalPanel(
					ViewTemplateControlRoom.P_MAIN_CENTER_BTN, "*");
			centerhp.setStyle("background-color:#dfeafa");
			vp.addSubPanel(centerhp);
		} else {// 正常按钮栏
			ButtonBarPanel centerBtn = new ButtonBarPanel(
					ViewTemplateControlRoom.P_MAIN_CENTER_BTN);
			centerBtn.setStyle("padding-left:5px;background-color:#dfeafa");
			centerBtn.setAlign(Align.left);
			centerBtn.setCellspacing(10);
			vp.addSubPanel(centerBtn);// 按钮
		}
		vp.addSubPanel(grid);// 表格

		FlowPanel hp = new FlowPanel(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		hp.setDirection("h");
		vp.addSubPanel(hp);
		view.addSubPanel(vp);
		return view;
	}

	/**
	 * 绘制双表格界面 黄国海 2017-01-04
	 * 
	 * @param isSpecialBtnPanel
	 * @return
	 */
	public static BaseView buildIndexTwoGridView(boolean isSpecialBtnPanel) {
		BaseView view = new BaseView();
		VerticalPanel vp = null;// FIXME 搜索栏不能有175的高度
		String firstPanelHeight = "86";// 搜索栏默认高度
		String secondPanelHeight = "40";// 按钮栏默认高度
		String thireePanelHeight = "*";// 表格栏默认高度
		String secondGridPanelHeight = "*";// 表格栏默认高度
		String fourPanelHeight = "40";// 翻页栏默认高度

		// 搜索栏
		HorizontalPanel p = new HorizontalPanel("f_searchVP", "*,120");

		// VerticalPanel p = new VerticalPanel("f_searchVP",
		// "*,"+secondPanelHeight);
		p.setStyleClass("query-background");
		FlowPanel conditionPanel = new FlowPanel("condition");
		conditionPanel.setStyleClass("bd-onlybottom  bd-title");
		conditionPanel.setStyle("padding-top:5px;padding-right:5px;");
		conditionPanel.setScroll(Scroll.miniscroll);
		p.addSubPanel(conditionPanel);
		GridLayoutFormPanel form = new GridLayoutFormPanel(P_MAIN_SEARCH);
		form.setFace(GridPanelPubInfo.FACE_NONE);
		form.setStyleClass("");
		form.setHighlightMouseover(false);
		conditionPanel.addSubPanel(form);

		// 搜索按钮栏
		ButtonBarPanel bbp = new ButtonBarPanel(P_MAIN_BTN);
		p.addSubPanel(bbp);
		bbp.setAlign(Align.center);
		bbp.setStyleClass("bd-onlybottom  bd-title");
		bbp.setCellspacing(10);
		bbp.setDirectionVertical(true);

		// 列表显示
		GridPanel grid = new GridPanel(P_MAIN_GRID);
		grid.setNobr(true);
		grid.setStyleClass("grid-odd");
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("margin:10px;margin-bottom:0;border:1px solid #B7CBE3;");
		grid.setRowHeight(40);

		GridPanel secondGrid = new GridPanel(P_SECOND_GRID);
		secondGrid.setNobr(true);
		secondGrid.setStyleClass("grid-odd");
		secondGrid.setFace(GridPanelPubInfo.FACE_CELL);
		secondGrid.getPub().setHeaderClass("handle_grid_head");
		secondGrid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		secondGrid.setHighlightMouseover(true);
		secondGrid
				.setStyle("margin:10px;margin-bottom:0;border:1px solid #B7CBE3;");
		secondGrid.setRowHeight(40);

		vp = new VerticalPanel(P_MAIN_ROOT, firstPanelHeight + ","
				+ secondPanelHeight + "," + thireePanelHeight + ","
				+ secondGridPanelHeight + "," + fourPanelHeight);
		vp.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;
		vp.addSubPanel(p);// 搜索栏
		// 按钮栏
		if (isSpecialBtnPanel) {// 中间按钮特殊处理，可以带表单等。
			HorizontalPanel centerhp = new HorizontalPanel(
					ViewTemplateControlRoom.P_MAIN_CENTER_BTN, "*");
			centerhp.setStyle("background-color:#dfeafa");
			vp.addSubPanel(centerhp);
		} else {// 正常按钮栏
			ButtonBarPanel centerBtn = new ButtonBarPanel(
					ViewTemplateControlRoom.P_MAIN_CENTER_BTN);
			centerBtn.setStyle("padding-left:5px;background-color:#dfeafa");
			centerBtn.setAlign(Align.left);
			centerBtn.setCellspacing(10);
			vp.addSubPanel(centerBtn);// 按钮
		}
		vp.addSubPanel(grid);// 表格
		vp.addSubPanel(secondGrid);// 表格

		FlowPanel hp = new FlowPanel(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		hp.setDirection("h");
		vp.addSubPanel(hp);
		view.addSubPanel(vp);
		return view;
	}
	
	/**
	 * 上部统计信息GridPanel，下部显示具体信息GridPanel 黄国海 2017-01-10
	 * 
	 * @param isSpecialBtnPanel
	 * @return
	 */
	public static BaseView buildIndexStatView(boolean isSpecialBtnPanel) {
		BaseView view = new BaseView();
		VerticalPanel vp = null;// FIXME 搜索栏不能有175的高度
		String firstPanelHeight = "40";// 搜索栏默认高度
		String secondPanelHeight = "29%";// 按钮栏默认高度
		String thireePanelHeight = "40";// 表格栏默认高度
		String secondGridPanelHeight = "*";// 表格栏默认高度
		String fourPanelHeight = "45";// 翻页栏默认高度
		// 统计栏
		ButtonBarPanel stat = new ButtonBarPanel(P_STAT_BTN);
		stat.setAlign(Align.center);
		stat.setStyleClass("bd-onlybottom  bd-title");
		stat.setCellspacing(10);
		

		// 列表显示
		GridPanel grid = new GridPanel(P_MAIN_GRID);
		grid.setNobr(true);
		grid.setStyleClass("grid-odd");
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		grid.setStyle("margin:0px;margin-bottom:0;border:1px solid #B7CBE3;");
		grid.setRowHeight(30);

		// 新建栏    查询详细信息
		ButtonBarPanel detail = new ButtonBarPanel(P_DETAIL_BTN);
		detail.setAlign(Align.center);
		detail.setStyleClass("bd-onlybottom  bd-title");
		detail.setCellspacing(10);
		
		GridPanel secondGrid = new GridPanel(P_SECOND_GRID);
		secondGrid.setNobr(true);
		secondGrid.setStyle("background-color:#E9F2F7");
		secondGrid.setFace(GridPanelPubInfo.FACE_CELL);
		secondGrid.getPub().setHeaderClass("handle_grid_head");
		secondGrid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		secondGrid.setHighlightMouseover(true);
		secondGrid
				.setStyle("margin:0px;margin-bottom:0;border:1px solid #B7CBE3;");
		secondGrid.setRowHeight(33);

		vp = new VerticalPanel(P_MAIN_ROOT, firstPanelHeight + ","
				+ secondPanelHeight + "," + thireePanelHeight + ","
				+ secondGridPanelHeight + "," + fourPanelHeight);
		vp.setStyle("border:1px solid #B7CBE3;background-color:white;");// border-radius:5px;
		
		

		FlowPanel hp = new FlowPanel(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		hp.setDirection("h");
		
		vp.addSubPanel(stat);
		vp.addSubPanel(grid);
		vp.addSubPanel(detail);
		vp.addSubPanel(secondGrid);
		vp.addSubPanel(hp);
		view.addSubPanel(vp);
		return view;
	}

	public static FlowPanel getPagePlusPanel(Page page, List<Object[]> data,
			String clk) {
		FlowPanel hp = new FlowPanel(ViewTemplateControlRoom.P_MAIN_LEFT_PAGE);
		hp.setDirection("h");
		HtmlPanel htmlPanel = new HtmlPanel("", "页码：" + page.getCurrentPage()
				+ "/" + page.getPageCount() + " 记录：" + data.size() + "/"
				+ page.getRowCount() + "");
		htmlPanel.setStyle("margin:8px 15px 0 10px;");
		hp.addSubPanel(htmlPanel).addSubPanel(
				getPagePanel(page, data, clk).setFace(PagePanel.FACE_DEFAULT)
						.setAlign(Align.left));
		return hp;
	}

	public static PagePanel getPagePanel(Page page, List<Object[]> data,
			String clk) {
		PagePanel pagePanel = Constants.getPagePanel();
		pagePanel.setShowInfo(true);
		pagePanel.setFace(PagePanel.FACE_OFFICE);
		pagePanel.setCurrentPage(page.getCurrentPage());
		pagePanel.setCurrentRecords(data == null ? 0 : data.size());
		pagePanel.setMaxPage(page.getPageCount());
		pagePanel.setSumRecords(page.getRowCount());
		pagePanel.setStyle("margin:10px 15px 0 10px;");
		if (Utils.isEmpty(clk)) {
			pagePanel.setClk("VM(this).cmd('turnPage',$0);");
		} else {
			pagePanel.setClk(clk);
		}
		return pagePanel;
	}

	/**
	 * 构建报检表单界面
	 * 
	 * @return
	 */
	public static BaseView buildDeclFormView() {
		BaseView view = new BaseView();

		VerticalPanel popVP = new VerticalPanel(P_POP_ROOT, "*,45");
		view.setRootPanel(popVP);
		popVP.setStyleClass("bg-white");

		VerticalPanel contentVP = new VerticalPanel("contentVP", "40,*");
		contentVP.setStyleClass("bd-deep bd-notop bg-white");
		contentVP.setHorizontalMinus(2);
		contentVP.setVerticalMinus(1);
		popVP.addSubPanel(contentVP);

		ButtonBarPanel bbp = new ButtonBarPanel(P_MAIN_BTN);
		contentVP.addSubPanel(bbp);
		bbp.setStyleClass("bd-deep bd-onlytop");
		bbp.setStyle("padding-left:6px;background-color:#E8F0F8");//
		bbp.setFace(ButtonFace.group);

		VerticalPanel formContentVP = new VerticalPanel("formContentVP", "50,*");
		contentVP.addSubPanel(formContentVP);
		// formContentVP.setStyleClass("bg-form");

		// TAB
		ButtonBarPanel typeBBP = new ButtonBarPanel(P_MAIN_TAB_BTN);
		formContentVP.addSubPanel(typeBBP);
		typeBBP.setFace(ButtonFace.tab_mod);
		typeBBP.setBindFilmId(P_MAIN_FILM);
		typeBBP.setStyle("border:solid 1px #DDDDDD;margin:10px 10px 0 10px;border-bottom:none;");

		FilmPanel film = new FilmPanel(P_MAIN_FILM);
		film.setStyle("border-left:solid 1px rgb(221,221,221);border-bottom:solid 1px rgb(221,221,221);"
				+ "border-right:solid 1px rgb(221,221,221);margin:0 10px 10px 10px;");
		formContentVP.addSubPanel(film);

		ButtonBarPanel popOper = new ButtonBarPanel(P_POP_BTN);
		popVP.addSubPanel(popOper);
		popOper.setAlign(Align.right);
		popOper.setFace(ButtonFace.office);
		popOper.setStyleClass("d-foot bd-onlytop");
		popOper.setStyle("padding:0 12px;background:#D3E1EC");

		return view;

	}

	public static GridPanel buildPubGridPanel() {
		GridPanel grid = new GridPanel(P_MAIN_GRID);
		grid.getPub().setHeaderClass("query-background");
		grid.setRowHeight(30);
		grid.setFace(GridPanelPubInfo.FACE_CELL);
		grid.setStyleClass("lb");
		grid.setScroll(Scroll.miniscroll);
		grid.pub().setComboDeleteSignalField("ds");
		return grid;
	}

	public static ButtonBarPanel buildBtnPanel() {
		ButtonBarPanel bbp = new ButtonBarPanel(P_MAIN_BTN);
		bbp.setStyleClass("bd-deep bd-onlytop");
		bbp.setStyle("padding-left:6px;background-color:#E8F0F8");//
		bbp.setFace(ButtonFace.group);
		return bbp;
	}

	public static GridLayoutFormPanel buildPubGridLayoutFormPanel() {
		GridLayoutFormPanel form = new GridLayoutFormPanel(P_MAIN_FORM);
		form.setScroll(Scroll.miniscroll);
		form.setStyleClass("bg-white");
		form.setHighlightMouseover(false);
		form.setFace(GridPanelPubInfo.FACE_NONE);
		return form;
	}

}


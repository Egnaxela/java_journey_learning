package com.rongji.eciq.common.util;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import com.rongji.system.entity.SysUser;

public class BaseUtil {

	public static SysUser getSessionUser(HttpServletRequest request) {
		SysUser curUser = (SysUser) request.getSession().getAttribute(
				"loginUser");
		return curUser;
	}
	
	public static String uuid(){
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

}

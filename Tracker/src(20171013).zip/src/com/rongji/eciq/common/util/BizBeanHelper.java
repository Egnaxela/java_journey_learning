/*
 *File:BizBeanHelper.java
 *company:ECIQ
 *@version: 1.0
 *Date:2013-8-31
 */
package com.rongji.eciq.common.util;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

/**
 * 实体辅助类，简化设置实体值的工作
 * 
 * @author 王惠峰
 * @since 1.0
 */
public class BizBeanHelper {

	/**
	 * 自动为实体对象赋值，返回实体对象，request中的参数名称应该与实体的字段名称对应
	 * 
	 * @param <T>
	 * @param clazz
	 *            实体class对象
	 * @param request
	 * @return
	 */
	public static <T> T setBean(Class<T> clazz, HttpServletRequest request) {
		if (clazz == null || request == null)
			try {
				return clazz.newInstance();
			} catch (Exception e) {
				throw new RuntimeException("实例化类失败", e);
			}
		return setBeanValue(clazz, request);
	}

	/**
	 * 自动为实体对象赋值，返回实体对象，request中的参数名称应该与实体的字段名称对应
	 * 
	 * @param <T>
	 * @param clazz
	 *            实体class对象
	 * @param request
	 * @return
	 */
	private static <T> T setBeanValue(Class<T> clazz, HttpServletRequest request) {
		T t;
		try {
			t = clazz.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("实例化类失败", e);
		}
		Field[] fields = clazz.getDeclaredFields();
		if (fields == null || fields.length < 1) {
			return t;
		}
		String fieldName;// 字段名称
		String value;// request中字段的值
		for (Field field : fields) {
			fieldName = field.getName();// 获取字段名称
			value = request.getParameter(fieldName);
			if (value != null && !"".equals(value)) {
				field.setAccessible(true);// 设置字段权限为可进入
				try {
					setVaule(field, t, value);// 设置字段值
				} catch (Exception e) {
					throw new RuntimeException("设置字段值失败", e);
				}
			}
		}
		return t;
	}

	/**
	 * 根据字段的类型设置字段的值
	 * 
	 * @param field
	 *            字段对象
	 * @param t
	 *            实体对象
	 * @param value
	 *            值
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws ParseException
	 */
	private static void setVaule(Field field, Object t, String value)
			throws Exception {
		Class<?> type = field.getType();
		field.setAccessible(true);
		if (type == String.class) {
			field.set(t, value);
		}
		if (type == Date.class) {
			DateFormat df;
			if (value.contains(":")) {// 判断是否有时分秒
				df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			} else {
				df = new SimpleDateFormat("yyyy-MM-dd");
			}
			Date d = df.parse(value);
			field.set(t, d);
		}
		if (type == int.class || type == Integer.class) {
			field.setInt(t, Integer.parseInt(value));
			return;
		}
		if (type == Integer.class) {
			field.set(t, new Integer(Integer.parseInt(value)));
			return;
		}
		if (type == double.class) {
			field.setDouble(t, Double.parseDouble(value));
			return;
		}
		if (type == Double.class) {
			field.set(t, new Double(Double.parseDouble(value)));
			return;
		}
		if (type == float.class) {
			field.setFloat(t, Float.parseFloat(value));
		}
		if (type == Float.class) {
			field.set(t, new Float(Float.parseFloat(value)));
			return;
		}
		if (type == long.class) {
			field.setLong(t, Long.parseLong(value));
		}
		if (type == Long.class) {
			field.set(t, new Long(Long.parseLong(value)));
			return;
		}
		if (type == short.class) {
			field.setShort(t, Short.parseShort(value));
			return;
		}
		if (type == Short.class) {
			field.set(t, new Short(Short.parseShort(value)));
			return;
		}
		if (type == boolean.class) {
			field.setBoolean(t, Boolean.parseBoolean(value));
			return;
		}
		if (type == Boolean.class) {
			field.set(t, new Boolean(Boolean.parseBoolean(value)));
		}
		// 其他基本类型暂时不处理
	}
}

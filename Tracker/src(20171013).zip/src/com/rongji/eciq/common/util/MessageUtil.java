/**
 * 
 */
package com.rongji.eciq.common.util;

import java.util.Date;
import javax.annotation.Resource;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.util.Utils;
import com.rongji.system.entity.PubMessage;

/**
 * 
 * Description: 公共消息处理类
 * Copyright:   Copyright (c)2011  
 * Company:     榕基软件股份有限公司  
 * @author:     YSY  
 * @version:    1.0  
 * Create at:   2017-1-11 下午02:00:44  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-1-11   YSY      1.0         1.0 Version
 */
public class MessageUtil {
	
	@Resource(name="pubCommonDAO")
    protected PubCommonDAO pubCommonDAO;
    
    public PubCommonDAO getPubCommonDAO() {
		return pubCommonDAO;
	}

	public void setPubCommonDAO(PubCommonDAO pubCommonDAO) {
		this.pubCommonDAO = pubCommonDAO;
	}
	
	/**
	 * 
	* <p>描述:保存消息并返回消息ID</p>
	* @param pubMessage
	* @return
	* @author YSY
	 */
	public String savePubMessage(PubMessage pubMessage){
		String uuid=Utils.getuuid();
		pubMessage.setId(uuid);
		pubMessage.setSendDate(new Date());
		pubMessage.setStatus("0");
		pubCommonDAO.saveObject(pubMessage);
		return uuid;
	}

}

package com.rongji.eciq.common.util;

import java.util.UUID;

import com.rongji.dfish.commons.ViewTemplate;
import com.rongji.dfish.engines.xmltmpl.ButtonFace;
import com.rongji.dfish.engines.xmltmpl.Scroll;
import com.rongji.dfish.engines.xmltmpl.component.ButtonBarPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanel;
import com.rongji.dfish.engines.xmltmpl.component.GridPanelPubInfo;
import com.rongji.dfish.util.Utils;

/****
 * 风险处置公共方法类
 * Description:   
 * Copyright:   Copyright (c)2016 
 * Company:     rongji  
 * @author:     付晨雨  
 * @version:    1.0  
 * Create at:   2016-12-30 下午4:29:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2016-12-30   付晨雨     1.0         1.0 Version
 */
public class RiskConstants  extends  ViewTemplate{
	 
	/**
	 * 
	* <p>描述:按钮样式</p>
	* @return
	* @author 付晨雨
	 */
	public static void  setButtonBarPanelStyle(ButtonBarPanel btn) {
		btn.setStyleClass("bg-low");
		btn.setStyle("padding-right:6px;background-color:#FFFFFF;border-bottom:1px solid #B7CBE3;");
		btn.setFace(ButtonFace.group);
	}
	
	/**
	 * 
	* <p>描述:列表样式</p>
	* @param grid
	* @author 付晨雨
	 */
	public static void  setGridPanelStyle(GridPanel grid){
		grid.setStyleClass("grid-odd");
		grid.setNobr(true);
		grid.getPub().setHeaderClass("handle_grid_head");
		grid.getPub().setFocusType(GridPanelPubInfo.FOCUS_TYPE_ALWAYS);
		grid.setHighlightMouseover(true);
		//grid.setStyle("margin:0px;margin-bottom:0;border:0px solid #B7CBE3;");
		grid.setRowHeight(30);
		grid.setScroll(Scroll.scroll);
	}
	
	/**
	 * 
	* <p>描述:获取uuid</p>
	* @return
	* @author 付晨雨
	 */
	public static String getUuid(){
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	/**
	 * 
	* <p>描述:将数组转换为String </p>
	* @param is
	* @return
	* @author 付晨雨
	 */
	public static String  convertValue(String[] is){
		if(Utils.isEmpty(is)){
			return null;
		}
		String a=new String();
		for (String str : is) {
			a=a+str+",";
		}
		System.out.println(a);
		return a.substring(0, a.length()-1);
	}
	
	/**
	 * 
	* <p>描述:将String转换为String[] </p>
	* @param is
	* @return
	* @author 付晨雨
	 */
	public static String[]  convertValue(String ids){
		if(Utils.isEmpty(ids)){
			return null;
		}
		String[] list=ids.split(",");
		return list;
	}
}

package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspBasicReportRecordLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_BASIC_REPORT_RECORD_LOG")
public class DspBasicReportRecordLog implements java.io.Serializable {

	// Fields

	private String reportRecordLogId;
	private String reportRecordId;
	private Date operateDate;
	private String operatorId;
	private String reportStatus;
	private String reportType;
	// Constructors

	/** default constructor */
	public DspBasicReportRecordLog() {
	}

	/** minimal constructor */
	public DspBasicReportRecordLog(String reportRecordLogId) {
		this.reportRecordLogId = reportRecordLogId;
	}

	/** full constructor */
	public DspBasicReportRecordLog(String reportRecordLogId,
			String reportRecordId,String operatorId,Date operateDate, String reportStatus,String reportType) {
		this.reportRecordLogId = reportRecordLogId;
		this.reportRecordId = reportRecordId;
		this.operatorId = operatorId;
		this.operateDate = operateDate;
		this.reportStatus = reportStatus;
		this.reportType=reportType;
	}

	// Property accessors
	@Id
	@Column(name = "REPORT_RECORD_LOG_ID", unique = true, nullable = false, length = 50)
	public String getReportRecordLogId() {
		return this.reportRecordLogId;
	}

	public void setReportRecordLogId(String reportRecordLogId) {
		this.reportRecordLogId = reportRecordLogId;
	}

	@Column(name = "REPORT_RECORD_ID", length = 50)
	public String getReportRecordId() {
		return this.reportRecordId;
	}

	public void setReportRecordId(String reportRecordId) {
		this.reportRecordId = reportRecordId;
	}

	@Column(name = "REPORT_STATUS", length = 1)
	public String getReportStatus() {
		return this.reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	@Column(name = "REPORT_TYPE", length = 20)
	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPERATE_DATE", length = 7)
	public Date getOperateDate() {
		return operateDate;
	}

	public void setOperateDate(Date operateDate) {
		this.operateDate = operateDate;
	}
	
	@Column(name = "OPERATOR_ID", length = 50)
	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

}
package com.rongji.eciq.entity;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DspFileAttach entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_FILE_ATTACH")
public class DspFileAttach implements java.io.Serializable {

	// Fields

	private String fileAttachId;
	private String fileName;
	private String fileExt;
	private BigDecimal fileSize;
	private String fileId;

	// Constructors

	/** default constructor */
	public DspFileAttach() {
	}

	/** minimal constructor */
	public DspFileAttach(String fileAttachId) {
		this.fileAttachId = fileAttachId;
	}

	/** full constructor */
	public DspFileAttach(String fileAttachId, String fileName, String fileExt,
			BigDecimal fileSize, String fileId) {
		this.fileAttachId = fileAttachId;
		this.fileName = fileName;
		this.fileExt = fileExt;
		this.fileSize = fileSize;
		this.fileId = fileId;
	}

	// Property accessors
	@Id
	@Column(name = "FILE_ATTACH_ID", unique = true, nullable = false, length = 100)
	public String getFileAttachId() {
		return this.fileAttachId;
	}

	public void setFileAttachId(String fileAttachId) {
		this.fileAttachId = fileAttachId;
	}

	@Column(name = "FILE_NAME", length = 400)
	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Column(name = "FILE_EXT", length = 10)
	public String getFileExt() {
		return this.fileExt;
	}

	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}

	@Column(name = "FILE_SIZE", precision = 22, scale = 0)
	public BigDecimal getFileSize() {
		return this.fileSize;
	}

	public void setFileSize(BigDecimal fileSize) {
		this.fileSize = fileSize;
	}

	@Column(name = "FILE_ID", length = 64)
	public String getFileId() {
		return this.fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

}
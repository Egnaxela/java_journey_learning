package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspFileManage entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_FILE_MANAGE")
public class DspFileManage implements java.io.Serializable {

	// Fields

	private String fileManageId;
	private String fileId;
	private String fileContent;
	private Date operTime;
	private String fileBizStyle;
	private String bizId;
	private String userId;

	// Constructors

	/** default constructor */
	public DspFileManage() {
	}

	/** minimal constructor */
	public DspFileManage(String fileManageId, String fileId) {
		this.fileManageId = fileManageId;
		this.fileId = fileId;
	}

	/** full constructor */
	public DspFileManage(String fileManageId, String fileId,
			String fileContent, Date operTime, String fileBizStyle,
			String bizId, String userId) {
		this.fileManageId = fileManageId;
		this.fileId = fileId;
		this.fileContent = fileContent;
		this.operTime = operTime;
		this.fileBizStyle = fileBizStyle;
		this.bizId = bizId;
		this.userId = userId;
	}

	// Property accessors
	@Id
	@Column(name = "FILE_MANAGE_ID", unique = true, nullable = false, length = 32)
	public String getFileManageId() {
		return this.fileManageId;
	}

	public void setFileManageId(String fileManageId) {
		this.fileManageId = fileManageId;
	}

	@Column(name = "FILE_ID", nullable = false, length = 64)
	public String getFileId() {
		return this.fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	@Column(name = "FILE_CONTENT", length = 200)
	public String getFileContent() {
		return this.fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FILE_BIZ_STYLE", length = 2)
	public String getFileBizStyle() {
		return this.fileBizStyle;
	}

	public void setFileBizStyle(String fileBizStyle) {
		this.fileBizStyle = fileBizStyle;
	}

	@Column(name = "BIZ_ID", length = 50)
	public String getBizId() {
		return this.bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}

	@Column(name = "USER_ID", length = 32)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
package com.rongji.eciq.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspFileTemplate entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_FILE_TEMPLATE")
public class DspFileTemplate implements java.io.Serializable {

	// Fields

	private String templateFileId;
	private String templateType;
	private String bizId;
	private String templateName;
	private String templateQuan;
	private Date uploadDate;

	// Constructors

	/** default constructor */
	public DspFileTemplate() {
	}

	/** minimal constructor */
	public DspFileTemplate(String templateFileId) {
		this.templateFileId = templateFileId;
	}

	/** full constructor */
	public DspFileTemplate(String templateFileId, String templateType,
			String bizId,String templateName,String templateQuan) {
		this.templateFileId = templateFileId;
		this.templateType = templateType;
		this.bizId = bizId;
		this.templateName = templateName;
		this.templateQuan = templateQuan;
	}

	// Property accessors
	@Id
	@Column(name = "TEMPLATE_FILE_ID", unique = true, nullable = false, length = 40)
	public String getTemplateFileId() {
		return this.templateFileId;
	}

	public void setTemplateFileId(String templateFileId) {
		this.templateFileId = templateFileId;
	}

	@Column(name = "TEMPLATE_TYPE", length = 10)
	public String getTemplateType() {
		return this.templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	@Column(name = "BIZ_ID", length = 40)
	public String getBizId() {
		return this.bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}
	@Column(name = "TEMPLATE_NAME", length = 40)
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	@Column(name = "TEMPLATE_QUAN", length = 3)
	public String getTemplateQuan() {
		return templateQuan;
	}

	public void setTemplateQuan(String templateQuan) {
		this.templateQuan = templateQuan;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPLOAD_DATE", length = 7)
	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

}
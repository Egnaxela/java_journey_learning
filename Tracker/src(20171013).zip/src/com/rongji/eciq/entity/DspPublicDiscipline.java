package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspPublicDiscipline entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_PUBLIC_DISCIPLINE")
public class DspPublicDiscipline implements java.io.Serializable {

	// Fields

	private String disciplineId;
	private String attachmentId;
	private String disciplineContent;
	private Date operTime;
	private Short keepTime;
	private String title;
	private String disciplineType;
	private String sendUser;
	private Date operationTime;
	private String sendStatus;
	private String describeContent;

	// Constructors

	/** default constructor */
	public DspPublicDiscipline() {
	}

	/** minimal constructor */
	public DspPublicDiscipline(String disciplineId) {
		this.disciplineId = disciplineId;
	}

	/** full constructor */
	public DspPublicDiscipline(String disciplineId, String attachmentId,
			String disciplineContent, Date operTime, Short keepTime,
			String title, String disciplineType, String sendUser,
			Date operationTime,String sendStatus, String describeContent) {
		this.disciplineId = disciplineId;
		this.attachmentId = attachmentId;
		this.disciplineContent = disciplineContent;
		this.operTime = operTime;
		this.keepTime = keepTime;
		this.title = title;
		this.disciplineType = disciplineType;
		this.sendUser = sendUser;
		this.operationTime = operationTime;
		this.sendStatus = sendStatus;
		this.describeContent = describeContent;
	}

	// Property accessors
	@Id
	@Column(name = "DISCIPLINE_ID", unique = true, nullable = false, length = 32)
	public String getDisciplineId() {
		return this.disciplineId;
	}

	public void setDisciplineId(String disciplineId) {
		this.disciplineId = disciplineId;
	}

	@Column(name = "ATTACHMENT_ID", length = 32)
	public String getAttachmentId() {
		return this.attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	@Column(name = "DISCIPLINE_CONTENT")
	public String getDisciplineContent() {
		return this.disciplineContent;
	}

	public void setDisciplineContent(String disciplineContent) {
		this.disciplineContent = disciplineContent;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "KEEP_TIME", precision = 4, scale = 0)
	public Short getKeepTime() {
		return this.keepTime;
	}

	public void setKeepTime(Short keepTime) {
		this.keepTime = keepTime;
	}

	@Column(name = "TITLE", length = 200)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "DISCIPLINE_TYPE", length = 1)
	public String getDisciplineType() {
		return this.disciplineType;
	}

	public void setDisciplineType(String disciplineType) {
		this.disciplineType = disciplineType;
	}

	@Column(name = "SEND_USER", length = 32)
	public String getSendUser() {
		return this.sendUser;
	}

	public void setSendUser(String sendUser) {
		this.sendUser = sendUser;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPERATION_TIME", length = 7)
	public Date getOperationTime() {
		return this.operationTime;
	}

	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}

	@Column(name = "DESCRIBE_CONTENT")
	public String getDescribeContent() {
		return this.describeContent;
	}

	public void setDescribeContent(String describeContent) {
		this.describeContent = describeContent;
	}
	@Column(name = "SEND_STATUS", length = 1)
	public String getSendStatus() {
		return this.sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
}
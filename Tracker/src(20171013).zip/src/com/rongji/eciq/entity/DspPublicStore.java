package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspPublicStore entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_PUBLIC_STORE", schema = "ECIQ_DISP")
public class DspPublicStore implements java.io.Serializable {

	// Fields

	private String disciplineStoreId;
	private Date operationTime;
	private Short keepTime;
	private String title;
	private String storyPersonId;

	// Constructors

	/** default constructor */
	public DspPublicStore() {
	}

	/** minimal constructor */
	public DspPublicStore(String disciplineStoreId) {
		this.disciplineStoreId = disciplineStoreId;
	}

	/** full constructor */
	public DspPublicStore(String disciplineStoreId, Date operationTime,
			Short keepTime, String title, String storyPersonId) {
		this.disciplineStoreId = disciplineStoreId;
		this.operationTime = operationTime;
		this.keepTime = keepTime;
		this.title = title;
		this.storyPersonId = storyPersonId;
	}

	// Property accessors
	@Id
	@Column(name = "DISCIPLINE_STORE_ID", unique = true, nullable = false, length = 32)
	public String getDisciplineStoreId() {
		return this.disciplineStoreId;
	}

	public void setDisciplineStoreId(String disciplineStoreId) {
		this.disciplineStoreId = disciplineStoreId;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPERATION_TIME", length = 7)
	public Date getOperationTime() {
		return this.operationTime;
	}

	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}

	@Column(name = "KEEP_TIME", precision = 4, scale = 0)
	public Short getKeepTime() {
		return this.keepTime;
	}

	public void setKeepTime(Short keepTime) {
		this.keepTime = keepTime;
	}

	@Column(name = "TITLE", length = 50)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "STORY_PERSON_ID", length = 20)
	public String getStoryPersonId() {
		return this.storyPersonId;
	}

	public void setStoryPersonId(String storyPersonId) {
		this.storyPersonId = storyPersonId;
	}

}
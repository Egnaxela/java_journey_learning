package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspPublicStudy entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_PUBLIC_STUDY")
public class DspPublicStudy implements java.io.Serializable {

	// Fields

	private String studyId;
	private String pureStudyContent;
	private String sendUser;
	private Date operTime;
	private String title;
	private String studyTime;
	private Date operationTime;
	private String sendStatus;
	private Date endTime;

	// Constructors

	/** default constructor */
	public DspPublicStudy() {
	}

	/** minimal constructor */
	public DspPublicStudy(String studyId) {
		this.studyId = studyId;
	}

	/** full constructor */
	public DspPublicStudy(String studyId, String pureStudyContent,
			String sendUser, Date operTime, String title, String studyTime,
			Date operationTime, String sendStatus, Date endTime) {
		this.studyId = studyId;
		this.pureStudyContent = pureStudyContent;
		this.sendUser = sendUser;
		this.operTime = operTime;
		this.title = title;
		this.studyTime = studyTime;
		this.operationTime = operationTime;
		this.sendStatus = sendStatus;
		this.endTime = endTime;
	}

	// Property accessors
	@Id
	@Column(name = "STUDY_ID", unique = true, nullable = false, length = 32)
	public String getStudyId() {
		return this.studyId;
	}

	public void setStudyId(String studyId) {
		this.studyId = studyId;
	}

	@Column(name = "PURE_STUDY_CONTENT")
	public String getPureStudyContent() {
		return this.pureStudyContent;
	}

	public void setPureStudyContent(String pureStudyContent) {
		this.pureStudyContent = pureStudyContent;
	}

	@Column(name = "SEND_USER", length = 20)
	public String getSendUser() {
		return this.sendUser;
	}

	public void setSendUser(String sendUser) {
		this.sendUser = sendUser;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "TITLE", length = 200)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "STUDY_TIME", length = 10)
	public String getStudyTime() {
		return this.studyTime;
	}

	public void setStudyTime(String studyTime) {
		this.studyTime = studyTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPERATION_TIME", length = 7)
	public Date getOperationTime() {
		return this.operationTime;
	}

	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}

	@Column(name = "SEND_STATUS", length = 1)
	public String getSendStatus() {
		return this.sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_TIME", length = 7)
	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

}
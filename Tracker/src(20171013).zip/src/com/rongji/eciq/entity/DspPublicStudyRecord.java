package com.rongji.eciq.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspPublicStudyRecord entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_PUBLIC_STUDY_RECORD")
public class DspPublicStudyRecord implements java.io.Serializable {

	// Fields

	private String recordId;
	private String pureStudyId;
	private Date startTime;
	private Date endTime;
	private String userCode;
	private String deptNo;
	private Date operTime;
	private String title;
	private String studyStatus;
	private String studySchedule;
	private BigDecimal studyTime;

	// Constructors

	/** default constructor */
	public DspPublicStudyRecord() {
	}

	/** minimal constructor */
	public DspPublicStudyRecord(String recordId) {
		this.recordId = recordId;
	}

	/** full constructor */
	public DspPublicStudyRecord(String recordId, String pureStudyId,
			Date startTime, Date endTime, String userCode, String deptNo,
			Date operTime, String title, String studyStatus,
			String studySchedule, BigDecimal studyTime) {
		this.recordId = recordId;
		this.pureStudyId = pureStudyId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.userCode = userCode;
		this.deptNo = deptNo;
		this.operTime = operTime;
		this.title = title;
		this.studyStatus = studyStatus;
		this.studySchedule = studySchedule;
		this.studyTime = studyTime;
	}

	// Property accessors
	@Id
	@Column(name = "RECORD_ID", unique = true, nullable = false, length = 32)
	public String getRecordId() {
		return this.recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	@Column(name = "PURE_STUDY_ID", length = 32)
	public String getPureStudyId() {
		return this.pureStudyId;
	}

	public void setPureStudyId(String pureStudyId) {
		this.pureStudyId = pureStudyId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "START_TIME", length = 7)
	public Date getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_TIME", length = 7)
	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Column(name = "USER_CODE", length = 20)
	public String getUserCode() {
		return this.userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	@Column(name = "DEPT_NO", length = 10)
	public String getDeptNo() {
		return this.deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "TITLE", length = 200)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "STUDY_STATUS", length = 10)
	public String getStudyStatus() {
		return this.studyStatus;
	}

	public void setStudyStatus(String studyStatus) {
		this.studyStatus = studyStatus;
	}

	@Column(name = "STUDY_SCHEDULE", length = 10)
	public String getStudySchedule() {
		return this.studySchedule;
	}

	public void setStudySchedule(String studySchedule) {
		this.studySchedule = studySchedule;
	}

	@Column(name = "STUDY_TIME", precision = 22, scale = 0)
	public BigDecimal getStudyTime() {
		return this.studyTime;
	}

	public void setStudyTime(BigDecimal studyTime) {
		this.studyTime = studyTime;
	}

}
package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspPublicWork entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_PUBLIC_WORK", schema = "ECIQ_DISP")
public class DspPublicWork implements java.io.Serializable {

	// Fields

	private String workId;
	private String workCommId;
	private String attachmentId;
	private String workConten;
	private Date operTime;
	private String title;
	private Date recTime;
	private Date processTime;
	private String processReq;
	private String describeCon;
	private Date describeTime;
	private String processCon;
	private String type;
	private String recDept;
	private String describePerson;
	private String inputPerson;
	private String revirePerson;
	private String nameTitle;

	// Constructors

	/** default constructor */
	public DspPublicWork() {
	}

	/** minimal constructor */
	public DspPublicWork(String workId) {
		this.workId = workId;
	}

	/** full constructor */
	public DspPublicWork(String workId, String workCommId, String attachmentId,
			String workConten, Date operTime, String title, Date recTime,
			Date processTime, String processReq, String describeCon,
			Date describeTime, String processCon, String type, String recDept,
			String describePerson, String inputPerson, String revirePerson,
			String nameTitle) {
		this.workId = workId;
		this.workCommId = workCommId;
		this.attachmentId = attachmentId;
		this.workConten = workConten;
		this.operTime = operTime;
		this.title = title;
		this.recTime = recTime;
		this.processTime = processTime;
		this.processReq = processReq;
		this.describeCon = describeCon;
		this.describeTime = describeTime;
		this.processCon = processCon;
		this.type = type;
		this.recDept = recDept;
		this.describePerson = describePerson;
		this.inputPerson = inputPerson;
		this.revirePerson = revirePerson;
		this.nameTitle = nameTitle;
	}

	// Property accessors
	@Id
	@Column(name = "WORK_ID", unique = true, nullable = false, length = 36)
	public String getWorkId() {
		return this.workId;
	}

	public void setWorkId(String workId) {
		this.workId = workId;
	}

	@Column(name = "WORK_COMM_ID", length = 32)
	public String getWorkCommId() {
		return this.workCommId;
	}

	public void setWorkCommId(String workCommId) {
		this.workCommId = workCommId;
	}

	@Column(name = "ATTACHMENT_ID", length = 32)
	public String getAttachmentId() {
		return this.attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	@Column(name = "WORK_CONTEN")
	public String getWorkConten() {
		return this.workConten;
	}

	public void setWorkConten(String workConten) {
		this.workConten = workConten;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "TITLE", length = 200)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REC_TIME", length = 7)
	public Date getRecTime() {
		return this.recTime;
	}

	public void setRecTime(Date recTime) {
		this.recTime = recTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PROCESS_TIME", length = 7)
	public Date getProcessTime() {
		return this.processTime;
	}

	public void setProcessTime(Date processTime) {
		this.processTime = processTime;
	}

	@Column(name = "PROCESS_REQ")
	public String getProcessReq() {
		return this.processReq;
	}

	public void setProcessReq(String processReq) {
		this.processReq = processReq;
	}

	@Column(name = "DESCRIBE_CON")
	public String getDescribeCon() {
		return this.describeCon;
	}

	public void setDescribeCon(String describeCon) {
		this.describeCon = describeCon;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DESCRIBE_TIME", length = 7)
	public Date getDescribeTime() {
		return this.describeTime;
	}

	public void setDescribeTime(Date describeTime) {
		this.describeTime = describeTime;
	}

	@Column(name = "PROCESS_CON")
	public String getProcessCon() {
		return this.processCon;
	}

	public void setProcessCon(String processCon) {
		this.processCon = processCon;
	}

	@Column(name = "TYPE")
	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name = "REC_DEPT", length = 32)
	public String getRecDept() {
		return this.recDept;
	}

	public void setRecDept(String recDept) {
		this.recDept = recDept;
	}

	@Column(name = "DESCRIBE_PERSON")
	public String getDescribePerson() {
		return this.describePerson;
	}

	public void setDescribePerson(String describePerson) {
		this.describePerson = describePerson;
	}

	@Column(name = "INPUT_PERSON", length = 32)
	public String getInputPerson() {
		return this.inputPerson;
	}

	public void setInputPerson(String inputPerson) {
		this.inputPerson = inputPerson;
	}

	@Column(name = "REVIRE_PERSON", length = 32)
	public String getRevirePerson() {
		return this.revirePerson;
	}

	public void setRevirePerson(String revirePerson) {
		this.revirePerson = revirePerson;
	}

	@Column(name = "NAME_TITLE", length = 100)
	public String getNameTitle() {
		return this.nameTitle;
	}

	public void setNameTitle(String nameTitle) {
		this.nameTitle = nameTitle;
	}

}
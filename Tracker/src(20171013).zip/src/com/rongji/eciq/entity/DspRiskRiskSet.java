package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * DspRiskRiskSet entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_RISK_RISK_SET")
public class DspRiskRiskSet implements java.io.Serializable {

	// Fields

	private String riskId;
	private String appId;
	private String ruleId;
	private String modelId;
	private String riskName;
	private String riskContent;
	private String orgCode;
	private String riskUnit;
	private String riskLevel;
	private String riskSource;
	private Date reportTime;
	private Date uptoDate;
	private String operPer;
	private Date operDate;
	private String riskStatus;
	private String auditBasis;
	private String auditPer;
	private Date auditTime;
	private String handlePer;
	private Date handleDate;
	private String handleContent;
	private String appSign;
	private String manageCont;
	private String manageResult;
	private String managePer;
	private Date manageDate;

	// Constructors

	/** default constructor */
	public DspRiskRiskSet() {
	}

	/** minimal constructor */
	public DspRiskRiskSet(String riskId) {
		this.riskId = riskId;
	}

	/** full constructor */
	public DspRiskRiskSet(String riskId, String appId, String ruleId,
			String modelId, String riskName, String riskContent,
			String orgCode, String riskUnit, String riskLevel,
			String riskSource, Date reportTime, Date uptoDate, String operPer,
			Date operDate, String riskStatus, String auditBasis,
			String auditPer, Date auditTime, String handlePer, Date handleDate,
			String handleContent, String appSign, String manageCont,
			String manageResult, String managePer, Date manageDate) {
		this.riskId = riskId;
		this.appId = appId;
		this.ruleId = ruleId;
		this.modelId = modelId;
		this.riskName = riskName;
		this.riskContent = riskContent;
		this.orgCode = orgCode;
		this.riskUnit = riskUnit;
		this.riskLevel = riskLevel;
		this.riskSource = riskSource;
		this.reportTime = reportTime;
		this.uptoDate = uptoDate;
		this.operPer = operPer;
		this.operDate = operDate;
		this.riskStatus = riskStatus;
		this.auditBasis = auditBasis;
		this.auditPer = auditPer;
		this.auditTime = auditTime;
		this.handlePer = handlePer;
		this.handleDate = handleDate;
		this.handleContent = handleContent;
		this.appSign = appSign;
		this.manageCont = manageCont;
		this.manageResult = manageResult;
		this.managePer = managePer;
		this.manageDate = manageDate;
	}

	// Property accessors
	@Id
	@Column(name = "RISK_ID", unique = true, nullable = false, length = 32)
	public String getRiskId() {
		return this.riskId;
	}

	public void setRiskId(String riskId) {
		this.riskId = riskId;
	}

	@Column(name = "APP_ID", length = 32)
	public String getAppId() {
		return this.appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Column(name = "RULE_ID", length = 32)
	public String getRuleId() {
		return this.ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	@Column(name = "MODEL_ID", length = 32)
	public String getModelId() {
		return this.modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	@Column(name = "RISK_NAME", length = 200)
	public String getRiskName() {
		return this.riskName;
	}

	public void setRiskName(String riskName) {
		this.riskName = riskName;
	}

	@Column(name = "RISK_CONTENT", length = 3000)
	public String getRiskContent() {
		return this.riskContent;
	}

	public void setRiskContent(String riskContent) {
		this.riskContent = riskContent;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "RISK_UNIT", length = 50)
	public String getRiskUnit() {
		return this.riskUnit;
	}

	public void setRiskUnit(String riskUnit) {
		this.riskUnit = riskUnit;
	}

	@Column(name = "RISK_LEVEL", length = 1)
	public String getRiskLevel() {
		return this.riskLevel;
	}

	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	@Column(name = "RISK_SOURCE", length = 2)
	public String getRiskSource() {
		return this.riskSource;
	}

	public void setRiskSource(String riskSource) {
		this.riskSource = riskSource;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "REPORT_TIME", length = 7)
	public Date getReportTime() {
		return this.reportTime;
	}

	public void setReportTime(Date reportTime) {
		this.reportTime = reportTime;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "UPTO_DATE", length = 7)
	public Date getUptoDate() {
		return this.uptoDate;
	}

	public void setUptoDate(Date uptoDate) {
		this.uptoDate = uptoDate;
	}

	@Column(name = "OPER_PER", length = 30)
	public String getOperPer() {
		return this.operPer;
	}

	public void setOperPer(String operPer) {
		this.operPer = operPer;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_DATE", length = 7)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "RISK_STATUS", length = 2)
	public String getRiskStatus() {
		return this.riskStatus;
	}

	public void setRiskStatus(String riskStatus) {
		this.riskStatus = riskStatus;
	}

	@Column(name = "AUDIT_BASIS", length = 200)
	public String getAuditBasis() {
		return this.auditBasis;
	}

	public void setAuditBasis(String auditBasis) {
		this.auditBasis = auditBasis;
	}

	@Column(name = "AUDIT_PER", length = 30)
	public String getAuditPer() {
		return this.auditPer;
	}

	public void setAuditPer(String auditPer) {
		this.auditPer = auditPer;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "AUDIT_TIME", length = 7)
	public Date getAuditTime() {
		return this.auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	@Column(name = "HANDLE_PER", length = 32)
	public String getHandlePer() {
		return this.handlePer;
	}

	public void setHandlePer(String handlePer) {
		this.handlePer = handlePer;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "HANDLE_DATE", length = 7)
	public Date getHandleDate() {
		return this.handleDate;
	}

	public void setHandleDate(Date handleDate) {
		this.handleDate = handleDate;
	}

	@Column(name = "HANDLE_CONTENT", length = 1000)
	public String getHandleContent() {
		return this.handleContent;
	}

	public void setHandleContent(String handleContent) {
		this.handleContent = handleContent;
	}

	@Column(name = "APP_SIGN", length = 30)
	public String getAppSign() {
		return this.appSign;
	}

	public void setAppSign(String appSign) {
		this.appSign = appSign;
	}

	@Column(name = "MANAGE_CONT")
	public String getManageCont() {
		return this.manageCont;
	}

	public void setManageCont(String manageCont) {
		this.manageCont = manageCont;
	}

	@Column(name = "MANAGE_RESULT")
	public String getManageResult() {
		return this.manageResult;
	}

	public void setManageResult(String manageResult) {
		this.manageResult = manageResult;
	}

	@Column(name = "MANAGE_PER", length = 50)
	public String getManagePer() {
		return this.managePer;
	}

	public void setManagePer(String managePer) {
		this.managePer = managePer;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MANAGE_DATE", length = 7)
	public Date getManageDate() {
		return this.manageDate;
	}

	public void setManageDate(Date manageDate) {
		this.manageDate = manageDate;
	}

}
package com.rongji.eciq.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * DspWorkSuver entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSP_WORK_SUVER")
public class DspWorkSuver implements java.io.Serializable {

	// Fields

	private String surveyId;//通知表id
	private String extraId;//附件id
	private String surName;//名称
	private String surNum;//编号
	private String surPer;//录入人
	private String surDept;//录入部门
	private Date surTime;//录入时间
	private String surCont;//录入内容
	private String recDept;//接收部门
	private Date endTime;//截止时间
	private String checkPer;//审核人
	private Date checkTime;//审核时间
	private String checkCont;//审核内容
	private String checkState;//审核状态
	

	private String receivePer;//转办接收者
	private String havePaper;
	private String modId;//功能模块ID
//	surveyId,extraId,surName,surNum,surPer,surDept,surTime
//	surCont,recDept,endTime,checkPer,checkTime,checkCont,checkState,havaPaper
	

	/**
	 * 展示字段与存储无关
	 */
	@Transient
	private String surPerName;
	// Constructors
	@Transient
	public String getSurPerName() {
		return surPerName;
	}

	public void setSurPerName(String surPerName) {
		this.surPerName = surPerName;
	}

	/** default constructor */
	public DspWorkSuver() {
	}

	/** minimal constructor */
	public DspWorkSuver(String surveyId) {
		this.surveyId = surveyId;
	}

	/** full constructor */
	public DspWorkSuver(String surveyId, String extraId, String surName,
			String surNum, String surPer, String surDept, Date surTime,
			String surCont, String recDept, Date endTime, String checkPer,
			Date checkTime, String checkCont, String checkState ,String receivePer,String havePaper,String modId) {
		this.surveyId = surveyId;
		this.extraId = extraId;
		this.surName = surName;
		this.surNum = surNum;
		this.surPer = surPer;
		this.surDept = surDept;
		this.surTime = surTime;
		this.surCont = surCont;
		this.recDept = recDept;
		this.endTime = endTime;
		this.checkPer = checkPer;
		this.checkTime = checkTime;
		this.checkCont = checkCont;
		this.checkState = checkState;
		this.receivePer = receivePer;
		this.havePaper=havePaper;
		this.modId=modId;
	}

	// Property accessors
	@Id
	@Column(name = "SURVEY_ID", unique = true, nullable = false, length = 32)
	public String getSurveyId() {
		return this.surveyId;
	}

	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	@Column(name = "EXTRA_ID", length = 32)
	public String getExtraId() {
		return this.extraId;
	}

	public void setExtraId(String extraId) {
		this.extraId = extraId;
	}

	@Column(name = "SUR_NAME", length = 30)
	public String getSurName() {
		return this.surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	@Column(name = "SUR_NUM", length = 20)
	public String getSurNum() {
		return this.surNum;
	}

	public void setSurNum(String surNum) {
		this.surNum = surNum;
	}

	@Column(name = "SUR_PER", length = 100)
	public String getSurPer() {
		return this.surPer;
	}

	public void setSurPer(String surPer) {
		this.surPer = surPer;
	}

	@Column(name = "SUR_DEPT", length = 100)
	public String getSurDept() {
		return this.surDept;
	}

	public void setSurDept(String surDept) {
		this.surDept = surDept;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SUR_TIME", length = 7)
	public Date getSurTime() {
		return this.surTime;
	}

	public void setSurTime(Date surTime) {
		this.surTime = surTime;
	}

	@Column(name = "SUR_CONT")
	public String getSurCont() {
		return this.surCont;
	}

	public void setSurCont(String surCont) {
		this.surCont = surCont;
	}

	@Column(name = "REC_DEPT", length = 500)
	public String getRecDept() {
		return this.recDept;
	}

	public void setRecDept(String recDept) {
		this.recDept = recDept;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "END_TIME", length = 7)
	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Column(name = "CHECK_PER", length = 100)
	public String getCheckPer() {
		return this.checkPer;
	}

	public void setCheckPer(String checkPer) {
		this.checkPer = checkPer;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CHECK_TIME", length = 7)
	public Date getCheckTime() {
		return this.checkTime;
	}

	public void setCheckTime(Date checkTime) {
		this.checkTime = checkTime;
	}

	@Column(name = "CHECK_CONT")
	public String getCheckCont() {
		return this.checkCont;
	}

	public void setCheckCont(String checkCont) {
		this.checkCont = checkCont;
	}

	@Column(name = "CHECK_STATE", length = 30)
	public String getCheckState() {
		return this.checkState;
	}

	public void setCheckState(String checkState) {
		this.checkState = checkState;
	}

	@Column(name = "RECEIVE_PER", length = 10)
	public String getReceivePer() {
		return this.receivePer;
	}

	public void setReceivePer(String receivePer) {
		this.receivePer = receivePer;
	}
	@Column(name = "HAVE_PAPER", length = 2)
	public String getHavePaper() {
		return havePaper;
	}

	public void setHavePaper(String havePaper) {
		this.havePaper = havePaper;
	}
	@Column(name = "MOD_ID", length = 30)
	public String getModId() {
		return modId;
	}

	public void setModId(String modId) {
		this.modId = modId;
	}
}
package com.rongji.eciq.entity;


// default package

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * EciqExceptionLog entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ECIQ_EXCEPTION_LOG")
public class EciqExceptionLog implements java.io.Serializable {

	// Fields

	
	private static final long serialVersionUID = 3140217976690354581L;
	private String logId;
	private String logUser;
	private String logContent;
	private Date logTime;
	private String logUrl;
	private String logParam;
	private String logIp;

	// Constructors

	/** default constructor */
	public EciqExceptionLog() {
	}

	/** minimal constructor */
	public EciqExceptionLog(String logId) {
		this.logId = logId;
	}

	/** full constructor */
	public EciqExceptionLog(String logId, String logUser, String logContent,
			Date logTime, String logUrl, String logParam, String logIp) {
		this.logId = logId;
		this.logUser = logUser;
		this.logContent = logContent;
		this.logTime = logTime;
		this.logUrl = logUrl;
		this.logParam = logParam;
		this.logIp = logIp;
	}

	// Property accessors
	@Id
	@Column(name = "LOG_ID", unique = true, nullable = false, length = 32)
	public String getLogId() {
		return this.logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}
	
	@Column(name = "LOG_USER", length = 32)
	public String getLogUser() {
		return this.logUser;
	}

	public void setLogUser(String logUser) {
		this.logUser = logUser;
	}
	
	@Column(name = "LOG_CONTENT")
	public String getLogContent() {
		return this.logContent;
	}

	public void setLogContent(String logContent) {
		this.logContent = logContent;
	}
	
	@Column(name = "LOG_TIME")
	public Date getLogTime() {
		return this.logTime;
	}

	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}
	
	@Column(name = "LOG_URL", length = 200)
	public String getLogUrl() {
		return this.logUrl;
	}

	public void setLogUrl(String logUrl) {
		this.logUrl = logUrl;
	}
	
	@Column(name = "LOG_PARAM", length = 500)
	public String getLogParam() {
		return this.logParam;
	}

	public void setLogParam(String logParam) {
		this.logParam = logParam;
	}
	
	@Column(name = "LOG_IP", length = 32)
	public String getLogIp() {
		return this.logIp;
	}

	public void setLogIp(String logIp) {
		this.logIp = logIp;
	}

}
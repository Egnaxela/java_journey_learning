/**  
 * FileName:  	 CommContext.java   
 * @Description: 本类为通用基础定值编码类   
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年3月24日 下午16:41:15  
 *  
 */  
package com.rongji.eciq.mobile.context;

/**
 * 
 * Description: 本类为通用基础定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年3月24日 下午16:41:15  
 *  
 * Modification History:  
 * Date          Author      Version      Description  
 * ------------------------------------------------------------------  
 * 2017-04-20    李晨阳                   1.0          添加综合评定结论基础编码
 * 2017-05-05    魏波                       1.0          增加报检单流程环节、状态、报检类别代码转名称
 * 2017-05-05    才江男                   1.0          审核环节编码
 * 2017-05-15    魏波                        1.0          添加所需单证基础代码
 * 2017-06-28    李云龙                   1.0          添加查验预约申请，受理基础代码
 */
public class CommContext {

    /**
     * [是：1]编码
     */
    public static final String Y = "1";
    /**
     * [否：0]编码
     */
    public static final String N = "0";
    
    /**
     * [出入境施检-报检单管理表-流程状态-主施检]编码
     */
    public static final String FLOW_PATH_STATUS_MAIN = "800";
    /**
     * [出入境施检-报检单管理表-流程状态-主施检]名称
     */
    public static final String FLOW_PATH_STATUS_MAIN_NAME = "主施检";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检]编码
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY = "801";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检]名称
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_NAME = "辅施检";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检完成]编码
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_DONE = "802";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检完成]名称
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_DONE_NAME = "辅施检完成";
    
    /**
     * [出入境施检-分单状态-已分单]编码
     */
    public static final String SUBMENU_TYPE_YET_SUB = "0";
    /**
     * [出入境施检-分单状态-已分单]名称
     */
    public static final String SUBMENU_TYPE_YET_SUB_NAME = "已分单";
    /**
     * [出入境施检-分单状态-未分单]编码
     */
    public static final String SUBMENU_TYPE_NOT_SUB = "1";
    /**
     * [出入境施检-分单状态-未分单]名称
     */
    public static final String SUBMENU_TYPE_NOT_SUB_NAME = "未分单";
    
    /**
     * [出入境施检-检验要求-需送检]编码
     */
    public static final String TEST_REQUIRE_SENDCHECK = "0";
    /**
     * [出入境施检-检验要求-需送检]名称
     */
    public static final String TEST_REQUIRE_SENDCHECK_NAME = "需送检";
    /**
     * [出入境施检-检验要求-需查验]编码
     */
    public static final String TEST_REQUIRE_EXAMINE = "1";
    /**
     * [出入境施检-检验要求-需查验]名称
     */
    public static final String TEST_REQUIRE_EXAMINE_NAME = "需查验";
    /**
     * [出入境施检-检验要求-需查验送检]编码
     */
    public static final String TEST_REQUIRE_SEDCHK_AND_EXAMINE = "2";
    /**
     * [出入境施检-检验要求-需查验送检]名称
     */
    public static final String TEST_REQUIRE_SEDCHK_AND_EXAMINE_NAME = "需查验送检";
    
    
    /**
     * 施检待办事项
     */
    public static String SUBOR = "1";
    public static String CHECK = "2";
    public static String SCENE = "3";
    public static String SDLAB = "4";
    public static String EVALU = "5";
    public static String QULIF = "6";
    public static String UNQUF = "7";
    public static String ACCRE = "8";
    
    //分单功能类型
    public static final String SUB_TYPE = "1";
    //审单功能类型
    public static final String AUDIT_TYPE = "2";
    
    /**
     * [监督管理-归档标志-未归档]编码
     */
    public static final String SUP_ARCHIVE_N = "0";
    /**
     * [监督管理-归档标志-未归档]名称
     */
    public static final String SUP_ARCHIVE_N_NAME = "未归档";
    /**
     * [监督管理-归档标志-已归档]编码
     */
    public static final String SUP_ARCHIVE_Y = "1";
    /**
     * [监督管理-归档标志-已归档]名称
     */
    public static final String SUP_ARCHIVE_Y_NAME = "已归档";
    
    /**
     * [分单改派单主施检退单]编码
     */
    public static final String SUB_MAIN_BACK = "1";
    /**
     * [分单改派单主施检退单]名称
     */
    public static final String SUB_MAIN_BACK_NAME = "分单改派单主施检退单";
    /**
     * [分单改派单辅施检退单]编码
     */
    public static final String SUB_AUXILIARY_BACK = "2";
    /**
     * [分单改派单辅施检退单]名称
     */
    public static final String SUB_AUXILIARY_BACK_NAME = "分单改派单辅施检退单";
    /**
     * [施检员审单主施检退单]编码
     */
    public static final String AUDIT_MAIN_BACK = "3";
    /**
     * [施检员审单主施检退单]名称
     */
    public static final String AUDIT_MAIN_BACK_NAME = "施检员审单主施检退单";
    /**
     * [施检员审单辅施检退单]编码
     */
    public static final String AUDIT_AUXILIARY_BACK = "4";
    /**
     * [施检员审单辅施检退单]名称
     */
    public static final String AUDIT_AUXILIARY_BACK_NAME = "施检员审单辅施检退单";
    /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_PACK_BACK = "5";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_PACK_BACK_NAME = "包装施检结果登记退单";
    /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_PACK_SUB_BACK = "6";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_PACK_SUB_BACK_NAME = "包装施检分单改派退单";
     /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_CARG_SUB_BACK = "7";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_CARG_SUB_BACK_NAME = "适载检验分单改派退单";
    
    /**
     * [是：1]编码
     */
    public static final String Y_1 = "1";
    public static final String Y_1_NAME = "是";
    /**
     * [否：0]编码
     */
    public static final String N_0 = "0";
    public static final String N_0_NAME = "否";
    
    
    /**
     * *****************环节定义 开始*******************
     */
    /**
     * 退单
     */
    public static final String BACK_DECL = "01";
    /**
     * 手工报检
     */
    public static final String SELF_DECL = "10";
    /**
     * 机审
     */
    public static final String AUTO_DECL = "11";
    /**
     * 人审
     */
    public static final String SELF_CHECK = "12";
    /**
     * 报检受理
     */
    public static final String DECL = "13";
    /**
     * 分单
     */
    public static final String SUBMENU = "14";
    /**
     * 施检审单
     */
    public static final String INS = "15";
    /**
     * 现场查验
     */
    public static final String SPOT = "16";
    /**
     * 送检
     */
    public static final String SEND = "17";
    /**
     * 综合评定
     */
    public static final String EVALUATE = "18";
    /**
     * 不合格
     */
    public static final String UNQULIFIED = "19";
    /**
     * 合格
     */
    public static final String QULIFIED = "20";
    /**
     * 拟稿
     */
    public static final String DRAFT = "21";
    /**
     * 核签
     */
    public static final String ATTESTATION = "22";
    /**
     * 收单
     */
    public static final String ACQUIR = "23";
    /**
     * 复审
     */
    public static final String RECHECK = "24";
    /**
     * 缮制
     */
    public static final String MAKE = "25";
    /**
     * 审校
     */
    public static final String VERIFY = "26";
    /**
     * 签发
     */
    public static final String SIGN = "27";
    /**
     * 归档
     */
    public static final String DOC = "28";
    /**
     * 归档解除
     */
    public static final String CANCEL_DOC = "29";
    /**
     * 通关
     */
    public static final String CUST_CLEARANCE = "30";
    /**
     * 放行
     */
    public static final String PASS = "98";
    /**
     * 计收费
     */
    public static final String CHARG = "99";
    /**
     * 结果登记
     */
    public static final String RESULT = "316";
    
    /**
     * 现场记录
     */
    public static final String SCE_RECORD = "40";
    
    public static final String SCE_RECORD_NAME = "现场记录";
    public static final String BACK_DECL_NAME = "退单";
    public static final String SELF_DECL_NAME = "手工报检";
    public static final String AUTO_DECL_NAME = "机审";
    public static final String SELF_CHECK_NAME = "人审";
    public static final String DECL_NAME = "报检受理";
    public static final String SUBMENU_NAME = "分单";
    public static final String INS_NAME = "施检审单";
    public static final String SPOT_NAME = "现场查验";
    public static final String SEND_NAME = "送检";
    public static final String EVALUATE_NAME = "综合评定";
    public static final String UNQULIFIED_NAME = "不合格处理";
    public static final String QULIFIED_NAME = "合格处理";
    public static final String DRAFT_NAME = "拟稿";
    public static final String ATTESTATION_NAME = "核签";
    public static final String ACQUIR_NAME = "收单";
    public static final String RECHECK_NAME = "复审";
    public static final String MAKE_NAME = "缮制";
    public static final String VERIFY_NAME = "审校";
    public static final String SIGN_NAME = "签发";
    public static final String DOC_NAME = "归档";
    public static final String CANCEL_DOC_NAME = "归档解除";
    public static final String CUST_CLEARANCE_NAME = "通关";
    public static final String PASS_NAME = "放行";
    public static final String CHARG_NAME = "计收费";
    public static final String RESULT_NAME = "结果登记";
    /**
     * *****************环节定义 结束*******************
     */
    /**
     * *****************状态定义 开始*******************
     */
    /**
     * H号退单
     */
    public static final String H_BACK = "1001";
    /**
     * 临时保存
     */
    public static final String TMP_SAVE = "1002";
    /**
     * 待机审
     */
    public static final String WAIT_AOTU_CHECK = "1003";
    /**
     * 退单
     */
    public static final String DECL_BACK = "1004";
    /**
     * 待人审
     */
    public static final String WAIT_SELF_CHECK = "1005";
    /**
     * 待受理
     */
    public static final String WAIT_DECL = "1006";
    /**
     * 待施检
     */
    public static final String WAIT_INS = "1007";
    /**
     * 待卫技反馈
     */
    public static final String WAIT_HEALTH = "1008";
    /**
     * 受理退回
     */
    public static final String ACC_RETURN = "1009";
    /**
     * 审单调回
     */
    public static final String DECL_RETURN = "1010";
    /**
     * E号退单(企业报检退单)
     */
    public static final String E_BACK = "1011";
    /**
     * 施检退回
     */
    public static final String INS_BACK = "1012";
    /**
     * 已调回(后续施检、签证环节被调回时修改成此状态)
     */
    public static final String DECL_RETURNED = "1013";
    /**
     * 施检审单退回
     */
    public static final String INS_CHECK_BACK = "1014";
    /**
     * 审单异常
     */
    public static final String INS_EXCEPTION = "1015";
    /**
     * 人工干预
     */
    public static final String MANUAL_INTERVENTION = "1016";
    /**
     * 抽批抽中
     */
    public static final String PUMP_GROUP = "1017";
    /**
     * 待施检审单
     */
    public static final String WAIT_INS_CHECK = "1018";
    /**
     * 待查验
     */
    public static final String WAIT_CHECK = "1019";
    /**
     * 已查验
     */
    public static final String CHECKED = "1020";
    /**
     * 已抽样
     */
    public static final String HAVE_SAMPLE = "1021";
    /**
     * 已送检
     */
    public static final String SUBMIT = "1022";
    /**
     * 综合评定合格
     */
    public static final String VER_APP_Y = "1023";
    /**
     * 综合评定不合格
     */
    public static final String VER_APP_N = "1024";
    /**
     * 待拟制
     */
    public static final String WAIT_FICTION = "1025";
    /**
     * 待核签
     */
    public static final String WAIT_ATTESTATION = "1026";
    /**
     * 待收单
     */
    public static final String WAIT_ACQUIR = "1027";
    /**
     * 待复审
     */
    public static final String WAIT_RECHECK = "1028";
    /**
     * 待缮制
     */
    public static final String WAIT_MAKE = "1029";
    /**
     * 待审校
     */
    public static final String WAIT_VERIFY = "1030";
    /**
     * 待签发
     */
    public static final String WAIT_SIGN = "1031";
    /**
     * 待归档(直接放行)(非法检)（调放行接口）
     */
    public static final String WAIT_DOC = "1032";
    /**
     * 已归档
     */
    public static final String DOCUMENTED = "1033";
    /**
     * 已归档、归档解除审核通过
     */
    public static final String CANCEL_DOC_S = "1034";
    /**
     * 已通关
     */
    public static final String CUST_CLEARANCE_S = "1035";
    /**
     * 待人工评定
     */
    public static final String SELF_CHECK_S = "1036";
    /**
     * 待授权综合评定
     */
    public static final String MUTI_CHECK = "1037";
    /**
     * 施检程序异常
     */
    public static final String INS_ERR = "1038";
    /**
     * 不合格处理放行
     */
    public static final String DISQUR_RELEAS = "1039";
    /**
     * 移入历史库
     */
    public static final String HISTORY_LIBRARY = "1041";
    /**
     * [报检单状态-已撤单]编号
     */
    public static final String REVOKED_DECL = "2010";
    /**
     * [报检单状态-报检改派]编号
     */
    public static final String RESSIGNMENT_DECL = "2011";
    /**
     * 报检调回拦截异常
     */
    public static final String INS_SECOND_EXCEPTION = "2015";
    /**
     * [包装施检-报检单状态-已结果登记]编码
     */
    public static final String DECL_PACK_AD_REG = "3002";
    /**
     * [包装施检-报检单状态-未结果登记]编码
     */
    public static final String NO_DECL_PACK_AD_REG = "3001";
    /**
     * [包装施检-报检单状态-未结果登记]编码
     */
    public static final String DECL_PACK_AD_REG_BACK = "3003";
    
    /**
     * 更改申请
     */
    public static final String ACCEPT_CHANGE = "1040";
    public static final String TMP_SAVE_NAME = "临时保存";
    public static final String DECL_BACK_NAME = "退单";
    public static final String WAIT_DOC_NAME = "待归档";
    public static final String WAIT_SELF_CHECK_NAME = "待人审";
    public static final String WAIT_DECL_NAME = "待受理";
    public static final String WAIT_AOTU_CHECK_NAME = "待机审";
    public static final String WAIT_INS_NAME = "待施检";
    public static final String WAIT_HEALTH_NAME = "待卫技反馈";
    public static final String DECL_RETURN_NAME = "审单调回";
    public static final String H_BACK_NAME = "H号退单";
    public static final String E_BACK_NAME = "E号退单";
    public static final String ACC_RETURN_NAME = "受理退回";
    public static final String INS_BACK_NAME = "施检退回";
    public static final String DECL_RETURNED_NAME = "已调回";
    public static final String INS_CHECK_BACK_NAME = "施检审单退回";
    public static final String INS_EXCEPTION_NAME = "审单异常";
    public static final String MANUAL_INTERVENTION_NAME = "人工干预";
    public static final String PUMP_GROUP_NAME = "抽批抽中";
    public static final String WAIT_INS_CHECK_NAME = "待施检审单";
    public static final String WAIT_CHECK_NAME = "待查验";
    public static final String CHECKED_NAME = "已查验";
    public static final String HAVE_SAMPLE_NAME = "已抽样";
    public static final String SUBMIT_NAME = "已送检";
    public static final String VER_APP_Y_NAME = "综合评定合格";
    public static final String VER_APP_N_NAME = "综合评定不合格";
    public static final String WAIT_FICTION_NAME = "待拟制";
    public static final String WAIT_ATTESTATION_NAME = "待核签";
    public static final String WAIT_ACQUIR_NAME = "待收单";
    public static final String WAIT_RECHECK_NAME = "待复审";
    public static final String WAIT_MAKE_NAME = "待缮制";
    public static final String WAIT_VERIFY_NAME = "待审校";
    public static final String WAIT_SIGN_NAME = "待签发";
    public static final String DOCUMENTED_NAME = "已归档";
    public static final String CANCEL_DOC_S_NAME = "归档解除审核通过";
    public static final String CUST_CLEARANCE_S_NAME = "已通关";
    public static final String SELF_CHECK_S_NAME = "待人工评定";
    public static final String MUTI_CHECK_NAME = "待授权综合评定";
    public static final String INS_ERR_NAME = "施检程序异常";
    public static final String DISQUR_RELEAS_NAME = "不合格处理放行";
    public static final String ACCEPT_CHANGE_NAME = "更改申请";
    public static final String HISTORY_LIBRARY_NAME = "移入历史库";
    public static final String RESSIGNMENT_DECL_NAME = "报检改派";
    public static final String INS_SECOND_EXCEPTION_NAME = "报检调回拦截异常";
    public static final String REVOKED_DECL_NAME = "已撤单";
    public static final String DECL_PACK_AD_REG_NAME = "已结果登记";
    public static final String NO_DECL_PACK_AD_REG_NAME = "未结果登记";
    public static final String DECL_PACK_AD_REG_BACK_NAME = "结果登记退回";
    /**
     * *****************状态定义 结束*******************
     */
    
    /**
     * [归档标志-0:未归档]编码
     */
    public static final String ARCHIVE_0 = "0";
    /**
     * [归档标志-0:未归档]名称
     */
    public static final String ARCHIVE_0_NAME = "未归档";
    /**
     * [归档标志-1:已归档]编码
     */
    public static final String ARCHIVE_1 = "1";
    /**
     * [归档标志-1:已归档]名称
     */
    public static final String ARCHIVE_1_NAME = "已归档";
    
    /**
     * [进出口标志-出口]编码
     */
    public static final String OUT_FLAG = "2";
    /**
     * [进出口标志-出口]名称
     */
    public static final String OUT_FLAG_NAME = "出口";
    /**
     * [进出口标志-进口]编码
     */
    public static final String IN_FLAG = "1";
    /**
     * [进出口标志-进口]名称
     */
    public static final String IN_FLAG_NAME = "进口";
    
    /***************审单结果登记综合评定*****************/
    
    /**
     * [审单结果登记综合评定-不合格]编码
     */
    public static final String ASSESS_STATUS_BHG = "0";
    /**
     * [审单结果登记综合评定-不合格]名称
     */
    public static final String ASSESS_STATUS_BHG_NAME = "不合格";
    /**
     * [审单结果登记综合评定-合格]编码
     */
    public static final String ASSESS_STATUS_HG = "1";
    /**
     * [审单结果登记综合评定-合格]名称
     */
    public static final String ASSESS_STATUS_HG_NAME = "合格";
    /**
     * [审单结果登记综合评定-未评定]编码
     */
    public static final String ASSESS_STATUS_WPD = "2";
    /**
     * [审单结果登记综合评定-未评定]名称
     */
    public static final String ASSESS_STATUS_WPD_NAME = "未评定";
    
    
    
    /*********************报检类别********************/
    public static final String IN_TEST_QUE="13";
    public static final String IN_FLOW="14";
    public static final String IN_VALI="15";
    
    public static final String OUT_PRE="21";
    public static final String OUT_TEST_QUE="24";
    public static final String OUT_CHECK_CAR="25";
    public static final String OUT_VALI="28";
    
    public static final String IN_TEST_QUE_NAME="入境检验检疫";
    public static final String IN_FLOW_NAME="入境流向";
    public static final String IN_VALI_NAME="入境验证";
    
    public static final String OUT_PRE_NAME="出境预检";
    public static final String OUT_TEST_QUE_NAME="出境检验检疫";
    public static final String OUT_CHECK_CAR_NAME="出境核查货证";
    public static final String OUT_VALI_NAME="出境验证";
    
    /*********************现场查验审核环节********************/
    /**
     * 现场查验审核环节-施检员复审
     */
    public static final String AUDIT_INSP = "1";
    /**
     * 现场查验审核环节-施检员复审
     */
    public static final String AUDIT_INSP_NAME = "施检员复审";
    /**
     * 现场查验审核环节-科长审核
     */
    public static final String AUDIT_DEPT = "2";
    /**
     * 现场查验审核环节-科长审核
     */
    public static final String AUDIT_DEPT_NAME = "科长审核";
    /**
     * 现场查验审核环节-处长审核
     */
    public static final String AUDIT_SECT = "3";
    /**
     * 现场查验审核环节-处长审核
     */
    public static final String AUDIT_SECT_NAME = "处长审核";
    /**
     * 现场查验审核环节-审核完毕
     */
    public static final String AUDIT_DONE = "4";
    /**
     * 现场查验审核环节-审核完毕
     */
    public static final String AUDIT_DONE_NAME = "审核完毕";
    
    /*********************所需单证********************/
    
    /**
     * 所需单证-品质证书
     */
    public static final String QUALITE ="11";
    /**
     * 所需单证-品质证书
     */
    public static final String QUALITE_NAME ="品质证书";
    /**
     * 所需单证-重量证书
     */
    public static final String WEITHT ="12";
    /**
     * 所需单证-重量证书
     */
    public static final String WEITHT_NAME ="重量证书";
    /**
     * 所需单证-数量证书
     */
    public static final String NUM ="13";
    /**
     * 所需单证-数量证书
     */
    public static final String NUM_NAME ="数量证书";
    
    /**
     * 所需单证-兽医卫生证书
     */
    public static final String VET_HEAL ="14";
    /**
     * 所需单证-兽医卫生证书
     */
    public static final String VET_HEAL_NAME ="兽医卫生证书";
    /**
     * 所需单证-健康证书
     */
    public static final String HEAL ="15";
    /**
     * 所需单证-健康证书
     */
    public static final String HEAL_NAME ="健康证书";
    /**
     * 所需单证-卫生证书
     */
    public static final String HYGI ="16";
    /**
     * 所需单证-卫生证书
     */
    public static final String HYGI_NAME ="卫生证书";
    /**
     * 所需单证-动物卫生证书
     */
    public static final String ANIM ="17";
    /**
     * 所需单证-动物卫生证书
     */
    public static final String ANIM_NAME ="动物卫生证书";
    /**
     * 所需单证-植物检疫证书
     */
    public static final String PLANT ="18";
    /**
     * 所需单证-植物检疫证书
     */
    public static final String PLANT_NAME ="植物检疫证书";
    
    /**
     * 所需单证-熏蒸/消毒证书
     */
    public static final String STEA_DIS ="19";
    /**
     * 所需单证-熏蒸/消毒证书
     */
    public static final String STEA_DIS_NAME ="熏蒸/消毒证书";
    /**
     * 所需单证-出境货物换证凭单
     */
    public static final String OUT_GOODS ="20";
    /**
     * 所需单证-出境货物换证凭单
     */
    public static final String OUT_GOODS_NAME ="出境货物换证凭单";
    /**
     * 所需单证-熏蒸/消毒证书
     */
    public static final String IN_DECL ="21";
    /**
     * 所需单证-熏蒸/消毒证书
     */
    public static final String IN_DECL_NAME ="入境货物检验检疫证明";
    /**
     * 所需单证-出境货物不合格通知单
     */
    public static final String OUT_GOODS_N ="22";
    /**
     * 所需单证-出境货物不合格通知单
     */
    public static final String OUT_GOODS_N_NAME ="出境货物不合格通知单";
 

    /**
     * 所需单证-集装箱检验检疫结果单
     */
    public static final String CONT ="23";
    /**
     * 所需单证-集装箱检验检疫结果单
     */
    public static final String CONT_NAME ="集装箱检验检疫结果单";
    /**
     * 所需单证-通关单
     */
    public static final String PORT ="97";
    /**
     * 所需单证-通关单
     */
    public static final String PORT_NAME ="通关单";
    /**
     * 所需单证-其他单
     */
    public static final String ELSE ="98";
    /**
     * 所需单证-其他单
     */
    public static final String ELSE_NAME ="其他单";
    /**
     * 所需单证-其他证书
     */
    public static final String ELSE_DESC ="99";
    /**
     * 所需单证-其他证书
     */
    public static final String ELSE_DESC_NAME ="其他证书";
    
    
    /**
     * 复审开关标志
     */
    public static final String RECHECK_SWITCH="regiAudit";
    
}

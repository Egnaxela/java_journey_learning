/**  
 * FileName:  CommMsgContext.java   
 * @Description: 此类为通用消息异常定值编码类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月20日 上午10:02:08  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为通用消息异常定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月20日 上午10:02:08  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月20日      吴有根                      1.0         1.0 Version  
 */

public class CommMsgContext {
	 /**
     * 操作成功!
     */
    public static final String INFO_SUCC = "操作成功";
    /**
     * 操作失败!
     */
    public static final String INFO_FAILE = "操作失败";
    /**
     * 确认删除数据吗？
     */
    public static final String WIN_DELETE = "确认删除数据吗";
    /**
     * 确认删除数据吗？
     */
    public static final String WIN_DELETE_ALL = "确认删除该单号关联的所有数据吗";
    /**
     * 请选择要操作的记录！<br>用于操作检索结果时，未选中任何一条记录时的提示信息。
     */
    public static final String INFO_SELECT_ONE_RESULT = "请选择要操作的记录";
    
     /**
     * 请选择要操作的记录！<br>用于操作检索结果时，未选中任何一条记录时的提示信息。
     */
    public static final String INFO_SAMPLE_NUM_ERROR = "样品总量不能小于样品分组数量";

    /**
     * 请选择要操作的记录！<br>用于操作检索结果时，未选中任何一条记录时的提示信息。
     */
    public static final String FEE_COMPANY_ERROR = "企业注册号过长";
    /**
     * 只能选择一条记录！
     */
    public static final String ERR_SELECT_ONE_RESULT = "只能选择一条记录";
    /**
     * 开始日期不得大于结束日期，请修改后再进行操作！
     */
    public static final String ERR_START_BIG_THAN_END = "开始日期不得大于结束日期，请修改后再进行操作";
    /**
     * 开始日期不能为空！
     */
    public static final String ERR_START_IS_NOT_NULL = "开始日期不能为空";
    /**
     * 结束日期不能为空
     */
    public static final String ERR_END_IS_NOT_NULL = "结束日期不能为空";
    /**
     * %s日期不得小于当前日期！<br>参数：开始日期/结束日期
     */
    public static final String ERR_LITTLE_THAN_TODAY = "%s不得小于当前日期";
    /**
     * %s操作是否继续？<br>参数用于根据自身业务，提出前半段警告信息，如果没有则不填。
     */
    public static final String WIN_CONTINUE_OR_NOT = "%s操作是否继续";
    /**
     * 报检号为空值！
     */
    public static final String ERR_DECL_NULL = "报检号为空值";
    /**
     * 转单号为空值！
     */
    public static final String ERR_TRAN_NO_NULL = "转单号为空值";
    public static final String ERR_DECL_IS_NULL = "请选择要操作的报检单";
    /**
     * 报检号格式不正确，15位全号或者【X-XXXXXXX】短号！
     */
    public static final String ERR_DECL_LENGTH = "报检号格式不正确，15位全号或者【X-XXXXXXX】短号";
    /**
     * 报检号短号格式不正确，号码中间不得存在多个【-】！
     */
    public static final String ERR_DECL_STYLE = "报检号短号格式不正确，\n号码中间不得存在多个【-】";
    /**
     * 报检号前缀必须在('1','2','3','4','8')之内 !
     */
    public static final String ERR_DECL_FORMAT = "报检号前缀必须在('1','2','3','4','7','8')之内 ";
    /**
     * 报检号短号【-】右侧不得大于8位长度！
     */
    public static final String ERR_DECL_RIGHT_FORMAT = "报检号短号【-】右侧不得大于13位长度";
        /**
     * 报检号短号【-】右侧不得大于8位长度！
     */
    public static final String ERR_DECL_RIGHT_FORMAT_8 = "报检号短号【-】右侧不得大于8位长度";
    /**
     * 报检号由纯数字或者数字组合一个\"-\"、\"H\"、\"T\"、\"E\"、\"L\"、\"h\"、\"t\"、\"e\"、\"l\"字符构成，请检查格式！
     */
    public static final String ERR_DECL_CHAR_FORMAT = "报检号由纯数字或者数字和一个\n\"-\"、\"H\"、\"T\"、\"E\"、\"L\"、\"h\"、\"t\"、\"e\"、\"l\"\n字符构成，请检查格式";
    /**
     * 报检号中的字符必须出现在最后位置，请修改报检号输入条件！
     */
    public static final String ERR_DECL_CHAR_RIGHT_FORMAT = "报检号中的字符必须出现在最后位置，\n请修改报检号输入条件";
    /**
     * 报检号中的字母个数不得超过2个！
     */
    public static final String ERR_DECL_CHAR_SIZE = "报检号中的字母个数不得超过2个";
    /**
     * 查询条件不得为空！
     */
    public static final String ERR_QUERY = "至少有一个查询条件不得为空";
    /**
     * %s不能为空！
     */
    public static final String ERR_COMMON_BLANK = "%s不能为空";
    /**
     * 无查询结果！
     */
    public static final String ERR_QUERY_RESULT = "无查询结果";
    /**
     * %s重复，请重新输入！
     */
    public static final String ERR_REPEAT = "%s重复，请重新输入";
    /**
     * 本操作是不可恢复的，您确认要执行吗？
     */
    public static final String WIN_CANT_REC = "本操作是不可恢复的，您确认要执行吗";
    /**
     * 有未保存的数据，是否保存？
     */
    public static final String WIN_SURE_SAVE = "有未保存的数据，是否保存";
    /**
     * 没有要保存的数据！
     */
    public static final String INFO_NO_DATA_TO_SAVE = "没有要保存的数据";
    /**
     * 对象拷贝失败！
     */
    public static final String ERR_BEAN_COPE = "对象拷贝失败";
    /**
     * 导入文件失败！
     */
    public static final String ERR_IMPORT_FAIL = "导入文件失败";
    /**
     * 加锁失败提示信息
     */
    public static final String DECL_NO_LOCK_MSG = "该报检号已经被锁，操作人：%s，所属机构：%s，业务类别：%s";
    /**
     * 加锁失败提示信息
     */
    public static final String THIS_DECL_NO_LOCK_MSG = "【报检单号】:%s已经被锁; 【操作人】:%s; 【所属机构】:%s; 【业务类别】:%s";
    /**
     * 请选择文件
     */
    public static final String WARN_IMP_FILE_EMPTY = "请选择文件";
    /**
     * 成功导入数据，共X条
     */
    public static final String PROMPT_IMP_SUCC_ROWS = "已成功导入数据记录，共%s条";
    /**
     * 导入失败
     */
    public static final String PROMPT_IMP_FAIL_ROWS = "导入失败";
    /**
     * 没有导入数据
     */
    public static final String PROMPT_IMP_ROWS_ZERO = "没有可以被导入的数据";
    /**
     * 导入校验失败，提示信息的标题
     */
    public static final String ERR_IMP_INFOTITLE = "第%s行数据校验失败，原因如下:";
    /**
     * 系统异常！
     */
    public static final String ERR_SYSTEM = "系统异常，请联系系统管理员";
    public static final String ERR_SYS_PERSON_INFO = "当前操作人信息异常。";
    /**
     * 导入时出现异常！请检查配置或者导入文件 *
     */
    public static final String EXCEP_IMPORT = "导入时出现异常！请检查配置文件或者导入文件";

    public static final String QUALITY_NOT_ISS = "该通报信息已下发";
    
    public static final String FEBACK_WAIT="请选择待下发的通报信息";

    public static final String BRANCH_FEEBACK_ERROR = "该调查反馈信息已调查";
    /**
     * 加锁失败提示信息
     */
    public static final String DECL_NO_LOCK_MSG_NOMAL = "该数据已经被锁，操作人：%s，所属机构：%s。";

    /**
     * 针对报检号字段输入特出字符
     */
    public static final String DECL_NO_ERROR = "报检号只能是输入数字或者字母";

    /**
     * 选择的收费票据中缴费方式必须相同！
     */
    public static final String FEE_MAIN_PAY_ERROR = "选择的收费票据中缴费方式必须相同";
    /**
     * 操作成功!
     */
    public static final String INFO_REPORT_ALREADY = "该报检单已经上报，不能重复上报";

    /**
     * 确认删除所选数据吗？
     */
    public static final String CONFIRM_DELETE_SELECTED = "确认删除所选数据吗";
    /**
     * 确认废止选中模板吗？
     */
    public static final String CONFIRM_ABLISH = "确认废止选中模板吗";
    /**
     * 该生产批已送检，不能退单!
     */
    public static final String PROMPT_BATCH_CHECK = "该生产批已送检，不能退单";
    /**
     * 该生产批已监管完成，不能退单！
     */
    public static final String PROMPT_BATCH_OVER = "该生产批已监管完成，不能退单";
    /**
     * 该生产批已进行了现场查验，不能退单！
     */
    public static final String PROMPT_BATCH_HAVECHECK = "该生产批已进行了现场查验，不能退单";
    /**
     * 该生产批已报检，不能退单！
     */
    public static final String PROMPT_BATCH_DECL = "该生产批已报检，不能退单";

     /**
     * 归档管理--请先选择归档表再进行设置归档条件
     */
    public static final String PROMPT_SELECT_TABLE = "请先选择归档表再进行设置归档条件";

    /**
     * 报检号不存在
     */
    public static final String NOT_DECL_NO = "%s报检号没有对应的数据，请重新输入";
    
    /**
     * 注册备案-后续管理-事项维护-修改-该证书已核销，不能进行修改
     */
    public static final String NOT_CERT_EDIT = "该证书已核销，不能进行修改";
    
    /**
     * 系统管理-开关设置-批量维护-确定，请选择合适的开关或者机构
     */
    public static final String SELECT_RIGHT_ITEM = "请选择合适的开关或者机构";

}

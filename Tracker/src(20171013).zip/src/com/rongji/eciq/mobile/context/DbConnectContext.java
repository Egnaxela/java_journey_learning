/**  
 * FileName:  DbConnectContext.java   
 * @Description: 数据库连接相关基础配置&字符编码集  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午11:22:16  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 数据库连接相关基础配置&字符编码集  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午11:22:16  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version  
 */

public class DbConnectContext {
	//电子业务平台服务地址
	public static String address= "http://192.168.1.151:9080/eciq_service";
	
	//CA认证平台地址
	public static String host = "http://192.168.1.151:9080/eciq_cas/casTicketRequest";
	
	public static final String EONDING_GBK = "GBK";
	public static final String EONDING_GB2312 = "GBK";
	public static final String EONDING_UTF8 = "UTF-8";
}

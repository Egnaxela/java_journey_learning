
/**  
 * FileName: DeclContext.java   
 * @Description: 此类为审单受理基础定值编码类   
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月7日 下午14:50:16  
 *  
 */ 
package com.rongji.eciq.mobile.context;

/**
 * 
 * Description: 此类为审单受理基础定值编码类    
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月7日 下午14:50:16  
 *  
 * Modification History:  
 * Date          Author       Version       Description  
 * ------------------------------------------------------------------  
 * 2017-04-19    李云龙                      1.0             添加退回布控处理标识
 * 2017-05-15    才江男                      1.0             去掉！号
 */
public class DeclContext {
	/**
     * [抽样方案-传统百分比抽样方案]编码
     */
    public static final String SAMPLE_PLAN_PERCENT = "1";
    /**
     * [抽样方案-传统百分比抽样方案]名称
     */
    public static final String SAMPLE_PLAN_PERCENT_NAME = "传统百分比抽样方案";
    /**
     * [抽样方案-标准抽样方案]编码
     */
    public static final String SAMPLE_PLAN_STANDARD = "2";
    /**
     * [抽样方案-标准抽样方案]名称
     */
    public static final String SAMPLE_PLAN_STANDARD_NAME = "标准抽样方案";
    /**
     * [抽样方案-无需使用抽样方案]编码
     */
    public static final String SAMPLE_PLAN_NONE = "3";
    /**
     * [抽样方案-无需使用抽样方案]名称
     */
    public static final String SAMPLE_PLAN_NONE_NAME = "无需使用抽样方案";
    /**
     * [抽样方案-按产品间歇抽样]编码
     */
    public static final String SAMPLE_PLAN_PRODUCT = "4";
    /**
     * [抽样方案-按产品间歇抽样]名称
     */
    public static final String SAMPLE_PLAN_PRODUCT_NAME = "按产品间歇抽样";
    /**
     * [抽样方案-按时间抽样]编码
     */
    public static final String SAMPLE_PLAN_TIME = "5";
    /**
     * [抽样方案-按时间抽样]名称
     */
    public static final String SAMPLE_PLAN_TIME_NAME = "按时间抽样";
    /**
     * [抽样方案-自定义抽样方案]编码
     */
    public static final String SAMPLE_PLAN_CUSTOM = "6";
    /**
     * [抽样方案-自定义抽样方案]名称
     */
    public static final String SAMPLE_PLAN_CUSTOM_NAME = "自定义抽样方案";
    /**
     * [抽样方案-特定抽样方案]编码
     */
    public static final String SAMPLE_PLAN_SPECIAL = "7";
    /**
     * [抽样方案-特定抽样方案]名称
     */
    public static final String SAMPLE_PLAN_SPECIAL_NAME = "特定抽样方案";
    
    
    /**
     * 无纸化参数标识
     */
    public static final String PAPERLESS_URL_PARAM = "paperLess_url_param";
    
    /**
     * 请首先在系统参数中维护无纸化系统参数！
     */
    public static final String INFO_SET_PAPERLESS_PARAM = "请首先在系统参数中维护无纸化系统参数";
    
    /**
     * 非企业端上报报检信息无法查看无纸化信息！
     */
    public static final String INFO_NO_PAPERLESS = "非企业端上报报检信息无法查看无纸化信息";
    
    /**
     * [企业端出入境标识-入境报检]编码
     */
    public static final String ENT_DECL_TYPE_IN = "I";
    /**
     * [企业端出入境标识-入境报检]名称
     */
    public static final String ENT_DECL_TYPE_IN_NAME = "入境报检";
    /**
     * [企业端出入境标识-出境报检]编码
     */
    public static final String ENT_DECL_TYPE_OUT = "O";
    /**
     * [企业端出入境标识-出境报检]名称
     */
    public static final String ENT_DECL_TYPE_OUT_NAME = "出境报检";
    /**
     * [报检类别-入境报检]编码
     */
    public static final String DECL_TYPE_IN = "1";
    /**
     * [报检类别-入境报检]名称
     */
    public static final String DECL_TYPE_IN_NAME = "入境报检";
    /**
     * [报检类别-出境报检]编码
     */
    public static final String DECL_TYPE_OUT = "2";
    /**
     * [报检类别-出境报检]名称
     */
    public static final String DECL_TYPE_OUT_NAME = "出境报检";
    /**
     * [报检类别-出境包装报检]编码
     */
    public static final String DECL_TYPE_GOODS = "3";
    /**
     * [报检类别-出境包装报检]名称
     */
    public static final String DECL_TYPE_GOODS_NAME = "出境包装报检";
    /**
     * [报检类别-集装箱报检]编码
     */
    public static final String DECL_TYPE_CONTAINER = "4";
    /**
     * [报检类别-集装箱报检]名称
     */
    public static final String DECL_TYPE_CONTAINER_NAME = "集装箱报检";
    /**
     * [报检类别-邮寄物报检]编码
     */
    public static final String DECL_TYPE_MAIL = "5";
    /**
     * [报检类别-邮寄物报检]名称
     */
    public static final String DECL_TYPE_MAIL_NAME = "邮寄物报检";
    /**
     * [报检类别-旅客携带物报检]编码
     */
    public static final String DECL_TYPE_CARRY = "6";
    /**
     * [报检类别-旅客携带物报检]名称
     */
    public static final String DECL_TYPE_CARRY_NAME = "旅客携带物报检";
    /**
     * [报检类别-尸体棺柩报检]编码
     */
    public static final String DECL_TYPE_CORPSE = "7";
    /**
     * [报检类别-尸体棺柩报检]名称
     */
    public static final String DECL_TYPE_CORPSE_NAME = "尸体棺柩报检";
    /**
     * [报检类别-更改申请报检]编码
     */
    public static final String DECL_TYPE_CHANGE = "8";
    
    
    /**
     * [小于]编码
     */
    public static final String OPERATOR_LITTLETHAN_ID = "3";
    /**
     * [小于]名称
     */
    public static final String CHECK_LEVEL_L = "<";
    /**
     * [小于等于]编码
     */
    public static final String OPERATOR_LITTLETHANEQUAL_ID = "4";
    /**
     * [小于等于]名称
     */
    public static final String CHECK_LEVEL_L_E = "<=";
    /**
     * [大于]编码
     */
    public static final String OPERATOR_GREATTHAN_ID = "5";
    /**
     * [大于]名称
     */
    public static final String CHECK_LEVEL_H = ">";
    /**
     * [大于等于]编码
     */
    public static final String OPERATOR_GREATTHANEQUAL_ID = "6";
    /**
     * [大于等于]名称
     */
    public static final String CHECK_LEVEL_H_E = ">=";
    /**
     * [等于]编码
     */
    public static final String OPERATOR_EQUAL_ID = "1";
    /**
     * [等于]名称
     */
    public static final String CHECK_LEVEL_E = "=";
    
    /**
     * [状态-维护]编码
     */
    public static final String STATUS_EDIT = "1";
    /**
     * [状态-维护]名称
     */
    public static final String STATUS_EDIT_NAME = "维护";
    /**
     * [状态-已发布]编码
     */
    public static final String STATUS_PUBLISH = "2";
    /**
     * [状态-已发布]名称
     */
    public static final String STATUS_PUBLISH_NAME = "已发布";
    /**
     * [状态-已解除]编码
     */
    public static final String STATUS_RELIEVE = "3";
    /**
     * [状态-已解除]名称
     */
    public static final String STATUS_RELIEVE_NAME = "已解除";
    /**
     * [状态-审核通过]编码
     */
    public static final String STATUS_AUDIT = "4";
    /**
     * [状态-审核通过]名称
     */
    public static final String STATUS_AUDIT_NAME = "审核通过";
    /**
     * [状态-审核不通过]编码
     */
    public static final String STATUS_NO_AUDIT = "5";
    /**
     * [状态-审核不通过]名称
     */
    public static final String STATUS_NO_AUDIT_NAME = "审核不通过";
    /**
     * [状态-待审核]编码
     */
    public static final String STATUS_SBUMIT = "6";
    /**
     * [状态-待审核]名称
     */
    public static final String STATUS_SBUMIT_NAME = "待审核";
    
    /**
     * [退回布控处理标识-否]编码
     */
    public static final String JOINT_INSPECTION_CODE = "0";
    /**
     * [退回布控处理标识-否]名称
     */
    public static final String BACK_CONTROL_N_NAME = "否";
    /**
     * [退回布控处理标识-是]编码
     */
    public static final String BACK_CONTROL_Y = "1";
    
    /**
     * [施捡管理-现场查验-检验方式]编码
     */
    public static final String SELF_CHECKING_CODE = "1";
    
    /**
     * [退回布控处理标识-是]名称
     */
    public static final String SELF_CHECKING_NAME = "自检自验";
    
    /**
     * [施捡管理-现场查验-检验方式]编码
     */
    public static final String EXEMPTION_CODE = "2";
    /**
     * [施捡管理-现场查验-检验方式]名称
     */
    public static final String EXEMPTION_NAME = "免检";
}

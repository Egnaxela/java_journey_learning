/**  
 * FileName:   DeclevalConstants.java  
 * @Description: 此类为综合评定定值编码类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月19日 下午2:09:10  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为综合评定定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月19日 下午2:09:10  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月19日      吴有根                      1.0         1.0 Version  
 */

public class DeclevalConstants {
	
    //出入境标记：出境

    public static final String EXP_IMP_FALG_EXP = CommContext.OUT_FLAG;
    //出入境标记:入境
    public static final String EXP_IMP_FALG_IMP = CommContext.IN_FLAG;
    //出入境标记:出入境
    public static final String EXP_IMP_FALG_IMPEXP = CommContext.IN_FLAG
                                                     + CommContext.OUT_FLAG;
    public static final char COMMA = ',';
    public static final char VERTICAL = '/';
    public static final String COMMA_STR = ",";
    public static final String VERTICAL_STR = "/";
    //以下为报检单的施检状态
    // 审单异常
    public static final String INSP_STATE_AUDIT_EXCEPTION = CommContext.INS_EXCEPTION;
    // 等待人工干预
    public static final String INSP_STATE_WAIT_INTERVENTION = CommContext.MANUAL_INTERVENTION;
    //综合判定等待人工评定(非零缺陷不合格)
    public static final String INSP_STATE_WAIT_MANUAL_EVAL = CommContext.SELF_CHECK_S;
    // 综合判定合格
    public static final String INSP_STATE_EVALUATION_PASS = CommContext.VER_APP_Y;
    // 综合判定不合格
    public static final String INSP_STATE_PASS_FAIL = CommContext.VER_APP_N;
    //程序错误产生的异常
    public static final String INSP_STATE_EVALUATION_PROC_EXCEPTION = CommContext.INS_ERR;
    ;
    //电子抽批抽中
    public static final String INSP_STATE_LOT_RATION_SELECT = CommContext.PUMP_GROUP;
    //以下为报检单环节
    //环节:合格处理
    public static String LINK_EVAL_PASS = CommContext.QULIFIED;
    //环节：审单
    public static String LINK_AUDIT = CommContext.INS;
    //环节：分单
    public static String LINK_ASSIGN = CommContext.SUBMENU;
    //环节：综合评定
    public static String LINK_EVAL = CommContext.EVALUATE;
    //环节：不合格处理
    public static String LINK_EVAL_FAIL = CommContext.UNQULIFIED;
    //2011-6-22修改
    //保税货物出区核销
    public static final String BONDED_CANCEL_AFTER_VERIFICATION = "51";
    //报检单状态
    public static final String DECLBILL_STATUS_CIQ2000CALLBACK = "99";//CIQ2000调回的
    public static final String DECLBILL_STATUS_CIQ2000CANCEL = "97";//CIQ2000撤消的
    public static final String DECLBILL_STATUS_MANDECIDE = "90";
    public static final String DECLBILL_STATUS_BUSINESSSELFTEST = "100";//企业自检结果确认
    //待人工判定状态
    public static final String DECLBILL_STATUS_INSPMANDECIDE = "50";
    //报检单货物已送检(added by 2011-8-2)如果insp_decl_goods.is_send = "1",则此货物已送检
    public static final String GOOODS_IS_SEND = "1";
    //开关
    //人工综合评定合格后，是否需要经过审核后再放行
    public static final String SWITCH_PASS_NEED_AUDIT = "passNeedAudit";
    //如果开关打开,采用设置的人员进行回信，否则默认取CIQ的人员
    public static String SWITCH_EVAL_USER = "EVAL_USER";
    //单位类别
    public final static String UNIT_CAT_CODE_WEIGHT = "2";//数量类别为"重量"
    public final static String UNIT_CAT_CODE_QTY = "1";//数量类别为"数量"
    public final static String QTY_WEIGHT_UNIT_CODE = "3";//数量,重量
    //放行方式
    //2011-5-30新增入境电子检管放行状态 
    
    //入境企业自检-》对应于出境快速核放    
    public static final String DECLBILL_PASSED_MODE_IMP_ENT_QUICKLY = "A";
    //入境现场查验放行->查验放行
    public static final String DECLBILL_PASSED_MODE_IMP_INSPECTION = "B";
    //入境实验室检测放行->检验放行
    public static final String DECLBILL_PASSED_MODE_IMP_VERIFY_PASSED = "C";
    //入境组织检验放行->监管放行
    public static final String DECLBILL_PASSED_MODE_IMP_SUPERVISE = "D";
    //入境不合格处理->不合格处理放行
    public static final String DECLBILL_PASSED_MODE_IMP_DIS_PROC_PASSED = "E";//不合格处理放行
    //快速核放
    public static final String DECLBILL_PASSED_MODE_QUICKLY = "1";
    //监管放行
    public static final String DECLBILL_PASSED_MODE_SUPERVISE = "2";
    //查验放行
    public static final String DECLBILL_PASSED_MODE_INSPECTION = "3";
    //未放行
    public static final String DECLBILL_PASSED_MODE_NOT_PASSED = "4";
    //检验放行
    public static final String DECLBILL_PASSED_MODE_VERIFY_PASSED = "5";//检验放行
    public static final String DECLBILL_PASSED_MODE_DIS_PROC_PASSED = "6";//不合格处理放行
    public static final String DECLBILL_PASSED_MODE_DIS_PASSED = "7";//不准出口
    /**
     * 企业分类等级代码 10 一类企业，20 二类企业，30 三类企业，40 四类企业
     */
//    public static final String ENT_LEVEL_ONE = "10";
//    public static final String ENT_LEVEL_TWO = "20";
//    public static final String ENT_LEVEL_THREE = "30";
//    public static final String ENT_LEVEL_FOUR = "40";
    /**
     * 风险等级代码 3 高风险，2 较高风险，1 一般风险
     */
//    public static final String RiskLevel_HIGH = "3";
//    public static final String RiskLevel_LITTLE_HIGH = "2";
//    public static final String RiskLevel_NORMAL = "1";
    //报检单人工综合评定合格后待审核,如insp_decl_mag表的is_audit状态为1,则此报检单需要审核后放行
    public static final String DECLBILL_AUDIT_MODE_NEED_AUDIT = "1";
    /**
     * 日常监管方式代码 1 信用监管，2 验证监管，3 一般监管，4 严密监管，5 特别监管
     */
    public static final String SUP_WAY_TRUST = "1";
    public static final String SUP_WAY_CHECK = "2";
    public static final String SUP_WAY_NORMAL = "3";
    public static final String SUP_WAY_RIGOR = "4";
    public static final String SUP_WAY_SPECIAL = "5";
    /**
     * 填写结果状态 0 未填写，1 已填写
     */
    public static final String RESULT_STATE_NO = "0";
    public static final String RESULT_STATE_YES = "1";
    /**
     * 抽批检验结果 1 实施抽批检验，抽批检验评定结论合格 2 实施抽批检验，抽批检验评定结论不合格 3 不实施抽批检验
     */
    public static final String BATCH_RESULT_HIT_QUALI = "1";
    public static final String BATCH_RESULT_HIT_UNQUALI = "2";
    public static final String BATCH_RESULT_UNHIT = "3";
    /**
     * 核销类型
     */
    public final static String GO_TYPE_AUTO = "1";//自动核销
    public final static String GO_TYPE_MOD = "2";//手工核销
    //是否有效标记
    public final static String VALID_YES = "1";
    public final static String VALID_NO = "0";
    //有生产批模式
    public static final String PRODUCT_MODEL_HAS_BATCH = "1";
    //无生产批模式
    public static final String PRODUCT_MODEL_NO_BATCH = "2";
//    /*
//     * 初审异常的描述信息
//     * @author zhuweiming
//     *
//     */
//    public static final String AUDIT_EXCEPTION_RISK_ALARM = "1";//B类风险预警
//    public static final String AUDIT_EXCEPTION_IMPORTANT_INSP = "2";//重点监控
//    public static final String AUDIT_EXCEPTION_EXCEPTION_ORG = "3";//生产批监管异常(局端异常）
//    public static final String AUDIT_EXCEPTION_NEED_CERT = "7";//出证拦截
//    public static final String AUDIT_EXCEPTION_COUNTRY_CHANGE = "6";//出口国家改变
//    public static final String AUDIT_EXCEPTION_EXCEPTION_ENT = "4";//企业生产批异常（企业异常）
//    public static final String AUDIT_EXCEPTION_PRODUCTBATCH_LOT = "5";//生产批电子抽批抽中
//    public static final String AUDIT_EXCEPTION_NO_PERMIT = "8";//无产品许可
//    public static final String AUDIT_EXCEPTION_AUTO_LOT = "9";//电子抽批抽中
//    public static final String AUDIT_EXCEPTION_REACCESS_INTERCEPT = "REACCESS";//调回后修改重新进入的单子
//    public static final String AUDIT_EXCEPTION_OTHER = "Z";//其它异常
//    public static final String AUDIT_EXCEPTION_ENT_BASE_EXCEPT = "ZM";//监管名录没有企业和产品
//    public static final String AUDIT_EXCEPTION_CTRLFORM_INVALIDATE = "A";//监控项目表单不符
//    public static final String AUDIT_EXCEPTION_ITEM_PERIOD_INVALIDATE = "B";//项目超出有效期
//    public static final String AUDIT_EXCEPTION_ITEM_CENT_DECL = "C";//集报(深圳模式)
//    public static final String AUDIT_EXCEPTION_ORDER = "order_1";//布控拦截
//    public static final String AUDIT_EXCEPTION_ASSIGNMENT = "assign_1"; //辅施检部门拦截
//    public static final String AUDIT_EXCEPTION_ENTOUTPUT = "ENTOUTPUT_1"; //产能核销拦截 add by zn 2008-9-19
//    public static final String AUDIT_EXCEPTION_EXCEPTTIME = "EXCEPTTIME_1";//监管批周期异常 added by dongxin 2009-7-28 
//    public static final String AUDIT_EXCEPTION_BURENKE = "NRK";//企业检测项目不被局端认可
//    public static final String AUDIT_EXCEPTION_LX = "LX";//企漏项
//    public static final String AUDIT_EXCEPTION_NJCZ = "NJCZ";//检测结果没有值
//    public static final String AUDIT_EXCEPTION_JGWFH = "JGWFH";//结果未返回
    /*
     * 自动审单错误的描述信息
     */
    public static final String AUTO_PBATH_DATA_EXCEPTION = "AUTO_B";//生产批数据不符合规范
    public static final String AUTO_HSCODE_EXCEPTION = "AUTO_A";//HS 编码不存在
    public static final String AUTO_ASSIGN_EXCEPTION = "AUTO_C";//自动分单失败
    /**
     * 企业生产批检测结果
     */
    public static final String CHKITEMEVALRESULT_PASS = "1";//合格
    public static final String CHKITEMEVALRESULT_DIS = "2";//不合格
    /*
     * 实验室检测结果是否提交的标志
     */
    public static final String LAB_RESULT_SUBMIT = "5";//已提交
    public static final String LAB_RESULT_CANCEL = "6";//已取消
    /*
     * 通用的合格不合格结果
     */
    public static final String COMMON_PASSED = "1";
    public static final String COMMON_FAIL = "0";
    /*
     * 生产批是否需要人工判定的标志
     */
    public static final String PRODUCT_BATCH_EVAL_NEED = "1";//需要人工判定
    public static final String PRODUCT_BATCH_EVAL_NEEDLESS = "2";//不需要
    /*
     * 生产批监控项目的评定结论
     */
    public static final String PB_ITEM_RESULT_PASS = "1";//合格
    public static final String PB_ITEM_RESULT_FAIL = "0";//不合格
    public static final String PB_ITEM_RESULT_EXCEP = "2";//异常
    /*
     * 生产批的评定结论
     */
    public static final String PB_RESULT_PASS = "1";//合格
    public static final String PB_RESULT_FAIL = "9";//不合格
    //成品关键点
    public static final String KEY_POINT_FINISHIED_PRODUCT = "300";
    //许可强制级别--业务设限（用于拦截报检批）
    public static final String ENT_FORCE_LEVEL_BUSINESS = "B";
    //标识程序异常
    public static final String PROG_EXCEPTION = "EXCEPTION";
    //执行接入程序时发生异常
    public static final String PLUGIN_PROG_EXCEPTION = "PLUGIN_EXCEPTION";
    //生成批项目的填报类型
    public static final String PROD_BATCH_REPORT_ITEM = "1";//按项目填报
    public static final String PROD_BATCH_REPORT_STAT = "2";//按统计数填报
    public static final String PROD_BATCH_REPORT_RESULT = "3";//按最终结果填报
    //检验方式
    public static final String PRODUCT_SELFCHECK = "1";//1.产品自检自验
    public static final String PRODUCT_SHARECHECK = "2";//2.产品共同检验
    public static final String PRODUCTMODEL_NOTCHECK = "3";//3.产品免验，规格不免验
    public static final String PRODUCMODEL_CHECK = "4";//4.产品免验，规格免验
    //add by liuguoliang 2010-5-18 根据分类管理办法，新增5中检验方式，回写CIQ2000时，属于此五种方式的都对应为方式1：自检自验
    public static final String PRODUCT_CREDIT_CONTROL = "5";//5.信用监管方式
    public static final String PRODUCT_VALIDATE_CONTROL = "6";//6.验证监管方式
    public static final String PRODUCTMODEL_COMMON_CONTROL = "7";//7.一般监管方式 
    public static final String PRODUCMODEL_RIGOR_CONTROL = "8";//8.严密监管方式
    public static final String PRODUCMODEL_SPECIALTIES_CONTROL = "9";//9.特别监管方式
    //企业检验项目的实验室检验类型
    public static final String PROD_ITEM_LAB_SELF = "1";//企业自检
    public static final String PROD_ITEM_LAB_CIQLAB = "2";//企业送CIQ实验室检验
    //报检单环节
    public static final String COMBATCH_EXCEPTION = "1";//组批判断
    public static final String INIT_REGISTER = "2";//初始化结果登记
    public static final String AUDIT_EXCEPTION = "3";//电子审单
    public static final String EVAL_EXCEPTION = "4";//综合评定
    public static final String TO_CIQ_EXCEPTION = "5";//回写ciq2000
    public static final String DEL_DECL = "6";//回写ciq2000
    public static final String CEMS_ORDER = "7"; //布控信息加载
    public static final String PROCESS_BACK = "8";//流程回退
    //Begin 计算货物数重量 1：货物以‘数量’计；2：货物以‘重量’计 add by zn 20080919 企业产能核销
    public static final String QTY_CALC = "1";
    public static final String WEIGHT_CALC = "2";
    //End 计算货物数重量 1：货物以‘数量’计；2：货物以‘重量’计 add by zn 20080919 企业产能核销
    //modify by dongxin 2008-9-26 获得当前线程中 收集的电子审单异常信息
    public static final String ESV12_DBATH_EXC = "ESV12_DBATH_EXC";
    //产品许可类别是否定义适用国家
    //0:未执行输出国家；1:指定输出国家，且和报检单输往国家一致；2:指定输出国家，但和报检单输往国家不一致
    public static final String LICENCE_DEFINE_COUNTRY = "1";
    public static final String LICENCE_NO_DEFINE_COUNTRY = "0";
    public static final String LICENCE_DEFINE_COUNTRY_DIF_DECL = "2";
    //检验检疫结果_合格
    public static final String INSP_QUAR_RESULT_PASS_NAME = "合格";
    public static final String INSP_QUAR_RESULT_PASS = "1";
    //检验检疫结果_返工整理合格
    public static final String INSP_QUAR_RESULT_REDONE_PASS_NAME = "返工整改合格";
    public static final String INSP_QUAR_RESULT_REDONE_PASS = "2";
    //检验检疫结果_修改合同(信用证)合格
    public static final String INSP_QUAR_RESULT_CHANGE_SRANDARD_NAME = "修改合同(信用证)合格";
    public static final String INSP_QUAR_RESULT_CHANGE_SRANDARD = "3";
    //检验检疫结果_检疫处理合格
    public static final String INSP_QUAR_RESULT_REDO_PASS_NAME = "检疫处理合格";
    public static final String INSP_QUAR_RESULT_REDO_PASS = "4";
    //检验检疫结果_检验检疫不合格
    public static final String INSP_QUAR_RESULT_INSP_QUAR_FAIL_NAME = "检验检疫不合格";
    public static final String INSP_QUAR_RESULT_INSP_QUAR_FAIL = "7";
    //检验检疫结果_检疫不合格
    public static final String INSP_QUAR_RESULT_QUAR_FAIL_NAME = "检疫不合格";
    public static final String INSP_QUAR_RESULT_QUAR_FAIL = "8";
    //检验检疫结果_检验不合格
    public static final String INSP_QUAR_RESULT_INSP_FAIL_NAME = "检验不合格";
    public static final String INSP_QUAR_RESULT_INSP_FAIL = "9";
    //检验检疫结果_延期检验
    public static final String EXTENSION_SURVEY_NAME = "延期检验";
    public static final String EXTENSION_SURVEY = "Z";
    //检验结果合格
    public static final String INSP_RESULT_PASS = "1";
    //检验结果不合格
    public static final String INSP_RESULT_FAIL = "9";
    //返工整理合格
    public static final String INSP_RESULT_REDONE_PASS = "2";
    //修改合同(信用证)合格
    public static final String INSP_RESULT_CHANGE_SRANDARD = "3";
    //检疫处理合格
    public final static String QUAR_RESULT_REDO_PASS = "4";
    //检疫结果合格
    public static final String QUAR_RESULT_PASS = "1";
    //检疫结果不合格
    public static final String QUAR_RESULT_FAIL = "8";
    //集装箱检疫结果
    public static final String QUAR_CONT_RESULT_PASS = "1";
    //检验结果合格
    public static String INSP_SUM_RESULT_PASS = "1";
    //默认的检验依据代码
    public static String INSP_BASIC_CODE_DEFAULT = "1";
    //外检标记
    public static String INSP_OUTER_FALG_YES = "1";
    //CIQ 外检标记
    public static final String CIQ_INSP_OUTER_FALG_YES = "3";
    //综合评定调用类型:自动
    public static final String INVOKE_TYPE_AUTO = "auto";
    //综合评定调用类型:人工
    public static final String INVOKE_TYPE_MANUAL = "manual";
    //综合评定调用类型:重取
    public static final String INVOKE_TYPE_REFETCH = "refetch";
    //综合评定调用类型:外部调用
    public static final String INVOKE_TYPE_EXP = "exp";
//    //报检类型入境
//    public static final String DECL_TYPE_IN = "1";
//    //报检类型出境
//    public static final String DECL_TYPE_OUT = "2";
    //报检上下文参数：是否审单综合评定
    public static final String DECL_CONTEXT_PARAMS_IS_AUDIT_EVAL = "isAuditEvaluation";
    //报检上下文参数：是否现场查验综合评定
    public static final String DECL_CONTEXT_PARAMS_IS_SCENE_EVAL = "isSceneEvaluation";
    //报检上下文参数：是否为人工判定
    public static String DECL_CONTEXT_PARAMS_IS_MANUAL_DECITION = "isManualDecition";
    //报检上下文参数：是否为授权综合评定
    public static String DECL_CONTEXT_PARAMS_IS_AUDITOR_EVAL = "isAuditorDecition";
    //报检上下文参数：审单结果
    public static String DECL_CONTEXT_PARAMS_AUDIT_RESULT = "auditResult";
    //报检上下文参数: 初始化结果的用户
    public static String DECL_CONTEXT_PARAMS_INIT_RESULT_USER = "initResultUser";
    //报检上下文参数：初始化结果
    public static String DECL_CONTEXT_PARAMS_INIT_RESULT = "initResult";
    //抽批结果
    public static String DECL_CONTEXT_PARAMS_LOT_RESULT = "lotResult";
    //货物的评定结果
    //评定结果：漏项
    public static final String EVAL_RESULT_LOST_ITEM = "1";
    //评定结果：评定不合格
    public static final String EVAL_RESULT_EVAL_FAIL = "2";
    //综合评定合格
    public static final String EVAL_RESULT_EVAL_PASS = "3";
    //评定结果：等待人工评定(非零缺陷)
    public static final String EVAL_RESULT_NEED_MANUAL_EVAL = "4";
    //评定结果:自动审单异常
    public static final String EVAL_RESULT_AUDIT_EXCEPTION = "6";
    //评定结果:抽批抽中
    public static final String EVAL_RESULT_LOTTED = "7";
    //现场查验评定不合格
    //public static final String EVAL_RESULT_SCENE_FAIL = "8";
    //表单未找到
    public static final String EVAL_RESULT_NOT_FOUND_FORM = "9";
    // 初审正常(等待人工干预)
    public static final String EVAL_RESULT_NEED_MANUAL_INTERVENTIONS = "10";
    //程序异常
    public static final String EVAL_RESULT_PROGRAM_EXCEPTION = "11";
    /*
     * 监控项目的评定结论
     */
    public static final String ITEM_EVAL_FAIL = "0";//不合格
    public static final String ITEM_EVAL_PASS = "1";//合格
    public static final String ITEM_EVAL_NO_RULE = "2";//无规则
    public static final String ITEM_EVAL_NEED_MANUAL = "3";//需要人工判定
    public static final String ITEM_EVAL_NO_VALUE = "4";//项目无检测值
    //结果未返回
    public static final String ITEM_EVAL_UNRETURN = "5";
    //漏项
    public static final String ITEM_EVAL_ITEM_LOST = "6";
    //检验检疫要求：需查验
    public static String INSP_REQUIRE_SCENE = InsContext.TEST_REQUIRE_EXAMINE;
    //检验检疫要求：需送检
    public static String INSP_REQUIRE_SENDLAB = InsContext.TEST_REQUIRE_SENDCHECK;
    //检验检疫要求：需查验并送检
    public static String INSP_REQUIRE_SCENE_SENDLAB = "2";
    //抽批原因：常规抽批 代码
    public static String LOT_REASON_STD = "1";
    //抽批原因：监管方式抽批 代码
    public static String LOT_REASON_INSP_MODE = "2";
    //抽批原因：风险监控抽批 代码
    public static String LOT_REASON_RISK_MONITOR = "3";
    //抽批原因：常规抽批 名称
    public static String LOT_REASON_STD_NAME = "常规抽批";
    //抽批原因：监管方式抽批 名称
    public static String LOT_REASON_INSP_MODE_NAME = "监管方式抽批";
    //抽批原因：风险监控抽批 名称
    public static String LOT_REASON_RISK_MONITOR_NAME = "风险监控抽批";
    //综合评定审单开关：自动放行时，是否需要审核后再放行
    public static String EVAL_SWITCH_AUTOPASS_NEED_AUDIT = "passNeedAudit";
    //审单开关：企业周期异常
    public static final String AUDIT_SWITCH_ENT_CYC_EXCEPTION = "";
    //审单开关：重点监控企业
    public static final String AUDIT_SWITCH_ENT_SUP_MEASURE = "";
    //审单开关：辅检拦截
    public static final String AUDIT_SWITCH_ASSISTANT_CHECK = "";
    //审单开关：货物周期异常
    public static final String AUDIT_SWITCH_GOODS_CYC_EXCEPTION = "";
    //审单开关：是否存在表单
    public static final String AUDIT_SWITCH_EXISTS_CTLITEM = "";
    //审单开关：是否存在监管属性
    public static final String AUDIT_SWITCH_EXISTS_ENT_ATTRIBUTE = "";
    //审单开关：出证拦截
    public static final String AUDIT_SWITCH_NEED_CERT = "";
    //审单开关：重点监控产品
    public static final String AUDIT_SWITCH_GOODS_SUP_MEASURE = "";
    //审单开关：产能核消
    public static final String AUDIT_SWITCH_YEAR_CAPACITY = "";
    //审单开关:生产批是否有ciqcode
    public static final String AUDIT_SWITCH_PB_CIQ_CODE = "";
    //审单开关:异常生产批
    public static final String AUDIT_SWITCH_PB_EXCEPTION = "";
    //审单开关:集装箱抽批
    public static final String AUDIT_SWITCH_CONTLOT = "";
    //审单开关:木包抽批
    public static final String AUDIT_SWITCH_WOODLOT = "";
    //审单开关:卫生检疫抽批
    public static final String AUDIT_SWITCH_ISOLOT = "";
    //默认值：默认企业类型为三类
    public static String DEFAULT_ENT_LEVEL = "3";
    //授权综合评定
    public static String POW_PASS = "1";
    //不合格类型：综合评定不合格
    public static final String UNQUALIFIED_TYPE_EVAL = "1";
    //评定指标的操作符
    /**
     * operator 等于
     */
    //public static final String OPERATOR_EQUAL_CODE = "EQUAL";
    public static final String OPERATOR_EQUAL_ID = "1";
    /**
     * operator 不等于
     */
    //public static final String OPERATOR_NOTEQUAL_CODE = "NOTEQUAL";
    public static final String OPERATOR_NOTEQUAL_ID = "2";
    /**
     * operator 小于
     */
    //public static final String OPERATOR_LITTLETHAN_CODE = "LITTLETHAN";
    public static final String OPERATOR_LITTLETHAN_ID = "3";
    /**
     * operator 小于等于
     */
    //public static final String OPERATOR_LITTLETHANEQUAL_CODE = "LITTLETHANEQUAL";
    public static final String OPERATOR_LITTLETHANEQUAL_ID = "4";
    /**
     * operator 大于
     */
    //public static final String OPERATOR_GREATTHAN_CODE = "GREATTHAN";
    public static final String OPERATOR_GREATTHAN_ID = "5";
    /**
     * operator 大于等于
     */
    //public static final String OPERATOR_GREATTHANEQUAL_CODE = "GREATTHANEQUAL";
    public static final String OPERATOR_GREATTHANEQUAL_ID = "6";
    /**
     * OPERATOR LIKE
     */
    //public static final String OPERATOR_LIKE_CODE = "LIKE";
    public static final String OPERATOR_LIKE_ID = "7";
    //企业端报文名称
    public static String SEND_CONFIG_ENT_MESSAGE_TYPE = "EntInterReceipt";
    //源应用Id
    public static String SEND_CONFIG_SOURCE_APP_ID = "eciq";
    //企业回执表的表名
    public static String SEND_CONFIG_ENT_MESSAGE_TABLE_NAME = "Inter_Receipt";
    //企业端的应用名称
    public static String SEND_CONFIG_ENT_DEST_APP_ID = "entPlatform";

    //货物检验
    public static String GOODS_INS = "2-货物检验";
    //货物检疫
    public static String GOODS_REQUIRE = "1-货物检疫";
    //货物鉴定
    public static String GOODS_APPRAISAL = "3-货物鉴定";
    
}

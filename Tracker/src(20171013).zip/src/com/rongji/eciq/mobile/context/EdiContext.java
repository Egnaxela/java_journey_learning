/**  
 * FileName:EdiContext.java
 * @Description: 源应用与目标应用代码 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.context;
/**
 * 
 * Description: 源应用与目标应用代码 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:43:37  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10      李云龙                      1.0         1.0 Version
 */
public class EdiContext {
	/**
     * [源应用代码]
     */
    public static final String EDI_SOURCE_APP_ID = "ECIQ";
    /**
     * [目标应用代码]
     */
    public static final String EDI_DEST_APP_ID = "ENT";
    /**
     * 通用数据下发[目标应用代码]
     */
    public static final String EDI_DEST_APP_GDATA = "GDATA";
    /**
     * 电子支付方下发[目标应用代码]
     */
    public static final String EDI_DEST_APP_PAY = "PAY";
    /**
     * 检疫处理系统下发[目标应用代码]
     */
    public static final String EDI_DEST_APP_QT = "QT";
    /**
     * 统计数据转换系统[目标应用代码]
     */
    public static final String EDI_DEST_APP_STAT = "STAT";
    /**
     * 认监委接口数据下发[目标应用代码]
     */
    public static final String EDI_DEST_APP_CNCA = "CNCA";
    
    /**
     * [消息源代码]
     */
    public static final String MESSAGE_SOURCE = "000000";
    /**
     * [目标代码]
     */
    public static final String MESSAGE_DEST = "990000";
    /**
     * [消息源类别 ： 1-企业端]
     */
    public static final String MESSAGE_SOUCE_TYPE_1 = "1";
    /**
     * [消息源类别 ： 2-局端]
     */
    public static final String MESSAGE_SOUCE_TYPE_2 = "2";

}

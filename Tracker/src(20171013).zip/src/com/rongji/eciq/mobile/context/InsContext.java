/**  
 * FileName:  InsContext.java   
 * @Description: 此类为施检基础代码-名称类  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年3月31日 下午13:53:16  
 *  
 */ 
package com.rongji.eciq.mobile.context;

/**
 * 
 * Description: 此类为施检基础代码-名称类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年3月31日 下午13:53:16  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-07-17    李云龙                         1.0         修改查验预约-申请状态
 * 
 */
public class InsContext {
	 /**
     * [施检员审单-异常类型-风险预警]编码
     */
    public static final String RISK_EARLY_WARNING = "1";
    /**
     * [施检员审单-异常类型-风险预警]名称
     */
    public static final String RISK_EARLY_WARNING_NAME = "风险预警";
    /**
     * [施检员审单-异常类型-许可拦截]编码
     */
    public static final String PERMISSION_TO_INTERCEPT = "2";
    /**
     * [施检员审单-异常类型-许可拦截]名称
     */
    public static final String PERMISSION_TO_INTERCEPT_NAME = "许可拦截";
    /**
     * [施检员审单-异常类型-抽批抽中]编码
     */
    public static final String PICK_A_GROUP_OF = "3";
    /**
     * [施检员审单-异常类型-抽批抽中]名称
     */
    public static final String PICK_A_GROUP_OF_NAME = "抽批抽中";
    /**
     * [施检员审单-异常类型-规则布控拦截]编码
     */
    public static final String SUPERVISED_RULES_INTERCEPT = "4";
    /**
     * [施检员审单-异常类型-规则布控拦截]名称
     */
    public static final String SUPERVISED_RULES_INTERCEPT_NAME = "规则布控拦截";
    /**
     * [施检员审单-异常类型-辅施检拦截]编码
     */
    public static final String AUXILIARY_INSPECTION_INTERCEPT = "5";
    /**
     * [施检员审单-异常类型-辅施检拦截]名称
     */
    public static final String AUXILIARY_INSPECTION_INTERCEPT_NAME = "辅施检拦截";
    /**
     * [施检员审单-异常类型-布控指令拦截]编码
     */
    public static final String MONITOR_ORDER_INTERCEPT = "6";
    /**
     * [施检员审单-异常类型-布控指令拦截]名称
     */
    public static final String MONITOR_ORDER_INTERCEPT_NAME = "布控指令拦截";
    /**
     * [施检员审单-异常类型-无监控项目表单拦截]编码
     */
    public static final String NOT_MONITORING_PROJECT_INTERCEPT = "7";
    /**
     * [施检员审单-异常类型-无监控项目表单拦截]名称
     */
    public static final String NOT_MONITORING_PROJECT_INTERCEPT_NAME = "无监控项目表单拦截";
    /**
     * [施检员审单-异常类型-调回修改后重新拦截]编码
     */
    public static final String REVISED_BACK_TO_INTERCEPT = "8";
    /**
     * [施检员审单-异常类型-调回修改后重新拦截]名称
     */
    public static final String REVISED_BACK_TO_INTERCEPT_NAME = "调回修改后重新拦截";
    /**
     * [施检员审单-异常类型-企业周期异常拦截]编码
     */
    public static final String BUSINESS_CYCLE_ABNORMAL_INTERCEPT = "9";
    /**
     * [施检员审单-异常类型-企业周期异常拦截]名称
     */
    public static final String BUSINESS_CYCLE_ABNORMAL_INTERCEPT_NAME = "企业周期异常拦截";
    /**
     * [施检员审单-异常类型-企业产能核销拦截]编码
     */
    public static final String ENTERPRISE_CAPACITY_VERIFICATION = "10";
    /**
     * [施检员审单-异常类型-企业产能核销拦截]名称
     */
    public static final String ENTERPRISE_CAPACITY_VERIFICATION_NAME = "企业产能核销拦截";
    /**
     * [施检员审单-异常类型-无监管属性]编码
     */
    public static final String NO_REGULATORY_PROPERTIES = "11";
    /**
     * [施检员审单-异常类型-无监管属性]名称
     */
    public static final String NO_REGULATORY_PROPERTIES_NAME = "无监管属性";
    /**
     * [施检员审单-异常类型-重点监控拦截]编码
     */
    public static final String MONITOR_AND_INTERCEPT = "12";
    /**
     * [施检员审单-异常类型-重点监控拦截]名称
     */
    public static final String MONITOR_AND_INTERCEPT_NAME = "重点监控拦截";
    /**
     * [施检员审单-异常类型-出证拦截]编码
     */
    public static final String HIS_BLOCK = "13";
    /**
     * [施检员审单-异常类型-出证拦截]名称
     */
    public static final String HIS_BLOCK_NAME = "出证拦截";
    /**
     * [施检员审单-异常类型-生产批无CIQ代码拦截]编码
     */
    public static final String PRODUCTION_BATCH_NO_CIQ_CODE_BLOCK = "14";
    /**
     * [施检员审单-异常类型-生产批无CIQ代码拦截]名称
     */
    public static final String PRODUCTION_BATCH_NO_CIQ_CODE_BLOCK_NAME = "生产批无CIQ代码拦截";
    /**
     * [施检员审单-异常类型-企业上报异常拦截]编码
     */
    public static final String COMPANIES_REPORT_THE_ABNORMAL_INTERCEPT = "15";
    /**
     * [施检员审单-异常类型-企业上报异常拦截]名称
     */
    public static final String COMPANIES_REPORT_THE_ABNORMAL_INTERCEPT_NAME = "企业上报异常拦截";
    /**
     * [施检员审单-异常类型-生产批局端监管拦截]编码
     */
    public static final String PRODUCTION_BATCH_SUPERVISION_BUREAU_END_INTERCEPT = "16";
    /**
     * [施检员审单-异常类型-生产批局端监管拦截]名称
     */
    public static final String PRODUCTION_BATCH_SUPERVISION_BUREAU_END_INTERCEPT_NAME = "生产批局端监管拦截";
    /**
     * [施检员审单-异常类型-生产批有效期拦截]编码
     */
    public static final String PRODUCTION_BATCH_VALIDITY_OF_INTERCEPTION = "17";
    /**
     * [施检员审单-异常类型-生产批有效期拦截]名称
     */
    public static final String PRODUCTION_BATCH_VALIDITY_OF_INTERCEPTION_NAME = "生产批有效期拦截";
    /**
     * [施检员审单-异常类型-首次出口拦截]编码
     */
    public static final String FIRST_EXPORT_INTERCEPT = "18";
    /**
     * [施检员审单-异常类型-首次出口拦截]名称
     */
    public static final String FIRST_EXPORT_INTERCEPT_NAME = "首次出口拦截";
    /**
     * [施检员审单-异常类型-首次进口拦截]编码
     */
    public static final String FIRST_IMPORT_INTERCEPT = "19";
    /**
     * [施检员审单-异常类型-首次进口拦截]名称
     */
    public static final String FIRST_IMPORT_INTERCEPT_NAME = "首次进口拦截";
    /**
     * [施检员审单-异常类型-无施检人员]编码
     */
    public static final String NO_INSP_USER = "20";
    /**
     * [施检员审单-异常类型-无施检人员]名称
     */
    public static final String NO_INSP_USER_NAME = "无施检人员拦截";
   

    public static final String INSP_QUAR_RESULT_PASS_NAME = "合格";
    public static final String INSP_QUAR_RESULT_PASS = "1";
    //检验检疫结果_返工整理合格
    public static final String INSP_QUAR_RESULT_REDONE_PASS_NAME = "返工整改合格";
    public static final String INSP_QUAR_RESULT_REDONE_PASS = "2";
    //检验检疫结果_修改合同(信用证)合格
    public static final String INSP_QUAR_RESULT_CHANGE_SRANDARD_NAME = "修改合同(信用证)合格";
    public static final String INSP_QUAR_RESULT_CHANGE_SRANDARD = "3";
    //检验检疫结果_检疫处理合格
    public static final String INSP_QUAR_RESULT_REDO_PASS_NAME = "检疫处理合格";
    public static final String INSP_QUAR_RESULT_REDO_PASS = "4";
    //检验检疫结果_检验检疫不合格
    public static final String INSP_QUAR_RESULT_INSP_QUAR_FAIL_NAME = "检验检疫不合格";
    public static final String INSP_QUAR_RESULT_INSP_QUAR_FAIL = "7";
    //检验检疫结果_检疫不合格
    public static final String INSP_QUAR_RESULT_QUAR_FAIL_NAME = "检疫不合格";
    public static final String INSP_QUAR_RESULT_QUAR_FAIL = "8";
    //检验检疫结果_检验不合格
    public static final String INSP_QUAR_RESULT_INSP_FAIL_NAME = "检验不合格";
    public static final String INSP_QUAR_RESULT_INSP_FAIL = "9";
    
    /**
     * 施检查验项目定值
     */
    public final static String CHECK_ITEM_CODE = "1";
    /**
     * 施检木质包装项目定值
     */
    public final static String WOOD_ITEM_CODE = "2";
    /**
     * 施检集装箱项目定值
     */
    public final static String CONT_ITEM_CODE = "3";
    /**
     * 施检卫生检疫项目定值
     */
    public final static String HEAL_ITEM_CODE = "4";
    
    //////////////////////////////////////////
    /**
     * 查验项目类型--货物检疫
     */
    public final static String QUAR_ITEM_CODE = "1";
    /**
     * 查验项目类型--货物检验
     */
    public final static String INSP_ITEM_CODE = "2";
    /**
     * 查验项目类型--货物鉴定
     */
    public final static String AUTH_ITEM_CODE = "3";
    /**
     * 查验项目类型--其他
     */
    public final static String OTHER_ITEM_CODE = "4";
    
    /**
     * 现场查验项目类别-货物类-口岸查验项目-货物检疫
     */
    public static final String INS_SCENE_GOODS_ITEM_TYPE_1 = "1_1";
    /**
     * 现场查验项目类别-货物类-口岸查验项目-货物检验
     */
    public static final String INS_SCENE_GOODS_ITEM_TYPE_2 = "1_2";
    /**
     * 现场查验项目类别-货物类-口岸查验项目-货物鉴定
     */
    public static final String INS_SCENE_GOODS_ITEM_TYPE_3 = "1_3";
    
    /**
     * 现场查验项目类别-口岸查验项目
     */
    public static final String PORT_INS_SCENE_ITEM = "port_items";
    
    /**
     * [出入境施检-是]编码
     */
    public static final String INS_Y = CommContext.Y;
    /**
     * [出入境施检-是]名称
     */
    public static final String INS_Y_NAME = "是";
    /**
     * [出入境施检-否]编码
     */
    public static final String INS_N = CommContext.N;
    /**
     * [出入境施检-否]名称
     */
    public static final String INS_N_NAME = "否";
    /**
     * 施检现场查验项目不适用编码
     */
    public static final String NOT_TRY_OUT_CODE = "2";
    /**
     * 施检现场查验项目不适用名称
     */
    public static final String NOT_TRY_OUT_NAME = "不适用";
    
    
    /**
     * [出入境施检-不合格] 编码
     */
    public static final String INS_UNQUALIFIED = "0";
    /**
     * [出入境施检-不合格] 名称
     */
    public static final String INS_UNQUALIFIED_NAME = "不合格";
    /**
     * [出入境施检-合格] 编码
     */
    public static final String INS_QUALIFIED = "1";
    /**
     * [出入境施检-合格] 名称
     */
    public static final String INS_QUALIFIED_NAME = "合格";
    /**
     * [出入境施检-返工整改合格] 编码
     */
    public static final String BACK_INS_UNQUALIFIED = "2";
    /**
     * [出入境施检-返工整改合格] 名称
     */
    public static final String BACK_INS_UNQUALIFIED_NAME = "返工整改合格";
    
    
    /**
     * [出入境施检-分单状态-未分单]编码
     */
    public static final String SUBMENU_TYPE_NOT_SUB = "1";
    /**
     * [出入境施检-分单状态-未分单]名称
     */
    public static final String SUBMENU_TYPE_NOT_SUB_NAME = "未分单";
    /**
     * [出入境施检-分单状态-已分单]编码
     */
    public static final String SUBMENU_TYPE_YET_SUB = "0";
    /**
     * [出入境施检-分单状态-已分单]名称
     */
    public static final String SUBMENU_TYPE_YET_SUB_NAME = "已分单";
    /**
     * [出入境施检-报检单管理表-流程状态-主施检]编码
     */
    public static final String FLOW_PATH_STATUS_MAIN = "800";
    /**
     * [出入境施检-报检单管理表-流程状态-主施检]名称
     */
    public static final String FLOW_PATH_STATUS_MAIN_NAME = "主施检";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检]编码
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY = "801";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检]名称
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_NAME = "辅施检";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检完成]编码
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_DONE = "802";
    /**
     * [出入境施检-报检单管理表-流程状态-辅施检完成]名称
     */
    public static final String FLOW_PATH_STATUS_AUXILIARY_DONE_NAME = "辅施检完成";
    /**
     * [出入境施检-现场查验-封识号状态-已使用]编码
     */
    public static final String BILL_STATUS_USED = "1";
    /**
     * [出入境施检-现场查验-封识号状态-已使用]名称
     */
    public static final String BILL_STATUS_USED_NAME = "已使用";
    /**
     * [出入境施检-现场查验-封识号状态-已废除]编码
     */
    public static final String BILL_STATUS_CANCEL = "2";
    /**
     * [出入境施检-现场查验-封识号状态-已废除]名称
     */
    public static final String BILL_STATUS_CANCEL_NAME = "已废除";
    /**
     * [出入境施检-分单改派单-施检内容-货物鉴定]编码
     */
    public static final String GOODS_IDENTIFY = "3";
    /**
     * [出入境施检-分单改派单-施检内容-货物鉴定]名称
     */
    public static final String GOODS_IDENTIFY_NAME = "货物鉴定";
    /**
     * [出入境施检-分单改派单-施检内容-木包装检疫]编码
     */
    public static final String WOOD_PACKAG_QUARANTINE = "4";
    /**
     * [出入境施检-分单改派单-施检内容-木包装检疫]名称
     */
    public static final String WOOD_PACKAG_QUARANTINE_NAME = "木包装检疫";
    /**
     * [出入境施检-分单改派单-施检内容-集装箱检疫]编码
     */
    public static final String CONTAINER_QUARANTINE = "6";
    /**
     * [出入境施检-分单改派单-施检内容-集装箱检疫]名称
     */
    public static final String CONTAINER_QUARANTINE_NAME = "集装箱检疫";
    /**
     * [出入境施检-分单改派单-施检内容-货物检疫]编码
     */
    public static final String SGOODS_QUARANTINE = "2";
    /**
     * [出入境施检-分单改派单-施检内容-货物检疫]名称
     */
    public static final String SGOODS_QUARANTINE_NAME = "货物检疫";
    /**
     * [出入境施检-分单改派单-施检内容-隔离检疫]编码
     */
    public static final String ISOLATION_QUARANTINE = "5";
    /**
     * [出入境施检-分单改派单-施检内容-隔离检疫]名称
     */
    public static final String ISOLATION_QUARANTINE_NAME = "隔离检疫";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]代码
     */
    public static final String SGOODS_CHECKOUT_CODE = "1";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]名称
     */
    public static final String SGOODS_CHECKOUT_NAME = "货物检验";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]代码
     */
    public static final String AUX_INS_QUAR_CODE = "7";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]名称
     */
    public static final String AUX_INS_QUAR_CODE_NAME = "检验检疫";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]代码
     */
    public static final String AUX_INS_HEALTH_CODE = "8";
    /**
     * [出入境施检-分单改派单-施检内容-货物检验]名称
     */
    public static final String AUX_INS_HEALTH_CODE_NAME = "卫生检疫";
    
    /**
     * 查询历史库标记
     */
    public static final String HISTORY_SIGN = "historyLibrary";
    
    /**
     * 出入境施检-审单评定类型
     */
    public static final String AUDIT_EVALUATE_TYPE = "1";
    /**
     * 出入境施检-查验评定类型
     */
    public static final String CHECK_EVALUATE_TYPE = "2";
    /**
     * 出入境施检-送检评定类型
     */
    public static final String SEND_EVALUATE_TYPE = "3";
    /**
     * 出入境施检-综合评定类型
     */
    public static final String SYNTH_EVALUATE_TYPE = "4";
    
    /**
     * [出入境施检-检验要求-需送检]编码
     */
    public static final String TEST_REQUIRE_SENDCHECK = "0";
    /**
     * [出入境施检-检验要求-需送检]名称
     */
    public static final String TEST_REQUIRE_SENDCHECK_NAME = "需送检";
    /**
     * [出入境施检-检验要求-需查验]编码
     */
    public static final String TEST_REQUIRE_EXAMINE = "1";
    /**
     * [出入境施检-检验要求-需查验]名称
     */
    public static final String TEST_REQUIRE_EXAMINE_NAME = "需查验";
    /**
     * [出入境施检-检验要求-需查验送检]编码
     */
    public static final String TEST_REQUIRE_SEDCHK_AND_EXAMINE = "2";
    /**
     * [出入境施检-检验要求-需查验送检]名称
     */
    public static final String TEST_REQUIRE_SEDCHK_AND_EXAMINE_NAME = "需查验送检";
    
    /**
     * 项目送检标志 0-不送检*
     */
    public static final String DELIVER_FLAG_NO_SEND = "0";
    /**
     * 项目送检标志 0-不送检*
     */
    public static final String DELIVER_FLAG_NO_SEND_NAME = "不送检";
    /**
     * 项目送检标志 1-确认送检*
     */
    public static final String DELIVER_FLAG_SURE_SEND = "1";
    /**
     * 项目送检标志 1-确认送检*
     */
    public static final String DELIVER_FLAG_SURE_SEND_NAME = "确定送检";
    
    /**
     * [检测结果来源类别-实验室项目]编码
     */
    public static final String CHECK_RESULT_LAB = "1";
    /**
     * [检测结果来源类别-实验室项目]名称
     */
    public static final String CHECK_RESULT_LAB_NAME = "实验室项目";
    /**
     * [检测结果来源类别-人工登记项目]编码
     */
    public static final String CHECK_RESULT_SELF = "2";
    /**
     * [检测结果来源类别-人工登记项目]名称
     */
    public static final String CHECK_RESULT_SELF_NAME = "人工登记项目";
    
    /**
     * [监督管理-归档标志-未归档]编码
     */
    public static final String SUP_ARCHIVE_N = "0";
    /**
     * [监督管理-归档标志-未归档]名称
     */
    public static final String SUP_ARCHIVE_N_NAME = "未归档";
    /**
     * [监督管理-归档标志-已归档]编码
     */
    public static final String SUP_ARCHIVE_Y = "1";
    /**
     * [监督管理-归档标志-已归档]名称
     */
    public static final String SUP_ARCHIVE_Y_NAME = "已归档";
    
    /**
     * [分单改派单主施检退单]编码
     */
    public static final String SUB_MAIN_BACK = "1";
    /**
     * [分单改派单主施检退单]名称
     */
    public static final String SUB_MAIN_BACK_NAME = "分单改派单主施检退单";
    /**
     * [分单改派单辅施检退单]编码
     */
    public static final String SUB_AUXILIARY_BACK = "2";
    /**
     * [分单改派单辅施检退单]名称
     */
    public static final String SUB_AUXILIARY_BACK_NAME = "分单改派单辅施检退单";
    /**
     * [施检员审单主施检退单]编码
     */
    public static final String AUDIT_MAIN_BACK = "3";
    /**
     * [施检员审单主施检退单]名称
     */
    public static final String AUDIT_MAIN_BACK_NAME = "施检员审单主施检退单";
    /**
     * [施检员审单辅施检退单]编码
     */
    public static final String AUDIT_AUXILIARY_BACK = "4";
    /**
     * [施检员审单辅施检退单]名称
     */
    public static final String AUDIT_AUXILIARY_BACK_NAME = "施检员审单辅施检退单";
    /**
     * [结果登记主施检退单]编码
     */
    public static final String REG_MAIN_BACK = "9";
    /**
     * [结果登记主施检退单]名称
     */
    public static final String REG_MAIN_BACK_NAME = "施检员审单辅施检退单";
    /**
     * [结果登记辅施检退单]编码
     */
    public static final String REG_AUXILIARY_BACK = "10";
    /**
     * [结果登记辅施检退单]名称
     */
    public static final String REG_AUXILIARY_BACK_NAME = "施检员审单辅施检退单";
    /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_PACK_BACK = "5";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_PACK_BACK_NAME = "包装施检结果登记退单";
    /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_PACK_SUB_BACK = "6";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_PACK_SUB_BACK_NAME = "包装施检分单改派退单";
     /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_CARG_SUB_BACK = "7";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_CARG_SUB_BACK_NAME = "适载检验分单改派退单";
     /** 
      * [适载检验-结果登记-未评定]编码
      */
    public static final String PAR_ST_UNEVAL = "3";
    /**
     * [适载检验-结果登记-未评定]名称
     */
    public static final String PAR_ST_UNEVAL_NAME = "未评定";
    /**
     * [出境包装-结果登记-退单]编码
     */
    public static final String AUDIT_CARG_REG_BACK = "8";
    /**
     * [出境包装-结果登记-退单]名称
     */
    public static final String AUDIT_CARG_REG_BACK_NAME = "适载检验结果登记退单";
    
    /**
     * 施检分单退单
     */
    public static final String BACK_SUB_TYPE = "1";
    /**
     * 施检审单退单
     */
    public static final String BACK_AUDIT_TYPE = "2";
    
    /**
     * 施检结果登记退单
     */
    public static final String BACK_REG_TYPE = "9";
    
    /**
     * 工作量-处理状态
     */
    public static final String WORKPROC_TREAT_STATE_PASS = "1"; // 放行
    public static final String WORKPROC_TREAT_STATE_BACK = "0"; // 退回
    /**
     * 工作量-业务操作状态
     */
    public static final String WORKPROC_OPER_STATE_Y = "1"; // 已处理
    public static final String WORKPROC_OPER_STATE_N = "0"; // 未处理
    public static final String WORKPROC_OPER_STATE_C = "2"; // 处理未统计
    
    
    /**
     * 流程规则引擎-施检自定义表名
     */
    public static final String TABLE_NAME = "ZDY_LCKZ_SHIJIAN";
    /**
     * 流程规则引擎-规则类型
     */
    public static final String RULE_TYPE = "13";
    /**
     * 流程规则引擎-自定义施检表字段
     */
    public static final String SUB_FIELD = "ZDY_ANNIU";
    /**
     * 流程规则引擎-自定义施检表字段
     */
    public static final String AUDIT_FIELD = "ZDY_AUDIT";

    /**
     * 查验预约-申请状态
     */
    public static final String APPLY_STATUS_0="0";
    
    /**
     * 查验预约-申请状态名称
     */
    public static final String APPLY_STATUS_0_NAME="待上报";
    
    /**
     * 查验预约-申请状态
     */
    public static final String APPLY_STATUS_1="1";
    
    /**
     * 查验预约-申请状态名称
     */
    public static final String APPLY_STATUS_1_NAME="待受理";
    /**
     * 查验预约-申请状态
     */
    public static final String APPLY_STATUS_2="2";
    
    /**
     * 查验预约-申请状态名称
     */
    public static final String APPLY_STATUS_2_NAME="已受理";
    
    /**
     * 查验预约-申请状态
     */
    public static final String APPLY_STATUS_3="3";
    
    /**
     * 查验预约-申请状态名称
     */
    public static final String APPLY_STATUS_3_NAME="待审批";
    
    /**
     * 查验预约-申请状态
     */
    public static final String APPLY_STATUS_4="4";
    
    /**
     * 查验预约-申请状态名称
     */
    public static final String APPLY_STATUS_4_NAME="已审批";
    
    
    /**
     * 查验预约-申请类别
     */
    public static final String APPLY_TYPE_1="1";
    
    /**
     * 查验预约-申请类别名称
     */
    public static final String APPLY_TYPE_1_NAME="预约申请";
    
    
    /**
     * 查验预约-申请类别
     */
    public static final String APPLY_TYPE_2="2";
    
    /**
     * 查验预约-申请类别名称
     */
    public static final String APPLY_TYPE_2_NAME="撤销申请";
    
    /**
     * 查验预约-受理结果
     */
    public static final String ACCEPT_RESULT_0="0";
    
    /**
     * 查验预约-受理结果名称
     */
    public static final String ACCEPT_RESULT_0_NAME="未审批";
    
    
    /**
     * 查验预约-受理结果
     */
    public static final String ACCEPT_RESULT_1="1";
    
    /**
     * 查验预约-受理结果名称
     */
    public static final String ACCEPT_RESULT_1_NAME="同意";
    
    
    /**
     * 查验预约-受理结果
     */
    public static final String ACCEPT_RESULT_2="2";
    
    /**
     * 查验预约-受理结果名称
     */
    public static final String ACCEPT_RESULT_2_NAME="不同意";
    
    
}

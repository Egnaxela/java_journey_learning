/**  
 * FileName:  InsMsgContext.java   
 * @Description: 此类为施检提示消息定值编码类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月18日 下午3:35:14  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为施检提示消息定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月18日 下午3:35:14  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月18日      吴有根                      1.0         1.0 Version  
 * 2017年4月19日      吴有根                      1.0         添加"工作内容已存在"
 * 2017-06-06   魏波                            1.0        辅检完成公用方法
 */

public class InsMsgContext {
    public final static String INSPECTION_PROCESS_LOCK = "报检单流程被锁定,请填写相关布控信息或等待布控信息！";
    /**
     * 工作内容已存在。
     */
    public static String WORK_CONTENT_EXIST = "工作内容已存在";
    
    
    /**
     * 现场查验
     */
    public final static String AUXILIARY_NO_OPERATION = "辅施检人员不能进行该操作！";
    public final static String DO_INSPECT_OPERATION = "请先完成查验送检操作！";
    public final static String DO_CHECK_OPERATION = "请先完成查验操作！";
    public final static String ACTSMPLNUM_NO_LESS_EUQAL_THAN_ZERO = "实际抽样量不能小于或等于0！";
    public final static String ACTSMPLNUM_NO_LESS_THAN_ZERO = "实际抽样量不能小于0！";
    public final static String AUXILIARY_NOT_FINISHED = "辅检未处理完成！";
    public final static String SPOTDESC_NOTNULL = "现场情况描述不能为空！";
    public final static String CHECKER_NOTNULL = "查验人员不能为空！";
    public final static String ENDDATE_NO_BEFORE_BEGINDATE = "检毕日期不能在查验日期之前！";
    public final static String BASECATCODE_MUST_BASICCODE = "您选择查验依据后,必须填写依据编码！";
    public final static String NOT_BASECATCODE_MUST_BASICCODE = "查验依据为空,不能再填写依据编码！";
    public final static String GOODSRESULT_MUST_SAME = "货物评定结果与货物检验结果要一致！";
    public final static String GOODSVALUE_NOT_GREATER_DECLVALUE = "货物总值不能大于报检货物总值！";
    public final static String ACTSMPLNUM_NOT_GREATER_REALWEIGHT = "实际抽样量不能大于实际数/重量！";
    public final static String ITEMRESU_GOODSRESU_SAME = "货物检验结果与查验项目结果要一致！";
    public final static String THIS_GOODS_RETURN_QUALITY = "这条货物信息只能选择返工整改合格！";
    public final static String ITEM_NO_ADD = "查验项目基础数据的根节点不能被添加！";
    public final static String ITEM_ALREADY_EXISTS = "查验项目列表已存在该查验项目！";
    public final static String NOT_ADD_REPEAT = "请不要重复增加！";
    public final static String FIRST_CHECK_SAVE = "请先进行现场查验保存操作！";
    public final static String WHETHER_COMPRE = "是否综合评定?";
    public final static String WHETHER_BATCH_COMPRE = "是否进行批量综合评定?";
    public final static String CHOOSE_WHETHER2NDINS = "只有勾选二次检验才能查验检验记录！";
    public final static String NO_CHOOSE_ONE_RECORD = "没有选中一条记录！";
    public final static String VERIFY_FALIED = "核销失败！";
    public final static String VERIFY_SUCCESSFUL = "核销成功！";
    public final static String SURE_COPY_RECORD = "确定要复写记录吗?";
    public final static String RELEASENO_NOTNULL = "放行号为空,无法进行查验完成操作！";
    public final static String OBJECT_CONT_NO_ZERO = "对象数量不能小于0！";
    public final static String OBJECT_WEIGHT_NO_ZERO = "对象重量不能小于0！";
    public final static String CONTROL_NOT_OPEN = "布控开关没有打开！";
    public final static String PACKQTY_NO_ZERO = "包装件数不能小于0！";
    public final static String CHECK_PLACE_NOTNULL = "查验地点不能为空！";
    public final static String FINISHED_WOOD_PACKAG_QUARANTINE = "请先完成木质包装检疫结果处理！";
    public final static String FINISHED_CONTAINER_QUARANTINE = "请先完成集装箱检疫结果处理！";
    public final static String NO_SAVE_DATA = "没有要保存的数据！";
    public final static String MARKNO_NOTNULL = "铅封号码不能为空！";
    public final static String MARKNO_STATUS_NOTNULL = "铅封号状态不能为空！";
    public final static String SURE_SEND = "确定要发送吗?";
    public final static String NOT_BASECATCODE = "检验依据不能为空！";
    public final static String CONSIGNEE_NOTNULL = "收货人不能为空！";
    public final static String CONSIGNER_NUTNULL = "发货人不能为空！";
    public final static String OBJAMOUNTTYPE_NORIGHT = "对象数量类型不正确！";
    public final static String OBJAMOUNTTYPE_NUTNULL = "对象数量不能为空！";
    public final static String OBJWEIGHTTYPE_NORIGHT = "对象重量类型不正确！";
    public final static String OBJWEIGHT_NUTNULL = "对象重量不能为空！";
}

/**  
 * FileName:   ManagementContext.java  
 * @Description: 此类为评定放行定值编码类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月19日 下午5:03:01  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为评定放行定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月19日 下午5:03:01  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月19日      吴有根                      1.0         1.0 Version  
 */

public class ManagementContext {
    //------------- 获取评定放行数据来源----
    public static final int Power = 1;//授权评定审核
    public static final int People = 2;//人工判定审核
    public static final int Qita = 3;//其他
    //----------结束---------------------
    //审核通过
    public static final String adopt = "1";
    //审核不通过
    public static final String notAdopt = "0";
    //更改施检完成标识
    public static final String INSP_FINISH_FLAG = "1";
    
    public static String dialogPromptMessage="选中的货物为合格，未选中的货物为不合格。";
    
    public static String pdDate="请填写判定日期";
    public static String afteDate="判定日期不能大于当前时间";
    public static String  InspPowerPass="授权评定完成";
    public static String  InspPowerPassBack="退回完成";
     
     public static String InspDeclYes="1";//人工判定合格
     public static String InspDeclNo="0";//人工判定不合格
     
     public static String sucess="0";//成功
     public static String sence="1";//查验
     public static String senceName="需进行现场查验";
     public static String send="2";//送检
      public static String sendName="需送检的货物未送检";
     public static String senceSend="3";//查验送检
     public static String senceSendName="需进行查验送检";//查验送检
     
     public static String senceFJ="辅施检未完成";//查验送检
     public static String senceZJ="主施检未完成";//查验送检
    
     public static String FEEDBACK="1";
}

/**  
 * FileName:    MobileCommContext.java 
 * @Description: 移动端基础定值编码类  
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-5-13 下午3:18:56  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 移动端基础定值编码类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-5-13 下午3:18:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-13     才江男                      1.0         1.0 Version 
 * 2017-5-26     才江男                      1.0         结果查验流程状态
 * 2017-5-26     魏波                           1.0         增加流程状态与环节的代码和名称
 * 2017-5-26     才江男                      1.0         审核不通过
 * 2017-5-27     魏波                           1.0         修改分单退单状态码
 * 2017-6-16     才江男                      1.0         增加送检，抽样，回写流程
 * 2017-6-16     才江男                      1.0         已数据回写
 * 2017-7-18     才江男                      1.0         文件服务器地址
 */

public class MobileCommContext {
	
	/**
     * *****************环节定义 开始*******************
     */
	 /**
     * 手工报检
     */
    public static final String SELF_DECL = "10";
    public static final String SELF_DECL_NAME = "手工报检";
 
    /**
     * 机审
     */
    public static final String AUTO_DECL = "11";
    public static final String AUTO_DECL_NAME = "机审";
 
    /**
     * 人审
     */
    public static final String SELF_CHECK = "12";
    public static final String SELF_CHECK_NAME = "人审";
    /**
     * 报检受理
     */
    public static final String DECL = "13";
    public static final String DECL_NAME = "报检受理";
    /**
     * 分单
     */
    public static final String SUBMENU = "14";
    public static final String SUBMENU_NAME = "分单";
    /**
     * 施检审单
     */
    public static final String INS = "15";
    public static final String INS_NAME = "施检审单";
    /**
     * 现场查验
     */
    public static final String SPOT = "16";
    public static final String SPOT_NAME = "现场查验";
    /**
     * 送检
     */
    public static final String SEND = "17";
    public static final String SEND_NAME = "送检";
    /**
     * 结果登记
     */
    public static final String RESULT = "31";
    public static final String RESULT_NAME = "结果登记";
    /**
     * 施检员复审
     */
    public static final String INSP_AUDIT = "32";
    public static final String INSP_AUDIT_NAME = "审核环节";
//    /**
//     * 科长审核
//     */
//    public static final String DEPT_AUDIT = "19";
//    public static final String DEPT_AUDIT_NAME = "科长审核";
//    /**
//     * 处长审核
//     */
//    public static final String SECT_AUDIT = "20";
//    public static final String SECT_AUDIT_NAME = "处长审核";
    /**
     * 综合评定
     */
    public static final String EVALUATE = "18";
    public static final String EVALUATE_NAME = "综合评定";
    /**
     * *****************环节定义 结束*******************
     */
    
    
    /**
     * *****************状态定义 开始*******************
     */

    /**
     * 待施检
     */
    public static final String WAIT_INS = "1007";
    public static final String WAIT_INS_NAME = "待施检";
    /**
     * 待受理
     */
    public static final String WAIT_DECL = "1006";
    public static final String WAIT_DECL_NAME = "待受理";
    /**
     * 待分单
     */
    public static final String PUMP_GROUP = "1017";
    public static final String PUMP_GROUP_NAME = "待分单";
    /**
     * 待施检审单
     */
    public static final String WAIT_INS_CHECK = "1018";
    public static final String WAIT_INS_CHECK_NAME = "待审单";
    /**
     * 待查验
     */
    public static final String WAIT_CHECK = "1019";
    public static final String WAIT_CHECK_NAME = "待查验";
    /**
     * 已查验
     */
    public static final String CHECKED = "1020";
    public static final String CHECKED_NAME = "已查验";
    /**
     * 已抽样
     */
    public static final String HAVE_SAMPLE = "1021";
    public static final String HAVE_SAMPLE_NAME = "已抽样";
    
    /**
     * 已送检
     */
    public static final String SUBMIT = "1022";
    public static final String SUBMIT_NAME = "已送检";
    /**
     * 待登记
     */
    public static final String WAIT_INS_RESULT = "1042";
    public static final String WAIT_INS_RESULT_NAME = "待登记";
    /**
     * 已登记
     */
    public static final String INS_RESULT = "1043";
    public static final String INS_RESULT_NAME = "已登记";
    /**
     * 待施检员复审
     */
    public static final String WAIT_INSP_AUDIT = "1044";
    public static final String WAIT_INSP_AUDIT_NAME = "待审核";
    /**
     * 待科长审核
     */
    public static final String WAIT_DEPT_AUDIT = "1045";
    public static final String WAIT_DEPT_AUDIT_NAME = "待科长审核";
    /**
     * 待处长审核
     */
    public static final String WAIT_SECT_AUDIT = "1046";
    public static final String WAIT_SECT_AUDIT_NAME = "待处长审核";
    /**
     * 待数据回写
     */
    public static final String WAIT_SEND_DATA_BACK = "1047";
    public static final String WAIT_SEND_DATA_BACK_NAME = "待数据回写";
    /**
     * 待综合评定
     */
    public static final String WAIT_VER_APP = "1037";
    public static final String WAIT_VER_APP_NAME = "待综合评定";
    /**
     * 已综合评定
     */
    public static final String VER_APP_RESULT = "1048";
    public static final String VER_APP_RESULT_NAME = "已综合评定";
    /**
     * 综合评定成功
     */
    public static final String VER_APP_Y = "1023";
    public static final String VER_APP_Y_NAME = "综合评定成功";
    /**
     * 综合评定失败
     */
    public static final String VER_APP_N = "1024";
    public static final String VER_APP_N_NAME = "综合评定失败";
    /**
     * 分单退单
     */
    public static final String PUMP_GROUP_N = "1053";
    public static final String PUMP_GROUP_N_NAME = "分单退单";
    /**
     * 施检审单退单
     */
    public static final String INS_CHECK_N = "1014";
    public static final String INS_CHECK_N_NAME = "审单退单";
    /**
     * 现场查验退单
     */
    public static final String CHECK_N = "1049";
    public static final String CHECK_N_NAME = "查验退单";
    /**
     * 结果登记退单
     */
    public static final String INS_RESULT_N = "1050";
    public static final String INS_RESULT_N_NAME = "结果登记退单";
    /**
     * 结束查验
     */
    public static final String END_SCENE = "1051";
    public static final String END_SCENE_NAME = "结束查验";
    /**
     * 审核不通过
     */
    public static final String AUDIT_FAIL = "1052";
    public static final String AUDIT_FAIL_NAME = "审核不通过";
    
    /**
     * 已数据回写
     */
    public static final String SEND_DATA_BACK = "1054";
    public static final String SEND_DATA_BACK_NAME = "已数据回写";
    
    
    /**
     * 文件服务器地址标识
     */
    public static final String ATTACH_ADDR = "attachAddr";
    
}

/**  
 * FileName:   RuleContext.java  
 * @Description: 出入境施检规则引擎参数 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月27日 上午10:09:46  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 出入境施检规则引擎参数  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月27日 上午10:09:46  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月27日      吴有根                      1.0         1.0 Version  
 */

public class RuleContext {
    //对比值1
    public static final String COMPARE_VALUE_1 = "1";
    //对比值2
    public static final String COMPARE_VALUE_2 = "2";

}

/**  
 * FileName: SceneContext.java    
 * @Description: 此类为现场查验基础定值类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月17日 下午5:17:10  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为现场查验基础定值类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月17日 下午5:17:10  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月17日      吴有根                      1.0         1.0 Version  
 */

public class SceneContext {

	public final static String PROCEDURE_CODE = "PROCEDURE";
    //货物序号为空定值
    public final static Integer GOODS_NO_NULL_CODE = 1;
   //主辅检标记
    public final static String FLOW_PATH_STATUS_MAIN = "flowPathStatusFlag";
    //拼接的工作内容
    public final static String INSP_COUNT_CODE = "inspCountCodes";
    //当前登录人对应的mag实体
    public final static String INS_DECL_MAG = "insDeclMag";
    //辅检鉴定处理工作内容
    public final static String GOODS_IDENTIFY = "goodsInentify";
     //集装箱检验结果表定值
    public final static String INSCONTAINERRESULTENTITY = "InsContainerResultEntity";
    //木质包装检验结果表定值
    public final static String INSRESULTWOODPACKENTITY = "InsResultWoodpackEntity";
    //货物检验结果表定值
    public final static String INSRESULTGOODSENTITY = "InsResultGoodsEntity";
    
}

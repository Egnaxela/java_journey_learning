/**  
 * FileName:  SwitchContext.java   
 * @Description: 此类为开关基础定值编码类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月18日 下午3:30:11  
 *  
 */  

package com.rongji.eciq.mobile.context;

/**  
 * Description: 此类为开关基础定值编码类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月18日 下午3:30:11  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月18日      吴有根                      1.0         1.0 Version  
 */

public class SwitchContext {
	/**
	 * 施检布控开关代码【insOrder】
	 */
    public static final String INS_ORDER = "insOrder";
    public static final String INS_ORDER_NAME = "施检布控开关";
}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-26 上午11:25:53  
 *  
 */  

package com.rongji.eciq.mobile.controller.decl.query;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itown.rcp.core.utils.CollectionUtils;
import com.rongji.dfish.base.DateUtil;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.OrdInfoSearchVo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.decl.query.OrdInfoSearchModel;
import com.rongji.eciq.mobile.service.decl.query.SurInfoQueryService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo  
 * @version:    1.0  
 * Create at:   2017-5-26 上午11:25:53  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-26      魏波                     1.0         1.0 Version  
 */

@Controller
@RequestMapping("/decl/surinfo")
public class SurInfoQueryController  extends MobileExceptionHandlerController{
	
	@Autowired
	SurInfoQueryService service;
	@Autowired
	private SubAuxiliaryService subService;
	
	/**
	 * 
	* <p>描述:综合查询-布控信息查询</p>
	* @param request
	* @param response
	* @return
	* @author 魏波
	 */
	@RequestMapping(value = "/initSurQuery", method = RequestMethod.GET)
	@ResponseBody
	public DataModel initDeclQuery(HttpServletRequest request,
			HttpServletResponse response){
		DataModel base = MobileHelper.getBaseModel();
		String declNo = request.getParameter("declNo");// 报检号
		if ( StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<OrdInfoSearchVo> Searchvo = service.getOrdInfoSearchVo(declNo);
		List<OrdInfoSearchModel> modelList = new ArrayList<OrdInfoSearchModel>();
		if(CollectionUtils.isNotEmpty(Searchvo)){
			for(OrdInfoSearchVo vo: Searchvo){
				OrdInfoSearchModel model = new OrdInfoSearchModel();
				model.setContDesc(vo.getConcDesc());
				model.setConclusionName(vo.getConclusionName());
				model.setOrderDate(DateUtil.format(vo.getOrderDate(),
						"yyyy-MM-dd"));
				model.setArriveLink(CommonCodeToNameUtils.mobileLinkToName(vo.getArrivLink()));
				if(vo.getEnabled() == null){
					model.setEnableed("");
				}else if(vo.getEnabled().equals("1")){
					model.setEnableed("生效");
				}else if(vo.getEnabled().equals("0")){
					model.setEnableed("不生效");
				}
				
				if(vo.getCensType().equals("M")){
					model.setCentType("机审");
				}else if(vo.getCensType().equals("P")){
					model.setCentType("人审");
				}else if(vo.getCensType().equals("A")){
					model.setCentType("补批查");
				}else if(vo.getCensType().equals("E")){
					model.setCentType("额外");
				}
				
				model.setOrgCodeName(subService.getOrgCodeNameOrgCode(vo.getCensOrg().substring(0,6)));
				modelList.add(model);
			}
		}
		base.setData(modelList);
		return base;
	}

}

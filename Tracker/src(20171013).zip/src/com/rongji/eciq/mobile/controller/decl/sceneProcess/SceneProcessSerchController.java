/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-9 上午11:15:23  
 *  
 */  

package com.rongji.eciq.mobile.controller.decl.sceneProcess;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.decl.query.DclIoDeclModel;
import com.rongji.eciq.mobile.model.decl.sceneProcess.SceneProcessModel;
import com.rongji.eciq.mobile.service.decl.process.DeclProcessSearchStreamService;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;
import com.rongji.system.entity.SysAppProcessLog;

/**  
 * Description: 查验信息查询  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波  
 * @version:    1.0  
 * Modification History:  
 * Date        Author     Version     Description   
 * ------------------------------------------------------------------  
 * 20170927    智文龙                 2.0        处理报检长长号变短号引出的问题。
 */

@Controller
@RequestMapping("/decl/sceneProcess")
public class SceneProcessSerchController extends MobileExceptionHandlerController{

	@Autowired
	private SceneProcessSerchService service;
	@Autowired
	private SubAuxiliaryService subService;
	@Autowired
	private DeclProcessSearchStreamService declService;
	@Autowired
	private DeclNoUtils declNoUtils;
	
	@Resource
	HQLCodeToNameDao dao;
	
	/**
	 * 
	* <p>描述:移动工作流程</p>
	* @param request
	* @param response
	* @return
	* @author 魏波
	 */
	@RequestMapping(value = "/initSceneProcess", method = RequestMethod.GET)
	@ResponseBody
	public DataModel initSceneProcess(HttpServletRequest request,
			HttpServletResponse response){
		DataModel base = MobileHelper.getBaseModel();
		String operDateBegin = request.getParameter("operDateBegin");//开始时间
		String operDateEnd = request.getParameter("operDateEnd");//结束时间
		String processStatus = request.getParameter("processStatus");//状态
		String processNode = request.getParameter("processNode");//环节
		String exeInspOrgCode = request.getParameter("exeInspOrgCode");// 施检机构
		String operCode = request.getParameter("operCode");// 接单员代码
		String declNo = request.getParameter("declNo");// 报检号
		String currentPage = request.getParameter("currentPage");// 当前页号
		
		List<SysAppProcessLog> list = service.getList(declNo, operCode, operDateBegin, operDateEnd, processStatus, processNode, currentPage,exeInspOrgCode);
		List<SceneProcessModel> modelList = new ArrayList<SceneProcessModel>();
		if(CollectionUtils.isNotEmpty(list)){
			for(SysAppProcessLog log : list){
				SceneProcessModel model = new SceneProcessModel();
				model.setDeclNo(log.getDeclNo());
				model.setDeclDate(DateUtil.format(log.getOperDate(),
						"yyyy-MM-dd HH:mm:ss"));
				
				model.setLinkName(CommonCodeToNameUtils.mobileLinkToName(log.getProcessNode()));
				model.setProcessName(CommonCodeToNameUtils.mobileStatusToName(log.getProcessStatus()));
				model.setOperName(log.getOperName());
				model.setOrgName(subService.getOrgCodeNameOrgCode(log.getTreaOrgCode().substring(0,6)));//机构名称
				model.setDeptName(subService.getOrgCodeNameOrgCode(log.getTreaOrgCode()));//部门名称
				modelList.add(model);
			}
		}
		base.setData(modelList);
		return base;
	}
	
	/**
	 * 获取报检单主表信息
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	@RequestMapping(value = "/initProcessStream", method = RequestMethod.GET)
	@ResponseBody
	public DataModel initProcessStream(HttpServletRequest request,
			HttpServletResponse response){
		DataModel base = MobileHelper.getBaseModel();
		String beginDate = request.getParameter("operDateBegin");//开始时间
		String endDate = request.getParameter("operDateEnd");//结束时间
		String processStatus = request.getParameter("processStatus");//状态
		String processNode = request.getParameter("processNode");//环节
		String expImpFlag = request.getParameter("expImpFlag");// 出入境标志
		String exeInspOrgCode = request.getParameter("exeInspOrgCode");// 施检机构
		String receiverDocCode = request.getParameter("receiverDocCode");// 接单员代码receiverDocCode
		String declNo = request.getParameter("declNo");// 报检号
		String declRegName = Utils.getParameter(request, "declRegName");// 报检单位
		String currentPage = request.getParameter("currentPage");// 当前页号
		if (StringUtils.isEmpty(exeInspOrgCode)
				|| StringUtils.isEmpty(receiverDocCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
		//----------------------------------短号变长号--------------------------------------------------
		List<DclIoDeclModel> modelList = new ArrayList<DclIoDeclModel>();
		if(StringUtils.isNotEmpty(declNo) && declNo.length() != 15){
		}else{
			List<DclIoDeclEntity> list = declService.getSubAuditList(exeInspOrgCode, receiverDocCode, declNo, declRegName, currentPage,beginDate,endDate);
			for(DclIoDeclEntity entity:list){
				DclIoDeclModel model = new DclIoDeclModel();
				model.setDeclNo(entity.getDeclNo());
				model.setDeclDate(DateUtil.format(entity.getDeclDate(),
						"yyyy-MM-dd"));
				model.setDeclCodeName(CommonCodeToNameUtils.declCodeToName(entity.getDeclCode()));
				model.setLinkName(CommonCodeToNameUtils.mobileLinkToName(entity.getProcessLink()));
				model.setProcessName(CommonCodeToNameUtils.mobileStatusToName(entity.getProcessStatus()));
				model.setTradeCountryCode(dao.getTradeCountryNameByCode(entity.getTradeCountryCode()));
				modelList.add(model);
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(modelList);
		base.setData(vo);
		return base;
	}
}

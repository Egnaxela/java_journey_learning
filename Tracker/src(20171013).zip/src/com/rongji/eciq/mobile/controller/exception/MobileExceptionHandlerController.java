package com.rongji.eciq.mobile.controller.exception;




import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


import com.fasterxml.jackson.databind.ObjectMapper;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;


import com.rongji.dfish.framework.ClusterIdGetter;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.eciq.entity.EciqExceptionLog;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.utils.MobileHelper;







public class MobileExceptionHandlerController  extends MultiActionController {
	
	
	@ExceptionHandler
	@ResponseBody
    public void exception(Exception e,HttpServletRequest request,HttpServletResponse response) {
	   e.printStackTrace();
	   handleMobileException(response);
	   try {
			saveException(e,request);
	   } catch (Exception e1) {
		   e1.printStackTrace();
	   }
	}
	
   
   
   private void saveException(Exception e,HttpServletRequest request) throws Exception{
	   PubCommonDAO dao =  FrameworkHelper.getDAO();
	   StringWriter writer = new StringWriter();
	   e.printStackTrace(new PrintWriter(writer));
	   EciqExceptionLog log = new EciqExceptionLog();
	   log.setLogId(ClusterIdGetter.getInstance().getNewId());
	   log.setLogTime(new Date());
	   StringBuffer logUrl = request.getRequestURL();
	   log.setLogUrl(logUrl.toString());
	   log.setLogIp(getIpAddr(request));
	   log.setLogContent(writer.toString());
	   Map<String, String> argsMap = getArgsMap(request);
	   if(Utils.notEmpty(argsMap)){
		   log.setLogParam( new ObjectMapper().writeValueAsString(argsMap));
	   }
	   log.setLogUser(MobileHelper.getLoginUser(request));
	   dao.saveObject(log);
 }

   
   private  static String getIpAddr(HttpServletRequest request) {
		try {
			 String ip = request.getHeader("x-forwarded-for");
			    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			    ip = request.getHeader("Proxy-Client-IP");
			    }
			    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			       ip = request.getHeader("WL-Proxy-Client-IP");
			    }
			    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			       ip = request.getRemoteAddr();
			    }
			    return ip;
		} catch (Exception e) {
			// TODO: handle exception
		}
	    return "";
	}
   
   
	public static Map<String, String> getArgsMap(HttpServletRequest request) {
		Map<String, String> argsMap = new LinkedHashMap<String, String>();
		try {
			Map properties = request.getParameterMap();
			if (properties != null) {
				Iterator entries = properties.entrySet().iterator();
				boolean isGet = "GET".equalsIgnoreCase(request.getMethod());
			    while (entries.hasNext()) {
			    	Map.Entry entry = (Map.Entry) entries.next();
			        Object valueObj = entry.getValue();
			        String name = (String) entry.getKey();
			        if (Utils.notEmpty(name) && valueObj != null) {
				    	String value = "";
			        	if(valueObj instanceof String[]){
				            String[] values = (String[])valueObj;
				            if (Utils.notEmpty(values)) {
								for (String v : values) {
									if (Utils.notEmpty(v)) {
										if (isGet) {
											v = new String(v.getBytes("ISO-8859-1"), "UTF-8");
										}
										value += "," + v;
									}
								}
								if (Utils.notEmpty(value)) {
									value = value.substring(1);
								}
							}
				        } else {
				            value = valueObj.toString();
				            if (isGet && Utils.notEmpty(value)) {
				            	value = new String(value.getBytes("ISO-8859-1"), "UTF-8");
							}
				        }
			        	if (Utils.notEmpty(value)) {
			        		argsMap.put(name, value);
						}
					}
			    }
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return argsMap;
	}
   
   private  void handleMobileException(HttpServletResponse response){
	   ObjectMapper objectMapper = new ObjectMapper();
	   DataModel baseModel = MobileHelper.getBaseModel("服务端异常");
	   baseModel.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	   try {
		   String json = objectMapper.writeValueAsString(baseModel);
		   response.setContentType("text/json;UTF-8");
		   PrintWriter writer = response.getWriter();
		   writer.write(json);
		   writer.flush();
		   writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
   }

}

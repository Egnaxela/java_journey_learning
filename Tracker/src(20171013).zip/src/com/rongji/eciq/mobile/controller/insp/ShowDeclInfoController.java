/**  
 * FileName:ShowDeclInfoController.java
 * @Description: 查看报检信息 controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.controller.insp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsPackEntity;
import com.rongji.eciq.mobile.entity.ZBbdHsCode;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.DclIoDeclContModel;
import com.rongji.eciq.mobile.model.insp.DclIoDeclGoodsModel;
import com.rongji.eciq.mobile.model.insp.DclIoDeclModel;
import com.rongji.eciq.mobile.model.insp.DetailInfoModel;
import com.rongji.eciq.mobile.service.insp.ShowDeclInfoService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**
 * 
 * Description: 查看报检信息 controller  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-12 下午2:11:52  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      吴有根                     1.0         1.0 Version
 * 2017-5-23      李晨阳                     1.0         将报检信息整合放进DetailInfoModel
 * 2017-6-07      魏波                          1.0         添加对hs第一计量单位的校验
 * 2017-07-07     才江男                      1.0         判断是否需要选择拼箱标志
 * 2017-09-01     夏晨琳                      2.0         添加手机端查询全部货物信息集合
 */
@Controller
@RequestMapping("/insp/common")
public class ShowDeclInfoController extends MobileExceptionHandlerController {
	
	@Autowired 
	private ShowDeclInfoService service;

	@Resource 
	private HQLCodeToNameDao codeToNameUtils;
	@RequestMapping(value="/showDeclInfo",method=RequestMethod.GET)
	@ResponseBody
	public DataModel showDeclInfo(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=Utils.getParameter(request, "declNo");//报检单号
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String currentPage=request.getParameter("currentPage");
		String isPhone = request.getParameter("isPhone");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(expImpFlag)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		DetailInfoModel DIModel=new DetailInfoModel();
		//报检单基础数据信息
		List<DclIoDeclEntity> queryList=service.queryDclIoDeclList(declNo,expImpFlag);
		ArrayList<DclIoDeclModel> dclIoDeclModelList=new ArrayList<DclIoDeclModel>();
		if(Utils.notEmpty(queryList)){
			dclIoDeclModelList.ensureCapacity(queryList.size());
			for(DclIoDeclEntity entity:queryList){
				DclIoDeclModel model=new DclIoDeclModel();
				model.setDeclNo(entity.getDeclNo());//报检单号
				model.setDeclDate(DateUtil.format(entity.getDeclDate(), "yyyy-MM-dd"));//报检日期
				model.setDeclRegName(entity.getDeclRegName());//报检单位
				if(StringUtils.equals(expImpFlag,"1")){
					model.setConsigneeCode(entity.getConsigneeCode());//收货人代码
					model.setConsigneeCname(entity.getConsigneeCname());//收货人名称(中文)
				}else if (StringUtils.equals(expImpFlag,"2")) {
					model.setConsignorCname(entity.getConsignorCname());//发货人名称(中文)
					model.setConsignorAddr(entity.getConsignorAddr());//发货人地址
				}else{
					
				}
				
				model.setTradeModeCode(codeToNameUtils.getTradeModeNameByCode(entity.getTradeModeCode()));//贸易方式
				model.setContractNo(entity.getContractNo());//合同号
				model.setOutDeclCode(codeToNameUtils.getInspBasCatNameByCode(entity.getDeclCode(),"LeaveDeclType"));//出境报检类别
				model.setInDeclCode(codeToNameUtils.getInspBasCatNameByCode(entity.getDeclCode(),"ImpDeclType"));//入境报检类别
				model.setDespCtryCode(codeToNameUtils.getTradeCountryNameByCode(entity.getDespCtryCode()));//启运国家/地区
				model.setTradeCountryCode(codeToNameUtils.getTradeCountryNameByCode(entity.getTradeCountryCode()));//贸易国家/地区
				model.setTransModeCode(codeToNameUtils.getTransModeNameByCode(entity.getTransModeCode()));//运输方式
				model.setMarkNo(entity.getMarkNo());//标记及号码
				model.setAttaCollectName(entity.getAttaCollectName());//随附单据
				model.setAppCertName(entity.getAppCertName());//所需单证
				model.setOrgCode(codeToNameUtils.getOrgNameByCode(entity.getOrgCode()));//报检地
				model.setVsaOrgCode(codeToNameUtils.getOrgNameByCode(entity.getVsaOrgCode()));//领证地
				model.setPurpOrgCode(codeToNameUtils.getOrgNameByCode(entity.getPurpOrgCode()));//目的地机构
				model.setPurpDeptCode(codeToNameUtils.getOrgNameByCode(entity.getPurpDeptCode()));//目的地部门
				model.setInspOrgCode(codeToNameUtils.getOrgNameByCode(entity.getInspOrgCode()));//口岸机构
				model.setExcInspDeptCode(codeToNameUtils.getOrgNameByCode(entity.getExcInspDeptCode()));//口岸部门
				model.setSpeclInspQuraRe(entity.getSpeclInspQuraRe());//特殊要求
				dclIoDeclModelList.add(model);
			}
			
			DIModel.setDclIoDeclList(dclIoDeclModelList);
		}
		
		//货物信息
		List<DclIoDeclGoodsEntity> queryGoodsList = null;
		if("1".equals(isPhone)){
			queryGoodsList = service.queryDclIoDeclGoodsList(declNo,expImpFlag);
		}else{
			queryGoodsList =service.queryDclIoDeclGoodsList(declNo,expImpFlag,currentPage);
		}
		ArrayList<DclIoDeclGoodsModel> dclIoDeclGoodsModelList=new ArrayList<DclIoDeclGoodsModel>();
		if(Utils.notEmpty(queryGoodsList)){
			dclIoDeclGoodsModelList.ensureCapacity(queryGoodsList.size());
			for(DclIoDeclGoodsEntity entity:queryGoodsList){
				DclIoDeclGoodsModel model=new DclIoDeclGoodsModel();
				model.setDeclNo(entity.getDeclNo());
				model.setGoodsNo((entity.getGoodsNo()+"").substring(0,(entity.getGoodsNo()+"").indexOf(".")));//货物序号
				model.setDeclGoodsCname(entity.getDeclGoodsCname());//货物名称
				model.setProdHsCode(entity.getProdHsCode());//HS 编码
				model.setHsCodeDesc(entity.getHsCodeDesc());//HS名称描述
				model.setCiqCode(entity.getCiqCode());//ciq代码
				model.setCiqName(entity.getCiqName());//ciq名称
				model.setGoodsTotalVal(entity.getGoodsTotalVal()+"");//货物总值
				model.setCurrency(codeToNameUtils.getMeasurementNameByCode(entity.getCurrency(),"CurrencyType"));//货币单位
				model.setQty(entity.getQty()+"");//数量
				model.setQtyMeasUnit(codeToNameUtils.getMeasurementNameByCode(entity.getQtyMeasUnit(), "Measurement"));//数量计量单位
				model.setWeight(entity.getWeight()+"");//重量
				model.setWtMeasUnit(codeToNameUtils.getMeasurementNameByCode(entity.getWtMeasUnit(), "Measurement"));//重量计量单位
				model.setPurpose(codeToNameUtils.getCntnrModeByCode("UsePurpose",entity.getPurpose()));//用途
				DclIoDeclGoodsPackEntity pack =service.getDclGoodsPackName(declNo,model.getGoodsNo());
				model.setPackqty((pack.getPackQty()+"").substring(0,(pack.getPackQty()+"").indexOf(".")));
				model.setPackCatgName(pack.getPackCatgName());
				
				//查看第一计量单位
				ZBbdHsCode zBbdHsCode = service.queryZBbdHsCode(entity.getProdHsCode());
				
				if(zBbdHsCode!=null){
					if(zBbdHsCode.getMeasureTypeCode().equals("2")){//重量
						BigDecimal slText = new BigDecimal(String.format("%.6f", entity.getStdWeight()));
						model.setStdWeight(Double.parseDouble(slText+""));
						model.setStdWeightUnitCode(codeToNameUtils.getMeasurementNameByCode(entity.getStdWeightUnitCode(),"Measurement"));
					}else{//数量
						 BigDecimal slText = new BigDecimal(String.format("%.6f", entity.getStdQty()));
						 model.setStdWeight(Double.parseDouble(slText+""));
						 model.setStdWeightUnitCode(codeToNameUtils.getMeasurementNameByCode(entity.getStdQtyUnitCode(),"Measurement"));
					}
				}else{//数量
					BigDecimal slText = new BigDecimal(String.format("%.6f", entity.getStdQty()));
					model.setStdWeight(Double.parseDouble(slText+""));
					model.setStdWeightUnitCode(codeToNameUtils.getMeasurementNameByCode(entity.getQtyMeasUnit(),"Measurement"));
				}
				
//				model.setStdWeight(entity.getStdWeight());//标准重量
//				model.setStdWeightUnitCode(codeToNameUtils.getMeasurementNameByCode(entity.getStdWeightUnitCode(),"Measurement"));//标准重量单位
				model.setOriCtryCode(codeToNameUtils.getTradeCountryNameByCode(entity.getOriCtryCode()));//原产国代码
				model.setOrigPlaceCode(codeToNameUtils.getOrigPlaceNameByCode(entity.getOrigPlaceCode()));//原产地区
				model.setPlaceCode(codeToNameUtils.getplaceNameByCode(entity.getOrigPlaceCode()));//产地
				model.setMnufctrRegName(entity.getMnufctrRegName());
				dclIoDeclGoodsModelList.add(model);
			}
			
			DIModel.setDclIoDeclGoodsList(dclIoDeclGoodsModelList);

		}
		
		
		//集装箱信息
		List<DclIoDeclContEntity> queryContList=service.queryDclIoDeclContList(declNo,expImpFlag);
		ArrayList<DclIoDeclContModel> dclIoDeclContModelList=new ArrayList<DclIoDeclContModel>();
		if(Utils.notEmpty(queryContList)){
			dclIoDeclContModelList.ensureCapacity(queryContList.size());
			String clFlag = "0";
			for(DclIoDeclContEntity entity:queryContList){
				DclIoDeclContModel model=new DclIoDeclContModel();
				model.setDeclNo(entity.getDeclNo());
				model.setSeqNo((entity.getSeqNo()+"").substring(0, (entity.getSeqNo()+"").indexOf(".")));
				model.setCntnrModeCode(codeToNameUtils.getMeasurementNameByCode(entity.getCntnrModeCode(), "ContainerStandard"));//集装箱规格
				model.setContainerQty((entity.getContainerQty()+"").substring(0, (entity.getContainerQty()+"").indexOf(".")));//集装箱数量
				model.setContNo(entity.getContNo());//号码
				List<DclIoDeclContDetailEntity> details = service.isNeedLclFlag(entity.getDeclNo(), entity.getContId());
				if(CollectionUtils.isEmpty(details)) {
					model.setLclFlag("0");// 拼箱标志
				} else {
					for (DclIoDeclContDetailEntity dclIoDeclContDetailEntity : details) {
						if("1".equals(dclIoDeclContDetailEntity.getLclFlag())) {
							clFlag = "1";
							break;
						}
					}
					model.setLclFlag(clFlag);// 拼箱标志
					model.setDetails(details);//集装箱明细
				}
				dclIoDeclContModelList.add(model);
			}
			
			DIModel.setDclIoDeclContList(dclIoDeclContModelList);
		}
		base.setData(DIModel);
		return base;
	}
	
}

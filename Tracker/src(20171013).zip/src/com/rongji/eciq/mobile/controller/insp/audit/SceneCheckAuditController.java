package com.rongji.eciq.mobile.controller.insp.audit;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.audit.InsDeclReviewModel;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.audit.SceneCheckAuditService;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;
import com.rongji.eciq.server.entity.InsDeclMag;
import com.rongji.eciq.server.entity.InsDeclReview;
import com.rongji.eciq.server.entity.InsDeclReviewSt;
import com.rongji.system.entity.SysAppProcessLog;

/**  
 * Description:   施检员复审，科长审核，处长审核
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-27 下午2:37:45  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-27    才江男                      1.0         1.0 Version  
 * 2017-05-04            才江男		1.0                            增加审核更新及查找审核记录    
 * 2017-05-04            才江男		1.0        	 审核时校验是否已审核  
 * 2017-05-05            才江男		1.0        	 增加审核状态           
 * 2017-05-11            才江男		1.0        	 审核逻辑放到Service 
 * 2017-05-12            才江男		1.0                            更改审核不通过标志
 * 2017-05-12    魏波                            1.0         根据报检单号查第一条货物的名称
 * 2017-05-15    魏波                            1。0         现场查验退单添加流程日志
 * 2017-05-15    李云龙                         1。0         添加更新报检信息流程环节，流程状态
 * 2017-05-16    魏波                              1.0         审核查询添加出入境标示
 * 2017-05-19            才江男		1.0                            修改提示     
 * 2017-05-24    才江男                     1.0         增加返回报检号    
 * 2017-05-26    才江男                     1.0         更新流程环节及流程状态        
 * 2017-05-27    才江男                     1.0         审核记录非空校验
 * 2017-06-16    才江男                     1.0         增加审核参数
 * 2017-06-16    才江男                     1.0         结果登记评定
 * 2017-07-03    才江男                     1.0         审核通过，审核意见非必填
 * 2017-09-15    才江男                     2.0         增加接单员代码
 */

@Controller
@RequestMapping("/insp/sceneAudit")
public class SceneCheckAuditController extends MobileExceptionHandlerController{

	@Autowired
	private SceneCheckAuditService service;
	@Resource
	private HQLCodeToNameDao codeToNameUtils;
	@Autowired
	private SubAuditService subService;
	@Autowired
	private SubOrReasService reaService;
	@Resource
	SceneProcessSerchService processService;
	@Resource
	StatusControlUtils statusControlUtils;
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	@Autowired
	private DeclNoUtils declNoUtils;
	
	/**
	 * 审核界面初始化数据
	 * @param flag   	        审核环节
	 * @param exeInspOrgCode   施检机构代码
	 * @param declNo		       报检单号
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSceneTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSceneTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String orgCode=request.getParameter("orgCode");//施检机构
		String declNo=request.getParameter("declNo");//报检号
		String flag=request.getParameter("flag");//审核标志
		String currentPage=request.getParameter("currentPage");//当前页号
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志 
		if(StringUtils.isEmpty(flag)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
//			UserInfo user = new UserInfo();
//			user.setUserCode(userCode);
//			SysUser sysUser = subOrReasDao.getSysUser(userCode);
//			if (sysUser != null) {
//				user.setCompanyCode(sysUser.getOrgCode());
//				user.setUserName(sysUser.getUserName());
//			}
//			String longDeclNo = "";
//			if (expImpFlag.equals("1")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_IN, user);
//			} else if (expImpFlag.equals("2")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_OUT, user);
//			}
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
        //----------------------------------短号变长号--------------------------------------------------
		
		List<InsDeclMag> queryMagList=service.getMagList(flag, orgCode, declNo, currentPage,expImpFlag);
		
		ArrayList<SceneCheckInitTableModel> list=new ArrayList<SceneCheckInitTableModel>();
		
		if(!CollectionUtils.isEmpty(queryMagList)){
			list.ensureCapacity(queryMagList.size());
			for(InsDeclMag entity:queryMagList){
				SceneCheckInitTableModel model=new SceneCheckInitTableModel();
				model.setDeclNo(entity.getDeclNo());

				List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(entity.getDeclNo());
				if(CollectionUtils.isEmpty(dcl)){
					model.setDeclRegName("");
				}else{
					model.setDeclRegName(dcl.get(0).getDeclRegName());
				}
				model.setFlowPathStatus(CommonCodeToNameUtils
						.flowPathStatusToName(entity.getFlowPathStatus()));
				model.setGoodsName(subService.getGoodName(entity.getDeclNo()));
				
				
//				model.setDeclRegName(entity.getDeclRegName());
				model.setFlowPathStatusCode(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
//				model.setGoodsName(entity.getGoodsName());
				if(StringUtils.isNotEmpty(entity.getRemark())){
					model.setTradeCountryCode(entity.getRemark());
				}else{
					model.setTradeCountryCode("");
				}
				model.setDeclDate(DateUtil.format(entity.getDeclDate(), "yyyy-MM-dd"));
				model.setReceiverDocCode(entity.getReceiverDocCode());
				model.setInsRequire(entity.getInspRequire());
				list.add(model);
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(list);
		base.setData(vo);
		return base;
	}
	
	/**
	* <p>描述: 审核记录</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/auditHistoryList",method=RequestMethod.GET)
	@ResponseBody
	public DataModel auditHistoryList(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		List<InsDeclReviewSt> queryMagList=service.getAuditList(declNo);
		
		ArrayList<InsDeclReviewModel> list=new ArrayList<InsDeclReviewModel>();
		if(!CollectionUtils.isEmpty(queryMagList)){
			list.ensureCapacity(queryMagList.size());
			for(InsDeclReviewSt entity:queryMagList){
				InsDeclReviewModel model=new InsDeclReviewModel();
				//审核人
				model.setAuditCode(codeToNameUtils.getUserNameByCode(entity.getAuditCode()));
				String processStatus = entity.getProcessStatus();
				if(CommContext.AUDIT_INSP.equals(processStatus)) {
					processStatus = CommContext.AUDIT_INSP_NAME;
				} else if(CommContext.AUDIT_DEPT.equals(processStatus)) {
					processStatus = CommContext.AUDIT_DEPT_NAME;
				} else if(CommContext.AUDIT_SECT.equals(processStatus)) {
					processStatus = CommContext.AUDIT_SECT_NAME;
				} else if(CommContext.AUDIT_DONE.equals(processStatus)) {
					processStatus = CommContext.AUDIT_DONE_NAME;
				} else {
					processStatus = "";
				}
				//审核环节
				model.setProcessStatus(processStatus);
				//审核时间
				model.setAuditTime(DateUtil.format(entity.getAuditTime(), "yyyy-MM-dd"));
				//审核意见
				model.setAuditAdvice(entity.getAuditAdvice());
				String isAudit = entity.getIsAudit();
				if("2".equals(isAudit)) {
					isAudit = "审核不通过";
				} else {
					isAudit = "审核通过";
				}
				model.setIsAudit(isAudit);
				list.add(model);
			}
		}
		base.setData(list);
		return base;
	}
	
	/**
	* <p>描述: 审核记录</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/submit",method=RequestMethod.POST)
	@ResponseBody
	public DataModel submit(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		String flag=request.getParameter("flag");//审核标志
		String userCode = request.getParameter("userCode");//用户代码
		
		 UserInfo user=new UserInfo();
         user.setUserCode(userCode);
         SysUser sysUser=reaService.getSysUser(userCode);
         
		if(StringUtils.isEmpty(declNo) || StringUtils.isEmpty(flag) || StringUtils.isEmpty(userCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//审核记录
		InsDeclReview declReview = new InsDeclReview();
		declReview.setDeclReviewId(UUIDKeyGeneratorUils.newInstance().generateKey());
		declReview.setDeclNo(declNo);
		declReview.setProcessStatus(flag);
		declReview.setOperTime(new Date());
		declReview.setOperCode(userCode);
		//保存审核记录
		service.saveAudit(declReview);
		
		//保存移动流程日志
		SysAppProcessLog log = new SysAppProcessLog();
		log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		log.setDeclNo(declNo);
		if("1".equals(flag)){
			log.setProcessStatus(MobileCommContext.WAIT_INSP_AUDIT);
			log.setStatusMemo(MobileCommContext.WAIT_INSP_AUDIT_NAME);
			statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_INSP_AUDIT, userCode);
		}else if("2".equals(flag)){
			log.setProcessStatus(MobileCommContext.WAIT_DEPT_AUDIT);
			log.setStatusMemo(MobileCommContext.WAIT_DEPT_AUDIT_NAME);
			statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_DEPT_AUDIT, userCode);
		}else if("3".equals(flag)){
			log.setProcessStatus(MobileCommContext.WAIT_SECT_AUDIT);
			log.setStatusMemo(MobileCommContext.WAIT_SECT_AUDIT_NAME);
			statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_SECT_AUDIT, userCode);
		}
		
		log.setProcessNode(MobileCommContext.INSP_AUDIT);
		log.setNodeMemo(MobileCommContext.INSP_AUDIT_NAME);
		if (sysUser != null) {
			log.setOperCode(userCode);
			log.setOperName(sysUser.getUserName());
			log.setTreaOrgCode(sysUser.getOrgCode());
		}
//		log.setOperCode(userCode);
//		log.setOperName(user.getUserName());
//		log.setTreaOrgCode(user.getCompanyCode());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		Date newDate;
		try {
			newDate = formatter.parse(dateString);
			log.setOperDate(newDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		processService.savelog(log);
		
		
		DataModel back=MobileHelper.getBaseModel();
		base.setData(back);
		return base;
	}
	
	/**
	* <p>描述: 检查审核记录</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/check",method=RequestMethod.GET)
	@ResponseBody
	public DataModel check(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		InsDeclReview declReview = service.findAuditByDeclNo(declNo);
		DataModel back=MobileHelper.getBaseModel();
		if(!(null == declReview || CommContext.AUDIT_DONE.equals(declReview.getProcessStatus()))) {
			back.setMsg("请先施检审核");
		}
		
		base.setData(back);
		return base;
	}
	
	/**
	* <p>描述: 检查审核记录</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/checkSubmit",method=RequestMethod.GET)
	@ResponseBody
	public DataModel checkSubmit(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		InsDeclReview declReview = service.findAuditByDeclNo(declNo);
		DataModel back=MobileHelper.getBaseModel();
		if((null != declReview) && ("2".equals(declReview.getIsAudit()))) {
			back.setMsg("审核不通过");
			base.setData(back);
			return base;
		}
		if(!(null == declReview || CommContext.AUDIT_DONE.equals(declReview.getProcessStatus()))) {
			back.setMsg("请先施检审核");
		}
		
		base.setData(back);
		return base;
	}
	
	/**
	* <p>描述: 审核</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/audit",method=RequestMethod.POST)
	@ResponseBody
	public DataModel audit(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String advice = request.getParameter("advice");//审核意见
		String declNo = request.getParameter("declNo");//报检单号
		String flag = request.getParameter("flag");//审核环节
		String userCode = request.getParameter("userCode");//审核人
		String orgCode = request.getParameter("orgCode");
		String status = request.getParameter("status");//审核状态
		String picked = request.getParameter("picked");//提交审核
		String batch = request.getParameter("batch");//批量审核
		String appFlag = request.getParameter("appFlag");//移动查验版本-手机版本[mobile]
		if(StringUtils.isEmpty(declNo) || StringUtils.isEmpty(status) || StringUtils.isEmpty(flag) || StringUtils.isEmpty(userCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		if("0".equals(status) && StringUtils.isEmpty(advice)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//审核
		DataModel back = service.findAuditByDeclNo(batch, request, response, declNo, flag, advice, userCode, status, orgCode, picked, appFlag);
		
		base.setData(back);
		return base;
	}
	
	/**
	* <p>描述: 提交评定</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/eval",method=RequestMethod.POST)
	@ResponseBody
	public DataModel eval(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String isRequire = request.getParameter("require");//审核意见
		String declNo = request.getParameter("declNo");//报检单号
		String flowPathStatus = request.getParameter("flowPathStatus");//审核环节
		String userCode = request.getParameter("userCode");//审核人
		String orgCode = request.getParameter("orgCode");
		if(StringUtils.isEmpty(declNo) || StringUtils.isEmpty(flowPathStatus) || StringUtils.isEmpty(orgCode) || StringUtils.isEmpty(userCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//审核
		DataModel back = service.registerEval(request, response, flowPathStatus, isRequire, userCode, orgCode, declNo);
		
		base.setData(back);
		return base;
	}
	
}

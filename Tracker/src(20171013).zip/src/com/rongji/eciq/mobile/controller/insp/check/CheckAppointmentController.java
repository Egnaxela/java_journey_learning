/**  
 * FileName: CheckAppointmentController.java    
 * @Description: 查验预约Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年6月27日 下午5:46:49  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.check;


import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.InsCheckAppointInfoEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.check.CheckAppointBaseInfoModel;
import com.rongji.eciq.mobile.model.insp.check.CheckAppointmentInfoModel;
import com.rongji.eciq.mobile.service.insp.check.CheckAppointmentService;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description: 查验预约Controller  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年6月27日 下午5:46:49  
 *  
 * Modification History:  
 * Date      	   Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-06-27      吴有根                              1.0         1.0 Version  
 * 2017-07-07      李云龙                              1.0         添加保存，提交，查看，删除，撤销等方法 
 * 2017-07-12      才江男                              1.0         解决中文乱码
 * 2017-07-13      李云龙                               1.0         查看类型的放在一个方法中
 * 2017-07-19      李云龙                               1。0         修改审批保存方法
 * 2017-07-19      李云龙                               1。0         修改初始化查验预约方法
 * 2017-07-21      吴有根                               1.0         增加根据报检单位注册号带出企业基本信息
 * 2017-07-28      李云龙                                1.0         添加必填项校验
 */

@Controller
@RequestMapping("/insp/check")
public class CheckAppointmentController extends MobileExceptionHandlerController {

	@Autowired
	private CheckAppointmentService checkAppointService;
	@Resource
	private HQLCodeToNameDao codeToNameUtils;

	/**
	 * 
	 * <p>
	 * 描述:初始化查验预约-查询table数据
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 吴有根
	 */
	@RequestMapping(value = "/initCheckAppointQuery", method = RequestMethod.GET)
	@ResponseBody
	public DataModel initCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		
		String declNo = request.getParameter("declNo");// 报检号
		String declRegNo = request.getParameter("declRegNo");// 检单位注册号
		String declRegName = Utils.getParameter(request, "declRegName");// 报检单位名称
		String startApplyTime = request.getParameter("startApplyTime");// 申请时间-起始时间
		String endApplyTime = request.getParameter("endApplyTime");// 申请时间-结束时间
		String applyStatus = request.getParameter("applyStatus");// 申请状态(0:待受理、1:已受理、3:待审批、4:已审批)
		String acceptResult = request.getParameter("acceptResult");// 受理结果(0:未审批 1:同意   2:不同意)
		String currentPage = request.getParameter("currentPage");// 当前页
		String exeInspOrgCode = request.getParameter("exeInspOrgCode");// 施检机构--个人默认条件 
		String entOrgCode=request.getParameter("entOrgCode");//组织机构代码 --企业默认条件
		String type=request.getParameter("type");//查询数据范围：1：待受理与已受理的；2：除待上报的数据
        
		
/*		if (StringUtils.isEmpty(entOrgCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}*/


		List<InsCheckAppointInfoEntity> list = checkAppointService.getAppointInfo(declNo, declRegNo, declRegName,
				startApplyTime, endApplyTime, applyStatus, acceptResult, exeInspOrgCode,type, currentPage,entOrgCode);
		ArrayList<CheckAppointmentInfoModel> modelList = new ArrayList<CheckAppointmentInfoModel>();
		if (Utils.notEmpty(list)) {
			modelList.ensureCapacity(list.size());
			for (InsCheckAppointInfoEntity entity : list) {
				CheckAppointmentInfoModel model = new CheckAppointmentInfoModel();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(model, entity);
					if(entity.getApplyTime()!=null){
						model.setApplyTime(DateUtil.format(entity.getApplyTime(), "yyyy-MM-dd HH:mm:ss"));// 申请时间
					}
					if(entity.getAppointCheckDate() !=null){
						model.setAppointCheckDate(DateUtil.format(entity.getAppointCheckDate(), "yyyy-MM-dd HH:mm:ss"));// 预约时间
					}
					if(entity.getCheckDate() !=null){
						model.setCheckDate(DateUtil.format(entity.getCheckDate(), "yyyy-MM-dd"));// 查验日期
					}
					
					model.setApplyStatus(CommonCodeToNameUtils.getApplyStatusName(entity.getApplyStatus()));// 申请状态
					model.setApplyType(CommonCodeToNameUtils.getApplyTypeName(entity.getApplyType()));// 申请类型
					model.setAcceptResult(CommonCodeToNameUtils.getAcceptResultName(entity.getAcceptResult()));// 受理结果

				} catch (Throwable e) {
					e.printStackTrace();
				}
				modelList.add(model);
			}
		}
		base.setData(modelList);
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:查验预约-受理&审核</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value = "/checkAppointAccept", method = RequestMethod.POST)
	@ResponseBody
	public DataModel CheckAppointAccept(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String info=Utils.getParameter(request, "InsCheckAppointInfoEntity");
		Gson gson=new GsonBuilder().create();
		InsCheckAppointInfoEntity entity=gson.fromJson(info, InsCheckAppointInfoEntity.class);
		if(entity==null){
			base.setData("不存在操作对象");
			return base;
		}
		
		if(StringUtils.isEmpty(entity.getApplyId())){
			entity.setApplyId(UUIDKeyGeneratorUils.newInstance().generateKey());
		}
		checkAppointService.saveInsCheckAppointInfoEntity(entity);
		base.setData("操作成功");
		return base;
	}

	/**
	 * 
	 * <p>
	 * 描述:保存查验预约信息
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "/saveCheckAppointmentApply", method = RequestMethod.POST)
	@ResponseBody
	public DataModel saveCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		DataModel base = MobileHelper.getBaseModel();
		String applyType = request.getParameter("applyType");// 申请类别
		String declNo = request.getParameter("declNo");// 报检号 
		String entOrgCode = request.getParameter("entOrgCode");// 组织机构代码
		String declRegNo = request.getParameter("declRegNo");// 报检单位注册号
		String declRegName =Utils.getParameter(request, "declRegName");// 报检单位名称
		String inspOrgCode = request.getParameter("inspOrgCode");// 施检机构
		String plateNo = request.getParameter("plateNo");// 车牌号
		String contNo = request.getParameter("contNo");// 集装箱号
		String appointCheckPlace = Utils.getParameter(request, "appointCheckPlace");// 预约查验地点
		String appointCheckDate = request.getParameter("appointCheckDate");// 预约日期
		String appointContactPerson = Utils.getParameter(request, "appointContactPerson");// 预约联系人
		String appointContactTel = request.getParameter("appointContactTel");// 预约联系电话
		String remark = Utils.getParameter(request, "remark");// 备注
		
		
		if (StringUtils.isEmpty(applyType) || StringUtils.isEmpty(declNo) || StringUtils.isEmpty(entOrgCode)|| StringUtils.isEmpty(declRegName)
				|| StringUtils.isEmpty(declRegNo)|| StringUtils.isEmpty(appointCheckDate)|| StringUtils.isEmpty(inspOrgCode)
				|| StringUtils.isEmpty(appointCheckPlace)|| StringUtils.isEmpty(appointContactPerson)|| StringUtils.isEmpty(appointContactTel)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
//		if(StringUtils.isNotEmpty(appointContactTel)&&!Pattern.compile("^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,5-9]))\\d{8}$").matcher(appointContactTel).matches()) {
//			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//			base.setMsg(MobileHelper.TEL_FORMAT_ERROR_TIP);
//			return base;
//		}
        
		
		List<InsCheckAppointInfoEntity> list=checkAppointService.getInsCheckAppointInfoEntityList(declNo);
		if(CollectionUtils.isNotEmpty(list)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("该报检单号已经进行查验预约");
			return base;
			
		}
		
		EntBaseInfoEntity entBaseINfoEntity=checkAppointService.getEntBaseInfoEntity(declRegNo);
		if(entBaseINfoEntity==null){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("该报检单位注册号不存在");
			return base;
		}

		String applyId = UUIDKeyGeneratorUils.newInstance().generateKey();
		InsCheckAppointInfoEntity entity = new InsCheckAppointInfoEntity();
		entity.setApplyId(applyId);
		entity.setApplyType(applyType);
		entity.setApplyTime(new Date());
		entity.setDeclNo(declNo);
	//	entity.setApplyNo(checkAppointService.getMaxApplyNo());//申请单号
		entity.setApplyNo(checkAppointService.getApplyNoRul(entOrgCode));//申请单号
		entity.setEntOrgCode(entOrgCode);
		entity.setDeclRegNo(declRegNo);
		entity.setDeclRegName(declRegName);
		entity.setInspOrgCode(inspOrgCode);
		entity.setPlateNo(plateNo);
		entity.setContNo(contNo);
		entity.setAppointCheckPlace(appointCheckPlace);
		entity.setApplyStatus("0");
		entity.setAcceptResult("0");
		entity.setOperDate(new Date());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if(StringUtils.isNotEmpty(appointCheckDate)){
				entity.setAppointCheckDate(sdf.parse(appointCheckDate));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		entity.setAppointContactPerson(appointContactPerson);
		
		if(appointContactTel.length()>20){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("预约联系电话不符合规范");
			return base;
		}
		entity.setAppointContactTel(appointContactTel);
		entity.setRemark(remark);
		checkAppointService.saveInsCheckAppointInfoEntity(entity);
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(applyId);
		return base;

	}
	
	
	
	/**
	 * 
	 * <p>
	 * 描述:初始化查验预约-查询table数据
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 
	 */
	@RequestMapping(value = "/seeCheckAppointQuery", method = RequestMethod.GET)
	@ResponseBody
	public DataModel seeCheckAppointmentApply(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();

		String declNo = request.getParameter("declNo");// 报检号
		if (StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		List<InsCheckAppointInfoEntity> list = checkAppointService
				.getInsCheckAppointInfoEntityList(declNo);
		InsCheckAppointInfoEntity entity = new InsCheckAppointInfoEntity();
		if (CollectionUtils.isNotEmpty(list)) {
			entity = list.get(0);
		}
		CheckAppointmentInfoModel model = new CheckAppointmentInfoModel();
		model.setApplyId(entity.getApplyId());
		model.setApplyType(entity.getApplyType());
		model.setDeclNo(entity.getDeclNo());
		model.setEntOrgCode(entity.getEntOrgCode());
		model.setInspOrgCode(entity.getInspOrgCode());
		model.setInspOrgName(codeToNameUtils.getOrgNameByCode(entity
				.getInspOrgCode()));
		model.setDeclRegNo(entity.getDeclRegNo());
		model.setDeclRegName(entity.getDeclRegName());
		model.setPlateNo(entity.getPlateNo());
		model.setContNo(entity.getContNo());
		model.setAppointCheckPlace(entity.getAppointCheckPlace());
		if (entity.getApplyTime() != null) {
			model.setAppointCheckDate(DateUtil.format(entity.getApplyTime(),
					"yyyy-MM-dd"));
		}
		model.setAppointContactPerson(entity.getAppointContactPerson());
		model.setAppointContactPersonName(codeToNameUtils
				.getUserNameByCode(entity.getAppointContactPerson()));
		model.setAppointContactTel(entity.getAppointContactTel());
		model.setRemark(entity.getRemark());
		model.setApprovalPerson(entity.getApprovalPerson());
		model.setApprovalPersonName(codeToNameUtils.getUserNameByCode(entity
				.getApprovalPerson()));
		if (entity.getApprovalTime() != null) {
			model.setApprovalTime(DateUtil.format(entity.getApprovalTime(),
					"yyyy-MM-dd"));
		}
		model.setCheckOrgCode(entity.getCheckOrgCode());
		model.setCheckOrgCodeName(codeToNameUtils.getOrgNameByCode(entity
				.getCheckOrgCode()));
		if (entity.getCheckDate() != null) {
			model.setCheckDate(DateUtil.format(entity.getCheckDate(),
					"yyyy-MM-dd"));
		}
		model.setCheckPerson(entity.getCheckPerson());
		model.setCheckPersonName(codeToNameUtils.getUserNameByCode(entity
				.getCheckPerson()));

		model.setAcceptResult(entity.getAcceptResult());
		model.setAcceptRemark(entity.getAcceptRemark());
		model.setCheckContactTel(entity.getCheckContactTel());

		base.setCode(HttpServletResponse.SC_OK);
		base.setData(model);
		return base;

	}

	
	
	
	/**
	 * 
	 * <p>
	 * 描述:提交查验
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "/submitCheckAppointmentApply", method = RequestMethod.POST)
	@ResponseBody
	public DataModel CheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		DataModel base = MobileHelper.getBaseModel();

		String applyId=request.getParameter("applyId");// 申请ID
		String applyType = request.getParameter("applyType");// 申请类别
		String declNo = request.getParameter("declNo");// 报检号 
		String entOrgCode = request.getParameter("entOrgCode");// 组织机构代码
		String declRegNo = request.getParameter("declRegNo");// 报检单位注册号
		String declRegName=Utils.getParameter(request, "declRegName");// 报检单位名称

		String inspOrgCode = request.getParameter("inspOrgCode");// 施检机构
		String plateNo = request.getParameter("plateNo");// 车牌号
		String contNo = request.getParameter("contNo");// 集装箱号
		String appointCheckPlace = Utils.getParameter(request, "appointCheckPlace");// 预约查验地点
		String appointCheckDate = request.getParameter("appointCheckDate");// 预约日期
		String appointContactPerson = Utils.getParameter(request, "appointContactPerson");// 预约联系人
		String appointContactTel = request.getParameter("appointContactTel");// 预约联系电话
		String remark = Utils.getParameter(request, "remark");// 备注

		if(StringUtils.isEmpty(applyId)){
			if (StringUtils.isEmpty(applyType) || StringUtils.isEmpty(declNo) || StringUtils.isEmpty(entOrgCode)|| StringUtils.isEmpty(declRegName)
					|| StringUtils.isEmpty(declRegNo)|| StringUtils.isEmpty(appointCheckDate)|| StringUtils.isEmpty(inspOrgCode)
					|| StringUtils.isEmpty(appointCheckPlace)|| StringUtils.isEmpty(appointContactPerson)|| StringUtils.isEmpty(appointContactTel)) {
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
				return base;
			}
		}
		
		//申请ID不为空，直接更新状态
		if(StringUtils.isNotEmpty(applyId)){
			if (applyId.contains(",")) {
				String applyIds[] = applyId.split(",");
				for (int i = 0; i < applyIds.length; i++) {
					checkAppointService.submitInsCheckAppointInfoEntity(applyIds[i]);
				}
			} else {
				checkAppointService.submitInsCheckAppointInfoEntity(applyId);
			}
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(true);
			return base;
		}
		
		//数据库中已保存该单号，直接更新状态
		List<InsCheckAppointInfoEntity> list=checkAppointService.getInsCheckAppointInfoEntityList(declNo);
		if(CollectionUtils.isNotEmpty(list)){
			for (InsCheckAppointInfoEntity insCheckAppointInfoEntity : list) {
				if("0".equals(insCheckAppointInfoEntity.getApplyStatus()) && insCheckAppointInfoEntity.getApplyType().equals(applyType)) {
					checkAppointService.submitInsCheckAppointInfoEntity(insCheckAppointInfoEntity.getApplyId());
				}
			}
			
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(true);
			return base;
			
		}
		
		InsCheckAppointInfoEntity entity = new InsCheckAppointInfoEntity();
		entity.setApplyId(UUIDKeyGeneratorUils.newInstance().generateKey());
		entity.setApplyType(applyType);
		entity.setApplyTime(new Date());
		entity.setDeclNo(declNo);
		entity.setInspOrgCode(inspOrgCode);
		entity.setApplyNo(checkAppointService.getApplyNoRul(entOrgCode));//申请单号
		entity.setEntOrgCode(entOrgCode);
		entity.setDeclRegNo(declRegNo);
		entity.setDeclRegName(declRegName);
		entity.setPlateNo(plateNo);
		entity.setContNo(contNo);
		entity.setAppointCheckPlace(appointCheckPlace);
		entity.setApplyStatus("1");
		entity.setAcceptResult("0");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if(StringUtils.isNotEmpty(appointCheckDate)){
				entity.setAppointCheckDate(sdf.parse(appointCheckDate));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		entity.setAppointContactPerson(appointContactPerson);
		entity.setAppointContactTel(appointContactTel);
		entity.setRemark(remark);
		entity.setOperDate(new Date());
		checkAppointService.saveInsCheckAppointInfoEntity(entity);
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}
	
	
	
	/**
	 * 
	 * <p>
	 * 描述:撤销查验预约信息
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 */
	@RequestMapping(value = "/cancelCheckAppointmentApply", method = RequestMethod.GET)
	@ResponseBody
	public DataModel cancelCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String applyId=request.getParameter("applyId");//申请ID
		if (StringUtils.isEmpty(applyId)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		if (applyId.contains(",")) {
			String applyIds[] = applyId.split(",");
			for (int i = 0; i < applyIds.length; i++) {
				checkAppointService.cancelInsCheckAppointInfoEntity(applyIds[i]);
			}
		} else {
			checkAppointService.cancelInsCheckAppointInfoEntity(applyId);
		}
		
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}
	
	/**
	 * 
	 * <p>
	 * 描述:删除查验预约信息
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 */
	@RequestMapping(value = "/deleteCheckAppointmentApply", method = RequestMethod.GET)
	@ResponseBody
	public DataModel deleteCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String applyId=request.getParameter("applyId");//申请ID
		
		if (StringUtils.isEmpty(applyId)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		if (applyId.contains(",")) {
			String applyIds[] = applyId.split(",");
			for (int i = 0; i < applyIds.length; i++) {
				checkAppointService.deleteInsCheckAppointInfoEntity(applyIds[i]);
			}
		} else {
			checkAppointService.deleteInsCheckAppointInfoEntity(applyId);
		}

		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}

	
	/**
	 * 
	 * <p>
	 * 描述:修改界面保存操作
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "/editSaveCheckAppointmentApply", method = RequestMethod.POST)
	@ResponseBody
	public DataModel editSaveCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		DataModel base = MobileHelper.getBaseModel();
		String applyId=request.getParameter("applyId");//申请ID
		String applyType = request.getParameter("applyType");// 申请类别
		String declNo = request.getParameter("declNo");// 报检号
		String entOrgCode = request.getParameter("entOrgCode");//组织机构代码
		String declRegNo = request.getParameter("declRegNo");// 报检单位注册号
		String declRegName = Utils.getParameter(request, "declRegName");// 报检单位名称
		String inspOrgCode = request.getParameter("inspOrgCode");// 施检机构
		String plateNo = request.getParameter("plateNo");// 车牌号
		String contNo = request.getParameter("contNo");// 集装箱号
		String appointCheckPlace = Utils.getParameter(request, "appointCheckPlace");// 预约查验地点
		String appointCheckDate = request.getParameter("appointCheckDate");// 预约日期
		String appointContactPerson = Utils.getParameter(request, "appointContactPerson");// 预约联系人
		String appointContactTel = request.getParameter("appointContactTel");// 预约联系电话
		String remark = Utils.getParameter(request, "remark");// 备注

		if (StringUtils.isEmpty(applyId)||StringUtils.isEmpty(applyType) || StringUtils.isEmpty(declNo) || StringUtils.isEmpty(entOrgCode)|| StringUtils.isEmpty(declRegName)
				|| StringUtils.isEmpty(declRegNo)|| StringUtils.isEmpty(appointCheckDate)|| StringUtils.isEmpty(inspOrgCode)
				|| StringUtils.isEmpty(appointCheckPlace)|| StringUtils.isEmpty(appointContactPerson)|| StringUtils.isEmpty(appointContactTel)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		EntBaseInfoEntity entBaseINfoEntity=checkAppointService.getEntBaseInfoEntity(declRegNo);
		if(entBaseINfoEntity==null){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("该报检单位注册号不存在");
			return base;
		}
		
		InsCheckAppointInfoEntity entity = checkAppointService.getInsCheckAppointInfoEntity(applyId);
		entity.setApplyTime(new Date());
		entity.setApplyType(applyType);
		entity.setDeclNo(declNo);
		//entity.setApplyNo(checkAppointService.getMaxApplyNo());//申请单号
		entity.setEntOrgCode(entOrgCode);
		entity.setDeclRegNo(declRegNo);
		entity.setDeclRegName(declRegName);
		entity.setInspOrgCode(inspOrgCode);
		entity.setPlateNo(plateNo);
		entity.setContNo(contNo);
		entity.setAppointCheckPlace(appointCheckPlace);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		entity.setAppointContactPerson(appointContactPerson);
		entity.setAppointContactTel(appointContactTel);
		entity.setRemark(remark);
		try {
			if(StringUtils.isNotEmpty(appointCheckDate)){
				entity.setAppointCheckDate(sdf.parse(appointCheckDate));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		checkAppointService.saveInsCheckAppointInfoEntity(entity);
		entity.setOperDate(new Date());
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}
	
	
	
	/**
	 * 
	 * <p>
	 * 描述:受理
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "/assessCheckAppointmentApply", method = RequestMethod.GET)
	@ResponseBody
	public DataModel assessAppointmentApply(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();

		String declNo = request.getParameter("declNo");// 申请ID

		if (StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}

		// 申请ID不为空，直接更新状态
		if (declNo.contains(",")) {
			String declNos[] = declNo.split(",");
			for (int i = 0; i < declNos.length; i++) {
				checkAppointService.updateInsCheckAppointInfoEntity("2",
						declNos[i]);
			}
		} else {
			checkAppointService.updateInsCheckAppointInfoEntity("2", declNo);
		}
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}
	
	
	/**
	 * 
	 * <p>
	 * 描述:审批界面保存操作
	 * </p>
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @author 李云龙
	 * @throws Throwable 
	 */
	@RequestMapping(value = "/approveSaveCheckAppointmentApply", method = RequestMethod.POST)
	@ResponseBody
	public DataModel approveSaveCheckAppointmentApply(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		DataModel base = MobileHelper.getBaseModel();
		String applyId=request.getParameter("applyId");//申请ID
		String declNo=request.getParameter("declNo");//报检单号
		String checkOrgCode = request.getParameter("checkOrgCode");//查验机构
		String checkDate = request.getParameter("checkDate");//查验日期
		String checkContactTel = Utils.getParameter(request, "checkContactTel");//查验联系电话
		String checkPerson = request.getParameter("checkPerson");//查验人员
		String acceptResult = request.getParameter("acceptResult");//受理结果 (0：未审批 1:同意 2：不同意)
		String acceptRemark = Utils.getParameter(request, "acceptRemark");//受理意见
		String approvalPerson = request.getParameter("approvalPerson");//审批人员
		String approvalTime = request.getParameter("approvalTime");//审批时间
		
		if (StringUtils.isEmpty(applyId) || StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		List<InsCheckAppointInfoEntity> list=checkAppointService.getInsCheckAppointInfoEntityList(declNo);
		InsCheckAppointInfoEntity oldEntity=new InsCheckAppointInfoEntity();
		InsCheckAppointInfoEntity entity = new InsCheckAppointInfoEntity();
		if(CollectionUtils.isNotEmpty(list)){
			oldEntity=list.get(0);
			BeanPropertyUtils.getInstance().copyPropertiesBean(entity,oldEntity);
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		entity.setCheckContactTel(checkContactTel);
		entity.setCheckPerson(checkPerson);
		entity.setCheckOrgCode(checkOrgCode);
		entity.setAcceptRemark(acceptRemark);
		entity.setApprovalPerson(approvalPerson);
		entity.setAcceptResult(acceptResult);
		entity.setApplyStatus("4");
		entity.setOperDate(new Date());
		try {
			if(StringUtils.isNotEmpty(checkDate)){
				entity.setCheckDate(sdf.parse(checkDate));
			}
			if(StringUtils.isNotEmpty(approvalTime)){
				entity.setApprovalTime(sdf.parse(approvalTime));
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		checkAppointService.saveInsCheckAppointInfoEntity(entity);
		base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;
	}
	
	/**
	 * 
	* <p>描述:输入报检单位注册号查询基本信息</p>
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/loadCheckAppointBaseInfo",method=RequestMethod.GET)
	@ResponseBody
	public  DataModel loadCheckAppointBaseInfo(HttpServletRequest request,HttpServletResponse response) {
		DataModel base=MobileHelper.getBaseModel();
		String declRegNo=request.getParameter("declRegNo");//报检单位注册号
		String declNo=request.getParameter("declNo");//报检单号
		String flag=request.getParameter("flag");
		if("declRegNo".equals(flag)&&StringUtils.isEmpty(declRegNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}	
		if("declNo".equals(flag)&&StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}		
		
		EntBaseInfoEntity entity=checkAppointService.loadCheckAppointBaseInfo(declRegNo,declNo);
		CheckAppointBaseInfoModel model=new CheckAppointBaseInfoModel();
		if(entity!=null) {
			model.setDeclRegNo(entity.getDeclRegNo());//报检单注册号
			model.setUnitNameCn(entity.getUnitNameCn());//报检单位名称中文
			base.setData(model);
		}else {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("该报检单号或报检单位注册号不存在！请检查拼写");
		}
		return base;
	}
	

}

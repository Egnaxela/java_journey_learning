package com.rongji.eciq.mobile.controller.insp.examining;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.examining.DclIoDeclXEModel;
import com.rongji.eciq.mobile.service.insp.ShowDeclInfoService;
import com.rongji.eciq.mobile.service.insp.examining.DclIoDeclXEService;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**
 * Description  施检员审单-审单按钮Controller
 * @author 		魏波
 * @version		1.0
 * Modification History:  
 * Date        Author     Version     Description  
 * ------------------------------------------------------------------  
 * 20170419    魏波                             1.0         根据货物条数查询货物信息
 * 20170512    魏波                             1.0         根据报检单号查第一条货物的名称
 * 20170515    魏波                             1.0         修改所需单证代码转名称
 * 20170804    李云龙                         1.0         修改审单所需单证为空问题
 *
 */
@Controller
@RequestMapping("/insp/audit")
public class AuditController extends MobileExceptionHandlerController{
	
	@Autowired
	private DclIoDeclXEService service;
	@Autowired
	private ShowDeclInfoService showService;
	@Autowired
	private SubAuxiliaryService auxService;
	@Autowired
	private SubAuditService subService;
	@Resource
	HQLCodeToNameDao dao;
	
	/**
	 * 点击审单按钮查看数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initAuditView",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initAuditView(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
//		DclIoDeclEx ex = new DclIoDeclEx();
		InsDeclMagEntity msg = new InsDeclMagEntity();
		DclIoDeclXEModel model = new DclIoDeclXEModel();
		String declNo=request.getParameter("declNo");//报检号
		String currentPage = request.getParameter("currentPage");// 当前页号
		String expImpFlag = request.getParameter("expImpFlag");// 出入境标志
		String size = request.getParameter("size");//货物条数
		String inspDeptCode=request.getParameter("orgCode");//部门代码
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
//		 List<DclIoDeclEx> list = service.getDclIoDeclXEModel(declNo);
		 //List<InsDeclMagEntity> listMsg =auxService.findInsDeclListByDeclNo(declNo);
		List<InsDeclMagEntity> listMsg =auxService.findInsDeclListByDeclNoAndDeptCode(declNo,inspDeptCode);
		
		 if(!CollectionUtils.isEmpty(listMsg)){
			msg = listMsg.get(0);
//			model.setCertTypeName(msg.getCertTypeNames());//证书
			model.setCertTypeName(CommonCodeToNameUtils.certCodeToName(msg.getCertTypeCodes()));
		 }
//		 HQLCodeToNameDao dao = new HQLCodeToNameDao();
//		 if(!CollectionUtils.isEmpty(list)){
//			ex = list.get(0);
			model.setDeclNo(msg.getDeclNo());//报检号
			List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(msg.getDeclNo());
			if(CollectionUtils.isEmpty(dcl)){
				model.setEntName("");
			}else{
				model.setEntName(dcl.get(0).getDeclRegName());
			}
//			model.setEntName(msg.getEntName());//企业名称
//			model.setEntTypeCode(ex.getEntTypeCode());//企业类型
			
			if(StringUtils.isNotEmpty(msg.getInspRequire())){
				model.setInspRequire(CommonCodeToNameUtils
						.inspRequireToName(msg.getInspRequire()));
			}else{
				model.setInspRequire("无查验要求");
			}
			
			List<DclIoDeclEntity> ent = showService.queryDclIoDeclList(declNo, expImpFlag);
			if(!CollectionUtils.isEmpty(ent)){
				model.setCountry(dao.getTradeCountryNameByCode(ent.get(0).getTradeCountryCode()));
			}
//		}
		List<DclIoDeclGoodsEntity> goodsList = showService.queryDclIoDeclGoodsListBySize(declNo,expImpFlag,currentPage,size);
		Map map = new HashMap();
		map.put("model", model);
		map.put("goods", goodsList);
		base.setData(map);
		return base;
	}
}

package com.rongji.eciq.mobile.controller.insp.examining;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsOriaudiExcePbinfoEntity;
import com.rongji.eciq.mobile.entity.RewMonPlanLotedVo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.sub.InsOriaudiExcePbinfoModel;
import com.rongji.eciq.mobile.service.insp.ShowDeclInfoService;
import com.rongji.eciq.mobile.service.insp.examining.RewMonPlanLotedService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**
 * Description  施检员审单-审单按钮Controller
 * @author 		魏波
 * @version		1.0
 *
 */
@Controller
@RequestMapping("/insp/audit")
public class RewMonPlanLotedController {

	@Autowired
	private RewMonPlanLotedService service;
	@Autowired
	private ShowDeclInfoService showService;
	@Autowired
	private SubOrReasService subOrReasService;
	
	/**
     * 取得报检命中的规划
     *
	 * @param request
	 * @param response
	 * @return
     */
	@RequestMapping(value="/getLotedPlans",method=RequestMethod.GET)
	@ResponseBody
	public DataModel getLotedPlans(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		String goodsNo=request.getParameter("goodsNo");//货物序号
		String expImpFlag = request.getParameter("expImpFlag");// 出入境标志
		String entCode="";
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(goodsNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<DclIoDeclEntity> ent = showService.queryDclIoDeclList(declNo, expImpFlag);
		if(!CollectionUtils.isEmpty(ent)){
			entCode = ent.get(0).getConsigneeCode();
		}
		List<RewMonPlanLotedVo> list = service.getLotedPlans(declNo, goodsNo, entCode);
		base.setData(list);
		return base;
	}
	
	/**
	 * 审单布控数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initControl",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initAuditView(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		String goodsNo=request.getParameter("goodsNo");//货物序号
		List<InsOriaudiExcePbinfoEntity> oriaudList = subOrReasService.findInsOriaudiExcePbinfo(declNo, goodsNo);
        List<InsOriaudiExcePbinfoModel> oriaudModelList=new ArrayList<InsOriaudiExcePbinfoModel>();
        if(!CollectionUtils.isEmpty(oriaudList)){
        	for(InsOriaudiExcePbinfoEntity entity:oriaudList){
        		InsOriaudiExcePbinfoModel model=new InsOriaudiExcePbinfoModel();
        		model.setAbnormalCause(entity.getAbnormalCause());
        		model.setAbnormalType(CommonCodeToNameUtils.MonitorBlockTypeCodeToName(entity.getAbnormalType()));
        		model.setExceptionDetail(entity.getExceptionDetail());
        		model.setDeclNo(entity.getDeclNo());
        		if(entity.getGoodsNo()!=null){
        			model.setGoodsNo((entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")));
        		}else{
        			model.setGoodsNo("");
        		}
        		oriaudModelList.add(model);
        	}
        }
        base.setData(oriaudModelList);
        return base;
	}
}

/**  
 * FileName:  SubAuditController.java   
 * @Description: 施检员审单Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年3月28日 上午11:47:08  
 *  
 */  
package com.rongji.eciq.mobile.controller.insp.examining;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.examining.InsCheckItemModel;
import com.rongji.eciq.mobile.model.insp.examining.SubAuditInitTableModel;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.model.insp.scene.ShowMessageModel;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;

/**
 * Description: 施检员审单Controller
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年3月28日 上午11:47:08  
 *  
 * Modification History:  
 * Date        Author     Version     Description   
 * ------------------------------------------------------------------  
 * 20170411    李晨阳                 1.0         新增功能-查询查验项目
 * 20170427    才江男                 1.0         增加接单员
 * 20170427    吴有根                 1.0         审单退单、分单退单操作  
 * 20170511    才江男                 1.0         报检日期空检验  
 * 20170512    魏波                      1.0         根据报检单号查第一条货物的名称
 * 2017-05-24  才江男                  1.0         增加返回报检号
 */

@Controller
@RequestMapping("/insp/examining")
public class SubAuditController extends MobileExceptionHandlerController {

	@Autowired
	private SubAuditService service;
	@Autowired
	private SubAuditService subService;
	
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	@Autowired
	private DeclNoUtils declNoUtils;

	/**
	 * 施检员审单查看数据初始化查询
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/initSubAuditTable", method = RequestMethod.GET)
	@ResponseBody
	public DataModel initSubAuditTable(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String expImpFlag = request.getParameter("expImpFlag");// 出入境标志
		String exeInspOrgCode = request.getParameter("exeInspOrgCode");// 施检机构
		String receiverDocCode = request.getParameter("receiverDocCode");// 接单员代码
		String declNo = request.getParameter("declNo");// 报检号
		String declRegName = Utils.getParameter(request, "declRegName");// 报检单位
		String currentPage = request.getParameter("currentPage");// 当前页号
		if (StringUtils.isEmpty(expImpFlag)
				|| StringUtils.isEmpty(exeInspOrgCode)
				|| StringUtils.isEmpty(receiverDocCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
//			UserInfo user = new UserInfo();
//			user.setUserCode(userCode);
//			SysUser sysUser = subOrReasDao.getSysUser(userCode);
//			if (sysUser != null) {
//				user.setCompanyCode(sysUser.getOrgCode());
//				user.setUserName(sysUser.getUserName());
//			}
//			String longDeclNo = "";
//			if (expImpFlag.equals("1")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_IN, user);
//			} else if (expImpFlag.equals("2")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_OUT, user);
//			}
//			declNo = longDeclNo;
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
        //----------------------------------短号变长号--------------------------------------------------
		

		List<SubOrReasEntity> querySubAuditList = service.getSubAuditList(
				expImpFlag, exeInspOrgCode, receiverDocCode, declNo,
				declRegName, currentPage);//SceneCheckInitTableModel
		ArrayList<SceneCheckInitTableModel> list = new ArrayList<SceneCheckInitTableModel>();
		if (!CollectionUtils.isEmpty(querySubAuditList)) {
			list.ensureCapacity(querySubAuditList.size());
			for (SubOrReasEntity entity : querySubAuditList) {
				SceneCheckInitTableModel model = new SceneCheckInitTableModel();
				model.setDeclNo(entity.getDeclNo());
				List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(entity.getDeclNo());
				if(CollectionUtils.isEmpty(dcl)){
					model.setDeclRegName("");
				}else{
					model.setDeclRegName(dcl.get(0).getDeclRegName());
				}
				model.setFlowPathStatus(CommonCodeToNameUtils
						.flowPathStatusToName(entity.getFlowPathStatus()));
				model.setGoodsName(subService.getGoodName(entity.getDeclNo()));
//				model.setGoodsName(entity.getGoodsName());
				if (StringUtils.isNotEmpty(entity.getRemark())) {
					model.setTradeCountryCode(entity.getRemark());
				} else {
					model.setTradeCountryCode("");
				}
				Timestamp declDate = entity.getDeclDate();
				String date = "";
				if(null != declDate) {
					date = DateUtil.format(declDate, "yyyy-MM-dd");
				}
				
				model.setDeclDate(date);
				
				model.setInsRequire(entity.getInspRequire());
//				if(model.getInspRequire().isEmpty()){
//					model.setInspRequire("无检验要求");
//				}
				//接单员
				model.setReceiverDocCode(entity.getReceiverDocCode());
				model.setFlowPathStatus(entity.getFlowPathStatus());//主辅检标记
				model.setFlowPathStatusCode(entity.getFlowPathStatus());
				model.setFlowPathStatusName(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
				list.add(model);
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(list);
		base.setData(vo);
		return base;
	}

	/**
	 * 施检员审单-查验项目信息
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/InsCheckItem", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getInsCheckItemList(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String declNo = request.getParameter("declNo");// 报检单号
		String goodsNo = request.getParameter("goodsNo");// 货物序号
		String type = request.getParameter("type");// 检测类别
		if (StringUtils.isEmpty(declNo)|| StringUtils.isEmpty(goodsNo)|| StringUtils.isEmpty(type)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		List<InsCheckItemEntity> queryList = service.getInsCheckItemList(declNo, goodsNo, type);
		ArrayList<InsCheckItemModel> list = new ArrayList<InsCheckItemModel>();
		if (!CollectionUtils.isEmpty(queryList)) {
			list.ensureCapacity(queryList.size());
			for (InsCheckItemEntity entity : queryList) {
				InsCheckItemModel model = new InsCheckItemModel();
				model.setCheckItemName(entity.getCheckItemName());
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));
				model.setCheckCont(entity.getCheckCont());
				if(StringUtils.isEmpty(entity.getIsAppFlag())){
					model.setFormName("");
				}else{
					model.setFormName(entity.getIsAppFlag());
				}
				list.add(model);
			}
		}
		base.setData(list);
		return base;
	}

	
	/**
	 * 主辅施检员审单-退单、分单退单
	* <p>描述:</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value = "/chargeBack", method = RequestMethod.GET)
	@ResponseBody
	public DataModel chargeBack(HttpServletRequest request,HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String declNo = request.getParameter("declNo");// 报检单号
		String receiverDocCode = request.getParameter("userCode");//接单员代码
		String userOrgCode = request.getParameter("userOrgCode");//接单员机构代码
		String flowPathStatus = request.getParameter("flowPathStatus");//主辅检标记流程状态
		String returnReason =Utils.getParameter(request, "returnReason");// 退单原因
		String operType=request.getParameter("operType");//退单类型   1:分单退单    2:审单退单     9:结果登记退单
	
		if (StringUtils.isEmpty(declNo)|| StringUtils.isEmpty(returnReason)||StringUtils.isEmpty(operType)
				||StringUtils.isEmpty(receiverDocCode)||StringUtils.isEmpty(flowPathStatus)||StringUtils.isEmpty(userOrgCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		ShowMessageModel model=new ShowMessageModel();
		System.out.println("退单原因长度: "+returnReason.length());
		if(StringUtils.isNotEmpty(returnReason)){
			if(returnReason.length()>100){
				model.setDeclNo(declNo);
				model.setMessage("退单原因超长");
				base.setData(model);
				return base;
			}
		}else{
			model.setDeclNo(declNo);
			model.setMessage("退单原因不能为空");
			base.setData(model);
			return base;
		}
		
		SubOrReasEntity entity=null;
		if(StringUtils.equals(operType, "9")){
			 entity=service.getInsDeclMagByNo(declNo,flowPathStatus,userOrgCode, receiverDocCode);
			 if(entity==null){
				 model.setDeclNo(declNo);
				 model.setMessage("当前报检单不在结果登记环节");
				 base.setData(model);
				 return base;
			 }
		}
		if(StringUtils.equals(operType, "2")){
			 entity=service.getInsDeclMagByNo(declNo,flowPathStatus,userOrgCode, receiverDocCode);
			 if(entity==null){
				 model.setDeclNo(declNo);
				 model.setMessage("当前报检单不在审单环节");
				 base.setData(model);
				 return base;
			 }
		}
		if(StringUtils.equals(operType, "1")){
			 entity=service.getInsDeclMagByNo(declNo,flowPathStatus,userOrgCode);
			 if(entity==null){
				 model.setDeclNo(declNo);
				 model.setMessage("操作失败！或当前报检单不在分单环节");
				 base.setData(model);
				 return base;
			 }
		}
		if(entity!=null){
			String msString=service.chargeBack(entity,returnReason,operType,receiverDocCode);
			if(StringUtils.isEmpty(msString)){
				model.setDeclNo(declNo);
				model.setMessage("退单成功");
				base.setData(model);
			}else{
				model.setDeclNo(declNo);
				model.setMessage(msString);
				base.setData(model);
			}
		}
		return base;
	}
}

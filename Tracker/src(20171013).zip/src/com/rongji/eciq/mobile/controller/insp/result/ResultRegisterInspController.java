/**  
 * FileName:    ResultRegisterInspController.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-5-9 下午7:33:55  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.result;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.result.ResultRegisterService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-5-9 下午7:33:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-9      才江男                      1.0         1.0 Version  
 * 2017-05-12    魏波                          1.0         根据报检单号查第一条货物的名称
 * 2017-05-24    才江男                      1.0         增加返回报检号
 */
@Controller
@RequestMapping("/insp/result")
public class ResultRegisterInspController extends MobileExceptionHandlerController{

	@Autowired
	private ResultRegisterService service;
	@Autowired
	private SubAuditService subService;
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	@Autowired
	private DeclNoUtils declNoUtils;
	
	/**
	 * 结果登记界面初始化数据
	 * @param expImpFlag   	        出入境标志
	 * @param exeInspOrgCode   施检机构代码
	 * @param receiverDocCode  接单员代码
	 * @param declNo		       报检单号
	 * @param declRegName      报检单位
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSceneTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSceneTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String exeInspOrgCode=request.getParameter("exeInspOrgCode");//施检机构
		String receiverDocCode=request.getParameter("receiverDocCode");//接单员代码
		String declNo=request.getParameter("declNo");//报检号
		String declRegName=Utils.getParameter(request, "declRegName");//报检单位
		String currentPage=request.getParameter("currentPage");//当前页号
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(exeInspOrgCode)||StringUtils.isEmpty(receiverDocCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
//			UserInfo user = new UserInfo();
//			user.setUserCode(userCode);
//			SysUser sysUser = subOrReasDao.getSysUser(userCode);
//			if (sysUser != null) {
//				user.setCompanyCode(sysUser.getOrgCode());
//				user.setUserName(sysUser.getUserName());
//			}
//			String longDeclNo = "";
//			if (expImpFlag.equals("1")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_IN, user);
//			} else if (expImpFlag.equals("2")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_OUT, user);
//			}
//			declNo = longDeclNo;
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
        //----------------------------------短号变长号--------------------------------------------------
		
		
		List<SubOrReasEntity> queryMagList=service.getMagList(expImpFlag,exeInspOrgCode,receiverDocCode,declNo,declRegName,currentPage);
		
		ArrayList<SceneCheckInitTableModel> list=new ArrayList<SceneCheckInitTableModel>();
		if(!CollectionUtils.isEmpty(queryMagList)){
			list.ensureCapacity(queryMagList.size());
			for(SubOrReasEntity entity:queryMagList){
				SceneCheckInitTableModel model=new SceneCheckInitTableModel();
				model.setDeclNo(entity.getDeclNo());
				model.setInsRequire(entity.getInspRequire());
				List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(entity.getDeclNo());
				if(CollectionUtils.isEmpty(dcl)){
					model.setDeclRegName("");
				}else{
					model.setDeclRegName(dcl.get(0).getDeclRegName());
				}
				model.setGoodsName(subService.getGoodName(entity.getDeclNo()));
				
//				model.setDeclRegName(entity.getDeclRegName());
				model.setFlowPathStatus(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
				model.setFlowPathStatusCode(entity.getFlowPathStatus());
//				model.setGoodsName(entity.getGoodsName());
				if(StringUtils.isNotEmpty(entity.getRemark())){
					model.setTradeCountryCode(entity.getRemark());
				}else{
					model.setTradeCountryCode("");
				}
				Timestamp declDate = entity.getDeclDate();
				if(null != declDate) {
					model.setDeclDate(DateUtil.format(declDate, "yyyy-MM-dd"));
				}
				list.add(model);
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(list);
		base.setData(vo);
		return base;
	}
	
	/**
	 * 结束查验
	 */
	@RequestMapping(value="/endScene",method=RequestMethod.POST)
	@ResponseBody
	public DataModel endScene(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String exeInspOrgCode=request.getParameter("exeInspOrgCode");//施检机构
		String receiverDocCode=request.getParameter("receiverDocCode");//接单员代码
		String declNo=request.getParameter("declNo");//报检号
		String declRegName=Utils.getParameter(request, "declRegName");//报检单位
		String currentPage=request.getParameter("currentPage");//当前页号
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(exeInspOrgCode)||StringUtils.isEmpty(receiverDocCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		List<SubOrReasEntity> queryMagList=service.getMagList(expImpFlag,exeInspOrgCode,receiverDocCode,declNo,declRegName,currentPage);
		
		ArrayList<SceneCheckInitTableModel> list=new ArrayList<SceneCheckInitTableModel>();
		if(!CollectionUtils.isEmpty(queryMagList)){
			list.ensureCapacity(queryMagList.size());
			for(SubOrReasEntity entity:queryMagList){
				SceneCheckInitTableModel model=new SceneCheckInitTableModel();
				model.setDeclNo(entity.getDeclNo());
				model.setDeclRegName(entity.getDeclRegName());
				model.setFlowPathStatus(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
				model.setFlowPathStatusCode(entity.getFlowPathStatus());
				model.setGoodsName(entity.getGoodsName());
				if(StringUtils.isNotEmpty(entity.getRemark())){
					model.setTradeCountryCode(entity.getRemark());
				}else{
					model.setTradeCountryCode("");
				}
				model.setDeclDate(DateUtil.format(entity.getDeclDate(), "yyyy-MM-dd"));
				list.add(model);
			}
		}
		base.setData(list);
		return base;
	}
}

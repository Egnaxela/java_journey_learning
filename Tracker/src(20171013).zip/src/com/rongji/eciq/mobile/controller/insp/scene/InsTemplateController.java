/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-10 下午2:59:12  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.scene;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.common.util.BaseUtil;
import com.rongji.eciq.mobile.entity.InsDeptDefTemplate;
import com.rongji.eciq.mobile.entity.InsTemplate;
import com.rongji.eciq.mobile.entity.InsTemplateSub;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.InsTemplateDeptModel;
import com.rongji.eciq.mobile.model.insp.scene.InsTemplateModel;
import com.rongji.eciq.mobile.service.insp.scene.InsTemplateService;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-10 下午2:59:12  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-10      夏晨琳                      1.0         1.0 Version  
 */
@Controller
@RequestMapping("/insp/template")
public class InsTemplateController {
	
	@Autowired
	private InsTemplateService templateService;
	
	/**
	 * 查询模板集合
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/getTemplateList", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getTemplateList(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String expImpFlag = request.getParameter("expImpFlag");//出入境
		String cp = request.getParameter("currentPage");//分页
		if (StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(expImpFlag) ||
				StringUtils.isEmpty(cp)||StringUtils.isEmpty(cp)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		String templateTitle = request.getParameter("templateTitle");
		Page page = MobileHelper.getPage(cp);
		String templateType="0";
		List<InsTemplate> list = templateService.searchCheckTempListByUser(expImpFlag,templateType,page,templateTitle);
		base.setCode(200);
		base.setData(list);
		return base;
	}
	
	/**
	 * 模板维护，获取查询模板集合
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/searchCheckTempList", method = RequestMethod.GET)
	@ResponseBody
	public DataModel searchCheckTempList(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String cp = request.getParameter("currentPage");//分页
		if (StringUtils.isEmpty(cp)||StringUtils.isEmpty(cp)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		String templateTitle = request.getParameter("templateTitle");
		String whetherEffect = request.getParameter("whetherEffect");//是否有效
		String orgCodes = request.getParameter("orgCodes");//维护部门
		Page page = MobileHelper.getPage(cp);
		List<InsTemplate> list = templateService.searchCheckTempList(templateTitle,whetherEffect,orgCodes,page);
		base.setCode(200);
		base.setData(list);
		return base;
	}
	
	/**
	 * 模板查看
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/getInsTemplate", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getInsTemplate(HttpServletRequest request,HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String templateId = request.getParameter("templateId");
		if (StringUtils.isEmpty(templateId)||StringUtils.isEmpty(templateId) ) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		InsTemplate template = templateService.getInsTemplate(templateId);
		//获取子模板中的使用部门和名称等信息
		List<InsTemplateSub> sublist = templateService.getInsTemplateSubList(templateId);
		List<InsTemplateDeptModel> deptList = new ArrayList<InsTemplateDeptModel>();
		for (InsTemplateSub sub : sublist) {
			InsTemplateDeptModel dep = new InsTemplateDeptModel();
			dep.setCode(sub.getUseDeptCode());
			dep.setName(sub.getUseDeptName());
			deptList.add(dep);
		}
		InsTemplateModel model = new InsTemplateModel();
		if(template!=null){
			model.setTmpltNo(String.valueOf(template.getTmpltNo()));
			model.setWhetherEffect("0".equals(template.getWhetherEffect())?"否":"是");
			model.setTemplateTitle(template.getTemplateTitle());
			model.setTemplateType("0".equals(template.getTemplateType())?"现场查验":"隔离检疫");
			model.setTemplateContent(template.getTemplateContent());
			model.setDeptList(deptList);
		}
		base.setCode(200);
		base.setData(model);
		return base;
	}
	
	/**
	 * 模板删除
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/deleteInsTemplate", method = RequestMethod.POST)
	@ResponseBody
	public DataModel deleteInsTemplate(HttpServletRequest request,HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String templateId = request.getParameter("templateId");
		if (StringUtils.isEmpty(templateId)||StringUtils.isEmpty(templateId) ) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		templateService.deleteInsTemplate(templateId);//删除模板信息
		templateService.deleteSubTemplate(templateId);//删除子模板信息
		templateService.deleteDefTemplate(templateId);//删除默认模板信息
		base.setCode(200);	
		base.setData("删除成功");
		return base;
	}
	
	/**
	 * 模板添加和更新
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/addInsTemplate", method = RequestMethod.POST)
	@ResponseBody
	public DataModel addInsTemplate(HttpServletRequest request,HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String templateId = request.getParameter("templateId");
		String tmpltNo = request.getParameter("tmpltNo");
		String templateTitle = request.getParameter("templateTitle");
		String whetherEffect = request.getParameter("whetherEffect");
		String templateType = request.getParameter("templateType");
		String templateContent = request.getParameter("templateContent");
		if (StringUtils.isEmpty(tmpltNo) || StringUtils.isEmpty(templateTitle) || StringUtils.isEmpty(whetherEffect) || StringUtils.isEmpty(templateType) || StringUtils.isEmpty(templateContent)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		String userCode = request.getParameter("userCode");//维护人员代码
		String deptCode = request.getParameter("deptCode");//维护人员部门
		String userName = request.getParameter("userName");//维护人员名称
		String codes = request.getParameter("codes");
		String names = request.getParameter("names");
		InsTemplate template = null;
		boolean boo = false;
		if(StringUtils.isEmpty(templateId)){//添加
			boo = true;
			template = new InsTemplate();
			template.setTemplateId(UUIDKeyGeneratorUils.newInstance().generateKey());
			template.setOperUserCode(userCode);
			template.setOperDeptCode(deptCode);
			template.setMakers(userCode);
			template.setOperUserName(userName);
			template.setMakeTime(new Date());
		}else{//更新
			template = templateService.getInsTemplate(templateId);
		}
		template.setTmpltNo(BigDecimal.valueOf(Double.valueOf(tmpltNo)));
		template.setTemplateTitle(templateTitle);
		template.setWhetherEffect(whetherEffect);
		template.setTemplateType(templateType);
		template.setTemplateContent(templateContent);
		template.setOperTime(new Date());
		templateService.saveOrUpdateTemp(template,boo);
		//删除子模板信息
		templateService.deleteSubTemplate(templateId);
		String[] cs =null;
		if(Utils.notEmpty(codes)){
			if(codes.contains(",")){
				cs = codes.split(",");
			}else{
				cs = new String[]{codes};
			}
		}
		String[] ns = null;
		if(Utils.notEmpty(names)){
			if(names.contains(",")){
				ns = names.split(",");
			}else{
				ns = new String[]{names};
			}
		}
		if(cs!=null&&Utils.notEmpty(cs)&&cs.length>0){
			for (int i = 0; i < cs.length; i++) {
				InsTemplateSub sub = new InsTemplateSub();
				sub.setTemplateSubId(UUIDKeyGeneratorUils.newInstance().generateKey());
				sub.setTemplateId(templateId);
				sub.setOperTime(new Date());
				sub.setUseDeptCode(cs[i]);
				sub.setUseDeptName(ns[i]);
				templateService.saveTemplateSub(sub);
			}
		}
		base.setCode(200);
		base.setData("操作成功");
		return base;
	}
	
	/**
	 * 设置为默认的模板
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/setDefTemplate", method = RequestMethod.POST)
	@ResponseBody
	public DataModel setDefTemplate(HttpServletRequest request,HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String templateId = request.getParameter("templateId");
		String orgCodes = request.getParameter("orgCodes");
		if (StringUtils.isEmpty(templateId) || StringUtils.isEmpty(orgCodes)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		String[] orgList=null;
		if(orgCodes.contains(",")){
			orgList = orgCodes.split(",");
		}else{
			orgList = new String[]{orgCodes};
		}
		//删除该模板对应的部门信息
		templateService.deleteDefTemplate(templateId);
		for (String orgCode : orgList) {
			//查询对应的部门是否存在
			List<InsDeptDefTemplate> list = templateService.getDefTemplateEntity(orgCode);
			if(Utils.notEmpty(list)){//进行更新
				for (InsDeptDefTemplate def : list) {
					def.setTemplateId(templateId);
					templateService.updateDefTempleate(def);
				}
			}else{//进行保存
				InsDeptDefTemplate def = new InsDeptDefTemplate();
				def.setInsDeptDefTemplateId(UUIDKeyGeneratorUils.newInstance().generateKey());
				def.setDefDeptCode(orgCode);
				def.setOperTime(new Date());
				def.setTemplateId(templateId);
				templateService.saveDefTemplate(def);
			}
		}
		base.setCode(200);
		base.setData("操作成功");
		return base;
	}
	
}

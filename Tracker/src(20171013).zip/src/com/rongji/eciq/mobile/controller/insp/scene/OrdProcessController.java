/**  
 * FileName:OrdProcessController.java
 * @Description: 布控处理Controller
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.controller.insp.scene;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.dfish.base.DateUtil;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.SwitchContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.DclOrdBackMainEntity;
import com.rongji.eciq.mobile.entity.DclOrdDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.OrdBackMainVo;
import com.rongji.eciq.mobile.entity.OrdFeedbackDetailVo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.DclOrdDetailModel;
import com.rongji.eciq.mobile.model.insp.scene.DclOrdFeedbackModel;
import com.rongji.eciq.mobile.model.insp.scene.DclOrgBackModel;
import com.rongji.eciq.mobile.service.insp.scene.OrdProcessService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.vo.insp.OrdBackVo;
import com.rongji.eciq.mobile.vo.insp.OrdFeedbacklVo;

/**
 * 
 * Description: 布控处理Controller
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-8 下午5:43:25  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-20    李晨阳                     1.0         添加综合评定和反馈结论代码转名称
 * 2017-05-02    才江男                     1.0         修改反馈环节指令为静态
 * 2017-05-02    李云龙                      1.0         布控反馈显示添加根据报检号与环节值查询布控信息
 * 2017-05-11    李晨阳                     1.0         布控开关暂时设成开
 */
@Controller
@RequestMapping("/insp/ord")
public class OrdProcessController extends MobileExceptionHandlerController{
	@Autowired
	private OrdProcessService service;
	@Autowired
	private SubOrReasService subOrReasService;
	@Autowired
	private SubAuxiliaryService subAuxiliaryService;
	@Autowired
	private CompanyCodeUtils companyCodeUtils;
	private static final String feedbackLink = CommContext.SPOT;//反馈环节指令
	

	/**
	 * 布控反馈查看数据初始化查询
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/open", method = RequestMethod.GET)
	@ResponseBody
	public DataModel ordHandle(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String orgCode = request.getParameter("orgCode");// 用户所属机构
		String declNo = request.getParameter("declNo");// 报检单号
		if (StringUtils.isEmpty(orgCode)||StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}

		boolean b = true; //service.getSwitchResultByUp(SwitchContext.INS_ORDER, orgCode);
		if (b) {// 布控开关为打开状态
			boolean ordDetail = service.getOrdMain(declNo, feedbackLink);
			DclOrdBackMainEntity backMain = service
					.getOrdBackMain(declNo, "16");
			if (ordDetail) {
				if (backMain != null) {
					if (StringUtils.equals("0", backMain.getTreatFlag())) {
						base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
						base.setMsg("布控已经回退尚未处理");
						return base;
					} else {
						base.setCode(HttpServletResponse.SC_OK);
						base.setData("true");
						return base;
					}

				} else {
					base.setCode(HttpServletResponse.SC_OK);
					base.setData("true");
					return base;
				}

			} else {
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg("没有找到相对应的布控信息");
				return base;
			}

		} else {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("布控开关没有打开");
			return base;
		}
	}
	
	
	
	
	
	
	/**
	 * 布控反馈查看数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initOrdFeedbackDetailTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initOrdFeedbackDetailTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
//		String feedbackLink=request.getParameter("feedbackLink");//反馈环节指令
		String deptCode = request.getParameter("deptCode");//用户所属机构
		String fedbackPersn=request.getParameter("fedbackPersn");//反馈人
		String currentPage=request.getParameter("currentPage");//当前页号
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(deptCode)||StringUtils.isEmpty(fedbackPersn)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		DclOrdFeedbackModel dclOrdFeedbackModel= new DclOrdFeedbackModel();
		DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity = service.getOrdFeedBackMain(deptCode,fedbackPersn,declNo, feedbackLink,currentPage);
		if (dclOrdFeedbackMainEntity == null) {
            dclOrdFeedbackMainEntity = new DclOrdFeedbackMainEntity();
            dclOrdFeedbackMainEntity.setDeclNo(declNo);
            dclOrdFeedbackMainEntity.setFeedbackLink(feedbackLink);
            dclOrdFeedbackMainEntity.setOperTime(new Date());
            dclOrdFeedbackMainEntity.setFeedbackTime(new Date());
            dclOrdFeedbackMainEntity.setFedbackPersn(fedbackPersn);

            //默认合格
            dclOrdFeedbackMainEntity.setAssessStatus("1");
        }
		
		if(dclOrdFeedbackMainEntity!=null){
				dclOrdFeedbackModel.setDeclNo(declNo);
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getFedbackPersn())){
				dclOrdFeedbackModel.setFedbackPersn(dclOrdFeedbackMainEntity.getFedbackPersn());
				dclOrdFeedbackModel.setFedbackPersnName(subOrReasService.getUserNameUserCode(dclOrdFeedbackMainEntity.getFedbackPersn()));
			}
			if(dclOrdFeedbackMainEntity.getOperTime()!=null){
				dclOrdFeedbackModel.setOperTime(DateUtil.format(dclOrdFeedbackMainEntity.getOperTime(), "yyyy-MM-dd"));
			}
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getAssessStatus())){
				dclOrdFeedbackModel.setAssessStatus(dclOrdFeedbackMainEntity.getAssessStatus());
				dclOrdFeedbackModel.setAssessStatusName(CommonCodeToNameUtils.assessStatusToName(dclOrdFeedbackMainEntity.getAssessStatus()));//综合评定结论名称
			}
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getSuplement())){
				dclOrdFeedbackModel.setSuplement(dclOrdFeedbackMainEntity.getSuplement());
			}
			
			List<OrdFeedbackDetailVo> list=service.getFeedbackDetailListByMainNo(dclOrdFeedbackMainEntity.getFeedbackMainNo());
			if (CollectionUtils.isEmpty(list)) {
	            list = service.getFeedbackDetailListBydeclNo(declNo, feedbackLink);
	        }
			List<OrdFeedbacklVo> listVo=new ArrayList<OrdFeedbacklVo>();
			
			if(!CollectionUtils.isEmpty(list)){
				for(OrdFeedbackDetailVo vo:list){
					OrdFeedbacklVo ordFeedbacklVo=new OrdFeedbacklVo();
					ordFeedbacklVo.setConcDesc(vo.getConcDesc());
					ordFeedbacklVo.setConclusionName(vo.getConclusionName());
					ordFeedbacklVo.setExecLevel(vo.getExecLevel());
					ordFeedbacklVo.setExecRslt(vo.getExecRslt());
					ordFeedbacklVo.setExecRsltName(CommonCodeToNameUtils.assessStatusToName(vo.getExecRslt()));//反馈结论名称
					ordFeedbacklVo.setExecRsltDesc(vo.getExecRsltDesc());
					ordFeedbacklVo.setOrdFeedbackInfoNo(vo.getOrdFeedbackInfoNo());
					ordFeedbacklVo.setOrderNo(vo.getOrderNo());
					listVo.add(ordFeedbacklVo);
				}	
				dclOrdFeedbackModel.setFeebackDetailVoList(listVo);
		    }
		}
		base.setData(dclOrdFeedbackModel);
		return base;
	}
	
	/**
	 * 全部布控信息查看数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initAllOrdTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initAllOrdTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
		String currentPage=request.getParameter("currentPage");//当前页号
		String type=request.getParameter("type");//如果是1，则为审单环节的布控
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<DclOrdDetailEntity> list = new ArrayList<DclOrdDetailEntity>();
		if("1".equals(type)){
			list=service.getOrdDetailInfoAudit(declNo, currentPage);
		}else{
			list=service.getOrdDetailInfo(declNo, currentPage);
		}
		
		ArrayList<DclOrdDetailModel> DetailModelList=new ArrayList<DclOrdDetailModel>();
		if(!CollectionUtils.isEmpty(list)){
			DetailModelList.ensureCapacity(list.size());
			for(DclOrdDetailEntity entity:list){
				DclOrdDetailModel model=new DclOrdDetailModel();
				model.setArriveApp(entity.getArriveApp());
				model.setArrivLink(entity.getArrivLink());
				model.setArrivLinkName(CommonCodeToNameUtils.processLinkToName(entity.getArrivLink()));
				model.setConcDesc(entity.getConcDesc());
				model.setConclusionName(entity.getConclusionName());
				model.setExecLevel(entity.getExecLevel());
				DetailModelList.add(model);
			}			
		}
		
		base.setData(DetailModelList);
		return base;
	}
	
	
	/**
	 * 布控回退查看数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initOrdTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initOrdTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
//		String feedbackLink=request.getParameter("feedbackLink");//反馈环节指令
		String deptCode = request.getParameter("deptCode");//用户所属机构
		String fedbackPersn=request.getParameter("fedbackPersn");//反馈人
		String currentPage=request.getParameter("currentPage");//当前页号
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(deptCode)||StringUtils.isEmpty(fedbackPersn)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		DclOrgBackModel dclOrgBackModel= new DclOrgBackModel();
		DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity = service.getOrdFeedBackMain(deptCode,fedbackPersn,declNo, feedbackLink,currentPage);
		if (dclOrdFeedbackMainEntity == null) {
            dclOrdFeedbackMainEntity = new DclOrdFeedbackMainEntity();
            dclOrdFeedbackMainEntity.setDeclNo(declNo);
            dclOrdFeedbackMainEntity.setFeedbackLink(feedbackLink);
            dclOrdFeedbackMainEntity.setOperTime(new Date());
            dclOrdFeedbackMainEntity.setFeedbackTime(new Date());
            dclOrdFeedbackMainEntity.setFedbackPersn(fedbackPersn);
            dclOrdFeedbackMainEntity.setFeedbackOrg(deptCode.substring(0,2)+"0000");
            //默认合格
            dclOrdFeedbackMainEntity.setAssessStatus("1");
        }
		
		if(dclOrdFeedbackMainEntity!=null){
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getDeclNo())){
				dclOrgBackModel.setDeclNo(dclOrdFeedbackMainEntity.getDeclNo());
			}
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getFedbackPersn())){
				dclOrgBackModel.setFedbackPersn(dclOrdFeedbackMainEntity.getFedbackPersn());
				dclOrgBackModel.setFedbackPersnName(subOrReasService.getUserNameUserCode(dclOrdFeedbackMainEntity.getFedbackPersn()));
			}
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getSuplement())){
				dclOrgBackModel.setSuplement(dclOrdFeedbackMainEntity.getSuplement());
			}
			if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getFeedbackOrg())){
				dclOrgBackModel.setFeedbackOrg(dclOrdFeedbackMainEntity.getFeedbackOrg());
				deptCode=deptCode.substring(0,2)+"0000";
				dclOrgBackModel.setFeedbackOrgName(subAuxiliaryService.getOrgCodeNameOrgCode(deptCode));
			}
		}
		List<OrdBackMainVo> list=service.getOrdDetail(declNo, feedbackLink, null);
		List<OrdBackVo> listVo=new ArrayList<OrdBackVo>();
		
		if(!CollectionUtils.isEmpty(list)){
			for(OrdBackMainVo vo:list){
				OrdBackVo ordBackVo=new OrdBackVo();
				ordBackVo.setArrivLink(vo.getArrivLink());
				ordBackVo.setArrivLinkName(CommonCodeToNameUtils.processLinkToName(vo.getArrivLink()));
				ordBackVo.setBackCauseDesc(vo.getBackCauseDesc());
				ordBackVo.setConcDesc(vo.getConcDesc());
				ordBackVo.setConclusionName(vo.getConclusionName());
				ordBackVo.setExecLevel(vo.getExecLevel());
				
				ordBackVo.setDeclNo(vo.getDeclNo());
				ordBackVo.setBackMainNo(vo.getBackMainNo());
				ordBackVo.setOrdBackInfoNo(vo.getOrdBackInfoNo());
				ordBackVo.setBackType(vo.getBackType());
				ordBackVo.setOrderNo(vo.getOrderNo());
				listVo.add(ordBackVo);
			}
			dclOrgBackModel.setOrdBacklist(listVo);
	    }
		base.setData(dclOrgBackModel);
		return base;
	}
	
	/**
	 * 布控反馈暂存或提交
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/ordFeedbackSubmit", method = RequestMethod.POST)
	@ResponseBody
	public DataModel ordFeedbackSubmit(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//机构代码
		String orgCode=request.getParameter("orgCode");//机构代码
		String fedbackPersn=request.getParameter("fedbackPersn");//反馈人
//		String feedbackLink=request.getParameter("feedbackLink");//反馈环节指令
		String ordFeedbackDetail=request.getParameter("ordFeedbackDetail");//布控反馈列表
		String assessStatus = request.getParameter("assessStatus");//综合评定结论
		if(StringUtils.isEmpty(orgCode) ||StringUtils.isEmpty(fedbackPersn)||StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		// 布控反馈列表
	    JSONArray ordFeedbackDetailJson = JSONArray.fromObject(ordFeedbackDetail);
		List<OrdFeedbacklVo> list = (List<OrdFeedbacklVo>) JSONArray
						.toList(ordFeedbackDetailJson, OrdFeedbacklVo.class);
		
		DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity=new DclOrdFeedbackMainEntity();
		dclOrdFeedbackMainEntity = service.getOrdFeedBackMain(orgCode,fedbackPersn,declNo, feedbackLink,"");
		
		if (dclOrdFeedbackMainEntity == null) {
			dclOrdFeedbackMainEntity = new DclOrdFeedbackMainEntity();
            dclOrdFeedbackMainEntity.setDeclNo(declNo);
            dclOrdFeedbackMainEntity.setFeedbackLink(feedbackLink);
            dclOrdFeedbackMainEntity.setOperTime(new Date());
            dclOrdFeedbackMainEntity.setFeedbackTime(new Date());
            dclOrdFeedbackMainEntity.setFedbackPersn(fedbackPersn);
            if(StringUtils.isEmpty(assessStatus)) {
            	assessStatus = "1";
            }
            //默认合格
            dclOrdFeedbackMainEntity.setAssessStatus(assessStatus);
        } else {
        	//默认合格
            if(StringUtils.isEmpty(assessStatus)) {
            	assessStatus = "1";
            }
            dclOrdFeedbackMainEntity.setAssessStatus(assessStatus);
        }
		
		DclOrdFeedbackDetailEntity dclOrdFeedbackDetailEntity = null;
		
		OrdFeedbacklVo ordFeedbacklVo = new OrdFeedbacklVo();
		List<DclOrdFeedbackDetailEntity> detailList = new ArrayList<DclOrdFeedbackDetailEntity>();

		if (!CollectionUtils.isEmpty(list)) {
			for (int i = 0; i < list.size(); i++) {
				ordFeedbacklVo = list.get(i);
				dclOrdFeedbackDetailEntity = new DclOrdFeedbackDetailEntity();
				try {
					PropertyUtils.copyProperties(dclOrdFeedbackDetailEntity,
							ordFeedbacklVo);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				}
				detailList.add(dclOrdFeedbackDetailEntity);
			}
		}
		service.updateFeedbackInfo(dclOrdFeedbackMainEntity, detailList,orgCode,fedbackPersn);
		base.setCode(HttpServletResponse.SC_OK);
		base.setMsg(MobileHelper.OPERATION_SUCCESS_FLAG_TIP);
		return base;
	}
	
	
	/**
	 * 布控回退提交
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/backSubmit", method = RequestMethod.POST)
	@ResponseBody
	public DataModel backSubmit(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
//		String feedbackLink=request.getParameter("feedbackLink");
		String fedbackPersn=request.getParameter("fedbackPersn");
		String deptCode = request.getParameter("deptCode");//用户所属机构
        String selectMain=request.getParameter("selectList");//布控回退列表
        
        if(StringUtils.isEmpty(deptCode) ||StringUtils.isEmpty(fedbackPersn)||StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
        
        
        //选中的布控回退列表
	    JSONArray selectJson = JSONArray.fromObject(selectMain);
		List<OrdBackVo> ordBackMainList = (List<OrdBackVo>) JSONArray
						.toList(selectJson, OrdBackVo.class);
        String orgCode=companyCodeUtils.getBusinessOrgCode(deptCode, false);
		DclOrdBackMainEntity dclOrdBackMainEntity=service.initOrdBackMain(declNo, feedbackLink, orgCode, fedbackPersn);

		
		if(ordBackMainList == null || ordBackMainList.size() <= 0){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("请选择要操作的记录");
			return base;
        }

		if (dclOrdBackMainEntity != null) {
            dclOrdBackMainEntity.setTreatFlag("0");
        }
		
		service.ordBackSave(dclOrdBackMainEntity, ordBackMainList);
		base.setCode(HttpServletResponse.SC_OK);
		base.setMsg(MobileHelper.OPERATION_SUCCESS_FLAG_TIP);
		return base;
	}
	
	
}

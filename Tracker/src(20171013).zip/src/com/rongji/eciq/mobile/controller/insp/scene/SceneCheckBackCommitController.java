/**  
 * FileName: SceneCheckBackCommitController.java    
 * @Description: 现场查验数据提交等controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月17日 下午4:38:03  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.scene;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.SceneContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.ShowMessageModel;
import com.rongji.eciq.mobile.service.insp.scene.SceneCheckBackCommitService;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description: 现场查验数据提交等controller   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月17日 下午4:38:03  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-17      吴有根                    1.0         1.0 Version  
 * 2017-05-26      才江男                    1.0         综合评定
 * 2017-05-27      才江男                    1.0         增加评定环节
 * 2017-05-27      才江男                    1.0         综合评定增加数据回写
 * 2017-06-01      李云龙                    1.0         根据主辅施检更新现场查验-退单流程
 * 
 */

@Controller
@RequestMapping("/insp/sceneCommit")
public class SceneCheckBackCommitController extends MobileExceptionHandlerController{

	@Autowired
	private SceneCheckBackCommitService service;
	
	//数据权限map
	private Map<String, Object> limitsMap=null;
	
    //主辅施捡流程状态
    private String flowPathStatusFlag = null;
    
    /**
     * 
    * <p>描述:现场查验-综合评定初步判断</p>
    * @param request
    * @param response
    * @param declNo  报检号
    * @param userCode 用户代码
    * @param orgCode  用户机构
    * @param confirm  当存在不合格的查验项目是否继续
    * @return
     */
	@RequestMapping(value="/compAssessment/{declNo}/{userCode}/{userOrgCode}/{confirm}",method=RequestMethod.POST)
	public @ResponseBody DataModel compAssessment(HttpServletRequest request,HttpServletResponse response,
			@PathVariable String declNo,@PathVariable String userCode,
			@PathVariable String userOrgCode,@PathVariable String confirm){
		DataModel base=MobileHelper.getBaseModel();
//		DclIoDeclEntity dclIoDeclVO=service.queryDclIoDeclByNo(declNo);
		if(StringUtils.isEmpty(userCode)||StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userOrgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		initJude(declNo,userCode,userOrgCode);
		ShowMessageModel model=new ShowMessageModel();
		if(!StringUtils.equals(InsContext.FLOW_PATH_STATUS_MAIN, flowPathStatusFlag)){
			model.setDeclNo(declNo);
			model.setMessage("只有主施检员才能进行综合评定");
			base.setData(model);
			return base;
		}
		InsResultSumEntity entity=service.getInsResultSumEntityByNo(declNo,userCode);
		if(entity!=null&&StringUtils.isEmpty(entity.getSpotDesc())){
			model.setDeclNo(declNo);
			model.setMessage("请先进行现场查验保存操作");
			base.setData(model);
			return base;
		}
		
		
		//获得综合评定和送检校验信息
//		String verifyMessage=service.getSendAndEvalMessage(declNo, null, flowPathStatusFlag, null, dclIoDeclVO, userOrgCode, null, null);
//		if(StringUtils.isNotEmpty(verifyMessage)){
//			model.setDeclNo(declNo);
//			model.setMessage(verifyMessage);
//			base.setData(model);
//			return base;
//		}
		
		String message="";
		//判断是否存在不合格的查验项目或货物检疫、检疫结果
		if(service.isCheckItemFail(declNo)){
			message="不合格的查验项目,";
		}
//		if(service.isGoodsResultFail(declNo)){
//			message+="不合格的货物检验或检疫结果";
//		}
		
		if (confirm == null) {
			if (StringUtils.isNotEmpty(message)) {
				message = "存在" + message + "是否进行综合评定?";
				model.setDeclNo(declNo);
				model.setMessage(message);
				base.setData(model);
				return base;
			}
		}
		
		DclIoDeclEntity dclIoDeclEntity=service.queryDclIoDeclByDeclNo(declNo);
		Map<String, Object> isClose=service.synthesizeEvaluate(declNo,dclIoDeclEntity.getDeclWorkNo(),InsContext.CHECK_EVALUATE_TYPE,dclIoDeclEntity.getProcessStatus(),dclIoDeclEntity.getProcessLink());
		Boolean flag=false;
		if(isClose.get("flag")!=null){
			flag=(Boolean)isClose.get("flag");
		}
		if(flag){
			model.setDeclNo(declNo);
			model.setMessage(MobileHelper.OPERATION_SUCCESS_FLAG_TIP+"等待是否进行自动综合评定");
			base.setData(model);
		}else{
			model.setDeclNo(declNo);
			model.setMessage(isClose.get("msg").toString());
			base.setData(model);
		}
		return base;
	}
	
	/**
	 * 
	* <p>描述:根据报检单号判断报检单的状态(主施检、辅施检)</p>
	* @param declNo
	* @author 吴有根
	 */
	public void initJude(String declNo,String userCode,String orgCode){
		limitsMap=service.getLoginUserPermission(declNo,SceneContext.PROCEDURE_CODE, userCode, orgCode);
		flowPathStatusFlag = (String) limitsMap.get(SceneContext.FLOW_PATH_STATUS_MAIN);
	}
	
	
	/**
	 * 
	* <p>描述:现场查验-退单</p>
	* @param request
	* @param response
	* @return
	 */
	@RequestMapping(value="/declBack/{declNo}/{userCode}/{userOrgCode}/{expImpFlag}/{flowPathStatus}",method=RequestMethod.POST)
	public @ResponseBody DataModel declBack(HttpServletRequest request,HttpServletResponse response,
			@PathVariable String declNo,@PathVariable String userCode,@PathVariable String userOrgCode,
			@PathVariable String expImpFlag,@PathVariable String flowPathStatus){
		DataModel base=MobileHelper.getBaseModel();
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userCode)||StringUtils.isEmpty(userOrgCode)||StringUtils.isEmpty(flowPathStatus)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		ShowMessageModel model=new ShowMessageModel();
		if(!StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_MAIN)){
			model.setDeclNo(declNo);
			model.setMessage("只有主施检允许退回至审单环节");
			base.setData(model);
			return base;
		}
		
		DclIoDeclEntity dclIoDeclEntity=service.queryDclIoDeclByDeclNo(declNo);
		if(dclIoDeclEntity!=null&&StringUtils.equals(CommContext.INS, dclIoDeclEntity.getProcessLink())){
			model.setDeclNo(declNo);
			model.setMessage("该报检单已经回退到审单环节");
			base.setData(model);
			return base;
		}
		
		List<InsDeclMagEntity> insDeclMagList=service.getInsDeclMag(declNo,expImpFlag,userOrgCode,flowPathStatus);
		if(Utils.notEmpty(insDeclMagList)&&insDeclMagList.size()==1){
			InsDeclMagEntity insDeclMagEntity=insDeclMagList.get(0);
			String declMagId=insDeclMagEntity.getDeclMagId();
			String inOutFlag=StringUtils.isEmpty(expImpFlag)?"1":expImpFlag	;//出入境标志
			String workNo=insDeclMagEntity.getDeclWorkNo();
			
			try {
				service.declBack(declMagId,declNo,inOutFlag,dclIoDeclEntity,workNo,userCode,userOrgCode,insDeclMagEntity);
				model.setDeclNo(declNo);
				model.setMessage(MobileHelper.OPERATION_SUCCESS_FLAG_TIP+",已退回至审单环节");
				base.setData(model);
				return base;
			} catch (Exception e) {
				base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
				base.setData(model);
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				e.printStackTrace();
			}
		}
		return base;
	}
	
	/**
	* <p>描述: 审核</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/synthBatchEval",method=RequestMethod.POST)
	@ResponseBody
	public DataModel synthBatchEval(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String userCode = request.getParameter("userCode");//用户代码
		String orgCode = request.getParameter("orgCode");//部门代码
		String list = request.getParameter("list");//评定数据
		String flag = request.getParameter("flag");
		if(StringUtils.isEmpty(list) || StringUtils.isEmpty(userCode) || StringUtils.isEmpty(orgCode) || StringUtils.isEmpty(flag)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//审核
		ShowMessageModel back = service.synthBatchEval(request, response, list, userCode, orgCode, flag);
		
		base.setData(back);
		return base;
	}
}

/**  
 * FileName: SceneCheckInitController.java    
 * @Description: 现场查验Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月17日 下午4:38:03  
 *  
 */  
package com.rongji.eciq.mobile.controller.insp.scene;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.rongji.common.mfile.FileManager;
import com.rongji.common.mfile.FileManagerHolder;
import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.context.DeclevalConstants;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.context.SceneContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.controller.sys.DeclNoCountController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsContainerResultEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.BigDataModel;
import com.rongji.eciq.mobile.model.base.ContBigDataModel;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.BaseModel;
import com.rongji.eciq.mobile.model.insp.scene.DeclBaseInfoModel;
import com.rongji.eciq.mobile.model.insp.scene.DialogPromptMessageModel;
import com.rongji.eciq.mobile.model.insp.scene.FileModel;
import com.rongji.eciq.mobile.model.insp.scene.GoodsResultRegisterModel;
import com.rongji.eciq.mobile.model.insp.scene.InsCheckItemModel;
import com.rongji.eciq.mobile.model.insp.scene.InsCheckItemSubTreeModel;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModel;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelAnimal;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelCont;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelDetail;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelHealth;
import com.rongji.eciq.mobile.model.insp.scene.InsResultGoodsModel;
import com.rongji.eciq.mobile.model.insp.scene.InsResultSumModel;
import com.rongji.eciq.mobile.model.insp.scene.PaperLessModel;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.model.insp.scene.ShowMessageModel;
import com.rongji.eciq.mobile.sendxml.service.DclOrdFeedBackMainHandel;
import com.rongji.eciq.mobile.sendxml.service.InsResultSumHandel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.scene.SceneCheckBackCommitService;
import com.rongji.eciq.mobile.service.insp.scene.SceneService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;
import com.rongji.eciq.mobile.vo.insp.FileVo;
import com.rongji.eciq.server.entity.InsDeclLobEntity;
import com.rongji.system.entity.SysAppProcessLog;
import com.rongji.system.sys.service.SysUserService;
import com.rongji.system.sys.service.UserService;

/**
 * Description: 现场查验Controller
 * @author 	 	吴有根
 * @version 	1.0
 * Modification History:  
 * Date          Author     Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-19    才江男                     1.0.0       增加检验依据代码转名称
 * 2017-04-19    才江男                     1.0.0       增加附件上传
 * 2017-04-24    魏波                         1.0.0       现场查验跳不合格登记
 * 2017-04-25    才江男                     1.0.0       货物不合格登记代码转名称
 * 2017-04-25    才江男                     1.0.0       获取附件时，增加人员条件
 * 2017-04-27    才江男                     1.0.0       审单进入现场查验
 * 2017-04-28    才江男                     1.0.0       增加主辅检标志代码返回
 * 2017-05-03    吴有根                     1.0.0       无纸化部门代码转机构代码查询
 * 2017-05-03    才江男                     1.0.0       实际重量null为空字符串
 * 2017-05-05    才江男                     1.0.0       实际数量、实际抽样量默认为0
 * 2017-05-05    才江男                     1.0.0       删除附件
 * 2017-05-08    才江男                     1.0.0       单独删除附件
 * 2017-05-09    才江男                     1.0.0       数据回写
 * 2017-05-10    吴有根                     1.0.0       现场查验-查看更改返回josn的格式  
 * 2017-05-11    才江男                     1.0.0       结束查验
 * 2017-05-12    魏波                         1.0         根据报检单号查第一条货物的名称
 * 2017-05-12    吴有根                     1.0.0       报检单号短号变长号
 * 2017-05-12    吴有根                     1.0.0       增加货物评定合格判断&返回集装箱检疫、木质包装检疫结果
 * 2017-05-13    才江男                     1.0.0       不合格登记时，更新现场记录货物评定为不合格
 * 2017-05-15    才江男                     1.0.0       获取完整访问的无纸化地址
 * 2017-05-15    魏波                         1。0         现场查验退单添加流程日志
 * 2017-05-15    李云龙                         1。0         添加更新报检信息流程环节，流程状态
 * 2017-05-16    吴有根                      1.0.0       不合格登记-集装箱不合格登记监听
 * 2017-05-18    才江男                     1.0.0       保存现场记录后，返回数据，需要后续操作
 * 2017-05-24    才江男                      1.0.0       增加返回报检号
 * 2017-05-26    才江男                      1.0.0       更新流程环节及流程状态
 * 2017-05-26    才江男                      1.0.0       检验依据
 * 2017-05-26    才江男                      1.0.0       查验人员代码转名称
 * 2017-05-26    才江男                      1.0.0       更新流程状态
 * 2017-05-27    才江男                      1.0.0       流程日志放到service
 * 2017-05-27    才江男                      1.0.0       实际货物总值，Double改为BigDecimal
 * 2017-06-01    李云龙                     1.0。0       根据主辅施检更新保存现场记录流程
 * 2017-06-02    才江男                      1.0.0       天气初始化为空字符串
 * 2017-06-06     魏波                            1.0        辅检完成公用方法
 * 2017-06-07    魏波                           1.0.0       现场记录保存检疫和检测结果评定
 * 2017-06-07    才江男                      1.0         辅施检数据回写
 * 2017-06-13    才江男                      1.0         辅施检改为结果登记回写
 * 2017-06-16    才江男                      1.0         更新权限，不可查询
 * 2017-06-19    才江男                      1.0         现场记录描述为null
 * 2017-06-22    才江男                      1.0         保存检验评定结果，检疫评定结果
 * 2017-07-05    张锡森                      1.0         现场查验保存时多次保存有多个流程日志记录问题
 * 2017-07-06    张锡森                      1.0         结果登记保存时多次保存有多个流程日志记录问题
 * 2017-07-11    才江男                      1.0         增加审核开关
 * 2017-07-20    才江男                      1.0         附件
 * 2017-07-26            吴有根                      1.0		             根据报检单号带出企业、生产批号等基本信息
 * 2017-08-02    才江男                      1.0         完善附件上传
 * 2017-08-29            吴有根                      1.0		             报检单回写操作流程记录(&适用统计)
 * 2017-09-15    夏晨琳                      2.0         修改记录报检单回写记录信息
 * 2017-09-20    才江男                      2.0         增加保存和提交标志
 */

@Controller
@RequestMapping("/insp/scene")
public class SceneCheckInitController extends MobileExceptionHandlerController{

	@Autowired
	private SceneService service;
	@Autowired
	private SceneProcessSerchService processService;
	@Autowired
	private SceneCheckBackCommitService commitService;
	
	@Autowired
	private SubOrReasService subOrReasService;
	@Autowired
	private SubAuditService subService;
	@Resource
	private HQLCodeToNameDao codeToNameUtils;
	
	@Resource
	private CompanyCodeUtils companyCodeUtils;
	@Resource
	private StatusControlUtils statusControlUtils;
	
	@Autowired
	InsResultSumHandel insResultSumHandel;
	@Autowired
	DclOrdFeedBackMainHandel dclOrdFeedBackMainHandel;
	
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	@Autowired
	private DeclNoUtils declNoUtils;
	private String orgCode;
	
	@Autowired
	private SysUserService userService;
	@Autowired
	private SceneService sceneService;
	/**
	 * 现场查验界面初始化数据
	 * @param expImpFlag   	        出入境标志
	 * @param exeInspOrgCode   施检机构代码
	 * @param receiverDocCode  接单员代码
	 * @param declNo		       报检单号
	 * @param declRegName      报检单位
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSceneTable",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSceneTable(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String exeInspOrgCode=request.getParameter("exeInspOrgCode");//施检机构
		String receiverDocCode=request.getParameter("receiverDocCode");//接单员代码
		String declNo=request.getParameter("declNo");//报检号
		String declRegName=Utils.getParameter(request, "declRegName");//报检单位
		String currentPage=request.getParameter("currentPage");//当前页号
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(exeInspOrgCode)||StringUtils.isEmpty(receiverDocCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
//			UserInfo user = new UserInfo();
//			user.setUserCode(userCode);
//			SysUser sysUser = subOrReasDao.getSysUser(userCode);
//			if (sysUser != null) {
//				user.setCompanyCode(sysUser.getOrgCode());
//				user.setUserName(sysUser.getUserName());
//			}
//			String longDeclNo = "";
//			if (expImpFlag.equals("1")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_IN, user);
//			} else if (expImpFlag.equals("2")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_OUT, user);
//			}
//			declNo = longDeclNo;
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
        //----------------------------------短号变长号--------------------------------------------------
		
		List<SubOrReasEntity> queryMagList=service.getMagList(expImpFlag,exeInspOrgCode,receiverDocCode,declNo,declRegName,currentPage);
		ArrayList<SceneCheckInitTableModel> list=new ArrayList<SceneCheckInitTableModel>();
		if(!CollectionUtils.isEmpty(queryMagList)){
			list.ensureCapacity(queryMagList.size());
			for(SubOrReasEntity entity:queryMagList){
				SceneCheckInitTableModel model=new SceneCheckInitTableModel();
				model.setDeclNo(entity.getDeclNo());
				model.setInsRequire(entity.getInspRequire());
				List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(entity.getDeclNo());
				if(CollectionUtils.isEmpty(dcl)){
					model.setDeclRegName("");
				}else{
					model.setDeclRegName(dcl.get(0).getDeclRegName());
				}
//				model.setDeclRegName(entity.getDeclRegName());
				model.setFlowPathStatus(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
				model.setFlowPathStatusCode(entity.getFlowPathStatus());
//				model.setGoodsName(entity.getGoodsName());
				model.setGoodsName(subService.getGoodName(entity.getDeclNo()));
				if(StringUtils.isNotEmpty(entity.getRemark())){
					model.setTradeCountryCode(entity.getRemark());
					//entity.setRemark(entity.getRemark().substring(0, entity.getRemark().indexOf("$")));
				}else{
					model.setTradeCountryCode("");
					//entity.setRemark("");
				}
				model.setDeclDate(DateUtil.format(entity.getDeclDate(), "yyyy-MM-dd"));
				list.add(model);
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(list);
		base.setData(vo);
		return base;
	}
	
	/**
	 * 现场查验跳不合格登记
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initResultRegister",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initResultRegister(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String goodsNo=request.getParameter("goodsNo");
		String ioFlag = request.getParameter("ioFlag");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(goodsNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		GoodsResultRegisterModel model = service.getInsResultGoodsEntity(declNo, goodsNo, ioFlag);
		base.setData(model);
		return base;
	}
	
	/**
	 * 不合格登记保存
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/isSave",method=RequestMethod.POST)
	@ResponseBody
	public DataModel isSave(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String register = request.getParameter("register");
		String declNo = request.getParameter("declNo");
		String code = request.getParameter("code");
		String type = request.getParameter("type");
		JSONArray addjson = JSONArray.fromObject(register); 
		List<GoodsResultRegisterModel> addList = (List<GoodsResultRegisterModel>)JSONArray.toList(addjson, GoodsResultRegisterModel.class); 
		
		if(CollectionUtils.isEmpty(addList) || StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		if(subOrReasService.updateResiter(addList.get(0), declNo,code,type)){
			base.setData("操作成功");
			return base;
		}else{
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
			return base;
		}
	}
	
	/**
	 * 结果登记保存
	 * @param request
	 * @param response
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/saveRegister",method=RequestMethod.POST)
	@ResponseBody
	public DataModel saveRegister(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String receiverDocCode = request.getParameter("receiverDocCode");
		String flowPathStatus = request.getParameter("flowPathStatus");
		String declNo = request.getParameter("declNo");
		String submitFlag = request.getParameter("submitFlag");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(receiverDocCode)||StringUtils.isEmpty(flowPathStatus)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		String goodsInfosOld = request.getParameter("goodsInfosList");
		if(StringUtils.isNotEmpty(goodsInfosOld)){
			String goodsInfos = goodsInfosOld.substring(1, goodsInfosOld.length()-1);
			JSONArray ResultGoods = JSONArray.fromObject(goodsInfos);
			List<InsResultGoodsModel> resultList =(List<InsResultGoodsModel>)JSONArray.toList(ResultGoods, InsResultGoodsModel.class);
			//货物信息
			if(CollectionUtils.isNotEmpty(resultList)){
				String quarResSpotCode;//检疫不合格
				String inspResSpotCode;//检验不合格
				for(InsResultGoodsModel model:resultList){
					InsResultGoodsEntity entity = new InsResultGoodsEntity();
					entity.setDeclNo(declNo);//报检号
					entity.setGoodsNo(Double.parseDouble(model.getGoodsNo()));//货物编号
					entity.setGoodsTotalVal(new BigDecimal(Double.parseDouble(model.getGoodsTotalVal())));//实际货物总值
					entity.setPackQty(Double.parseDouble(model.getPackQty()));//包装件数量
					entity.setRealWeight(new BigDecimal(model.getRealWeight()));//实际重量
					entity.setActualQty(Double.parseDouble(model.getActualQty()));//实际数量
					entity.setActSmplNum(Double.parseDouble(model.getActSmplNum()));//实际抽样量
					
					quarResSpotCode = model.getQuarResSpotCode();
					entity.setQuarResSpot(quarResSpotCode);//检疫结果代码
					if(DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL.equals(quarResSpotCode) || DeclevalConstants.INSP_RESULT_PASS.equals(quarResSpotCode)) {
						entity.setQuarResEval(quarResSpotCode);
					}
					
					inspResSpotCode = model.getInspResSpotCode();
					entity.setInspResSpot(inspResSpotCode);//检验结果代码
					if(DeclevalConstants.INSP_QUAR_RESULT_INSP_FAIL.equals(inspResSpotCode) || DeclevalConstants.INSP_RESULT_PASS.equals(inspResSpotCode)) {
						entity.setInspResEval(inspResSpotCode);
					}
					entity.setInspPatternCode(model.getInspPatternCode());//检验方式代码
					subOrReasService.updateEntity(entity);
				}
			}
		}
		
		String portInspInfosOld = request.getParameter("portInspInfosList");
		List<InsCheckItemModel> insCheckItemPortModelList=new ArrayList<InsCheckItemModel>();
		List<InsCheckItemModel> insCheckItemPortModelList1=new ArrayList<InsCheckItemModel>();
		List<InsCheckItemModel> insCheckItemPortModelList2=new ArrayList<InsCheckItemModel>();
		List<InsCheckItemModel> insCheckItemPortModelList3=new ArrayList<InsCheckItemModel>();
		List<InsCheckItemModel> insCheckItemPortModelList4=new ArrayList<InsCheckItemModel>();
		if(StringUtils.isNotEmpty(portInspInfosOld)&&!"[]".equals(portInspInfosOld)){
			String portInspInfos = portInspInfosOld.substring(1, portInspInfosOld.length()-1);
			JSONArray port = JSONArray.fromObject(portInspInfos);
			insCheckItemPortModelList =(List<InsCheckItemModel>)JSONArray.toList(port, InsCheckItemModel.class);
		} else {
			// phone
			String portInspInfosOld1 = request.getParameter("portInspInfosList1");
			String portInspInfos1 = portInspInfosOld1.substring(1, portInspInfosOld1.length() - 1);
			JSONArray port1 = JSONArray.fromObject(portInspInfos1);
			insCheckItemPortModelList1 = (List<InsCheckItemModel>) JSONArray.toList(port1, InsCheckItemModel.class);

			String portInspInfosOld2 = request.getParameter("portInspInfosList2");
			String portInspInfos2 = portInspInfosOld2.substring(1, portInspInfosOld2.length() - 1);
			JSONArray port2 = JSONArray.fromObject(portInspInfos2);
			insCheckItemPortModelList2 = (List<InsCheckItemModel>) JSONArray.toList(port2, InsCheckItemModel.class);

			String portInspInfosOld3 = request.getParameter("portInspInfosList3");
			String portInspInfos3 = portInspInfosOld3.substring(1, portInspInfosOld3.length() - 1);
			JSONArray port3 = JSONArray.fromObject(portInspInfos3);
			insCheckItemPortModelList3 = (List<InsCheckItemModel>) JSONArray.toList(port3, InsCheckItemModel.class);

			String portInspInfosOld4 = request.getParameter("portInspInfosList4");
			String portInspInfos4 = portInspInfosOld4.substring(1, portInspInfosOld4.length() - 1);
			JSONArray port4 = JSONArray.fromObject(portInspInfos4);
			insCheckItemPortModelList4 = (List<InsCheckItemModel>) JSONArray.toList(port4, InsCheckItemModel.class);

			insCheckItemPortModelList.addAll(insCheckItemPortModelList1);
			insCheckItemPortModelList.addAll(insCheckItemPortModelList2);
			insCheckItemPortModelList.addAll(insCheckItemPortModelList3);
			insCheckItemPortModelList.addAll(insCheckItemPortModelList4);
		}	
			
		//查验项目列表
		if(CollectionUtils.isNotEmpty(insCheckItemPortModelList)){
			for(InsCheckItemModel model :insCheckItemPortModelList ){
				InsCheckItemEntity entity = new InsCheckItemEntity();
				entity.setDeclNo(declNo);//报检号
				entity.setGoodsNo(Double.parseDouble(model.getGoodsNo()));//货物编号
				entity.setCheckItemCode(model.getCheckItemCode());//查验项目编码
				entity.setWhetherQualfy(model.getWhetherQualfyCode());//是否合格代码
				entity.setBatchDesc(model.getBatchDesc());//查验情况描述
				entity.setSampleSch(model.getSampleSchCode());//抽样方案类别代码
				subOrReasService.updateEntity(entity);
			}
		}
		
		String containerInfosOld = request.getParameter("containerInfosList");
		if(StringUtils.isNotEmpty(containerInfosOld)){
			String containerInfos = containerInfosOld.substring(1, containerInfosOld.length()-1);
			JSONArray container = JSONArray.fromObject(containerInfos);
			List<InsCheckItemModel> insCheckItemContModelList =(List<InsCheckItemModel>)JSONArray.toList(container, InsCheckItemModel.class);
			//集装箱检疫
			if(CollectionUtils.isNotEmpty(insCheckItemContModelList)){
				for(InsCheckItemModel model :insCheckItemContModelList ){
						InsCheckItemEntity entity = new InsCheckItemEntity();
						entity.setDeclNo(declNo);//报检号
						entity.setGoodsNo(Double.parseDouble(model.getGoodsNo()));//货物编号
						entity.setCheckItemCode(model.getCheckItemCode());//查验项目编码
						entity.setWhetherQualfy(model.getWhetherQualfyCode());//是否合格代码
						entity.setBatchDesc(model.getBatchDesc());//查验情况描述
						entity.setSampleSch(model.getSampleSchCode());//抽样方案类别代码
						subOrReasService.updateEntity(entity);
				}
				
			}
		}
		
		String healthInfosOld = request.getParameter("healthInfosList");
		if(StringUtils.isNotEmpty(healthInfosOld)){
			String healthInfos = healthInfosOld.substring(1, healthInfosOld.length()-1);
			JSONArray health = JSONArray.fromObject(healthInfos);
			List<InsCheckItemModel> insCheckItemHealthModelList =(List<InsCheckItemModel>)JSONArray.toList(health, InsCheckItemModel.class);
			//卫生检疫
			if(CollectionUtils.isNotEmpty(insCheckItemHealthModelList)){
				for(InsCheckItemModel model :insCheckItemHealthModelList ){
					InsCheckItemEntity entity = new InsCheckItemEntity();
					entity.setDeclNo(declNo);//报检号
					entity.setGoodsNo(Double.parseDouble(model.getGoodsNo()));//货物编号
					entity.setCheckItemCode(model.getCheckItemCode());//查验项目编码
					entity.setWhetherQualfy(model.getWhetherQualfyCode());//是否合格代码
					entity.setBatchDesc(model.getBatchDesc());//查验情况描述
					entity.setSampleSch(model.getSampleSchCode());//抽样方案类别代码
					subOrReasService.updateEntity(entity);
				}
			}
		}
		
		String checkInspInfoOld = request.getParameter("checkInspInfosList");
		if(StringUtils.isNotEmpty(checkInspInfoOld)){
			String checkInspInfos = checkInspInfoOld.substring(1, checkInspInfoOld.length()-1);
			JSONArray checkInsp = JSONArray.fromObject(checkInspInfos);
			List<InsCheckItemModel> insCheckItemCheckGoodsModelList =(List<InsCheckItemModel>)JSONArray.toList(checkInsp, InsCheckItemModel.class);
			//检验检疫
			if(CollectionUtils.isNotEmpty(insCheckItemCheckGoodsModelList)){
				for(InsCheckItemModel model :insCheckItemCheckGoodsModelList ){
					InsCheckItemEntity entity = new InsCheckItemEntity();
					entity.setDeclNo(declNo);//报检号
					entity.setGoodsNo(Double.parseDouble(model.getGoodsNo()));//货物编号
					entity.setCheckItemCode(model.getCheckItemCode());//查验项目编码
					entity.setWhetherQualfy(model.getWhetherQualfyCode());//是否合格代码
					entity.setBatchDesc(model.getBatchDesc());//查验情况描述
					entity.setSampleSch(model.getSampleSchCode());//抽样方案类别代码
					subOrReasService.updateEntity(entity);
				}
			}

		}
		SysUser sysUser = subOrReasService.getSysUser(receiverDocCode);
		//辅检完成
		subOrReasService.judgeLoginUserIsChecked(declNo, sysUser, flowPathStatus);
		
//		DclIoDeclEntity dclEntity=commitService.queryDclIoDeclByDeclNo(declNo);
		String processStatus=MobileCommContext.INS_RESULT;
		String processNode=MobileCommContext.RESULT;
		SysAppProcessLog log = service.getSysAppProcessLog(declNo);
		//如果为空则，创建一条新的流程记录，否则，对原来的记录更新
		boolean flag=false;
		if(log==null){
			log=new SysAppProcessLog();
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			flag=true;
		}else {
			String node=log.getProcessNode();
			String status=log.getProcessStatus();
			if (processNode.equals(node)&&processStatus.equals(status)) {
				flag=false;
			}else {
				log=new SysAppProcessLog();
				log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
				flag=true;
			}
		}
		//移动端查验流程日志
//		SysAppProcessLog log = new SysAppProcessLog();
		String orgCode = "";
		if (sysUser != null) {
			log.setOperCode(receiverDocCode);
			log.setOperName(sysUser.getUserName());
			log.setTreaOrgCode(sysUser.getOrgCode());
			orgCode = sysUser.getOrgCode();
		}
//		log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		log.setDeclNo(declNo);
		log.setProcessNode(MobileCommContext.RESULT);
		log.setNodeMemo(MobileCommContext.RESULT_NAME);
		log.setProcessStatus(MobileCommContext.INS_RESULT);
		log.setStatusMemo(MobileCommContext.INS_RESULT_NAME);
		log.setRemark("保存结果登记信息");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		Date newDate;
		try {
			newDate = formatter.parse(dateString);
			log.setOperDate(newDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		//辅施检回写，sum_sc表
/*		if(StringUtils.isNotEmpty(submitFlag) && ("801".equals(flowPathStatus) || "802".equals(flowPathStatus))) {
			sendBackSum(request, response, declNo, flowPathStatus, receiverDocCode, orgCode);
			//更新权限，不可查询
//			service.updatePriv(declNo);
		}*/
		if(flag){
			processService.savelog(log);
		}else{
			processService.updateLog(log);
		}
		
		statusControlUtils.updateProcess(declNo, MobileCommContext.RESULT, MobileCommContext.INS_RESULT, receiverDocCode);
		
		//判断复审开关
		String reCheckSwitch=service.getReCheckSwitchFlag(companyCodeUtils.getBusinessOrgCode(orgCode, false),CommContext.RECHECK_SWITCH);
		if(StringUtils.isNotEmpty(reCheckSwitch)) {
			base.setData(reCheckSwitch);
		} else {
			base.setData("操作成功");
		}
		return base;
	}
	
	/**
	* <p>描述: 回写现场查验信息</p>
	* @param request
	* @param response
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param userCode 用户代码
	* @author 才江男
	 */
	private void sendBackSum(HttpServletRequest request,HttpServletResponse response, String declNo, String flowPathStatus, String userCode, String orgCode) {
		
		// 机构
		if (StringUtils.isEmpty(orgCode) || 6 > orgCode.length()) {
			return ;
		}
		// 机构
		String businessOrgCode = orgCode.substring(0, 2) + "0000";

		// 现场查验
		insResultSumHandel.getSendInsResultSum(request,
				response, declNo, flowPathStatus, userCode, orgCode,
				businessOrgCode);
	}
	
	/**
	 * 现场查验-货物、口岸查验、集装箱检疫、卫生检疫、检验检疫数据查看
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSceneCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSceneCheck(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String expImpFlag=request.getParameter("expImpFlag");
		String goodsNo=request.getParameter("goodsNo");
		String currentPage=request.getParameter("currentPage");
		String checkItemName=Utils.getParameter(request, "checkItemName");//查验项目名称
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		BigDataModel bigDataModel=new BigDataModel();
		
		//货物的基本信息
		List<InsResultGoodsEntity> resultList=service.getInsResultGoodsList(declNo,currentPage);
		ArrayList<InsResultGoodsModel> modelList=new ArrayList<InsResultGoodsModel>();
		if(Utils.notEmpty(resultList)){
			for(InsResultGoodsEntity entity:resultList){
				InsResultGoodsModel model=new InsResultGoodsModel();
				model.setDeclNo(entity.getDeclNo());
				model.setGoodsNo(entity.getGoodsNo()!=null?(entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setGoodsNameCn(entity.getGoodsNameCn());//货物名称
				model.setStatKindCode(codeToNameUtils.getProductCiqNameByCode(entity.getStatKindCode(), "CiqCode"));//商品统计分类代码
				model.setDeclGoodsValues(entity.getDeclGoodsValues()+"");//报检货物总值
				model.setCurrency(codeToNameUtils.getMeasurementNameByCode(entity.getCurrency(), "CurrencyType"));//币种
				model.setGoodsTotalVal(entity.getGoodsTotalVal()+"");//实际货币总值
				model.setPackQty(entity.getPackQty()!=null?(entity.getPackQty()+"").substring(0, (entity.getPackQty()+"").indexOf(".")):"");//包装件数量
				model.setRiskInfoLevelCode(entity.getRiskInfoLevelCode());//产品风险等级
				model.setInspRequire("");//检验要求
				model.setBatchRatio("");//抽批率
				BigDecimal weight = entity.getRealWeight();
				model.setRealWeight(weight == null ? "0" : weight+"");//实际重量
				model.setActualQty(entity.getActualQty()!=null?(entity.getActualQty()+"").substring(0, (entity.getActualQty()+"").indexOf(".")):"0");//实际数量
				model.setActSmplNum(entity.getActSmplNum()!=null?(entity.getActSmplNum()+"").substring(0, (entity.getActSmplNum()+"").indexOf(".")):"0");//实际抽样量
				model.setQuarResSpot(CommonCodeToNameUtils.inspquarCodeToName(entity.getQuarResSpot()));//检疫结果
				model.setQuarResSpotCode(entity.getQuarResSpot());//检疫结果代码
				model.setInspResSpot(CommonCodeToNameUtils.inspquarCodeToName2(entity.getInspResSpot()));//检验结果
				model.setInspResSpotCode(entity.getInspResSpot());//检验结果代码
				model.setInspPattern(codeToNameUtils.getCheckoutMethodNameByCode(entity.getInspPatternCode(), "CheckoutMethod"));//检验方式
				model.setInspPatternCode(entity.getInspPatternCode());//检验方式代码
				
				modelList.add(model);
			}
			//list.add(modelList);
			bigDataModel.setInsResultGoods(modelList);//货物信息
		}
		
		//查验项目列表
		List<InsCheckItemEntity> insCheckItemList=new ArrayList<InsCheckItemEntity>();
		ArrayList<InsCheckItemModel> insCheckItemPortModelList=new ArrayList<InsCheckItemModel>();
		if(StringUtils.isEmpty(goodsNo)){
			goodsNo="1";//默认取第一条货物的查验项目信息
		}
		insCheckItemList=service.getInsCheckItemList(declNo,goodsNo,checkItemName);
		Map<String, List<InsCheckItemEntity>> itemCacheMap = null;
		itemCacheMap=buildInsCheckItemData(insCheckItemList);
		List<InsCheckItemEntity> insCheckItemPortList=new ArrayList<InsCheckItemEntity>();
		insCheckItemPortList = itemCacheMap.get(InsContext.PORT_INS_SCENE_ITEM);
		if(Utils.notEmpty(insCheckItemPortList)){
			insCheckItemPortModelList.ensureCapacity(insCheckItemPortList.size());
			for(InsCheckItemEntity entity:insCheckItemPortList){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemPortModelList.add(model);
			}
		}
		
		//*******20170830 手机端区分口岸查验 S
		List<InsCheckItemEntity> insCheckItemPortList1=new ArrayList<InsCheckItemEntity>();//货物检疫
		ArrayList<InsCheckItemModel> insCheckItemPortModelList1=new ArrayList<InsCheckItemModel>();

		List<InsCheckItemEntity> insCheckItemPortList2=new ArrayList<InsCheckItemEntity>();//货物检验
		ArrayList<InsCheckItemModel> insCheckItemPortModelList2=new ArrayList<InsCheckItemModel>();

		List<InsCheckItemEntity> insCheckItemPortList3=new ArrayList<InsCheckItemEntity>();//货物鉴定
		ArrayList<InsCheckItemModel> insCheckItemPortModelList3=new ArrayList<InsCheckItemModel>();

		List<InsCheckItemEntity> insCheckItemPortList4=new ArrayList<InsCheckItemEntity>();//木质包装检疫
		ArrayList<InsCheckItemModel> insCheckItemPortModelList4=new ArrayList<InsCheckItemModel>();

		insCheckItemPortList1=itemCacheMap.get(InsContext.INS_SCENE_GOODS_ITEM_TYPE_1);
		if(Utils.notEmpty(insCheckItemPortList1)){
			insCheckItemPortModelList1.ensureCapacity(insCheckItemPortList1.size());
			for(InsCheckItemEntity entity:insCheckItemPortList1){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemPortModelList1.add(model);
			}
		}
		bigDataModel.setInsCheckItemPorts1(insCheckItemPortModelList1);
		
		insCheckItemPortList2=itemCacheMap.get(InsContext.INS_SCENE_GOODS_ITEM_TYPE_2);
		if(Utils.notEmpty(insCheckItemPortList2)){
			insCheckItemPortModelList2.ensureCapacity(insCheckItemPortList2.size());
			for(InsCheckItemEntity entity:insCheckItemPortList2){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemPortModelList2.add(model);
			}
		}
		//货物检验
		bigDataModel.setInsCheckItemPorts2(insCheckItemPortModelList2);
		
		insCheckItemPortList3=itemCacheMap.get(InsContext.INS_SCENE_GOODS_ITEM_TYPE_3);
		if(Utils.notEmpty(insCheckItemPortList3)){
			insCheckItemPortModelList3.ensureCapacity(insCheckItemPortList3.size());
			for(InsCheckItemEntity entity:insCheckItemPortList3){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemPortModelList3.add(model);
			}
		}
		bigDataModel.setInsCheckItemPorts3(insCheckItemPortModelList3);
		
		insCheckItemPortList4=itemCacheMap.get(InsContext.WOOD_ITEM_CODE);
		if(Utils.notEmpty(insCheckItemPortList4)){
			insCheckItemPortModelList4.ensureCapacity(insCheckItemPortList4.size());
			for(InsCheckItemEntity entity:insCheckItemPortList4){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemPortModelList4.add(model);
			}
		}
		bigDataModel.setInsCheckItemPorts4(insCheckItemPortModelList4);
		
		//*******20170830 手机端区分口岸查验 E
		
	//	list.add(buildJsonInsCheckItemTree(insCheckItemPortModelList));
		//2017-4-13 不转json树
		//list.add(insCheckItemPortModelList);
		bigDataModel.setInsCheckItemPorts(insCheckItemPortModelList);//口岸查验
		
		
		//集装箱检疫
		List<InsCheckItemEntity> insCheckItemContList=new ArrayList<InsCheckItemEntity>();
		ArrayList<InsCheckItemModel> insCheckItemContModelList=new ArrayList<InsCheckItemModel>();
		insCheckItemContList = itemCacheMap.get(InsContext.CONT_ITEM_CODE);
		if(Utils.notEmpty(insCheckItemContList)){
			insCheckItemContModelList.ensureCapacity(insCheckItemContList.size());
			for(InsCheckItemEntity entity:insCheckItemContList){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemContModelList.add(model);
			}
		}
	//	list.add(insCheckItemContModelList);
		bigDataModel.setInsCheckItemConts(insCheckItemContModelList);//集装箱检疫
		
		//卫生检疫
		List<InsCheckItemEntity> insCheckItemHealthList=new ArrayList<InsCheckItemEntity>();
		ArrayList<InsCheckItemModel> insCheckItemHealthModelList=new ArrayList<InsCheckItemModel>();
		insCheckItemHealthList = itemCacheMap.get(InsContext.HEAL_ITEM_CODE);
		if(Utils.notEmpty(insCheckItemHealthList)){
			insCheckItemHealthModelList.ensureCapacity(insCheckItemHealthList.size());
			for(InsCheckItemEntity entity:insCheckItemHealthList){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemHealthModelList.add(model);
			}
		}
	//	list.add(insCheckItemHealthModelList);
		bigDataModel.setInsCheckItemHealths(insCheckItemHealthModelList);//卫生检疫
		
		//检验检疫
		List<InsCheckItemEntity> insCheckItemCheckGoodsList=new ArrayList<InsCheckItemEntity>();
		ArrayList<InsCheckItemModel> insCheckItemCheckGoodsModelList=new ArrayList<InsCheckItemModel>();
		insCheckItemCheckGoodsList = itemCacheMap.get(InsContext.CHECK_ITEM_CODE);
		if(Utils.notEmpty(insCheckItemCheckGoodsList)){
			insCheckItemCheckGoodsModelList.ensureCapacity(insCheckItemCheckGoodsList.size());
			for(InsCheckItemEntity entity:insCheckItemCheckGoodsList){
				InsCheckItemModel model=new InsCheckItemModel();
				model.setCheckItemCode(entity.getCheckItemCode());//查验项目编码
				model.setCheckItemName(entity.getCheckItemName());//查验项目名称
				model.setGoodsNo(entity.getGoodsNo() instanceof Object ? (entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")):"");
				model.setCheckCont(entity.getCheckCont());//查验内容
				model.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
				model.setWhetherQualfyCode(entity.getWhetherQualfy());//是否合格代码
				model.setBatchDesc(entity.getBatchDesc());//查验情况描述
				model.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
				model.setSampleSchCode(entity.getSampleSch());//抽样方案类别代码
				model.setFormName("");//表单名称
				model.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
				model.setNodeCode(entity.getNodeCode());
				model.setParentItemCode(entity.getParentItemCode());
				insCheckItemCheckGoodsModelList.add(model);
			}
		}
		//list.add(insCheckItemCheckGoodsModelList);
		bigDataModel.setInsCheckItemCheckGoods(insCheckItemCheckGoodsModelList);//检验检疫
		
//		list.add(modelList);
//		base.setData(list);
		
		base.setData(bigDataModel);
		return base;
	}


	/**
	 * 拼接查验项目数据
	 * @param insCheckItemList
	 * @return
	 */
	private Map<String, List<InsCheckItemEntity>> buildInsCheckItemData(List<InsCheckItemEntity> insCheckItemList) {
        Map<String, List<InsCheckItemEntity>> itemCacheMap = new HashMap<String, List<InsCheckItemEntity>>();;
        List<InsCheckItemEntity> checkItemList = null;
        List<InsCheckItemEntity> woodItemList = null;
        List<InsCheckItemEntity> contItemList = null;
        List<InsCheckItemEntity> healItemList = null;
        //货物检疫
        List<InsCheckItemEntity> checkItemList_1 ;
        //货物检验
        List<InsCheckItemEntity> checkItemList_2 ;
        //货物鉴定
        List<InsCheckItemEntity> checkItemList_3 ;
        if (Utils.notEmpty(insCheckItemList)) {
            checkItemList = new ArrayList<InsCheckItemEntity>();
            checkItemList_1 = new ArrayList<InsCheckItemEntity>();
            checkItemList_2 = new ArrayList<InsCheckItemEntity>();
            checkItemList_3 = new ArrayList<InsCheckItemEntity>();
            woodItemList = new ArrayList<InsCheckItemEntity>();
            contItemList = new ArrayList<InsCheckItemEntity>();
            healItemList = new ArrayList<InsCheckItemEntity>();
            List<InsCheckItemEntity> portCheckItemList = new ArrayList<InsCheckItemEntity>();
            for (InsCheckItemEntity InsCheckItemEntity : insCheckItemList) {
                InsCheckItemEntity.setNodeCode(lowerCase(InsCheckItemEntity.getNodeCode()));
                InsCheckItemEntity.setParentItemCode(lowerCase(InsCheckItemEntity.getParentItemCode()));
                //查验项目
                if (StringUtils.equals(InsContext.WOOD_ITEM_CODE, InsCheckItemEntity.getItemTypeCode())) {//木质包装
                    woodItemList.add(InsCheckItemEntity);
                    portCheckItemList.add(InsCheckItemEntity);
                } else if (StringUtils.equals(InsContext.CONT_ITEM_CODE, InsCheckItemEntity.getItemTypeCode())) {//集装箱
                    contItemList.add(InsCheckItemEntity);
                } else if (StringUtils.equals(InsContext.HEAL_ITEM_CODE, InsCheckItemEntity.getItemTypeCode())) {//卫生检疫
                    healItemList.add(InsCheckItemEntity);
                } else if(StringUtils.equals(InsContext.CHECK_ITEM_CODE, InsCheckItemEntity.getItemTypeCode())){
                    //区分口岸查验和检验检疫查验项目
                    if (StringUtils.equals(InsContext.QUAR_ITEM_CODE, InsCheckItemEntity.getCheckGoodsType())) {
                        checkItemList_1.add(InsCheckItemEntity);
                        portCheckItemList.add(InsCheckItemEntity);
                    } else if (StringUtils.equals(InsContext.INSP_ITEM_CODE, InsCheckItemEntity.getCheckGoodsType())) {
                        checkItemList_2.add(InsCheckItemEntity);
                        portCheckItemList.add(InsCheckItemEntity);
                    } else if (StringUtils.equals(InsContext.AUTH_ITEM_CODE, InsCheckItemEntity.getCheckGoodsType())) {
                        checkItemList_3.add(InsCheckItemEntity);
                        portCheckItemList.add(InsCheckItemEntity);
                    } else {
                        checkItemList.add(InsCheckItemEntity);
                    }
                }
            }

            itemCacheMap.put(InsContext.CHECK_ITEM_CODE, checkItemList);
            //货物检疫
            itemCacheMap.put(InsContext.INS_SCENE_GOODS_ITEM_TYPE_1, checkItemList_1);
            //货物检验
            itemCacheMap.put(InsContext.INS_SCENE_GOODS_ITEM_TYPE_2, checkItemList_2);
            //货物鉴定
            itemCacheMap.put(InsContext.INS_SCENE_GOODS_ITEM_TYPE_3, checkItemList_3);
            itemCacheMap.put(InsContext.WOOD_ITEM_CODE, woodItemList);
            itemCacheMap.put(InsContext.CONT_ITEM_CODE, contItemList);
            itemCacheMap.put(InsContext.HEAL_ITEM_CODE, healItemList);
//            portCheckItemList = portCheckItemList.addAll(woodItemList);
            //口岸查验项目
            itemCacheMap.put(InsContext.PORT_INS_SCENE_ITEM, portCheckItemList);
        }
        return itemCacheMap;
	}
	
    private  String lowerCase(String str){
        StringBuilder strBuilder = new StringBuilder();
        if(StringUtils.isNotEmpty(str)){
            for(int i = 0; i < str.length();i++){
                strBuilder.append(Character.toLowerCase(str.charAt(i)));
            }
        }
        return strBuilder.toString();
    }
	
    /**
     * 拼装查验项目树
     * @param insCheckItemPortModelList
     * @return
     */
    private List<InsCheckItemModel> buildJsonInsCheckItemTree(List<InsCheckItemModel> insCheckItems){
    	List<InsCheckItemModel> itemModelList = new ArrayList<InsCheckItemModel>();
    	InsCheckItemModel itemModel =null;
    	for(InsCheckItemModel entity:insCheckItems){
    		String parentCode=entity.getParentItemCode();
    		String code=entity.getNodeCode();
    		if("root".equals(parentCode)){
    			List<InsCheckItemModel> assItemModel=assItemModel(insCheckItems,code);
    			if(null!=assItemModel){ //有子节点
    				itemModel=new InsCheckItemSubTreeModel();
    				itemModel.setCheckItemName(entity.getCheckItemName());//查验项目名称
    				itemModel.setGoodsNo(entity.getGoodsNo());
    				itemModel.setCheckCont(entity.getCheckCont());//查验内容
    				itemModel.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
    				itemModel.setBatchDesc(entity.getBatchDesc());//查验情况描述
    				itemModel.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
    				itemModel.setFormName("");//表单名称
    				itemModel.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
    				itemModel.setNodeCode(entity.getNodeCode());
    				itemModel.setParentItemCode(entity.getParentItemCode());
    				((InsCheckItemSubTreeModel)itemModel).setSub(assItemModel);
    			}else{//无子节点
    				itemModel=new InsCheckItemModel();
    				itemModel=entity;
    			}
    			
    			itemModelList.add(itemModel);
    			break;
    		}
    		
    	}
    	return itemModelList;
    }


    /**
     * 遍历子节点
     * @param insCheckItemPortModels
     * @param code 下一个节点
     * @return
     */
	private List<InsCheckItemModel> assItemModel(List<InsCheckItemModel> insCheckItems,String code) {
		List<InsCheckItemModel> insCheckItemModelList=new ArrayList<InsCheckItemModel>();
		InsCheckItemModel insCheckItemModel=null;
		for(InsCheckItemModel entity:insCheckItems){
			String parentCode=entity.getParentItemCode();
			String subCode=entity.getNodeCode();
			if(StringUtils.equals(code, parentCode)){
				
				
				List<InsCheckItemModel> assItemModel=assItemModel(insCheckItems, subCode);
				if(Utils.notEmpty(assItemModel)){
					insCheckItemModel=new InsCheckItemSubTreeModel();
					insCheckItemModel.setCheckItemName(entity.getCheckItemName());//查验项目名称
					insCheckItemModel.setGoodsNo(entity.getGoodsNo());
					insCheckItemModel.setCheckCont(entity.getCheckCont());//查验内容
					insCheckItemModel.setWhetherQualfy(CommonCodeToNameUtils.insSceneItemCodeToName(entity.getWhetherQualfy()));//是否合格
					insCheckItemModel.setBatchDesc(entity.getBatchDesc());//查验情况描述
					insCheckItemModel.setSampleSch(CommonCodeToNameUtils.samplePlanCodeToName(entity.getSampleSch()));//抽样方案类别
					insCheckItemModel.setFormName("");//表单名称
					insCheckItemModel.setAddInputFlag(CommonCodeToNameUtils.commonCodeToName(entity.getAddInputFlag()));//是否补录
					insCheckItemModel.setNodeCode(entity.getNodeCode());
					insCheckItemModel.setParentItemCode(entity.getParentItemCode());
					((InsCheckItemSubTreeModel)insCheckItemModel).setSub(assItemModel);
				}else{
					insCheckItemModel=new InsCheckItemModel();
					insCheckItemModel=entity;
				}
				insCheckItemModelList.add(insCheckItemModel);
			}
			
		}
		return insCheckItemModelList;
	}

	
	/**
	 * 现场记录查看
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/recordCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel recordCheck(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String expImpFlag=request.getParameter("expImpFlag");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(expImpFlag)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return base;
		}
		
		String receiverDocCode = request.getParameter("receiverDocCode");
		String flowPathStatus = request.getParameter("flowPathStatus");
		//审单进入现场查验
		if(StringUtils.isNotEmpty(receiverDocCode) && StringUtils.isNotEmpty(flowPathStatus)) {
			service.examingToScene(declNo, receiverDocCode, flowPathStatus);
		}
		
		List<InsResultSumEntity> insResultSumList=service.getInsResultSumList(declNo,expImpFlag);
		ArrayList<InsResultSumModel> insResultSumModelList=new ArrayList<InsResultSumModel>();
		if(Utils.notEmpty(insResultSumList)){
			insResultSumModelList.ensureCapacity(insResultSumList.size());
			for(InsResultSumEntity entity:insResultSumList){
				InsResultSumModel model=new InsResultSumModel();
				String checker = entity.getChecker();
				model.setChecker(checker);//查验人员
				model.setCheckerName(getCheckUserName(checker));//查验人员名称
				Timestamp insBeginDate = entity.getInsBeginDate();
				if(null != insBeginDate) {
					model.setInsBeginDate(DateUtil.format(entity.getInsBeginDate(), "yyyy-MM-dd"));//查验日期
				}
				Timestamp inspEndDate = entity.getInspEndDate();
				if(null != inspEndDate) {
					model.setInspEndDate(DateUtil.format(entity.getInspEndDate(), "yyyy-MM-dd"));//检毕日期
				}
				model.setCheckPlace(entity.getCheckPlace());//查验地点
				String inspBasCatCode = entity.getInspBasCatCode();
				model.setInspBasCatCode(inspBasCatCode);//检验依据代码
				model.setInspBasCatName(getInspBasCatName(inspBasCatCode));//检验依据
				model.setWhether2ndIns(entity.getWhether2ndIns());//二次查验
				model.setKepIsolat(entity.getKepIsolat());//隔离检疫
				String weatherCode = entity.getWeatherCode();
				model.setWeatherCode(null == weatherCode?"":weatherCode);//天气代码
				if(StringUtils.isNotEmpty(weatherCode)) {
					model.setWeatherName(codeToNameUtils.getWeatherNameByCode(weatherCode,"WeatherCircs"));//天气名称
				} else {
					model.setWeatherName("");
				}
				String goodsEvalResult = entity.getGoodsEvalResult();
				model.setGoodsEvalResult(goodsEvalResult);//货物评定
				model.setGoodsEvalResultName(CommonCodeToNameUtils.goodsEvalResultCodeToName(goodsEvalResult));//货物评定名称
				String spotDesc = entity.getSpotDesc();
				if(StringUtils.isEmpty(spotDesc)) {
					spotDesc = "";
				}
				model.setSpotDesc(spotDesc);//情况描述
				//20170512补充
				model.setContQuarResult(entity.getContQuarResult());//集装箱检疫结果代码
				model.setContQuarResultName(CommonCodeToNameUtils.inspquarCodeToName(entity.getContQuarResult()));//集装箱检疫结果名称
				model.setWoodpackQuarResult(entity.getWoodpackQuarResult());//木质包装检疫结果代码
				model.setWoodpackQuarResultName(CommonCodeToNameUtils.inspquarCodeToName(entity.getWoodpackQuarResult()));//木质包装检疫结果名称
				//初始化设置集装箱检疫结果是否可编辑
				boolean contQuarResultEditFlag=service.getDclIoDeclGoodsContEntitys(declNo);
				model.setContQuarResultEditFlag(contQuarResultEditFlag);//集装箱检疫结果是否可编辑
				insResultSumModelList.add(model);
			}
		}
		base.setData(insResultSumModelList);
		return base;
		
	}
	
	/**
	 * 获取检验依据名称
	 * 
	 * @param inspBasCatCode 检验依据代码
	 * @return 检验依据名称
	 */
	private String getInspBasCatName(String inspBasCatCode) {
		String name = "";
		if(StringUtils.isNotEmpty(inspBasCatCode) && inspBasCatCode.contains(",")) {
			String[] codes = inspBasCatCode.split(",");
			boolean flag = false;
			for (int i=0;i<codes.length;i++) {
				String tmp = codeToNameUtils.getInspBasCatNameByCode(codes[i],"InsQuaAttestatType");
				if(StringUtils.isNotEmpty(name) && flag) {
					name += "," + tmp;
				} else {
					name = tmp;
					flag = true;
				}
			}
		} else {
			name = codeToNameUtils.getInspBasCatNameByCode(inspBasCatCode,"InsQuaAttestatType");
		}
		return name;
	}
	
	/**
	 * 获取查验人员名称
	 * 
	 * @param checker 查验人员代码
	 * @return 查验人员名称
	 */
	private String getCheckUserName(String checker) {
		String name = "";
		if(StringUtils.isNotEmpty(checker) && checker.contains(",")) {
			String[] codes = checker.split(",");
			boolean flag = false;
			for (int i=0;i<codes.length;i++) {
				String tmp = codeToNameUtils.getUserNameByCode(codes[i]);
				if(StringUtils.isNotEmpty(name) && flag) {
					name += "," + tmp;
				} else {
					name = tmp;
					flag = true;
				}
			}
		} else {
			name = codeToNameUtils.getUserNameByCode(checker);
		}
		return name;
	}
    
	/**
	 * 无纸化信息查看
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="paperLess",method=RequestMethod.GET)
	@ResponseBody 
	public DataModel paperLess(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String orgCode=request.getParameter("orgCode");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(orgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
//      暂
//		String org=companyCodeUtils.getBusinessOrgCode(orgCode, false);
//		String str=insResultSumHandel.getSendInsResultSum(request,response,declNo, "800", "1100000036", orgCode, org);
//		logger.info("insResultSumHandel: "+str);
//		
//		String mString=insResultEvalHandel.getSendInsResultEval(request, response, null,org);
//		logger.info("****************************insResultEvalHandel:"+mString);
//		dclOrdFeedBackMainHandel.getSendDclOrdFeedBackMain(request,response,"650c3c28c8ef4336b639e74f3c012014", org);
		Map<String,String> map=new HashMap<String, String>();
		String entDeclNo="";
		//部门代码转机构
		orgCode=companyCodeUtils.getBusinessOrgCode(orgCode, false);
		String paperLessUrl=service.getPaperLessUrl(orgCode,DeclContext.PAPERLESS_URL_PARAM);
		if(StringUtils.isEmpty(paperLessUrl)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(DeclContext.INFO_SET_PAPERLESS_PARAM);
			return base;
		}
		
		map=service.getDeclInfo(declNo);
		if(null==map){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("未找到相关信息");
			return base;
		}
		map.put("decl_no", declNo);

        //判断declNo为正式号
        if (DeclNoUtils.checkOfficialDeclNo(declNo)) {
            if (!StringUtils.isEmpty(map.get("decl_get_no")) 
			        && DeclNoUtils.checkDeclNoE(map.get("decl_get_no"))) {
			    entDeclNo = declNo;
			} else {
			    entDeclNo = "";
			}
        } else if (DeclNoUtils.checkDeclNoE(declNo)) {
            entDeclNo = declNo;
        } else if (DeclNoUtils.checkDeclNoT(declNo)) {
            //获取转出局报检号
            String officialDeclNo = service.getOutDeclNoByTranNo(declNo);
            //获取预报检号
            String declGetNo = service.getDeclGetNoByDeclNo(officialDeclNo);
            if (!StringUtils.isEmpty(declGetNo)) {
                if (DeclNoUtils.checkDeclNoE(declGetNo)) {
                    entDeclNo = officialDeclNo;
                } else {
                    entDeclNo = "";
                }
            } else {
                entDeclNo = "";
            }
        }
        
        //企业报检号为空时返回结果
        if (StringUtils.isEmpty(entDeclNo)) {
        	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            base.setMsg(DeclContext.INFO_NO_PAPERLESS);
            return base;
        }else {
        	PaperLessModel model=new PaperLessModel();
        	model.setPaperLessUrl(paperLessUrl);
        	model.setEntDeclNo(entDeclNo);
        	model.setMap(map);
        	model.setOrgCode(orgCode);
        	model.setTitle("无纸化信息查看");
        	base.setData(model);
		}
		return base;
	}
	
	/**
	 * 无纸化信息查看
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="checkPaperLess",method=RequestMethod.GET)
	@ResponseBody 
	public DataModel checkPaperLess(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String orgCode=request.getParameter("orgCode");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(orgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//获取无纸化地址
		base = service.getFullPaperLessUrl(base, declNo, orgCode,DeclContext.PAPERLESS_URL_PARAM);
		return base;
	}
	
	/**
	 * 现场记录保存
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/recordCheckCommit",method=RequestMethod.POST)
	@ResponseBody
	public DataModel recordCheckCommit(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String expImpFlag=request.getParameter("expImpFlag");
		String receiverDocCode = request.getParameter("receiverDocCode");
		String flowPathStatus = request.getParameter("flowPathStatus");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(receiverDocCode)||StringUtils.isEmpty(flowPathStatus)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return base;
		}
		String checker=request.getParameter("checker");//查验人员
		String insBeginDate=request.getParameter("insBeginDate");//查验日期
		String inspEndDate=request.getParameter("inspEndDate");//检毕日期
		String checkPlace=Utils.getParameter(request, "checkPlace");//查验地点
		String inspBasCatCode=request.getParameter("inspBasCatCode");//检验依据
		String whether2ndIns=request.getParameter("whether2ndIns");//二次查验
		String kepIsolat=request.getParameter("kepIsolat");//隔离检疫
		String weatherCode=request.getParameter("weatherCode");//天气
		String goodsEvalResult=request.getParameter("goodsEvalResult");//货物评定
		String spotDesc=Utils.getParameter(request, "spotDesc");//现场情况描述
		String woodpackQuarResult = request.getParameter("woodpackQuarResult");//木质包装结果
		String contQuarResult = request.getParameter("contQuarResult");//集装箱检疫结果
		if(StringUtils.isEmpty(checker)||StringUtils.isEmpty(checkPlace)
				||StringUtils.isEmpty(kepIsolat)||StringUtils.isEmpty(goodsEvalResult)
				||StringUtils.isEmpty(inspBasCatCode)
				||StringUtils.isEmpty(insBeginDate)||StringUtils.isEmpty(inspEndDate)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return base;
		}
		
		List<InsResultSumEntity> insResultSumList=service.getInsResultSumList(declNo,expImpFlag);
		if(Utils.notEmpty(insResultSumList)&&insResultSumList.size()==1){
			InsResultSumEntity entity=insResultSumList.get(0);
			DateFormat format=new SimpleDateFormat("yyyy-MM-dd");
			format.setLenient(false);
			entity.setChecker(checker);
			try {
				entity.setInsBeginDate(new Timestamp(format.parse(insBeginDate).getTime()));
				entity.setInspEndDate(new Timestamp(format.parse(inspEndDate).getTime()));
				entity.setOperTime(new Timestamp(new Date().getTime()));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			entity.setCheckPlace(checkPlace);
			entity.setInspBasCatCode(inspBasCatCode);
			entity.setWhether2ndIns(whether2ndIns);
			entity.setKepIsolat(kepIsolat);
			entity.setWeatherCode(weatherCode);
			entity.setGoodsEvalResult(goodsEvalResult);
			entity.setSpotDesc(spotDesc);
			entity.setContQuarResult(contQuarResult);
			if(woodpackQuarResult!=null&&!StringUtils.equals(woodpackQuarResult, "null")){
				entity.setWoodpackQuarResult(woodpackQuarResult);
			}
			String msg=service.saveRecordCheck(entity);
			
			
			
			SysUser sysUser = subOrReasService.getSysUser(receiverDocCode);
			String userName="";
			String orgCode="";
			if (sysUser != null) {
				userName=sysUser.getUserName();
				orgCode=sysUser.getOrgCode();
			}
			
		
			
			// 如果为主施检
			//if (StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_MAIN)) {
				//移动端查验流程日志
			//获取当前流程状态：
//				DclIoDeclEntity dclEntity=commitService.queryDclIoDeclByDeclNo(declNo);
				String processStatus=MobileCommContext.WAIT_INS_RESULT;
				String processNode=MobileCommContext.RESULT;
				SysAppProcessLog log = service.getSysAppProcessLog(declNo);
				//标示是否是新创建的流程记录
				boolean flag=false;
				//如果为空则，创建一条新的流程记录，否则，对原来的记录更新
				if(log==null){
					log=new SysAppProcessLog();
					log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
					flag=true;
				}else {
					String node=log.getProcessNode();
					String status=log.getProcessStatus();
					if (processNode.equals(node)&&processStatus.equals(status)) {
						flag=false;
					}else {
						log=new SysAppProcessLog();
						log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
						flag=true;
					}
				}
				if (sysUser != null) {
					log.setOperCode(receiverDocCode);
					log.setOperName(sysUser.getUserName());
					log.setTreaOrgCode(sysUser.getOrgCode());
				}
				log.setDeclNo(declNo);
				log.setProcessNode(MobileCommContext.RESULT);
				log.setNodeMemo(MobileCommContext.RESULT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_INS_RESULT);
				log.setStatusMemo(MobileCommContext.WAIT_INS_RESULT_NAME);
				log.setRemark("保存现场记录");
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(new Date());
				Date newDate;
				try {
					newDate = formatter.parse(dateString);
					log.setOperDate(newDate);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				if(flag){
					processService.savelog(log);
				}else{
					processService.updateLog(log);
				}
				statusControlUtils.updateProcess(declNo, MobileCommContext.RESULT, MobileCommContext.WAIT_INS_RESULT, receiverDocCode);
				
			//}else if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_AUXILIARY)){
			//	statusControlUtils.writeAuxLog("", "", "", "", declNo, MobileCommContext.RESULT, MobileCommContext.WAIT_INS_RESULT, "保存现场记录", receiverDocCode, userName, orgCode);
			//}
			
			
			if(StringUtils.isNotEmpty(msg)){
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
			}else{
				//进入结果登记
				service.enterResultRegister(request, response, declNo, receiverDocCode, flowPathStatus);
				base.setMsg(MobileHelper.OPERATION_SUCCESS_FLAG_TIP);
				base.setData("1");
			}
		}else{
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
			return base;
		}
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:判断是否可以进行二次检验勾选</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/whether2ndInsCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel whether2ndInsCheck(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		if(StringUtils.isEmpty(declNo)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		boolean judgeIsSecondUse=service.judgeIsSecondUse(declNo);
		ShowMessageModel model=new ShowMessageModel();
		if(!judgeIsSecondUse){
			model.setMessage("该报检单不符合二次检验条件");
			model.setDeclNo(declNo);
			model.setFlag("0");
		}else {
			model.setMessage("该报检单符合二次检验条件");
			model.setDeclNo(declNo);
			model.setFlag("1");
		}
		base.setData(model);
		return base;
	}
	
	/**
	* <p>描述:数据回写</p>
	* @param request
	* @param response
	* @return 回写结果
	* @author 才江男
	 */
	@RequestMapping(value="/submit",method=RequestMethod.POST)
	@ResponseBody
	public DataModel dataWriteBack(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		//现场查验
		String declNo=request.getParameter("declNo");
		String flowPathStatus = request.getParameter("flowPathStatus");
		String userCode = request.getParameter("userCode");
		String orgCode = request.getParameter("orgCode");
		if(StringUtils.isEmpty(declNo) || StringUtils.isEmpty(flowPathStatus) || StringUtils.isEmpty(userCode) || StringUtils.isEmpty(orgCode)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		
		//回写，并返回结果
		String msg = service.sendBackData(request,response,declNo, flowPathStatus, userCode, orgCode);
		
        base.setData(msg);
		return base;
	}
	

	@RequestMapping(value="/load/up/{reqWith}/{userCode}/{hexCode}/{declNo}",method=RequestMethod.POST)
	@ResponseBody
	public DataModel upload(HttpServletRequest request,HttpServletResponse response, @PathVariable("reqWith") String reqWith, @PathVariable("userCode") String userCode, @PathVariable("hexCode") String hexCode,@PathVariable("declNo") String declNo){
		DataModel base=MobileHelper.getBaseModel();
		BaseModel bm = new BaseModel();
		base.setData(bm);
		bm.setFlag(true);
		if(!"e-CIQ".equals(reqWith) || Utils.isEmpty(userCode) || Utils.isEmpty(hexCode) || !hexCode.equals(MobileHelper.getMD5(userCode)) || Utils.isEmpty(declNo)){
			bm.setFlag(false);
			bm.setMsg("请求异常");
			base.setCode(500);
			return base;
		}
		
		MultipartHttpServletRequest mRequest=(MultipartHttpServletRequest)request;
        Iterator<String> fns=mRequest.getFileNames();//获取上传的文件列表
        while(fns.hasNext()){
            String s = fns.next();
            MultipartFile mFile = mRequest.getFile(s);  
            if(mFile.isEmpty()){
            	bm.setMsg("上传文件为空");
            	bm.setFlag(false);
            }else{
                String basePath= request.getSession().getServletContext().getRealPath("/upload");
                DateFormat format=new SimpleDateFormat("yyyyMMdd");
                Date date = new Date();
                String dateString = format.format(date);
                String dPath= "/" + declNo + "/" + userCode + "/" + dateString;//日期
                String originFileName=mFile.getOriginalFilename();
                String suffix=originFileName.split("\\.")[originFileName.split("\\.").length-1];
                String path = basePath+dPath+"/"+suffix;
                File dir = new File(path);
                if(!dir.exists()){
                	dir.mkdirs();
                }
                File file =  new File(path, originFileName);
                try {
                    FileUtils.copyInputStreamToFile(mFile.getInputStream(),file);//存储文件
                } catch (IOException e) {
                	bm.setMsg("保存文件出错");
                	bm.setFlag(false);
                }  
                
                InsDeclLobEntity entity = new InsDeclLobEntity();
                entity.setDeclLobId(UUIDKeyGeneratorUils.newInstance().generateKey());
                entity.setDeclNo(declNo);
                entity.setOperCode(userCode);
                entity.setOperTime(new Date());
                entity.setPath(dPath +"/"+ suffix + "/" + originFileName);
                //保存附件
                service.saveFile(entity);
            }
        }
        
		return base;
	}
	
	@RequestMapping(value="/load/down",method=RequestMethod.GET)
	@ResponseBody
	public DataModel downLoad(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String reqWith=request.getParameter("reqWith");
		String userCode=request.getParameter("loginUser");
		String hexCode=request.getParameter("hexCode");
		String orgCode=request.getParameter("orgCode");
		String flag = request.getParameter("flag");

		BaseModel bm = new BaseModel();
		base.setData(bm);
		bm.setFlag(true);
		if(!"e-CIQ".equals(reqWith) || Utils.isEmpty(userCode) || Utils.isEmpty(hexCode) || !hexCode.equals(MobileHelper.getMD5(userCode)) || Utils.isEmpty(declNo) || Utils.isEmpty(orgCode)){
			bm.setFlag(false);
			bm.setMsg("请求异常");
			base.setCode(500);
			return base;
		}
		orgCode = orgCode.substring(0,2) + "0000";
		
		String basePath=service.getPaperLessUrl(orgCode, MobileCommContext.ATTACH_ADDR);
		if(StringUtils.isEmpty(basePath)) {
			bm.setFlag(false);
			bm.setMsg("请联系管理员，维护文件服务器地址");
			base.setData(bm);
			return base;
		}
		
		List<FileVo> file = service.loadFile(basePath, declNo, userCode, flag);
//		List<FileVo> file = service.loadFile(declNo);
		if(CollectionUtils.isEmpty(file)){
			bm.setFlag(true);
//			bm.setMsg("无附件");
			base.setData(bm);
		} else {
			FileModel fm = new FileModel();
			fm.setFiles(file);
			fm.setFlag(true);
			base.setData(fm);
		}
		
		return base;
	}
	
	/**
	 * 删除附件
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/delFile",method=RequestMethod.POST)
	@ResponseBody
	public DataModel delFile(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getPOSTModel();
		String delPath=request.getParameter("path");
		String orgCode = request.getParameter("orgCode");
		if(StringUtils.isEmpty(delPath)){
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		//删除文件
		if(StringUtils.isNotEmpty(delPath)) {
//			String rootPath = request.getSession().getServletContext()
//					.getRealPath("/");
//			int lastIndex = delPath.lastIndexOf("/");
//			String filePath = delPath.substring(0, lastIndex);
//			String fileName = delPath.substring(lastIndex + 1);
//			try {
//				File file = new File(rootPath + filePath, fileName);
			orgCode = orgCode.substring(0,2) + "0000";
			
			String basePath=service.getPaperLessUrl(orgCode, MobileCommContext.ATTACH_ADDR);
			String fileId = delPath.replaceFirst(basePath + "/", "");
			service.delFile(fileId);
			FileManager fm = FileManagerHolder.getFileManager();
			try {
				fm.deleteFile(fileId);
			} catch (Exception e) {
				e.printStackTrace();
			}
//				file.delete();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
		}
		return base;
	}
	
	/**
	* <p>描述: 结束查验</p>
	* @param request
	* @param response
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/endScene",method=RequestMethod.POST)
	@ResponseBody
	public DataModel endScene(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getPOSTModel();
		String flowPathStatus=request.getParameter("flowPathStatus");//施检机构
		String receiverDocCode=request.getParameter("userCode");//接单员代码
		String declNo=request.getParameter("declNo");//报检号
		if(StringUtils.isEmpty(flowPathStatus)||StringUtils.isEmpty(receiverDocCode)||StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//结束查验
		service.endScene(declNo, receiverDocCode, flowPathStatus);
		
		return base;
	}
	
	
	
	/**
	 * 
	* <p>描述:报检单号短号变长号</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/changeDeclNoToLong",method=RequestMethod.GET)
	@ResponseBody
	public DataModel changeDeclNoToLong(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		String expImpFlag = request.getParameter("expImpFlag");
		//当前登录用户
		String userCode=request.getParameter("receiverDocCode");
//		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userCode)){
//			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
//			return base;
//		}
		
        UserInfo user=new UserInfo();
        user.setUserCode(userCode);
        SysUser sysUser=subOrReasDao.getSysUser(userCode);
        if(sysUser!=null){
        	user.setCompanyCode(sysUser.getOrgCode());
        	user.setUserName(sysUser.getUserName());
        }
        String longDeclNo="";
        if(expImpFlag.equals("1")){
            longDeclNo=DeclNoUtils.chageDeclNoToLangNo(declNo, DeclContext.DECL_TYPE_IN, user);
        }else if(expImpFlag.equals("2")){
        	longDeclNo=DeclNoUtils.chageDeclNoToLangNo(declNo, DeclContext.DECL_TYPE_OUT, user);
        }
		base.setData(longDeclNo);
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:判读货物评定是否可勾选合格</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/goodsEvalResultCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel goodsEvalResultCheck(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//查询所有的货物检验结果
		boolean goodsEvtFlag=false;
		List<InsResultGoodsEntity> insResultGoods=service.getInsResultGoodsList(declNo,"");
		if(Utils.notEmpty(insResultGoods)){
			for(InsResultGoodsEntity insResultGoodsVO:insResultGoods){
                if (!((StringUtils.equals(DeclevalConstants.INSP_QUAR_RESULT_PASS, insResultGoodsVO.getQuarResSpot())
                        || StringUtils.equals(DeclevalConstants.INSP_QUAR_RESULT_REDO_PASS, insResultGoodsVO.getQuarResSpot()))
                        && (StringUtils.equals(DeclevalConstants.INSP_QUAR_RESULT_PASS, insResultGoodsVO.getInspResSpot())
                        || StringUtils.equals(DeclevalConstants.INSP_QUAR_RESULT_REDONE_PASS, insResultGoodsVO.getInspResSpot())))) {
                    goodsEvtFlag = true;
                    break;
                }
			}
			ShowMessageModel model=new ShowMessageModel();
            if (goodsEvtFlag) {
            	model.setDeclNo(declNo);
            	model.setFlag("0");
            	model.setMessage("检验合格或返工整改合格与检疫合格或检疫处理合格,货物评定才能选择合格!");
            }
            base.setData(model);
		}
		return base;
	}
	
	
	
	/**
	 * 
	* <p>描述:集装箱检疫结果-检疫不合格监听判断&数据库查询</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	* @throws Exception 
	 */
	@RequestMapping(value="/contQuarResultCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel contQuarResultCheck(HttpServletRequest request, HttpServletResponse response) throws Exception {
		DataModel base = MobileHelper.getBaseModel();
		String declNo = request.getParameter("declNo");//报检单号
		String expImpFlag=request.getParameter("expImpFlag");//出入境标记
		String contResultId=request.getParameter("contResultId");//集装箱ID
		String selectedStatus=request.getParameter("selectedStatus");//集装箱检疫结果当前选择状态
		if (StringUtils.isEmpty(declNo)||StringUtils.isEmpty(expImpFlag)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		// 根据集装箱项目合格与否，判断集装箱检疫结果是否可以选择检疫不合格
		String contItemWhetherQualfy = InsContext.INS_Y;
		List<InsCheckItemEntity> insCheckItemList = service.getInsCheckItemList(declNo, "","");
		Map<String, List<InsCheckItemEntity>> itemCacheMap = null;
		itemCacheMap = buildInsCheckItemData(insCheckItemList);
		List<InsCheckItemEntity> contItemList = itemCacheMap.get(InsContext.CONT_ITEM_CODE);
		ShowMessageModel msgModel = (ShowMessageModel) Class.forName("com.rongji.eciq.mobile.model.insp.scene.ShowMessageModel").newInstance();
		if (Utils.notEmpty(contItemList)) {
			for (InsCheckItemEntity entity : contItemList) {
				if (StringUtils.equals(entity.getWhetherQualfy(), InsContext.INS_N)) {
					contItemWhetherQualfy = InsContext.INS_N;
				}
			}

			// 集装箱都为合格
			if (StringUtils.equals(contItemWhetherQualfy, InsContext.INS_Y)
					&& DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL.equals(selectedStatus)) {
				msgModel.setDeclNo(declNo);
				msgModel.setMessage("集装箱检疫结果要与集装箱项目结果一致");
				msgModel.setFlag(DeclevalConstants.INSP_QUAR_RESULT_PASS);
				base.setData(msgModel);
				return base;
			} else if (StringUtils.equals(contItemWhetherQualfy, InsContext.INS_N)
					&& (DeclevalConstants.INSP_QUAR_RESULT_PASS.equals(selectedStatus)
							|| DeclevalConstants.INSP_QUAR_RESULT_REDO_PASS.equals(selectedStatus))) {// 集装箱有不合格的项目
				msgModel.setDeclNo(declNo);
				msgModel.setMessage("集装箱检疫结果要与集装箱项目结果一致");
				msgModel.setFlag(DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL);
				base.setData(msgModel);
				return base;
			} else if (selectedStatus == null) {
				msgModel.setDeclNo(declNo);
				msgModel.setMessage("集装箱检疫结果不能为空");
				if (StringUtils.equals(contItemWhetherQualfy, InsContext.INS_Y)) {
					msgModel.setFlag(DeclevalConstants.INSP_QUAR_RESULT_PASS);
				} else if (StringUtils.equals(contItemWhetherQualfy, InsContext.INS_N)) {
					msgModel.setFlag(DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL);
				}
				base.setData(msgModel);
				return base;
			}
		}

		ContBigDataModel bigDataModel=new ContBigDataModel();
		//当可以选择检疫不合格处理时，加载集装箱不合格登记初始化数据
		if (DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL.equals(selectedStatus)) {
			List<InsContainerResultEntity> insContainerResultList=service.findInsContainerResultListByDeclNo2(declNo);
			ArrayList<InsContainerResultModel> modelList=new ArrayList<InsContainerResultModel>();
			if(Utils.notEmpty(insContainerResultList)){
				modelList.ensureCapacity(insContainerResultList.size());
				for(InsContainerResultEntity entity:insContainerResultList){
					InsContainerResultModel model=new InsContainerResultModel();
					try {
						BeanPropertyUtils.getInstance().copyPropertiesBean(model, entity);
					} catch (Throwable e) {
						e.printStackTrace();
					}
					model.setCntnrModeCodeName(codeToNameUtils.getCntnrModeByCode("ContainerStandard",entity.getCntnrModeCode()));//集装箱规格名称
					modelList.add(model);
				}
				bigDataModel.setInsContainerResultModelList(modelList);
			}
			
			//若没有传集装箱检疫结果过来，默认取第一条记录
			if(StringUtils.isEmpty(contResultId)){
				contResultId=Utils.notEmpty(insContainerResultList)?insContainerResultList.get(0).getContResultId():"";
			}
			
			if(Utils.notEmpty(insContainerResultList)){
				for(InsContainerResultEntity entity:insContainerResultList){
					//根据选择的集装箱联动
					if(StringUtils.equals(contResultId, entity.getContResultId())){
						//集装箱基本情况信息
						InsContainerResultModelDetail detailModel=new InsContainerResultModelDetail();
						try {
							BeanPropertyUtils.getInstance().copyPropertiesBean(detailModel, entity);
							detailModel.setContOpetnTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(entity.getContOpetnTime()));//查验日期
							detailModel.setCntnrModeCodeName(codeToNameUtils.getCntnrModeByCode("ContainerStandard", entity.getCntnrModeCode()));//集装箱规格名称
							detailModel.setContCategoryName(codeToNameUtils.getZBbdEciqsimplelistEntity("ContainerType", entity.getContCategory(),null));//集装箱类别名称
							detailModel.setTradeCountryCodeName(codeToNameUtils.getTradeCountryNameByCode(entity.getTradeCountryCode()));//来源国家和地区名称
						} catch (Throwable e) {
							e.printStackTrace();
						}
						bigDataModel.setInsContainerResultModelDetail(detailModel);
						
						//集装箱检疫情况
						InsContainerResultModelCont contModel=new InsContainerResultModelCont();
						contModel.setCntnrUnqlResnC(entity.getCntnrUnqlResnC());//集装箱检疫不合格原因
						contModel.setCntnrUnqlResnCName(codeToNameUtils.getZBbdEciqsimplelistEntity("SuitableLoadProject", entity.getCntnrUnqlResnC(),"and (t.alias1 !='suitableLoadIns' or t.alias1 is null)"));//集装箱检疫不合格原因名称
						contModel.setEpidSituCatg(entity.getEpidSituCatg());//疫情种类
						contModel.setEpidSituCatgName(codeToNameUtils.getZCcmSimplelist10Entity("EpidemicSituatinoSor", entity.getEpidSituCatg()));//疫情种类名称
						contModel.setCntnrTreatCodes(entity.getCntnrTreatCodes());//检疫处理措施
						contModel.setCntnrTreatCodesName(codeToNameUtils.getZCcmSimplelist9Entity("ProductDwHandleMethd", entity.getCntnrTreatCodes()));//检疫处理措施名称
						contModel.setContQuarUnqualDesc(entity.getContQuarUnqualDesc());//不合格原因描述
						bigDataModel.setInsContainerResultModelCont(contModel);
						
						//卫生查验检疫情况
						InsContainerResultModelHealth healthModel=new InsContainerResultModelHealth();
						healthModel.setQuarUnqualReasonCode(entity.getQuarUnqualReasonCode());//卫生检疫查验不合格原因
						healthModel.setQuarUnqualReasonCodeName(codeToNameUtils.getZCcmSimplelist9Entity("QuarUnqualifiedReason", entity.getQuarUnqualReasonCode()));//卫生检疫查验不合格原因名称
						healthModel.setQuarUnqualContentCodes(entity.getQuarUnqualContentCodes());//卫生检疫查验不合格内容
						healthModel.setSanitTrtMethCodes(entity.getSanitTrtMethCodes());//卫生除害处理方法
						healthModel.setSanitTrtMethCodesName(codeToNameUtils.getZCcmSimplelist9Entity("ProductDwDetailMethd", entity.getSanitTrtMethCodes()));//卫生除害处理方法名称
						healthModel.setSntTrtOrgCode(entity.getSntTrtOrgCode());//卫生除害处理机构
						healthModel.setSntTrtOrgCodeName(codeToNameUtils.getOrgNameByCode(entity.getSntTrtOrgCode()));//卫生除害处理机构名称
						bigDataModel.setInsContainerResultModelHealth(healthModel);
						
						//动植物检疫情况
						InsContainerResultModelAnimal animalModel=new InsContainerResultModelAnimal();
						animalModel.setPamUnqualReasonCodes(entity.getPamUnqualReasonCodes());//动植物检疫不合格原因
						animalModel.setPamTrtMethCodes(entity.getPamTrtMethCodes());//处理方法
						animalModel.setPamTrtMethCodesName(codeToNameUtils.getZCcmSimplelist9Entity("ProductDwDetailMethd", entity.getPamTrtMethCodes()));//处理方法名称
						animalModel.setPamTrtOrgCode(entity.getPamTrtOrgCode());//除害处理机构
						animalModel.setPamTrtOrgCodeName(codeToNameUtils.getOrgNameByCode(entity.getPamTrtOrgCode()));//除害处理机构名称
						bigDataModel.setInsContainerResultModelAnimal(animalModel);
						break;
					}
				}
			}
		}

		base.setData(bigDataModel);
		return base;
	}
	
	 
	
	/**
	 * 
	* <p>描述:现场查验-现场记录展示施检工作内容类别代码串</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value = "/inspCountCodes", method = RequestMethod.GET)
	@ResponseBody
	public DataModel inspCountCodes(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		Map<String,Object> limtsMap=new HashMap<String, Object>();
		String declNo = request.getParameter("declNo");
		String userCode = request.getParameter("userCode");
		String orgCode = request.getParameter("orgCode");
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userCode)||StringUtils.isEmpty(orgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		 //主辅施捡流程状态
	    String flowPathStatusFlag = null;
		
		String inspCountCodes="";
		limtsMap=service.getLoginUserPermission(declNo,userCode,orgCode,SceneContext.PROCEDURE_CODE);
		
		if(Utils.notEmpty(limtsMap)){
			inspCountCodes=(String)limtsMap.get(SceneContext.INSP_COUNT_CODE);
		}
		DialogPromptMessageModel model=new DialogPromptMessageModel();
		model.setMessage(inspCountCodes);
		InsDeclMagEntity insDeclMag=(InsDeclMagEntity)limtsMap.get("insDeclMag");
		if(insDeclMag!=null){
			if(StringUtils.isNotEmpty(insDeclMag.getInspContCodes())){
				model.setInspCountNames(codeToNameUtils.insContCodesToName(insDeclMag.getInspContCodes()));
			}
		
		}
		
	
		base.setData(model);
		return base;
	}
	
	/**
	 * 
	* <p>描述:保存照片和视频</p>
	* @param request
	* @param response
	* @author 才江男
	 */
	@RequestMapping(value = "/load/savePhoto/{reqWith}/{userCode}/{declNo}/{orgCode}", method=RequestMethod.POST)
	@ResponseBody
	public DataModel savePhoto(HttpServletRequest request,HttpServletResponse response,@PathVariable("declNo") String declNo,@PathVariable("userCode") String userCode,@PathVariable("reqWith") String reqWith){
		DataModel base = MobileHelper.getBaseModel();
		String hexCode = request.getParameter("hexCode");
		if(!"e-CIQ".equals(reqWith) || Utils.isEmpty(userCode) || Utils.isEmpty(hexCode) || !hexCode.equals(MobileHelper.getMD5(userCode)) || Utils.isEmpty(declNo)){
			BaseModel bm = new BaseModel();
			bm.setFlag(false);
			bm.setMsg("请求异常");
			base.setCode(500);
			return base;
		}
		service.uploadFiles(request, declNo, userCode);
		return base;
		
	}
	
	/**
	 * 
	* <p>描述:由报检单号带出企业、生产批号等基本信息</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/loadBaseInfo",method=RequestMethod.POST)
	@ResponseBody
	public DataModel loadBaseInfo(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");
		if(StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<DeclBaseInfoModel> modelist=service.loadBaseInfo(declNo);
		base.setData(Utils.notEmpty(modelist)?modelist:"");
		//recordCount(declNo,"1100000036",request,response);
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:记录报检单回写记录信息</p>
	* @param declNo
	* @param userCode
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	public boolean recordCount(String declNo,String userCode,HttpServletRequest request,HttpServletResponse response) {
	/*	com.rongji.system.entity.SysUser user = userService.getUser2(userCode);
		String orgCode = companyCodeUtils.getLevelOrgCode(user.getOrgCode());
		boolean boo = service.dclDeclNoExist(declNo);
		if (boo) {
			return true;
		}
		return DeclNoCountController.updateCount(orgCode,user.getOrgCode(),new Date());
	*/
		return sceneService.recordCount(declNo, userCode, request, response);
	}
	
}

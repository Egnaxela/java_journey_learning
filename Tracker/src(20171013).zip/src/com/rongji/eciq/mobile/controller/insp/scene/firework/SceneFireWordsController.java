/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      weibo  
 * @version:     1.0
 * Createdate:   2017-7-20 下午2:31:16  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.scene.firework;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.InsResultRecord;
import com.rongji.eciq.mobile.entity.InsResultRecordItem;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.DeclBaseInfoModel;
import com.rongji.eciq.mobile.model.insp.scene.InsResultRecordItemModel;
import com.rongji.eciq.mobile.model.insp.scene.InsResultRecordModel;
import com.rongji.eciq.mobile.service.insp.scene.SceneService;
import com.rongji.eciq.mobile.service.insp.scene.fireWork.SceneFireWorksService;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo
 * @version:    1.0  
 * Create at:   2017-7-20 下午2:31:16  
 *  
 */
@Controller
@RequestMapping("/insp/fireWork")
public class SceneFireWordsController  extends MobileExceptionHandlerController{
	@Autowired
	private SceneFireWorksService service;
	@Autowired
	private SceneService Sceneservice;
	@Resource
	HQLCodeToNameDao dao;
	/**
	 * 烟花查验单初始化
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/open", method = RequestMethod.GET)
	@ResponseBody
	public DataModel ordHandle(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		InsResultRecord insResultRecord = new InsResultRecord();
		InsResultRecordModel model = new InsResultRecordModel();
		
		List<InsResultRecordItem> insResultRecordItemList = new ArrayList<InsResultRecordItem>();
		List<InsResultRecordItemModel> modelList = new ArrayList<InsResultRecordItemModel>();
		
		String declNo = request.getParameter("declNo");// 报检单号
		if (StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		insResultRecord = service.getInsResultRecord(declNo);
		String redId = "";
		if(insResultRecord.getResultRecordId()!= null){
			insResultRecordItemList = service.getInsResultRecordItem(insResultRecord.getResultRecordId());
			model.setBatchNo(insResultRecord.getBatchNo());
			model.setContainer(insResultRecord.getContainer());
			model.setContent(insResultRecord.getContent());
			model.setDandNo(insResultRecord.getDandNo());
			model.setDangBasCatCode(insResultRecord.getDangBasCatCode());
			model.setDangBasCatName(insResultRecord.getDangBasCatName());
			model.setDangDefect(insResultRecord.getDangDefect());
			model.setDangEval(insResultRecord.getDangEval());
			model.setDangEvalName(insResultRecord.getDangEvalName());
			model.setDangSmplNo(insResultRecord.getDangSmplNo());
			model.setDangSmplNum(insResultRecord.getDangSmplNum());
			model.setDeclNo(insResultRecord.getDeclNo());
			model.setDetectFlag(insResultRecord.getDetectFlag());
			model.setDetectResult(insResultRecord.getDetectResult());
			
			if(null != insResultRecord.getDropCheckDate()) {
				model.setDropCheckDate(DateUtil.format(insResultRecord.getDropCheckDate(), "yyyy-MM-dd"));
			}
//			model.setDropCheckDate(insResultRecord.getDropCheckDate());

			model.setDropCheckNo(insResultRecord.getDropCheckNo());
			if(null != insResultRecord.getDrugProhDate()) {
				model.setDrugProhDate(DateUtil.format(insResultRecord.getDrugProhDate(), "yyyy-MM-dd"));
			}
//			model.setDrugProhDate(insResultRecord.getDrugProhDate());
			
			model.setDrugProhNo(insResultRecord.getDrugProhNo());
			
//			model.setDrugSafeDate(insResultRecord.getDrugSafeDate());
			if(null != insResultRecord.getDrugSafeDate()) {
				model.setDrugSafeDate(DateUtil.format(insResultRecord.getDrugSafeDate(), "yyyy-MM-dd"));
			}
			
			model.setDrugSafeNo(insResultRecord.getDrugSafeNo());
			model.setEntName(insResultRecord.getEntName());
			model.setFireworkEval(insResultRecord.getFireworkEval());
			model.setFireworkEvalName(insResultRecord.getFireworkEvalName());
			model.setFlagArchive(insResultRecord.getFlagArchive());
			model.setGoodsNo(insResultRecord.getGoodsNo());
			model.setHugeFirework(insResultRecord.getHugeFirework());
			
//			model.setInsDate(insResultRecord.getInsDate());
			if(null != insResultRecord.getInsDate()) {
				model.setInsDate(DateUtil.format(insResultRecord.getInsDate(), "yyyy-MM-dd"));
			}
			
			model.setInspBasCatCode(insResultRecord.getInspBasCatCode());
			model.setInspBasCatName(insResultRecord.getInspBasCatName());
			model.setInspCommEval(insResultRecord.getInspCommEval());
			model.setInspCommEvalName(insResultRecord.getInspCommEvalName());
			model.setInspDefect(insResultRecord.getInspDefect());
			model.setInspEval(insResultRecord.getInspEval());
			model.setInspEvalName(insResultRecord.getInspEvalName());
			model.setInspMode(insResultRecord.getInspMode());
			model.setInspOthCatCode(insResultRecord.getInspOthCatCode());
			model.setInspOthCatName(insResultRecord.getInspOthCatName());
			String isClean = insResultRecord.getIsClean();
			if(StringUtils.isEmpty(isClean)) {
				isClean = "1";
			}
			model.setIsClean(isClean);
			String isContain = insResultRecord.getIsContain();
			if(StringUtils.isEmpty(isContain)) {
				isContain = "1";
			}
			model.setIsContain(isContain);
			String isCover = insResultRecord.getIsCover();
			if(StringUtils.isEmpty(isCover)) {
				isCover = "1";
			}
			model.setIsCover(isCover);
			String isHold = insResultRecord.getIsHold();
			if(StringUtils.isEmpty(isHold)) {
				isHold = "1";
			}
			model.setIsHold(isHold);
			String isLess = insResultRecord.getIsLess();
			if(StringUtils.isEmpty(isLess)) {
				isLess = "1";
			}
			model.setIsLess(isLess);
			String isMatch = insResultRecord.getIsMatch();
			if(StringUtils.isEmpty(isMatch)) {
				isMatch = "1";
			}
			model.setIsMatch(isMatch);
			String isNail = insResultRecord.getIsNail();
			if(StringUtils.isEmpty(isNail)) {
				isNail = "1";
			}
			model.setIsNail(isNail);
			String isSuit = insResultRecord.getIsSuit();
			if(StringUtils.isEmpty(isSuit)) {
				isSuit = "1";
			}
			model.setIsSuit(isSuit);
			String isTag = insResultRecord.getIsTag();
			if(StringUtils.isEmpty(isTag)) {
				isTag = "1";
			}
			model.setIsTag(isTag);
			
//			model.setOperDate(operDate)
			if(null != insResultRecord.getOperDate()) {
				model.setOperDate(DateUtil.format(insResultRecord.getOperDate(), "yyyy-MM-dd"));
			}
			
			model.setPackHeight(insResultRecord.getPackHeight());
			model.setPackLength(insResultRecord.getPackLength());
			model.setPackWidth(insResultRecord.getPackWidth());
			model.setProdDesc(insResultRecord.getProdDesc());
			model.setProdLevel(insResultRecord.getProdLevel());
			model.setProdName(insResultRecord.getProdName());
			model.setProdType(insResultRecord.getProdType());
			model.setQty(insResultRecord.getQty());
			model.setRemark(insResultRecord.getRemark());
			model.setResultRecordId(insResultRecord.getResultRecordId());
			//如果唛头为空，获取主干标记号码，湖南局邹俊反馈，业务员在主干报单时，会将唛头填在这里
			String shipMark = insResultRecord.getShipMark();
			if(StringUtils.isEmpty(shipMark)) {
				shipMark = service.getMarkNoByDeclNo(declNo);
			}
			model.setShipMark(shipMark);
			
//			model.setSpecCheckDate(insResultRecord.getSpecCheckDate());
			if(null != insResultRecord.getSpecCheckDate()) {
				model.setSpecCheckDate(DateUtil.format(insResultRecord.getSpecCheckDate(), "yyyy-MM-dd"));
			}
			
			model.setSpecCheckNo(insResultRecord.getSpecCheckNo());
			model.setTradeCountry(insResultRecord.getTradeCountry());
			model.setUnName(insResultRecord.getUnName());
			model.setUnNo(insResultRecord.getUnNo());
			model.setWeight(insResultRecord.getWeight());
			model.setWeightGross(insResultRecord.getWeightGross());
			model.setWeightNet(insResultRecord.getWeightNet());
			
			model.setContainerBlk(insResultRecord.getContainerBlk());
			model.setContainerCn(insResultRecord.getContainerCn());
			model.setContainerGy(insResultRecord.getContainerGy());
			model.setContainerPi(insResultRecord.getContainerPi());
			model.setContainerS(insResultRecord.getContainerS());
			
		
		}else{
			List<DeclBaseInfoModel> modelist=Sceneservice.loadBaseInfo(declNo);
			if(!CollectionUtils.isEmpty(modelist)){
				DeclBaseInfoModel m = modelist.get(0);
				model.setEntName(m.getMnufctrRegName());
				model.setBatchNo(m.getProdBatchNo());
				BigDecimal qty=new BigDecimal(m.getQty());
				model.setTradeCountry(dao.getTradeCountryNameByCode(m.getTradeCountryCode()));
				model.setQty(qty);
				BigDecimal weight=new BigDecimal(m.getWeight());
				model.setWeight(weight);
				//如果唛头为空，获取主干标记号码，湖南局邹俊反馈，业务员在主干报单时，会将唛头填在这里
				String shipMark = insResultRecord.getShipMark();
				if(StringUtils.isEmpty(shipMark)) {
					shipMark = service.getMarkNoByDeclNo(declNo);
				}
				model.setShipMark(shipMark);
			}
			
			/*model.setContent("无");
			model.setShipMark("无");*/
			model.setInspDefect("无");
			model.setDangDefect("无");
			redId = UUIDKeyGeneratorUils.newInstance().generateKey();
			model.setResultRecordId(redId);
		}
		
		
		
		if(CollectionUtils.isEmpty(insResultRecordItemList)){
			int a = 1;
			for(int i=0;i<21;i++){
				InsResultRecordItem item = new InsResultRecordItem();
				item.setEntUuid(UUIDKeyGeneratorUils.newInstance().generateKey());
				if(StringUtils.isNotEmpty(redId)) {
					item.setResultRecordId(redId);
				}
				item.setResultRecordItemId(new BigDecimal(a));
				a++;
				insResultRecordItemList.add(item);
			}
		}
		Map map = new HashMap();
		map.put("insResultRecord", model);
		map.put("insResultRecordItem", insResultRecordItemList);
		base.setData(map);
		return base;
	}
	
	
	/**
	 * 保存烟花查验单
	 * 
	 * @param request
	 * @param response
	 * @return	
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ResponseBody
	public DataModel saveFireworks(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base=MobileHelper.getBaseModel();
		
		String resultList = request.getParameter("insInfos");//查验记录
		String itemList = request.getParameter("checkInfos");//检验项目
		String appFlag = request.getParameter("appFlag");//移动版本
		if(StringUtils.isEmpty(resultList) || StringUtils.isEmpty(itemList) ){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		JSONArray resultListInfo = JSONArray.fromObject("["+resultList+"]");
		
		String redId = UUIDKeyGeneratorUils.newInstance().generateKey();
		List<InsResultRecordModel> modelList =(List<InsResultRecordModel>)JSONArray.toList(resultListInfo, InsResultRecordModel.class);
//		List<InsResultRecord> insResultRecord1 =(List<InsResultRecord>)JSONArray.toList(resultListInfo, InsResultRecord.class);
		
		JSONArray itemListInfo = JSONArray.fromObject(itemList);
		List<InsResultRecordItem> insResultRecordItem =(List<InsResultRecordItem>)JSONArray.toList(itemListInfo, InsResultRecordItem.class);

		if(!CollectionUtils.isEmpty(modelList)){
			InsResultRecordModel ins = modelList.get(0);
			InsResultRecord ent = service.getInsResultRecord(ins.getDeclNo());
			InsResultRecord newEntity = new InsResultRecord();
			newEntity.setBatchNo(ins.getBatchNo());
			newEntity.setContainer(ins.getContainer());
			newEntity.setContent(ins.getContent());
			newEntity.setDandNo(ins.getDandNo());
			newEntity.setDangBasCatCode(ins.getDangBasCatCode());
			newEntity.setDangBasCatName(ins.getDangBasCatName());
			newEntity.setDangDefect(ins.getDangDefect());
			newEntity.setDangEval(ins.getDangEval());
			newEntity.setDangEvalName(ins.getDangEvalName());
			newEntity.setDangSmplNo(ins.getDangSmplNo());
			newEntity.setDangSmplNum(ins.getDangSmplNum());
			newEntity.setDeclNo(ins.getDeclNo());
			newEntity.setDetectFlag(ins.getDetectFlag());
			newEntity.setDetectResult(ins.getDetectResult());
			
//			model.setDropCheckDate(insResultRecord.getDropCheckDate());
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			String dstr=ins.getDropCheckDate();  
			try {
				newEntity.setDropCheckDate(sdf.parse(dstr));
			} catch (ParseException e4) {
				e4.printStackTrace();
			}

			
			newEntity.setDropCheckNo(ins.getDropCheckNo());
//			newEntity.setDrugProhDate(DateUtil.format(insResultRecord.getDrugProhDate(), "yyyy-MM-dd"));
			SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");
			String dstr1=ins.getDrugProhDate();  
			try {
				newEntity.setDrugProhDate(sdf.parse(dstr1));
			} catch (ParseException e3) {
				e3.printStackTrace();
			}			
			
//			model.setDrugSafeDate(insResultRecord.getDrugSafeDate());
//			newEntity.setDrugSafeDate(DateUtil.format(ins.getDrugSafeDate(), "yyyy-MM-dd"));
			SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");
			String dstr2=ins.getDrugSafeDate();  
			try {
				newEntity.setDrugSafeDate(sdf.parse(dstr2));
			} catch (ParseException e2) {
				e2.printStackTrace();
			}	
			
			newEntity.setDrugSafeNo(ins.getDrugSafeNo());
			newEntity.setDrugProhNo(ins.getDrugProhNo());
			newEntity.setEntName(ins.getEntName());
			newEntity.setFireworkEval(ins.getFireworkEval());
			newEntity.setFireworkEvalName(ins.getFireworkEvalName());
			newEntity.setFlagArchive(ins.getFlagArchive());
			newEntity.setGoodsNo(ins.getGoodsNo());
			newEntity.setHugeFirework(ins.getHugeFirework());
			
//			model.setInsDate(insResultRecord.getInsDate());
//			newEntity.setInsDate(DateUtil.format(ins.getInsDate(), "yyyy-MM-dd"));
			SimpleDateFormat sdf3=new SimpleDateFormat("yyyy-MM-dd");
			String dstr3=ins.getInsDate();  
			try {
				newEntity.setInsDate(sdf.parse(dstr3));
			} catch (ParseException e1) {
				e1.printStackTrace();
			}	
			
			newEntity.setInspBasCatCode(ins.getInspBasCatCode());
			newEntity.setInspBasCatName(ins.getInspBasCatName());
			newEntity.setInspCommEval(ins.getInspCommEval());
			newEntity.setInspCommEvalName(ins.getInspCommEvalName());
			newEntity.setInspDefect(ins.getInspDefect());
			newEntity.setInspEval(ins.getInspEval());
			newEntity.setInspEvalName(ins.getInspEvalName());
			newEntity.setInspMode(ins.getInspMode());
			newEntity.setInspOthCatCode(ins.getInspOthCatCode());
			newEntity.setInspOthCatName(ins.getInspOthCatName());
			newEntity.setIsClean(ins.getIsClean());
			newEntity.setIsContain(ins.getIsContain());
			newEntity.setIsCover(ins.getIsCover());
			newEntity.setIsHold(ins.getIsHold());
			newEntity.setIsLess(ins.getIsLess());
			newEntity.setIsMatch(ins.getIsMatch());
			newEntity.setIsNail(ins.getIsNail());
			newEntity.setIsSuit(ins.getIsSuit());
			newEntity.setIsTag(ins.getIsTag());
			
//			model.setOperDate(operDate)
//			newEntity.setOperDate(DateUtil.format(insResultRecord.getOperDate(), "yyyy-MM-dd"));
//			SimpleDateFormat sdf3=new SimpleDateFormat("yyyy-MM-dd");
//			String dstr3=ins.getInsDate();  
			newEntity.setOperDate(new Date());	
			
			newEntity.setPackHeight(ins.getPackHeight());
			newEntity.setPackLength(ins.getPackLength());
			newEntity.setPackWidth(ins.getPackWidth());
			newEntity.setProdDesc(ins.getProdDesc());
			newEntity.setProdLevel(ins.getProdLevel());
			newEntity.setProdName(ins.getProdName());
			newEntity.setProdType(ins.getProdType());
			newEntity.setQty(ins.getQty());
			newEntity.setRemark(ins.getRemark());
			newEntity.setResultRecordId(ins.getResultRecordId());
			newEntity.setShipMark(ins.getShipMark());
			
//			model.setSpecCheckDate(insResultRecord.getSpecCheckDate());
//			newEntity.setSpecCheckDate(DateUtil.format(insResultRecord.getSpecCheckDate(), "yyyy-MM-dd"));
			SimpleDateFormat sdf4=new SimpleDateFormat("yyyy-MM-dd");
			String dstr4=ins.getSpecCheckDate();  
			try {
				newEntity.setSpecCheckDate(sdf.parse(dstr4));
			} catch (ParseException e) {
				e.printStackTrace();
			}	
			
			newEntity.setSpecCheckNo(ins.getSpecCheckNo());
			newEntity.setTradeCountry(ins.getTradeCountry());
			newEntity.setUnName(ins.getUnName());
			newEntity.setUnNo(ins.getUnNo());
			newEntity.setWeight(ins.getWeight());
			newEntity.setWeightGross(ins.getWeightGross());
			newEntity.setWeightNet(ins.getWeightNet());
			
			newEntity.setContainerBlk(ins.getContainerBlk());
			newEntity.setContainerCn(ins.getContainerCn());
			newEntity.setContainerGy(ins.getContainerGy());
			newEntity.setContainerPi(ins.getContainerPi());
			newEntity.setContainerS(ins.getContainerS());
			
			
			if(ent.getResultRecordId()!=null){
				newEntity.setResultRecordId(ent.getResultRecordId());
				service.saveOrUpDate(newEntity);
				String resultRecordId="";
				for(InsResultRecordItem item : insResultRecordItem){
					resultRecordId = item.getResultRecordId();
					if(StringUtils.isEmpty(resultRecordId)){
						item.setResultRecordId(resultRecordId);
					}
					if(StringUtils.isEmpty(item.getEntUuid())) {
						item.setEntUuid(UUIDKeyGeneratorUils.newInstance().generateKey());
					}
					service.saveOrUpDateItem(item);
				}
			}else{
				newEntity.setResultRecordId(redId);
				service.saveOrUpDate(newEntity);
				int a = 1;
				for(InsResultRecordItem item : insResultRecordItem){
					item.setEntUuid(UUIDKeyGeneratorUils.newInstance().generateKey());
					item.setResultRecordId(redId);
					item.setResultRecordItemId(new BigDecimal(a));
					service.saveOrUpDateItem(item);
					a++;
				}
			}
			
			base.setMsg("保存成功");
			if("mobile".equals(appFlag)) {
				base.setData(true);
			}
		}
		return base;
	}
}

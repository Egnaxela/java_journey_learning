/**  
 * FileName:SubAgainBtnController.java
 * @Description: 施检再分单控制层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.sub;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.service.insp.sub.SubAginBtnService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description: 施检再分单
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 上午10:21:04  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version  
 */
@Controller
@RequestMapping("/insp/again")
public class SubAgainBtnController extends MobileExceptionHandlerController{
	
	@Autowired
	private SubOrReasService service;
	@Autowired
	private SubAginBtnService againService;
	@Autowired
	private CompanyCodeUtils companyCodeUtils;
	
	/**
	 * 施检再分单
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/againSubBtn",method=RequestMethod.GET)
	@ResponseBody
	public DataModel againSubBtn(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		
		String declNo=request.getParameter("declNo");//选择记录的报检单号报检单号;多个以逗号隔开
		String userOrgCode=request.getParameter("userOrgCode");//当前施检部门
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String underDeptCode=request.getParameter("underDeptCode");//选择的施检分单部门
		String loginUser=request.getParameter("loginUser");//登录人员代码
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userOrgCode) ||StringUtils.isEmpty(expImpFlag)
				||StringUtils.isEmpty(underDeptCode)||StringUtils.isEmpty(loginUser)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<SubOrReasEntity> list =service.queryList(declNo,expImpFlag,userOrgCode);
		
		String[] arr=new String[2];
		if(CollectionUtils.isNotEmpty(list)){
			arr = checkAgainSub(list,userOrgCode,underDeptCode);
			if(arr[0].equals("1")){
                //校验选择是否为部门代码-------------
				String deptCode=arr[1];
                if(!isDeptCodeType(deptCode)){
                	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        			base.setMsg("请选择部门");
        			return base;
                }
                //施检再分单
                String msg =againSubmenu(list, deptCode,loginUser); 
                //提示结果信息
                if(StringUtils.isNotEmpty(msg)){
                	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        			base.setMsg(msg);
        			return base;
                }else{
                	base.setCode(HttpServletResponse.SC_OK);
        			base.setMsg("操作成功");
        			return base;
                }
            }else{
            	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    			base.setMsg(arr[1]);
    			return base;
            }
		}
		
		return null;
	}
	
	
	/**
     * 出入境施检再分单
     *
     * @param orgCode 机构代码
     * @param List<SubOrReasVO> 分单实体集合
     * @return 返回所选分单记录中被锁定的异常信息
     */
    public String againSubmenu(List<SubOrReasEntity> list, String orgCode,String userCode) {
    	if (CollectionUtils.isNotEmpty(list) && StringUtils.isNotEmpty(orgCode)) {

            // 用于施检再分单单待办事项  --暂未

            //报检单号
            String declNo;
            //管理记录id
            String declMagId;



            //获取当前部门所属机构
            String companyCode1 = companyCodeUtils.getBusinessOrgCode(orgCode,false);

            for (SubOrReasEntity vo : list) {
                //报检单号
                declNo = vo.getDeclNo();
                //管理记录id
                declMagId = vo.getDeclMagId();
                //判断管理记录是否被锁 
                if (service.getLocked(declMagId, null)) {
                	String msg=("报检单号:" + vo.getDeclNo() + ",已经被锁");
					return msg;
                }
                //锁住
                service.comLock(declMagId,userCode,orgCode);
                try {
                    String orgCodePatch = service.getOrgPathByOrgCode(orgCode);
                    //更新施检机构/清空接单人代码
                    againService.againSubmenu(declMagId, orgCode, orgCodePatch);
                    //更新报检单结果表同步接单人/施检机构代码
                    //增加机构参数  
                    againService.updateInsResultSum(declNo, orgCode, companyCode1, "");

                    // 用于施检再分单单待办事项  暂未
                    

                } catch (Exception err) {
                	
                } finally {
                    //解锁
                    service.comUnLock(declMagId);
                }
            }
        }
        return null;
    }
	
	
	
	
	
	/**
     * 校验出入境施检单是否可以再分单
     *
     * @param list 施检管理vo集合
     * @return 校验通过返回部门代码,否则返回空
     */
    public  String[] checkAgainSub(List<SubOrReasEntity> list,String companyCode,String underDeptCode) {
        String[] arr=new String[2];
        for (SubOrReasEntity vo : list) {
            //校验是否为辅施检
            if (!isAuxType(vo.getDeclNo(), vo.getFlowPathStatus())) {
            	arr[0]="0";
            	arr[1]="报检单号:" + vo.getDeclNo() + "为辅施检单,不可执行施检再分单";
            	return arr;
            }
            if (StringUtils.isNotEmpty(vo.getReceiverDocCode())) {
            	arr[0]="0";
            	arr[1]="报检单号:" + vo.getDeclNo() + "已分单,不可执行施检再分单";
            	return arr;
            }
        }
        //String companyCode = UserInfoUtil.getClientOrgCode();
        String orgCode;
        if(companyCode.length()>2){
        	orgCode=companyCode.substring(0, 2)+"0000";
        }
        //String orgCode = CompanyCodeUtils.getBusinessOrgCodeForFront(companyCode);
        //构建机构树并返回选择的部门
        //Orginfo orgInfo = OrgBasisDataHelper.getLowerDeptNoOrg2(orgCode);
        //关闭基础数据返回null
        if (underDeptCode == null) {
            return null;
        } else {
        	SubOrReasEntity sub = againService.findRepeatInsMagByDeclNoOrgCode(list, underDeptCode);
            if (sub != null) {
            	arr[0]="0";
            	arr[1]="报检单号:" + sub.getDeclNo() + "所选部门已被分配,不可执行施检再分单";
            	return arr;
            }
        }
        arr[0]="1";
    	arr[1]=underDeptCode;
    	return arr;
    }
	
    /**
     * 判断报检单是否为辅施检单<无提示>
     *
     * @param declNo 报检单号
     * @param flowStatus 流程状态
     * @return 辅施检返回false,否则返回true
     */
    public  boolean isAuxType(String declNo, String flowStatus) {
    	
        if (StringUtils.equals(flowStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY)
                || StringUtils.equals(flowStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE)) {
            return false;
        }
        return true;
    }
    
    /**
     * 判断是否为部门代码
     * 
     * @param  companyCode 部门代码
     * @return 校验通过返回true,否则返回false
     *
     */
    public  boolean isDeptCodeType(String companyCode) {
        Map<Integer,String> lev = companyCodeUtils.getOrgMapForFront(companyCode);
        if (lev != null && !lev.isEmpty()) {
            if (lev.containsKey(companyCodeUtils.ORG_LEVEL_4) || lev.containsKey(companyCodeUtils.ORG_LEVEL_5)) {
                return true;
            } 
        }
        return false;
    }
    
    

}

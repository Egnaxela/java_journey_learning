/**  
 * FileName:SubAuxiliaryController.java
 * @Description: 辅施检分单Controller
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.controller.insp.sub;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.dfish.base.DateUtil;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.InsMsgContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.sub.SubAuxiliaryModel;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.StringHelper;
import com.rongji.eciq.mobile.utils.StringTools;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.insp.InsDeclMagVo;

/**
 * 
 * Description: 辅施检分单Controller
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-8 下午5:39:09  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-2      李云龙                      1.0         修改辅施检分单数据初始化查询方法
 * 2017-5-10     才江男                      1.0         取消查询报检单扩展表
 * 2017-5-10     李云龙                      1.0         所需证单代码转名称
 * 2017-5-31     才江男                      1.0         所需证单判断null
 * 2017-6-05     李云龙                       1.0         修改工作内容代码串转名称方法 
 */
@Controller
@RequestMapping("/insp/auxi")
public class SubAuxiliaryController extends MobileExceptionHandlerController{
	@Autowired
	private SubAuxiliaryService service;
	@Autowired
	private SubOrReasService subService;
	@Autowired
	private SubAuditService audService;
	@Autowired
	private CompanyCodeUtils companyCodeUtils;
	@Resource
	private HQLCodeToNameDao codeToNameUtils;
	
	/**
	 * 辅施检分单数据初始化查询
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSubAuxiliary",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSubAuxiliary(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
		String expImpFlag=request.getParameter("expImpFlag");//出入境
		String orgCode=request.getParameter("orgCode");//当前机构
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(orgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		SubAuxiliaryModel subAuxiliaryModel= new SubAuxiliaryModel();
		List<InsDeclMagEntity> list =service.findInsDeclListByDeclNo(declNo);
		ArrayList<InsDeclMagVo> voList=new ArrayList<InsDeclMagVo>();
		
		
		InsDeclMagEntity insDeclMagEntity=service.getInsDeclMag(declNo,expImpFlag,orgCode);
//		DclIoDeclEx dclIoDeclEx=service.findDclIoDeclEx(declNo);
		String tradeCountryCode=service.getTradeCountryCodeByDeclNo(declNo);	
		String tradeCountryName=service.getTradeCountryNameByCode(tradeCountryCode);
//		if(dclIoDeclEx!=null){
//			String entTypeCode=dclIoDeclEx.getEntTypeCode();
//			if(StringUtils.isNotEmpty(entTypeCode)){
//				String entTypeName=service.findEntTypeName(entTypeCode);
//				subAuxiliaryModel.setEntTypeName(entTypeName);
//			}
//			
//		}
		if(insDeclMagEntity!=null){
            String declMagId = insDeclMagEntity.getDeclMagId();
//          //判断管理记录是否被锁 
//            if (subService.getLocked(declMagId, null)) {
//            	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//    			base.setMsg("报检单号:"+declNo+"已经已经被锁");
//    			return base;
//            }
			
			subAuxiliaryModel.setDeclNo(insDeclMagEntity.getDeclNo());
			List<DclIoDeclEntity> dcl = audService.getDclIoDeclEntity(insDeclMagEntity.getDeclNo());
			if(CollectionUtils.isEmpty(dcl)){
				subAuxiliaryModel.setEntName("");
			}else{
				subAuxiliaryModel.setEntName(dcl.get(0).getDeclRegName());
			}
//			subAuxiliaryModel.setEntName(insDeclMagEntity.getEntName());
			subAuxiliaryModel.setInspRequire(CommonCodeToNameUtils.inspRequireToName(insDeclMagEntity.getInspRequire()));
		}
		
		if(StringUtils.isNotEmpty(tradeCountryName)){
			subAuxiliaryModel.setTradeCountryName(tradeCountryName);
		}
		if(CollectionUtils.isNotEmpty(list)){
			for(InsDeclMagEntity vo:list){
				InsDeclMagVo insDeclMagVo=new InsDeclMagVo();
				insDeclMagVo.setDeclMagId(vo.getDeclMagId());
				insDeclMagVo.setFlowPathStatus(vo.getFlowPathStatus());
				
				
				//主施检所需证单数组
//		        String[] mainCertCodeArray = StringTools.sptString(vo.getCertTypeCodes(), ",");
//		        String[] arr=getNotEmptyCert(mainCertCodeArray);
//		        insDeclMagVo.setCertTypeNames(arr[1]);
				String certTypeCodes = vo.getCertTypeCodes();
				if(StringUtils.isEmpty(certTypeCodes)) {
					certTypeCodes = "";
				}
				insDeclMagVo.setCertTypeCodes(certTypeCodes);
				insDeclMagVo.setCertTypeNames(codeToNameUtils.getZCcmSimplelist5Entity("IOFCertBillName", vo.getCertTypeCodes()));
				
				insDeclMagVo.setDeclNo(vo.getDeclNo());
				insDeclMagVo.setExeInspOrgCode(vo.getExeInspOrgCode().substring(0,6));
				insDeclMagVo.setExcInspDeptCode(vo.getExcInspDeptCode());
				insDeclMagVo.setExcInspDeptName(service.getOrgCodeNameOrgCode(vo.getExcInspDeptCode()));
				insDeclMagVo.setExeInspOrgName(service.getOrgCodeNameOrgCode(vo.getExeInspOrgCode().substring(0,6)));
				if(vo.getFinishTime()!=null){
				insDeclMagVo.setFinishTime(DateUtil.format(vo.getFinishTime(), "yyyy-MM-dd"));
				}
				insDeclMagVo.setInspContCodes(vo.getInspContCodes());
				
				if(StringUtils.isNotEmpty(vo.getInspContCodes())){
					insDeclMagVo.setInspContNames(codeToNameUtils.insContCodesToName(vo.getInspContCodes()));
				}
				
				if(StringUtils.isNotEmpty(vo.getRemark())){
					if(vo.getRemark().equals("$MobileTerminal$")){
						insDeclMagVo.setRemark("");
					}else{
						insDeclMagVo.setRemark(vo.getRemark());
					}
					
				}

				String flowStatus=vo.getFlowPathStatus();
				//主辅检状态转名称
                if (flowStatus.equals(InsContext.FLOW_PATH_STATUS_AUXILIARY)) {
                	insDeclMagVo.setStatus(InsContext.FLOW_PATH_STATUS_AUXILIARY_NAME);
                } else if (flowStatus.equals(InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE)) {
                	insDeclMagVo.setStatus(InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE_NAME);
                } else if (flowStatus.equals(InsContext.FLOW_PATH_STATUS_MAIN)) {
                	insDeclMagVo.setStatus(InsContext.FLOW_PATH_STATUS_MAIN_NAME);
                }
				
				//分单状态转名称
                if (StringUtils.isEmpty(vo.getReceiverDocCode())) {
                	insDeclMagVo.setSubmenuType(InsContext.SUBMENU_TYPE_NOT_SUB_NAME);
                } else {
                	insDeclMagVo.setSubmenuType(InsContext.SUBMENU_TYPE_YET_SUB_NAME);
                }
                insDeclMagVo.setSubType(vo.getSubType());

				voList.add(insDeclMagVo);
				
			}
			subAuxiliaryModel.setInsDeclMaglist(voList);
			
		}
		base.setData(subAuxiliaryModel);
		return base;	
	}
	
	/**
	 * 辅施检分单--添加校验
	 * @param request
	 * @param response
	 * @return
	 * @throws ParseException 
	 */
	@RequestMapping(value="/auxInfoValidate",method=RequestMethod.POST)
	@ResponseBody
	public DataModel auxInfoValidate(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		DataModel base=MobileHelper.getBaseModel();
		String addInsDeclMag =request.getParameter("InsDeclMag");// 添加的辅施检信息
		String oldInsDeclMag =request.getParameter("InsDeclMagList");//原来的辅施检信息
		
//		//添加的信息
		JSONArray addjson = JSONArray.fromObject(addInsDeclMag); 
		List<InsDeclMagVo> addList = (List<InsDeclMagVo>)JSONArray.toList(addjson, InsDeclMagVo.class);  
		//原来的信息
		JSONArray oldjson = JSONArray.fromObject(oldInsDeclMag); 
		List<InsDeclMagVo> oldList = (List<InsDeclMagVo>)JSONArray.toList(oldjson, InsDeclMagVo.class); 

		InsDeclMagVo magVo=new InsDeclMagVo();
		if(CollectionUtils.isNotEmpty(addList)){
			magVo=addList.get(0);
		}else{
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("添加的辅施检信息为空");
			return base;
		}
		String warnMsg = "";

        if (CollectionUtils.isNotEmpty(oldList)) {
            int size = oldList.size();
            String sameInsContMsg = "";
            for (int i = 0; i < size; i++) {
            	InsDeclMagVo vo = oldList.get(i);
                if (vo != null) {
                    warnMsg += checkAuxOrgRepeat(magVo.getExcInspDeptCode(), vo.getExcInspDeptCode());
                    if(StringUtils.isEmpty(sameInsContMsg)){
                        sameInsContMsg = checkSameInsCont(magVo.getInspContCodes(), vo.getInspContCodes());
                        warnMsg += sameInsContMsg;
                    }
                    if (!StringUtils.equals(vo.getStatus(), InsContext.FLOW_PATH_STATUS_MAIN_NAME)) {
                        warnMsg += checkCertRepeat(magVo.getCertTypeCodes(), vo.getCertTypeCodes());
                    }
                }
            }
        }
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		if (StringUtils.isNotEmpty(magVo.getFinishTime())) {
			warnMsg += checkDate(sdf.parse(magVo.getFinishTime()));
		}
        if (StringUtils.isNotEmpty(warnMsg)) {
            warnMsg = StringHelper.replace("校验信息 : " + warnMsg, "\n", "");
            base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(warnMsg);
			return base;
        }
        base.setCode(HttpServletResponse.SC_OK);
        base.setData("true");
		return base;
	}
	
	/**
	 * 辅施检分单修改校验
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/modBtnAction", method = RequestMethod.POST)
	@ResponseBody
	public DataModel modBtnAction(HttpServletRequest request,
			HttpServletResponse response) throws ParseException {
		DataModel base = MobileHelper.getBaseModel();
		String mainDeptCode = request.getParameter("mainDeptCode");// 原来施检部门代码
		String mainCertCodes = request.getParameter("mainCertCodes");// 原来所需证单代码
		String selRow = request.getParameter("selRow");// 选择的哪一行
		String selectInsDeclMag = request.getParameter("selectInsDeclMagList");// 选中的辅施检信息
		String oldInsDeclMag = request.getParameter("InsDeclMagList");// 全部的辅施检信息
		if (StringUtils.isEmpty(mainDeptCode)
				|| StringUtils.isEmpty(selRow)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}

		// 选择的信息
		JSONArray selectjson = JSONArray.fromObject(selectInsDeclMag);
		List<InsDeclMagVo> list = (List<InsDeclMagVo>) JSONArray.toList(
				selectjson, InsDeclMagVo.class);
		// 全部信息
		JSONArray oldjson = JSONArray.fromObject(oldInsDeclMag);
		List<InsDeclMagVo> oldList = (List<InsDeclMagVo>) JSONArray.toList(
				oldjson, InsDeclMagVo.class);

		
		String oldsorgCode = companyCodeUtils.getBusinessOrgCode(mainDeptCode,
				false);
		String declWorkNo;
		if (CollectionUtils.isNotEmpty(list) & list.size() == 1) {
			// 若选中这一条获得此条记录对应的实体
			InsDeclMagVo ModiyVO = list.get(0);
			String sorgCode = companyCodeUtils.getBusinessOrgCode(
					ModiyVO.getExcInspDeptCode(), false);
			if (!StringUtils.equals(oldsorgCode, sorgCode)) {
				declWorkNo = "";
				sorgCode = sorgCode;
			}

			// 主施检
			if (StringUtils.equals(ModiyVO.getStatus(),
					InsContext.FLOW_PATH_STATUS_MAIN_NAME)) {
				
				
				
				
				if ((!StringUtils.equals(mainDeptCode,
						ModiyVO.getExcInspDeptCode()))) {
					base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					base.setMsg("主施检记录不可修改施检部门");
					return base;
				}
				if (!StringUtils.equals(mainCertCodes,
						ModiyVO.getCertTypeCodes())) {
					base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					base.setMsg("主施检记录不可修改所需证单");
					return base;
				}
			}
			
			// 辅施检
		    if (StringUtils.equals(ModiyVO.getStatus(),
					InsContext.FLOW_PATH_STATUS_AUXILIARY_NAME)) {
		    	//已分单不能修改、删除、保存
                if(ModiyVO.getSubmenuType().equals("已分单")){
                	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					base.setMsg("已分单不能修改记录");
					return base;
                }			
			}
			
		    // 辅施检完成
		    if (StringUtils.equals(ModiyVO.getStatus(),
					InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE_NAME)) {
		    	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg("辅施检完成不能修改记录");
				return base;			
			}
		    
			String warnMsg = "";
			if (CollectionUtils.isNotEmpty(oldList)) {
				int size = oldList.size();
				String sameInsContMsg = "";
				for (int i = 0; i < size; i++) {
					if (i == Integer.parseInt(selRow)) {
						continue;
					}
					InsDeclMagVo vo = oldList.get(i);
					if (vo != null) {
						warnMsg += checkAuxOrgRepeat(
								ModiyVO.getExcInspDeptCode(),
								vo.getExcInspDeptCode());
						if (StringUtils.isEmpty(sameInsContMsg)) {
							sameInsContMsg = checkSameInsCont(
									ModiyVO.getInspContCodes(),
									vo.getInspContCodes());
							warnMsg += sameInsContMsg;
						}
						if (!StringUtils.equals(vo.getStatus(),
								InsContext.FLOW_PATH_STATUS_MAIN_NAME)) {
							warnMsg += checkCertRepeat(
									ModiyVO.getCertTypeCodes(),
									vo.getCertTypeCodes());
						}
					}
				}
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if (StringUtils.isNotEmpty(ModiyVO.getFinishTime())) {
				warnMsg += checkDate(sdf.parse(ModiyVO.getFinishTime()));
			}
			if (StringUtils.isNotEmpty(warnMsg)) {
				warnMsg = StringHelper.replace("校验信息 : " + warnMsg, "\n", "");
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg(warnMsg);
				return base;
			}
			base.setCode(HttpServletResponse.SC_OK);
			base.setData("true");
			return base;
		} else if (CollectionUtils.isEmpty(list)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("请选择操作记录");
			return base;
		} else if (CollectionUtils.isNotEmpty(list) & list.size() > 1) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("只能选择一条记录");
			return base;
		}
		return null;

	}
	
	/**
	 * 辅施检分单--提交按钮
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/saveBtnAction",method=RequestMethod.POST)
	@ResponseBody
	public DataModel saveBtnAction(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
		String all=request.getParameter("allList");//表格中全部数据
		
		
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//全部的信息
		JSONArray addjson = JSONArray.fromObject(all); 
		List<InsDeclMagVo> list = (List<InsDeclMagVo>)JSONArray.toList(addjson, InsDeclMagVo.class); 
		List<InsDeclMagEntity> allList=new ArrayList<InsDeclMagEntity>();
		List<InsDeclMagEntity> allList1=new ArrayList<InsDeclMagEntity>();
		InsDeclMagEntity magVo=new InsDeclMagEntity();
		if(CollectionUtils.isNotEmpty(list)){
			for(InsDeclMagVo vo:list){
				magVo=getInsDeclMagEntity(vo);
				allList.add(magVo);
				allList1.add(magVo);
			}
		}
		
	
		
		HashMap<String, String> map = new HashMap<String, String>();
		String sorgCode="1";
		String expImpFlag="1";
		if(CollectionUtils.isNotEmpty(allList)){
			expImpFlag=allList.get(0).getExpImpFlag();
            for(InsDeclMagEntity v : allList){
            	sorgCode=companyCodeUtils.getBusinessOrgCode(v.getExcInspDeptCode(),false); 
                if(!map.containsKey(sorgCode) && StringUtils.isNotEmpty(v.getDeclWorkNo())){
                    map.put(sorgCode, v.getDeclWorkNo());
                }  
            }
        }
		if(CollectionUtils.isNotEmpty(allList)){
			InsDeclMagEntity main=new InsDeclMagEntity();
            for(InsDeclMagEntity ww:allList){
            	if(ww.getFlowPathStatus().equals("800")){
            		main=ww;
            	}
            }
			
            allList.remove(main);//去除主施检记录
        }
		boolean  isHaveAux = (allList == null|| allList.size()<=0)?false:true;

		
		String declCertCode;
		String[] sumCert = new String[2];
		//结果登记实体
		InsResultSumEntity insResultSumEntity=service.findInsResultSumByDeclNo(declNo);
		if(insResultSumEntity != null){
            declCertCode = insResultSumEntity.getCertTypeCodes();
            //将所有辅施检记录的所需证单代码剔除,重组主施检的所需证单代码
            sumCert =repMainCert1(declCertCode, allList);
        }
		//保存辅助施检分单
        service.saveInsMag1(declNo, sumCert, expImpFlag, allList1,isHaveAux, map,sorgCode);  
        base.setCode(HttpServletResponse.SC_OK);
		base.setData(true);
		return base;

	}
	
	
	/**
	 * 辅施检分单--设置主检
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/setMainCheckBtn", method = RequestMethod.POST)
	@ResponseBody
	public DataModel setMainCheckBtn(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();

		String declNo = request.getParameter("declNo");// 报检单号
		String selectarr = request.getParameter("selectList");// 选中的表格中的数据
		String all = request.getParameter("allList");// 表格中的数据

		if (StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}

		// 选中的记录
		JSONArray selectJson = JSONArray.fromObject(selectarr);
		List<InsDeclMagVo> listVo = (List<InsDeclMagVo>) JSONArray
				.toList(selectJson, InsDeclMagVo.class);
		// 全部的记录
		JSONArray addJson = JSONArray.fromObject(all);
		List<InsDeclMagVo> allListVo = (List<InsDeclMagVo>) JSONArray
				.toList(addJson, InsDeclMagVo.class);


		List<InsDeclMagEntity> list=new ArrayList<InsDeclMagEntity>();
		List<InsDeclMagEntity> allList=new ArrayList<InsDeclMagEntity>();
		List<InsDeclMagEntity> allList1=new ArrayList<InsDeclMagEntity>();
		
		InsDeclMagEntity magVo=new InsDeclMagEntity();
		if(CollectionUtils.isNotEmpty(listVo)){
			for(InsDeclMagVo vo:listVo){
				magVo=getInsDeclMagEntity(vo);
				list.add(magVo);
			}
		}
		if(CollectionUtils.isNotEmpty(allListVo)){
			for(InsDeclMagVo vo:allListVo){
				magVo=getInsDeclMagEntity(vo);
				allList.add(magVo);
				allList1.add(magVo);
			}
		}

		
		String sorgCode = "1";// 作用机构
		String expImpFlag = "1";// 出入境标志
		if (list.size() == 1) {
			InsDeclMagEntity main=new InsDeclMagEntity();
            for(InsDeclMagEntity ww:allList){
            	if(ww.getFlowPathStatus().equals("800")){
            		main=ww;
            	}
            }

			if (StringUtils.isEmpty(main.getInspContCodes())) {
				base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				base.setMsg("请设置主施检工作内容");
				return base;
			}
			
			HashMap<String, String> map = new HashMap<String, String>();
			// 获得列表对象集合
			expImpFlag = allList.get(0).getExpImpFlag();
			if (CollectionUtils.isNotEmpty(allList)) {
				for (InsDeclMagEntity v : allList) {
					sorgCode = companyCodeUtils.getBusinessOrgCode(
							v.getExcInspDeptCode(), false);
					if (!map.containsKey(sorgCode)
							&& StringUtils.isNotEmpty(v.getDeclWorkNo())) {
						map.put(sorgCode, v.getDeclWorkNo());
					}
				}
			}
			// 去除主施检记录
			allList.remove(main);
			// 结果登记实体
			String declCertCode;
			String[] sumCert = new String[2];
			InsResultSumEntity insResultSumEntity = service
					.findInsResultSumByDeclNo(declNo);
			if (insResultSumEntity != null) {
				declCertCode = insResultSumEntity.getCertTypeCodes();
				// 将所有辅施检记录的所需证单代码剔除,重组主施检的所需证单代码
				sumCert = repMainCert1(declCertCode, allList);
			}			
			// 保存辅施检分单
//			service.saveInsMag1(declNo, sumCert, expImpFlag, allList1, true,
//					map, sorgCode);

			// 主辅检互换
			String businessOrgCode = companyCodeUtils.getBusinessOrgCode(
					main.getExcInspDeptCode(), false);
			
			service.setMainIns(main, list.get(0), businessOrgCode);
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(true);
			return base;
		} else if (CollectionUtils.isEmpty(list)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("请选择操作记录");
			return base;
		} else if (list.size() > 1) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("只能选择一条记录");
			return base;
		}
		return null;

	}
	
	
	
	/**
	 * 填充list
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param list
	 * @return
	 * @author 李云龙
	 */
	public InsDeclMagEntity getInsDeclMagEntity(InsDeclMagVo vo) {
		InsDeclMagEntity magVo = new InsDeclMagEntity();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if (StringUtils.isNotEmpty(vo.getFinishTime())) {
				magVo.setFinishTime(sdf.parse(vo.getFinishTime()));
			}
			magVo.setDeclNo(vo.getDeclNo());
			magVo.setInspContCodes(vo.getInspContCodes());
			magVo.setCertTypeNames(vo.getCertTypeNames());
			magVo.setRemark(vo.getRemark());
			magVo.setExeInspOrgCode(vo.getExcInspDeptCode());
			magVo.setCertTypeCodes(vo.getCertTypeCodes());
			magVo.setExcInspDeptCode(vo.getExcInspDeptCode());
			InsDeclMagEntity mainVO = service.findInsDeclMagEntity(vo.getDeclNo());
			
			String orgCodePath=subService.getOrgPathByOrgCode(vo.getExcInspDeptCode());

			if (StringUtils.isNotEmpty(vo.getDeclMagId())) {
				magVo.setDeclMagId(vo.getDeclMagId());
			} else {
				// 添加时设置主键
				magVo.setDeclMagId(UUIDKeyGeneratorUils.newInstance()
						.generateKey());
			}

			if (StringUtils.isNotEmpty(vo.getFlowPathStatus())) {
				magVo.setFlowPathStatus(vo.getFlowPathStatus());
			} else {
				magVo.setFlowPathStatus(InsContext.FLOW_PATH_STATUS_AUXILIARY);
			}
			// 分单状态代码
			if (StringUtils.isNotEmpty(vo.getSubType())) {
				magVo.setSubType(vo.getSubType());
			} else {
				magVo.setSubType(InsContext.SUBMENU_TYPE_NOT_SUB);
			}
			// 货物名称
			magVo.setGoodsName(mainVO.getGoodsName());
			// 出入境标记
			magVo.setExpImpFlag(mainVO.getExpImpFlag());
			// 分单标记
			magVo.setSubPriv(CommContext.Y);
			// 审单标记
			magVo.setAuditPriv(CommContext.N);
			// 查验标记
			magVo.setCheckPriv(CommContext.N);
			// 综合评定标记
			magVo.setEvalPriv(CommContext.N);
			// 不合格登记标记
			magVo.setUnquaPriv(CommContext.N);
			// 检验要求
			magVo.setInspRequire(mainVO.getInspRequire());
			// 报检日期
			magVo.setDeclDate(mainVO.getDeclDate());
			// 收货人
			magVo.setConsigneeCname(mainVO.getConsigneeCname());
			magVo.setEntName(mainVO.getEntName());
			magVo.setEntMgrNo(mainVO.getEntMgrNo());
			magVo.setDeclRegName(mainVO.getDeclRegName());
			// 流程状态
			magVo.setProcessStatus(mainVO.getProcessStatus());
			// 是否存在辅检标记
			magVo.setIsHaveAux(CommContext.Y);
			magVo.setOrgCodePath(orgCodePath);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return magVo;
	}
	
	
	
	/**
     * 辅施检选择证书后，过滤出主施检中相同的证书代码
     *
     * @param mainCertCodes 报检时所需证单代码
     * @param List<InsDeclMagVO> 辅施检InsDeclMagVO对象集合
     */
    public String[] repMainCert1(String mainCertCodes, List<InsDeclMagEntity> list) {
    	
        //主施检所需证单数组
        String[] mainCertCodeArray = StringTools.sptString(mainCertCodes, ",");
        //判断不为空
        if (CollectionUtils.isNotEmpty(list) && mainCertCodeArray != null
                && mainCertCodeArray.length > 0) {
            for (InsDeclMagEntity vo : list) {
                for (int i = 0; i < mainCertCodeArray.length; i++) {
                    //辅施检所需证单串
                    String auxCertTypeCodes = vo.getCertTypeCodes();
                    //辅施检所需证单数组
                    String[] auxCertTypeCodeArray = StringTools.sptString(auxCertTypeCodes, ",");
                    //如果未复选证单
                    if (auxCertTypeCodeArray.length == 0) {
                        if (StringUtils.equals(auxCertTypeCodes, mainCertCodeArray[i])) {
                            mainCertCodeArray[i] = "";
                        }
                    } else {
                        int s = auxCertTypeCodeArray.length;
                        for (int j = 0; j < s; j++) {
                            if (StringUtils.equals(mainCertCodeArray[i], auxCertTypeCodeArray[j])) {
                                mainCertCodeArray[i] = "";
                            }
                        }
                    }
                }
            }
        }
        return getNotEmptyCert(mainCertCodeArray);
    }
	
    /**
     * 所需证单数据里的非空字符值的元素即是主施检最后的证书代码串
     *
     * @param certCodes 所需证单代码
     */
    public String[] getNotEmptyCert(String[] certCodes) {
        String[] array = new String[2];
        String newCertCode = "";
        String newCertName = "";
        if (certCodes != null && certCodes.length > 0) {
            for (String code : certCodes) {
                if (StringUtils.isNotEmpty(code)) {
                    newCertName += service.getIOFCertBillNameName(code) + ",";
                    newCertCode = newCertCode + code + ",";
                }
            }
            if (newCertCode.length() > 0) {
                newCertCode = newCertCode.substring(0, newCertCode.length() - 1);
            }
            if (newCertName.length() > 0) {
                newCertName = newCertName.substring(0, newCertName.length() - 1);
            }
        }
        array[0] = newCertCode;
        array[1] = newCertName;

        return array;
    }
    
    /**
     * 校验所选机构或部门是否与其他辅施检机构或部门重复
     *
     * @param orgCode 被比较机构码
     * @param otherOrgCode 其他要比较机构代码
     * @return 校验通过返回空字符,否则返回异常提示
     */
    public static String checkAuxOrgRepeat(String orgCode, String otherOrgCode) {
        if (isSameCompanyCode(orgCode, otherOrgCode)) {
            return "施检部门已存在";
        }
        return "";
    }
    
    /**
     * 判断两个机构或部门代码是否相同
     *
     * @param companyCode 机构/部门代码
     * @param paramCompanyCode 比较机构/部门代码
     * @return 非空相同返回true, 不同返回false
     */
    public static boolean isSameCompanyCode(String companyCode, String paramCompanyCode) {
        if (StringHelper.isNotEmpty(companyCode, paramCompanyCode) && StringUtils.equals(companyCode, paramCompanyCode)) {
            return true;
        }
        return false;
    }
    
    /**
     * 校验施检内容不重复
     *
     * @param insContCodes 工作内容代码串
     * @param compInsContCodes 工作内容代码串
     * @return 校验不通过返回异常提示，否则返回空字符
     */
    public static String checkSameInsCont(String insContCodes, String compInsContCodes) {
        if (StringUtils.isNotEmpty(insContCodes) && StringUtils.isNotEmpty(compInsContCodes)) {
            String[] insContArray = insContCodes.split(",");
            if (insContArray != null && insContArray.length > 0) {
                for (String insContCode : insContArray) {
                    if (compInsContCodes.indexOf(insContCode) != -1) {
                        return InsMsgContext.WORK_CONTENT_EXIST + " ";
                    }
                }
            }
        }
        return "";
    }
    
    /**
     * 校验所需证单是否重复
     *
     * @param certCodes 所需证单代码串
     * @param compCertCodes 所需证单代码串
     * @return 校验不通过返回异常提示，否则返回空字符
     */
    public static String checkCertRepeat(String certCodes, String compCertCodes) {
        String[] certCodesArray = StringTools.sptString(certCodes, ",");
        String[] compCertCodesArray = StringTools.sptString(compCertCodes, ",");
        if (certCodesArray != null && certCodesArray.length > 0 && compCertCodesArray != null && compCertCodesArray.length > 0) {
            for (String code : certCodesArray) {
                for (String compCode : compCertCodesArray) {
                    if (StringUtils.equals(code, compCode)) {
                        return "所需证单已存在于其他管理记录中";
                    }
                }
            }
        }
        return "";
    }
    
    /**
     * 校验选择的日期是否大于等于当日日期
     *
     * @param startDate 日期
     * @return 校验不通过返回异常提示，否则返回空字符
     */
    public static String checkDate(Date startDate) {
        Date taday = new Date();
        if (startDate != null) {
            if (startDate.after(taday) || DateUtils.isSameDay(taday, startDate)) {
                return "";
            } else {
                return "完成时间要大于等于当日日期";
            }
        } else {
            return "";
        }
    }
}

/**  
 * FileName:    SubDeclContController.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 下午2:35:49  
 *  
 */  

package com.rongji.eciq.mobile.controller.insp.sub;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.coobird.thumbnailator.name.ConsecutivelyNumberedFilenames;
import net.sf.json.JSONArray;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsCheckCommand;
import com.rongji.eciq.mobile.entity.InsCheckCommandCont;
import com.rongji.eciq.mobile.entity.InsContModel;
import com.rongji.eciq.mobile.entity.InsDrawRecord;
import com.rongji.eciq.mobile.entity.SysIfcCheckCommonModel;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.GoodsResultRegisterModel;
import com.rongji.eciq.mobile.model.insp.sub.SubInsContModel;
import com.rongji.eciq.mobile.service.insp.sub.SubDeclContService;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description: 分单改派单发送查验指令控制层  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 下午2:35:49  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */
@Controller
@RequestMapping("/sub/declcont")
public class SubDeclContController {
	
	@Autowired
	private SubDeclContService contService;
	
	@Autowired
	private HQLCodeToNameDao codeToNameDao;
	
	/**
	 * <p>
	 * 通过报检号获得集装箱信息列表与开掏箱设置信息
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 */
	@RequestMapping(value = "/getDclIoDeclCont", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getDclIoDeclCont(HttpServletRequest request, HttpServletResponse response) {
		String declNo = request.getParameter("declNo");
		DataModel base = MobileHelper.getBaseModel();
		if (declNo == null || StringUtils.isEmpty(declNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		String entName = request.getParameter("entName");//企业名称
	    String billLadNo = request.getParameter("billLadNo");//提运单号
		List<SubInsContModel> rlist = new ArrayList<SubInsContModel>(); 
		//根据报检单号获得所有集装箱
		List<InsContModel> contList = contService.getContList(declNo);
		for (InsContModel cont : contList) {
			SubInsContModel e = new SubInsContModel();
			e.setCntnrModeCode(cont.getCntnrModeCode());
			e.setContDtId(cont.getContDtId());
			e.setContNo(cont.getContNo());
			e.setDeclNo(cont.getDeclNo());
			e.setIfDrawBox(cont.getIfDrawBox());
			e.setIfOpenBox(cont.getIfOpenBox());
			e.setInsDrawRecordId(cont.getInsDrawRecordId());
			e.setIsCheck(cont.getIsCheck());
			e.setOperCode(cont.getOperCode());
			//通过报检号/集装箱号获得所关联货物信息集合
			List<DclIoDeclGoodsEntity> list = contService.getGoodsList(declNo,cont.getContNo()); 
			String[] goodsInfo =  mergeGoodsIdNoName(list);
			e.setEntName(entName);
            e.setBillLadNo(billLadNo);
            e.setGoodsNos(goodsInfo[0]);
            e.setDeclGoodsCnames(goodsInfo[1]);
            
            //select t.*, t.rowid from Z_CCM_SIMPLELIST_4 t where t.indexid='ContainerStandard'
            e.setCntnrModeName(codeToNameDao.getMeasurementNameByCode(e.getCntnrModeCode(),"ContainerStandard"));
            //界面展示操作开掏箱标记
            if(StringUtils.equals(e.getIsCheck(),"1") || StringUtils.equals(e.getIsCheck(),"2")){
                e.setChekIs(true);
            }else{
                e.setChekIs(false);
            }
            //无论是系统或人为操作掏箱,开箱查验都设置true
            if(StringUtils.equals(e.getIfDrawBox(),"1") || StringUtils.equals(e.getIfDrawBox(),"2")){
                e.setChekIs(true);
                e.setIfOpeBox(true);
                e.setIfDrwBox(true);
            }else{
                e.setIfDrwBox(false);
            }
            //无论是系统或人为操作开箱,查验都设置true
            if(StringUtils.equals(e.getIfOpenBox(),"1") || StringUtils.equals(e.getIfOpenBox(),"2")){
                e.setChekIs(true);
                e.setIfOpeBox(true);
            }else{
                e.setIfOpeBox(false);
            }
            
           //判断是否发送查验指令
            if (contService.findCheckCommandByContNo(declNo, e.getContNo(),e.getCntnrModeCode())) {
                e.setIsSendCheckCommand("已发送");
            } else {
                e.setIsSendCheckCommand("未发送");
            }
            rlist.add(e);
		}
		base.setCode(200);
		base.setData(rlist);
		return base;
	}

	/**
	* <p>描述:进行拼接</p>
	* @param list
	* @return
	* @author 夏晨琳
	*/
	private String[] mergeGoodsIdNoName(List<DclIoDeclGoodsEntity> list) {
		String goodsNos = "";
        String goodsCnames = "";
        String[] goods = new String[2];

        if (Utils.notEmpty(list)) {
            for (DclIoDeclGoodsEntity e : list) {
                goodsNos += e.getGoodsNo() + ",";
                goodsCnames += e.getDeclGoodsCname() + ",";
            }

            int goodsNosLength = goodsNos.length();
            if (goodsNosLength > 200) {
                goodsNos = goodsNos.substring(0, 201);
            } else if (goodsNosLength > 0) {
                goodsNos = goodsNos.substring(0, goodsNosLength - 1);
            }

            int goodsCnamesLength = goodsCnames.length();
            if (goodsCnamesLength > 4000) {
                goodsCnames = goodsCnames.substring(0, 4001);
            } else if (goodsCnamesLength > 0) {
                goodsCnames = goodsCnames.substring(0, goodsCnamesLength - 1);
            }
        }

        goods[0] = goodsNos;
        goods[1] = goodsCnames;

        return goods;
	}
	
	/**
	 * <p>
	 * 保存开掏箱设置
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 */
	@RequestMapping(value = "/saveBoxSet", method = RequestMethod.POST)
	@ResponseBody
	public DataModel saveBoxSet(HttpServletRequest request, HttpServletResponse response) {
		String insContList = request.getParameter("insContList");
		DataModel base = MobileHelper.getBaseModel();
		String operCode = request.getParameter("operCode");//操作人代码
		if (insContList == null || StringUtils.isEmpty(insContList)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		JSONArray addjson = JSONArray.fromObject(insContList); 
		List<SubInsContModel> addList = (List<SubInsContModel>)JSONArray.toList(addjson, SubInsContModel.class); 
		//保存开掏箱设置
		contService.saveBoxSet(addList,operCode);
		base.setCode(200);
		base.setData("操作成功");
		return base;
	}
	
	/**
	 * <p>
	 * 发送查验指令
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/sendCheck", method = RequestMethod.POST)
	@ResponseBody
	public DataModel sendCheck(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		String insContList = request.getParameter("insContList");
		String declNo = request.getParameter("declNo");
		String checkDate = request.getParameter("checkDate");//查验时间
		String orgCode = request.getParameter("orgCode");//施检机构
		String checkSiteCode = request.getParameter("checkSiteCode");
		String checkSisteName = request.getParameter("checkSisteName");
		String operCode = request.getParameter("operCode");
		DataModel base = MobileHelper.getBaseModel();
		if (insContList == null || StringUtils.isEmpty(insContList)
			|| StringUtils.isEmpty(declNo)	|| StringUtils.isEmpty(declNo)	
			|| StringUtils.isEmpty(checkDate)	|| StringUtils.isEmpty(orgCode)	
			|| StringUtils.isEmpty(checkSiteCode)	|| StringUtils.isEmpty(checkSisteName)	
			|| StringUtils.isEmpty(operCode)
		   ) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		JSONArray addjson = JSONArray.fromObject(insContList); 
		List<SubInsContModel> list = (List<SubInsContModel>)JSONArray.toList(addjson, SubInsContModel.class); 
		//初始化查验指令信息
		InsCheckCommand checkEntity = new InsCheckCommand();
		checkEntity.setCheckCmdId(UUIDKeyGeneratorUils.newInstance().generateKey());
		checkEntity.setDeclNo(declNo);//报检号
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    checkEntity.setCheckDate(format.parse(checkDate));
	    checkEntity.setExeInspOrgCode(orgCode);
	    checkEntity.setCheckSiteCode(checkSiteCode);//场地编号
        checkEntity.setCheckSiteName(checkSisteName);//场地名称
        List<InsCheckCommandCont> contList=contService.insContToCommandCont(checkEntity.getCheckCmdId(),list);
        //校验查验指令主表信息
        if (format.parse(checkDate).getTime() < new Date().getTime()) {
        	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
			base.setData("拟查验时间小于当前时间!");
			return base;
        }
        if(Utils.isEmpty(contList)){
        	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
			return base;
        }
        //需要前台校验非当前操作人维护,不能保存开掏箱设置，行记录未进行开掏箱设置
        for (InsCheckCommandCont cont : contList) {
           boolean boo= contService.findCheckCommandByContNo(declNo, cont.getContNo(),cont.getCntnrModeCode());
           if (boo) {
        	base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
   			base.setMsg(MobileHelper.OPERATION_FAIL_FLAG_TIP);
   			base.setData("已发送查验指令");
   			return base;
           }
		}
        //发送查验指令
       contService.sendCommand(checkEntity, contList, list,operCode);
       base.setCode(200);
       base.setData("操作成功");
	   return base;
	}
	
	/**
	 * <p>
	 * 获取查验场地信息
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/getInspList", method = RequestMethod.POST)
	@ResponseBody
	public DataModel getInspList(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		DataModel base = MobileHelper.getBaseModel();
		String orgCode = request.getParameter("orgCode");
		String fieldNo = request.getParameter("fieldNo");
		String fieldName = request.getParameter("fieldName");
		if (orgCode == null || StringUtils.isEmpty(orgCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		List<SysIfcCheckCommonModel> mlist = contService.queryInspList(orgCode,fieldNo,fieldName);
		base.setCode(200);
		base.setData(mlist);
		return base;
	}
}

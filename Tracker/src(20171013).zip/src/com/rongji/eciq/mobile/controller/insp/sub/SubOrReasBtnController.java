/**  
 * FileName:SubOrReasBtnController.java
 * @Description: 分单改派单按钮Controller
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */ 
package com.rongji.eciq.mobile.controller.insp.sub;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.DeclOrgCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.ProcessControlUtils;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.entity.SysAppProcessLog;

/**
 * 
 * Description: 分单改派单按钮Controller
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-8 下午5:41:02  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12     李云龙                      1.0         修改报检流程状态不正确
 * 2017-5-12     才江男                      1.0         更新流程状态
 * 2017-06-19    李云龙                      1.0         优化分单改派单操作
 */
@Controller
@RequestMapping("/insp/subbtn")
public class SubOrReasBtnController extends MobileExceptionHandlerController {
	@Autowired
	private SubOrReasService service;
	@Resource
	StatusControlUtils statusControlUtils;
	@Resource
	DeclOrgCodeUtils declOrgCodeUtils;
	@Resource
	ProcessControlUtils processControlUtils;
	@Resource
	CompanyCodeUtils companyCodeUtils;
	@Resource
	SceneProcessSerchService processService;

	/**
	 * 分单改派单按钮操作
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/subOrReasBtn", method = RequestMethod.POST)
	@ResponseBody
	public DataModel initSubAuxiliary(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String declNos = request.getParameter("declNo");// 报检单号
		String deptCode = request.getParameter("deptCode");// 施检部门
		String recCode = request.getParameter("recCode");// 施检员
		String userCode = request.getParameter("loginUser");// 当前登录人员代码
		String expImpFlag = request.getParameter("expImpFlag");// 出入境标志
		if (StringUtils.isEmpty(declNos) || StringUtils.isEmpty(deptCode)
				|| StringUtils.isEmpty(recCode)||StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(userCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<SubOrReasEntity> queryList = service.queryList(declNos,
				expImpFlag, deptCode);
		String msg=subOrReassigned(queryList, deptCode, recCode,userCode);

		if(StringUtils.isNotEmpty(msg)){
			base.setMsg(msg);
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return base;
		}else{
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(MobileHelper.OPERATION_SUCCESS_FLAG_TIP);
			return base;
		}
	}
	
	/**
     * 出入境分单改派单操作
     *
     * @param  recCode 接单人代码
     * @param  deptCode 施检部门代码<界面所选>
     */	
	public String subOrReassigned(List<SubOrReasEntity> queryList,String deptCode,String recCode,String userCode){
		String msg;
    	if (!CollectionUtils.isEmpty(queryList)) {
			// 分单改派单退单 待办事项 暂不
            

			// 报检单号
			String declNo;
			// 管理表记录id
			String declMagId;
			// 流程状态
			String flowStatus;
			// 报检单环节
			String processLink;
			// 报检单状态
			String processStatus;
			// 接单人代码
			String receiverDocCode;
			String workNo;
//            UserInfo user=new UserInfo();
//            user.setUserCode(userCode);
            SysUser sysUser=service.getSysUser(userCode);
//            if(sysUser!=null){
//            	user.setCompanyCode(sysUser.getOrgCode());
//            	user.setUserName(sysUser.getUserName());
//            }
            
            String orgCode=companyCodeUtils.getBusinessOrgCode(deptCode,false);
			
			HashMap<String, String> mainSub = new HashMap<String, String>();
			mainSub.put("AUDIT_PRIV", CommContext.Y);
			mainSub.put("EVAL_PRIV", CommContext.Y);
			HashMap<String, String> auxSub = new HashMap<String, String>();
			auxSub.put("AUDIT_PRIV", CommContext.Y);
			auxSub.put("CHECK_PRIV", CommContext.Y);

			SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			for (SubOrReasEntity vo : queryList) {
				// 报检单号
				declNo = vo.getDeclNo();

				workNo = vo.getDeclWorkNo();
				// 管理表记录id
				declMagId = vo.getDeclMagId();
				
				//DclIoDeclEntity dclIoDeclEntity=service.getDclIoDeclEntity(declNo);
			    // 报检单环节
//				processLink = dclIoDeclEntity.getProcessLink();
//				// 报检单状态
//				processStatus=vo.getProcessStatus();
//				if(StringUtils.isEmpty(processStatus)){
//					processStatus = dclIoDeclEntity.getProcessStatus();
//				}
				
				// 流程状态
				flowStatus = vo.getFlowPathStatus();
				
				// 接单人代码
				receiverDocCode = vo.getReceiverDocCode();				
				
				if (!StringUtils.equals(deptCode, vo.getExeInspOrgCode())
						|| !service.isUserByOrg(deptCode, recCode)) {
					msg=("报检单号:" + vo.getDeclNo()+ ",所选施检员非当前报检单中施检部门人员");
					return msg;
				}
				// 判断管理记录是否被锁
				if (service.getLocked(declMagId, null)) {
					msg=("报检单号:" + vo.getDeclNo() + ",已经被锁");
					return msg;
				}

				// 锁住
				service.comLock(declMagId,userCode,sysUser.getOrgCode());

				try {
					// 如果为主施检分单
					if (StringUtils.equals(flowStatus,CommContext.FLOW_PATH_STATUS_MAIN)) {
						//更新施检总结果表
						service.updateInsResultSum( recCode, orgCode, declNo);
						if (StringUtils.isEmpty(receiverDocCode)) {
							// 更新报检单环节状态
							statusControlUtils.updateProcess(declNo,CommContext.INS,MobileCommContext.WAIT_INS_CHECK,userCode);
//							processControlUtils.updateProAndStatus(declNo, workNo,
//                                    CommContext.INS, MobileCommContext.WAIT_INS_CHECK, user, processLink, processStatus, null, recCode, true, null);
							// 用于主施检分单待办事项

							// 更新mag表查询权限标记位
							service.updatePriv(declMagId, mainSub);
						} else {
						  // 分单改派单退单 待办事项 暂不

						}
//						service.updateRecerByProcessLog(declNo, recCode);
						// 下发分单流程表数据
					    //sendSysProcessLog(declNo);
						SysAppProcessLog log = new SysAppProcessLog();
						log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
						log.setDeclNo(declNo);
						log.setProcessNode(MobileCommContext.INS);
						log.setNodeMemo(MobileCommContext.INS_NAME);
						log.setProcessStatus(MobileCommContext.WAIT_INS_CHECK);
						log.setStatusMemo(MobileCommContext.WAIT_INS_CHECK_NAME);
						log.setOperCode(userCode);
						log.setOperName(sysUser.getUserName());
						log.setTreaOrgCode(deptCode);
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String dateString = formatter.format(new Date());
						Date newDate = formatter.parse(dateString);
//						ParsePosition pos = new ParsePosition(8);
//						Date currentTime_2 = formatter.parse(dateString, pos);
						log.setOperDate(newDate);
						processService.savelog(log);
						
					} else {
						 //增加方法参数（施检部门，施检机构，施检内容）
//						 service.writeAuxLog(vo.getExeInspOrgCode(),
//						 vo.getExeInspOrgCode(), vo.getInspContCodes(),
//						 declMagId, declNo, CommContext.INS, processStatus,
//						 "辅施检进行分单改派单", user);

						 //添加辅施检流程日志与更新报检单环节
						 SysAppProcessLog log = new SysAppProcessLog();
						 log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
						 log.setDeclNo(declNo);
						 log.setProcessNode(MobileCommContext.INS);
						 log.setNodeMemo(MobileCommContext.INS_NAME);
						 log.setProcessStatus(MobileCommContext.WAIT_INS_CHECK);
						 log.setStatusMemo(MobileCommContext.WAIT_INS_CHECK_NAME);
						 log.setOperCode(userCode);
						 log.setOperName(sysUser.getUserName());
						 log.setTreaOrgCode(deptCode);
						 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						 String dateString = formatter.format(new Date());
						 Date newDate = formatter.parse(dateString);
						 log.setOperDate(newDate);
						 processService.savelog(log);
						 statusControlUtils.updateDclProcess(declNo, MobileCommContext.INS, MobileCommContext.WAIT_INS_CHECK, userCode);
						 
						 
						 
						// 用于辅施检分单改派单待办事项
						// backLob.auxSubBackLob(subPowerCode, chkPowerCode,
						// scePowerCode, deptCode, recCode, receiverDocCode);
						// 辅检权限
						service.updatePriv(declMagId, auxSub);
					}
					// 批量sql-执行分单改派单
					String time = sf.format(new Date());
					
					service.updateInsDeclMag( deptCode, time, userCode, recCode, declMagId);		
				} catch (Exception e) {
					e.printStackTrace();
					msg="出现异常";
					return msg;
				} finally {
					// 解锁
					service.comUnLock(declMagId);					
				}
			}
		}else{
			msg="分单改派单为空信息";
			return msg;
		} 
    	return null;
	}
		
	
}

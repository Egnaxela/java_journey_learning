/**  
 * FileName:SubOrReasController.java
 * @Description: 分单改派单按钮Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */ 
package com.rongji.eciq.mobile.controller.insp.sub;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsGoodsMonItemEntity;
import com.rongji.eciq.mobile.entity.InsMonItemEvalStdEntity;
import com.rongji.eciq.mobile.entity.InsOriaudiExcePbinfoEntity;
import com.rongji.eciq.mobile.entity.RulBatchruleEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.sub.AuditCheckGoodsModel;
import com.rongji.eciq.mobile.model.insp.sub.InsGoodsMonItemModel;
import com.rongji.eciq.mobile.model.insp.sub.InsOriaudiExcePbinfoModel;
import com.rongji.eciq.mobile.model.insp.sub.RulBatchruleModel;
import com.rongji.eciq.mobile.model.insp.sub.SubOrReasInitTableModel;
import com.rongji.eciq.mobile.service.insp.examining.SubAuditService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.OperatorType;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;


/**
 * 
 * Description: 分单改派单controller  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017-5-12 下午1:37:45  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-11          吴有根           	 1.0                         增加审单查看-检测项目的查询显示
 * 2017-05-12   魏波                       1.0       根据报检单号查第一条货物的名称
 * 2017-05-22   李晨阳                           1.0         添加短号变长号方法 
 * 2017-05-24   才江男                           1.0         增加返回报检号
 */
@Controller
@RequestMapping("/insp/sub")
public class SubOrReasController extends MobileExceptionHandlerController{
	
	@Autowired
	private SubOrReasService service;
	@Autowired
	private SubAuditService subService;
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	
	@Resource
	private HQLCodeToNameDao codeToNameUtils;
	@Autowired
	private DeclNoUtils declNoUtils;
	
	
	/**
	 * 分单改派单-table数据初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/initSubOrReas",method=RequestMethod.GET)
	@ResponseBody
	public DataModel initSubOrReas(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		String userOrgCode=request.getParameter("userOrgCode");//机构代码
		String declNo=request.getParameter("declNo");//报检单号
		String declRegName= Utils.getParameter(request, "declRegName");//报检单位
		String currentPage=request.getParameter("currentPage");
		String subStatus=request.getParameter("subStatus");//分单状态
		String processStatus=request.getParameter("processStatus");//流程状态
		String consigneeCname=request.getParameter("consigneeCname");//国内收货人
		String orgCode=request.getParameter("orgCode");//施检机构
		String recCode=request.getParameter("recCode");//施检员
		String checkRequire=request.getParameter("checkRequire");//检验要求
//		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		Date starDate=new Date();
		Date endDate=new Date();
//		try {
//			starDate=dateFormat.parse(request.getParameter("starDate"));//开始日期
//			endDate=dateFormat.parse(request.getParameter("endDate"));//结束日期
//		} catch (Exception e) {
//			logger.info("日期转换异常...");
//		}
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(userOrgCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		//-----------------------------------短号变长号------------------------------------------------
		if (StringUtils.isNotEmpty(declNo)) {
			String userCode = request.getParameter("userCode");
//			UserInfo user = new UserInfo();
//			user.setUserCode(userCode);
//			SysUser sysUser = subOrReasDao.getSysUser(userCode);
//			if (sysUser != null) {
//				user.setCompanyCode(sysUser.getOrgCode());
//				user.setUserName(sysUser.getUserName());
//			}
//			String longDeclNo = "";
//			if (expImpFlag.equals("1")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_IN, user);
//			} else if (expImpFlag.equals("2")) {
//				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
//						DeclContext.DECL_TYPE_OUT, user);
//			}
//			declNo = longDeclNo;
			declNo = declNoUtils.shortDeclNoToLong(declNo, userCode, expImpFlag);
		}
        //----------------------------------短号变长号--------------------------------------------------
		List<SubOrReasEntity> querySubList=service.querySubList(declNo, orgCode, "",subStatus, recCode, processStatus, 
                starDate, endDate, checkRequire, consigneeCname, expImpFlag, null, declRegName,userOrgCode,currentPage);
		ArrayList<SubOrReasInitTableModel> list= new ArrayList<SubOrReasInitTableModel>();
		if(Utils.notEmpty(querySubList)){
			list.ensureCapacity(querySubList.size());
			for(SubOrReasEntity entity :querySubList){
				SubOrReasInitTableModel model=new SubOrReasInitTableModel();
				model.setDeclNo(entity.getDeclNo());
				model.setDeclRegName(entity.getDeclRegName());
				model.setFlowPathStatus(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
//				model.setGoodsName(entity.getGoodsName());
				List<DclIoDeclEntity> dcl = subService.getDclIoDeclEntity(entity.getDeclNo());
				if(CollectionUtils.isEmpty(dcl)){
					model.setDeclRegName("");
				}else{
					model.setDeclRegName(dcl.get(0).getDeclRegName());
				}
				model.setGoodsName(subService.getGoodName(entity.getDeclNo()));
				if(StringUtils.isNotEmpty(entity.getRemark())){
					model.setTradeCountryCode(entity.getRemark());
					//entity.setRemark(entity.getRemark().substring(0, entity.getRemark().indexOf("$")));
				}else{
					model.setTradeCountryCode("");
					//entity.setRemark("");
				}
				model.setSubType(CommonCodeToNameUtils.subTypeStatusToName(entity.getSubType()));
				model.setDeclDate(DateUtil.format(entity.getDeclDate(), "yyyy-MM-dd"));
				model.setEntMgrNo(entity.getEntMgrNo());
				model.setInspRequire(CommonCodeToNameUtils.inspRequireToName(entity.getInspRequire()));
				model.setFlowPathStatus(entity.getFlowPathStatus());
				model.setFlowPathStatusName(CommonCodeToNameUtils.flowPathStatusToName(entity.getFlowPathStatus()));
				list.add(model);				
			}
		}
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(declNo);
		vo.setList(list);
		base.setData(vo);
		return base;
	}
	
	
	/**
	 * 审单信息 查看
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/auditCheck",method=RequestMethod.GET)
	@ResponseBody
	public DataModel auditCheck(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		List<Object> reList=new ArrayList<Object>();
		String declNo=request.getParameter("declNo");//报检单号     
		String userOrgCode=request.getParameter("userOrgCode");//施检部门 
		String userCode=request.getParameter("userCode");//施检员
		String expImpFlag=request.getParameter("expImpFlag");
		
		String currentPage=request.getParameter("currentPage");
		String goodsNo=request.getParameter("goodsNo");
		
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userOrgCode)||StringUtils.isEmpty(userCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<SubOrReasEntity> queryList=service.queryList(declNo,expImpFlag,userOrgCode);
		if(!CollectionUtils.isEmpty(queryList)&&queryList.size()==1){
			//报检单信息
			
			//货物信息
			//根据报检号获取报检货物列表
			List<DclIoDeclGoodsEntity> goodList=service.queryGoodsListByDeclNo(queryList.get(0).getDeclNo(),currentPage);
			List<AuditCheckGoodsModel> modelList=new ArrayList<AuditCheckGoodsModel>();
			if(!CollectionUtils.isEmpty(goodList)){
				for(DclIoDeclGoodsEntity entity :goodList){
					AuditCheckGoodsModel model=new AuditCheckGoodsModel();
					model.setGoodsNo((entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")));
					model.setDeclGoodsCname(entity.getDeclGoodsCname());
					model.setCiqCode(entity.getCiqCode());
					model.setCiqName(entity.getCiqName());
					model.setProdHsCode(entity.getProdHsCode());
					model.setHsCodeDesc(entity.getHsCodeDesc());
					model.setInspType(entity.getInspType());
					model.setGoodsTotalVal(entity.getGoodsTotalVal()+"");
					model.setCurrency(entity.getCurrency());
					model.setQty((entity.getQty()+"").substring(0,(entity.getQty()+"").indexOf(".")));
					model.setQtyMeasUnit(entity.getQtyMeasUnit());
					model.setWeight(entity.getWeight()+"");
					model.setWtMeasUnit(entity.getWtMeasUnit());
					modelList.add(model);
				}
				
				//默认加载第一条货物的布控信息
				if(StringUtils.isEmpty(goodsNo)){
					goodsNo = goodList.get(0).getGoodsNo()+"";
				}
				DclIoDeclGoodsEntity declGoodsVo=goodList.get(0);
				if(declGoodsVo!=null){
                    //CIQ代码
                    String ciqCode = declGoodsVo.getCiqCode();
                    //若为出境
                    if(expImpFlag.equals("2")){
                        //生产单位注册号
                        String entCode = declGoodsVo.getMnufctrRegNo();
                        //出境企业编码取货物的生产单位注册号
                        String entMgrCode = declGoodsVo.getMnufctrRegNo();
                    }else{
                        //原产国
                        String countryCode = declGoodsVo.getOriCtryCode();
                    }
                    
                    //根据报检号和货物序号加载布控信息
                    List<InsOriaudiExcePbinfoEntity> oriaudList = service.findInsOriaudiExcePbinfo(declNo, goodsNo);
                    List<InsOriaudiExcePbinfoModel> oriaudModelList=new ArrayList<InsOriaudiExcePbinfoModel>();
                    if(!CollectionUtils.isEmpty(oriaudList)){
                    	for(InsOriaudiExcePbinfoEntity entity:oriaudList){
                    		InsOriaudiExcePbinfoModel model=new InsOriaudiExcePbinfoModel();
                    		model.setAbnormalCause(entity.getAbnormalCause());
                    		model.setAbnormalType(CommonCodeToNameUtils.MonitorBlockTypeCodeToName(entity.getAbnormalType()));
                    		model.setExceptionDetail(entity.getExceptionDetail());
                    		model.setDeclNo(entity.getDeclNo());
                    		if(entity.getGoodsNo()!=null){
                    			model.setGoodsNo((entity.getGoodsNo()+"").substring(0, (entity.getGoodsNo()+"").indexOf(".")));
                    		}else{
                    			model.setGoodsNo("");
                    		}
                    		oriaudModelList.add(model);
                    	}
                    }
                    reList.add(oriaudModelList);
                    
//                    //根据报检号和货物序号加载检测项目
//                    List<InsGoodsMonItemVO> insGoodsMonItemVOsList= service.findDetectionItem(declNo, goodsNo);
//                    
//                    
//                    //根据报检号和货物序号加载查验项目
//                    List<InsCheckItemVO> checkItemList = service.queryInsCheckItemList1(declNo, goodsNo, InsContext.CHECK_ITEM_CODE);
//                    
//                    //根据报检号和货物序号加载木质包装检疫
//                    List<InsCheckItemVO> woodItemList = service.queryInsCheckItemList1(declNo, goodsNo, InsContext.WOOD_ITEM_CODE);
//                    
//                    
//                    //根据报检号和货物序号加载集装箱检疫
//                    List<InsCheckItemVO> contItemList = service.queryInsCheckItemList1(declNo, goodsNo, InsContext.CONT_ITEM_CODE);
//                    
//                    
//                    
//                    //根据报检号和货物序号加载卫生检疫
//                    List<InsCheckItemVO> healItemList = service.queryInsCheckItemList1(declNo, goodsNo, InsContext.HEAL_ITEM_CODE);
//                    
//                    //根据报检号和货物序号加载风险监控
//                    List<RewMonPlanLotedVo> monPlanlist =  service.getLotedPlans(declNo, goodsNo, entCode);
//                    
//                    //根据报检号和货物序号加载法定抽批规则
//                    List<RulBatchruleEntity> rulelist=service.queryRuleList(countryCode, ciqCode, impExpFlag, entMgrCode)
//                    
				}
			}
			reList.add(modelList);
			
		}else{
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.REQUEST_FAIL_FLAG_TIP);
			
		}
		base.setData(reList);
		return base;
	}
	
	/**
	 * 审单信息 查看-加载检测项目
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/auditCheck-monItem",method=RequestMethod.GET)
	@ResponseBody
	public DataModel auditCheck2(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号     
		String userOrgCode=request.getParameter("userOrgCode");//施检部门 
		String userCode=request.getParameter("userCode");//施检员
		String expImpFlag=request.getParameter("expImpFlag");
		
		String currentPage=request.getParameter("currentPage");
		String goodsNo=request.getParameter("goodsNo");
		
		if(StringUtils.isEmpty(declNo)||StringUtils.isEmpty(userOrgCode)||StringUtils.isEmpty(userCode)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		List<SubOrReasEntity> queryList=service.queryList(declNo,expImpFlag,userOrgCode);
		if(!CollectionUtils.isEmpty(queryList)&&queryList.size()==1){
			InsGoodsMonItemModel model;
			String formName="";//表单名称
			String monItemId="";//监控项目Id
			String evalStandards="";//评定标准
			String statuteTitle="";//法规标题
			//监管货物评定标准对象集合
			List<InsMonItemEvalStdEntity> insMonStdList;
			List<InsGoodsMonItemEntity> list=service.findGoodsItemsByGoodsNo(declNo,goodsNo);
			if(Utils.notEmpty(list)){
				ArrayList<InsGoodsMonItemModel> modelList=new ArrayList<InsGoodsMonItemModel>();
				modelList.ensureCapacity(list.size());
				for(InsGoodsMonItemEntity entity:list){
					model=new InsGoodsMonItemModel();
					monItemId=entity.getMonItemId();
					//获得监管货物评定标准对象集合
					insMonStdList=service.findInsMonItemEvalStdEntityById(monItemId);
					//获得监控项目评定标准
					evalStandards=this.toStdString(insMonStdList);
					//获得表单名称
					formName=service.getRulCtlitemFormName(monItemId);
					//判断是否必报
					if(StringUtils.equals(entity.getDeclareSym(), CommContext.Y_1)){
						model.setDeclareSymName(CommContext.Y_1_NAME);
					}else{
						model.setDeclareSymName(CommContext.N_0_NAME);
					}
					//获取法规标题串
					statuteTitle=service.getlegalBasisTitles(insMonStdList);
					model.setEvaluationStandard(evalStandards);
					model.setFormName(formName);
					model.setMonitItemName(entity.getMonitItemName());
					model.setMonitItemTypeN(entity.getMonitItemTypeN());
					model.setStatuteTitle(statuteTitle);
					modelList.add(model);
				}
				
				base.setData(modelList);
			}else{
				base.setData(list);
			}
		}else {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.REQUEST_FAIL_FLAG_TIP);
			return base;
		}	
		return base;
	}

	
	/**
	 * 将评定指标拼成字符串
	 * @param insMonStdList
	 * @return
	 */
	private String toStdString(List<InsMonItemEvalStdEntity> evalStds) {
		 StringBuilder stdString = new StringBuilder();

	        if (evalStds != null
	            && evalStds.size() > 0) {
	            for (InsMonItemEvalStdEntity std : evalStds) {
	                if (std.getTargVal() != null
	                    ) {//&& std.getStdOperateSymbol() != null
	                    stdString.append(
	                            OperatorType.getLiteral(std.getTargOperSymbl()))
	                            .append(std.getTargVal());
	                }

	                if (std.getIndLowrLim() != null
	                    && std.getOperSymblLow() != null) {
	                    if (stdString.length() > 0) {
	                        stdString.append(" AND ");
	                    }
	                    stdString.append(
	                            OperatorType
	                            .getLiteral(std.getOperSymblLow()))
	                            .append(std.getIndLowrLim());
	                }

	                if (std.getIndUppLim() != null
	                    && std.getOperSymblUp() != null) {
	                    if (stdString.length() > 0) {
	                        stdString.append(" AND ");
	                    }
	                    stdString.append(
	                            OperatorType
	                            .getLiteral(std.getOperSymblUp()))
	                            .append(std.getIndUppLim());
	                }
	                if (stdString.length() > 0) {
	                    stdString.append(" ");
	                }
	                if (StringUtils.isNotBlank(std.getAssMeasureUnit())) {
	                    String measureUnitName = codeToNameUtils.getMeasurementNameByCode(std.getAssMeasureUnit(),"Measurement");
	                    stdString.append(StringUtils.isEmpty(measureUnitName)?std.getAssMeasureUnit():measureUnitName);
	                }
	                break;
	            }
	            if (evalStds.size() > 1) {
	                stdString.append(" ...");
	            }
	        }
	        return stdString.toString();
	}
	
	
	/**
	 * 审单查看-法定抽批规则查看
	 */
	@RequestMapping(value="/auditCheck-legal",method=RequestMethod.GET)
	@ResponseBody
	public DataModel auditCheckLegal(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检号
		String goodsNo=request.getParameter("goodsNo");//货物序号
		String userOrgCode=request.getParameter("userOrgCode");//用户机构代码
		String currentPage=request.getParameter("currentPage");//当前页
		String expImpFlag=request.getParameter("expImpFlag");//出入境标志
		
		String ciqCode;
		String countryCode = "";    //与法定抽批规则适用国家代码
		String entMgrCode = "";   // //出境企业编码取货物的生产单位注册号
		if(StringUtils.isEmpty(expImpFlag)||StringUtils.isEmpty(userOrgCode)||StringUtils.isEmpty(expImpFlag)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		DclIoDeclEx vo=service.getInsDeclInfo(declNo);
		if(vo!=null){
            //入境企业编码取报检单上的企业报检单位注册号,
            entMgrCode = vo.getEntMgrNo();
            //出境为贸易国别
          //  countryCode = vo.getTradeCountryCode();
            
		}
		List<SubOrReasEntity> queryList=service.queryList(declNo,expImpFlag,userOrgCode);
		List<RulBatchruleEntity> rulelist=new ArrayList<RulBatchruleEntity>();
		ArrayList<RulBatchruleModel> modelList=new ArrayList<RulBatchruleModel>();
		if(!CollectionUtils.isEmpty(queryList)&&queryList.size()==1){
			//根据报检号获取报检货物列表
			List<DclIoDeclGoodsEntity> goodList=service.queryGoodsListByDeclNo(queryList.get(0).getDeclNo(),currentPage);
			if(!CollectionUtils.isEmpty(goodList)){
				HashMap<String,DclIoDeclGoodsEntity> map=new HashMap<String, DclIoDeclGoodsEntity>();
				for(DclIoDeclGoodsEntity declGoodsVo:goodList){
					map.put((declGoodsVo.getGoodsNo()+"").contains(".")?(declGoodsVo.getGoodsNo()+"").substring(0, (declGoodsVo.getGoodsNo()+"").indexOf(".")):"",declGoodsVo);
				}
				
				DclIoDeclGoodsEntity declGoodsVo=null;
				//默认加载第一条货物的布控信息
				if(StringUtils.isEmpty(goodsNo)){
					declGoodsVo=goodList.get(0);
				}else {
					declGoodsVo=map.get(goodsNo);
				}
				
				if(declGoodsVo!=null){
                    //CIQ代码
                     ciqCode = declGoodsVo.getCiqCode();
                    //若为出境
                    if(expImpFlag.equals("2")){
                    	//出境企业编码取货物的生产单位注册号
                         entMgrCode = declGoodsVo.getMnufctrRegNo();
                    }else{
                        //原产国
                         countryCode = declGoodsVo.getOriCtryCode();
                    }

                    //加载法定抽批规则
                    rulelist=service.queryRuleList(countryCode, ciqCode, expImpFlag, entMgrCode,userOrgCode);
				}
			}
		}
		
		if(Utils.notEmpty(rulelist)){
			modelList.ensureCapacity(rulelist.size());
			for(RulBatchruleEntity entity:rulelist){
				RulBatchruleModel model=new RulBatchruleModel();
				model.setBatchruleName(entity.getBatchruleName());//法定抽批规则名称
				model.setSampleSch(entity.getSampleSch());//抽样方案
				model.setBatchruleLstate(CommonCodeToNameUtils.legalRuleStatusToName(entity.getBatchruleLstate()));//法定抽批状态
				modelList.add(model);
			}
		}
		base.setData(modelList);
		return base;
	}
	
}
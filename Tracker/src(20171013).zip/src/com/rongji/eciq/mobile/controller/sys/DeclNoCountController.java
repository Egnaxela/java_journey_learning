/**  
 * FileName: DeclNoCountController.java    
 * @Description: 报检单统计处理Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年9月12日 下午7:20:59  
 *  
 */

package com.rongji.eciq.mobile.controller.sys;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.DclProcessCountEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.DclProcessCountModel;
import com.rongji.eciq.mobile.model.sys.DclProcessStatsModel;
import com.rongji.eciq.mobile.service.sys.DeclNoCountService;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.entity.SysOrganize;
import com.rongji.system.sys.service.SysOrganizeService;

/**
 * Description: 报检单统计处理
 * Controller Copyright:
 * Copyright (c)2017 Company: rongji
 * 
 * @author: 吴有根
 * @version: 1.0 
 * Create at: 2017年9月12日 下午7:20:59
 * Modification History: 
 * Date 		Author		 Version 	Description
 * ------------------------------------------------------------------
 * 2017-09-12 	吴有根 		  2.0      2.0 Version
 * 2017-09-14   夏晨琳                              2.0      统计各直属局每年，每月，每周，每天的报检单数量
 * 
 * 
 */

@Controller
@RequestMapping(value = "/declNoCount")
public class DeclNoCountController extends MobileExceptionHandlerController {

	@Autowired
	DeclNoCountService service;
	@Autowired
	CompanyCodeUtils CompanyCodeUtils;
	@Autowired
	SysOrganizeService sysOrganizeService;
	/**
	 * <p>
	 * 描述:更新报检单统计的信息
	 * </p>
	 * @param declNo   报检单号
	 * @param orgCode  机构代码
	 * @param deptCode 部门代码
	 * @param date     操作时间
	 * @return
	 * @author 夏晨琳
	 */
	@RequestMapping(value="/updateCount",method=RequestMethod.POST)
	@ResponseBody
	public boolean updateCount(String orgCode, String deptCode, Date date) {
		//DataModel base = MobileHelper.getBaseModel();
		DclProcessCountEntity dclProcess = new DclProcessCountEntity();
		dclProcess.setProcessCalendarId(UUIDKeyGeneratorUils.newInstance().generateKey());
		dclProcess.setDeptCode(deptCode);
		dclProcess.setOrgCode(orgCode);
		dclProcess.setOperDate(new Timestamp(date.getTime()));
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);// 获取年份
		int month = cal.get(Calendar.MONTH) + 1;// 获取月份
		int day = cal.get(Calendar.DATE);// 获取日
		int hour = cal.get(Calendar.HOUR_OF_DAY);// 小时
		if(hour == 0){
			hour = 24;
		}
		int WeekOfYear = cal.get(Calendar.DAY_OF_WEEK) - 1;
		// 判断数据库中是否有这一年
		DclProcessCountEntity dcl = service.dclProcessIsExit(deptCode, year);
		boolean  sucess = false;
		if(dcl == null){
			dclProcess.setYear(year+"");
			service.saveDclProcess(dclProcess);
			dcl = service.dclProcessIsExit(deptCode, year);
		}
		if (dcl != null) {// 有这一年就在原来基础上进行加1
			String[] monthArr = { "MONTH_JAN", "MONTH_FEB", "MONTH_MAR", "MONTH_APR", "MONTH_MAY", "MONTH_JUN", "MONTH_JUL", "MONTH_AUG", "MONTH_SEP", "MONTH_OCT", "MONTH_NOV", "MONTH_DEC" };
			String[] weekArr = { "WEEK_SUN","WEEK_MON", "WEEK_TUES", "WEEK_WED", "WEEK_THUR", "WEEK_FRI", "WEEK_SAT"};
			String[] hourArr = { "HOUR_ONE", "HOUR_TWO", "HOUR_THREE", "HOUR_FOUR", "HOUR_FIVE", "HOUR_SIX", "HOUR_SEVEN", "HOUR_EIGHT", "HOUR_NINE", "HOUR_TEN", "HOUR_ELEVEN", "HOUR_TWELVE",
					"HOUR_THIRTEEN", "HOUR_FORTEEN", "HOUR_FIFTEEN", "HOUR_SIXTEEN", "HOUR_SEVENTEEN", "HOUR_EIGHTEEN", "HOUR_NINETEEN", "HOUR_TWENTY", "HOUR_TWENTY_ONE", "HOUR_TWENTY_TWO", "HOUR_TWENTY_THREE", "HOUR_TWENTY_FOUR" };
			String monthName = monthArr[month - 1 ];
			String weekName = weekArr[WeekOfYear];
			String hourName = hourArr[hour - 1];
			Calendar cal1 = Calendar.getInstance();
			cal1.setTime(dcl.getOperDate());
			boolean isSameWeek = cal.get(Calendar.WEEK_OF_YEAR)==cal1.get(Calendar.WEEK_OF_YEAR);
		    int operDate = cal1.get(Calendar.DATE);
		    boolean isSameDay = day == operDate;
			sucess = service.updateDclProcess(dcl,monthName,weekName,hourName,isSameWeek,isSameDay);
		} 
		return sucess;
	}
	

	/**
	 * <p>
	 * 包括每年、每月、本周、每天直属局统计单子的信息
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 */
	@RequestMapping(value = "/getCount", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getCount(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String orgCode = request.getParameter("orgCode");
		String deptCode = request.getParameter("deptCode");
		String year = request.getParameter("year");
		if (orgCode == null || StringUtils.isEmpty(orgCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		boolean isAll = false;
		if(Utils.isEmpty(deptCode)){
			isAll = true;
			orgCode = CompanyCodeUtils.getLevelOrgCode(orgCode);
		}
		if (orgCode == null || StringUtils.isEmpty(orgCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		//  orgCode = CompanyCodeUtils.getLevelOrgCode(orgCode);
		String orgNameSc = "";
		if(isAll){
			SysOrganize or = sysOrganizeService.getOrganize(orgCode);
			if(or!=null){
				orgNameSc =	or.getOrgNameSc();
			}
		}else{
			SysOrganize or = sysOrganizeService.getOrganize(deptCode);
			if(or!=null){
				orgNameSc =	or.getOrgNameSc();
			}
		}
		if(StringUtils.isEmpty(year)){
			Calendar cal = Calendar.getInstance();
			year = cal.get(Calendar.YEAR)+"";// 获取年份
		}
		List<String> weekCount = new ArrayList<String>();
		List<String> monthCount = new ArrayList<String>();
		List<String> hourCount = new ArrayList<String>();
		//
			List<DclProcessCountEntity> dclist = service.getdclistByDeptCode(orgCode,Integer.parseInt(year),deptCode,isAll);
			if(dclist == null || Utils.isEmpty(dclist)){
				DclProcessCountModel model = new DclProcessCountModel();
				model.setYearCount("0");
				model.setMonthCount(monthCount);
				model.setWeekCount(weekCount);
				model.setHourCount(hourCount);
				model.setOrgNameSc(orgNameSc);
				base.setCode(200);
				base.setData(model);
				return base;
			}
			for (DclProcessCountEntity dcl : dclist) {
				//判断是否是新的一天
				Calendar cal1 = Calendar.getInstance();
				cal1.setTime(dcl.getOperDate());
				int operDay = cal1.get(Calendar.DATE);// 获取日
				Calendar cal = Calendar.getInstance();
				int nowDay = cal.get(Calendar.DATE);
				if(operDay != nowDay){
					service.updateDay(dcl);
				}
				boolean isSameWeek = cal.get(Calendar.WEEK_OF_YEAR)==cal1.get(Calendar.WEEK_OF_YEAR);
				if(!isSameWeek){
					service.updateWeek(dcl);
				} 
			}
			dclist = service.getdclistByDeptCode(orgCode,Integer.parseInt(year),deptCode,isAll);
			DclProcessCountEntity dcl = dclist.get(0);
			monthCount.add(0, dcl.getMonthJan()==null?"0":dcl.getMonthJan());
			monthCount.add(1, dcl.getMonthFeb()==null?"0":dcl.getMonthFeb());
			monthCount.add(2, dcl.getMonthMar()==null?"0":dcl.getMonthMar());
			monthCount.add(3, dcl.getMonthApr()==null?"0":dcl.getMonthApr());
			monthCount.add(4, dcl.getMonthMay()==null?"0":dcl.getMonthMay());
			monthCount.add(5, dcl.getMonthJun()==null?"0":dcl.getMonthJun());
			monthCount.add(6, dcl.getMonthJul()==null?"0":dcl.getMonthJul());
			monthCount.add(7, dcl.getMonthAug()==null?"0":dcl.getMonthAug());
			monthCount.add(8, dcl.getMonthSep()==null?"0":dcl.getMonthSep());
			monthCount.add(9, dcl.getMonthOct()==null?"0":dcl.getMonthOct());
			monthCount.add(10, dcl.getMonthNov()==null?"0":dcl.getMonthNov());
			monthCount.add(11, dcl.getMonthDec()==null?"0":dcl.getMonthDec());
			weekCount.add(0, dcl.getWeekMon()==null?"0":dcl.getWeekMon());
			weekCount.add(1, dcl.getWeekTues()==null?"0":dcl.getWeekTues());
			weekCount.add(2, dcl.getWeekWed()==null?"0":dcl.getWeekWed());
			weekCount.add(3, dcl.getWeekThur()==null?"0":dcl.getWeekThur());
			weekCount.add(4, dcl.getWeekFri()==null?"0":dcl.getWeekFri());
			weekCount.add(5, dcl.getWeekSat()==null?"0":dcl.getWeekSat());
			weekCount.add(6, dcl.getWeekSun()==null?"0":dcl.getWeekSun());
			hourCount.add(0,dcl.getHourOne()==null?"0":dcl.getHourOne());
			hourCount.add(1,dcl.getHourTwo()==null?"0":dcl.getHourTwo());
			hourCount.add(2,dcl.getHourThree()==null?"0":dcl.getHourThree());
			hourCount.add(3,dcl.getHourFour()==null?"0":dcl.getHourFour());
			hourCount.add(4,dcl.getHourFive()==null?"0":dcl.getHourFive());
			hourCount.add(5,dcl.getHourSix()==null?"0":dcl.getHourSix());
			hourCount.add(6,dcl.getHourSeven()==null?"0":dcl.getHourSeven());
			hourCount.add(7,dcl.getHourEight()==null?"0":dcl.getHourEight());
			hourCount.add(8,dcl.getHourNine()==null?"0":dcl.getHourNine());
			hourCount.add(9,dcl.getHourTen()==null?"0":dcl.getHourTen());
			hourCount.add(10,dcl.getHourEleven()==null?"0":dcl.getHourEleven());
			hourCount.add(11,dcl.getHourTwelve()==null?"0":dcl.getHourTwelve());
			hourCount.add(12,dcl.getHourThirteen()==null?"0":dcl.getHourThirteen());
			hourCount.add(13,dcl.getHourForteen()==null?"0":dcl.getHourForteen());
			hourCount.add(14,dcl.getHourFifteen()==null?"0":dcl.getHourFifteen());
			hourCount.add(15,dcl.getHourSixteen()==null?"0":dcl.getHourSixteen());
			hourCount.add(16,dcl.getHourSeventeen()==null?"0":dcl.getHourSeventeen());
			hourCount.add(17,dcl.getHourEighteen()==null?"0":dcl.getHourEighteen());
			hourCount.add(18,dcl.getHourNineteen()==null?"0":dcl.getHourNineteen());
			hourCount.add(19,dcl.getHourTwenty()==null?"0":dcl.getHourTwenty());
			hourCount.add(20,dcl.getHourTwentyOne()==null?"0":dcl.getHourTwentyOne());
			hourCount.add(21,dcl.getHourTwentyTwo()==null?"0":dcl.getHourTwentyTwo());
			hourCount.add(22,dcl.getHourTwentyThree()==null?"0":dcl.getHourTwentyThree());
			hourCount.add(23,dcl.getHourTwentyFour()==null?"0":dcl.getHourTwentyFour());
			if(dclist.size()>0){
				boolean boo=true;
				for (DclProcessCountEntity dcl1 : dclist) {
					if (boo) {
						boo=false;
						continue;
					}
					monthCount.set(0, (Integer.parseInt(dcl1.getMonthJan()==null?"0":dcl1.getMonthJan())+Integer.parseInt(monthCount.get(0)))+"");
					monthCount.set(1, (Integer.parseInt(dcl1.getMonthFeb()==null?"0":dcl1.getMonthFeb())+Integer.parseInt(monthCount.get(1)))+"");
					monthCount.set(2, (Integer.parseInt(dcl1.getMonthMar()==null?"0":dcl1.getMonthMar())+Integer.parseInt(monthCount.get(2)))+"");
					monthCount.set(3,( Integer.parseInt(dcl1.getMonthApr()==null?"0":dcl1.getMonthApr())+Integer.parseInt(monthCount.get(3)))+"");
					monthCount.set(4, (Integer.parseInt(dcl1.getMonthMay()==null?"0":dcl1.getMonthMay())+Integer.parseInt(monthCount.get(4)))+"");
					monthCount.set(5, (Integer.parseInt(dcl1.getMonthJun()==null?"0":dcl1.getMonthJun())+Integer.parseInt(monthCount.get(5)))+"");
					monthCount.set(6, (Integer.parseInt(dcl1.getMonthJul()==null?"0":dcl1.getMonthJul())+Integer.parseInt(monthCount.get(6)))+"");
					monthCount.set(7,( Integer.parseInt(dcl1.getMonthAug()==null?"0":dcl1.getMonthAug())+Integer.parseInt(monthCount.get(7)))+"");
					monthCount.set(8, (Integer.parseInt(dcl1.getMonthSep()==null?"0":dcl1.getMonthSep())+Integer.parseInt(monthCount.get(8)))+"");
					monthCount.set(9,( Integer.parseInt(dcl1.getMonthOct()==null?"0":dcl1.getMonthOct())+Integer.parseInt(monthCount.get(9)))+"");
					monthCount.set(10,( Integer.parseInt(dcl1.getMonthNov()==null?"0":dcl1.getMonthNov())+Integer.parseInt(monthCount.get(10)))+"");
					monthCount.set(11, (Integer.parseInt(dcl1.getMonthDec()==null?"0":dcl1.getMonthDec())+Integer.parseInt(monthCount.get(11)))+"");
					weekCount.set(0, (Integer.parseInt(dcl1.getWeekMon()==null?"0":dcl1.getWeekMon())+Integer.parseInt(weekCount.get(0)))+"");
					weekCount.set(1, (Integer.parseInt(dcl1.getWeekTues()==null?"0":dcl1.getWeekTues())+Integer.parseInt(weekCount.get(1)))+"");
					weekCount.set(2, (Integer.parseInt(dcl1.getWeekWed()==null?"0":dcl1.getWeekWed())+Integer.parseInt(weekCount.get(2)))+"");
					weekCount.set(3, (Integer.parseInt(dcl1.getWeekThur()==null?"0":dcl1.getWeekThur())+Integer.parseInt(weekCount.get(3)))+"");
					weekCount.set(4, (Integer.parseInt(dcl1.getWeekFri()==null?"0":dcl1.getWeekFri())+Integer.parseInt(weekCount.get(4)))+"");
					weekCount.set(5, (Integer.parseInt(dcl1.getWeekSat()==null?"0":dcl1.getWeekSat())+Integer.parseInt(weekCount.get(5)))+"");
					weekCount.set(6, (Integer.parseInt(dcl1.getWeekSun()==null?"0":dcl1.getWeekSun())+Integer.parseInt(weekCount.get(6)))+"");
					hourCount.set(0,(Integer.parseInt(dcl1.getHourOne()==null?"0":dcl1.getHourOne())+Integer.parseInt(hourCount.get(0)))+"");
					hourCount.set(1,(Integer.parseInt(dcl1.getHourTwo()==null?"0":dcl1.getHourTwo())+Integer.parseInt(hourCount.get(1)))+"");
					hourCount.set(2,(Integer.parseInt(dcl1.getHourThree()==null?"0":dcl1.getHourThree())+Integer.parseInt(hourCount.get(2)))+"");
					hourCount.set(3,(Integer.parseInt(dcl1.getHourFour()==null?"0":dcl1.getHourFour())+Integer.parseInt(hourCount.get(3)))+"");
					hourCount.set(4,(Integer.parseInt(dcl1.getHourFive()==null?"0":dcl1.getHourFive())+Integer.parseInt(hourCount.get(4)))+"");
					hourCount.set(5,(Integer.parseInt(dcl1.getHourSix()==null?"0":dcl1.getHourSix())+Integer.parseInt(hourCount.get(5)))+"");
					hourCount.set(6,(Integer.parseInt(dcl1.getHourSeven()==null?"0":dcl1.getHourSeven())+Integer.parseInt(hourCount.get(6)))+"");
					hourCount.set(7,(Integer.parseInt(dcl1.getHourEight()==null?"0":dcl1.getHourEight())+Integer.parseInt(hourCount.get(7)))+"");
					hourCount.set(8,(Integer.parseInt(dcl1.getHourNine()==null?"0":dcl1.getHourNine())+Integer.parseInt(hourCount.get(8)))+"");
					hourCount.set(9,(Integer.parseInt(dcl1.getHourTen()==null?"0":dcl1.getHourTen())+Integer.parseInt(hourCount.get(9)))+"");
					hourCount.set(10,(Integer.parseInt(dcl1.getHourEleven()==null?"0":dcl1.getHourEleven())+Integer.parseInt(hourCount.get(10)))+"");
					hourCount.set(11,(Integer.parseInt(dcl1.getHourTwelve()==null?"0":dcl1.getHourTwelve())+Integer.parseInt(hourCount.get(11)))+"");
					hourCount.set(12,(Integer.parseInt(dcl1.getHourThirteen()==null?"0":dcl1.getHourThirteen())+Integer.parseInt(hourCount.get(12)))+"");
					hourCount.set(13,(Integer.parseInt(dcl1.getHourForteen()==null?"0":dcl1.getHourForteen())+Integer.parseInt(hourCount.get(13)))+"");
					hourCount.set(14,(Integer.parseInt(dcl1.getHourFifteen()==null?"0":dcl1.getHourFifteen())+Integer.parseInt(hourCount.get(14)))+"");
					hourCount.set(15,(Integer.parseInt(dcl1.getHourSixteen()==null?"0":dcl1.getHourSixteen())+Integer.parseInt(hourCount.get(15)))+"");
					hourCount.set(16,(Integer.parseInt(dcl1.getHourSeventeen()==null?"0":dcl1.getHourSeventeen())+Integer.parseInt(hourCount.get(16)))+"");
					hourCount.set(17,(Integer.parseInt(dcl1.getHourEighteen()==null?"0":dcl1.getHourEighteen())+Integer.parseInt(hourCount.get(17)))+"");
					hourCount.set(18,(Integer.parseInt(dcl1.getHourNineteen()==null?"0":dcl1.getHourNineteen())+Integer.parseInt(hourCount.get(18)))+"");
					hourCount.set(19,(Integer.parseInt(dcl1.getHourTwenty()==null?"0":dcl1.getHourTwenty())+Integer.parseInt(hourCount.get(19)))+"");
					hourCount.set(20,(Integer.parseInt(dcl1.getHourTwentyOne()==null?"0":dcl1.getHourTwentyOne())+Integer.parseInt(hourCount.get(20)))+"");
					hourCount.set(21,(Integer.parseInt(dcl1.getHourTwentyTwo()==null?"0":dcl1.getHourTwentyTwo())+Integer.parseInt(hourCount.get(21)))+"");
					hourCount.set(22,(Integer.parseInt(dcl1.getHourTwentyThree()==null?"0":dcl1.getHourTwentyThree())+Integer.parseInt(hourCount.get(22)))+"");
					hourCount.set(23,(Integer.parseInt(dcl1.getHourTwentyFour()==null?"0":dcl1.getHourTwentyFour())+Integer.parseInt(hourCount.get(23)))+"");
				}
			}
		/*DclProcessCountEntity dcl = service.dclProcessIsExit(orgCode,Integer.parseInt(year));
		if(dcl == null){
			DclProcessCountModel model = new DclProcessCountModel();
			model.setYearCount("0");
			model.setMonthCount(monthCount);
			model.setWeekCount(weekCount);
			model.setHourCount(hourCount);
			model.setOrgNameSc(orgNameSc);
			base.setCode(200);
			base.setData(model);
			return base;
		}
		//判断是否是新的一天
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(dcl.getOperDate());
		int operDay = cal1.get(Calendar.DATE);// 获取日
		Calendar cal = Calendar.getInstance();
		int nowDay = cal.get(Calendar.DATE);
		boolean re = false;
		if(operDay != nowDay){
			service.updateDay(dcl);
			re=true;
		}
		boolean isSameWeek = cal.get(Calendar.WEEK_OF_YEAR)==cal1.get(Calendar.WEEK_OF_YEAR);
		if(!isSameWeek){
			service.updateWeek(dcl);
			re = true;
		} 
		if (re) {
			dcl = service.dclProcessIsExit(orgCode,Integer.parseInt(year));
		}
		if(dcl!=null){
		monthCount.add(0, dcl.getMonthJan()==null?"0":dcl.getMonthJan());
		monthCount.add(1, dcl.getMonthFeb()==null?"0":dcl.getMonthFeb());
		monthCount.add(2, dcl.getMonthMar()==null?"0":dcl.getMonthMar());
		monthCount.add(3, dcl.getMonthApr()==null?"0":dcl.getMonthApr());
		monthCount.add(4, dcl.getMonthMay()==null?"0":dcl.getMonthMay());
		monthCount.add(5, dcl.getMonthJun()==null?"0":dcl.getMonthJun());
		monthCount.add(6, dcl.getMonthJul()==null?"0":dcl.getMonthJul());
		monthCount.add(7, dcl.getMonthAug()==null?"0":dcl.getMonthAug());
		monthCount.add(8, dcl.getMonthSep()==null?"0":dcl.getMonthSep());
		monthCount.add(9, dcl.getMonthOct()==null?"0":dcl.getMonthOct());
		monthCount.add(10, dcl.getMonthNov()==null?"0":dcl.getMonthNov());
		monthCount.add(11, dcl.getMonthDec()==null?"0":dcl.getMonthDec());
		weekCount.add(0, dcl.getWeekMon()==null?"0":dcl.getWeekMon());
		weekCount.add(1, dcl.getWeekTues()==null?"0":dcl.getWeekTues());
		weekCount.add(2, dcl.getWeekWed()==null?"0":dcl.getWeekWed());
		weekCount.add(3, dcl.getWeekThur()==null?"0":dcl.getWeekThur());
		weekCount.add(4, dcl.getWeekFri()==null?"0":dcl.getWeekFri());
		weekCount.add(5, dcl.getWeekSat()==null?"0":dcl.getWeekSat());
		weekCount.add(6, dcl.getWeekSun()==null?"0":dcl.getWeekSun());
		hourCount.add(0,dcl.getHourOne()==null?"0":dcl.getHourOne());
		hourCount.add(1,dcl.getHourTwo()==null?"0":dcl.getHourTwo());
		hourCount.add(2,dcl.getHourThree()==null?"0":dcl.getHourThree());
		hourCount.add(3,dcl.getHourFour()==null?"0":dcl.getHourFour());
		hourCount.add(4,dcl.getHourFive()==null?"0":dcl.getHourFive());
		hourCount.add(5,dcl.getHourSix()==null?"0":dcl.getHourSix());
		hourCount.add(6,dcl.getHourSeven()==null?"0":dcl.getHourSix());
		hourCount.add(7,dcl.getHourEight()==null?"0":dcl.getHourEight());
		hourCount.add(8,dcl.getHourNine()==null?"0":dcl.getHourNine());
		hourCount.add(9,dcl.getHourTen()==null?"0":dcl.getHourTen());
		hourCount.add(10,dcl.getHourEleven()==null?"0":dcl.getHourEleven());
		hourCount.add(11,dcl.getHourTwelve()==null?"0":dcl.getHourTwelve());
		hourCount.add(12,dcl.getHourThirteen()==null?"0":dcl.getHourThirteen());
		hourCount.add(13,dcl.getHourForteen()==null?"0":dcl.getHourForteen());
		hourCount.add(14,dcl.getHourFifteen()==null?"0":dcl.getHourFifteen());
		hourCount.add(15,dcl.getHourSixteen()==null?"0":dcl.getHourSixteen());
		hourCount.add(16,dcl.getHourSeventeen()==null?"0":dcl.getHourSeventeen());
		hourCount.add(17,dcl.getHourEighteen()==null?"0":dcl.getHourEighteen());
		hourCount.add(18,dcl.getHourNineteen()==null?"0":dcl.getHourNineteen());
		hourCount.add(19,dcl.getHourTwenty()==null?"0":dcl.getHourTwenty());
		hourCount.add(20,dcl.getHourTwentyOne()==null?"0":dcl.getHourTwentyOne());
		hourCount.add(21,dcl.getHourTwentyTwo()==null?"0":dcl.getHourTwentyTwo());
		hourCount.add(22,dcl.getHourTwentyThree()==null?"0":dcl.getHourTwentyThree());
		hourCount.add(23,dcl.getHourTwentyFour()==null?"0":dcl.getHourTwentyFour());
		}*/
		DclProcessCountModel model = new DclProcessCountModel();
		Integer yearCount = 0;
		for (String mon : monthCount) {
			if("0".equals(mon)){
				continue;
			}
			yearCount += Integer.parseInt(mon);
		}
		model.setYearCount(yearCount+"");
		model.setMonthCount(monthCount);
		model.setWeekCount(weekCount);
		model.setHourCount(hourCount);
		model.setOrgNameSc(orgNameSc);
		base.setCode(200);
		base.setData(model);
		return base;
	}
	
	/**
	 * <p>
	 * 包括每年、每月、本周、每天直属局统计单子的信息
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author  夏晨琳
	 */
	@RequestMapping(value = "/getCount2", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getCount2(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		String deptCode = request.getParameter("orgCode");//部门编号
		if (deptCode == null || StringUtils.isEmpty(deptCode)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String day = request.getParameter("day");
		Calendar cal = Calendar.getInstance();
		//cal.set(cal.WEEK_OF_YEAR, 44);
		//cal.add(Calendar.DAY_OF_WEEK, 6);
		if(Utils.isEmpty(year)){
		  year = cal.get(Calendar.YEAR)+"";//默认今年
		}
		if(Utils.isEmpty(month)){
		  int mon = cal.get(Calendar.MONTH) + 1;//默认本月
		  if(mon<10){
			  month = "0"+mon;
		  }else{
			  month = mon +"";
		  }
		}
		if(Utils.isEmpty(day)){
			  int  d  = cal.get(Calendar.DATE);//默认今天
			  if(d<10){
				  day = "0"+d;
			  }else{
				  day = d +"";
			  }
		}
		String weekOfYear = request.getParameter("weekOfYear");
		if(Utils.isEmpty(weekOfYear)){
			weekOfYear = cal.get(cal.WEEK_OF_YEAR)+"";
		}

		Calendar cale = Calendar.getInstance();
		cale.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		cale.set(Calendar.YEAR, Integer.valueOf(year));
		cale.set(Calendar.WEEK_OF_YEAR,Integer.valueOf(weekOfYear));  
        int beginyear = cale.get(Calendar.YEAR);
        int beginmonth = cale.get(Calendar.MONTH) + 1;  
        int beginday  =  cale.get(Calendar.DAY_OF_MONTH);   
        cale.add(Calendar.DAY_OF_WEEK, 6);
        int endyear = cale.get(Calendar.YEAR);
        int endmonth = cale.get(Calendar.MONTH) + 1;  
        int endday  =  cale.get(Calendar.DAY_OF_MONTH);
		//int dayOfMonth = cal.get(cal.DAY_OF_MONTH);
		/*int firstDayOfWeek = day + 1 - cal.get(Calendar.DAY_OF_WEEK) +1;//本周开始
		int lastDayOfWeek  = day + 7 - cal.get(Calendar.DAY_OF_WEEK) +1;//本周结束
		*/		
		
		List<String[]> monthList = service.getDclOperDateCount(deptCode,year);//查询每月
		List<String[]> dayList   = service.getDclDayCountCount(deptCode,year,month,day);//查询今天
		//List<String[]> weekList  = service.getWeekDateCount(deptCode,year,month,firstDayOfWeek,lastDayOfWeek);
		base.setCode(200);
		base.setData(dayList);
		return base;
	}
	
	/**
	 * <p>
	 * 包括每个直属局每年的单子数量
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author 夏晨琳
	 */
	@RequestMapping(value = "/getOrgCount", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getOrgCount(String year) {
		DataModel base = MobileHelper.getBaseModel();
		if(StringUtils.isEmpty(year)){
			Calendar cal = Calendar.getInstance();
			year = cal.get(Calendar.YEAR)+"";// 获取年份
		}
		List<DclProcessCountEntity> list = service.getNowYearCount(year);
		Map<String,String> map = new HashMap<String, String>();
		for (DclProcessCountEntity dcl : list) {
			int yearCount = 0;
			List<String> monthCount = new ArrayList<String>() ;
			monthCount.add(0, dcl.getMonthJan()==null?"0":dcl.getMonthJan());
			monthCount.add(1, dcl.getMonthFeb()==null?"0":dcl.getMonthFeb());
			monthCount.add(2, dcl.getMonthMar()==null?"0":dcl.getMonthMar());
			monthCount.add(3, dcl.getMonthApr()==null?"0":dcl.getMonthApr());
			monthCount.add(4, dcl.getMonthMay()==null?"0":dcl.getMonthMay());
			monthCount.add(5, dcl.getMonthJun()==null?"0":dcl.getMonthJun());
			monthCount.add(6, dcl.getMonthJul()==null?"0":dcl.getMonthJul());
			monthCount.add(7, dcl.getMonthAug()==null?"0":dcl.getMonthAug());
			monthCount.add(8, dcl.getMonthSep()==null?"0":dcl.getMonthSep());
			monthCount.add(9, dcl.getMonthOct()==null?"0":dcl.getMonthOct());
			monthCount.add(10, dcl.getMonthNov()==null?"0":dcl.getMonthNov());
			monthCount.add(11, dcl.getMonthDec()==null?"0":dcl.getMonthDec());
			for (String mon : monthCount) {
				if("0".equals(mon)){
					continue;
				}
				yearCount += Integer.parseInt(mon);
			}
			map.put(dcl.getOrgCode(),yearCount+"");
		}
		base.setCode(200);
		base.setData(map);
		return base;
	}
	
	/**
	 * <p>
	 *获取直属局某个月份执行的报检单
	 * </p>
	 * @param request
	 * @param response
	 * @return
	 * @author 夏晨琳
	 */
	@RequestMapping(value = "/getDeptList", method = RequestMethod.GET)
	@ResponseBody
	public DataModel getDeptList(HttpServletRequest request, HttpServletResponse response) {
		DataModel base = MobileHelper.getBaseModel();
		Calendar now=Calendar.getInstance();
		int today = now.get(Calendar.DAY_OF_WEEK);
		int first_day_of_week = now.get(Calendar.DATE) + 1 - today+1;
		//int last_day_of_week = now.get(Calendar.DATE) + 7 - today+1;
		String orgCode = request.getParameter("orgCode");
		String deptCode = request.getParameter("deptCode");
		String year = now.get(Calendar.YEAR)+"";// 获取年份
		String month = request.getParameter("month");//月份传值需要两位数，09，12
		String day = request.getParameter("day");
		if (day!=null && Utils.notEmpty(day)) {
			month = (now.get(Calendar.MONTH) + 1)+"";// 获取月份
		}
		String hour = request.getParameter("hour");
		if (hour!=null && Utils.notEmpty(hour)) {
			month = (now.get(Calendar.MONTH) + 1)+"";// 获取月份
		}
		if (month!=null && Utils.notEmpty(month)) {
			int mon = Integer.parseInt(month);
			if(mon < 10){
				month = "0"+mon;
			}
		}
		if (day!=null && Utils.notEmpty(day)) {
			int d = (first_day_of_week + Integer.parseInt(day) - 1);
			if(d<10){
				day = "0"+d;
			}else{
				day = d +"";
			}
		}
		if (hour!=null && Utils.notEmpty(hour)) {
			day = now.get(Calendar.DATE)+"";// 获取日
			int hou = Integer.parseInt(hour);
			if(hou < 10){
				hour = "0" + hou;
			}
		}
		String cp = request.getParameter("currentPage");
		if ( StringUtils.isEmpty(cp) || StringUtils.isEmpty(orgCode) || StringUtils.isEmpty(month) || StringUtils.isEmpty(year) ) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		boolean isAll = false;
		if(Utils.isEmpty(deptCode)){
			isAll = true;
			orgCode = CompanyCodeUtils.getLevelOrgCode(orgCode);
		}
		Page page = MobileHelper.getPage(cp);
		page.setPageSize(20);
		List<DclProcessStatsEntity> declList = service.getDeclNoList(orgCode,month,year,page,hour,day,deptCode,isAll);
		List<DclProcessStatsModel> list = new ArrayList<DclProcessStatsModel>();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for (DclProcessStatsEntity dcl : declList) {
			DclProcessStatsModel model = new DclProcessStatsModel();
			model.setDeclNo(dcl.getDeclNo());
			model.setOperDate(format.format(dcl.getOperDate()));
			list.add(model);
		}
		base.setCode(200);
		base.setData(list);
		return base;
	}


	/**
	* <p>描述:对重复的单子更新记录值</p>
	* @param orgCode
	* @param operDate
	* @author 夏晨琳
	*/
	@RequestMapping(value = "/updateCountForReDeclNo", method = RequestMethod.POST)
	@ResponseBody
	public void updateCountForReDeclNo(String orgCode, Timestamp operDate) {
		Calendar before=Calendar.getInstance();
		before.setTime(operDate);
		int year = before.get(Calendar.YEAR);// 获取年份
		DclProcessCountEntity dcl = service.dclProcessIsExit(orgCode, year);
		if(dcl == null){
			return ;
		}
		int month = before.get(Calendar.MONTH) + 1;// 获取月份
		int day = before.get(Calendar.DATE);// 获取日
		int hour = before.get(Calendar.HOUR_OF_DAY);// 小时
		Calendar now=Calendar.getInstance();
		now.setTime(dcl.getOperDate());
		int nowDay = now.get(Calendar.DATE);// 获取日
		//判断是否是同一周，是：对应减一
		boolean isSameWeek = before.get(Calendar.WEEK_OF_YEAR)==now.get(Calendar.WEEK_OF_YEAR);
		int dayOfWeek = before.get(Calendar.DAY_OF_WEEK)-1;
		//判断是否是同一天，是的话：对应小时减一
		boolean isSameDay = day == nowDay;
		String[] monthArr = { "MONTH_JAN", "MONTH_FEB", "MONTH_MAR", "MONTH_APR", "MONTH_MAY", "MONTH_JUN", "MONTH_JUL", "MONTH_AUG", "MONTH_SEP", "MONTH_OCT", "MONTH_NOV", "MONTH_DEC" };
		String[] weekArr = { "WEEK_SUN","WEEK_MON", "WEEK_TUES", "WEEK_WED", "WEEK_THUR", "WEEK_FRI", "WEEK_SAT"};
		String[] hourArr = { "HOUR_ONE", "HOUR_TWO", "HOUR_THREE", "HOUR_FOUR", "HOUR_FIVE", "HOUR_SIX", "HOUR_SEVEN", "HOUR_EIGHT", "HOUR_NINE", "HOUR_TEN", "HOUR_ELEVEN", "HOUR_TWELVE",
				"HOUR_THIRTEEN", "HOUR_FORTEEN", "HOUR_FIFTEEN", "HOUR_SIXTEEN", "HOUR_SEVENTEEN", "HOUR_EIGHTEEN", "HOUR_NINETEEN", "HOUR_TWENTY", "HOUR_TWENTY_ONE", "HOUR_TWENTY_TWO", "HOUR_TWENTY_THREE", "HOUR_TWENTY_FOUR" };
		if(hour == 0){
			hour = 24;
		}
		String monthName = monthArr[month - 1 ];
		String weekName = weekArr[dayOfWeek];
		String hourName = hourArr[hour - 1];
		service.updateCountForReDeclNo(orgCode,year,monthName,isSameWeek,weekName,isSameDay,hourName);
	}
}

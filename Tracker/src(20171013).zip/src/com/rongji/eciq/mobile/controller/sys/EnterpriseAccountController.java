/**  
 * FileName: EnterpriseAccountController.java    
 * @Description: 企业用户登录&注册Controller
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月18日 上午9:41:38  
 *  
 */  

package com.rongji.eciq.mobile.controller.sys;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.EnterpriseModel;
import com.rongji.eciq.mobile.service.sys.EnterpriseAccountService;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description: 企业用户登录&注册Controller  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月18日 上午9:41:38  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月18日      吴有根                      1.0         1.0 Version  
 */
@Controller
@RequestMapping(value="/enterprise")
public class EnterpriseAccountController extends MobileExceptionHandlerController {

	@Autowired
	EnterpriseAccountService service;
	
	/**
	 * 
	* <p>描述:企业用户注册</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/register",method=RequestMethod.POST)
	@ResponseBody
	public DataModel register(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String entOrgCode=request.getParameter("entOrgCode");//企业组织机构代码
		String entPWD=request.getParameter("entPWD");//企业登录密码
		if(StringUtils.isEmpty(entOrgCode)||StringUtils.isEmpty(entPWD)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		
		String msg=service.registerInfo(entOrgCode,entPWD);
		if(StringUtils.isNotEmpty(msg)){
			base.setMsg(msg);
			return base;
		}
		base.setMsg("注册成功！请切换登录");
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:企业用户登录</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="/login",method=RequestMethod.POST)
	@ResponseBody
	public DataModel login(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String entOrgCode=request.getParameter("entOrgCode");//企业组织机构代码
		String entPWD=request.getParameter("entPWD");//企业登录密码
		if(StringUtils.isEmpty(entOrgCode)||StringUtils.isEmpty(entPWD)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		
		Map<String,Object> map=service.loginInfo(entOrgCode, entPWD);
		EnterpriseModel model=new EnterpriseModel();
		if(!(Boolean) map.get("flag")){
			base.setMsg((String) map.get("data"));
			return base;
		}
		base.setMsg("登录成功");
		try {
			BeanPropertyUtils.getInstance().copyPropertiesBean(model, (EntBaseInfoEntity)(map.get("data")));
		} catch (Throwable e) {
			e.printStackTrace();
		}
		model.setId(model.getEntOrgCode());
		model.setHexCode(MobileHelper.getMD5(model.getEntOrgCode()));
		model.setLogin(true);
		base.setData(model);
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:企业用户信息修改</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 */
	@RequestMapping(value="modify",method=RequestMethod.POST)
	@ResponseBody
	public DataModel modify(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String info=Utils.getParameter(request,"EntBaseInfoEntity");
		Gson gson=new GsonBuilder().create();
		EntBaseInfoEntity entity=gson.fromJson(info, EntBaseInfoEntity.class);
		if(entity==null){
			base.setMsg("不存在操作对象");
			return base;
		}
		
		String msg=service.saveObject(entity);
		if(StringUtils.isNotEmpty(msg)){
			base.setMsg(msg);
			return base;
		}
		base.setMsg("操作成功");
		return base;
	}
}

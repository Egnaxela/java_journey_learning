/**  
 * FileName: FileUpAndLoadController.java    
 * @Description: 通用文件上传&下载至nginx文件服务器
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月19日 下午4:45:47  
 *  
 */  

package com.rongji.eciq.mobile.controller.sys;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description: 通用文件上传&下载至nginx文件服务器  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月19日 下午4:45:47  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月19日      吴有根                      1.0         1.0 Version  
 */

@Controller
@RequestMapping("/file")
public class FileUpAndLoadController {
	
	
	@RequestMapping(value="/upload/{reqWith}/{userCode}/{hexCode}/{declNo}",method=RequestMethod.POST)
	@ResponseBody
	public DataModel upload(HttpServletRequest request, @PathVariable("reqWith") String reqWith, @PathVariable("userCode") String userCode, @PathVariable("hexCode") String hexCode,@PathVariable("declNo") String declNo) {

		DataModel base=MobileHelper.getBaseModel();
		if (request.getHeader("content-type") != null
				&& "application/x-www-form-urlencoded".equals(request.getHeader("content-type"))) {
			return null;// 不支持断点续传，直接返回null即可
		}
		// 将请求转换成能用于文件处理的
		MultipartHttpServletRequest mRequest = (MultipartHttpServletRequest) request;
		Iterator<String> fnames=mRequest.getFileNames();//获取上传的文件列表
		while(fnames.hasNext()) {
			String s=fnames.next();
			MultipartFile mFile=mRequest.getFile(s);
			if(mFile.isEmpty()) {
				
			}else {
				String basePath=request.getSession().getServletContext().getRealPath("/upload");
				DateFormat format=new SimpleDateFormat("yyyyMMdd");
				Date date=new Date();
				String dateString =format.format(date);
				String dPath="/"+declNo+"/"+userCode+"/"+dateString;
				String originFileName=mFile.getOriginalFilename();
			}
			
			
			
		}
		
		String basePath=request.getSession().getServletContext().getRealPath("/upload");
		
		
		return base;
		
	} 

	

}

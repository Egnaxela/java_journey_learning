/**  
 * FileName: HomePageInfoController.java    
 * @Description: 首页待办信息
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月19日 下午3:51:15  
 *  
 */  

package com.rongji.eciq.mobile.controller.sys;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DfishException;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.platform.license.service.LicenseLocalMethods;
import com.rongji.dfish.platform.license.service.LicenseTools;
import com.rongji.dfish.platform.license.service.impl.LicenseJsonType;
import com.rongji.eciq.mobile.entity.SysAnnInfoMainEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.HomePageModel;
import com.rongji.eciq.mobile.model.sys.PortalNoticeModel;
import com.rongji.eciq.mobile.model.sys.SysHomePageTodoModel;
import com.rongji.eciq.mobile.service.sys.HomePageInfoService;
import com.rongji.eciq.mobile.service.sys.PortalNoticeService;
import com.rongji.eciq.mobile.utils.MobileHelper;


/**  
 * Description: 首页待办信息  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月19日 下午3:51:15  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-19      吴有根                      1.0         1.0 Version
 * 2017-05-22      李晨阳                      1.0         添加公告信息查询，合并两个model一起传回移动端 
 * 2017-06-07      才江男                      1.0         证书过期
 * 2017-08-30      才江男                      1.0         查询报检单回写记录信息 
 */

@Controller
@RequestMapping("/sys/homepage")
public class HomePageInfoController {
	private static final Logger log=Logger.getLogger(HomePageInfoController.class);
	
	@Autowired
	private HomePageInfoService service;
	@Autowired
	private PortalNoticeService portalNoticeService;
	/**
	 * 
	* <p>描述:首页待办事项展示</p>
	* @param request
	* @param response
	* @return
	* @author 吴有根
	 * @throws DfishException 
	 */
	@RequestMapping(value="/todo",method=RequestMethod.GET)
	@ResponseBody
	@Cacheable(value="model")
	public DataModel homePagetodo(HttpServletRequest request,HttpServletResponse response) throws DfishException{
		DataModel base=MobileHelper.getBaseModel();
		HomePageModel hpModel = new HomePageModel();
		
		String userCode=request.getParameter("userCode");//用户代码
		String userOrgCode=request.getParameter("userOrgCode");//用户机构
		String annTitle = request.getParameter("annTitle");
		String currentPage = request.getParameter("currentPage");
		String privileges=Utils.getParameter(request, "privileges");//用户权限
		if(StringUtils.isEmpty(userCode)||StringUtils.isEmpty(userOrgCode)||StringUtils.isEmpty(privileges)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			base.setData("");
			return base;
		}
		//SysHomePageTodoModel model=service.getCount(userCode,userOrgCode);
		long t1=System.currentTimeMillis();
//		SysHomePageTodoModel model=service.getCount2(userCode,userOrgCode,privileges);
		SysHomePageTodoModel model=service.getCount3(userCode,userOrgCode,privileges);
		log.info("query todo case "+(System.currentTimeMillis()-t1)+"ms");
		
		long t2=System.currentTimeMillis();
		List<PortalNoticeModel> pnList = new ArrayList<PortalNoticeModel>();
		PortalNoticeModel portalNoticeModel = new PortalNoticeModel();
		List<SysAnnInfoMainEntity> queryList=portalNoticeService.getPortalNotice(annTitle, currentPage);
		if(!CollectionUtils.isEmpty(queryList)){
			for(SysAnnInfoMainEntity entity :queryList){
				portalNoticeModel = new PortalNoticeModel();
				portalNoticeModel.setAnnTitle(entity.getAnnTitle());
				portalNoticeModel.setAnnContent(entity.getAnnContent());
				portalNoticeModel.setIsueOrgCode(entity.getIsueOrgCode());
				portalNoticeModel.setAnnIssDate(entity.getAnnIssDate());
				portalNoticeModel.setAnnIssuerCode(entity.getAnnIssuerCode());
				pnList.add(portalNoticeModel);
			}
		}
		log.info("pnList case "+(System.currentTimeMillis()-t2)+"ms");
		hpModel.setSysHomePageTodoModel(model);
		hpModel.setPortalNoticeModel(pnList);
		
		long t3=System.currentTimeMillis();
		//证书过期
		String spath = "license";
		String contextPath = request.getSession().getServletContext().getRealPath("/WEB-INF");
		String path = contextPath + "/" + spath+ "/dfish-license.zip";  
		Map<String, List<String>>  map = new TreeMap<String, List<String>>();
		LicenseJsonType json = LicenseTools.getLicenseTypefromJson(LicenseTools.readZipFile(path));
		LicenseTools.formatLicenseMap(map,new StringBuilder(),(Map<String, Object>)LicenseLocalMethods.decryptCode(json.getCode()));
		List<String> list = map.get("com.rongji.dfish.platform.expire");
		if(!CollectionUtils.isEmpty(list) && list.size() > 1) {
			String expire = list.get(1);
			hpModel.setExpire(expire);
		}
		log.info("license case "+(System.currentTimeMillis()-t3)+"ms");
		
		Map jobDone = service.jobDone(userCode);
		hpModel.setDone(jobDone);
		base.setData(hpModel);
		return base;
	}

}

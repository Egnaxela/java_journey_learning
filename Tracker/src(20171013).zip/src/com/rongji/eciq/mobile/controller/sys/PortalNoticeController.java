/**  
 * FileName:     
 * @Description: 公告信息控制类 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */

package com.rongji.eciq.mobile.controller.sys;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.SysAnnInfoMainEntity;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.PortalNoticeModel;
import com.rongji.eciq.mobile.service.sys.PortalNoticeService;

/**  
 * Description: 公告信息控制类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-12 上午10:29:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      李晨阳                      1.0         1.0 Version
 * 2017-6-12      李晨阳                      1.0         公告加模糊查询  
 */

@Controller
@RequestMapping("/portal")
public class PortalNoticeController extends MobileExceptionHandlerController{
	
	@Autowired
	private PortalNoticeService portalNoticeService;
	
	@RequestMapping(value = "/notice",method = RequestMethod.POST)
	@ResponseBody
	public DataModel notice(HttpServletRequest request,HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String annTitle = request.getParameter("annTitle");
		String currentPage = request.getParameter("currentPage"); 
//		if(StringUtils.isEmpty(userCode)||StringUtils.isEmpty(userOrgCode)){
//			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
//			return base;
//		}
		List<PortalNoticeModel> pnList = new ArrayList<PortalNoticeModel>();
		PortalNoticeModel portalNoticeModel = new PortalNoticeModel();
		List<SysAnnInfoMainEntity> queryList=portalNoticeService.getPortalNotice(annTitle, currentPage);
		if(!CollectionUtils.isEmpty(queryList)){
			for(SysAnnInfoMainEntity entity :queryList){
				portalNoticeModel = new PortalNoticeModel();
				portalNoticeModel.setAnnTitle(entity.getAnnTitle());
				portalNoticeModel.setAnnContent(entity.getAnnContent());
				portalNoticeModel.setIsueOrgCode(entity.getIsueOrgCode());
				portalNoticeModel.setAnnIssDate(entity.getAnnIssDate());
				portalNoticeModel.setAnnIssuerCode(entity.getAnnIssuerCode());
				pnList.add(portalNoticeModel);
			}
		}
		base.setData(pnList);
		return base;
	}
	
}

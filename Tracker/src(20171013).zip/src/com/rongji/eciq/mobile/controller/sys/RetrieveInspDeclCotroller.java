/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-25 上午9:25:03  
 *  
 */  

package com.rongji.eciq.mobile.controller.sys;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.service.sys.RetrieveInspDeclService;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.vo.insp.DeclNoQueryVo;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-25 上午9:25:03  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-25      李晨阳                      1.0         1.0 Version  
 * 2017-6-06      才江男                      1.0         校验数据是否已同步过
 * 2017-6-19      李晨阳                      1.0         调整代码，独立mag表模板归档数据，解决相同主键引发的问题
 */
@Controller
@RequestMapping("/sys/common")
public class RetrieveInspDeclCotroller  extends MobileExceptionHandlerController{

	@Autowired 
	private RetrieveInspDeclService service;
	
	@RequestMapping(value="/retrieveDecl",method=RequestMethod.GET)
	@ResponseBody
	public DataModel RetrieveInspDecl(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		String[] result = service.getDecl(declNo);
		String exsit = result[0];
		String writeUsec = result[1];
		String message;
		if("1" == exsit){
			message = service.retrieveInspDecl(declNo, writeUsec);
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(message);
			return base;
		}else if("-1" == exsit){
			message = "该报检单不存在下发库中！";
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(message);
			return base;
		}else if("2" == exsit){
			message = "该报检单不在移动查验流程中，无法调单！";
			base.setCode(HttpServletResponse.SC_OK);
			base.setData(message);
			return base;
		}else{
			message = "报检单调单异常，请联系管理员";
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(message);
			return base;
		}
		
	}
	
	/**
	* <p>描述:数据是否已同步过</p>
	* @param declNo 报检单号
	* @return
	* @author 才江男
	 */
	@RequestMapping(value="/findDecl",method=RequestMethod.GET)
	@ResponseBody
	public DataModel findDecl(HttpServletRequest request,HttpServletResponse response){
		DataModel base=MobileHelper.getBaseModel();
		String declNo=request.getParameter("declNo");//报检单号
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		String exsit = service.findDecl(declNo);
		DeclNoQueryVo vo = new DeclNoQueryVo();
		vo.setDeclNo(exsit);
		base.setData(vo);
		return base;
	}
	
}

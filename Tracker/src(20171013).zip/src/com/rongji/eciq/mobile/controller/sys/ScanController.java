/**  
 * FileName: ScanController.java    
 * @Description: 查询报检单管理表流程状态
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-5-16 上午10:03:54  
 *  
 */  

package com.rongji.eciq.mobile.controller.sys;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.ProcessModel;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.service.sys.PortalNoticeService;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**  
 * Description: 查询报检单管理表流程状态  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-16 上午10:03:54  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-16      李云龙                      1.0         1.0 Version 
 * 2017-5-17      李晨阳                      1.0         调整返回数据，添加提示信息   
 */
@Controller
@RequestMapping("/process")
public class ScanController {
	
	@Autowired
	private SubAuxiliaryService service;
	
	@RequestMapping(value = "/selectProcess",method = RequestMethod.GET)
	@ResponseBody
	public DataModel selectProcessStatus(HttpServletRequest request,HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String declNo = request.getParameter("declNo");
		if(StringUtils.isEmpty(declNo)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		
		String[] processStatus = new String[2];
		processStatus[0] = service.getProcessStatus(declNo);
		if(processStatus[0] == null){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("暂时查询不到该报检单相关信息，请稍后再试");
			return base;
		}
		processStatus[1] = CommonCodeToNameUtils.mobileStatusToName(processStatus[0]);
		
		ProcessModel model=new ProcessModel();
		model.setProcessStatusCode(processStatus[0]);
		model.setProcessStatusName(processStatus[1]);
		base.setCode(HttpServletResponse.SC_OK);
        base.setData(model);
		return base;
	}
	
	

}

package com.rongji.eciq.mobile.controller.sys;



import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.ezmorph.object.DateMorpher;
import net.sf.json.JSONArray;
import net.sf.json.util.JSONUtils;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.DfishException;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.platform.license.service.LicenseLocalMethods;
import com.rongji.dfish.platform.license.service.LicenseTools;
import com.rongji.dfish.platform.license.service.impl.LicenseJsonType;
import com.rongji.eciq.mobile.controller.exception.MobileExceptionHandlerController;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.LoginLogInfo;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.sys.Base64ImgModel;
import com.rongji.eciq.mobile.model.sys.ListModel;
import com.rongji.eciq.mobile.model.sys.LoginModel;
import com.rongji.eciq.mobile.model.sys.PrivilegeModel;
import com.rongji.eciq.mobile.model.sys.SysOrgModel;
import com.rongji.eciq.mobile.model.sys.SysUserModel;
import com.rongji.eciq.mobile.model.sys.UpdataModel;
import com.rongji.eciq.mobile.service.insp.scene.SceneService;
import com.rongji.eciq.mobile.service.insp.sub.SubAuxiliaryService;
import com.rongji.eciq.mobile.service.sys.HomePageInfoService;
import com.rongji.eciq.mobile.service.sys.SysUserMgrService;
import com.rongji.eciq.mobile.utils.HashMD5File;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.sys.SysTableCacheConfigList;
import com.rongji.eciq.mobile.vo.sys.SysTableCacheConfigVo;
import com.rongji.eciq.server.service.SenceCheckService;
import com.rongji.system.entity.EciqAppVersion;
import com.rongji.system.entity.SysFeedback;
import com.rongji.system.pub.service.IndexService;
import com.rongji.system.sys.service.VersionService;


/**  
 * Description: 系统用户控制类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-3-23 下午3:12:14  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0        修改用户信息模型  
 * 2017-5-08      才江男                      1.0        保存意见
 * 2017-5-17      才江男                      1.0        刷新缓存
 * 2017-5-17      魏波                          1.0        添加我的信息
 * 2017-6-6       夏晨琳                      1.0        获取证书所有信息集合
 * 2017-6-07      才江男                      1.0        证书过期
 * 2017-6-15      李晨阳                      1.0        获取当局信息
 * 2017-6-16      才江男                      1.0        更改逻辑
 * 2017-7-24      吴有根                      1.0        增加企业的信息查看、密码修改
 * 2017-8-03      才江男                      1.0        企业登录
 * 2017-8-03      李晨阳                      1.0        添加登录信息
 * 2017-8-03      李晨阳                      1.0        获取推广图片
 * 2017-9-19      夏晨琳                       2.0        添加登陆日志
 */
@Controller
@RequestMapping("/account")
public class SysAccountController extends MobileExceptionHandlerController{
	
	 static{
         String[] dateFormats = new String[] {"yyyy-MM-dd"};  
         JSONUtils.getMorpherRegistry().registerMorpher(new DateMorpher(dateFormats));  
    }
	
	@Autowired
	private SysUserMgrService sysUserMgrService;
	@Autowired
	private VersionService versionService;
	@Autowired
	private SubAuxiliaryService subService;
	@Autowired
	private HomePageInfoService homepageService;
	@Autowired
	private SceneService sceneService;
	
	@RequestMapping(value = "/login",method = RequestMethod.POST)
	@ResponseBody
	public DataModel login(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String userCode = request.getParameter("userCode");
		String password = request.getParameter("password");
		LoginModel loginModel = new LoginModel();
		//用户名和密码不能为空
		if(StringUtils.isEmpty(userCode) || StringUtils.isEmpty(password)) {
			loginModel.setLogin(false);
			loginModel.setMsg("用户名或密码不能为空");
		} else {
			//根据用户代码查询用户
			SysUser user = sysUserMgrService.checkUser(userCode);	
			//用户不存在
			if(null == user) {
				loginModel.setLogin(false);
				loginModel.setMsg("用户不存在");
			} else {
				//用户存在
				//加密密码
				String encodedPassword = HashMD5File.getStringMD5(password);
				//校验密码
				if(!encodedPassword.equals(user.getPassword())) {	
					//密码错误
					loginModel.setLogin(false);
					loginModel.setMsg("密码错误");
				} else if(!"1".equals(user.getOnDuty())){
					//密码正确
					loginModel.setLogin(false);
					loginModel.setMsg("用户已经不在岗");
				} else {
					//密码正确
					loginModel.setLogin(true);
					loginModel.setMsg("登录成功");
					//登录记录
					LoginLogInfo log=new LoginLogInfo();
					log.setId(UUIDKeyGeneratorUils.newInstance().generateKey());
					log.setUserId(user.getUserCode());
					log.setLoginTime(new Date());
					//String equipment=request.getParameter("equipment");
					String platform=request.getParameter("platform");
					String model=request.getParameter("model");
					String version=request.getParameter("version");
					//log.setEquipment(equipment);
					String loginIp;
					try {
						loginIp = sceneService.getIp(request);
					} catch (Exception e) {
						e.printStackTrace();
						loginIp = "unknow";
					}
					if(version==null || Utils.isEmpty(version)){
						version = "<4.4";
					}
					log.setLoginIp(loginIp);
					log.setAddr(sceneService.getIpAddr(loginIp));
					log.setDeviceType(platform);
					log.setDeviceInfo(model);
					log.setDeviceType(platform);
					log.setDeviceOs(version);
					subService.saLog(log);
					//用户信息
					SysUserModel sysUser = new SysUserModel();
					sysUser.setOrgCode(user.getOrgCode());
					sysUser.setUserCode(user.getUserCode());
					sysUser.setUserName(user.getUserName());
					//所属信息
					String orgCode = user.getOrgCode();
					String deptName = subService.getOrgCodeNameOrgCode(orgCode);//部门名称
					String orgName = subService.getOrgCodeNameOrgCode(orgCode.substring(0,6));//机构名称
					sysUser.setOrgDeptName(orgName+ " / " +deptName);//所属机构/部门
					loginModel.setUser(sysUser);
					//用户ID
					loginModel.setId(userCode);
					
					sysUser.setOrgName(deptName);
//					SysOrganizeEntity organizeEntity = sysUserMgrService.getOrgByUserCode(userCode);
//					if(null != organizeEntity) {
						//部门名称
//						sysUser.setOrgName(organizeEntity.getOrgNameSc());
//					}
					
					//防伪码
					String hexCode = MobileHelper.getMD5(userCode);
					loginModel.setHexCode(hexCode);
					//获取权限
					List<PrivilegeModel> privileges = sysUserMgrService.getUserPrivileges(userCode);
					
					if (CollectionUtils.isNotEmpty(privileges)) {
						//将权限改装为JSON格式权限
						loginModel.setPrivileges(privileges);
					}
					
					//证书过期
					String expire = expire(request);
					loginModel.setExpire(expire);
				}
			}
		}
		base.setData(loginModel);
		return base;
	}
	
	/**
	 * 证书过期
	 */
	private String expire(HttpServletRequest request) throws DfishException {
		String spath = "license";
		String contextPath = request.getSession().getServletContext().getRealPath("/WEB-INF");
		String path = contextPath + "/" + spath+ "/dfish-license.zip";  
		Map<String, List<String>>  map = new TreeMap<String, List<String>>();
		LicenseJsonType json = LicenseTools.getLicenseTypefromJson(LicenseTools.readZipFile(path));
		LicenseTools.formatLicenseMap(map,new StringBuilder(),(Map<String, Object>)LicenseLocalMethods.decryptCode(json.getCode()));
		List<String> list = map.get("com.rongji.dfish.platform.expire");
		String expire = "";
		if(!CollectionUtils.isEmpty(list) && list.size() > 1) {
			expire = list.get(1);
		}
		return expire;
	}
	
	@RequestMapping(value = "/update",method = RequestMethod.GET)
	@ResponseBody
	public DataModel update(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String sysType = request.getParameter("system");
		UpdataModel updataModel = new UpdataModel();
		if(StringUtils.isEmpty(sysType) ){
			base.setMsg("获取版本失败");
		}else{
			EciqAppVersion EaiqData = versionService.getVersionByType(sysType);
			updataModel.setVersionId(EaiqData.getVersionId());
			updataModel.setUrl(EaiqData.getUrl());
			updataModel.setUpdateExplain(EaiqData.getUpdateExplain());
			base.setData(updataModel);
		}
		return base;
	}
	
	@RequestMapping(value = "/modifyPwd",method = RequestMethod.POST)
	@ResponseBody
	public DataModel modifyPwd(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String userCode = request.getParameter("loginUser");
		String password = request.getParameter("old");
		String newPwd = request.getParameter("newPwd");
		String flag=request.getParameter("flag");
		String entOrgCode=request.getParameter("entOrgCode");
		LoginModel loginModel = new LoginModel();
		
		if(!"2".equals(flag)) {
			//用户名和密码不能为空
			if(StringUtils.isEmpty(userCode)) {
				loginModel.setLogin(false);
				loginModel.setMsg("用户名不能为空，若再次出现该提示，请重新登录后再次尝试");
			} else if(StringUtils.isEmpty(password) || StringUtils.isEmpty(newPwd)){
				loginModel.setLogin(false);
				loginModel.setMsg("原密码或新密码不能为空");
			} else {
				//根据用户代码查询用户
				SysUser user = sysUserMgrService.checkUser(userCode);	
				//用户不存在
				if(null == user) {
					loginModel.setLogin(false);
					loginModel.setMsg("用户不存在");
				} else {
					//用户存在
					//加密密码
					String encodedPassword = HashMD5File.getStringMD5(password);
					//校验密码
					if(!encodedPassword.equals(user.getPassword())) {	
						//密码错误
						loginModel.setLogin(false);
						loginModel.setMsg("原密码错误");
					} else if(!"1".equals(user.getOnDuty())){
						//密码正确
						loginModel.setLogin(false);
						loginModel.setMsg("用户已经不在岗");
					} else {
						//密码正确
						loginModel.setLogin(true);
						loginModel.setMsg("操作成功");
						encodedPassword = HashMD5File.getStringMD5(newPwd);
						//修改密码
						sysUserMgrService.modifyPwd(userCode, encodedPassword);
					}
				}
			}
		
		}else {
			EntBaseInfoEntity entity=sysUserMgrService.getEntBaseInfo(entOrgCode);
			String MD5Salt="rjkd;askd;lakdpqndnqnlw&*"; 
			//加密传过来的旧密码
			String encodedPassword=HashMD5File.getStringMD5(password+MD5Salt);
			//校验密码
			if(!encodedPassword.equals(entity.getEntOrgPwd())) {	
				//密码错误
				loginModel.setLogin(false);
				loginModel.setMsg("原密码错误");
			} else {
				//密码正确
				loginModel.setLogin(true);
				loginModel.setMsg("操作成功");
				//加密新密码
				encodedPassword=HashMD5File.getStringMD5(newPwd+MD5Salt);
				//修改密码
				sysUserMgrService.modifyEntBaseInfoPwd(entOrgCode, encodedPassword);
			}
		}
		base.setData(loginModel);
		return base;
	}
	
	@RequestMapping(value = "/users",method = RequestMethod.GET)
	@ResponseBody
	public DataModel getUsers(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		ListModel model = new ListModel();
		String orgCode = request.getParameter("orgCode");
		String userCode = request.getParameter("userCode");
		String cp = request.getParameter("cp");
		if(StringUtils.isEmpty(orgCode)) {
			model.setMsg("请选择部门");
		} else {
			List users = sysUserMgrService.getUsers(orgCode, userCode, cp);
			model.setList(users);
			base.setData(model);
		}
		return base;
	}
	
	@RequestMapping(value = "/orgs",method = RequestMethod.GET)
	@ResponseBody
	public DataModel getOrgs(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		SysOrgModel model = new SysOrgModel();
		String orgCode = request.getParameter("orgCode");
		String cp = request.getParameter("cp");
		if (StringUtils.isEmpty(orgCode)) {
			model.setMsg("请选择部门");
		} else {
			// 查询本机构及下属部门
			model = sysUserMgrService.getOrgs(orgCode);
		}
		base.setData(model);
		return base;
	}

	/**
	 * 保存意见反馈
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/feeback", method = RequestMethod.POST)
	@ResponseBody
	public DataModel feeback(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = new DataModel();
		DataModel back = new DataModel();
		base.setData(back);
		String userCode = request.getParameter("userCode");
		String userName = request.getParameter("userName");
		String orgCode = request.getParameter("orgCode");
		String orgName = request.getParameter("orgName");
		String feedbackDesc = request.getParameter("feedbackDesc");
		String feedbackTitle = request.getParameter("feedbackTitle");

		if (StringUtils.isEmpty(feedbackDesc)
				|| StringUtils.isEmpty(feedbackTitle)) {
			back.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
		} else {
			SysFeedback sysFeedback = new SysFeedback();
			sysFeedback.setFeedbackId(UUIDKeyGeneratorUils.newInstance()
					.generateKey());
			sysFeedback.setFeedbackDesc(feedbackDesc);
			sysFeedback.setFeedbackTitle(feedbackTitle);
			sysFeedback.setOperCode(userCode);
			sysFeedback.setOperName(userName);
			sysFeedback.setOrgCode(orgCode);
			sysFeedback.setOrgName(orgName);
			sysFeedback.setOperTime(new Date());

			// 查询本机构及下属部门
			sysUserMgrService.saveFeeBack(sysFeedback);
		}
		return base;
	}
	

	/**
	 * 获取db配置项
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/dbConfig", method = RequestMethod.GET)
	@ResponseBody
	public DataModel dbConfig(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = new DataModel();
		List<SysTableCacheConfigVo> dbConfig = sysUserMgrService.getDbConfig();
		base.setData(dbConfig);
		return base;
	}
	
	/**
	 * 更新缓存
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/dbUpdate", method = RequestMethod.POST)
	@ResponseBody
	public DataModel dbUpdate(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = new DataModel();
		String dbs = request.getParameter("dbs");
		if(StringUtils.isEmpty(dbs)){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		JSONArray dbUpdates = JSONArray.fromObject(dbs);
		List<SysTableCacheConfigVo> resultList =(List<SysTableCacheConfigVo>)JSONArray.toList(dbUpdates, SysTableCacheConfigVo.class);
		
		List<SysTableCacheConfigList> dbConfig = sysUserMgrService.dbUpdate(resultList);
		base.setData(dbConfig);
		return base;
	}
	
	
	/**
	 * 
	* <p>描述:查看我的信息</p>
	* @param request
	* @param response
	* @return
	* @author 魏波
	 */
	@RequestMapping(value = "/info", method = RequestMethod.GET)
	@ResponseBody
	public DataModel infor(HttpServletRequest request,
			HttpServletResponse response) {
		DataModel base = new DataModel();
		SysUserModel model = new SysUserModel();
		String userCode = request.getParameter("loginUser");
		String orgCode = request.getParameter("orgCode");
		String flag=request.getParameter("flag");
		String entOrgCode=request.getParameter("entOrgCode");
		if((!"2".equals(flag))&&(StringUtils.isEmpty(userCode)||StringUtils.isEmpty(orgCode))){
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(MobileHelper.PARAM_VALIDATE_TIP);
			return base;
		}
		if(!StringUtils.equals("2", flag)) {
			SysUser user = sysUserMgrService.checkUser(userCode);	
			String deptName = subService.getOrgCodeNameOrgCode(orgCode);//部门名称
			String orgName = subService.getOrgCodeNameOrgCode(orgCode.substring(0,6));//机构名称
			model.setOrgDeptName(orgName+"/"+deptName);//所属机构/部门
			model.setUserName(user.getUserName());
			Date date = user.getCreateTime();
			String time = DateUtil.format(date,"yyyy年MM月dd日");//获取年月日
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE");  
	        String week = sdf.format(date);//获取星期几
	        model.setDate(time+" "+week);
	        base.setData(model);
			return base;
		}else {
			EntBaseInfoEntity entity=sysUserMgrService.getEntBaseInfo(entOrgCode);
			if(entity!=null) {
				model.setUserName(entity.getEntOrgCode());
				model.setOrgDeptName(entity.getUnitNameCn());
			}
			Date date = new Date();
			String time = DateUtil.format(date,"yyyy年MM月dd日");//获取年月日
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE");  
	        String week = sdf.format(date);//获取星期几
	        model.setDate(time+" "+week);
	        base.setData(model);
			return base;
			
		}
	}	
	
	/**
	 * 
	* <p>描述:获取证书所有信息集合</p>
	* @return
	* @throws DfishException
	* @author 夏晨琳
	 */
	@RequestMapping(value = "/getLicenseInfos", method = RequestMethod.GET)
	@ResponseBody
	public  Map<String, List<String>> getLicenseInfos() throws DfishException{
		String spath = "license";
		URL url = Thread.currentThread().getContextClassLoader()  
			    .getResource("");  
		String path = url.getPath().replace("classes", spath);  
		path = path.substring(1)+"dfish-license.zip";  
		Map<String, List<String>>  map = new TreeMap<String, List<String>>();
		LicenseJsonType json = LicenseTools.getLicenseTypefromJson(LicenseTools.readZipFile(path));
		LicenseTools.formatLicenseMap(map,new StringBuilder(),(Map<String, Object>)LicenseLocalMethods.decryptCode(json.getCode()));
		return map;
	}
	
	/**
	 * <p>
	 * 描述:获取当局信息
	 * </p>
	 * 
	 * @return
	 * @throws DfishException
	 * @author 李晨阳
	 */
	@RequestMapping(value = "/orgName",method = RequestMethod.GET)
	@ResponseBody
	public DataModel getOrgName(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DataModel base = new DataModel();
		String orgCode = request.getParameter("orgCode");
		String orgName = "0";
			String name = versionService.getOrgName(orgCode);
			if(StringUtils.isEmpty(name)) {
				name = orgName;
			}
			base.setData(name);
		return base;
	}
	
	/**
	 * <p>
	 * 描述:获取推广图片
	 * </p>
	 * 
	 * @return
	 * @throws DfishException
	 * @author 李晨阳
	 */
	@RequestMapping(value = "/baseImg",method = RequestMethod.GET)
	@ResponseBody
	public DataModel getBaseImg(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String date = request.getParameter("date");
		DataModel base = new DataModel();
		Base64ImgModel model = new Base64ImgModel();
		String[] res = homepageService.isRefresh(date);
		String[] tiltle = res[2].split("；");
		if(res[0].equals("No")){
			model.setImgID("Keep");
			model.setTitle(tiltle);
		}else {
			String[] base64Str = homepageService.getBase64Img(res[1]);
			model.setImgID("NewToDay");
			model.setImgDate(res[0]);
			model.setTitle(tiltle);
			model.setBase64Str(base64Str);
		}
		base.setData(model);
		return base;
	}
}
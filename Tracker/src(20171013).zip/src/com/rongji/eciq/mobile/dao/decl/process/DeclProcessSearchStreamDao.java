/**  
 * FileName:DeclProcessSearchStreamDao.java
 * @Description: 流程查询-报检信息查询dao 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.decl.process;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 流程查询-报检信息查询dao  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波 
 * @version:    1.0  
 * Create at:   2017-5-15 下午1:52:59  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                      1.0         1.0 Version
 */
@Repository
public class DeclProcessSearchStreamDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	@Autowired
	private CompanyCodeUtils companyCodeUtils;
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	/**
	 * 获取报检单主表信息
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	public List<DclIoDeclEntity> getSubAuditList(String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage,String beginDate,String endDate) {
		String orgCode = companyCodeUtils.getBusinessOrgCode(exeInspOrgCode, false);
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclIoDeclEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isEmpty(declNo)){
			sql.append(" AND t.orgCode =?");
			param.add(orgCode);
		}else{
			sql.append(" AND (t.declNo='").append(declNo).append("' or t.declGetNo='")
			.append(declNo).append("' or entDeclNo='").append(declNo).append("')");
		}
		if (StringUtils.isNotEmpty(beginDate)) {
			sql.append(" AND t.declDate >to_date('")
					.append(beginDate + " 00:00:00")
					.append("','yyyy-mm-dd hh24:mi:ss')");
		}
		if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" AND t.declDate <to_date('").append(endDate + " 23:59:59")
					.append("','yyyy-mm-dd hh24:mi:ss')");
		}
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<DclIoDeclEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
		return list;
	}


	/**
	 * 机构代码串
	 * @param orgCode
	 * @return
	 */
	 public String getOrgCodePath(String orgCode) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = " select t from SysOrganizeEntity t where t.orgCode = '"+orgCode+"'";
	        Query query = session.createQuery(sql);
	        List<SysOrganizeEntity> result = query.list();
			session.close();
			if (CollectionUtils.isEmpty(result)) {
				return null;
			} else {
				return result.get(0).getOrgCodePath();
			}
	 }
	 
	 /**
	  * 工作流程查询下发库
	  * @param declNo
	  * @return
	  */
	 public List<SysProcessLogEntity> getSysProcessLog(String declNo){
		 	String declGetNo="";
		 	if (declNo.endsWith("L")) {
	            return null;
	        } else if (declNo.endsWith("H")) {
	            //传进来的报检号以"H"结尾
	        	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
//	            String sql = "SELECT G FROM SysProcessLogEntity G WHERE G.declNo = :declNo ORDER BY G.operDate";
	            String sql = "SELECT * FROM SYS_PROCESS_LOG G WHERE G.DECL_NO=:declNo ORDER BY G.OPER_DATE ASC,G.PROCESS_STATUS ASC ";
	            List<SysProcessLogEntity> resultList = session.createSQLQuery(sql).addEntity(SysProcessLogEntity.class).setParameter("declNo",declNo).list();
	            session.close();
	            return resultList;
	        }else{
	        	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		        String sql = " select t from DclIoDeclEntity t where t.declNo = '"+declNo+"'";
		        Query query = session.createQuery(sql);
		        List<DclIoDeclEntity> result = query.list();
				session.close();
				if (CollectionUtils.isNotEmpty(result)) {
					declGetNo = result.get(0).getDeclGetNo();
				}
				
				Session session1=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
				String ql = "SELECT * FROM SYS_PROCESS_LOG G WHERE G.DECL_NO IN('"+declNo+"','"+declGetNo+"') ORDER BY G.OPER_DATE ASC, G.PROCESS_STATUS ASC ";
				List<SysProcessLogEntity> list = session1.createSQLQuery(ql).addEntity(SysProcessLogEntity.class).list();
				
				Session session2=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
				String ql2 = "SELECT SYS_GUID() PROCESS_LOG_ID,"
                     + "       T.BIZ_NO DECL_NO,"
                     + "       T.FLOW  PROCESS_NODE,"
                     + "       T.STATUS  PROCESS_STATUS,"
                     + "       '' STATUS_MEMO,"
                     + "       '' NODE_MEMO,"
                     + "       T.USER_CODE OPER_CODE,"
                     + "       T.USER_NAME TREA_OPER_NAME,"
                     + "       T.CREATE_TIME OPER_DATE,"
                     + "       '' FALG_ARCHIVE,"
                     + "       CASE T.STATUS WHEN '0' THEN '等待施检初始化' WHEN '1' THEN '正在初始化施检' WHEN '3' THEN '异常-请联系管理员' END REMARK,"
                     + "       '' END_DATE,"
                     + "       '' TREA_OPER_CODE,"
                     + "       '' OPER_NAME,"
                     + "       T.ORG_CODE TREA_ORG_CODE,"
                     + "       '' END_FLAG,"
                     + "       '' DECL_WORK_NO,"
                     + "       '' WORK_SER_STAMP,"
                     + "       '' SEND_FLAG"
                     + "  FROM ASYN_BUSINESS_PROCESS T"
                     + "   WHERE T.BIZ_NO =:declNo"
                     + "   AND T.BIZ_TYPE='DeclEvaluation' "
                     + "   AND T.CREATE_TIME = (SELECT MAX(T.CREATE_TIME) FROM ASYN_BUSINESS_PROCESS S WHERE T.BIZ_NO =:declNo )";
	            List<SysProcessLogEntity> newtList = session2.createSQLQuery(ql2).addEntity(SysProcessLogEntity.class).setParameter("declNo",declNo).list();
	            if(CollectionUtils.isNotEmpty(newtList)){
	            	list.add(newtList.get(0));
	            }
	            session1.close();
	            session2.close();
	            return list;
	        }
	 }
}

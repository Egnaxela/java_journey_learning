/**  
 * FileName:DeclInfoQueryDao.java
 * @Description: 流程查询下发库-报检信息查询dao
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.decl.query;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 流程查询下发库-报检信息查询dao  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波    
 * @version:    1.0  
 * Create at:   2017-5-15 下午1:55:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                   1.0         1.0 Version
 */
@Repository
public class DeclInfoQueryDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	@Autowired
	private CompanyCodeUtils companyCodeUtils;
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	/**
	 * 获取报检单主表信息
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	public List<DclIoDeclEntity> getSubAuditList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage) {
		String orgCode = companyCodeUtils.getBusinessOrgCode(exeInspOrgCode, false);
		String orgCodePath = this.getOrgCodePath(orgCode);
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclIoDeclEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND  t.declType =?");
		param.add(expImpFlag);
		if(StringUtils.isNotEmpty(orgCodePath)){
			//.append("%' or t.vsaOrgCodePath like '").append(orgCodePath)
//			.append("%' or t.portOrgCodePath like '").append(orgCodePath)
//			sql.append("or (t.orgCodePath like '").append(orgCodePath).append("%')");
			sql.append(" and (t.orgCode like '").append(orgCode).append("%' or t.inspOrgCode like '").append(orgCode)
			.append("%' or t.purpOrgCode like '").append(orgCode)
			.append("%') ");
		}
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<DclIoDeclEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
		return list;
	}

	/**
	 * 机构代码串
	 * @param orgCode
	 * @return
	 */
	 public String getOrgCodePath(String orgCode) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = " select t from SysOrganizeEntity t where t.orgCode = '"+orgCode+"'";
	        Query query = session.createQuery(sql);
	        List<SysOrganizeEntity> result = query.list();
			session.close();
			if (CollectionUtils.isEmpty(result)) {
				return null;
			} else {
				return result.get(0).getOrgCodePath();
			}

	    }
}

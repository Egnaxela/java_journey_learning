/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-26 上午11:05:39  
 *  
 */  

package com.rongji.eciq.mobile.dao.decl.query;

import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.OrdBackMainVo;
import com.rongji.eciq.mobile.entity.OrdInfoSearchVo;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波 
 * @version:    1.0  
 * Create at:   2017-5-26 上午11:05:39  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-26      魏波                     1.0         1.0 Version  
 */
@Repository
public class SurInfoQueryDao {
	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	
	/**
	 * 
	* <p>描述:查看布控信息dao</p>
	* @param declNo
	* @return
	* @author 魏波
	 */
	public List<OrdInfoSearchVo> getOrdInfoSearchVo(String declNo){
		 String ql = "SELECT e.* FROM ( SELECT B.DECL_NO, "//报检号
	                + "B.RULE_ID, "//规则id
	                + "B.CONC_TYPE, "//结论分类
	                + "B.CONC_DESC, "//结论内容
	                + "B.CENS_TYPE, "//审单类型
	                + "B.EXEC_LEVEL, "//执行级别
	                + "B.CONCLUSION_NAME, "//结论名称
	                + "B.CENS_PERSON, "//审单人
	                + "B.CENS_ORG, "//审单机构
	                + "B.ADD_LINK, "//布控增加环节
	                + "B.SEND_TIME, "//下发时间
	                + "B.ORDER_NO, "//布控信息编号
	                + "B.ARRIV_LINK, "//到达的环节
	                +" B.CONCLUSION_NO, "//结论编号
	                +" B.ENABLED, "//是否生效
	                +" B.OPER_TYPE, "//操作类型 
	                + "A.ORDER_DATE, "//布控时间
	                + "A.ORDER_MAIN_NO, "//布控主编号
	                + "C.EXEC_RSLT, "//执行结果
	                + "C.ORD_FEEDBACK_INFO_NO, "//布控反馈信息编号
	                + "C.UNQU_REASON, "//不合格原因
//	                + "D.RESULT_NODE_ID, "//结论分类编号
//	                + "D.NODE_NAME, "//名称
	                + "C.EXEC_RSLT_DESC "//执行结果描述
	                + "FROM  DCL_ORD_DETAIL B "
	                + "LEFT JOIN DCL_ORD_MAIN A ON A.ORDER_MAIN_NO=B.ORDER_MAIN_NO "
//	                + "LEFT JOIN SYS_RULE_RESULT_NODE D ON D.RESULT_NODE_ID=B.CONCLUSION_NO "
	                + "LEFT JOIN DCL_ORD_FEEDBACK_DETAIL C ON B.ORDER_NO=C.ORDER_NO WHERE 1=1 ";

	        ql += " ) e WHERE e.DECL_NO='"+declNo+"' AND e.CONCLUSION_NO !='0004410'";
	
	        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	    	List<OrdInfoSearchVo> list=session.createSQLQuery(ql).addEntity(OrdInfoSearchVo.class).list();
			session.close();
			return list;
	}

}

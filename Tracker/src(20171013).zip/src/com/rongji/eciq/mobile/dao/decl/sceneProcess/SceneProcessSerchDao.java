/**  
 * FileName:SceneProcessSerchDao.java    
 * @Description: 查验信息
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-9 上午9:48:13  
 *  
 */

package com.rongji.eciq.mobile.dao.decl.sceneProcess;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.entity.SysAppProcessLog;

/**
 * 
 * Description: 查验信息  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波  
 * @version:    1.0  
 * Create at:   2017-5-15 下午1:56:33  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                         1.0         1.0 Version
 * 2017-5-31      才江男                     1.0         不分页查询
 */
@Repository
public class SceneProcessSerchDao {

	PubCommonDAO dao = FrameworkHelper.getDAO();

	/**
	 * 
	 * <p>
	 * 描述:获取查验信息
	 * </p>
	 * 
	 * @param declNo
	 * @param operCode
	 * @param operDateBegin
	 * @param operDateEnd
	 * @param processStatus
	 * @param processNode
	 * @param currentPage
	 * @return
	 * @author 魏波
	 */
	public List<SysAppProcessLog> getList(String declNo, String operCode,
			String operDateBegin, String operDateEnd, String processStatus,
			String processNode, String currentPage,String exeInspOrgCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysAppProcessLog t where  1=1 ");
		List<String> param = new ArrayList<String>();
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		if (StringUtils.isNotEmpty(operCode)) {
			sql.append(" AND t.operCode =?");
			param.add(operCode);
		}
		if (StringUtils.isNotEmpty(exeInspOrgCode)) {
			sql.append(" AND t.treaOrgCode =?");
			param.add(exeInspOrgCode);
		}
		if (StringUtils.isNotEmpty(processStatus)) {
			sql.append(" AND t.processStatus =?");
			param.add(processStatus);
		}
		if (StringUtils.isNotEmpty(processNode)) {
			sql.append(" AND t.processNode =?");
			param.add(processNode);
		}
		if (StringUtils.isNotEmpty(operDateBegin)) {
			sql.append(" AND t.operDate >to_date('")
					.append(operDateBegin + " 00:00:00")
					.append("','yyyy-mm-dd hh24:mi:ss')");
		}
		if (StringUtils.isNotEmpty(operDateEnd)) {
			sql.append(" AND t.operDate <to_date('").append(operDateEnd + " 23:59:59")
					.append("','yyyy-mm-dd hh24:mi:ss')");
		}
		sql.append(" order by t.operDate");
		if (StringUtils.isEmpty(currentPage)) {
			currentPage = "1";
		}
//		Page page = MobileHelper.getPage(currentPage);
		List<SysAppProcessLog> list = dao.getQueryList(sql.toString(),
				param.toArray());
		return list;
	}

	/**
	 * 
	* <p>描述:保存查验流程日志</p>
	* @param log
	* @return
	* @author 魏波
	 */
	public void saveLog(SysAppProcessLog log) {
			dao.saveObject(log);
	}
	
	/**
	 * 
	 * <p>描述:更新查验流程日志</p>
	 * @param log
	 * @return
	 * @author 张锡森
	 */
	public void updateLog(SysAppProcessLog log) {
		dao.updateObject(log);
	}
}

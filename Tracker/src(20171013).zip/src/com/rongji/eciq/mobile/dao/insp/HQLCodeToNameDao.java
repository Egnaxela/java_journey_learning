/**  
 * FileName:    HQLCodeToNameDao.java 
 * @Description: 代码转名称工具类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-5-13 下午3:18:56  
 *  
 */
package com.rongji.eciq.mobile.dao.insp;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.system.sys.utils.RedisUtils;


/**
 * 
 * Description: 代码转名称工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-15 下午4:55:25  
 *  
 * Modification History:  
 * Date           Author        Version       Description  
 * ------------------------------------------------------------------  
 * 2017-04-25     才江男                         1.0.0         货物不合格登记代码转名称
 * 2017-05-17     吴有根                         1.0.0         增加施检常用代码转名称
 * 2017-05-24     李云龙                         1.0.0         增加所需证单代码转名称
 * 2017-06-01     李云龙                          1.0.0         增加工作内容串代码转名称
 * 2017-06-01     夏晨琳                          1.0.0         增加部分方法redis缓存获取
 * 2017-06-13     李晨阳                         1.0.0         整理代码，代码转名称替换为redis缓存 
 * 2017-06-16     才江男                         1.0.0         用户不读缓存      
 * 2017-07-07     才江男                         1.0.0         检疫不合格原因查询indexid
 */
@Repository
public class HQLCodeToNameDao {

	@Autowired
	HibernateTemplate chgHibernateTemplate;
	@Autowired
	private RedisUtils redisUtils;
	
	
	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getTradeCountryNameByCode(String code){
		String value = redisUtils.codeToName(RedisUtils.Z_CCM_WORLDDISTRICT,code,"WorldDistrict");
		if (Utils.isEmpty(value) || value == null) {
			value = findTradeCountryNameByCode(code);
		}
		return value;
	} 
	
	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String findTradeCountryNameByCode(String code){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from Z_CCM_WORLDDISTRICT t where 1=1";
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.itemcode=?";
		}else {
			return "";
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, code);
		List list=query.list();
		session.close();
		return  Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 施检机构代码转名称
	 * @param code
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getOrgNameByCode(String code){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String OrgName = redisUtils.codeToName("SYS_ORGANIZE", code);
		if(null == OrgName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.ORG_NAME_SC from SYS_ORGANIZE t where 1=1 and t.ORG_CODE=?";
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
			OrgName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return OrgName;
	} 
	
	
	/**
	 * 贸易方式代码转名称
	 * @param code
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getTradeModeNameByCode(String code){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String TradeModeName = redisUtils.codeToName("Z_CCM_SIMPLELIST_4", code, "TradeMode");
		if(null == TradeModeName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.CNAME from Z_CCM_SIMPLELIST_4 t where 1=1 AND t.indexid='TradeMode' and t.code=?";
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
			TradeModeName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return  TradeModeName;
	} 
	
	
	/**
	 * 运输方式代码转名称
	 * @param code
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getTransModeNameByCode(String code){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String TransModeName = redisUtils.codeToName("Z_CCM_SIMPLELIST_4", code, "TransitMode");
		if(null == TransModeName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.CNAME from Z_CCM_SIMPLELIST_4 t where 1=1 AND t.indexid='TransitMode' and t.code=?";
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
			TransModeName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return  TransModeName;
	} 
	
	/**
	 * 计量单位和货币代码转名称
	 * @param code
	 * @return
	 */
	public String getMeasurementNameByCode(String code,String flag){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String MeasurementName = redisUtils.codeToName("Z_CCM_SIMPLELIST_4", code, flag);
		if(null == MeasurementName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_SIMPLELIST_4 t where 1=1 and t.indexid=? and t.code=?";
			Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
			List list=query.list();
			session.close();
			MeasurementName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return MeasurementName;
	}
	
	
	/**
	 * 根据ciq code获取ciq货物名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String getProductCiqNameByCode(String code,String flag){
		String value = redisUtils.codeToName(RedisUtils.Z_BBD_CIQ_CODE,code, flag);
		if (StringUtils.isEmpty(value) || value == null) {
			value = findProductCiqNameByCode(code, flag);
		}
		return value;
	}
	
	/**
	 * 根据ciq code获取ciq货物名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String findProductCiqNameByCode(String code,String flag){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.goods_name from Z_BBD_CIQ_CODE t where 1=1";
		if(StringUtils.isNotEmpty(flag)){
			sql+=" and t.indexid=?";
		}
		
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.ciq_code=?";
		}else {
			return "";
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 检验方式代码转名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String getCheckoutMethodNameByCode(String code,String flag){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String CheckoutMethodName = redisUtils.codeToName("Z_CCM_SIMPLELIST_7", code, flag);
		if(null == CheckoutMethodName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_SIMPLELIST_7 t where 1=1 and t.indexid=? and t.code=?";
			Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
			List list=query.list();
			session.close();
			CheckoutMethodName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return CheckoutMethodName;
	}
	
	
	/**
	 * 天气代码转名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String findWeatherNameByCode(String code,String flag){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from Z_CCM_SIMPLELIST_10 t where 1=1";
		if(StringUtils.isNotEmpty(flag)){
			sql+=" and t.indexid=:flag";
		}
		
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.code=:code";
		}else {
			return "";
		}
		
		Query query=session.createSQLQuery(sql);
		if(StringUtils.isNotEmpty(flag)){
			query.setParameter("flag", flag);
		}
		if(StringUtils.isNotEmpty(code)){
			query.setParameter("code", code);
		}
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 天气代码转名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String getWeatherNameByCode(String code,String flag){
		String value = redisUtils.codeToName(RedisUtils.Z_CCM_SIMPLELIST_10,code, flag);
		if (value == null || StringUtils.isEmpty(value)) {
			value = findWeatherNameByCode(code, flag);
		}
		return value;
	}
	
	
	/**
	 * 检验依据转名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String getInspBasCatNameByCode(String code,String flag){
		String value = redisUtils.codeToName(RedisUtils.Z_CCM_SIMPLELIST_6,code, flag);
		if (value == null || StringUtils.isEmpty(value)) {
			value = findInspBasCatNameByCode(code, flag);
		}
		return value;
	}
	
	/**
	 * 检验依据转名称
	 * @param code
	 * @param flag
	 * @return
	 */
	public String findInspBasCatNameByCode(String code,String flag){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from Z_CCM_SIMPLELIST_6 t where 1=1";
		if(StringUtils.isNotEmpty(flag)){
			sql+=" and t.indexid=?";
		}
		
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.code=?";
		}else {
			return "";
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 获取用户名称
	 * @param code
	 * @param flag
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getUserNameByCode(String code){
		if(StringUtils.isEmpty(code)){
			return "";
		}
//		String UserName = redisUtils.codeToName("SYS_USER_A", code);
//		if(null == UserName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.USER_NAME from SYS_USER_A t where 1=1 and t.USER_CODE=?";
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
//			UserName = Utils.notEmpty(list)?(String)list.get(0):"";
//		}
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	* <p>描述: 入境/出境检验不合格处理</p>
	* @param flag 出入境标志
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String getUnqualHaDic(String flag, String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select cname from Z_CCM_SIMPLELIST_7 where indexid = 'IOFGoodCheckoutDisQH' and flag <> ? ";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		if(StringUtils.isEmpty(flag)) {
			flag = "1";
		}
		if("1".equals(flag)) {
			sql += " and alias1 like ?";
		} else {
			sql += " and alias1 like ?";
		}
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0,"1");
		if("1".equals(flag)) {
			query.setParameter(1,"%进%");
		} else {
			query.setParameter(1,"%出%");
		}
		query.setParameter(2, code);
		return getResult(query);
	}
	
	/**
	* <p>描述: 检验不合格原因</p>
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String getIOFGoodCheckoutDisQR(String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select t.cname from Z_CCM_SIMPLELIST_7 t where t.indexid = 'IOFGoodCheckoutDisQR' and t.flag <> '1'";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0, code);
		return getResult(query);
	}
	
	/**
	* <p>描述: 检疫不合格原因</p>
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String getProductDwHandleRea(String code) {
		String value = redisUtils.codeToName(RedisUtils.Z_CCM_SIMPLELIST_9,code, "ProductDwHandleRea");
		if (StringUtils.isEmpty(value) || value == null) {
			value = findProductDwHandleRea(code);
		}
		return value;
	}
	
	/**
	* <p>描述: 检疫不合格原因</p>
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String findProductDwHandleRea(String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select i.cname from Z_CCM_SIMPLELIST_9 i where i.indexid = 'ProductDwHandleRea' and i.flag <>'1'";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0, code);
		return getResult(query);
	}
	
	/**
	* <p>描述: 检疫不合格处理(检疫处理措施)</p>
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String getProductDwHandleMethd(String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select cname from Z_CCM_SIMPLELIST_9 where indexid = 'ProductDwHandleMethd' and flag <> '1'";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0, code);
		return getResult(query);
	}
	
	/**
	* <p>描述: 检疫不合格处理方法</p>
	* @param code 代码
	* @return 名称
	* @author 才江男
	 */
	public String getProductDwDetailMethd(String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select cname from Z_CCM_SIMPLELIST_9 where indexid = 'ProductDwDetailMethd' and flag <> '1'";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0, code);
		return getResult(query);
	}
	
	/**
	* <p>描述: 不合格内容</p>
	* @param code 代码
	* @param flag 代码1：检验 2：检疫
	* @return 名称
	* @author 才江男
	 */
	public String getIOFGoodCheckoutDisQC(String flag, String code) {
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select t.cname from Z_CCM_SIMPLELIST_7 t where t.indexid = 'IOFGoodCheckoutDisQC' and t.flag != '1'";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		if("2".equals(flag)) {
			sql += " and t.alias1 like ? ";
		} else {
			sql += " and t.alias1 like ? ";
		}
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		if("2".equals(flag)) {
			query.setParameter(0, "%2%");
		} else {
			query.setParameter(0, "%1%");
		}
		query.setParameter(1, code);
		return getResult(query);
	}
	
	/**
	* <p>描述:货物检疫不合格处理</p>
	* @param code
	* @return
	* @author 才江男
	 */
	public String getQurUnqProcDic(String code){
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String sql = "select cname from Z_CCM_SIMPLELIST_9 where indexid = 'ProductDwHandleMethd' and flag <> ?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql +=" and code = ?";
		Query query=session.createSQLQuery(sql);
		query.setParameter(0,"1");
		query.setParameter(1, code);
		if(null == query) {
			session.close();
			return "";
		}
		List<String> list = query.list();
		session.close();
		if(CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}
		return "";

	}
	
	/**
	* <p>描述: 获取数据</p>
	* @param query
	* @return 名称
	* @author 才江男
	 */
	public String getResult(Query query){
		if(null == query) {
			return "";
		}
		List<String> list = query.list();
		if(CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}
		return "";
	}

	
	/**
	* <p>描述:获取集装箱规格名称</p>
	* @param cntnrModeCode
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("rawtypes")
	public String getCntnrModeByCode(String flag,String code) {
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String cntnrModeName = redisUtils.codeToName("Z_CCM_SIMPLELIST_4", code, flag);
		if(null == cntnrModeName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_SIMPLELIST_4 t where 1=1 and t.indexid=? and t.code=?";
			Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
			List list=query.list();
			session.close();
			cntnrModeName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return cntnrModeName;
	}
	
	/**
	* <p>描述:获取集装箱类型(箱型、种类)名称</p>
	* @param cntnrModeCode  ContainerType
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("rawtypes")
	public String getCntnrTypeByCode(String flag,String code) {
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String CntnrTypeName = redisUtils.codeToName("Z_BBD_ECIQSIMPLELIST", code, flag);
		if(null == CntnrTypeName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.ITEMNAME from Z_BBD_ECIQSIMPLELIST t where 1=1 and t.INDEXID=?  and t.ITEMCODE=?";
			Query query=session.createSQLQuery(sql).setParameter(0, flag).setParameter(1, code);
			List list=query.list();
			session.close();
			CntnrTypeName = Utils.notEmpty(list)?(String)list.get(0):"";
		}
		return CntnrTypeName;
	}
	
	
	//////////////////////////////////////////////
	
	/**
	 * 
	* <p>描述:人类传染病类等基础代码定义转名称</p>
	* <ul>
	* <li>(调用此方法,请在此头注释添加详细注释 如：动植物处理方法   ProductDwDetailMethd )
	* <li>Add  动植物处理方法      		  ProductDwDetailMethd
	* <li>Add  卫生除害处理方法    	  ProductDwDetailMethd
	* <li>Add  卫生检疫查验不合格原因      QuarUnqualifiedReason
	* <li>Add  货物检疫处理措施方法          ProductDwHandleMethd
	* </ul>
	* @param flag
	* @param code
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("rawtypes")
	public String getZCcmSimplelist9Entity(String indexId,String code){
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String CntnrTypeName;
		if (code.contains(",")) {
			String codes[] = code.split(",");
			String name;
			String names = "";
			for (int i = 0; i < codes.length; i++) {
				name = redisUtils.codeToName("Z_CCM_SIMPLELIST_9", codes[i], indexId);
				if (Utils.notEmpty(name)) {
					names += name + ",";
				}
			}
			CntnrTypeName = StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
		} else {
			String name = redisUtils.codeToName("Z_CCM_SIMPLELIST_9", code, indexId);
			CntnrTypeName = StringUtils.isNotEmpty(name) ? name : "";
		}
		
//		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
//		String sql="select t.CNAME from Z_CCM_SIMPLELIST_9 t where 1=1";
//		if(StringUtils.isNotEmpty(indexId)){
//			sql+=" and t.INDEXID=?";
//		}
//		
//		if(StringUtils.isNotEmpty(code)){
//			sql+=" and t.CODE=?";
//		}else {
//			return "";
//		}
//		List list=new ArrayList();
//		if (code.contains(",")) {
//			String codes[] = code.split(",");
//			String names = "";
//			for (int i = 0; i < codes.length; i++) {
//				list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, codes[i]).list();
//				if (Utils.notEmpty(list)) {
//					names += list.get(0) + ",";
//				}
//			}
//			session.close();
//			return StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
//		} else {
//			list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, code).list();
//		}
//		session.close();
//		return Utils.notEmpty(list)?(String)list.get(0):"";
		return CntnrTypeName;
	}
	
	
	/**
	 * 
	* <p>描述:ECIQ简单型通用列表</p>
	* <ul>(调用此方法,请在此头注释添加详细注释 如：动植物处理方法   ProductDwDetailMethd )
	* <li>Add  集装箱不合格原因       SuitableLoadProject   suitableLoadIns  
	* <li>Add  集装箱类别(种类)  ContainerType
	* </ul>
	* @param flag
	* @param code
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("rawtypes")
	public String getZBbdEciqsimplelistEntity(String indexId,String code,String condition) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.ITEMNAME from Z_BBD_ECIQSIMPLELIST t where 1=1";
		if(StringUtils.isNotEmpty(indexId)){
			sql+=" and t.INDEXID=?";
		}
		
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.ITEMCODE=?";
		}else {
			return "";
		}
		
		if(StringUtils.isNotEmpty(condition)){
			sql+=condition;
		}
		
		List list=new ArrayList();
		if(code.contains(",")){
			String codes[]=code.split(",");
			String names="";
			for(int i=0;i<codes.length;i++){
				list=session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, codes[i]).list();
				if(Utils.notEmpty(list)){
					names+=list.get(0)+",";
				}
			}
			session.close();
			return StringUtils.isNotEmpty(names)?names.substring(0, names.lastIndexOf(",")):"";
		}else{
			list=session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, code).list();
		}
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	
	/**
	 * 
	* <p>描述:变更原因、木质包装种类、疫情种类等</p>
	* <ul>
	* <li>(调用此方法,如需请在此头注释添加详细注释 如：动植物处理方法   ProductDwDetailMethd )
	* <li>Add  疫情种类类别       EpidemicSituatinoSor    
	* </ul>
	* @param flag
	* @param code
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("rawtypes")
	public String getZCcmSimplelist10Entity(String indexId, String code) {
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String CntnrTypeName;
		if (code.contains(",")) {
			String codes[] = code.split(",");
			String name;
			String names = "";
			for (int i = 0; i < codes.length; i++) {
				name = redisUtils.codeToName("Z_CCM_SIMPLELIST_10", codes[i], indexId);
				if (Utils.notEmpty(name)) {
					names += name + ",";
				}
			}
			CntnrTypeName = StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
		} else {
			String name = redisUtils.codeToName("Z_CCM_SIMPLELIST_10", code, indexId);
			CntnrTypeName = StringUtils.isNotEmpty(name) ? name : "";
		}
		return CntnrTypeName;
		
//		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
//		String sql = "select t.cname from Z_CCM_SIMPLELIST_10 t where 1=1";
//		if (StringUtils.isNotEmpty(indexId)) {
//			sql += " and t.indexid=?";
//		}
//
//		if (StringUtils.isNotEmpty(code)) {
//			sql += " and t.code=?";
//		} else {
//			return "";
//		}
//		List list=new ArrayList();
//		if (code.contains(",")) {
//			String codes[] = code.split(",");
//			String names = "";
//			for (int i = 0; i < codes.length; i++) {
//				list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, codes[i]).list();
//				if (Utils.notEmpty(list)) {
//					names += list.get(0) + ",";
//				}
//			}
//			session.close();
//			return StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
//		} else {
//			list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, code).list();
//		}
//		session.close();
//		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 
	* <p>描述:所需证单等</p>
	* <ul>
	* <li>( )
	* <li>Add  所需证单     IOFCertBillName    
	* </ul>
	* @param flag
	* @param code
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("rawtypes")
	public String getZCcmSimplelist5Entity(String indexId, String code) {
		if(StringUtils.isEmpty(code)){
			return "";
		}
		String CntnrTypeName;
		if (code.contains(",")) {
			String codes[] = code.split(",");
			String name;
			String names = "";
			for (int i = 0; i < codes.length; i++) {
				name = redisUtils.codeToName("Z_CCM_SIMPLELIST_5", codes[i], indexId);
				if (Utils.notEmpty(name)) {
					names += name + ",";
				}
			}
			CntnrTypeName = StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
		} else {
			String name = redisUtils.codeToName("Z_CCM_SIMPLELIST_5", code, indexId);
			CntnrTypeName = StringUtils.isNotEmpty(name) ? name : "";
		}
		return CntnrTypeName;
		
//		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
//		String sql = "select t.cname from Z_CCM_SIMPLELIST_5 t where 1=1";
//		if (StringUtils.isNotEmpty(indexId)) {
//			sql += " and t.indexid=?";
//		}
//
//		if (StringUtils.isNotEmpty(code)) {
//			sql += " and t.code=?";
//		} else {
//			return "";
//		}
//		List list=new ArrayList();
//		if (code.contains(",")) {
//			String codes[] = code.split(",");
//			String names = "";
//			for (int i = 0; i < codes.length; i++) {
//				list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, codes[i]).list();
//				if (Utils.notEmpty(list)) {
//					names += list.get(0) + ",";
//				}
//			}
//			session.close();
//			return StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
//		} else {
//			list = session.createSQLQuery(sql).setParameter(0, indexId).setParameter(1, code).list();
//		}
//		session.close();
//		return Utils.notEmpty(list)?(String)list.get(0):"";
	}
	
	/**
	 * 
	* <p>描述:工作内容串代码转名称</p>
	* @param insContCodes
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("rawtypes")
	public String insContCodesToName(String insContCodes){
		if(StringUtils.isNotEmpty(insContCodes)){
			if (insContCodes.contains(",")) {
				String codes[] = insContCodes.split(",");
				String names = "";
				for (int i = 0; i < codes.length; i++) {
					names+=CommonCodeToNameUtils.insContCodesToName(codes[i])+",";
				}
				return StringUtils.isNotEmpty(names) ? names.substring(0, names.lastIndexOf(",")) : "";
			} else {
				return CommonCodeToNameUtils.insContCodesToName(insContCodes);
			}
		}
		
		return "";
	}

	/**
	* <p>描述:原产地区转名称</p>
	* @param origPlaceCode
	* @return
	* @author 夏晨琳
	*/
	public String getOrigPlaceNameByCode(String code) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.ITEMNAME from Z_CCM_WORLDFIRSTDISTRICT t where 1=1";
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.ITEMCODE=?";
		}else {
			return "";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, code);
		List list=query.list();
		session.close();
		return  Utils.notEmpty(list)?(String)list.get(0):"";
	}

	/**
	* <p>描述:获取出境产地名称</p>
	* @param origPlaceCode
	* @return
	* @author 夏晨琳
	*/
	public String getplaceNameByCode(String code) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from  Z_BBD_CHN_ADMINDIVISION t where t.indexid ='Chinaregionalism' ";
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.ITEMCODE=?";
		}else {
			return "";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, code);
		List list=query.list();
		session.close();
		return  Utils.notEmpty(list)?(String)list.get(0):"";
	} 
	
}

/**  
 * FileName:    ShowDeclInfoDao.java 
 * @Description: 报检信息查看公告接口 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-5-13 下午3:18:56  
 *  
 */  
package com.rongji.eciq.mobile.dao.insp;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsPackEntity;
import com.rongji.eciq.mobile.entity.ZBbdHsCode;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 报检信息查看公告接口  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-15 下午4:52:22  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 20170419    魏波                             1.0         根据货物条数查询货物信息
 * 2017-07-07    才江男                        1.0         判断是否需要选择拼箱标志
 * 2017-09-20    才江男                        2.0         返回集装箱明细
 */
@Repository
public class ShowDeclInfoDao {

	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	
	/**
	 * 根据报检单号查询报检单基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclEntity> queryDclIoDeclList(String declNo, String expImpFlag) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<DclIoDeclEntity> list = dao.getQueryList(sql.toString(),param.toArray());
		if(Utils.notEmpty(list)){
			for(DclIoDeclEntity entity:list){
			}
		}
		return list;
	}

	/**
	 * 根据报检号查询货物基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsList(String declNo, String expImpFlag,String currentPage) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		Page page=MobileHelper.getPage(currentPage,"5");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		sql.append("order by t.goodsNo asc ");
		List<DclIoDeclGoodsEntity> list = dao.getQueryList(sql.toString(),page,param.toArray());
		return list;
	}
	
	/**
	 * 根据hs编码查hs实体
	 * @param hsCode
	 * @return
	 */
	public ZBbdHsCode queryZBbdHsCode(String hsCode) {
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM ZBbdHsCode t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(hsCode)){
			sql.append(" AND t.hsCode =?");
			param.add(hsCode);
		}
		List<ZBbdHsCode> list = dao.getQueryList(sql.toString(),param.toArray());
		if(CollectionUtils.isEmpty(list)){
			return null;
		}else{
			return list.get(0);
		}
		
	}
	
	/**
	 * 根据报检号和货物条数查询货物基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @param size
	 * @return
	 */
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsListBySize(String declNo, String expImpFlag,String currentPage,String size) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		Page page=MobileHelper.getPage(currentPage,size);
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		sql.append("order by t.goodsNo asc ");
		List<DclIoDeclGoodsEntity> list = dao.getQueryList(sql.toString(),page,param.toArray());
		return list;
	}

	/**
	 * 根据报检号查询集装箱基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclContEntity> queryDclIoDeclContList(String declNo, String expImpFlag) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclContEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<DclIoDeclContEntity> list = dao.getQueryList(sql.toString(),param.toArray());
		return list;
	}

	/**
	* <p>描述:判断是否需要选择拼箱标志</p>
	* @param declNo
	* @return
	* @author 才江男
	*/
	public List<DclIoDeclContDetailEntity> isNeesLclFlag(String declNo, String contId) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT * FROM DCL_IO_DECL_CONT_DETAIL M WHERE M.cont_Id=?";
		List<DclIoDeclContDetailEntity> list=session.createSQLQuery(sql).addEntity(DclIoDeclContDetailEntity.class).setParameter(0, contId).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:查询全部货物信息</p>
	* @param declNo
	* @param expImpFlag
	* @return
	* @author 夏晨琳
	*/
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsList(String declNo, String expImpFlag) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		sql.append("order by t.goodsNo asc ");
		List<DclIoDeclGoodsEntity> list = dao.getQueryList(sql.toString(),param.toArray());
		return list;
	}

	/**
	* <p>描述:</p>
	* @param declNo
	* @param goodsNo
	* @return
	* @author 夏晨琳
	*/
	public DclIoDeclGoodsPackEntity getDclGoodsPackName(String declNo, String goodsNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT * FROM DCL_IO_DECL_GOODS_PACK M WHERE M.DECL_NO=? and M.GOODS_NO = ?";
		List<DclIoDeclGoodsPackEntity> list=session.createSQLQuery(sql).addEntity(DclIoDeclGoodsPackEntity.class).setParameter(0,declNo).setParameter(1, goodsNo).list();
		session.close();
		return list.size()>0?list.get(0):new DclIoDeclGoodsPackEntity() ;
	}
	
}

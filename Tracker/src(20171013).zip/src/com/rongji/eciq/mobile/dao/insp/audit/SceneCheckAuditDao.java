/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-4-27 下午2:42:10  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.audit;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.dfish.framework.FrameworkHelper;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.server.entity.InsDeclMag;
import com.rongji.eciq.server.entity.InsDeclReview;
import com.rongji.eciq.server.entity.InsDeclReviewSt;

/**  
 * Description:   施检员复审，科长审核，处长审核DAO
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-27 下午2:42:10  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-27     才江男                        1.0         1.0 Version  
 * 2017-05-04            才江男		 1.0                            增加审核更新及查找审核记录
 * 2017-05-11            才江男		 1.0                            批量审核      
 * 2017-05-13            才江男		 1.0                            审核记录排序                 
 * 2017-05-16    魏波                                 1.0        审核查询添加出入境标示  
 * 2017-05-27            才江男		 1.0                            审核不通过   
 * 2017-06-16            才江男		 1.0                            评定后不可见                   
 */
@Repository
public class SceneCheckAuditDao {
	
	PubCommonDAO dao = FrameworkHelper.getDAO();
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	@Autowired
	HibernateTemplate hibernateTemplate;

	/**
	* <p>描述:获取需审核的数据</p>
	* @param flag 审核环节
	* @param orgCode 机构代码
	* @param declNo 报检单号
	* @param currentPage 分页
	* @return 审核的数据
	* @author 才江男
	 */
	public List<InsDeclMag> getMagList(String flag, String orgCode, String declNo, String currentPage,String expImpFlag) {
		StringBuilder sql = new StringBuilder();
		List<String> param = new ArrayList<String>();

		sql.append("select t FROM InsDeclMag t, InsDeclReview r  where t.declNo = r.declNo ");
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo = ?");
			param.add(declNo);
		}
		if (StringUtils.isNotEmpty(orgCode)) {
			sql.append(" AND t.exeInspOrgCode  = ?");
			param.add( orgCode);
		}
		if(StringUtils.isNotEmpty(expImpFlag)){
			sql.append(" AND t.expImpFlag = ?");
			param.add(expImpFlag);
		}
		//改为只查当前环节的
		if (StringUtils.isNotEmpty(flag)) {
			if("1".equals(flag)) {
				sql.append(" AND r.processStatus = ?");
				param.add( flag);
			} else if ("2".equals(flag)){
				sql.append(" AND r.processStatus in ('2')");
			} else if ("3".equals(flag)){
				sql.append(" AND r.processStatus in ('3')");
			}
		}
		sql.append(" AND (r.isAudit <> '2' or r.isAudit is null)");
		if(StringUtils.isEmpty(currentPage)) {
			currentPage = "1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<InsDeclMag> list=dao.getQueryList(sql.toString(), page, param.toArray());
		if(!CollectionUtils.isEmpty(list)){
			for(int i=0;i<list.size();i++){
				chgHibernateTemplate.evict(list.get(i));
				String pushString=getTradeCountryCodeByDeclNo(list.get(i).getDeclNo());
				list.get(i).setRemark(getTradeCountryNameByCode(pushString));
			}
				
		}
		return list;
	}
	
	/**
	* <p>描述: 获取审核记录</p>
	* @param declNo 报检单号
	* @return 审核记录
	* @author 才江男
	 */
	public List<InsDeclReviewSt> getAuditList(String declNo) {
		StringBuilder sql = new StringBuilder();
		List<String> param = new ArrayList<String>();
		sql.append("FROM InsDeclReviewSt t  where 1 = 1");
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo = ?");
			param.add(declNo);
		} else {
			return null;
		}
		sql.append(" order by t.auditTime");
		List<InsDeclReviewSt> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}
	
	/**
	 * 根据报检单号查询贸易国别
	 */
	public String getTradeCountryCodeByDeclNo(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.trade_country_code from dcl_io_decl t where 1=1";
		if(StringUtils.isNotEmpty(declNo)){
			sql+=" and t.DECL_NO=?";
		} else {
			return declNo;
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		return com.rongji.dfish.base.Utils.notEmpty(list)? (String)list.get(0): "";
	} 

	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	public String getTradeCountryNameByCode(String code){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from Z_CCM_WORLDDISTRICT t where 1=1";
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.itemcode=?";
		} else {
			return code;
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, code);
		List list=query.list();
		session.close();
		return (String)list.get(0);
	}
	
	/**
	* <p>描述: 保存审核记录</p>
	* @param review 审核记录
	* @author 才江男
	 */
	public void saveAudit(Object review) {
		dao.saveObject(review);
	}
	
	/**
	* <p>描述: 更新审核记录</p>
	* @param review 审核记录
	* @author 才江男
	 */
	public void updateAudit(Object review) {
		dao.updateObject(review);
	}
	
	/**
	* <p>描述: 批量查找审核</p>
	* @param declNo 报检号
	* @return 审核
	* @author 才江男
	 */
	public List<InsDeclReview> findAuditByDeclNo(List<String> declNo) {
		
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		String sql="FROM InsDeclReview t  where t.declNo in (:list) and t.processStatus <> '4' order by operTime desc";
		Query query=session.createQuery(sql).setParameterList("list", declNo);
		List<InsDeclReview> list=query.list();
		session.close();
		return list;
	}
	
	/**
	* <p>描述: 查找审核</p>
	* @param declNo 报检号
	* @return 审核
	* @author 才江男
	 */
	public InsDeclReview findAuditByDeclNo(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append("FROM InsDeclReview t  where t.declNo = ? order by operTime desc");
		List<InsDeclReview> list=dao.getQueryList(sql.toString(), declNo);
		if(CollectionUtils.isEmpty(list)) {
			return null;
		}
		return list.get(0);
	}
	
	/**
	 * 审核不通过
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void auditFail(String declNo, String receiverDocCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG T SET CHECK_PRIV='1',REGI_PRIV='0' WHERE T.DECL_NO = ? AND T.RECEIVER_DOC_CODE = ?";
		session.createSQLQuery(sql).setParameter(0, declNo).setParameter(1, receiverDocCode).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 评定后，不可见
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void registerEval(String declNo, String receiverDocCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG T SET CHECK_PRIV='0',REGI_PRIV='0' WHERE T.DECL_NO = ? AND T.RECEIVER_DOC_CODE = ?";
		session.createSQLQuery(sql).setParameter(0, declNo).setParameter(1, receiverDocCode).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	
}

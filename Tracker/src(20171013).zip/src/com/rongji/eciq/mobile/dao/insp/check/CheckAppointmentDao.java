/**  
 * FileName: CheckAppointmentDao.java    
 * @Description: 查验预约dao
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年6月27日 下午5:57:26  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.check;
import java.util.List;
import java.text.ParseException;
import java.util.ArrayList;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.InsCheckAppointInfoEntity;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.dfish.base.DateUtil;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.utils.MobileHelper;

/**
 * 
 * Description: 查验预约dao 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-7-7 上午10:08:51  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-7-7      李云龙                      1.0          添加查询，更新，删除，撤销等方法
 * 2017-7-7      李云龙                      1.0          修改预约-查询
 * 2017-07-21    吴有根                      1.0          增加根据报检单位注册号带出企业基本信息
 */
@Repository
public class CheckAppointmentDao {

	PubCommonDAO dao = FrameworkHelper.getChgDAO();

	@Autowired
	HibernateTemplate hibernateTemplate;

	/**
	 * <p>
	 * 描述:查验预约-查询
	 * </p>
	 * 
	 * @param declNo
	 * @param declRegNo
	 * @param declRegName
	 * @param startApplyTime
	 * @param endApplyTime
	 * @param applyStatus
	 * @param acceptResult
	 * @return
	 * @author 吴有根
	 */
	public List<InsCheckAppointInfoEntity> getAppointInfo(String declNo, String declRegNo, String declRegName,
			String startTime,String endTime, String applyStatus, String acceptResult, String exeInspOrgCode,
			String type,String currentPage,String entOrgCode) {
		
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM InsCheckAppointInfoEntity t where  1=1 ");
		List<Object> param = new ArrayList<Object>();
		if(StringUtils.isNotEmpty(exeInspOrgCode)) {
			sql.append(" AND t.inspOrgCode like?");
			String orgCode = exeInspOrgCode.substring(0,2)+"%";
			param.add(orgCode);
		}
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}

		if (StringUtils.isNotEmpty(declRegNo)) {
			sql.append(" AND t.declRegNo =?");
			param.add(declRegNo);
		}
		
		if (StringUtils.isNotEmpty(entOrgCode)) {
			sql.append(" AND t.entOrgCode =?");
			param.add(entOrgCode);
		}

		if (StringUtils.isNotEmpty(declRegName)) {
			sql.append(" AND t.declRegName like ?");
			param.add("%" + declRegName + "%");
		}

		if (StringUtils.isNotEmpty(startTime)) {
			sql.append(" AND t.applyTime >?");
			try {
				param.add(DateUtil.parse(startTime));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		if (StringUtils.isNotEmpty(endTime)) {
			sql.append(" AND t.applyTime < ?");
			try {
				param.add(DateUtil.parse(endTime));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		if (StringUtils.isNotEmpty(applyStatus)) {
			sql.append(" AND t.applyStatus =?");
			param.add(applyStatus);
		}

		if (StringUtils.isNotEmpty(acceptResult)) {
			sql.append(" AND t.acceptResult =?");
			param.add(acceptResult);
		}

		if (StringUtils.isNotEmpty(type)) {
			if(type.equals("1")){
				sql.append(" AND (t.applyStatus ='1'  or t.applyStatus ='2') ");
			}else if(type.equals("2")){
				sql.append(" AND t.applyStatus !='0'");
			}
		}

		
		sql.append(" ORDER BY t.applyTime");


		if (StringUtils.isEmpty(currentPage)) {
			currentPage = "1";
		}

		Page page = MobileHelper.getPage(currentPage, "10");
		@SuppressWarnings("unchecked")
		List<InsCheckAppointInfoEntity> list = dao.getQueryList(sql.toString(), page, param.toArray());
		return list;
	}

	
	/**
	 * 
	 * <p>
	 * 描述:查询查验预约信息
	 * </p>
	 * 
	 * @return
	 * @author 李云龙
	 */
	public InsCheckAppointInfoEntity getInsCheckAppointInfoEntity(String applyId) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT * FROM  INS_CHECK_APPOINT_INFO WHERE APPLY_ID='" + applyId + "'";
		List<InsCheckAppointInfoEntity> list = session.createSQLQuery(sql).addEntity(InsCheckAppointInfoEntity.class)
				.list();
		if (CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * 保存查验信息
	 * <p>
	 * 描述:保存查验信息
	 * </p>
	 * 
	 * @param insCheckAppointInfoEntity
	 * @author 李云龙
	 */
	@Autowired
	HibernateTemplate chgHibernateTemplate;

	public void saveInsCheckAppointInfoEntity(InsCheckAppointInfoEntity insCheckAppointInfoEntity) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.saveOrUpdate(insCheckAppointInfoEntity);
		session.getTransaction().commit();
		session.flush();
		session.close();
	}

	/**
	 * 
	 * <p>
	 * 描述:更新查验信息
	 * </p>
	 * 
	 * @param insCheckAppointInfoEntity
	 * @author 李云龙
	 */
	public void updateInsCheckAppointInfoEntity(String applyStatus, String declNo) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_CHECK_APPOINT_INFO SET APPLY_STATUS='" + applyStatus + "' WHERE DECL_NO='" + declNo+"'";
		Query query = session.createSQLQuery(sql);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 
	* <p>描述:获取最大申请单号</p>
	* @return
	* @author 李云龙
	 */
	public String getMaxApplyNo() {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql ="SELECT MAX(APPLY_NO) FROM  INS_CHECK_APPOINT_INFO ";
		List<String> list = session.createSQLQuery(sql).list();
		session.close();
		if(CollectionUtils.isNotEmpty(list)){
			return list.get(0).toString();
		}
		return null;
		
	}
	
	
	/**
	 * 
	 * <p>
	 * 描述:提交查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void submitInsCheckAppointInfoEntity(String applyId) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_CHECK_APPOINT_INFO SET APPLY_STATUS='1' WHERE APPLY_ID='" + applyId+ "'";
		Query query = session.createSQLQuery(sql);
        query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 
	 * <p>
	 * 描述:撤销查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void cancelInsCheckAppointInfoEntity(String applyId) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_CHECK_APPOINT_INFO SET APPLY_TYPE='2' WHERE APPLY_ID='" + applyId+ "'";
		Query query = session.createSQLQuery(sql);
        query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 
	 * <p>
	 * 描述:删除查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void deleteInsCheckAppointInfoEntity(String applyId) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "DELETE INS_CHECK_APPOINT_INFO WHERE APPLY_ID='" + applyId+ "'";
		Query query = session.createSQLQuery(sql);
        query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 
	 * <p>
	 * 描述:获取查验预约信息
	 * </p>
	 * 
	 * @return
	 * @author 李云龙
	 */
	public List<InsCheckAppointInfoEntity> getInsCheckAppointInfoEntityList(String declNo) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT * FROM  INS_CHECK_APPOINT_INFO WHERE DECL_NO='" + declNo + "'";
		List<InsCheckAppointInfoEntity> list = session.createSQLQuery(sql).addEntity(InsCheckAppointInfoEntity.class).list();
		return list;
	}
	
	/**
	 * 
	* <p>描述:</p>
	* @return
	* @author 李云龙
	 */
	public EntBaseInfoEntity getEntBaseInfoEntity(String declRegNo){
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT * FROM  ENT_BASE_INFO WHERE DECL_REG_NO='" + declRegNo + "'";
		List<EntBaseInfoEntity> list = session.createSQLQuery(sql).addEntity(EntBaseInfoEntity.class).list();
		session.close();
		if(CollectionUtils.isNotEmpty(list)){
			return list.get(0);
		}
		return null;
	}


	/**
	* <p>描述:输入报检单位注册号查询基本信息</p>
	* @param declRegNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public EntBaseInfoEntity loadCheckAppointBaseInfo(String declRegNo, String declNo) {
		StringBuilder sql = new StringBuilder();
		List<String> param = new ArrayList<String>();
		List<EntBaseInfoEntity> list = null;
		if (StringUtils.isEmpty(declNo) && StringUtils.isNotEmpty(declRegNo)) {// 按报检单位注册号查询
			sql.append("FROM EntBaseInfoEntity t where 1=1 AND t.declRegNo=? ");
			param.add(declRegNo);
			list = dao.getQueryList(sql.toString(), param.toArray());
		} else if (StringUtils.isNotEmpty(declNo)) {
			String sql2 = "SELECT E.* "
							+ " FROM DCL_IO_DECL T, ENT_BASE_INFO E" 
							+ " WHERE T.DECL_REG_NO = E.DECL_REG_NO"
							+ " AND T.DECL_NO = ? ";
			Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			list = session.createSQLQuery(sql2).addEntity(EntBaseInfoEntity.class).setParameter(0, declNo).list();
			session.close();
		} else {
			return null;
		}
		return Utils.notEmpty(list) ? list.get(0) : null;
	}


	/**
	* <p>描述:获取申请单号</p>
	* @param entOrgCode
	* @author 吴有根
	*/
	public List<String> getApplyNoRul(String entOrgCode) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql ="SELECT T.APPLY_NO FROM  INS_CHECK_APPOINT_INFO T WHERE T.APPLY_NO LIKE ? ";
		@SuppressWarnings("unchecked")
		List<String> list = session.createSQLQuery(sql).setParameter(0, entOrgCode+"%").list();
		session.close();
		return list;
		
	}

}

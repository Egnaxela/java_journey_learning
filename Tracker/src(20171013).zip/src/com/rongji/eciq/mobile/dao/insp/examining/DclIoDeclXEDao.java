package com.rongji.eciq.mobile.dao.insp.examining;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.model.insp.examining.DclIoDeclXEModel;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * Description     审单查看数据初始化dao
 * @author 		           魏波    
 * @version        1.0
 *
 */
@Repository
public class DclIoDeclXEDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	/**
	 * 根据报检单号获取拓展表信息
	 * @param declNo
	 * @return
	 */
	public List<DclIoDeclEx> getDclIoDeclXEModel(String declNo){
		DclIoDeclXEModel model = new DclIoDeclXEModel();
		StringBuilder sql = new StringBuilder();
		List<String> param=new ArrayList<String>();
		DclIoDeclEx ex = new DclIoDeclEx();
		List<DclIoDeclEx> list = new ArrayList<DclIoDeclEx>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append("SELECT t FROM DclIoDeclEx t where  t.declNo=? ");
			param.add(declNo);
			list = dao.getQueryList(sql.toString(),param.toArray());
		}
		return list;
	}
}

/**  
 * FileName:  EntCategoryDao.java
 * @Description: 法定抽批规则数据初始化dao
 * Company       rongji
 * @version      1.0
 * @author:      魏波 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.insp.examining;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 法定抽批规则数据初始化dao  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波    
 * @version:    1.0  
 * Create at:   2017-5-15 下午5:09:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                 1.0         1.0 Version
 */
@Repository
public class EntCategoryDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	String IN_FLAG = "1";//入境
	String OUT_FLAG = "2";//出境
	
	/**
     * 根据生产单位注册号,出入境标记,获得企业分类等级
     *
     * @param declRegNo 生产单位注册号
     * @param expImpFlag 出入境号码
     * @return
     *
     */
    public String getEntCategory(String declRegNo, String expImpFlag) {
    	String entCategory = "";
        Object obs[] = new Object[2];
    	StringBuilder sql = new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("select t.expEntCategory, t.impEntCategory from SupEntClassify t where t.declRegNo =?");
		param.add(declRegNo);
		List list = dao.getQueryList(sql.toString(),param.toArray());
		if (list != null && list.size() > 0) {
            obs = (Object[]) list.get(0);
        }
        if (StringUtils.equals(expImpFlag, OUT_FLAG)) {
            entCategory = (String) obs[0];
        } else if (StringUtils.equals(expImpFlag,IN_FLAG )) {
            entCategory = (String) obs[1];
        }
        return entCategory;
    }
    
    /**
   	 * 根据生产单位注册号,出入境标记,ciq编码获得产品风险等级
   	 * 
   	 * @param ciqCode
   	 *            CIQ编码
   	 * @param declRegNo
   	 *            生产单位注册号
   	 * @param expImpFlag
   	 *            出入境号码
   	 * @return
   	 * 
   	 */
   	public String getRiskGradeCode(String declRegNo, String expImpFlag,String ciqCode) {
   		
   		String riskGradeCode = "";
   		StringBuilder sql = new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("select t.riskGradeCode from SupEntAttribute t where t.declRegNo =?");
		param.add(declRegNo);
		sql.append(" and t.expImpFlag = ?");
		param.add(expImpFlag);
		sql.append(" and t.ciqCode = ?");
		param.add(ciqCode);
		List list = dao.getQueryList(sql.toString(),param.toArray());
		if (list != null && list.size() > 0) {
			riskGradeCode = (String) list.get(0);
		}
		return riskGradeCode;
   	}
}

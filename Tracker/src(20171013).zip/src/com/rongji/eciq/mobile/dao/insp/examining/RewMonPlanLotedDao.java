/**  
 * FileName:  RewMonPlanLotedDao.java
 * @Description: 风险监控数据初始化dao
 * Company       rongji
 * @version      1.0
 * @author:      魏波 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.insp.examining;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.RewMonPlanCycStatus;
import com.rongji.eciq.mobile.entity.RewMonPlanLotedVo;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 风险监控数据初始化dao  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波    
 * @version:    1.0  
 * Create at:   2017-5-15 下午5:07:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                        1.0         1.0 Version
 */
@Repository
public class RewMonPlanLotedDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	String REASOM_NOPLAN = "1";//风险监控抽中原因-未找到规划]编码
	String REASOM_TO_NUMPLAN = "7";//[风险监控抽中原因-抽中次数已满足]编码
	
	  /**
     * 取得报检命中的规划
     * @param declNo 报检单
     * @param goodsNo 货物序号
     * @return 命中规划list
     */
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	public List<RewMonPlanLotedVo> getRewMonPlanLotedModel(String declNo,String goodsNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql = new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("select m.*,t.MON_PLAN_NAME,t.MON_CYCLE,t.IS_EXE_NUM_EFFECT,t.EXECUT_PLAN_TM,t.EXP_IMP_FLAG from Rew_Mon_Decl_Hit_Plan m,REW_MON_PLAN t where m.decl_No= ?");
//		param.add(declNo);
		sql.append(" and m.goods_No= ?");
//		param.add(goodsNo);
		sql.append(" and t.MON_PLAN_ID=m.MON_PLAN_ID and m.PITCH_ON_REASON<> ?");
//		param.add(REASOM_NOPLAN);
		sql.append(" and m.PITCH_ON_REASON<> ?");
//		param.add(REASOM_TO_NUMPLAN);
		List<RewMonPlanLotedVo> list=session.createSQLQuery(sql.toString()).addEntity(RewMonPlanLotedVo.class).setParameter(0, declNo).setParameter(1,goodsNo).setParameter(2, REASOM_NOPLAN).setParameter(3, REASOM_TO_NUMPLAN).list();
//		list = dao.getQueryList(sql.toString(),param.toArray());
		session.close();
//		return list;
	    return list;
	}
	
	 /**
     * 根据规划id取得周期信息
     *
     * @param planId
     * @return
     */
	 public List<RewMonPlanCycStatus> getRewStatusById(String planId, String entCode) {
		 StringBuilder sql = new StringBuilder();
		 List<String> param=new ArrayList<String>();
		 sql.append("select model from RewMonPlanCycStatus model where model.monPlanId = ?");
		 param.add(planId);
		 if(StringUtils.isNotEmpty(entCode)){
			 sql.append(" and model.entMgrNo = ?");
			 param.add(entCode);
		 }
		 sql.append(" order by model.cycleBeginTime desc");
		 List<RewMonPlanCycStatus> list = dao.getQueryList(sql.toString(),param.toArray());
		 return list;
	 }
}

/**  
 * FileName:  SubAuditDao.java
 * @Description: 施检员审单查看数据初始化dao
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.insp.examining;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.sys.utils.RedisUtils;

/**
 * 
 * Description: 施检员审单查看数据初始化dao 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017-5-15 下午5:06:06  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 20170411    李晨阳                  1.0        新增功能-查询查验项目
 * 20170427    吴有根                  1.0        审单退单、分单退单操作 
 * 20170512    魏波                      1.0        根据报检单号查第一条货物的名称
 * 2017-06-13     李晨阳                         1.0.0         整理代码，代码转名称替换为redis缓存
 * 20170626    吴有根                   1.0        多条货物显示提示修改
 */
@Repository
public class SubAuditDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	@Resource
	RedisUtils redisUtils;
	
	/**
	 * 根据参数查询施检员审单查看的数据
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	public List<SubOrReasEntity> getSubAuditList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SubOrReasEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.expImpFlag =?");
		param.add(expImpFlag);
		sql.append(" AND t.exeInspOrgCode =?");
		param.add(exeInspOrgCode);
		sql.append(" AND t.receiverDocCode =?");
		param.add(receiverDocCode);
		sql.append(" AND t.auditPriv =?");
		param.add(CommContext.Y); 
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(declRegName)){
			sql.append(" AND t.declRegName like ?");
			param.add("‘%"+declRegName+"%’");
		}
		
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<SubOrReasEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
	
		if(!CollectionUtils.isEmpty(list)){
			for(int i=0;i<list.size();i++){
				chgHibernateTemplate.evict(list.get(i));
				String pushString=getTradeCountryCodeByDeclNo(list.get(i).getDeclNo());
				list.get(i).setRemark(getTradeCountryNameByCode(pushString));
			}
		}
		return list;
	}


	
	/**
	 * 根据报检单号查询贸易国别
	 */
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	public String getTradeCountryCodeByDeclNo(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.trade_country_code from dcl_io_decl t where 1=1";
		if(StringUtils.isNotEmpty(declNo)){
			sql+=" and t.DECL_NO=?";
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		if(CollectionUtils.isEmpty(list)) {
			return "";
		}
		return (String) list.get(0);
	} 

	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	public String getTradeCountryNameByCode(String code){
		if(StringUtils.isEmpty(code)){
			return null;
		}
		String TradeCountryName = redisUtils.codeToName("Z_CCM_WORLDDISTRICT", code, "WorldDistrict");
		if(null == TradeCountryName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_WORLDDISTRICT t where 1=1 and t.itemcode=?";
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
			TradeCountryName = (String)list.get(0);
		}
		return TradeCountryName;
	} 
	
	/**
     * 根据报检单号 查询出查验项目列表
     *
     * @param declNo
     * @return
     */
    public List<InsCheckItemEntity> getInsCheckItemList(String declNo, Integer goodsNo, String type) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "SELECT A.CHECK_ITEM_ID,"
                + "A.DECL_NO,"
                + "A.GOODS_NO,"
                + "DECODE(A.NODE_CODE,null,sys_guid(),A.NODE_CODE) as NODE_CODE,"
                + "A.CHECK_ITEM_CODE,"
                + "A.CHECK_ITEM_NAME,"
                + "A.CHECK_ITEM_RESULT_CODE,"
                + "DECODE(A.PARENT_ITEM_CODE,null,'root',A.PARENT_ITEM_CODE) as PARENT_ITEM_CODE ,"
                + "A.CHECK_GOODS_TYPE,"
                + "A.PARENT_ITEM_NAME,"
                + "A.BATCH_DESC,"
                + "A.INSP_PROC_STATUS,"
                + "A.FALG_ARCHIVE,"
                + "A.SC_ORG_CODE,"
                + "A.SC_OPERATOR_CODE,"
                + "A.OPER_TIME,"
                + "A.SAMPLE_SCH,"
                + "A.ITEM_TYPE_CODE,"
                + "A.ADD_INPUT_FLAG,"
                + "A.CHECK_CONT,"
                + "A.WHETHER_QUALFY,"
                + "A.ARCHIVE_TIME,"
                + "A.CHECK_FORM_CODE "
//                + "B.FORM_NAME as IS_APP_FLAG "
                + "FROM INS_CHECK_ITEM A  "
//                + "ON A.CHECK_FORM_CODE = B.CHECK_FORM_CODE "
                + "WHERE A.DECL_NO = :DECLNO "
                + "AND (A.GOODS_NO = :GOODSNO or A.GOODS_NO is null) AND A.ITEM_TYPE_CODE = :TYPE ";
    	List<InsCheckItemEntity> list=session.createSQLQuery(sql).addEntity(InsCheckItemEntity.class).setParameter("DECLNO", declNo).setParameter("GOODSNO", goodsNo).setParameter("TYPE", type).list();
		session.close();
		return list;
    }

	/**
	* <p>描述:获取报检单管理表的基本信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public SubOrReasEntity getInsDeclMagByNo(String declNo, String flowPathStatus,String userOrgCode,String ...receiverDocCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SubOrReasEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		if(receiverDocCode!=null&&receiverDocCode.length>0){
			sql.append(" AND t.receiverDocCode =?");
			param.add(receiverDocCode[0]);
		}
		sql.append(" AND t.flowPathStatus =?");
		param.add(flowPathStatus);
		sql.append(" AND t.exeInspOrgCode=?");
		param.add(userOrgCode);
		List<SubOrReasEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		if(list.size()!=1){
			return null;
		}
		return Utils.notEmpty(list)?list.get(0):null;
	}

	
	
	/**
	* <p>描述:根据报检单管理表ID删除记录</p>
	* @param declMagId
	* @author 吴有根
	*/
	public void dltInsDelMagById(String declMagId) {
        String sql = "delete from  ins_decl_mag i where i.decl_mag_id = ?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
        Query query = session.createSQLQuery(sql).setParameter(0, declMagId);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
	}

	/**
	* <p>描述:根据报检单号获取管理表实体</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsDeclMagEntity> findInsDeclMagByFlowType2(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM InsDeclMagEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		List<InsDeclMagEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	* <p>描述:更新是否存在辅施检</p>
	* @param declNo
	* @param b
	* @author 吴有根
	*/
	public void updateIsHaveAux(String declNo, boolean b) {
        String sql = "update ins_decl_mag i set i.IS_HAVE_AUX = ? where i.decl_no = ?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
        Query query = session.createSQLQuery(sql).setParameter(0, b?CommContext.Y:CommContext.N).setParameter(1, declNo);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();		
	}

	/**
	* <p>描述:根据报检单管理表ID清空接单人代码,分单标记</p>
	* @param declMagId
	* @author 吴有根
	*/
	public void clearRecCodeById2(String declMagId) {
        String sql = "update ins_decl_mag i set i.receiver_doc_code = '',"
                + "i.SUB_TYPE = ? where i.decl_mag_id = ?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
        Query query = session.createSQLQuery(sql).setParameter(0, InsContext.SUBMENU_TYPE_NOT_SUB).setParameter(1, declMagId);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
	}

	/**
	* <p>描述:更新退单原因最新的记录</p>
	* @param declMagId
	* @param returnReason
	* @author 吴有根
	*/
	public void updateBackReason(String declMagId, String returnReason) {
	     String sql = "update ins_decl_mag i set i.RET_REASON = ? where i.decl_mag_id = ?";
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			session.beginTransaction();
	        Query query = session.createSQLQuery(sql).setParameter(0, returnReason).setParameter(1, declMagId);
	        query.executeUpdate();
	        session.getTransaction().commit();
	        session.close();		
	}
	
	/**
	 * 
	* <p>描述:更加报检单号查货物名</p>
	* @param declNo
	* @return
	* @author 魏波
	 */
	public String getGoodName(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.DECL_GOODS_CNAME from DCL_IO_DECL_GOODS t where 1=1";
		if(StringUtils.isNotEmpty(declNo)){
			sql+=" and t.DECL_NO=?";
		}
		//sql+=" and t.GOODS_NO='1'";
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		if(CollectionUtils.isEmpty(list)) {
			return "";
		}
		//return (String) list.get(0); 
		return list.size()>1?(String)list.get(0)+"...":(String)list.get(0);
	}
	
	/**
	 * 根据报检号查验报检单结果基本信息
	 * @param declNo
	 * @return
	 */
	public List<DclIoDeclEntity> getDclIoDeclEntity(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<String> params=new ArrayList<String>();
		sql.append("FROM DclIoDeclEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		List<DclIoDeclEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}
}

/**  
 * FileName:    ResultRegisterDao.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-5-9 下午7:42:50  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.result;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.dao.insp.scene.SceneDao;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-5-9 下午7:42:50  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-9      才江男                      1.0         1.0 Version  
 */

@Repository
public class ResultRegisterDao {

	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	@Autowired
	HibernateTemplate hibernateTemplate;
	@Resource
	SceneDao sceneDao;
	
	/**
	 * 结果登记初始化查询
	 * @param expImpFlag  出入境标志
	 * @param exeInspOrgCode 所在部门
	 * @param receiverDocCode 接单员
	 * @param declNo 报检号
	 * @param declRegName 报检单位名称
	 * @param currentPage 页号
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SubOrReasEntity> getMagList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SubOrReasEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.expImpFlag =?");
		param.add(expImpFlag);
		sql.append(" AND t.exeInspOrgCode =?");
		param.add(exeInspOrgCode);
		sql.append(" AND t.receiverDocCode =?");
		param.add(receiverDocCode);
		sql.append(" AND t.regiPriv =?");
		param.add(CommContext.Y); 
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(declRegName)){
			sql.append(" AND t.declRegName like ?");
			param.add("%"+declRegName+"%");
		}
		sql.append(" ORDER BY t.declDate");
		
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<SubOrReasEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
	
		if(!CollectionUtils.isEmpty(list)){
			for(int i=0;i<list.size();i++){
				hibernateTemplate.evict(list.get(i));
				String pushString=sceneDao.getTradeCountryCodeByDeclNo(list.get(i).getDeclNo());
				list.get(i).setRemark(sceneDao.getTradeCountryNameByCode(pushString));
			}
		}
		return list;
	}
	
}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-10 下午3:23:47  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.scene;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsDeptDefTemplate;
import com.rongji.eciq.mobile.entity.InsTemplate;
import com.rongji.eciq.mobile.entity.InsTemplateSub;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-10 下午3:23:47  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-10      夏晨琳                      1.0         1.0 Version  
 */
@Repository
public class InsTemplateDao {
	
	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;

	/**
	* <p>描述:查询集合</p>
	* @param orgCode
	* @param expImpFlag
	* @param templateType
	* @return
	* @author 夏晨琳
	 * @param page 
	 * @param templateTitle 
	*/
	public List<InsTemplate> searchCheckTempListByUser(String expImpFlag, String templateType, Page page, String templateTitle) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct m from InsTemplate m,InsTemplateSub s where  m.templateId=s.templateId  ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(expImpFlag)){
			sql.append(" and m.expImpFlag=? ");
			param.add(expImpFlag);
		}
		if(StringUtils.isNotEmpty(templateType)){
			sql.append(" and m.templateType=? ");
			param.add(templateType);
		}
		sql.append(" and m.whetherEffect= 1 ");
		if(StringUtils.isNotEmpty(templateTitle)){
			sql.append("  and m.templateTitle like ? ");
			param.add("%"+templateTitle+"%");
		}
		List<InsTemplate> list = dao.getQueryList(sql.toString(),page,param.toArray());
		return list;
	}

	/**
	* <p>描述:模板维护查询集合</p>
	* @param templateTitle
	* @param whetherEffect
	* @param orgCodes
	* @return
	* @author 夏晨琳
	 * @param page 
	*/
	public List<InsTemplate> searchCheckTempList(String templateTitle, String whetherEffect, String orgCodes, Page page) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct m from InsTemplate m ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(whetherEffect)){
			sql.append(" and m.whetherEffect=? ");
			param.add(whetherEffect);
		}
		if(StringUtils.isNotEmpty(orgCodes)){
			sql.append(" and m.operDeptCode in ? ");
			param.add("("+orgCodes+")");
		}
		if(StringUtils.isNotEmpty(templateTitle)){
			sql.append("  and s.useDeptCode like ? ");
			param.add("%"+templateTitle+"%");
		}
		List<InsTemplate> list = dao.getQueryList(sql.toString(),page,param.toArray());
		return list;
	}

	/**
	* <p>描述:获取模板对象</p>
	* @param templateId
	* @return
	* @author 夏晨琳
	*/
	public InsTemplate getInsTemplate(String templateId) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct m from InsTemplate m where 1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(templateId)){
			sql.append(" and m.templateId=? ");
			param.add(templateId);
		}
		List<InsTemplate> list = dao.getQueryList(sql.toString(),param.toArray());
		return list.size()>0?list.get(0):null;
	}

	/**
	* <p>描述:模板删除</p>
	* @param templateId
	* @author 夏晨琳
	*/
	public void deleteInsTemplate(String templateId) {
		InsTemplate tem = getInsTemplate(templateId);
		dao.delete(tem);
	}

	/**
	* <p>描述:删除子模板信息</p>
	* @param templateId
	* @author 夏晨琳
	*/
	public void deleteSubTemplate(String templateId) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "DELETE FROM INS_TEMPLATE_SUB where TEMPLATE_ID = ?";
		session.createSQLQuery(sql).setParameter(0, templateId).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:获取子模板集合</p>
	* @param templateId
	* @author 夏晨琳
	 * @return 
	*/
	public List<InsTemplateSub> getInsTemplateSubList(String templateId) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct m from InsTemplateSub m where 1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(templateId)){
			sql.append(" and m.templateId=? ");
			param.add(templateId);
		}
		List<InsTemplateSub> list = dao.getQueryList(sql.toString(),param.toArray());
		return list;
	}

	/**
	* <p>描述:保存或者更新模板</p>
	* @param template
	* @param boo
	* @author 夏晨琳
	*/
	public void saveOrUpdateTemp(InsTemplate template, boolean boo) {
		if(boo){
			dao.saveObject(template);
		}else{
			dao.updateObject(template);
		}
	}

	/**
	* <p>描述:删除模板对应的部门信息</p>
	* @param templateId
	* @author 夏晨琳
	*/
	public void deleteDefTemplate(String templateId) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "DELETE FROM INS_DEPT_DEF_TEMPLATE where TEMPLATE_ID = ?";
		session.createSQLQuery(sql).setParameter(0, templateId).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:查询部门是否存在默认</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	*/
	public List<InsDeptDefTemplate> getDefTemplateEntity(String orgCode) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct m from InsDeptDefTemplate m where 1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" and m.defDeptCode=? ");
			param.add(orgCode);
		}
		List<InsDeptDefTemplate> list = dao.getQueryList(sql.toString(),param.toArray());
		return list;
	}

	/**
	* <p>描述:更新默认模板</p>
	* @param def
	* @author 夏晨琳
	*/
	public void updateDefTempleate(InsDeptDefTemplate def) {
		dao.updateObject(def);
	}

	/**
	* <p>描述:保存默认模板</p>
	* @param def
	* @author 夏晨琳
	*/
	public void saveDefTemplate(InsDeptDefTemplate def) {
		dao.saveObject(def);
	}

	/**
	* <p>描述:保存子模板信息</p>
	* @param sub
	* @author 夏晨琳
	*/
	public void saveDefTemplateSub(InsTemplateSub sub) {
		// TODO Auto-generated method stub
		
	}

}

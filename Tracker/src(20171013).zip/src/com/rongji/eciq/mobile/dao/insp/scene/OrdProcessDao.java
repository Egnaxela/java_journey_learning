/**  
 * FileName:OrdProcessDao.java
 * @Description: 布控处理dao层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.dao.insp.scene;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclOrdBackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdBackMainEntity;
import com.rongji.eciq.mobile.entity.DclOrdDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.OrdBackMainVo;
import com.rongji.eciq.mobile.entity.OrdFeedbackDetailVo;
import com.rongji.eciq.mobile.entity.SysSwitchOrg;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.common.util.FrameworkHelper;

/**
 * 
 * Description: 布控处理dao层
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-2 下午4:30:53  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-2      李云龙                      1.0         添加根据布控反馈编号查询布控反馈详细信息方法
 */
@Repository
public class OrdProcessDao {
	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	/**
	 * 根据报检单号和反馈环节指令查询布控反馈信息
	 * 
	 * @param declNo
	 *            报检单号
	 * @param feedbackLink
	 *            反馈环节指令
	 * @return DclOrdFeedbackMainEntity 布控反馈主信息
	 */
	public DclOrdFeedbackMainEntity getOrdFeedBackMain(String deptCode,
			String fedbackPersn, String declNo, String feedbackLink,
			String currentPage) {
		Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
		String sql = "select t from DclOrdFeedbackMainEntity t where t.declNo='"
				+ declNo + "' and t.feedbackLink='" + feedbackLink + "'";
		Query query = session.createQuery(sql);
		List<DclOrdFeedbackMainEntity> list = query.list();
		session.close();
		DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity = new DclOrdFeedbackMainEntity();
		if (deptCode != null) {
			if (deptCode.length() > 6) {
				deptCode = deptCode.substring(0, 6);
			}
		}
		if (!CollectionUtils.isEmpty(list)) {
			dclOrdFeedbackMainEntity = list.get(0);
			if (StringUtils.isEmpty(dclOrdFeedbackMainEntity.getFedbackPersn())) {
				dclOrdFeedbackMainEntity.setFedbackPersn(fedbackPersn);
			}
			if (StringUtils.isEmpty(dclOrdFeedbackMainEntity.getFeedbackOrg())) {
				dclOrdFeedbackMainEntity.setFeedbackOrg(deptCode);
			}
			if (StringUtils.isEmpty(dclOrdFeedbackMainEntity.getFeedbackDept())) {
				dclOrdFeedbackMainEntity.setFeedbackDept(deptCode);
			}
			if (dclOrdFeedbackMainEntity.getOperTime() == null) {
				dclOrdFeedbackMainEntity.setOperTime(new Date());
			}
			return dclOrdFeedbackMainEntity;
		}else{
			return null;
		}
	}
    
    /**
     * 根据布控反馈编号查询布控反馈详细信息
     * @param feedbackMainNo 反馈主编号【UUID】
     * @return List<DclOrdFeedbackDetailEntity> 布控反馈相信信息
     */
    @Autowired
	HibernateTemplate chgHibernateTemplate;
    public List<OrdFeedbackDetailVo> getFeedbackDetailListByMainNo(String feedbackMainNo){    	
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "select od.conc_type,od.conclusion_no,od.conclusion_name,od.conc_desc,od.exec_level,od.order_no ,fd.* "
                + " from dcl_ord_feedback_detail fd ,dcl_ord_detail od where fd.order_no = od.order_no(+) and od.enabled = '1' and fd.feedback_main_no = '"+feedbackMainNo+"' ";
    	List<OrdFeedbackDetailVo> list=session.createSQLQuery(sql).addEntity(OrdFeedbackDetailVo.class).list();
		session.close();
		return list;
    }
    
    /**
     * 根据布控反馈编号查询布控反馈详细信息
     * @param feedbackMainNo 反馈主编号【UUID】
     * @return List<DclOrdFeedbackDetailEntity> 布控反馈相信信息
     */
    public List<OrdFeedbackDetailVo> getFeedbackDetailListBydeclNo(String declNo,String linkNo){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String ql = "select sys_guid() as ORD_FEEDBACK_INFO_NO,od.conc_type,od.conclusion_no,od.conclusion_name,od.conc_desc,od.exec_level,od.order_no,fd.* " 
                  +" from dcl_ord_feedback_detail fd ,dcl_ord_detail od where  od.order_no =fd.order_no(+) and od.decl_no='"+declNo+"' and od.arriv_link='"+linkNo+"' and od.enabled ='1'  ";
        List<OrdFeedbackDetailVo> list = session.createSQLQuery(ql).addEntity(OrdFeedbackDetailVo.class).list();
        session.close();
        return list;
    }
    
    
    /**
     * 根据报检单号查询报检单的布控信息
     * @param declNo 报检单号
     * @return 
     */
    public List<DclOrdDetailEntity> getOrdDetailInfo(String declNo,String currentPage){
    	
    	StringBuilder sql=new StringBuilder();
    	List<String> param=new ArrayList<String>();
    	DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity=new DclOrdFeedbackMainEntity();
    	sql.append(" FROM DclOrdDetailEntity t where  1=1 ");
    	sql.append(" AND t.declNo =?");
    	param.add(declNo);
    	sql.append(" AND t.enabled = '1' order by t.arrivLink,t.arriveApp desc  ");
    	if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
    	Page page=MobileHelper.getPage(currentPage);
    	List<DclOrdDetailEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
        return list;
    }
    
    /**
     * 根据报检单号查询审单环节之前的布控信息
     * @param declNo 报检单号
     * @return 
     */
    public List<DclOrdDetailEntity> getOrdDetailInfoAudit(String declNo,String currentPage){
    	
    	StringBuilder sql=new StringBuilder();
    	List<String> param=new ArrayList<String>();
    	DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity=new DclOrdFeedbackMainEntity();
    	sql.append(" FROM DclOrdDetailEntity t where  1=1 ");
    	sql.append(" AND t.declNo =?");
    	param.add(declNo);
    	sql.append(" AND t.arrivLink in ('01', '10', '11', '12', '13', '14','15') ");
    	sql.append(" AND t.enabled = '1' order by t.arrivLink,t.arriveApp desc  ");
    	if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
    	Page page=MobileHelper.getPage(currentPage);
    	List<DclOrdDetailEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
        return list;
    }
    
    /**
     * 根据应用和报检单号以及处理的环节号,查询布控回退信息
     * @param declNo     报检单号
     * @param arrivLink  处理的环节号
     * @param arriveApp  处理的应用
     * @return  List<OrdBackMainVo> 
     */
    public List<OrdBackMainVo> getOrdDetail(String declNo, String arrivLink, String arriveApp){
    	String sql = " select distinct od.*,obd.ORD_BACK_INFO_NO,obd.back_main_no,obd.back_type,obd.back_cause_desc from dcl_ord_detail od ,"
                + "dcl_ord_back_detail obd where od.order_no = obd.order_no(+) and od.decl_no ='"+declNo+"' and od.arriv_link= '"+arrivLink+"'  and od.enabled = '1' ";
        if(StringUtils.isNotEmpty(arriveApp)){
             sql += "and od.arrive_app ='"+arriveApp+"'" ; 
        }
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	List<OrdBackMainVo> list=session.createSQLQuery(sql).addEntity(OrdBackMainVo.class).list();
		session.close();
		return list;
    	
    }
    
    
    /**
     * 布控反馈信息保存
     * @param ordFeedbackMainEntity 布控反馈信息
     */
    public void updateFeedbackMainInfo(DclOrdFeedbackMainEntity ordFeedbackMainEntity){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
    	session.merge(ordFeedbackMainEntity);
    	session.getTransaction().commit();
    	session.close();
    }
    
    /**
     * 保存或修改布控反馈详细信息
     * @param list 布控反馈详细信息
     */
    public void updateFeedbackDetailInfo(List<DclOrdFeedbackDetailEntity> list){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	
    	DclOrdFeedbackDetailEntity dclOrdFeedbackDetailEntity = null ;
        //判断布控反馈详细信息是否为空
        if(CollectionUtils.isNotEmpty(list)){ 
            for(int i =0 ;i <list.size(); i++){
            	session.beginTransaction();
                dclOrdFeedbackDetailEntity = list.get(i);
                dclOrdFeedbackDetailEntity.setOperTime(new Date());
                if(StringUtils.isEmpty(dclOrdFeedbackDetailEntity.getOrdFeedbackInfoNo())){
                    dclOrdFeedbackDetailEntity.setOrdFeedbackInfoNo(UUIDKeyGeneratorUils.newInstance().generateKey());
                }
                session.merge(dclOrdFeedbackDetailEntity);
                session.getTransaction().commit();
            }
        }
        session.close();
    }
    
    /**
     * 根据uuid删除布控回退明细实体
     * @param ordBackInfoNo 布控回退明细主键
     */
    public void delBackDetail(String ordBackInfoNo){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String ql = "delete from DclOrdBackDetailEntity e where e.ordBackInfoNo =?";
        Query query = session.createQuery(ql) ;
        query.setParameter(0, ordBackInfoNo);
        query.executeUpdate();
        session.getTransaction().commit();
        session.flush();
        session.close();
    }
    
    /**
     * 按照报检单号和回退环节 删除报检单布控回退信息
     * @param declNo 报检单号
     * @param backLink  回退环节
     */
    public void deleteOrdBackMain(String declNo,String backLink){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
        String ql = "delete from DclOrdBackMainEntity e where e.declNo = ? and e.backLink = ?";
        Query query = session.createQuery(ql);
        query.setParameter(0,declNo);
        query.setParameter(1,backLink);
        query.executeUpdate();
        session.getTransaction().commit();
        session.flush();
        session.close();
    }
    
    /**
     * 保存布控回退信息
     * @param dclOrdBackMainEntity 
     */
    public void saveOrdBackMain(DclOrdBackMainEntity dclOrdBackMainEntity){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
        session.merge(dclOrdBackMainEntity);
        session.getTransaction().commit();
        session.flush();
        session.close();
    }
    
    /**
     * 保存布控回退详细信息
     * @param dclOrdBackDetailEntity 布控回退详细信息
     */
    public void saveOrdBackDetail(DclOrdBackDetailEntity dclOrdBackDetailEntity){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
        session.merge(dclOrdBackDetailEntity);
        session.getTransaction().commit();
        session.flush();
        session.close();
    }
    
    
    /**
     * 初始化布控回退主信息
     * @param declNo 报检单号
     * @param backLink 回退环节号
     * @param jpaService
     * @return DclOrdBackMainEntity 布控回退主信息
     */
    public DclOrdBackMainEntity initOrdBackMain(String declNo,String backLink,String orgCode,String backPerson){
        DclOrdBackMainEntity dclOrdBackMainEntity = getOrdBackMain(declNo, backLink);
        if(dclOrdBackMainEntity == null){ 
            //如果不存在布控回退信息则初始化布控回退主信息
            dclOrdBackMainEntity = new DclOrdBackMainEntity();
            dclOrdBackMainEntity.setDeclNo(declNo);
            dclOrdBackMainEntity.setBackLink(backLink);
            dclOrdBackMainEntity.setBackDate(new Date());
            dclOrdBackMainEntity.setBackOrg(orgCode);
            dclOrdBackMainEntity.setBackPerson(backPerson);
            dclOrdBackMainEntity.setBackMainNo(UUIDKeyGeneratorUils.newInstance().generateKey());
        }
        return dclOrdBackMainEntity ; 
    }
    
    
    /**
     * 根据报检单号和回退环节编号查询回退主信息
     * @param declNo 报检单号
     * @param backLink 回退环节编码
     * @return DclOrdBackMainEntity 布控回退主信息
     */
     public DclOrdBackMainEntity getOrdBackMain(String declNo,String backLink){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String ql = " select e from DclOrdBackMainEntity e where e.declNo ='"+declNo+"' and e.backLink ='"+backLink+"'" ; 
        Query query = session.createQuery(ql);
        List<DclOrdBackMainEntity> backMainList = query.list();
        session.close();
        if(CollectionUtils.isNotEmpty(backMainList)){
            return backMainList.get(0);
        }
        return null;
    }
     
     /**
      * 布控反馈
      * @param declNo 报检单号
      * @param backLink 回退环节编码
      * @return DclOrdBackMainEntity 布控回退主信息
      */
      public DclOrdFeedbackMainEntity getOrdFeedBackMain(String declNo,String backLink){
     	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
         String ql = " select e from DclOrdFeedbackMainEntity e where e.declNo ='"+declNo+"' and e.feedbackLink ='"+backLink+"'" ; 
         Query query = session.createQuery(ql);
         List<DclOrdFeedbackMainEntity> backMainList = query.list();
         session.close();
         if(CollectionUtils.isNotEmpty(backMainList)){
             return backMainList.get(0);
         }
         return null;
     }
     
     /**
      * 根据开关设置表ID、机构代码查询适用机构列表
      *
      * @param sysSwitchId 开关设置表ID
      * @param orgCode 机构代码
      * @return 适用机构
      *
      */
     public SysSwitchOrg getSwitchOpenByOrgCodeAndId(String sysSwitchId, String orgCode) {
    	 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
         String ql = "select a from SysSwitchOrg a where a.sysSwitchId='"+sysSwitchId+"' and a.orgCode='"+orgCode+"'";
         Query query = session.createQuery(ql);
         List<SysSwitchOrg> list = query.list();
         session.close();
         if (CollectionUtils.isNotEmpty(list)) {
             return list.get(0);
         }
         return null;
         
     }
     
     /**
      * 根据 布控环节指令和报检单号查询布控信息是否存在
      * @param declNo 报检单号
      * @param linkNo 环节指令号
      * @return 
      */
     public boolean getOrdMain(String declNo,String linkNo){
    	 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
         String sql = "select d.* from dcl_ord_main m,dcl_ord_detail d where m.decl_no=d.decl_no and d.order_main_no = m.order_main_no and d.decl_no=? and d.arriv_link= ? and d.enabled = ? " ;
         Query query = session.createSQLQuery(sql);
         query.setParameter(0, declNo);
         query.setParameter(1, linkNo);
         query.setParameter(2, "1");
         List list = query.list();
         session.close();
         if(CollectionUtils.isNotEmpty(list)){
        	 return true;
        	 
         }
         return false;
     }


     
}

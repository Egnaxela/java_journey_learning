/**  
 * FileName:     SceneCheckBackCommitDao
 * @Description: 现场查验-数据提交操作dao
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月17日 下午5:31:37  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.scene;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.context.DeclevalConstants;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsExEntity;
import com.rongji.eciq.mobile.entity.DclOrdDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.DeclLogicVo;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsResultEvalEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsSampleItemResultEntity;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysSwitchOrg;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 现场查验-数据提交操作dao 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月17日 下午5:31:37  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月17日      吴有根                      1.0         1.0 Version  
 * 2017-05-26   才江男                      1.0         保存评定记录
 * 2017-05-26   才江男                      1.0         更新报检单权限
 * 2017-05-27   才江男                      1.0         Double改为BigDecimal
 */

@Repository
public class SceneCheckBackCommitDao {

	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;

    
    /**
     * 机构局代码所属层级 0级 总局
     */
    public static final int ORG_LEVEL_0 = 0;
    /**
     * 机构局代码所属层级 1级 直属局
     */
    public static final int ORG_LEVEL_1 = 1;
    /**
     * 机构局代码所属层级 2级 分支局（业务层级）
     */
    public static final int ORG_LEVEL_2 = 2;
    /**
     * 机构局代码所属层级 3级 办事处/办公室（业务层级）
     */
    public static final int ORG_LEVEL_3 = 3;
    /**
     * 机构局代码所属层级 4级 科室（处室） --新增
     */
    public static final int ORG_LEVEL_4 = 4;
    /**
     * 机构局代码所属层级 5级 科室（部门） --调整
     */
    public static final int ORG_LEVEL_5 = 5;
    /**
     * 机构局代码所属层级判断失败
     */
    public static final int ORG_LEVEL_ERR = -1;
    /**
     * 机构代码长度
     */
    public static final int ORG_LENGTH = 6;
    /**
     * 处室机构代码长度 --新增
     */
    public static final int OFFICE_LENGTH = 8;
    /**
     * 部门机构代码长度 --新增
     */
    public static final int DEPARTMENT_LENGTH = 10;
    /**
     * 机构分类代码长度 --新增
     */
    public static final int ORG_CATEGORY_CODE_LENGTH = 8;
    /**
     * 处室分类代码长度：对应机构分类码+处室机构代码 总长16位 --新增
     */
    public static final int OFFICE_CATEGORY_CODE_LENGTH = 16;
    /**
     * 部门分类代码长度：对应机构分类代码+部门机构代码 总长18位 --新增
     */
    public static final int DEPARTMENT_CATEGORY_CODE_LENGTH = 18;
    private static final String COMPANY_CODE_SESSION_ATTRIBUTE_ID = "CompanyCodeSessionAttributeId";

    /**
     * 缺省定值
     */
    public static final String DEFAULT_CODE = "00000000";
    
    /**
     * 国家局分类代码
     */
    public static final String NATION_CATEGORY_CODE = "00000000";
    
	/**
	* <p>描述:根据报检单号、主施检状态获得主施检记录</p>
	* @param declNo  报检单号
	* @param flowPathStatus  流程状态
	* @param excInspDeptCode 施检部门
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public InsDeclMagEntity findMainInsMag(String declNo, String flowPathStatus,String excInspDeptCode) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsDeclMagEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		if(StringUtils.isNotEmpty(flowPathStatus)){
			sql.append(" AND t.flowPathStatus=?");
			params.add(flowPathStatus);
		}
		if(StringUtils.isNotEmpty(excInspDeptCode)){
			sql.append(" AND t.excInspDeptCode=?");
			params.add(excInspDeptCode);
		}
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:查询辅施检信息集合</p>
	* @param declNo
	* @param flowPathStatusAuxiliary
	* @param b
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsDeclMagEntity> queryInsDeclMagStatus(String declNo, String flowPathStatus, boolean isChecked) {
		if(isChecked){
			StringBuilder sql=new StringBuilder();
			List<Object> params=new ArrayList<Object>();
			sql.append(" FROM InsDeclMagEntity t where 1=1");
			if(StringUtils.isNotEmpty(declNo)){
				sql.append(" AND t.declNo=?");
				params.add(declNo);
			}
			if(StringUtils.isNotEmpty(flowPathStatus)){
				sql.append(" AND t.flowPathStatus=?");
				params.add(flowPathStatus);
			}
	
			sql.append(" or t.flowPathStatus=?");
			params.add(InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE);
			List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), params.toArray());
			return list;
		}else{
			StringBuilder sql=new StringBuilder();
			List<Object> params=new ArrayList<Object>();
			sql.append(" FROM InsDeclMagEntity t where 1=1");
			if(StringUtils.isNotEmpty(declNo)){
				sql.append(" AND t.declNo=?");
				params.add(declNo);
			}
			if(StringUtils.isNotEmpty(flowPathStatus)){
				sql.append(" AND t.flowPathStatus=?");
				params.add(flowPathStatus);
			}
			List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), params.toArray());
			return list;
		}
	}

	
	/**
	* <p>描述:判断辅施检是否处理完成</p>
	* @param declNo
	* @param inspOrgCode
	* @param flowPathStatusFlag
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public InsDeclMagEntity getjudgeLoginDeptIsChecked(String declNo, String excInspDeptCode, String flowPathStatus) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsDeclMagEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		if(StringUtils.isNotEmpty(excInspDeptCode)){
			sql.append(" AND t.excInspDeptCode=?");
			params.add(excInspDeptCode);
		}
		if(StringUtils.isNotEmpty(flowPathStatus)){
			sql.append(" AND t.flowPathStatus=?");
			params.add(flowPathStatus);
		}
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	
	}

	/**
	* <p>描述:根据报检号查询审单发送查验指令的查验场</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<String> getInsCheckCommandEntityList(String declNo) {
		String sql="SELECT CHECK_SITE_NAME FROM INS_CHECK_COMMAND WHERE DECL_NO =?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<String> list=session.createSQLQuery(sql).setParameter(0, declNo).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:如果查看场为空,就默认取报检单上边的存放地点</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public DclIoDeclEntity queryInsResultMark(String declNo) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	* <p>描述:获取开关值(追溯上级)</p>
	* @param insOrder
	* @param orgCode
	* @return
	* @author 吴有根
	*/
	public boolean judgeSwitchResule(String switchId, String orgCode) {
		//获取当前机构的所有上级代码
		Map<Integer, String> orgMap=this.getOrgCode(orgCode);
		if(orgMap.isEmpty()){
			return false;
		}

		SysSwitchOrg entity;
		//工作点办事处
		String orgCodeStr=orgMap.get(SceneCheckBackCommitDao.ORG_LEVEL_3);
		if(StringUtils.isNotEmpty(orgCodeStr)){
			entity=getSwitchOpenByOrgCodeAndId(switchId,orgCodeStr);
			if(null!=entity){
				//只要开关打开就返回
				return StringUtils.equals(entity.getSwitchValue(), "1");//开关值【1-开；0-关】
			}
		}
		
		//分支局
		orgCodeStr=orgMap.get(SceneCheckBackCommitDao.ORG_LEVEL_2);
		if(StringUtils.isNotEmpty(orgCodeStr)){
			entity=getSwitchOpenByOrgCodeAndId(switchId,orgCodeStr);
			if(null!=entity){
				return StringUtils.equals(entity.getSwitchValue(), "1");//开关值【1-开；0-关】
			}
		}
		
		//直属局
		orgCodeStr=orgMap.get(SceneCheckBackCommitDao.ORG_LEVEL_1);
		if(StringUtils.isNotEmpty(orgCodeStr)){
			entity=getSwitchOpenByOrgCodeAndId(switchId,orgCodeStr);
			if(null!=entity){
				return StringUtils.equals(entity.getSwitchValue(), "1");//开关值【1-开；0-关】
			}
		}
		
		//国家局
		orgCodeStr=orgMap.get(SceneCheckBackCommitDao.ORG_LEVEL_0);
		if(StringUtils.isNotEmpty(orgCodeStr)){
			entity=getSwitchOpenByOrgCodeAndId(switchId,orgCodeStr);
			if(null!=entity){
				return StringUtils.equals(entity.getSwitchValue(), "1");//开关值【1-开；0-关】
			}
		}
		return false;
	}

	/**
	* <p>描述:根据主键和当前机构查询是否有当前开关</p>
	* @param switchId
	* @param orgCodeStr
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	private SysSwitchOrg getSwitchOpenByOrgCodeAndId(String switchId, String orgCode) {
		StringBuilder sql=new StringBuilder();
		List<String> params=new ArrayList<String>();
		sql.append(" FROM SysSwitchOrg t where 1=1");
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.orgCode=?");
			params.add(orgCode);
		}
		if(StringUtils.isNotEmpty(switchId)){
			sql.append(" AND t.sysSwitchId=?");
			params.add(switchId);
		}
		
		List<SysSwitchOrg> list=dao.getQueryList(sql.toString(), params.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:</p>
	* 通过传入的当前机构代码，返回一个map， 获得总局、直属局、分支局、办事处机构代码 <br>
    * 本方法已经被规则引擎征用，方法改进时，通知规则引擎制作者调整规则引擎 KEY：机构代码，VALUE：机构名称 <br>
    * KEY：ORG_LEVEL_0 VALUE：国家局代码 <br>
    * KEY：ORG_LEVEL_1 VALUE：直属局 <br>
    * KEY：ORG_LEVEL_2 VALUE：分支局 <br>
    * KEY：ORG_LEVEL_3 VALUE：办事处/办公室（业务层级） <br>
    * KEY：ORG_LEVEL_4 VALUE：科室(处室级别) <br>
    * KEY：ORG_LEVEL_5 VALUE：科室(部门级别)
    * 
	* @param orgCode
	* @return Map KEY：机构层级，VALUE：机构代码
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	private Map<Integer, String> getOrgCode(String orgCode) {
        if (StringUtils.isEmpty(orgCode)) {
            return null;
        } else {
        	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
            Map<Integer, String> orgLevel = new HashMap<Integer, String>();
    		String sql = "SELECT t.ORG_CODE,t.CATEGORY_CODE,t.SENIOR_CATEGORY_CODE,t.* "
    				+ "    FROM SYS_ORGANIZE t  WHERE  t.STATE = '1' "
    				+ "   START WITH t.CATEGORY_CODE = "
    				+ "              (SELECT t.CATEGORY_CODE "
    				+ "                 FROM SYS_ORGANIZE t "
    				+ "                WHERE t.ORG_CODE =  :orgCode  ) "
    				+ "  CONNECT BY PRIOR t.SENIOR_CATEGORY_CODE = t.CATEGORY_CODE";
            
			List<SysOrganizeEntity> sysOrgList=session.createSQLQuery(sql).addEntity(SysOrganizeEntity.class).setParameter("orgCode", orgCode).list();
            int level;
            if(Utils.notEmpty(sysOrgList)){
            	for(SysOrganizeEntity sysOrg:sysOrgList){
            		level=getOrgDeptLevelByCategoryCode(sysOrg.getCategoryCode(),sysOrg.getSeniorCategoryCode());
            		if(level!=SceneCheckBackCommitDao.ORG_LEVEL_ERR){
            			orgLevel.put(level, sysOrg.getOrgCode());
            		}
            	}
            }
            session.close();
            return orgLevel;
        }
	}
	
	
    /**
     * 得到机构局代码所属层级
     *
     * @param categoryCode 机构分类码
     * @param seniorCategoryCode 父分类码
     *
     * @return 机构所属层级 <br>
     * -1 传递参数有误 <br>
     * 0 总局 <br>
     * 1 直属局 <br>
     * 2 分支局 <br>
     * 3 办事处、工作点 <br>
     * 4 科室(处室) <br>
     * 5 部门
     */
    public static int getOrgDeptLevelByCategoryCode(String categoryCode,
            String seniorCategoryCode) {

        // 分类码长度为16位 返回处室级别
        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == OFFICE_CATEGORY_CODE_LENGTH) {
            return ORG_LEVEL_4;
        }

        // 分类码长度为18位 返回部门级别
        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == DEPARTMENT_CATEGORY_CODE_LENGTH) {
            return ORG_LEVEL_5;
        }

        // 如果机构代码与总局代码一致则返回总局层级
        if (StringUtils.equals(NATION_CATEGORY_CODE, categoryCode)) {
            return ORG_LEVEL_0;
        }

        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == ORG_CATEGORY_CODE_LENGTH) {
            if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE, 0, 6),
                    StringUtils.substring(categoryCode, 2))) {
                // 如果分类码后六位为零，则为直属局
                return ORG_LEVEL_1;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 6), StringUtils.substring(seniorCategoryCode, 2))) {
                // 如果父分类码为直属局的，则本机构是分支局
                return ORG_LEVEL_2;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 4), StringUtils.substring(seniorCategoryCode, 4))) {
                // 如果父分类码为直属分支局的，则本机构是办事处/工作点
                return ORG_LEVEL_3;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 2), StringUtils.substring(seniorCategoryCode, 6))) {
                // 如果父分类码为办事处，则本机构是工作点
                return ORG_LEVEL_4;
            } else {
                // 其他情况，失败。
                return ORG_LEVEL_ERR;
            }
        } else {
            // 其他情况，失败。
            return ORG_LEVEL_ERR;
        }
    }

    
	/**
	* <p>描述:根据报价单号和指令环节  查询布控反馈详细信息</p>
	* @param declNo
	* @param spot
	* @return
	* @author 吴有根
	*/
	public boolean getOrdFeedbackDetailList(String declNo, String linkNo) {
		StringBuilder detailQl =new StringBuilder();
		List<String> params=new ArrayList<String>();
		detailQl.append(" FROM DclOrdDetailEntity t where 1=1 ");
		if(StringUtils.isNotEmpty(declNo)){
			detailQl.append(" AND t.declNo=?");
			params.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(linkNo)){
			detailQl.append(" AND t.arrivLink=?");
			params.add(linkNo);
		}
		
		detailQl.append(" AND t.enabled =?");
		params.add("1");
		List<DclOrdDetailEntity> detailEntities=dao.getQueryList(detailQl.toString(), params.toArray());
		if(Utils.notEmpty(detailEntities)){
			for(DclOrdDetailEntity ordDetailEntity :detailEntities){
				if(StringUtils.equals(ordDetailEntity.getExecLevel(), "1")){
					StringBuilder ql=new StringBuilder();
					List<String> param=new ArrayList<String>();
					ql.append(" FROM DclOrdFeedbackMainEntity t where 1=1");
					if(StringUtils.isNotEmpty(declNo)){
						ql.append(" AND t.declNo=?");
						param.add(declNo);
					}
					if(StringUtils.isNotEmpty(linkNo)){
						ql.append(" AND t.feedbackLink=?");
						param.add(linkNo);
					}
					List<DclOrdFeedbackMainEntity> mainList=dao.getQueryList(ql.toString(), param.toArray());
					DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity=null;
					if(Utils.notEmpty(mainList)){
						dclOrdFeedbackMainEntity=mainList.get(0);
                        StringBuilder feedbackDetailQl =new StringBuilder();
                        List<String> pList=new ArrayList<String>();
                        feedbackDetailQl.append(" FROM DclOrdFeedbackDetailEntity t where 1=1");
                        if(StringUtils.isNotEmpty(dclOrdFeedbackMainEntity.getFeedbackMainNo())){
                        	feedbackDetailQl.append(" AND t.feedbackMainNo=?");
                        	pList.add(dclOrdFeedbackMainEntity.getFeedbackMainNo());
                        }
                        List<DclOrdFeedbackDetailEntity> dclOrdFeedbackDetailEntitys = dao.getQueryList(feedbackDetailQl.toString(),pList.toArray());
                        if (Utils.isEmpty(dclOrdFeedbackDetailEntitys)) {
                            return true;
                        } else {
                            return false;
                        }
					}else{
						return true;
					}
						
				}
			}
		}
		
		return false;
	}

	/**
	* <p>描述:根据报检号查询查验项目</p>
	* @param declNo
	* @param i
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsCheckItemEntity> getInsCheckItemList(String declNo, int i) {
        String sql = "SELECT T.*,LEVEL FROM( "
                + "SELECT A.CHECK_ITEM_ID,"
                + " A.DECL_NO,"
                + " A.GOODS_NO,"
                + " DECODE(A.NODE_CODE,null,sys_guid(),A.NODE_CODE) as NODE_CODE,"
                + " A.CHECK_ITEM_CODE,"
                + " A.CHECK_ITEM_NAME,"
                + " A.CHECK_ITEM_RESULT_CODE,"
                + " DECODE(A.PARENT_ITEM_CODE,null,'root',A.PARENT_ITEM_CODE) as PARENT_ITEM_CODE ,"
                + " A.CHECK_GOODS_TYPE,"
                + " A.PARENT_ITEM_NAME,"
                + " A.BATCH_DESC,"
                + " A.INSP_PROC_STATUS,"
                + " A.FALG_ARCHIVE,"
                + " A.SC_ORG_CODE,"
                + " A.SC_OPERATOR_CODE,"
                + " A.OPER_TIME,"
                + " A.SAMPLE_SCH,"
                + " A.ITEM_TYPE_CODE,"
                + " A.IS_APP_FLAG,"
                + " A.ADD_INPUT_FLAG,"
                + " A.CHECK_CONT,"
                + " A.WHETHER_QUALFY,"
                + " A.ARCHIVE_TIME,"
                + " A.CHECK_FORM_CODE"
        //        + "B.FORM_NAME "
                + " FROM INS_CHECK_ITEM A LEFT JOIN RUL_CHECK_FORM B "
                + " ON A.CHECK_FORM_CODE = B.CHECK_FORM_CODE "
                + " WHERE A.DECL_NO =? "
                //                + "AND A.GOODS_NO = ?GOODSNO "
                + " ORDER BY A.GOODS_NO,A.CHECK_CONT) T "
                + " START WITH T.PARENT_ITEM_CODE = 'root' CONNECT BY PRIOR LOWER(T.NODE_CODE) = LOWER(T.PARENT_ITEM_CODE)";

        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<InsCheckItemEntity> list=session.createSQLQuery(sql).addEntity(InsCheckItemEntity.class).setParameter(0, declNo).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:根据报检号从报检单管理表中查询所有集合</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsResultGoodsEntity> getInsResultGoodsList(String declNo) {
        String sql = "SELECT DISTINCT G.RESULT_GOODS_ID"//货物ID
                + ",G.GOODS_NO"//货物序号
                + ",G.DECL_NO"//报检单号
                + ",G.PROD_BATCH_NO"//生产批号
                + ",G.PROD_HS_CODE"//HS代码
                + ",G.GOODS_TOTAL_VAL"//货物总值
                + ",G.GOODS_NAME_CN"//货物名称
                + ",G.STAT_KIND_CODE"//商品统计分类代码
                + ",G.DECL_GOODS_VALUES"//报检货物总值
                + ",G.CURRENCY"//币种
                + ",G.INSP_UNQ_RESN"//检验不合格原因
                + ",G.QUR_UNQUL_RSN_CODE"//检疫不合格原因
                + ",G.FALG_ARCHIVE"//归档标志
                + ",G.PACK_QTY"//包装件数
                + ",G.RISK_INFO_LEVEL_CODE"//风险信息等级代码
                + ",G.REAL_WEIGHT"//实际货重
                + ",G.ACTUAL_QTY"//实际数量
                + ",G.ACT_SMPL_NUM"//实际抽样量
                + ",G.QUAR_RES_SPOT"//检疫结果评定
                + ",G.INSP_RES_SPOT"//检验结果评定
                + ",G.INSP_PATTERN_CODE"//检验方式
                + ",G.MNUFCTR_CODE"//生产企业代码
                //                + ",D.QTY_MEAS_UNIT"//数量计量单位
                //                + ",D.WT_MEAS_UNIT"//重量计量单位
                + ",G.*"
                + ",E.INSP_REQUIRE"//检验要求
                + ",E.RISK_EVAL_CODE"//产品风险等级
                + ",E.BATCH_RATIO "//抽批率
                + ",D.CIQ_CODE "//CIQ编码
                + "FROM INS_RESULT_GOODS G "
                + "LEFT JOIN DCL_IO_DECL_GOODS D ON G.DECL_NO = D.DECL_NO AND G.GOODS_NO = D.GOODS_NO "
                + "LEFT JOIN DCL_IO_DECL_GOODS_EX E ON D.GOODS_ID = E.GOODS_ID "
                //                + "JOIN DCL_IO_DECL_GOODS D ON G.DECL_NO =D.DECL_NO  "
                + "WHERE G.DECL_NO = ? ORDER BY G.GOODS_NO asc";
        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<InsResultGoodsEntity> entityList=session.createSQLQuery(sql).addEntity(InsResultGoodsEntity.class).setParameter(0, declNo).list();
        if (Utils.notEmpty(entityList)) {
            for (InsResultGoodsEntity insResultGoodsVO : entityList) {
                //设置检疫结果默认项
                if (StringUtils.isEmpty(insResultGoodsVO.getQuarResSpot())) {
                    //默认设置为合格
                    insResultGoodsVO.setQuarResSpot(DeclevalConstants.INSP_QUAR_RESULT_PASS);
                } else if (StringUtils.isEmpty(insResultGoodsVO.getInspResSpot())) {//设置检验结果默认项
                    //默认设置为合格
                    insResultGoodsVO.setInspResSpot(DeclevalConstants.INSP_QUAR_RESULT_PASS);
                } else if (StringUtils.isEmpty(insResultGoodsVO.getInspPatternCode())) {//设置检验方式默认项
                    //默认设置为自检自验
                    insResultGoodsVO.setInspPatternCode(DeclContext.SELF_CHECKING_CODE);
                } else if (insResultGoodsVO.getActualQty() == null) {
                    insResultGoodsVO.setActualQty(BigDecimal.ZERO.doubleValue());
                } else if (insResultGoodsVO.getRealWeight() == null) {
                    insResultGoodsVO.setRealWeight(BigDecimal.ZERO);
                } else if (insResultGoodsVO.getActSmplNum() == null) {
                    insResultGoodsVO.setActSmplNum(BigDecimal.ZERO.doubleValue());
                }
                
                //true 重量  false  数量
                Boolean hsType = getHsType(insResultGoodsVO.getProdHsCode());
                if (hsType != null) {
                    if (hsType) {
                    	//Hstype  暂不用到
                     //   insResultGoodsVO.setHsType(DeclevalConstants.UNIT_CAT_CODE_WEIGHT);
                    } else {
                      //  insResultGoodsVO.setHsType(DeclevalConstants.UNIT_CAT_CODE_QTY);
                    }
                }
            }
        }
        session.close();
        return entityList;
        
	}
	
	/**
	 * 
	* <p>描述:根据HSCode，判断取数量还是重量</p>
	* @return
	* @author 吴有根
	 */
	private Boolean getHsType(String hsCode){
		String sqlString = "SELECT MEASURE_TYPE_CODE FROM Z_BBD_HS_CODE A WHERE A.HS_CODE=?";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<String> list=session.createSQLQuery(sqlString).setParameter(0, hsCode).list();
		session.close();
		String type=null;
		if(Utils.notEmpty(list)){
			type=list.get(0);
		}
		if(StringUtils.isEmpty(type)){
			return null; //否
		}
		
		if(StringUtils.equals(type, DeclevalConstants.UNIT_CAT_CODE_WEIGHT)){
			return true;//重量
		}else{
			return false;//数量
		}
	}

	/**
	* <p>描述:判断该报检单下货物检验要求为需查验送检是，是否都进行了送检</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean isFinshSend(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM DclIoDeclGoodsExEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		sql.append(" AND t.inspRequire=?");
		params.add(InsContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE);
		List<DclIoDeclGoodsExEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		if(Utils.notEmpty(list)){
			for(DclIoDeclGoodsExEntity e:list){
				if(!StringUtils.equals(InsContext.DELIVER_FLAG_SURE_SEND, e.getIsExamsym())){
					List<InsSampleItemResultEntity> rList=getItemResultByManualType(declNo,e.getGoodsNo()!=null?(e.getGoodsNo()+"").substring(0, (e.getGoodsNo()+"").indexOf(".")):"1");
					if(Utils.isEmpty(rList)){
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	* <p>描述:根据报检单号、货物序号，获得人工登记类型项目结果</p>
	* @param declNo
	* @param goodsNo
	* @return
	* @author 吴有根
	*/
	private List<InsSampleItemResultEntity> getItemResultByManualType(String declNo, String goodsNo) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsSampleItemResultEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(goodsNo)){
			sql.append(" AND t.goodsNo=?");
			params.add(goodsNo);
		}
		sql.append(" AND t.testResSorcType=?");
		params.add(InsContext.CHECK_RESULT_SELF);
		List<InsSampleItemResultEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}

	/**
	* <p>描述:报检单和报检扩展表对象</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public DeclLogicVo getDeclLogicVo(String declNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql = "SELECT D.DECL_NO,D.PROCESS_STATUS,E.INSP_REQUIRE,E.EXP_IMP_FLAG FROM DCL_IO_DECL D,DCL_IO_DECL_EX E WHERE D.DECL_NO=E.DECL_NO AND E.DECL_NO=:declNo ";
		List list=session.createSQLQuery(sql).setParameter("declNo", declNo).list();    
	    if(Utils.notEmpty(list)){
	    	DeclLogicVo vo=new DeclLogicVo();
	    	Object[] objects=(Object[]) list.get(0);
	    	//String[] strs=splitString(list.get(0));
	    	if(objects!=null&&objects.length>3){
		    	vo.setDeclNo((String)objects[0]);
		    	vo.setProcessStatus((String)objects[1]);
		    	vo.setInspRequire(objects[2].toString());
		    	vo.setExpImpFlag(objects[3].toString());
		    	return vo;
	    	}
	    }
	    session.close();
		return null;
	}
	
	/**
	 * 
	* <p>描述:拆分String</p>
	* @return
	* @author 吴有根
	 */
	private String[] splitString(String str){
		if(StringUtils.isNotEmpty(str)&&str.contains(",")){
			String[] st=str.split(",");
			return st;
		}else{
			return null;
		}
	}

	/**
	* <p>描述:根据报价单号获取检验检疫结果</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public InsResultSumEntity findInsResultSumEntitybyDeclNo(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsResultSumEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		List<InsResultSumEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:判断报检单下实验室检测项目是否有不合格</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean isNotQualifiedSampleItem(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsSampleItemResultEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		List<InsSampleItemResultEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		if(Utils.isEmpty(list)){
			return false;
		}
		for(InsSampleItemResultEntity e:list){
			if(!StringUtils.equals(e.getEvalResult(), DeclevalConstants.INSP_RESULT_PASS)){
				return false;
			}
		}
		return true;
	}

	/**
	* <p>描述:根据报检单号获取报检单管理表</p>
	* @param declNo
	* @param expImpFlag
	* @param userOrgCode
	* @return
	* @author 吴有根
	*/
	public List<InsDeclMagEntity> getInsDeclMag(String declNo, String expImpFlag, String userOrgCode,String flowPathStatus) {
		StringBuilder hql=new StringBuilder();
		hql.append("SELECT t FROM InsDeclMagEntity t WHERE t.declNo =:declNo");
		hql.append("	AND t.expImpFlag =:expImpFlag");
		hql.append("	AND t.exeInspOrgCode =:exeInspOrgCode");
		hql.append("	AND t.flowPathStatus =:flowPathStatus");
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	    Query query = session.createQuery(hql.toString());  
	    query.setParameter("declNo",declNo);  
	    query.setParameter("expImpFlag", expImpFlag);
	    query.setParameter("exeInspOrgCode", userOrgCode);
	    query.setParameter("flowPathStatus", flowPathStatus);
		List<InsDeclMagEntity> list=query.list();
		session.close();
		return list;
	}

	/**
	* <p>描述:更新报检单管理表</p>
	* @param declMagId
	* @param map
	* @author 吴有根
	*/
	public void updatePriv(String declMagId, HashMap<String, String> map) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="update INS_DECL_MAG t set t.CHECK_PRIV=?,t.AUDIT_PRIV=? where t.DECL_MAG_ID=?";
		Query query=session.createSQLQuery(sql).setParameter(0,map.get("CHECK_PRIV")).setParameter(1, map.get("AUDIT_PRIV")).setParameter(2, declMagId);
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:获取此报检单施检最后一次施检审单状态</p>
	* @param declNo
	* @param sceneCheckBackCommitService
	* @return
	* @author 吴有根
	*/
	public SysProcessLogEntity getLastAuditStatu(String declNo) {
		List<SysProcessLogEntity> list=getProcessLogDescOptime(declNo);
		if(Utils.notEmpty(list)){
			for(SysProcessLogEntity e:list){
				if(StringUtils.equals(e.getProcessNode(), CommContext.INS)){
					return e;
				}
			}
		}
		return null;
	}

	/**
	* <p>描述:根据报检号查询流程日志信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private List<SysProcessLogEntity> getProcessLogDescOptime(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM SysProcessLogEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		sql.append(" order by t.operDate desc");
		List<SysProcessLogEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}
	
	/**
	* <p>描述: 保存综合评定记录</p>
	* @param insResultEval
	* @author 才江男
	 */
	public void saveInsResultEval(InsResultEvalEntity insResultEval) {
		dao.saveObject(insResultEval);
	}

	/**
	* <p>描述: 更新报检单权限</p>
	* @param declNo 报检号
	* @author 才江男
	 */
	public void updatePriv(String declNo) {
		
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG SET SUB_PRIV='0',SUB_TYPE='1',AUDIT_PRIV='0',CHECK_PRIV='0',REGI_PRIV='0',OPER_TIME=sysdate WHERE DECL_NO = ? AND FLOW_PATH_STATUS='800'";
		Query query=session.createSQLQuery(sql).setParameter(0,declNo);
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:根据报检单号、主辅检标记获取报检单管理信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsDeclMagEntity> findInsDeclMagByFlowType2(String declNo,String flowPathStatus) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM InsDeclMagEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(flowPathStatus)){
			sql.append(" AND t.flowPathStatus =?");
			params.add(flowPathStatus);
		}
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}

}

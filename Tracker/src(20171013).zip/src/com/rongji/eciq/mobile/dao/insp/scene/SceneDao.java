/**  
 * FileName: SceneDao.java    
 * @Description: 现场查验dao查询类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */
package com.rongji.eciq.mobile.dao.insp.scene;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.entity.DclContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclPackDeclEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsContainerResultEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysConfigEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.TraControlEntity;
import com.rongji.eciq.mobile.model.insp.scene.DeclBaseInfoModel;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.server.entity.InsDeclLobEntity;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.entity.SysAppProcessLog;

/**
 * 
 * Description: 现场查验dao查询类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-15 下午5:02:07  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-19      才江男                      1.0        增加附件保存查询方法  
 * 2017-04-25      才江男                      1.0        获取附件时，增加人员条件
 * 2017-04-27      才江男                      1.0        审单进入现场查验
 * 2017-05-02      才江男                      1.0        查验信息按时间升序排列
 * 2017-05-05      才江男                      1.0        删除附件
 * 2017-05-09      吴有根                      1.0        添加一些非空的处理
 * 2017-05-09      才江男                      1.0        结束现场查验，进入结果登记
 * 2017-05-12      吴有根                     1.0.0      增加货物评定合格判断&返回集装箱检疫、木质包装检疫结果
 * 2017-05-13      才江男                     1.0.0      获取报检单所有的查验项目
 * 2017-05-13      才江男                     1.0.0      获取主辅施检标志
 * 2017-06-08      魏波                          1.0        关闭session
 * 2017-06-16      才江男                     1.0.0      更新报检单权限-辅施检保存现场查验后，不可操作
 * 2017-07-20      才江男                      1.0        附件
 * 2017-07-26               吴有根                      1.0	   	       根据报检单号带出企业、生产批号等基本信息
 * 2017-08-29               吴有根                      1.0		       报检单回写操作流程记录(&适用统计)
 * 2017-08-30      才江男                      1.0        结束查验分单-审单
 */
@Repository
public class SceneDao {

	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	PubCommonDAO daos = FrameworkHelper.getDAO();
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	/**
	 * 现场查验初始化查询
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SubOrReasEntity> getMagList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SubOrReasEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.expImpFlag =?");
		param.add(expImpFlag);
		sql.append(" AND t.exeInspOrgCode =?");
		param.add(exeInspOrgCode);
		sql.append(" AND t.receiverDocCode =?");
		param.add(receiverDocCode);
		sql.append(" AND t.checkPriv =?");
		param.add(CommContext.Y); 
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(declRegName)){
			sql.append(" AND t.declRegName like ?");
			param.add("%"+declRegName+"%");
		}
		sql.append(" ORDER BY t.declDate");
		
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		List<SubOrReasEntity> list=dao.getQueryList(sql.toString(), page, param.toArray());
	
		if(!CollectionUtils.isEmpty(list)){
			for(int i=0;i<list.size();i++){
				chgHibernateTemplate.evict(list.get(i));
				String pushString=getTradeCountryCodeByDeclNo(list.get(i).getDeclNo());
				list.get(i).setRemark(getTradeCountryNameByCode(pushString));
			}
				
		}
		return list;
	}
	
	
	/**
	 * 根据报检单号查询贸易国别
	 */
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	public String getTradeCountryCodeByDeclNo(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.trade_country_code from dcl_io_decl t where 1=1";
		if(StringUtils.isNotEmpty(declNo)){
			sql+=" and t.DECL_NO=?";
		}else{
			return "";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	} 

	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	public String getTradeCountryNameByCode(String code){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.cname from Z_CCM_WORLDDISTRICT t where 1=1";
		if(StringUtils.isNotEmpty(code)){
			sql+=" and t.itemcode=?";
		}else {
			return "";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, code);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}

	/**
	 * 现场查验-货物信息展示
	 * @param declNo
	 * @param currentPage
	 * @return
	 */
	public List<InsResultGoodsEntity> getInsResultGoodsList(String declNo,String currentPage) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}

		sql.append(" order by  t.goodsNo");

		Page page=MobileHelper.getPage(currentPage,"5");
		List<InsResultGoodsEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	 * 现场查验跳不合格登记
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	public InsResultGoodsEntity getInsResultGoodsEntity(String declNo,String goodsNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		if(StringUtils.isNotEmpty(goodsNo)){
			sql.append(" AND t.goodsNo =?");
			param.add(goodsNo);
		}
		
		List<InsResultGoodsEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}
	
	/**
	 * 根据货物序号和报检号获取查验项目
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	public List<InsCheckItemEntity> getInsCheckItemList(String declNo, String goodsNo,String checkItemName) {
		StringBuilder sql =new StringBuilder();
		
		sql.append("SELECT T.*,LEVEL FROM( ");
		sql.append(" SELECT A.CHECK_ITEM_ID,");
		sql.append("	A.DECL_NO,");
		sql.append("	A.GOODS_NO,");
		sql.append("	DECODE(A.NODE_CODE,null,sys_guid(),A.NODE_CODE) as NODE_CODE,");
		sql.append("	A.CHECK_ITEM_CODE,");
		sql.append("	A.CHECK_ITEM_NAME,");
		sql.append("	A.CHECK_ITEM_RESULT_CODE,");
		sql.append("	DECODE(A.PARENT_ITEM_CODE,null,'root',A.PARENT_ITEM_CODE) as PARENT_ITEM_CODE ,");
		sql.append("	A.CHECK_GOODS_TYPE,");
		sql.append("	A.PARENT_ITEM_NAME,");
		sql.append("	A.BATCH_DESC,");
		sql.append("	A.INSP_PROC_STATUS,");
		sql.append("	A.FALG_ARCHIVE,");
		sql.append("	A.SC_ORG_CODE,");
		sql.append("	A.SC_OPERATOR_CODE,");
        sql.append("	A.OPER_TIME,");
        sql.append("	A.SAMPLE_SCH,");
        sql.append("	A.ITEM_TYPE_CODE,");
        sql.append("	A.IS_APP_FLAG,");
        sql.append("	A.ADD_INPUT_FLAG,");
        sql.append("	A.CHECK_CONT,");
        sql.append("	A.WHETHER_QUALFY,");
        sql.append("	A.ARCHIVE_TIME,");
        sql.append("	A.CHECK_FORM_CODE");
		             //   + "	B.FORM_NAME "
		             //   + " B.FORM_NAME as {RulCheckFormEntity.formName}"
        sql.append("	FROM INS_CHECK_ITEM A LEFT JOIN RUL_CHECK_FORM B ");
        sql.append("	ON A.CHECK_FORM_CODE = B.CHECK_FORM_CODE ");
        sql.append("	WHERE A.DECL_NO =? ");
        if(StringUtils.isNotEmpty(checkItemName)) {
        	sql.append("	AND A.CHECK_ITEM_NAME like ? ");
        }
		                
		             //   + "	AND A.GOODS_NO = ? " //货物序号有可能为空
//		                +" AND ( A.GOODS_NO=? or A.GOODS_NO is null) "
        sql.append("	ORDER BY A.GOODS_NO,A.CHECK_CONT) T ");
        sql.append("	START WITH T.PARENT_ITEM_CODE = 'root' CONNECT BY PRIOR LOWER(T.NODE_CODE) = LOWER(T.PARENT_ITEM_CODE)");
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<InsCheckItemEntity> list=null;
		if(StringUtils.isNotEmpty(checkItemName)) {
			list=session.createSQLQuery(sql.toString()).addEntity(InsCheckItemEntity.class).setParameter(0, declNo).setParameter(1,"%"+checkItemName+"%").list();
		}else {
			list=session.createSQLQuery(sql.toString()).addEntity(InsCheckItemEntity.class).setParameter(0, declNo).list();
		}
		session.close();
		return list;
	}

	/**
	 * 根据报检号查验报检单结果基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<InsResultSumEntity> getInsResultSumList(String declNo, String expImpFlag) {
		StringBuilder sql=new StringBuilder();
		List<String> params=new ArrayList<String>();
		sql.append("FROM InsResultSumEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		List<InsResultSumEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}

	/**
	 * 指定参数查询
	 * @param orgCode   机构代码
	 * @param paperlessUrlParam  参数编码
	 * @return
	 */
	public String getPaperLessUrl(String orgCode, String paperlessUrlParam) {
		StringBuilder sql=new StringBuilder();
		sql.append("FROM SysConfigEntity t where 1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.companyCode=?");
			param.add(orgCode);
		}
		
		if(StringUtils.isNotEmpty(paperlessUrlParam)){
			sql.append(" AND t.configCode=?");
			param.add(paperlessUrlParam);
		}
		
//		List<SysConfigEntity> list=dao.getQueryList(sql.toString(),param.toArray());
//		return Utils.notEmpty(list)?(String)list.get(0).getConfigValue():"";
//		
		String sql2="SELECT t.* from SYS_CONFIG t where t.COMPANY_CODE=? and t.CONFIG_CODE=? ";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		List<SysConfigEntity> list=session.createSQLQuery(sql2).addEntity(SysConfigEntity.class).setParameter(0,orgCode).setParameter(1, paperlessUrlParam).list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0).getConfigValue():"";
	}


	/**
	 * 根据报检单号查询出入境报检单实体
	 * @param declNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public DclIoDeclEntity getIoEntDeclNo(String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclIoDeclEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<DclIoDeclEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	 * 根据报检号查询出口包装报检实体
	 * @param declNo
	 * @return
	 */
	public DclPackDeclEntity getPackEntDeclNo(String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclPackDeclEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<DclPackDeclEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	 * 通过报检号查询集装箱适载报检单实体
	 * @param declNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public DclContEntity getContainerEntDeclNo(String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclContEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.contDeclNo =?");
			param.add(declNo);
		}
		List<DclContEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	
	}

	/**
	 * 通过转单号查看转出局报检号
	 * @param declNo
	 * @return
	 */
	public String getOutDeclNoByTranNo(String tranNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM TraControlEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();

		if(StringUtils.isNotEmpty(tranNo)){
			sql.append(" AND t.tranNo =?");
			param.add(tranNo);
		}
		List<TraControlEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0).getDeclNoOut():"";
	
	}

	/**
	 * 保存现场查验记录
	 * @param entity
	 */
	public String updateEntity(Object o){
		String msg="";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		try {
			session.update(o);
			session.flush();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			msg="更新失败";
		}

		return msg;
	}


	
	/**
	* <p>描述:根据报检号查询流程日志</p>
	* @param declNo
	* @param checked
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public SysProcessLogEntity getSysProcessLogEntityByChecked(String declNo, String status) {
		StringBuilder sql=new StringBuilder();
		List<String> params=new ArrayList<String>();
		sql.append(" FROM SysProcessLogEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(status)){
			sql.append(" AND t.processStatus=?");
			params.add(status);
		}
		
		sql.append(" order by t.operDate asc");
		List<SysProcessLogEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:根据报检号查询报检已查验之后的日志</p>
	* @param declNo
	* @param date
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<SysProcessLogEntity> getSysProcessLogAfterChecked(String declNo, Date date) {
		StringBuilder sql=new StringBuilder();
		List<Object> params=new ArrayList<Object>();
		sql.append(" FROM SysProcessLogEntity t where 1=1");
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			params.add(declNo);
		}
		
		if(date!=null){
			sql.append(" AND t.operDate>?");
			params.add(date);
		}
		List<SysProcessLogEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}

	/**
	* <p>描述:保存附件路径到数据库</p>
	* @param entity
	* @author 才江男
	 */
	public void saveFile(InsDeclLobEntity entity) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		try {
			session.save(entity);
			session.flush();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	* <p>描述: 获取附件</p>
	* @param declNo 报检单号
	* @param userCode 用户代码
	* @return 附件
	* @author 才江男
	 */
	public List<DspFileAttach> loadFile(String declNo, String userCode, String flag) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		String sql = "select a FROM DspFileAttach a, InsDeclLobEntity t where a.fileId=t.path and t.declNo = ?";
		if(!"1".equals(flag)) {
			sql += " and t.operCode = ?";
		}
		Query query = session.createQuery(sql);
		query.setParameter(0, declNo);
		if(!"1".equals(flag)) {
			query.setParameter(1, userCode);
		}
		List<DspFileAttach> list = query.list();
		session.close();
		return list;
	}
	
	/**
	* <p>描述: 获取附件</p>
	* @param declNo 报检单号
	* @param userCode 用户代码
	* @return 附件
	* @author 才江男
	 */
	public List<InsDeclLobEntity> loadFile(String declNo) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		String sql = "FROM InsDeclLobEntity where declNo = ? ";
		List<InsDeclLobEntity> list=session.createQuery(sql).setParameter(0, declNo).list();
		session.close();
		return list;
	}
	
	/**
	* <p>描述: 删除附件</p>
	* @param path 附件
	* @author 才江男
	 */
	public void delFile(String path) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "DELETE FROM Ins_Decl_Lob where path = ?";
		session.createSQLQuery(sql).setParameter(0, path).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	* <p>描述:删除后台附件</p>
	* @param path
	* @author 才江男
	 */
	public void delDspFile(String path) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "DELETE FROM dsp_file_attach where file_id = ?";
		session.createSQLQuery(sql).setParameter(0, path).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	* <p>描述: 审单进入现场查验</p>
	* @param declNo 报检号
	* @param receiverDocCode 接单员代码
	* @param flowPathStatus 主辅检标志
	* @author 才江男
	 */
	public void examingToScene(String declNo, String receiverDocCode, String flowPathStatus) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG T SET CHECK_PRIV='1',AUDIT_PRIV = '0' WHERE T.DECL_NO = ? AND T.RECEIVER_DOC_CODE = ? AND T.FLOW_PATH_STATUS = ?";
		session.createSQLQuery(sql).setParameter(0, declNo).setParameter(1, receiverDocCode).setParameter(2, flowPathStatus).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 结束现场查验
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void endScene(String declNo, String receiverDocCode, String flowPathStatus) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG T SET SUB_PRIV='0',AUDIT_PRIV='0',CHECK_PRIV='0',REGI_PRIV='0' WHERE T.DECL_NO = ? AND T.FLOW_PATH_STATUS = ? ";
		if(!"fendanjieshuchayan".equals(receiverDocCode)) {
			sql += " AND T.RECEIVER_DOC_CODE = ? ";
		}
		SQLQuery createSQLQuery = session.createSQLQuery(sql);
		createSQLQuery.setParameter(0, declNo).setParameter(1, flowPathStatus);
		if(!"fendanjieshuchayan".equals(receiverDocCode)) {
			createSQLQuery.setParameter(2, receiverDocCode);
		}
		createSQLQuery.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 进入结果登记
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void enterResultRegister(String declNo, String receiverDocCode, String flowPathStatus) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG T SET CHECK_PRIV='0',REGI_PRIV='1' WHERE T.DECL_NO = ? AND T.RECEIVER_DOC_CODE = ? AND T.FLOW_PATH_STATUS = ?";
		session.createSQLQuery(sql).setParameter(0, declNo).setParameter(1, receiverDocCode).setParameter(2, flowPathStatus).executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:根据报检单号查询集装箱</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<DclIoDeclContDetailEntity> getDclIoDeclGoodsContEntitys(String declNo) {
		StringBuilder sql=new StringBuilder();
		List<String> params=new ArrayList<String>();
		sql.append(" FROM DclIoDeclContDetailEntity t where 1=1");
		sql.append(" AND t.declNo=?");
		params.add(declNo);
		List<DclIoDeclContDetailEntity> list=dao.getQueryList(sql.toString(), params.toArray());
		return list;
	}
	
	/**
	* <p>描述: 获取主辅施检标志</p>
	* @param expImpFlag 出入境标志
	* @param exeInspOrgCode 所属部门
	* @param receiverDocCode 接单员
	* @param declNo 报检号
	* @return 主辅施检标志
	* @author 才江男
	 */
	@SuppressWarnings("unchecked")
	public String getflowPathStatusByDeclNo(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append("select flowPathStatus FROM SubOrReasEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.expImpFlag =?");
		param.add(expImpFlag);
		sql.append(" AND t.exeInspOrgCode =?");
		param.add(exeInspOrgCode);
		sql.append(" AND t.receiverDocCode =?");
		param.add(receiverDocCode);
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		
		List<String> list=dao.getQueryList(sql.toString(), param.toArray());
		if(CollectionUtils.isEmpty(list)) {
			return null;
		}
		return list.get(0);
	}

	/**
	* <p>描述:根据报检单号查询集装箱检验结果信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsContainerResultEntity> findInsContainerResultListByDeclNo(String declNo) {
		String hql="FROM InsContainerResultEntity e where e.declNo =?";
		List<String> param = new ArrayList<String>();
		param.add(declNo);
		return dao.getQueryList(hql,param.toArray());
	}

	/**
	* <p>描述:查询报检单主施检记录</p>
	* @param declNo
	* @param flowPathStatusMain
	* @param inspOrgCode
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public InsDeclMagEntity getMainInsMag(String declNo, String flowPathStatus, String excInspDeptCode) {
		StringBuilder sql=new StringBuilder();
		sql.append("FROM InsDeclMagEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		sql.append(" AND t.flowPathStatus =?");
		param.add(flowPathStatus);
		sql.append(" AND t.excInspDeptCode =?");
		param.add(excInspDeptCode);
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}
	
	

	/**
	 * 
	* <p>描述:根据报检单号 从报检单管理表中查询出状态集合</p>
	* @param declNo
	* @param flowPathStatus
	* @param isChecked
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("unchecked")
    public List<InsDeclMagEntity> queryInsDeclMagStatus(String declNo, String flowPathStatus, boolean isChecked) {
        if (isChecked) {
        	StringBuilder sql=new StringBuilder();
    		sql.append("FROM InsDeclMagEntity t where  1=1 ");
    		List<String> param=new ArrayList<String>();
    		sql.append(" AND t.declNo =?");
    		param.add(declNo);
    		sql.append(" AND (t.flowPathStatus =?");
    		param.add(flowPathStatus);
    		sql.append(" or t.flowPathStatus =?)");
    		param.add(InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE);
    		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), param.toArray());
            return list;
        } else {
        	
        	StringBuilder sql=new StringBuilder();
    		sql.append("FROM InsDeclMagEntity t where  1=1 ");
    		List<String> param=new ArrayList<String>();
    		sql.append(" AND t.declNo =?");
    		param.add(declNo);
    		sql.append(" AND t.flowPathStatus=?");
    		param.add(flowPathStatus);
    		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), param.toArray());
            return list;
        }
    }
	
   
    /**
     * 
    * <p>描述:鉴定处理主表</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
	@SuppressWarnings("unchecked")
    public InsAuthenticateProcEntity getInsAuthenticateProcEntity(String declNo) {
    	
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsAuthenticateProcEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		List<InsAuthenticateProcEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
    	
    }
	
	/**
	 * 
	* <p>描述:检验检疫结果总结主辅检表</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("unchecked")
    public List<InsResultSumScEntity> getInsResultSumScEntity(String declNo, String scOperatorCode) {
    	
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsResultSumScEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		sql.append(" AND t.scOperatorCode =?");
		param.add(scOperatorCode);
		List<InsResultSumScEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
    }
    
	/**
	 * 
	* <p>描述:根据报检单号 查询隔离检表</p>
	* @param declNo
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("unchecked")
    public InsIsolationQuarEntity getInsIsolationQuarEntityByNo(String declNo) { 	
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsIsolationQuarEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		List<InsIsolationQuarEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;

    }
	
    /**
     * 
    * <p>描述:判断辅检是否处理完成</p>
    * @param declNo
    * @param excInspDeptCode
    * @param flowPathStatus
    * @return
    * @author 李云龙
     */
	@SuppressWarnings("unchecked")
    public InsDeclMagEntity getjudgeLoginDeptIsChecked(String declNo, String excInspDeptCode, String flowPathStatus) {
    	
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsDeclMagEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		sql.append(" AND t.excInspDeptCode =?");
		param.add(excInspDeptCode);
		sql.append(" AND t.flowPathStatus =?");
		param.add(flowPathStatus);
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), param.toArray());
        return Utils.notEmpty(list)?list.get(0):null;
    }

	/**
	* <p>描述:根据报检单号和操作员代码获取检验检疫结果总结表信息</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsResultSumEntity> getInsResultSumList2(String declNo, String userCode) {
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsResultSumEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		sql.append(" AND t.operatorCode =?");
		param.add(userCode);
		List<InsResultSumEntity> list=dao.getQueryList(sql.toString(), param.toArray());
        return list;
	}

	/**
	* <p>描述:判断辅检是否已完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public boolean isFjEnd(String declNo) {
		boolean b=true;
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "SELECT COUNT(1) FROM INS_DECL_MAG M WHERE M.DECL_NO=? AND M.FLOW_PATH_STATUS=? ";
		List<String> list=session.createSQLQuery(sql).setParameter(0, declNo).setParameter(1, InsContext.FLOW_PATH_STATUS_AUXILIARY).list();
		if(Utils.notEmpty(list)){
			if(Integer.parseInt(String.valueOf(list.get(0)))>0){
				b=false;
			}
		}
		session.getTransaction().commit();
		session.close();
		return b;
	}

	/**
	* <p>描述:根据报检单号查询集装箱是否合格</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("rawtypes")
	public String getContQuarResult(String declNo) {
		String contQuarResult=null;
    	StringBuilder sql=new StringBuilder();
		sql.append("SELECT t.contQuarResult FROM InsResultSumEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		List list=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(list)){
			contQuarResult=(String)list.get(0);
		}
        return contQuarResult;
	}

	/**
	* <p>描述:根据报检号查询集装箱结果表信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public List<InsContainerResultEntity> getCoutResultList(String declNo) {
    	StringBuilder sql=new StringBuilder();
		sql.append("FROM InsContainerResultEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		@SuppressWarnings("unchecked")
		List<InsContainerResultEntity> list=dao.getQueryList(sql.toString(), param.toArray());
        return list;
	}

	/**
	* <p>描述:根据报检号查询检验检疫结果表信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public InsResultSumEntity getInsResultSumEntityByNo(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append("FROM InsResultSumEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		@SuppressWarnings("unchecked")
		List<InsResultSumEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list) ? list.get(0) : null;
	}

	/**
	* <p>描述:根据报检单号查询隔离检疫信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public InsIsolationQuarEntity findInsIsolationQuarEntityByDeclNo(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append("FROM InsIsolationQuarEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		@SuppressWarnings("unchecked")
		List<InsIsolationQuarEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list) ? list.get(0) : null;
	}
    
	/**
	* <p>描述: 更新报检单权限-辅施检保存现场查验后，不可操作</p>
	* @param declNo 报检号
	* @author 才江男
	 */
	public void updatePriv(String declNo) {
		
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE INS_DECL_MAG SET SUB_PRIV='0',SUB_TYPE='1',AUDIT_PRIV='0',CHECK_PRIV='0',REGI_PRIV='0' WHERE DECL_NO = ? ";
		Query query=session.createSQLQuery(sql).setParameter(0,declNo);
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:根据报检号、流程状态和流程环节查询流程日志</p>
	* @param declNo  报检号
	* @param status   流程状态
	* @return
	* @author 张锡森
	*/
	@SuppressWarnings("unchecked")
	public SysAppProcessLog getSysAppProcessLog(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SysAppProcessLog t where  1=1 ");
		List<String> param = new ArrayList<String>();
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		sql.append(" order by t.operDate desc");
		List<SysAppProcessLog> list = daos.getQueryList(sql.toString(),
				param.toArray());
		return Utils.notEmpty(list) ? list.get(0) : null;
	}

	/**
	* <p>描述:获取复审开关</p>
	* @param orgCode
	* @return
	* @author 吴有根
	*/
	public String getReCheckSwitchFlag(String orgCode,String configCode) {
		StringBuilder sql = new StringBuilder();
		sql.append("FROM SysConfigEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.companyCode =?");
			param.add(orgCode);
		}else{
			return null;
		}
		if(StringUtils.isNotEmpty(configCode)){
			sql.append(" AND t.configCode =?");
			param.add(configCode);
		}else{
			return null;
		}
	//	@SuppressWarnings("unchecked")
	//	List<com.rongji.system.entity.SysConfigEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		
		String sql2="SELECT t.* from SYS_CONFIG t where t.COMPANY_CODE=? and t.CONFIG_CODE=? ";
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		@SuppressWarnings("unchecked")
		List<SysConfigEntity> list=session.createSQLQuery(sql2).addEntity(SysConfigEntity.class).setParameter(0,orgCode).setParameter(1, configCode).list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0).getConfigValue():"";
	}
	
	/**
	* <p>描述:</p>
	* @param obj
	* @author 保存实体
	 */
	public void saveObject(Object obj) {
		dao.saveObject(obj);
	}

	/**
	* <p>描述:由报检单号带出企业、生产批号等基本信息</p>
	* @param declNo
	* @author 吴有根
	*/
	public List<DeclBaseInfoModel> loadBaseInfoByDeclNo(String declNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="SELECT T.DECL_REG_NO, " + 
				"       T.DECL_REG_NAME," + 
				"       T.TRADE_COUNTRY_CODE," + 
				"       T.DESP_CTRY_CODE, " + 
				"       G.QTY," + 
				"       G.QTY_MEAS_UNIT," + 
				"       G.WEIGHT," + 
				"       G.WT_MEAS_UNIT," + 
				"       G.PROD_BATCH_NO," + 
				"		G.GOODS_ID,"+	
				"       G.GOODS_NO," + 
				"       G.MNUFCTR_REG_NAME"+
				"	FROM DCL_IO_DECL_GOODS G,DCL_IO_DECL T" + 
				" 	WHERE T.DECL_NO = G.DECL_NO" + 
				"       AND T.DECL_NO= ? ORDER BY G.DECL_NO ASC";
		@SuppressWarnings("unchecked")
		List<DeclBaseInfoModel> list=session.createSQLQuery(sql).addEntity(DeclBaseInfoModel.class).setParameter(0, declNo).list();		
		session.close();
		return list;
		
	}

	/**
	* <p>描述:记录报检单回写记录</p>
	* @param entity
	* @return
	* @author 吴有根
	*/
	public boolean recordCount(DclProcessStatsEntity entity) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		try {
			session.beginTransaction();
			session.saveOrUpdate(entity);
			session.getTransaction().commit();
			session.flush();
			session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	* <p>描述:根据报检单号获取回写记录</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public DclProcessStatsEntity getRecordCountByDeclNo(String declNo) {
		if(StringUtils.isEmpty(declNo)) {
			return null;
		}
		String sql="FROM DclProcessStatsEntity t where t.declNo=? ";
		List<String> param=new ArrayList<String>();
		param.add(declNo);
		@SuppressWarnings("unchecked")
		List<DclProcessStatsEntity> list=dao.getQueryList(sql, param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:获取操作号</p>
	* @param prefix
	* @return
	* @author 吴有根
	*/
	public List<String> getOperNoRul(String prefix) {
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql ="SELECT T.OPER_NO FROM  DCL_PROCESS_STATS T WHERE T.OPER_NO LIKE ? ";
		@SuppressWarnings("unchecked")
		List<String> list = session.createSQLQuery(sql).setParameter(0, prefix+"%").list();
		session.close();
		return list;
	}
	
	

    
}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      weibo
 * @version:     1.0
 * Createdate:   2017-7-20 下午2:43:35  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.scene.fireWork;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.InsResultRecord;
import com.rongji.eciq.mobile.entity.InsResultRecordItem;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.server.entity.InsDeclReviewSt;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo  
 * @version:    1.0  
 * Create at:   2017-7-20 下午2:43:35  
 *  
 */
@Repository
public class SceneFireWorkDao {
	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	/**
	 * 
	* <p>描述:根据报检单号查询烟花查验单信息</p>
	* @param declNo
	* @return
	* @author weibo
	 */
	public InsResultRecord getInsResultRecord(String declNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultRecord t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.declNo =?");
		param.add(declNo);
		List<InsResultRecord> list=dao.getQueryList(sql.toString(), param.toArray());
		if(!CollectionUtils.isEmpty(list)){
			return list.get(0);
		}else{
			return new InsResultRecord();
		}
	}
	
	/**
	 * 
	* <p>描述:根据记录单id查询检验项目</p>
	* @param resultRecordId
	* @return
	* @author weibo
	 */
	public List<InsResultRecordItem> getInsResultRecordItem(String resultRecordId){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultRecordItem t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.resultRecordId =? order by resultRecordItemId");
		param.add(resultRecordId);
		List<InsResultRecordItem> list=dao.getQueryList(sql.toString(), param.toArray());
		if(!CollectionUtils.isEmpty(list)){
			return list;
		}else{
			return null;
		}
	}
	
	/**
	* <p>描述: 根据报检单号获取唛头-标记号码e-CIQ</p>
	* @param declNo 报检单号
	* @return 唛头
	* @author 才江男
	 */
	public String getMarkNoByDeclNo(String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append("select markNo FROM DclIoDeclEntity t where t.declNo= ?");
		List<String> param=new ArrayList<String>();
		param.add(declNo);
		List<String> list=dao.getQueryList(sql.toString(), param.toArray());
		if(!CollectionUtils.isEmpty(list)){
			return list.get(0);
		}else{
			return "";
		}
	}
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	/**
	 * 
	* <p>描述:保存查验信息</p>
	* @param ins
	* @author weibo
	 */
	public void saveOrUpDate(InsResultRecord ins){
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.saveOrUpdate(ins);
		session.getTransaction().commit();
		session.flush();
		session.close();
	}
	
	/**
	 * 
	* <p>描述:保存检验项目</p>
	* @param ins
	* @author weibo
	 */
	public void saveOrUpDateItem(InsResultRecordItem ins){
		Session session = SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.saveOrUpdate(ins);
		session.getTransaction().commit();
		session.flush();
		session.close();
	}
}

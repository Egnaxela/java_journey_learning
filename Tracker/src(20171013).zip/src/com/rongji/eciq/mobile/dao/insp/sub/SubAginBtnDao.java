/**  
 * FileName:SubAginBtnDao.java     
 * @Description: 施检再分单dao层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午11:30:54  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.sub;

import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 施检再分单dao层
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 上午11:30:54  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version  
 */
@Repository
public class SubAginBtnDao {
	PubCommonDAO dao=FrameworkHelper.getChgDAO();

	/**
     * 根据报检号/施检机构代码查询施检管理表获得数量结果
     *
     * @param declNo 报检号
     * @param orgCode 机构代码
     * @return 记录数
     */
	@Autowired
	HibernateTemplate chgHibernateTemplate;
    public int getInsMagCountByDeclNoOrgCode(String declNo, String orgCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "select count(1) from ins_decl_mag m where m.decl_no = ? and m.exe_insp_org_code = ?";
        Query query = session.createSQLQuery(sql);
        query.setParameter(0, declNo);
        query.setParameter(1, orgCode);
        List list=query.list();
        session.close();
        if(CollectionUtils.isNotEmpty(list)){
        	return Integer.parseInt(list.get(0).toString());
        }
        return 0;
    }
    
    /**
     * 出入境施检再分单
     *
     * @param orgCode 再分单机构代码
     * @param declMagId 报检单管理表id
     */
    public void againSubmenu(String declMagId, String orgCode, String orgCodePatch) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String sql = "update ins_decl_mag i set i.exe_insp_org_code ='"+orgCode+"', i.exc_insp_dept_code ='"+orgCode+"',i.ORG_CODE_PATH  ='"+orgCodePatch+"',"
                + "i.receiver_doc_code = '', i.as_inp_tk_org_code = '',i.as_inp_tk_dept_code = '', i.oper_time = sysdate "
                + "where i.decl_mag_id  ='"+declMagId+"'";
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * 更新结果表接单人/施检机构代码
     *
     * @param declNo 报检单号
     * @param orgCode 施检机构代码
     * @param recCode 施检接单人代码
     */
    public void updateInsResultSum(String declNo, String orgCode, String companyCode, String recCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String sql = "update ins_result_sum s set s.operator_code = ?,"
                + "s.exe_insp_org_code = ?, s.exc_insp_dept_code = ? where s.decl_no = ?";
        Query query = session.createSQLQuery(sql);
        query.setParameter(0, recCode);
        query.setParameter(1, companyCode);
        query.setParameter(2, orgCode);
        query.setParameter(3, declNo);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    
}

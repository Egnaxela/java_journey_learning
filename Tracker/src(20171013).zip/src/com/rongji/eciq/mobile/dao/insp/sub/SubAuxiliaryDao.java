/**  
 * FileName:SubAuxiliaryDao.java     
 * @Description: 辅施检分单dao层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午11:30:54  
 *  
 */ 
package com.rongji.eciq.mobile.dao.insp.sub;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.LoginLogInfo;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.entity.SysOrganize;
import com.rongji.system.sys.utils.RedisUtils;

/**
 * 
 * Description: 辅施检分单dao层
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-2 下午4:37:28  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-2      李云龙                      1.0        获取本机构的报检单管理表信息
 * 2017-05-12    李晨阳                      1.0        机构代码转名称，名称为空时返回原代码
 * 2017-06-13    李晨阳                      1.0.0      整理代码，代码转名称替换为redis缓存
 * 2017-06-15    李云龙                      1.0.0      获取本机构的报检单管理表信息方法去掉权限条件
 * 2017-08-04    李云龙                      1.0.0      添加根据报检单号与部门代码获得施检管理记录方法。 
 */
@Repository
public class SubAuxiliaryDao {
	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	@Resource
	CompanyCodeUtils companyCodeUtils;
	@Resource
	RedisUtils redisUtils;
	
	/**
	 * 根据报检号查询报检单管理表
	 * @param declNo
	 * @return
	 */
	public InsDeclMagEntity findInsDeclMagEntity(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	List<String> param=new ArrayList<String>();
    	InsDeclMagEntity insDeclMagEntity=new InsDeclMagEntity();
    	String sql="select t FROM InsDeclMagEntity t where  1=1 AND t.declNo ='"+declNo+"' ";
    	Query query=session.createQuery(sql);
    	List<InsDeclMagEntity> list=query.list();
    	session.close();
    	if(!CollectionUtils.isEmpty(list)){
    		insDeclMagEntity =list.get(0);
        }
    	return insDeclMagEntity;
		
	}
	

	
	/**
	 * 根据报检号查询出入境报检扩展信息
	 * @param declNo
	 * @return
	 */
	public DclIoDeclEx findDclIoDeclEx(String declNo){
		StringBuilder sql=new StringBuilder();
    	List<String> param=new ArrayList<String>();
    	DclIoDeclEx dclIoDeclEx=new DclIoDeclEx();
    	sql.append(" FROM DclIoDeclEx t where  1=1 ");
    	sql.append(" AND t.declNo =?");
    	param.add(declNo);
    	List<DclIoDeclEx> list=dao.getQueryList(sql.toString(), param.toArray());
    	if(!CollectionUtils.isEmpty(list)){
    		dclIoDeclEx =list.get(0);
        }
    	return dclIoDeclEx;
	}
	

	/**
	 * 根据企业分类代码获得企业分类名称
	 * @param declNo
	 * @return
	 */

	public String findEntTypeName(String code){
		String EntTypeName = redisUtils.codeToName("Z_CCM_SIMPLELIST_2", code, "CorporationSort");
		if(null == EntTypeName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_SIMPLELIST_2 t where 1=1 and  t.INDEXID='CorporationSort' and t.code='"+code+"'";
			Query query=session.createSQLQuery(sql);
			List list=query.list();
			session.close();
			EntTypeName = (String) list.get(0);
		}
		return EntTypeName;
	}
	
	/**
	 * 根据机构代码查询机构名称
	 * @param orgCode
	 * @return
	 */
	public String getOrgCodeNameOrgCode(String code){
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		String orgName = redisUtils.codeToName("SYS_ORGANIZE", code);
		if(null == orgName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.ORG_NAME_SC from SYS_ORGANIZE t where 1=1 and  t.ORG_CODE='"+code+"'";
			Query query=session.createSQLQuery(sql);
			List list=query.list();
			session.close();
			if (!CollectionUtils.isEmpty(list)) {
				orgName = (String) list.get(0);
	        }else{
	        	orgName = code;
			}
		}
		return orgName;
	}
	
	
	
	/**
     * 根据报检单号获得施检管理记录
     *
     * @param declNo 报检单号
     * @return List<InsDeclMagVO>
     */
    @Autowired
	HibernateTemplate chgHibernateTemplate;
    public List<InsDeclMagEntity> findInsDeclListByDeclNo(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "select m.* from ins_decl_mag m where m.decl_no ='"+declNo+"' order by m.flow_path_status asc";
    	List<InsDeclMagEntity> list=session.createSQLQuery(sql).addEntity(InsDeclMagEntity.class).list();
		session.close();
		return list;
    }
	
    /**
     * 根据报检单号与部门代码获得施检管理记录
     *
     * @param declNo 报检单号
     * @return List<InsDeclMagVO>
     */
    public List<InsDeclMagEntity> findInsDeclListByDeclNoAndDeptCode(String declNo,String deptCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "select m.* from ins_decl_mag m where m.decl_no ='"+declNo+"' and m.exc_insp_dept_code='"+deptCode+"'";
    	List<InsDeclMagEntity> list=session.createSQLQuery(sql).addEntity(InsDeclMagEntity.class).list();
		session.close();
		return list;
    }
    
	
    /**
     * 根据报检单号获得施检结果登记实体
     *
     * @param declNo 报检单号
     * @return InsResultSumEntity
     */
    public InsResultSumEntity findInsResultSumByDeclNo(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "select t from InsResultSumEntity t where t.declNo =?";
        Query query = session.createQuery(sql);
        query.setParameter(0, declNo);
        List<InsResultSumEntity> list = query.list();
        session.close();
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0);
        }
        return null;
    }
    
	/**
	 * 证单号转名称
	 * @param code
	 * @return
	 */
    public String getIOFCertBillNameName(String code){
    	if (StringUtils.isEmpty(code)) {
			return null;
		}
    	String IOFCertBillName;
    	IOFCertBillName = redisUtils.codeToName("Z_CCM_SIMPLELIST_5", code, "IOFCertBillName");
    	if (null == IOFCertBillName) {
    		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        	String sql="SELECT CNAME FROM Z_CCM_SIMPLELIST_5 WHERE CODE=? AND INDEXID='IOFCertBillName'";
        	Query query=session.createSQLQuery(sql);
        	query.setParameter(0, code);
        	List list=query.list();
        	session.close();
        	if(CollectionUtils.isNotEmpty(list)){
        		IOFCertBillName = list.get(0).toString();
        	}
    	}
    	return IOFCertBillName;
    }
    
    /**
     * 根据机构代码查询机构信息
    * <p>描述:</p>
    * @param orgCode
    * @return
    * @author 李云龙
     */
    public SysOrganizeEntity getSysOrgByOrgCode(String orgCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String ql = "select t from SysOrganizeEntity t where t.orgCode ='"+orgCode+"' AND t.state = '1' ";
		Query query = session.createQuery(ql);
		List<SysOrganizeEntity> result = query.list();
		session.close();
		if (CollectionUtils.isEmpty(result)) {
			return null;
		} else {
			return result.get(0);
		}
	}
    
    /**
     * 根据机构分类码查询机构信息
    * <p>描述:</p>
    * @param categoryCode
    * @return
    * @author 李云龙
     */
    public SysOrganizeEntity getSysOrgByCategoryCode(String categoryCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String ql = "SELECT t FROM SysOrganizeEntity t WHERE t.categoryCode = ?  AND  t.state = '1' ";
		Query query = session.createQuery(ql);
		query.setParameter(0, categoryCode);
		List<SysOrganizeEntity> result = query.list();
		session.close();
		if (CollectionUtils.isEmpty(result)) {
			return null;
		}
		return result.get(0);
	}
	
    
    /**
     * 保存新增/修改/删除报检单管理表
     *
     * @param masterData 记录列表值变更对象
     */
    public void saveInsMag(List<InsDeclMagEntity>  allList) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);

    	if(CollectionUtils.isNotEmpty(allList)){
    		for(InsDeclMagEntity vo:allList){
    			session.beginTransaction();
    			session.merge(vo);
    			session.getTransaction().commit();
    		}
    	}
    	session.close();
    }
    
    /**
     * 删除报检单管理表
     *
     * @param masterData 记录列表值变更对象
     */
    public void deleteInsMag(List<InsDeclMagEntity>  allList) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);

    	if(CollectionUtils.isNotEmpty(allList)){
    		for(InsDeclMagEntity vo:allList){
    			session.beginTransaction();
    			session.delete(vo);
    			session.getTransaction().commit();
    		}
    	}
    	session.close();
    }
    
    
	
    /**
     * 更新主施检证单代码串
     *
     * @param declNo 报检单号
     * @param certCodes 申报证书代码串
     */
    public void updateMainCertCodes1(String declNo, String[] cert) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
    	String sql = "update ins_decl_mag m set m.cert_type_codes ='"+cert[0]+"',m.cert_type_names ='"+cert[1]+"' where m.decl_no ='"+declNo+"'"
                + " and m.flow_path_status ='800'";
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }

    
    /**
     * 更新是否存在辅检
     *
     * @param declNo
     * @param isHaveAux
     */
    public void updateIsHaveAux(String declNo, boolean isHaveAux) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
    	String sql = "update ins_decl_mag m set m.IS_HAVE_AUX = ? where m.decl_no = ? ";
        Query query = session.createSQLQuery(sql);
        query.setParameter(1, declNo);
        query.setParameter(0, (isHaveAux) ? CommContext.Y : CommContext.N);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    /**
	 * 根据机构代码查询该机构的分类码和父分类码
	 * 
	 * @param manager
	 *            事物管理
	 * @param orgCode
	 *            机构代码
	 * @return 上级机构代码
	 */
	public String[] queryCategory(String orgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		// 查询
		String sql = "SELECT e from SysOrganize e where e.orgCode = ? and e.state = '1' ";
		Query query = session.createQuery(sql);
		query.setParameter("orgCode", orgCode);
		List<SysOrganize> orgCodeList =query.list();
		session.close();
		if (CollectionUtils.isNotEmpty(orgCodeList)) {
			String categoryCode = orgCodeList.get(0).getCategoryCode();
			String seniorCategoryCode = orgCodeList.get(0)
					.getSeniorCategoryCode();
			return new String[] { categoryCode, seniorCategoryCode };
		}
		return null;
	}
    
    
	/**
	 * 判断是否完成鉴定处理
	 * 
	 * @param declNo
	 * @return
	 */
	public InsAuthenticateProcEntity getInsAuthenticateProcEntity(String declNo) {
		Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
		String hql = "select e from InsAuthenticateProcEntity e where e.declNo=?";
		Query query = session.createQuery(hql);
		query.setParameter(0, declNo);
		List<InsAuthenticateProcEntity> list = query.list();
		session.close();
		if (CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		} else {
			return null;
		}
	}
    
	/**
	 * 查询   检验检疫结果总结主辅检表信息
	* <p>描述:</p>
	* @param declNo
	* @param userCode 操作员代码
	* @return
	* @author 李云龙
	 */
	public List<InsResultSumScEntity> getInsResultSumScEntity(String declNo, String userCode) {
		Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
        String hql = "select e from InsResultSumScEntity e where e.declNo =? and e.scOperatorCode =? ";
        Query query = session.createQuery(hql);
        query.setParameter(0, declNo);
        query.setParameter(1, userCode);
        List<InsResultSumScEntity> insResultSumScEntitys = query.list();
        session.close();
        return insResultSumScEntitys;
    }
    
	/**
     * 根据报检单号 查询隔离检表
     *
     * @param declNo
     *
     * @return
     */
    public InsIsolationQuarEntity getInsIsolationQuarEntityByNo(String declNo) {
    	Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
        String ql = "SELECT a FROM InsIsolationQuarEntity a WHERE a.declNo =?";
        Query query = session.createQuery(ql);
        query.setParameter(0, declNo);
        List<InsIsolationQuarEntity> list = query.list();
        session.close();
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0);
        } else {
            return null;
        }
    }
    
    /**
     * 更新主辅检标记
     *
     * @param magId 管理表id
     * @param flowPathStatus 主辅检标记
     */
    public void updateFlowPathStatus(String magId, String flowPathStatus) {
    	Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String sql = "update ins_decl_mag m set m.flow_path_status ='"+flowPathStatus+"' where m.decl_mag_id ='"+magId+"'";
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
        
    }
    
    /**
     * 保存实体
     *
     * @param entity  实体
     * @param isAdd   是否为新增
     * @param service 服务类
     */
    public <T extends Serializable> void saveEntity(T entity, boolean isAdd) {
    	Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        if (isAdd) {
        	session.persist(entity);
        } else {
        	session.merge(entity);
        }
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * 更新出入境报检基本信息扩展表FILED_ORG_CODE字段
     *
     * @param declNo
     * @param orgCode
     */
    public void updatDeclExFledOrgCode(String declNo,String orgCode) {
    	Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String sql = "update DCL_IO_DECL_EX m set m.FILED_ORG_CODE ='"+orgCode+"' where m.decl_no ='"+declNo+"'" ;
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * 获取本机构的报检单管理表信息
    * <p>描述:</p>
    * @author 李云龙
     */
    public InsDeclMagEntity getInsDeclMag(String declNo,String expImpFlag,String orgCode){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	//String sql = "select m from InsDeclMagEntity m where m.declNo ='"+declNo+"' and m.expImpFlag='"+expImpFlag+"' and m.excInspDeptCode='"+orgCode+"' and m.subPriv ='1'";
    	String sql = "select m from InsDeclMagEntity m where m.declNo ='"+declNo+"' and m.expImpFlag='"+expImpFlag+"' and m.excInspDeptCode='"+orgCode+"'";
    	Query query=session.createQuery(sql);
    	List<InsDeclMagEntity> list=query.list();
    	session.close();
    	if(CollectionUtils.isNotEmpty(list)){
    		return list.get(0);
    	}
		return null;
    }
    
    
    public List<InsDeclMagEntity>  getInsDeclMagList(String declNo){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "select m from InsDeclMagEntity m where m.declNo ='"+declNo+"'" ;
    	Query query=session.createQuery(sql);
    	List<InsDeclMagEntity> list=query.list();
    	session.close();
    	return list;
    }
    
    /**
     * 
    * <p>描述:根据报检号查询流程状态</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
    public String getProcessStatus(String declNo){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = "select m from DclIoDeclEntity m where m.declNo ='"+declNo+"'" ;
    	Query query=session.createQuery(sql);
    	List<DclIoDeclEntity> list=query.list();
    	session.close();
    	if(CollectionUtils.isNotEmpty(list)){
    		return list.get(0).getProcessStatus();
    	}
    	return null;   	
    }



	/**
	* <p>描述:保存登录日志</p>
	* @param log
	* @author 夏晨琳
	*/
	public void saveLog(LoginLogInfo log) {
		dao.saveObject(log);		
	}
}

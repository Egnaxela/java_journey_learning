/**  
 * FileName:    SubDeclContDao.java
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 下午2:41:46  
 *  
 */  

package com.rongji.eciq.mobile.dao.insp.sub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.DclProcessCountEntity;
import com.rongji.eciq.mobile.entity.InsCheckCommand;
import com.rongji.eciq.mobile.entity.InsCheckCommandCont;
import com.rongji.eciq.mobile.entity.InsContModel;
import com.rongji.eciq.mobile.entity.InsDrawRecord;
import com.rongji.eciq.mobile.entity.OrdFeedbackDetailVo;
import com.rongji.eciq.mobile.entity.SysIfcCheckCommonModel;
import com.rongji.eciq.mobile.model.insp.sub.SubInsContModel;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 分单改派单dao层  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 下午2:41:46  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */
@Repository
public class SubDeclContDao {
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	PubCommonDAO dao=FrameworkHelper.getChgDAO();

	/**
	* <p>描述:根据报检单号获得所有集装箱</p>
	* @param declNo
	* @return
	* @author 夏晨琳
	*/
	public List<InsContModel> getContList(String declNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql ="select t.cont_dt_id,t.decl_no,t.cont_no,r.is_check,r.if_open_box,r.if_draw_box,"
                + "r.ins_draw_record_id, r.oper_Code,t.CNTNR_MODE_CODE from dcl_io_decl_cont_detail t left join ins_draw_record r on "
                + "t.decl_no = r.decl_no and t.cont_no = r.cont_no and t.CNTNR_MODE_CODE = r.CNTNR_MODE_CODE where t.decl_no = "+declNo+"";
    	List<InsContModel> list=session.createSQLQuery(sql).addEntity(InsContModel.class).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:通过报检号/集装箱号获得所关联货物信息集合</p>
	* @param declNo
	* @param contNo
	* @return
	* @author 夏晨琳
	*/
	public List<DclIoDeclGoodsEntity> getGoodsList(String declNo, String contNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer("select g.* from dcl_io_decl_goods_cont c join dcl_io_decl_goods g "
                + "on g.goods_id = c.goods_id where c.decl_no = ? and c.cont_code = ? ");
		Query query=session.createSQLQuery(sb.toString());
		List<DclIoDeclGoodsEntity> list=query.setParameter(0, declNo).setParameter(1,contNo).list();
		session.getTransaction().commit();
		session.close();
		return list;
	}

	/**
	* <p>描述:判断是否发送查验指令</p>
	* @param declNo
	* @param contNo
	* @param cntnrModeCode
	* @return
	* @author 夏晨琳
	*/
	public boolean findCheckCommandByContNo(String declNo, String contNo, String cntnrModeCode) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("select d.declNo,c from InsCheckCommandCont c, InsCheckCommand d "
                + "where d.checkCmdId = c.checkCmdId and d.declNo = ? ");
		param.add(declNo);
		if (StringUtils.isNotEmpty(contNo)) {
			sql.append(" and c.contNo = ? ");
			param.add(contNo);
		}
		if (StringUtils.isNotEmpty(cntnrModeCode)) {
			sql.append(" and c.cntnrModeCode = ? ");
			param.add(cntnrModeCode);
		}
		List<String[]> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?true:false;
	}

	/**
	* <p>描述:保存开掏箱设置</p>
	* @param addList
	* @author 夏晨琳
	*/
	public void saveBoxSet(List<SubInsContModel> addList,String operCode) {
		InsDrawRecord entity;
		for (SubInsContModel cont : addList) {
			if(Utils.isEmpty(cont.getInsDrawRecordId())){
				entity = new InsDrawRecord();
                entity.setInsDrawRecordId(UUIDKeyGeneratorUils.newInstance().generateKey());
                entity.setGoodsNames(cont.getDeclGoodsCnames());
                entity.setGoodsNos(cont.getGoodsNos());
                entity.setDeclNo(cont.getDeclNo());
                entity.setContNo(cont.getContNo());
                entity.setOperDate(new Date());
                entity.setCntnrModeCode(cont.getCntnrModeCode());
                entity.setOperCode(operCode);//操作人代码
			}else{
				entity = getInsDrawRecord(cont.getInsDrawRecordId());
				entity.setOperDate(new Date());
			}
			//开掏箱设置
            //增加相应校验，判断当前查验、开箱、掏箱是否为规则命中，如果是则存入规则命中代码“2” add by 董方旭
            if (cont.getIsCheck() != null && StringUtils.equals(cont.getIsCheck(), "2")) {
                entity.setIsCheck(cont.getIsCheck());
            } else {
                entity.setIsCheck(cont.isChekIs() ? "1" : "0");
            }
            if (cont.getIfOpenBox() != null && StringUtils.equals(cont.getIfOpenBox(),"2")) {
                entity.setIfOpenBox(cont.getIfOpenBox());
            } else {
                entity.setIfOpenBox(cont.isIfOpeBox() ? "1" : "0");
            }
            if (cont.getIfDrawBox() != null && StringUtils.equals(cont.getIfDrawBox(),"2")) {
                entity.setIfDrawBox(cont.getIfDrawBox());
            } else {
                entity.setIfDrawBox(cont.isIfDrwBox() ? "1": "0");
            }
          //保存开掏箱设置
          saveEntity(entity);
		}
		
	}

	/**
	* <p>描述:保存</p>
	* @param entity
	* @author 夏晨琳
	*/
	private void saveEntity(Object entity) {
		dao.saveObject(entity);
	}

	/**
	* <p>描述:根据主键获取对象</p>
	* @param insDrawRecordId
	* @return
	* @author 夏晨琳
	*/
	private InsDrawRecord getInsDrawRecord(String insDrawRecordId) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("from InsDrawRecord where 1=1 where insDrawRecordId = ?  ");
		param.add(insDrawRecordId);
		List<InsDrawRecord> list=dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:发送查验指令</p>
	* @param checkEntity
	* @param contList
	* @param list
	* @author 夏晨琳
	 * @param operCode 
	*/
	public void sendCommand(InsCheckCommand checkEntity, List<InsCheckCommandCont> contList, List<SubInsContModel> list, String operCode) {
		if(checkEntity != null && Utils.notEmpty(contList) && Utils.notEmpty(list)){
			//先保存开掏箱设置
			saveBoxSet(list, operCode);
			checkEntity.setIsCheckFinished("0");
			checkEntity.setOperTime(new Date());
			  //保存查验指令及集装箱查验信息
            saveEntity(checkEntity);
            if(Utils.notEmpty(contList)){
            	for (InsCheckCommandCont check : contList) {
					dao.saveObject(check);
				}
            }
		}
	}

	/**
	* <p>描述:获取查验场地集合</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	 * @param fieldName 
	 * @param fieldNo 
	*/
	public List<SysIfcCheckCommonModel> queryInspList(String orgCode, String fieldNo, String fieldName) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	String sql = " SELECT a.CHECK_FIELD_NO, " +//查验场编号
                " a.CHECK_FIELD_NAME," +//查验场名称
                " a.PAGE_CHECK_RATIO," +//查验场分配率
                " b.PORT_NAME," +//所属港区 港区名称
                " b.PORT_CODE," +// 港区代码
                " a.CHECK_ORG," +//查验处室代码
                " a.CHECK_NAME" +//查验处室名称
                " FROM SYS_IFC_CHECK_FIELD a"
                + " LEFT JOIN SYS_PORT_REPAIR b"
                + " ON b.PORT_CODE = a.OWNER_PORT"
                + " WHERE a.CHECK_ORG IN (" + makeOrgMutiSql(orgCode) + ")";
    	if(Utils.notEmpty(fieldNo)){
    		sql = sql + "AND a.CHECK_FIELD_NO LIKE %"+fieldNo+"%  ";
    	}
    	if(Utils.notEmpty(fieldName)){
    		sql = sql + "AND a.CHECK_FIELD_NAME LIKE %"+fieldName+"% ";
    	}
    	List<SysIfcCheckCommonModel> list=session.createSQLQuery(sql).addEntity(SysIfcCheckCommonModel.class).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	*/
	private String makeOrgMutiSql(String orgCode) {
		String subSql = "SELECT "
                + " DISTINCT ORG_CODE"
                + " FROM SYS_ORGANIZE T2 "
                + " START WITH T2.CATEGORY_CODE = (SELECT CATEGORY_CODE FROM SYS_ORGANIZE WHERE ORG_CODE='"
                + orgCode + "' ) "
                + " CONNECT BY  SENIOR_CATEGORY_CODE = PRIOR CATEGORY_CODE";
        return subSql;
	}

}

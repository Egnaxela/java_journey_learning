/**  
 * FileName: SubOrReasDao.java    
 * @Description: 分单改派单dao查询类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */
package com.rongji.eciq.mobile.dao.insp.sub;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.entity.AuxInsProcessLogEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsGoodsMonItemEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsMonItemEvalStdEntity;
import com.rongji.eciq.mobile.entity.InsOriaudiExcePbinfoEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.RulBatchruleEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SupEntAttribute;
import com.rongji.eciq.mobile.entity.SupEntClassify;
import com.rongji.eciq.mobile.entity.SysBusinessLockEntity;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysSwitchOrg;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.insp.scene.GoodsResultRegisterModel;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.sys.utils.RedisUtils;

/**
 * Description  分单改派单dao查询类
 * @author      吴有根
 * @version     1.0
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------ 
 * 2017-04-14     李云龙                       1.0        添加updatePriv方法    
 * 2017-04-14     李云龙                       1.0        分单改派单---更新施检总结果表
 * 2017-04-14     李云龙                       1.0        分单改派单---更新施检总结果表
 * 2017-04-14     李云龙                       1.0        根据人员代码查询名称
 * 2017-04-14     李云龙                       1.0        根据报检单号，查询管理表辅施检机构，并获取其直属局信息
 * 2017-04-14     李云龙                       1.0        记录辅施检流程日志
 * 2017-04-14     李云龙                       1.0        判断是否有锁
 * 2017-04-14     李云龙                       1.0        非报检单号解锁(业务主键)
 * 2017-04-14     李云龙                       1.0        添加判断人员与机构是否匹配
 * 2017-04-14     李云龙                       1.0        根据机构代码填充机构map 
 * 2017-04-14     李云龙                       1.0        记录辅施检流程日志
 * 2017-04-14     李云龙                       1.0        根据报检号查询报检单管理表
 * 2017-04-28     李云龙                        1.0        修改保存实体方法
 * 2017-05-02     李云龙                        1.0        修改根据报检单号查询贸易国别代码方法
 * 2017-05-11     才江男                        1.0        去掉机构路径条件
 * 2017-05-12     李云龙                        1.0        根据报检号与施检部门获得出入境报检单基本信息
 * 2017-05-12     李晨阳                       1.0        用户代码转名称，名称为空时返回原代码
 * 2017-05-13     才江男                       1.0        不合格登记时，更新现场记录货物评定为不合格
 * 2017-06-06     魏波                            1.0        辅检完成公用方法
 * 2017-06-08     魏波                            1.0        关闭session
 * 2017-06-08     才江男                        1.0        关闭session
 * 2017-06-13     李晨阳                         1.0        整理代码，代码转名称替换为redis缓存
 * 2017-06-22     才江男                        1.0        保存检验评定结果，检疫评定结果
 * 2017-07-07     才江男                        1.0        根据报检单号和货物序号保存
 */
@Repository
public class SubOrReasDao {
	@Resource
	CompanyCodeUtils companyCodeUtils;
	@Resource
	RedisUtils redisUtils;

	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	public List<SubOrReasEntity> querySubList(String declNo, String orgCode, String orgPath, String subStatus,
			String recCode, String processStatus, Date starDate, Date endDate, String checkRequire,
			String consigneeCname, String expImpFlag, String entName, String declRegName, String userOrgCode,String currentPage) {
		
		subStatus="1";//分单状态 【0为已分单,1为未分单】
		
//		//施检部门代码  没有该查询条件
//		if(StringUtils.isEmpty(orgCode)){
//			orgPath=this.getOrgPathByOrgCode(userOrgCode);
//		}else {
//			orgPath=this.getOrgPathByOrgCode(orgCode);
//		}
		
		//PubCommonDAO dao =DaoHelper.getSystemPageDAO();
		StringBuilder sql = new StringBuilder();
		
		
		sql.append("SELECT distinct(t.declNo),t FROM SubOrReasEntity as t,SysProcessLogEntity as s where  t.declNo=s.declNo ");
		List<String> param=new ArrayList<String>();
		
		if(StringUtils.isNotEmpty(expImpFlag)){//出入境
			sql.append(" AND t.expImpFlag =?");
			param.add(expImpFlag);
		}
		
		String subPriv="1";//分单权限
		if(StringUtils.isNotEmpty(subPriv)){
			sql.append(" AND t.subPriv=?");
			param.add(subPriv);
		}
		
		subStatus=subStatus instanceof Object?subStatus:"1";
		if(StringUtils.isNotEmpty(subStatus)){
			sql.append(" AND t.subType=?"); //分单状态
			param.add(subStatus);
		}
		
		if(StringUtils.isNotEmpty(userOrgCode)){
			sql.append(" AND t.exeInspOrgCode = ?");
			param.add(userOrgCode);
		}
		
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			param.add(declNo);
		}
		if(StringUtils.isNotEmpty(declRegName)){
			sql.append(" AND t.declRegName like ?");
			param.add("%"+declRegName+"%");
		}
		if(StringUtils.isEmpty(currentPage)){
			currentPage="1";
		}
		Page page=MobileHelper.getPage(currentPage);
		
		List<SubOrReasEntity> list=new ArrayList<SubOrReasEntity>();
		@SuppressWarnings("unchecked")
		List<Object[]> list0 =dao.getQueryList(sql.toString(),page,param.toArray());
		
		for (Object[] object : list0) {
			list.add((SubOrReasEntity)object[1]);
		}
		
		if(!CollectionUtils.isEmpty(list)){
			for(int i=0;i<list.size();i++){
				chgHibernateTemplate.evict(list.get(i));
				String pushString=getTradeCountryCodeByDeclNo(list.get(i).getDeclNo());
				list.get(i).setRemark(getTradeCountryNameByCode(pushString));
			}
				
		}
		return list;
	}
	
	/**
	 * 获取机构代码串
	* <p>描述:</p>
	* @param orgCode
	* @return
	* @author 李云龙
	 */
	@SuppressWarnings("unchecked")
	public String getOrgPathByOrgCode(String orgCode) {
		if (StringUtils.isNotEmpty(orgCode)) {
			List<SysOrganizeEntity> list = dao
					.getQueryList("SELECT s FROM SysOrganizeEntity s WHERE s.orgCode = ?", orgCode);
			if (!CollectionUtils.isEmpty(list)) {
				return list.get(0).getOrgCodePath();
			}
		}
		return null;
	}
	
	/**
	 * 根据报检单号查询贸易国别代码
	 */
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	public String getTradeCountryCodeByDeclNo(String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.trade_country_code from dcl_io_decl t where 1=1";
		if(StringUtils.isNotEmpty(declNo)){
			sql+=" and t.DECL_NO=?";
		}
		
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		if(!CollectionUtils.isEmpty(list)) {
			return list.get(0).toString();
		}
		return "";
	} 

	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	public String getTradeCountryNameByCode(String code){
		String TradeCountryName = redisUtils.codeToName("Z_CCM_WORLDDISTRICT", code, "WorldDistrict");
		
		if(null == TradeCountryName){
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql="select t.cname from Z_CCM_WORLDDISTRICT t where 1=1";
			if(StringUtils.isNotEmpty(code)){
				sql+=" and t.itemcode=?";
			} else {
				return "";
			}
			
			Query query=session.createSQLQuery(sql).setParameter(0, code);
			List list=query.list();
			session.close();
			if(!CollectionUtils.isEmpty(list)) {
				return (String)list.get(0);
			}
			return "";
		}
		
		return TradeCountryName;
	}

	/**
	 * 
	 * @param declNos
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SubOrReasEntity> queryList(String declNos,String expImpFlag,String userOrgCode) {
		// expImpFlag 后续复用再添加
		
		List<String> declNoList=new ArrayList<String>();
		String[] str=declNos.split(",");
		declNoList=Arrays.asList(str);
		StringBuilder hql=new StringBuilder();
		hql.append("SELECT t FROM SubOrReasEntity t WHERE t.declNo IN (:alist)");
		hql.append("	AND t.expImpFlag =:expImpFlag");
		hql.append("	AND t.exeInspOrgCode =:exeInspOrgCode");
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	    Query query = session.createQuery(hql.toString());  
	    query.setParameterList("alist",declNoList);  
	    query.setParameter("expImpFlag", expImpFlag);
	    query.setParameter("exeInspOrgCode", userOrgCode);
		List<SubOrReasEntity> list=query.list();
		session.close();
		return list;
	}

	public void  update(SubOrReasEntity entity,String userCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.merge(entity);
		session.flush();
		session.close();
		this.updateResultSum(userCode,entity.getDeclNo());
		
	}
	
	public void updateResultSum(String userCode,String declNo){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="update INS_RESULT_SUM t set t.OPERATOR_CODE=? where t.DECL_NO=?";
		Query query=session.createSQLQuery(sql).setParameter(0,userCode).setParameter(1, declNo);
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
		
	}

	public boolean updateResiter(GoodsResultRegisterModel model,String code,String type){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="";
		//检疫
		if(type.equals("1")){
			sql+= "update INS_RESULT_GOODS t set t.INP_UNQUAL_HA_CODE=? ," +//检验不合格处理
						" t.INSP_UNQUAF_WT=?, " +//检验不合格重量
						" t.UNQUL_COMM_INS_QTY=?, " +//检验不合格数量
						" t.INSP_UNQUA_AMT=? ," +//检验不合格金额
						" t.INSP_UNQ_RESN=? ," +//检验不合格原因
						" t.INSP_DISQUA_CONT_CODES=? ," +//检验不合格内容
						" t.QUR_UNQ_PROC_CODE=? ," +//检疫不合格处理
						" t.SPE_QUAR_TRMT_MEC_C=? ," +//检疫不合格处理方法
						" t.QUARAN_UNQUA_WT=? ," +//检疫不合格重量
						" t.UNQULFD_QUAR_QTY=? ," +//检疫不合格数量
						" t.UNQUAL_QUAR_AMT=? ," +//检疫不合格金额
						" t.QUR_UNQUL_RSN_CODE=? ," +//检疫不合格原因
						" t.QUAR_DISQUA_CONT_CODES=? ," +//检疫不合格内容
						" t.UNQUAL_QTY=? ," +//不合格数量
						" t.UNQUAL_AMT=? ," +//不合格金额
						" t.UNQUA_WT=? ," +//不合格重量
						" t.QUAR_RES_SPOT='"+code+"'"+//检疫代码
						" where t.DECL_NO=? and t.GOODS_NO=? ";
		}else{//检验
			sql+= "update INS_RESULT_GOODS t set t.INP_UNQUAL_HA_CODE=? ," +//检验不合格处理
					" t.INSP_UNQUAF_WT=?, " +//检验不合格重量
					" t.UNQUL_COMM_INS_QTY=?, " +//检验不合格数量
					" t.INSP_UNQUA_AMT=? ," +//检验不合格金额
					" t.INSP_UNQ_RESN=? ," +//检验不合格原因
					" t.INSP_DISQUA_CONT_CODES=? ," +//检验不合格内容
					" t.QUR_UNQ_PROC_CODE=? ," +//检疫不合格处理
					" t.SPE_QUAR_TRMT_MEC_C=? ," +//检疫不合格处理方法
					" t.QUARAN_UNQUA_WT=? ," +//检疫不合格重量
					" t.UNQULFD_QUAR_QTY=? ," +//检疫不合格数量
					" t.UNQUAL_QUAR_AMT=? ," +//检疫不合格金额
					" t.QUR_UNQUL_RSN_CODE=? ," +//检疫不合格原因
					" t.QUAR_DISQUA_CONT_CODES=? ," +//检疫不合格内容
					" t.UNQUAL_QTY=? ," +//不合格数量
					" t.UNQUAL_AMT=? ," +//不合格金额
					" t.UNQUA_WT=? ," +//不合格重量
					" t.INSP_RES_SPOT='"+code+"'"+//检验代码
					" where t.DECL_NO=? and t.GOODS_NO=? ";
		}
//		String sql =
		Query query=session.createSQLQuery(sql).setParameter(0,model.getInpUnqualHaCode()).setParameter(1,model.getInspUnquafWt())
				.setParameter(2,model.getUnqulCommInsQty()).setParameter(3, model.getInspUnquaAmt()).setParameter(4, model.getInspUnqResn())
				.setParameter(5, model.getInspDisquaContCodes()).setParameter(6, model.getQurUnqProcCode()).setParameter(7, model.getSpeQuarTrmtMecC())
				.setParameter(8, model.getQuaranUnquaWt()).setParameter(9, model.getUnqulfdQuarQty()).setParameter(10,model.getUnqualQuarAmt())
				.setParameter(11, model.getQurUnqulRsnCode()).setParameter(12, model.getQuarDisquaContCodes()).setParameter(13,model.getUnqualQty())
				.setParameter(14,model.getUnqualAmt()).setParameter(15, model.getUnquaWt()).setParameter(16, model.getDeclNo()).setParameter(17, model.getGoodsNo());
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
		if(i==0){
			return false;
		}else{
			return true;
		}
//		return null;
	}
	
	/**
	* <p>描述: 不合格登记时，更新现场记录为货物评定为不合格</p>
	* @param declNo 报检号
	* @author 才江男
	 */
	public void updateRecordCheck(String declNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="update ins_result_sum s set s.goods_eval_result ='0' where s.decl_no=?";
		Query query=session.createSQLQuery(sql).setParameter(0,declNo);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	
	
	/**
	 * 保存实体方法
	* <p>描述:</p>
	* @param entity
	* @param isAdd
	* @author 李云龙
	 */
	public <T extends Serializable> void saveEntity(T entity, boolean isAdd) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.merge(entity);
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 更新MAG表的退单原因
	 * @param declMagId
	 * @param backReason
	 */
	public void updateBackReason(String declMagId, String backReason) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="update INS_DECL_MAG t set t.RET_REASON=? where t.DECL_MAG_ID=?";
		Query query=session.createSQLQuery(sql).setParameter(0,backReason).setParameter(1, declMagId);
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

    /**
     * 更新主检权限
    * <p>描述:</p>
    * @param declMagId
    * @param subBack
    * @author 李云龙
     */
	public void updatePriv(String declMagId, HashMap<String, String> subBack) {
		// TODO Auto-generated method stub
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		 boolean f = false;
	        StringBuilder b = new StringBuilder("update ins_decl_mag m set ");
	        if (subBack != null && !subBack.isEmpty()) {
	            f = true;
	            for (Map.Entry<String, String> entry : subBack.entrySet()) {
	                b.append(entry.getKey()).append("='").append(entry.getValue()).append("',");
	            }
	        }
	        if (b.length() > 0 && b.lastIndexOf(",") == b.length() - 1) {
	            b = new StringBuilder(b.substring(0, b.length() - 1));
	        }

	        b.append(" where m.DECL_MAG_ID =  '"+declMagId+"'");

	        Query query = session.createSQLQuery(b.toString());

//	        if (f) {
//	            for (Map.Entry<String, String> entry : subBack.entrySet()) {
//	                query.setParameter(entry.getKey(), entry.getValue());
//	            }
//	        }
	        query.executeUpdate();
	        session.getTransaction().commit();
	        session.close();
		
	}

	public void dltInsDelMagById(String declMagId) {
		// TODO Auto-generated method stub
		
	}

	public void updateIsHaveAux(String declNo, boolean b) {
		// TODO Auto-generated method stub
		
	}


	public List<SubOrReasEntity> findInsDeclMagByFlowType2(String declNo) {
		// TODO Auto-generated method stub
		return null;
	}

	
	/**
	 * 分单改派单-审单查看
	 * 根据报检单号查询货物信息带分页
	 * @param declNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<DclIoDeclGoodsEntity> queryGoodsListByDeclNo(String declNo,String currentPage) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM DclIoDeclGoodsEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		
		if(StringUtils.isNotEmpty(declNo)){//出入境
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		Page page=MobileHelper.getPage(currentPage,"3");//默认3页
		List<DclIoDeclGoodsEntity> list=dao.getQueryList(sql.toString(),page, param.toArray());
		if(!CollectionUtils.isEmpty(list)){
			for(DclIoDeclGoodsEntity vo :list){
			//	chgHibernateTemplate.evict(vo);
				vo.setCurrency(getMeasurementNameByCode(vo.getCurrency(),"CurrencyType"));
				vo.setQtyMeasUnit(getMeasurementNameByCode(vo.getQtyMeasUnit(),"Measurement"));
				vo.setWtMeasUnit(getMeasurementNameByCode(vo.getWtMeasUnit(),"Measurement"));
			}
		}
		return list;
	}
	
	
	/**
	 * 计量单位和货币代码转名称
	 * @param code
	 * @return
	 */
	public String getMeasurementNameByCode(String code, String flag) {
		if (StringUtils.isEmpty(code)) {
			return "";
		}
		String MeasurementName;
		MeasurementName = redisUtils.codeToName("Z_CCM_SIMPLELIST_4", code, flag);
		if (null == MeasurementName) {
			Session session = SessionFactoryUtils.getSession(
					chgHibernateTemplate.getSessionFactory(), true);
			String sql = "select t.cname from Z_CCM_SIMPLELIST_4 t where 1=1 and t.indexid='" + code + "' ";
			if (StringUtils.isNotEmpty(flag)) {
				sql += " and t.indexid='" + flag + "' ";
			}
			Query query = session.createSQLQuery(sql);
			List list = query.list();
			session.close();
			MeasurementName = (String) list.get(0);
		}
		return MeasurementName;
	}

	/**
	 * 查询审单查看布控信息
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<InsOriaudiExcePbinfoEntity> findInsOriaudiExcePbinfo(String declNo, String goodsNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsOriaudiExcePbinfoEntity t where 1=1");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(goodsNo)){
			sql.append(" AND (t.goodsNo=? or t.goodsNo is null)");
			param.add(goodsNo);
		}
		List list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	 * 查找货物监控项目
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<InsGoodsMonItemEntity> findGoodsItemsByGoodsNo(String declNo, String goodsNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsGoodsMonItemEntity t where 1=1");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo=?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(goodsNo)){
			sql.append(" AND t.goodsNo=?");
			param.add(goodsNo);
		}
		List<InsGoodsMonItemEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	 * 获得监管货物评定标准对象集合
	 * @param monItemId
	 * @return
	 */
	public List<InsMonItemEvalStdEntity> findInsMonItemEvalStdEntityById(String monItemId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsMonItemEvalStdEntity t where 1=1");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(monItemId)){
			sql.append(" AND t.monItemId=?");
			param.add(monItemId);
		}
		List<InsMonItemEvalStdEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	 * 获得表单名称
	 * @param monItemId
	 * @return
	 */
	public String getRulCtlitemFormName(String monItemId) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select f.FORM_NAME from INS_GOODS_MON_ITEM g,RUL_CTLITEM_FORM f,RUL_CTLITEM r where r.CTLITEM_FORM_CODE=f.CTLITEM_FORM_CODE and r.CTLITEM_ID=g.SOURCE_ITEM_ID ";
		if(StringUtils.isNotEmpty(monItemId)){
			sql+=" and g.MON_ITEM_ID=?";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, monItemId);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}

	/**
	 * 获取法规标题串
	 * @param lawStdNo
	 * @return
	 */
	public String getRule2(String docNo) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.RULE_TOPIC from Z_BBD_RULE_STD t where 1=1 ";
		if(StringUtils.isNotEmpty(docNo)){
			sql+=" and t.DOC_NO=?";
		}
		Query query=session.createSQLQuery(sql).setParameter(0, docNo);
		List list=query.list();
		session.close();
		return Utils.notEmpty(list)?(String)list.get(0):"";
	}

	/**
	 * 根据报检号获取报检基本信息
	 * @param declNo
	 * @return
	 */
	public DclIoDeclEx getInsDeclInfo(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM DclIoDeclEx t where  1=1 ");
		List<String> param = new ArrayList<String>();

		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<DclIoDeclEx> list = dao.getQueryList(sql.toString(), param.toArray());
		return Utils.notEmpty(list) ? list.get(0) : null;
	}

	/**
	 * 根据生产单位注册号,出入境标记,获得企业分类等级
	 * @param declRegNo 生产单位注册号
	 * @param expImpFlag
	 * @return
	 */
	public String getEntCategory(String declRegNo, String expImpFlag) {
		String entCategory = "";
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SupEntClassify t where  1=1 ");
		List<String> param = new ArrayList<String>();

		if (StringUtils.isNotEmpty(declRegNo)) {
			sql.append(" AND t.declRegNo =?");
			param.add(declRegNo);
		}
		List<SupEntClassify> list = dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(list)){
		if(StringUtils.equals(expImpFlag, CommContext.OUT_FLAG)){
			entCategory=list.get(0).getExpEntCategory();
		}else if(StringUtils.equals(expImpFlag, CommContext.IN_FLAG)){}
			entCategory=list.get(0).getImpEntCategory();
		}
		return entCategory;
	}

	
	/**
	 * 根据生产单位注册号,出入境标记,ciq编码获得产品风险等级
	 * @param declRegNo  生产单位注册号
	 * @param expImpFlag
	 * @param ciqCode
	 * @return
	 */
	public String getRiskGradeCode(String declRegNo, String expImpFlag, String ciqCode) {
		String riskGradeCode = "";
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM SupEntAttribute t where  1=1 ");
		List<String> param = new ArrayList<String>();

		if (StringUtils.isNotEmpty(declRegNo)) {
			sql.append(" AND t.declRegNo =?");
			param.add(declRegNo);
		}
		
		if (StringUtils.isNotEmpty(ciqCode)) {
			sql.append(" AND t.ciqCode =?");
			param.add(ciqCode);
		}
		
		if (StringUtils.isNotEmpty(expImpFlag)) {
			sql.append(" AND t.expImpFlag =?");
			param.add(expImpFlag);
		}
		
		List<SupEntAttribute> list = dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(list)){
			riskGradeCode=list.get(0).getRiskGradeCode();
		}
		return riskGradeCode;
	}

	/**
	 * 法定抽批查询
	 * @param countryCode
	 * @param userOrgCode
	 * @param ciqCode
	 * @param expImpFlag
	 * @param entCategory
	 * @param riskGradeCode
	 * @return
	 */
	public List<RulBatchruleEntity> queryRuleList2(String countryCode, String userOrgCode, String ciqCode,
			String expImpFlag, String entCategory, String riskGradeCode) {
		List<String> countrylist=getCountryTreeUpList("WorldDistrict",countryCode);//向上追溯国家地区
		List<String> orglist=getOrgTreeUpList("SysOrganize", userOrgCode);//向上追溯机构
		List<String> ciqlist=getCiqTreeUpList("ProductCiqCode", ciqCode);//向上追溯ciq
		
		String neworgCode = "", newcountry = "", newciq = "";
		if (Utils.notEmpty(countrylist)) {
			for (int i = 0, size = countrylist.size(); i < size; i++) {
				if (i == size - 1) {
					newcountry += "'" + countrylist.get(i) + "'";
				} else {
					newcountry += "'" + countrylist.get(i) + "'" + ",";
				}
			}
		}
		if (Utils.notEmpty(orglist)) {
			for (int i = 0, size = orglist.size(); i < size; i++) {
				if (i == size - 1) {
					neworgCode += "'" + orglist.get(i) + "'";
				} else {
					neworgCode += "'" + orglist.get(i) + "'" + ",";
				}
			}
		}

		if (Utils.notEmpty(ciqlist)) {
			for (int i = 0, size = ciqlist.size(); i < size; i++) {
				if (i == size - 1) {
					newciq += "'" + ciqlist.get(i) + "'";
				} else {
					newciq += "'" + ciqlist.get(i) + "'" + ",";
				}
			}
		}
		
		List<RulBatchruleEntity> licalList =getKooRulBatchruleLocalEntity(countrylist, orglist, ciqlist,
				entCategory, riskGradeCode, expImpFlag);
		
//		List<RulBatchruleEntity> licalList2 =getKooRulBatchruleLocalEntity2(newcountry, neworgCode, newciq,
//				entCategory, riskGradeCode, expImpFlag);
		return licalList;
	}


	/**
	* <p>描述:向上追溯查询ciq代码</p>
	* @param string
	* @param ciqCode
	* @return
	* @author 吴有根
	*/
	private List<String> getCiqTreeUpList(String string, String ciqCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql=" SELECT T2.Ciq_Code"
				  	+" FROM z_bbd_ciq_code T2"
				  	+" START WITH T2.classify_code ="
				  	+" (SELECT classify_code"
				  	+" FROM z_bbd_ciq_code"
				  	+" WHERE ciq_code = ?)"
				  	+" CONNECT BY PRIOR senior_classify_code = classify_code";
        Query query=session.createSQLQuery(sql).setParameter(0,ciqCode);
        List<String> list=query.list();
        session.close();
        if(Utils.notEmpty(list)){
        	List<String> list2=getList(list);
        	return list2;
        }else {
			return null;
		}
	}

	/**
	* <p>描述:向上追溯查询机构代码</p>
	* @param string
	* @param userOrgCode
	* @return
	* @author 吴有根
	*/
	private List<String> getOrgTreeUpList(String string, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql=" SELECT T2.Org_Code"
        			+" FROM SYS_ORGANIZE T2"
        			+" START WITH T2.CATEGORY_CODE ="
        			+" (SELECT CATEGORY_CODE"
        			+" FROM SYS_ORGANIZE"
        			+" WHERE org_code = ?)"
        			+" CONNECT BY PRIOR SENIOR_CATEGORY_CODE = CATEGORY_CODE ";
        Query query=session.createSQLQuery(sql).setParameter(0,userOrgCode);
        List<String> list=query.list();
        session.close();
        if(Utils.notEmpty(list)){
        	List<String> list2=getList(list);
        	return list2;
        }else {
			return null;
		}
	}

	/**
	* <p>描述:向上追溯查询国家代码</p>
	* @param string
	* @param countryCode
	* @return
	* @author 吴有根
	*/
	private List<String> getCountryTreeUpList(String string, String countryCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql ="SELECT T2.Itemcode"
        			+" FROM Z_CCM_WORLDDISTRICT T2"
        			+" START WITH T2.itemcode ="
        			+" (SELECT itemcode"
        			+" FROM Z_CCM_WORLDDISTRICT"
        			+" WHERE itemcode = ?)"
        			+" CONNECT BY PRIOR parentcode = itemcode";
        Query query=session.createSQLQuery(sql).setParameter(0,countryCode);
        List<String> list=query.list();
        session.close();
        if(Utils.notEmpty(list)){
        	List<String> list2=getList(list);
        	return list2;
        }else {
			return null;
		}       

	}

	/**去重
	* <p>描述:</p>
	* @param list
	* @return
	* @author 吴有根
	*/
	private List<String> getList(List<String> list) {
		List<String> modelCode = new ArrayList<String>();
		Set<String> set = new HashSet<String>();
		for (String s : list) {
			if (set.add(s)) {
				modelCode.add(s);
			}
		}
		return modelCode;
	}

	/**
	 * 查询法定抽批规则
	 * @param countryCode
	 * @param orgCode
	 * @param ciqCode
	 * @param entLevelCode
	 * @param prodRiskLevel
	 * @param expImpFlag
	 * @return
	 */
    @SuppressWarnings("unchecked")
	public List<RulBatchruleEntity> getKooRulBatchruleLocalEntity(List<String> countryCode,
            List<String> orgCode,
            List<String> ciqCode,
            String entLevelCode,
            String prodRiskLevel,
            String expImpFlag) {
    	
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = " SELECT  A.BATCHRULE_ID," +   
                " A.BATCHRULE_NAME , "+
                " A.SAMPLE_SCH , "+
                "A.BATCHRULE_LSTATE  "
                +",A.* "
                + " FROM RUL_BATCHRULE A ,RUL_BATCHRULE_COUNTRY B,RUL_BATCHRULE_ORG C,RUL_BATCHRULE_PRODCIQ D "
                + " WHERE A.BATCHRULE_ID = B.BATCHRULE_ID  "
                + " AND A.BATCHRULE_ID = C.BATCHRULE_ID  "
                + " AND A.BATCHRULE_ID = D.BATCHRULE_ID "
                + " AND B.COUNTRY_CODE IN (:countryCode) "
                + " AND C.ORG_CODE IN (:orgCode) "
                + " AND D.CIQ_CODE IN (:ciqCode) "
                + " AND ( A.EXP_IMP_FLAG = :expImpFlag OR A.EXP_IMP_FLAG = :expImpFlag2)"
                + " AND A.IS_ENFOC= :isEnfoc"
                + " AND A.BATCHRULE_LSTATE = :batchruleLstate "
                + " AND A.BEGIN_DATE <= :beginDate AND (A.END_DATE IS NULL OR A.END_DATE >= :endDate ) "
                + " AND ((A.ENT_LEVEL_CODE IS NOT NULL AND INSTR(A.ENT_LEVEL_CODE, :entLevelCode) > 0 ) OR A.ENT_LEVEL_CODE IS NULL) "//这里需要改: a.ENT_LEVEL_CODE 有可能维护的是: (1,2,3,4)  传进来的就是一个1,所以不能再用 a.ENT_LEVEL_CODE = 
                + " AND ((A.PROD_RISK_LEVEL IS NOT NULL AND A.PROD_RISK_LEVEL = :prodRiskLevel ) OR A.PROD_RISK_LEVEL IS NULL) ";

		Query query=session.createSQLQuery(sql).addEntity(RulBatchruleEntity.class).setParameterList("countryCode", countryCode).setParameterList("orgCode", orgCode)
												.setParameterList("ciqCode", ciqCode).setParameter("expImpFlag", expImpFlag).setParameter("expImpFlag2", "3").setParameter("isEnfoc", "1")
												.setParameter("batchruleLstate", "2").setParameter("beginDate", new Date())
												.setParameter("endDate", new Date()).setParameter("entLevelCode", entLevelCode).setParameter("prodRiskLevel", prodRiskLevel);
		List<RulBatchruleEntity> list=query.list();
		session.close();
    	return list;
    }

	
	/**
	 * 判断人员与机构是否匹配
	 * @param orgCode
	 * @param userCode
	 * @return
	 */
	public boolean isUserByOrg(String orgCode, String userCode) {
		StringBuilder sql=new StringBuilder();
		sql.append("select s from SysUser s where 1=1 ") ;
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND s.orgCode=?");
			param.add(orgCode);
		}
		if(StringUtils.isNotEmpty(userCode)){
			sql.append(" AND s.userCode=?");
			param.add(userCode);
		}
		sql.append(" AND s.onDuty='1' ");
		List list=dao.getQueryList(sql.toString(), param.toArray());
        if (CollectionUtils.isEmpty(list)) {
            return false;
        } else {
            return true;
        }
    }
	
	
	/**
     * 判断是否有锁
     *
     * @param declNo 报检单号
     * @param status 流程状态
     * @return
     */
    public List getLocked(String declNo, String status) {
    	List<String> param=new ArrayList<String>();
        if (StringUtils.isEmpty(status)) {
            String sql = "select t from SysBusinessLockEntity t where t.keyId ='"+declNo+"'";
            List list=dao.getQueryList(sql.toString());
            return list;
        } else {
            String sql = "select t from SysBusinessLockEntity t where t.keyId = '"+declNo+"' and t.status='"+status+"'";
            param.add(declNo);
            param.add(status);
            List list=dao.getQueryList(sql.toString(), param.toArray());
            return list;
        }
    }
    
    /**
     * 非报检单号解锁(业务主键)
     *
     * @param uuid
     */
    public void comUnLock(String uuid) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
        String sql = "delete from SYS_BUSINESS_LOCK  where KEY_ID='"+uuid+"'";
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    
	
    /**
     * 分单改派单按钮--更新报检单管理表
     * @param sql
     */
    public void updateInsDeclMag(String deptCode,String time,String userCode,String recCode,String declMagId){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
    	String sql = "UPDATE INS_DECL_MAG T SET T.AS_INP_TK_ORG_CODE = '"
				+ deptCode
				+ "',T.INSP_ASSIGN_TM = TO_DATE('"
				+ time
				+ "','yyyy-mm-dd hh24:mi:ss'), "
				+ "T.INSP_ASGN_PRSN_C = '"
				+ userCode
				+ "', T.OPER_TIME = TO_DATE('"
				+ time
				+ "','yyyy-mm-dd hh24:mi:ss'), T.RECEIVER_DOC_CODE = '"
				+ recCode
				+ "' , T.SUB_TYPE = '"
				+ CommContext.SUBMENU_TYPE_YET_SUB
				+ "'"
				+ " WHERE T.DECL_MAG_ID = '" + declMagId + "'";

		Query query=session.createSQLQuery(sql);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
    }
	
    /**
     * 非报检单号加锁(业务主键)
     *
     * @param uuid
     * @param service
     */
    public void comLock(String uuid,String userCode,String orgCode) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	org.hibernate.Transaction tran=session.beginTransaction();
    	SysBusinessLockEntity entity = new SysBusinessLockEntity();
        String id = UUIDKeyGeneratorUils.newInstance().generateKey();
        entity.setOid(id);
        entity.setKeyId(uuid);
        entity.setUserId(userCode);
        entity.setOrgCode(orgCode);
        entity.setInsertTime(new Date());
        session.save(entity);
        tran.commit();
        session.close();
    }
    
    /**
     * 分单改派单---更新施检总结果表
     */
    public void updateInsResultSum(String recCode,String orgCode,String declNo){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
    	String sql=" UPDATE INS_RESULT_SUM S SET S.OPERATOR_CODE = '" + recCode + "',S.EXE_INSP_ORG_CODE = '" + orgCode + "' WHERE S.DECL_NO = '" + declNo + "'";
		Query query=session.createSQLQuery(sql);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
    }
    
    /**
     * 更新流程日志表
    * <p>描述:</p>
    * @param declNo
    * @param remark
    * @author 李云龙
     */
    public void updateRecerByProcessLog(String declNo, String remark) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String processId = null;
        String sql = "SELECT T.PROCESS_LOG_ID FROM SYS_PROCESS_LOG T WHERE T.DECL_NO = '"+declNo+"'"
                + " AND T.PROCESS_NODE ='"+CommContext.INS+"' ORDER BY T.OPER_DATE DESC";
        Query selectQuery = session.createSQLQuery(sql);
        List list = selectQuery.list();
        if (!CollectionUtils.isEmpty(list)) {
            processId = (String) list.get(0);
        }        
        if (processId != null) {
            sql = "UPDATE SYS_PROCESS_LOG T SET T.REMARK = '"+remark+"',T.TREA_OPER_CODE = '"+remark+"',T.TREA_OPER_NAME"
                    + " = '"+getUserNameUserCode(remark)+"' WHERE T.PROCESS_LOG_ID = '"+processId+"'";
            session.beginTransaction();
            Query query = session.createSQLQuery(sql);
            query.executeUpdate();
            session.getTransaction().commit();
        }
        session.close();
    }
    
    /**
	 * 根据人员代码查询名称
	 * @param orgCode
	 * @return
	 */
	public String getUserNameUserCode(String code){
		if(StringUtils.isEmpty(code)) {
			return "";
		}
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql="select t.USER_NAME from SYS_USER_A t where 1=1 and  t.USER_CODE='"+code+"'";
		Query query=session.createSQLQuery(sql);
		List list=query.list();
		session.close();
		if (!CollectionUtils.isEmpty(list)) {
            return (String) list.get(0);
        }else{
        	return code;
		}
	}
	 /**
	  * 获取报检单管理表信息
	 * <p>描述:</p>
	 * @param declNo
	 * @return
	 * @author 李云龙
	  */
	 public InsDeclMagEntity getMainDeclMag(String declNo) {
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from InsDeclMagEntity t where t.declNo = :declNo and "
	                + "t.flowPathStatus = '" + InsContext.FLOW_PATH_STATUS_MAIN + "'";
	        Query query = session.createQuery(sql);
	        query.setParameter("declNo", declNo);
	        List<InsDeclMagEntity> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)) {
	            return list.get(0);
	        }
	        return null;
	    }
	 
	 /**
	  * 获取报检单管理表信息
	 * <p>描述:</p>
	 * @param declNo
	 * @return
	 * @author 
	  */
	 public InsDeclMagEntity judgeLoginUser(String userCode,String companyCode,String declNo,String flowPathStatus) {
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from InsDeclMagEntity t where 1=1";
	        if(StringUtils.isNotEmpty(declNo)){
	        	sql+=" and t.declNo ='"+declNo+"' ";
	        }
	        if(StringUtils.isNotEmpty(userCode)){
	        	sql+=" and t.receiverDocCode='"+userCode+"' ";
	        }
	        if(StringUtils.isNotEmpty(companyCode)){
	        	sql+=" and t.exeInspOrgCode='"+companyCode+"' ";
	        }
	        if(StringUtils.isNotEmpty(flowPathStatus)){
	        	sql+=" and t.flowPathStatus='"+flowPathStatus+"' ";
	        }
	        Query query = session.createQuery(sql);
	        List<InsDeclMagEntity> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)) {
	            return list.get(0);
	        }
	        return null;
	    }
	 
	 /**
	  * 
	 * <p>描述:鉴定处理主表</p>
	 * @param declNo
	 * @return
	 * @author 魏波
	  */
	 public boolean getInsAuthenticateProcEntity(String declNo){
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from InsAuthenticateProcEntity t where t.declNo = :declNo  ";
	        Query query = session.createQuery(sql);
	        query.setParameter("declNo", declNo);
	        List<InsAuthenticateProcEntity> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)&& StringUtils.equals("1", list.get(0).getIsAuthFlag())) {
	            return true;
	        }
	        return false;
	        
	 }
	 
	 /**
	  * 
	 * <p>描述:查询隔离检表</p>
	 * @param declNo
	 * @return
	 * @author 魏波
	  */
	 public InsIsolationQuarEntity getInsIsolationQuarEntityByNo(String declNo){
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from InsIsolationQuarEntity t where t.declNo = :declNo  ";
	        Query query = session.createQuery(sql);
	        query.setParameter("declNo", declNo);
	        List<InsIsolationQuarEntity> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)) {
	            return list.get(0);
	        }
	        return null;
	 }
	 
	 public List<InsResultSumEntity> getInsResultSumScEntity(String declNo, String userCode) {
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from InsResultSumEntity t where t.declNo = :declNo and t.checker like '%"+userCode+"%' ";
	        Query query = session.createQuery(sql);
	        query.setParameter("declNo", declNo);
//	        query.setParameter("scOperatorCode", userCode);
	        List<InsResultSumEntity> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)) {
	        	return list;
	        }
	        return null;
	    }
	 
	 
	 public void updateInsDeclMagEntity1(String userCode,String companyCode,String declNo,String flowPathStatus){
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	    	session.beginTransaction();
	    	String sql=" UPDATE ins_decl_mag S SET S.flow_path_status = '" + flowPathStatus + "',S.AUDIT_PRIV = '" + 0 + "',S.SUB_PRIV='"+0+"' WHERE S.DECL_NO = '" + declNo + "' and S.exe_insp_org_code='"+companyCode+"' and S.receiver_doc_code='"+userCode+"'";
			Query query=session.createSQLQuery(sql);
			query.executeUpdate();
			session.getTransaction().commit();
			session.close();
	 }
	 /**
	  * 获取用户信息
	 * <p>描述:</p>
	 * @param userCode
	 * @return
	 * @author 李云龙
	  */
	 public SysUser getSysUser(String userCode) {
		 Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        String sql = "select t from SysUser t where t.userCode ='"+userCode+"'";
	        Query query = session.createQuery(sql);
	        List<SysUser> list = query.list();
	        session.close();
	        if (!CollectionUtils.isEmpty(list)) {
	            return list.get(0);
	        }
	        return null;
	    }
	 
	 
	   /**
	     * 很据报检号，获得出入境报检单基本信息
	     *
	     * @param declNo 报检号
	     * @return 出入境报检单基本信息
	     */
	    public DclIoDeclEntity getDeclDetails(String declNo) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        if (StringUtils.isNotEmpty(declNo)) {
	            String sql = "SELECT t FROM DclIoDeclEntity t WHERE t.declNo='"+declNo+"'";
	            Query query = session.createQuery(sql);
	            List<DclIoDeclEntity> list=query.list();
	            session.close();
	            if (!CollectionUtils.isEmpty(list)) {
	                return list.get(0);
	            }
	        }
	        return null;
	    }
	    
	    /**
	     * 
	    * <p>描述:根据报检号与施检部门获得出入境报检单基本信息</p>
	    * @param declNo
	    * @return
	    * @author 李云龙
	     */
	    public DclIoDeclEntity getDclIoDeclEntity(String declNo) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        if (StringUtils.isNotEmpty(declNo)) {
	            String sql = "SELECT t FROM DclIoDeclEntity t WHERE t.declNo='"+declNo+"'";
	            Query query = session.createQuery(sql);
	            List<DclIoDeclEntity> list=query.list();
	            session.close();
	            if (!CollectionUtils.isEmpty(list)) {
	                return list.get(0);
	            }
	        }
	        return null;
	    }
	    
	    
	    
	    /**
	     * 根据报检单号，查询管理表辅施检机构，并获取其直属局信息
	     *
	     * @param declNo
	     * @return
	     */
	    public List<String> getAuxOrgs(String declNo) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        if (StringUtils.isNotEmpty(declNo)) {
	            List<String> result = new ArrayList<String>();
	            String sql = "SELECT S.EXE_INSP_ORG_CODE FROM INS_DECL_MAG S WHERE S.DECL_NO='"+declNo+"' AND (S.FLOW_PATH_STATUS='"+InsContext.FLOW_PATH_STATUS_AUXILIARY+"' OR S.FLOW_PATH_STATUS='"+InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE+"')";
	            Query query = session.createSQLQuery(sql);
	            List list = query.list();
	            session.close();
	            if (!CollectionUtils.isEmpty(list)) {
	                for (Object obj : list) {
	                	Map<Integer, String> orgMap = companyCodeUtils.getOrgCode(String.valueOf(obj));
	                    if (null != orgMap && !orgMap.isEmpty()) {
	                        if (orgMap.get(companyCodeUtils.ORG_LEVEL_1) != null) {
	                            result.add(orgMap.get(companyCodeUtils.ORG_LEVEL_1).toString());
	                        } else {
	                            result.add(String.valueOf(obj));
	                        }
	                    }
	                }
	                return result;
	            }
	        }
	        return null;
	    }
	    
	    /**
		 * 根据机构代码填充机构map
		 * 
		 * @param orgCode
		 *            机构代码
		 * @param orgLeveal
		 */
		public void queryOrgMapByOrgCode(String orgCode,
				Map<Integer, String> orgLeveal) {
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
			String sql = "SELECT ORG_CODE "
					+ "    FROM SYS_ORGANIZE  WHERE  STATE = '1' "
					+ "   START WITH CATEGORY_CODE = "
					+ "              (SELECT CATEGORY_CODE "
					+ "                 FROM SYS_ORGANIZE "
					+ "                WHERE ORG_CODE =  '"+orgCode+"' ) "
					+ "  CONNECT BY PRIOR SENIOR_CATEGORY_CODE = CATEGORY_CODE";
			Query query = session.createSQLQuery(sql);
			List sysOrgList = query.list();		
			session.close();
			int level;
			if (!CollectionUtils.isEmpty(sysOrgList)) {
				for (Object org : sysOrgList) {
					List<SysOrganizeEntity> list = dao
					.getQueryList("SELECT s FROM SysOrganizeEntity s WHERE s.orgCode = ?", org.toString());
					SysOrganizeEntity sysOrg=list.get(0);
					level = companyCodeUtils.getOrgDeptLevelByCategoryCode(sysOrg
							.getCategoryCode(), sysOrg.getSeniorCategoryCode());
					if (level != companyCodeUtils.ORG_LEVEL_ERR) {
						orgLeveal.put(level, sysOrg.getOrgCode());
					}
				}
			}
		}  
		
		/**
	     * 获取通用数据下发开关
	     *
	     * @return
	     */
		public List<SysSwitchOrg> getSwitchValue(List<String> orgs, String switchId) {
			Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        if (CollectionUtils.isEmpty(orgs)) {
	            return null;
	        }
	        String sql = "SELECT A.SYS_SWITCH_ORG_ID,A.ORG_CODE,A.SWITCH_VALUE FROM SYS_SWITCH_ORG A WHERE A.SYS_SWITCH_ID = '"+switchId+"' AND A.ORG_CODE IN ( ";
	        StringBuilder strBuild = new StringBuilder(sql);
	        for (String org : orgs) {
	            strBuild.append("'").append(org).append("',");
	        }
	        strBuild.deleteCharAt(strBuild.length() - 1);
	        strBuild.append(")");
	        Query query = session.createSQLQuery(strBuild.toString());
	        List<SysSwitchOrg> sysSwitchs = query.list();
	        session.close();
	        return sysSwitchs;
	    }
		
		/**
	     * 保存实体
	     *
	     * @param obj
	     */
	    public void saveObject(Object obj) {
	    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	    	session.beginTransaction();
	    	session.persist(obj);
	    	session.getTransaction().commit();
	    	session.close();
	    }
		
	    
	    /**
	     * 记录辅施检流程日志
	     *
	     */
	    public void writeAuxLog(String exeInspOrgCode, String excInspDeptCode, String inspContCodes, String insDclMagId, String declNo, String processLink, String processstatus, String remark, UserInfo user) {
	        
	    	// 增加日志信息
	    	AuxInsProcessLogEntity logEntity = new AuxInsProcessLogEntity();
	        // 设定日志ID
	        logEntity.setAuxInsProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
	        // 施检管理记录id
	        logEntity.setDeclMagId(insDclMagId);
	        // 设定报检号
	        logEntity.setDeclNo(declNo);
	        // 设定流程环节
	        logEntity.setProcessNode(processLink);
	        // 设定流程状态
	        logEntity.setProcessStatus(processstatus);
	        // 设定环节描述
	        //logEntity.setNodeMemo(nodeMemo);
	        // 设定操作人代码
	        String userName;
	        String userCode;
	        if (user == null || StringUtils.isEmpty(user.getUserCode())) {
	            userCode = "auto";
	        } else {
	            userCode = user.getUserCode();
	        }
	        if (user == null || StringUtils.isEmpty(user.getUserName())) {
	            userName = "系统";
	        } else {
	            userName = user.getUserName();
	        }
	        logEntity.setOperCode(userCode);
	        // 设定操作人名称
	        logEntity.setOperName(userName);
	        // 设定操作时间
	        logEntity.setOperDate(new Date());
	        // 设定归档标志
	        logEntity.setFalgArchive(CommContext.ARCHIVE_0);
	        // 设定备注
	        logEntity.setRemark(remark);
	        // 设置流程操作机构
	        logEntity.setTreaOrgCode(user.getCompanyCode());
	        //设置施检机构
	        logEntity.setExeInspOrgCode(exeInspOrgCode);
	        //设置施检部门
	        logEntity.setExcInspDeptCode(excInspDeptCode);
	        //设置施检内容
	        logEntity.setInspContCodes(inspContCodes);
	        // 将流程日志入库
	        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
	        session.beginTransaction();
	        session.merge(logEntity);
	        session.getTransaction().commit();
	        session.close();
	    }
	    
	/**
	 * 根据报检号查询报检单管理表
	 * 
	 * @param declNo
	 * @return
	 */
	public List<InsDeclMagEntity> getMagByDeclNo(String declNo) {
		String ql = "select t from InsDeclMagEntity t where t.declNo=:declNo";
		List<InsDeclMagEntity> list = dao.getQueryList(
				"SELECT s FROM InsDeclMagEntity s WHERE s.orgCode = ?", declNo);
		return list;
	} 
	
	public  void updateEntity(InsCheckItemEntity entity){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "update INS_CHECK_ITEM t set t.WHETHER_QUALFY=? ," +
				" t.BATCH_DESC=? ," +
				" t.SAMPLE_SCH=?  where t.DECL_NO=? and t.GOODS_NO=? and t.CHECK_ITEM_CODE =? ";
		Query query=session.createSQLQuery(sql).setParameter(0, entity.getWhetherQualfy()).setParameter(1, entity.getBatchDesc())
					.setParameter(2, entity.getSampleSch()).setParameter(3, entity.getDeclNo()).setParameter(4, entity.getGoodsNo()).setParameter(5, entity.getCheckItemCode());
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	
	public  void updateEntity(InsResultGoodsEntity entity){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "update INS_RESULT_GOODS t set t.GOODS_TOTAL_VAL=? ," +
					 "  t.PACK_QTY=? ," +
					 "  t.REAL_WEIGHT=? ," +
					 "  t.ACTUAL_QTY=? ," +
					 "  t.ACT_SMPL_NUM=? ," +
					 "  t.QUAR_RES_SPOT=? ," +
					 "  t.INSP_RES_SPOT=? ," +
					 "  t.INSP_PATTERN_CODE=? ," +
					 "  t.INSP_RES_EVAL=? ," +
					 "  t.QUAR_RES_EVAL=? " +
					 " where t.DECL_NO=? and t.GOODS_NO=? ";
		Query query=session.createSQLQuery(sql).setParameter(0,entity.getGoodsTotalVal()).setParameter(1, entity.getPackQty())
				.setParameter(2, entity.getRealWeight()).setParameter(3, entity.getActualQty()).setParameter(4, entity.getActSmplNum()).setParameter(5, entity.getQuarResSpot())
				.setParameter(6, entity.getInspResSpot()).setParameter(7, entity.getInspPatternCode()).setParameter(8, entity.getInspResEval()).setParameter(9, entity.getQuarResEval()).setParameter(10, entity.getDeclNo())
				.setParameter(11, entity.getGoodsNo());
		int i=query.executeUpdate();
		session.getTransaction().commit();
		session.close();
    }
}
	    

	    

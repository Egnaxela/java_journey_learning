/**  
 * FileName:    DeclNoCountDao.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年9月12日 下午7:26:52  
 *  
 */  

package com.rongji.eciq.mobile.dao.sys;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclProcessCountEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 数据统计持久层  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年9月12日 下午7:26:52  
 *  
 * Modification History:  
 * Date           Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-09-12      吴有根                      2.0         2.0 Version  
 * 2017-09-14      夏晨琳                      2.0         统计各直属局每年，每月，每周，每天的报检单数量  
 */

@Repository
public class DeclNoCountDao {

	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;

	/**
	* <p>描述:判断是否存在这个年份的单子</p>
	* @param orgCode
	* @param year
	* @return
	* @author 夏晨琳
	*/
	public DclProcessCountEntity dclProcessIsExit(String deptCode, int year) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("FROM DclProcessCountEntity t where 1=1");
		if(StringUtils.isNotEmpty(deptCode)){
			sql.append(" AND t.deptCode=? ");
			param.add(deptCode);
		}
		if(StringUtils.isNotEmpty(year+"")){
			sql.append(" AND t.year=? ");
			param.add(year+"");
		}
		List<DclProcessCountEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list.size()>0?list.get(0):null;
	}

	/**
	* <p>描述:保存数据</p>
	* @param dcl
	* @author 夏晨琳
	*/
	public void saveDclProcess(DclProcessCountEntity dcl) {
		dao.saveObject(dcl);
	}

	/**
	* <p>描述:更新</p>
	* @param dcl
	* @param monthName
	* @param weekName
	* @param hourName
	* @author 夏晨琳
	 * @param isSameDay 
	 * @param isSameWeek 
	*/
	public void updateDclProcess(DclProcessCountEntity dcl, String monthName, String weekName, String hourName, boolean isSameWeek, boolean isSameDay) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer(" UPDATE DCL_PROCESS_COUNT ");
		sb.append(" SET "+monthName +"= nvl("+monthName+",0)+1 " );
		if (isSameWeek) {
			sb.append(" , "+weekName +"=nvl("+weekName+",0)+1 " );
		}else{
			//sb.append(" ,WEEK_MON = 0, WEEK_TUES=0, WEEK_WED=0, WEEK_THUR=0, WEEK_FRI=0, WEEK_SAT=0, WEEK_SUN=0 ");
			updateWeek(dcl);
			sb.append(" , "+weekName +"=1 " );
		}
		if (isSameDay) {
			sb.append(" , "+hourName +"=nvl("+hourName+",0)+1 " );
		}else{
			/*sb.append(" ,HOUR_ONE=0, HOUR_TWO=0, HOUR_THREE=0, HOUR_FOUR=0, HOUR_FIVE=0, HOUR_SIX=0, HOUR_SEVEN=0, HOUR_EIGHT=0, HOUR_NINE=0, HOUR_TEN=0, HOUR_ELEVEN=0, HOUR_TWELVE=0,"+
			" HOUR_THIRTEEN=0, HOUR_FORTEEN=0, HOUR_FIFTEEN=0, HOUR_SIXTEEN=0, HOUR_SEVENTEEN=0, HOUR_EIGHTEEN=0, HOUR_NINETEEN=0, HOUR_TWENTY=0, HOUR_TWENTY_ONE=0, HOUR_TWENTY_TWO=0, HOUR_TWENTY_THREE=0, HOUR_TWENTY_FOUR=0 ");
			*/
			updateDay(dcl);
			sb.append(" , "+hourName +"=1 " );
		}
		sb.append(" , OPER_DATE = sysdate ");
		sb.append(" where PROCESS_CALENDAR_ID = '"+dcl.getProcessCalendarId()+"'");
		Query query=session.createSQLQuery(sb.toString());
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:重置</p>
	* @param dcl
	* @author 夏晨琳
	*/
	public void updateDay(DclProcessCountEntity dcl) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer(" UPDATE DCL_PROCESS_COUNT ");
		sb.append(" set HOUR_ONE=0, HOUR_TWO=0, HOUR_THREE=0, HOUR_FOUR=0, HOUR_FIVE=0, HOUR_SIX=0, HOUR_SEVEN=0, HOUR_EIGHT=0, HOUR_NINE=0, HOUR_TEN=0, HOUR_ELEVEN=0, HOUR_TWELVE=0,"+
				" HOUR_THIRTEEN=0, HOUR_FORTEEN=0, HOUR_FIFTEEN=0, HOUR_SIXTEEN=0, HOUR_SEVENTEEN=0, HOUR_EIGHTEEN=0, HOUR_NINETEEN=0, HOUR_TWENTY=0, HOUR_TWENTY_ONE=0, HOUR_TWENTY_TWO=0, HOUR_TWENTY_THREE=0, HOUR_TWENTY_FOUR=0 ");
		sb.append(" where PROCESS_CALENDAR_ID = '"+dcl.getProcessCalendarId()+"'");
		Query query=session.createSQLQuery(sb.toString());
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:重置</p>
	* @author 夏晨琳
	 * @param dcl 
	*/
	public void updateWeek(DclProcessCountEntity dcl) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer(" UPDATE DCL_PROCESS_COUNT ");
		sb.append(" set WEEK_MON = 0, WEEK_TUES=0, WEEK_WED=0, WEEK_THUR=0, WEEK_FRI=0, WEEK_SAT=0, WEEK_SUN=0 ");
		sb.append(" where PROCESS_CALENDAR_ID = '"+dcl.getProcessCalendarId()+"'");
		Query query=session.createSQLQuery(sb.toString());
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:获取数据集合</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	*/
	public List<DclProcessCountEntity> getDclProcessList(String orgCode) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("FROM DclProcessCountEntity t where 1=1");
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.orgCode=? ");
			param.add(orgCode);
		}
		List<DclProcessCountEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	* <p>描述:获取各直属局今年的数量</p>
	* @param year
	* @return
	* @author 夏晨琳
	*/
	public List<DclProcessCountEntity> getNowYearCount(String year) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("FROM DclProcessCountEntity t where 1=1");
		if(StringUtils.isNotEmpty(year)){
			sql.append(" AND t.year=? ");
			param.add(year);
		}
		List<DclProcessCountEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}

	/**
	* <p>描述:查询某个直属局指定年份月份的报检单</p>
	* @param orgCode
	* @param month
	* @param year
	* @return
	* @author 夏晨琳
	 * @param page 
	 * @param day 
	 * @param hour 
	 * @param isAll 
	 * @param deptCode 
	*/
	public List<DclProcessStatsEntity> getDeclNoList(String orgCode, String month, String year, Page page, String hour, String day, String deptCode, boolean isAll) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append(" FROM DclProcessStatsEntity t where 1=1 ");
		if(StringUtils.isNotEmpty(year)){
			sql.append(" AND   to_char(t.firstOperDate,'YYYY') = ? ");
			param.add(year);
		}
		if (isAll) {
			if(StringUtils.isNotEmpty(orgCode)){
				sql.append(" AND  t.orgCode  = ? ");
				param.add(orgCode);
			}
		}else{
			if(StringUtils.isNotEmpty(deptCode)){
				sql.append(" AND t.deptCode = ? ");
				param.add(deptCode);
			}
		}
		
		if(StringUtils.isNotEmpty(month)){
			sql.append(" AND  to_char(t.firstOperDate,'MM') = ? ");
			param.add(month);
		}
		if(StringUtils.isNotEmpty(day)){
			sql.append(" AND  to_char(t.firstOperDate,'DD') = ? ");
			param.add(day);
		}
		if(StringUtils.isNotEmpty(hour)){
			int beginhour = Integer.parseInt(hour)-3;
			String beginh = beginhour+"";
			if(beginhour < 10){
				beginh = "0"+beginhour;
			}
			sql.append(" AND  to_char(t.firstOperDate,'HH24') > ? ");
			param.add(beginh);
			sql.append(" AND  to_char(t.firstOperDate,'HH24') <= ? ");
			param.add(hour);
			
		}
		sql.append(" order by t.firstOperDate ");
		List<DclProcessStatsEntity> list=dao.getQueryList(sql.toString(),page, param.toArray());
		return list;
	}

	/**
	* <p>描述:更新数量</p>
	* @param orgCode
	* @param year
	* @param isSameWeek
	* @param weekName
	* @param isSameDay
	* @param hourName
	* @author 夏晨琳
	 * @param monthName 
	*/
	public void updateCountForReDeclNo(String orgCode, int year, String monthName, boolean isSameWeek, String weekName, boolean isSameDay, String hourName) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer(" UPDATE DCL_PROCESS_COUNT ");
		sb.append(" SET "+monthName +"= nvl("+monthName+",1)-1 " );
		if (isSameWeek) {
			sb.append(" , "+weekName +"=nvl("+weekName+",1)-1 " );
		}
		if (isSameDay) {
			sb.append(" , "+hourName +"=nvl("+hourName+",1)-1 " );
		}
		//sb.append(" , OPER_DATE = sysdate ");
		sb.append(" where ( ORG_CODE = " + orgCode );
		sb.append(" and YEAR = " + year +")");
		Query query=session.createSQLQuery(sb.toString());
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	* <p>描述:获取操作时间</p>
	* @param deptCode
	* @param year
	* @author 夏晨琳
	*/
	public List<String[]> getDclOperDateCount(String deptCode, String year) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer(" select to_char(m.first_oper_date,'MM'),count( to_char(m.first_oper_date,'MM'))  from (select t.first_oper_date from DCL_PROCESS_STATS t where to_char(t.first_oper_date,'YYYY')= ? and t.org_code like ? ) m group by  to_char(m.first_oper_date,'MM') ");
		sb.append(" order by to_char(m.first_oper_date,'MM') ");
		Query query=session.createSQLQuery(sb.toString());
		List<String[]> list=query.setParameter(0, year).setParameter(1,deptCode).list();
		session.getTransaction().commit();
		session.close();
		return list;
	}

	/**
	* <p>描述:获取今天全部数量</p>
	* @param deptCode
	* @param year
	* @param day
	* @return
	* @author 夏晨琳
	 * @param day2 
	*/
	public List<String[]> getDclDayCountCount(String deptCode, String year, String month, String day) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer("select to_char(m.first_oper_date,'HH24'),count( to_char(m.first_oper_date,'HH24'))  from (select t.first_oper_date from DCL_PROCESS_STATS t where to_char(t.first_oper_date,'YYYY')=? and to_char(t.first_oper_date,'MM')=? and to_char(t.first_oper_date,'DD')= ? and t.org_code like ?  ) m group by  to_char(m.first_oper_date,'HH24')");
		sb.append(" order by to_char(m.first_oper_date,'HH24')");
		Query query=session.createSQLQuery(sb.toString());
		List<String[]> list=query.setParameter(0, year).setParameter(1,month).setParameter(2, day).setParameter(3,deptCode+"%").list();
		session.getTransaction().commit();
		session.close();
		return list;
	}

	/**
	* <p>描述:获取每周的数量</p>
	* @param deptCode
	* @param year
	* @param firstDayOfWeek
	* @param lastDayOfWeek
	* @return
	* @author 夏晨琳
	 * @param lastDayOfWeek2 
	*/
	public List<String[]> getWeekDateCount(String deptCode, String year, String month, String firstDayOfWeek, String lastDayOfWeek) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		StringBuffer sb = new StringBuffer("select to_char(m.first_oper_date,'DD'),count(to_char(m.first_oper_date,'DD')) from (select t.first_oper_date from DCL_PROCESS_STATS t where to_char(t.first_oper_date,'YYYY')=? and to_char(t.first_oper_date,'MM')=? and t.org_code like ? and to_char(t.first_oper_date,'DD')>= ? AND to_char(t.first_oper_date,'DD')<= ? ) m group by to_char(m.first_oper_date,'DD')");
		Query query=session.createSQLQuery(sb.toString());
		List<String[]> list=query.setParameter(0, year).setParameter(1,month).setParameter(2,deptCode).setParameter(3,firstDayOfWeek).setParameter(4,lastDayOfWeek).list();
		session.getTransaction().commit();
		session.close();
		return list;
	}



	/**
	* <p>描述:</p>
	* @param orgCode
	* @param year
	* @return
	* @author 夏晨琳
	 * @param isAll 
	 * @param deptCode 
	*/
	public List<DclProcessCountEntity> getdclistByDeptCode(String orgCode, int year, String deptCode, boolean isAll) {
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("FROM DclProcessCountEntity t where 1=1 ");
		if(isAll){
			if(StringUtils.isNotEmpty(orgCode)){
				sql.append(" AND t.orgCode = ? ");
				param.add(orgCode);
			}
		}else{
			if(StringUtils.isNotEmpty(deptCode)){
				sql.append(" AND t.deptCode = ? ");
				param.add(deptCode);
			}
		}
		if(StringUtils.isNotEmpty(year+"")){
			sql.append(" AND t.year=? ");
			param.add(year+"");
		}
		List<DclProcessCountEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}
}

/**  
 * FileName: EnterpriseAccountDao.java    
 * @Description: 企业注册、登录、修改信息dao
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月18日 上午9:42:07  
 *  
 */  

package com.rongji.eciq.mobile.dao.sys;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.EntBaseInfoIdEntity;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 企业注册、登录、修改信息dao  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月18日 上午9:42:07  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月18日      吴有根                      1.0         1.0 Version  
 */

@Repository
public class EnterpriseAccountDao {
	
	PubCommonDAO dao=FrameworkHelper.getChgDAO();
	
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	

	/**
	* <p>描述:根据企业组织机构代码登录验证</p>
	* @param entOrgCode
	* @return
	* @author 吴有根
	*/
	public List<EntBaseInfoEntity> checkexist(String entOrgCode,String... args){
		StringBuilder sql=new StringBuilder();
		List<String> param=new ArrayList<String>();
		sql.append("FROM EntBaseInfoEntity t where 1=1");
		if(StringUtils.isNotEmpty(entOrgCode)){
			sql.append(" AND t.entOrgCode=? ");
			param.add(entOrgCode);
		}else{
			return null;
		}
		
		if(args.length>=1){
			sql.append(" AND t.entOrgPwd=? ");
			param.add(args[0]);
		}
		@SuppressWarnings("unchecked")
		List<EntBaseInfoEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		return list;
	}


	/**
	* <p>描述:企业注册</p>
	* @param entOrgCode
	* @param entPWD
	* @return
	* @author 吴有根
	*/
	public String registerInfo(String entOrgCode, String entPWD) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql = "UPDATE ENT_BASE_INFO T SET ENT_ORG_PWD=?,ENT_ORG_REGISTER=?,OPER_TIME=sysdate  WHERE T.ENT_ORG_CODE = ?";
		int total=session.createSQLQuery(sql).setParameter(0, entPWD).setParameter(1, "1").setParameter(2, entOrgCode).executeUpdate();
		session.getTransaction().commit();
		session.close();
		return total+"";
	}


	/**
	* <p>描述:实体保存</p>
	* @param obj
	* @author 吴有根
	*/
	public void saveObject(Object obj) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.merge(obj);
		session.getTransaction().commit();
		session.flush();
		session.close();
	}


}

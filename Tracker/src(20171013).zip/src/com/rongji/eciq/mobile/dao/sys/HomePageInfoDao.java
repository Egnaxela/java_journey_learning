/**  
 * FileName: HomePageInfoDao.java    
 * @Description: 首页待办信息查询
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月19日 下午4:20:48  
 *  
 */  

package com.rongji.eciq.mobile.dao.sys;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 首页待办信息查询  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月19日 下午4:20:48  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月19日   吴有根                      1.0         1.0 Version 
 * 2017-08-30    才江男                      1.0         查询报检单回写记录信息
 * 2017-09-01    李晨阳                      1.0         获取文件id
 * 2017-09-12    才江男                      1.0         数据量统计
 */

@Repository
public class HomePageInfoDao {
	PubCommonDAO dao = FrameworkHelper.getChgDAO();

	@Autowired
	HibernateTemplate chgHibernateTemplate;
	
	/**
	* <p>描述:所有环节出入境报检单</p>
	* @param userCode
	* @return
	* @author 吴有根
	*/
	@SuppressWarnings("unchecked")
	public List<InsDeclMagEntity> getCount(String userCode,String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.* FROM INS_DECL_MAG T WHERE 1=1");
		if(StringUtils.isNotEmpty(userOrgCode)){
			sql.append(" AND T.EXE_INSP_ORG_CODE=?");
		}
		sql.append("AND T.PROCESS_STATUS IN('1017','1018','1019','1021','1023','1024','1025') AND T.EXP_IMP_FLAG IN('1','2')");
		Query query=session.createSQLQuery(sql.toString()).addEntity(InsDeclMagEntity.class).setParameter(0, userOrgCode);
		List<InsDeclMagEntity> list=query.list();
		session.close();
		return list;
	
	}

	/**
	* <p>描述:出入境待分单</p>
	* @param userCode
	* @param userOrgCode
	* @return
	* @author 吴有根
	*/
	public int getCountPumpGroup(String userCode, String ...userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT COUNT(DECL_MAG_ID) FROM INS_DECL_MAG T WHERE 1=1");
		if(userOrgCode.length!=1){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return 0;
		}
		sql.append("	AND T.SUB_PRIV='1'");//分单权限
		sql.append("	AND T.SUB_TYPE='1'");//分单状态【0为已分单,1为未分单】
		sql.append("	AND T.EXP_IMP_FLAG=?");//出入境标志
		BigDecimal count=(BigDecimal)session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode[0]).setParameter(1, userOrgCode[1]).uniqueResult();
		session.close();
		return count.intValue();
	}
	
	public List<Character> getCountPumpGroup(String userCode, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG FROM INS_DECL_MAG T WHERE 1=1");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		sql.append("	AND T.SUB_PRIV='1'");//分单权限
		sql.append("	AND T.SUB_TYPE='1'");//分单状态【0为已分单,1为未分单】
		@SuppressWarnings("unchecked")
		List<Character> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:出入境待审单</p>
	* @param userCode
	* @param userOrgCode
	* @param string
	* @return
	* @author 吴有根
	*/
	public int getCountWaitInsCheck(String userCode, String ...userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT COUNT(DECL_MAG_ID) FROM INS_DECL_MAG T WHERE 1=1");
		if(userOrgCode.length!=1){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return 0;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return 0;
		}
		sql.append("	AND T.AUDIT_PRIV='1'");//审单权限
		sql.append("	AND T.EXP_IMP_FLAG=?");//出入境标志
		BigDecimal count=(BigDecimal)session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode[0]).setParameter(1, userCode).setParameter(2, userOrgCode[1]).uniqueResult();
		session.close();
		return count.intValue();
	}

	public List<Character> getCountWaitInsCheck(String userCode, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG FROM INS_DECL_MAG T WHERE 1=1");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return null;
		}
		sql.append("	AND T.AUDIT_PRIV='1'");//审单权限
		@SuppressWarnings("unchecked")
		List<Character> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).setParameter(1, userCode).list();
		session.close();
		return list;
	}
	
	/**
	* <p>描述:出入境待查验</p>
	* @param userCode
	* @param userOrgCode
	* @return
	* @author 吴有根
	*/
	public int getCountWaitCheck(String userCode, String ...userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT COUNT(DECL_MAG_ID) FROM INS_DECL_MAG T WHERE 1=1");
		if(userOrgCode.length!=1){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return 0;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return 0;
		}
		sql.append("	AND T.CHECK_PRIV='1'");//查验权限
		sql.append("	AND T.EXP_IMP_FLAG=?");//出入境标志
		BigDecimal count=(BigDecimal)session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode[0]).setParameter(1, userCode).setParameter(2, userOrgCode[1]).uniqueResult();
		session.close();
		return count.intValue();
	}
	
	public List<Character> getCountWaitCheck(String userCode, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG FROM INS_DECL_MAG T WHERE 1=1");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return null;
		}
		sql.append("	AND T.CHECK_PRIV='1'");//查验权限
		@SuppressWarnings("unchecked")
		List<Character> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).setParameter(1, userCode).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:出入境结果登记</p>
	* @param userCode
	* @param userOrgCode
	* @param string
	* @return
	* @author 吴有根
	*/
	public int getCountWaitInsResult(String userCode, String ...userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT COUNT(DECL_MAG_ID) FROM INS_DECL_MAG T WHERE 1=1");
		if(userOrgCode.length!=1){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return 0;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return 0;
		}
		sql.append("	AND T.REGI_PRIV='1'");//结果登记权限
		sql.append("	AND T.EXP_IMP_FLAG=?");//出入境标志
		BigDecimal count=(BigDecimal)session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode[0]).setParameter(1, userCode).setParameter(2, userOrgCode[1]).uniqueResult();
		session.close();
		return count.intValue();
	}
	
	public List<Character> getCountWaitInsResult(String userCode, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG FROM INS_DECL_MAG T WHERE 1=1");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append("	AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		if(StringUtils.isNotEmpty(userCode)){//施检员
			sql.append("	AND T.RECEIVER_DOC_CODE=?");
		}else{
			return null;
		}
		sql.append("	AND T.REGI_PRIV='1'");//结果登记权限
		@SuppressWarnings("unchecked")
		List<Character> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).setParameter(1, userCode).list();
		session.close();
		return list;
	}

	/**
	* <p>描述:待审核、待科长、待处长审核</p>
	* @param userCode
	* @param userOrgCode
	* @param string
	* @return
	* @author 吴有根
	*/
	public int getCountWaitAudit(String userCode, String ...userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT COUNT(1) FROM INS_DECL_MAG T,INS_DECL_REVIEW R WHERE T.DECL_NO=R.DECL_NO");
		if(userOrgCode.length!=2){//施检机构
			sql.append(" AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return 0;
		}
		
		if(StringUtils.isNotEmpty(userOrgCode[2])){
			if("1".equals(userOrgCode[2])){
				sql.append(" AND R.PROCESS_STATUS='1' ");
			}else if("2".equals(userOrgCode[2])){
				sql.append(" AND R.PROCESS_STATUS in('1','2') ");
			}else if("3".equals(userOrgCode[2])){
				sql.append(" AND R.PROCESS_STATUS in('1','2','3') ");
			}
		}
		sql.append(" AND (R.IS_AUDIT <> '2' or R.IS_AUDIT is null)");
		sql.append("	AND T.EXP_IMP_FLAG=?");//出入境标志
		BigDecimal count=(BigDecimal)session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode[0]).setParameter(1, userOrgCode[1]).uniqueResult();
		session.close();
		return count.intValue();
	}
	
	
	public List<Character> getCountWaitAudit(String userCode, String userOrgCode,String type) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG FROM INS_DECL_MAG T,INS_DECL_REVIEW R WHERE T.DECL_NO=R.DECL_NO");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append(" AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		
		//改为只查当前环节
		if(StringUtils.isNotEmpty(type)){
			if("1".equals(type)){
				sql.append(" AND R.PROCESS_STATUS='1' ");
			}else if("2".equals(type)){
				sql.append(" AND R.PROCESS_STATUS in('2') ");
			}else if("3".equals(type)){
				sql.append(" AND R.PROCESS_STATUS in('3') ");
			}
		}
		sql.append(" AND (R.IS_AUDIT <> '2' or R.IS_AUDIT is null)");
		@SuppressWarnings("unchecked")
		List<Character> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).list();
		session.close();
		return list;
	}
	
	
	/**
	 * 
	* <p>描述:待施检员审核、科长审核、处长审核</p>
	* @param userCode
	* @param userOrgCode
	* @param type
	* @return
	* @author 吴有根
	 */
	public List<Object[]> getCountWaitAudit2(String userCode, String userOrgCode) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		StringBuilder sql=new StringBuilder("SELECT T.EXP_IMP_FLAG,R.PROCESS_STATUS FROM INS_DECL_MAG T,INS_DECL_REVIEW R WHERE T.DECL_NO=R.DECL_NO");
		if(StringUtils.isNotEmpty(userOrgCode)){//施检机构
			sql.append(" AND T.EXE_INSP_ORG_CODE=?");
		}else{
			return null;
		}
		
		sql.append(" AND R.PROCESS_STATUS in('1','2','3') ");
		sql.append(" AND (R.IS_AUDIT <> '2' or R.IS_AUDIT is null)");
		@SuppressWarnings("unchecked")
		List<Object[]> list=session.createSQLQuery(sql.toString()).setParameter(0, userOrgCode).list();
		session.close();
		return list;
	}

	/**
	 * 
	* <p>描述:查询报检单回写记录信息</p>
	* @param sqlToDay 今日
	* @param sqlWeek 本周
	* @param sqlMonth 本月
	* @return
	* @author 才江男
	 */
	public Map jobDone(String userCode, String sqlToDay, String sqlEndDay, String sqlWeek, String sqlMonth) {
		Map map = new HashMap();
		int day = 0;
		int week = 0;
		int month = 0;
		String sql="FROM DclProcessStatsEntity t where t.operCode = ? and t.firstOperDate between to_date(?,'yyyy-mm-dd hh24:mi:ss') and to_date(?,'yyyy-mm-dd hh24:mi:ss')";
		List<String> param=new ArrayList<String>();
		param.add(userCode);
		param.add(sqlToDay);
		param.add(sqlEndDay);
		@SuppressWarnings("unchecked")
		List listDay=dao.getQueryList(sql, param.toArray());
		if(Utils.notEmpty(listDay)) {
			day = listDay.size();
		}
		
		sql="FROM DclProcessStatsEntity t where t.operCode = ? and t.firstOperDate > to_date(?,'yyyy-mm-dd hh24:mi:ss')";
		param.clear();
		param.add(userCode);
		param.add(sqlWeek);
		@SuppressWarnings("unchecked")
		List listWeek=dao.getQueryList(sql, param.toArray());
		if(Utils.notEmpty(listWeek)) {
			week = listWeek.size();
		}
		
		sql="FROM DclProcessStatsEntity t where t.operCode = ? and t.firstOperDate > to_date(?,'yyyy-mm-dd hh24:mi:ss')";
		param.clear();
		param.add(userCode);
		param.add(sqlMonth);
		@SuppressWarnings("unchecked")
		List listMonth=dao.getQueryList(sql, param.toArray());
		if(Utils.notEmpty(listMonth)) {
			month = listMonth.size();
		}
		
		map.put("day", day);
		map.put("week", week);
		map.put("month", month);
		return map;
	}
	
	/*
	 * 获取文件id
	 */
	public Object[] getfile(){
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		
		String sql = " select t.oper_time, t.file_code, t.ann_content from sys_ann_info_main t where t.ann_title='今日图片' ";
		Query query = session.createSQLQuery(sql);
		Object[] result = (Object[]) query.list().get(0);
		
		return result;
	}
	
}

/**  
 * FileName: PortalNoticeDao.java    
 * @Description: 公告信息数据类 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */

package com.rongji.eciq.mobile.dao.sys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.SysAnnInfoMainEntity;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;

/**  
 * Description: 公告信息数据类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-12 上午10:29:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      李晨阳                      1.0         1.0 Version
 * 2017-6-09      李晨阳                      1.0         公告加模糊查询
 */

@Repository
public class PortalNoticeDao {
	@Resource
	CompanyCodeUtils companyCodeUtils;

	PubCommonDAO dao = FrameworkHelper.getChgDAO();

	@Autowired
	HibernateTemplate chgHibernateTemplate;

	/**
	 * 获得公告信息
	 * 
	 * @param orgLevel
	 *            机构层级
	 * @param businOrgCode
	 *            带分类码的机构代码
	 * @param companyCode
	 *            用户所属机构代码
	 * @param userCode
	 *            用户代码
	 * @return 公告信息
	 */
	public List<SysAnnInfoMainEntity> getPortalNotice(String annTitle, String currentPage) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT t FROM SysAnnInfoMainEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		if(StringUtils.isNotEmpty(annTitle)){//出入境
			sql.append(" AND t.annTitle like ?");
			param.add("%" + annTitle + "%");
		}
		sql.append("order by t.annIssDate desc");
		Page page=MobileHelper.getPage(currentPage, null);
		page.setPageSize(10);
		List<SysAnnInfoMainEntity> list = dao.getQueryList(sql.toString(),page,param.toArray());
		return list;
		
	}	
	
	public List<SysAnnInfoMainEntity> getPortalNoticeList(int orgLevel,
			String businOrgCode, String companyCode, String userCode) {
		Session session = SessionFactoryUtils.getSession(
				chgHibernateTemplate.getSessionFactory(), true);
		if (StringUtils.isEmpty(businOrgCode)
				|| orgLevel == companyCodeUtils.ORG_LEVEL_ERR) {
			return null;
		}
		Map params = new HashMap();
		// Map<String, String> params = new HashMap<String, String>();
		String sql = buildSql(params, orgLevel, businOrgCode, companyCode,
				userCode).toString();
		Query query = session.createSQLQuery(sql).addEntity(
				SysAnnInfoMainEntity.class);
		for (Object key : params.keySet()) {
			query.setParameter(key.toString(), params.get(key));
		}

		List<SysAnnInfoMainEntity> annInfoList = query.list();
		session.close();
		return annInfoList;
	}

	/**
	 * 构建查询SQL语句及条件
	 * 
	 * @param params
	 *            条件
	 * @param orgLevel
	 *            机构级别
	 * @param businOrgCode
	 *            带分类码的机构代码
	 * @param companyCode
	 *            用户所属机构代码
	 * @param userCode
	 *            用户信息
	 * @return 公告信息
	 */
	private StringBuilder buildSql(Map params, int orgLevel,
			String businOrgCode, String companyCode, String userCode) {
		// String roleCodes = getUserRoleCode(userCode);
		String tempSql = "SELECT DISTINCT  A.ANN_INFO_MAIN_ID,A.SERIAL_NUMBER,A.ANN_TITLE,"
				+ "A.ANN_CONTENT,A.ANN_ISS_DATE,A.ANN_VALID_PD,A.CANCEL_DATE,"
				+ "A.ANN_ISSUER_CODE,A.ANN_DEPT_CODE,A.ISUE_ORG_CODE,A.OPER_CODE,"
				+ "A.OPER_DEPT_CODE,A.OPER_ORG_CODE,A.OPER_TIME,A.FALG_ARCHIVE,A.IS_TOP   "
				+ "FROM SYS_ANN_INFO_MAIN A  "
				+ "JOIN SYS_ANN_INFO_SUBLIST B ON A.ANN_INFO_MAIN_ID = B.ANN_INFO_MAIN_ID "
				+ "JOIN SYS_ANN_INFO_ROLE C ON  A.ANN_INFO_MAIN_ID = C.ANN_INFO_MAIN_ID  "
				+ "WHERE A.ANN_VALID_PD <= SYSDATE AND A.CANCEL_DATE >=SYSDATE   AND"
				+ "       EXISTS (SELECT M.ROLE_CODE "
				+ "                 FROM (SELECT DISTINCT B.ROLE_CODE "
				+ "                         FROM SYS_USER_ROLE A, SYS_ROLE_GROUP_DETAIL B "
				+ "                        WHERE A.ROLE_GROUP_CODE = B.ROLE_GROUP_CODE "
				+ "                          AND A.USER_CODE = ?userCode "
				+ "                       UNION "
				+ "                       SELECT DISTINCT C.ROLE_CODE  "
				+ "                         FROM SYS_USER_GROUP        A, "
				+ "                              SYS_USER_GROUP_DETAIL B, "
				+ "                              SYS_ROLE_GROUP_DETAIL C, "
				+ "                              SYS_GROUP_USER        D "
				+ "                        WHERE A.SYS_USER_GROUP_CODE = B.GROUP_CODE "
				+ "                          AND B.ROLE_CODE = C.ROLE_GROUP_CODE "
				+ "                          AND A.ENABLED = '1' "
				+ "                          AND D.GROUP_CODE = B.GROUP_CODE "
				+ "                          AND D.USER_CODE = ?userCode ) M "
				+ "                WHERE M.ROLE_CODE = C.ROLE_CODE ) ";
		// 根据机构代码，获得机构Map CompanyCodeUtils.getOrgMap(companyCode);
		Map<Integer, String> orgMap = companyCodeUtils.getOrgMap(companyCode);
		String sql = "SELECT ANN_INFO_MAIN_ID,ANN_ISS_DATE,ANN_VALID_PD,CANCEL_DATE,"
				+ "ANN_ISSUER_CODE,ANN_DEPT_CODE,ISUE_ORG_CODE,ANN_TITLE,ANN_CONTENT,OPER_TIME,IS_TOP,SERIAL_NUMBER  "
				+ "FROM  ( SELECT DISTINCT  A.ANN_INFO_MAIN_ID,A.SERIAL_NUMBER,A.ANN_TITLE,"
				+ "A.ANN_CONTENT,A.ANN_ISS_DATE,A.ANN_VALID_PD,A.CANCEL_DATE,"
				+ "A.ANN_ISSUER_CODE,A.ANN_DEPT_CODE,A.ISUE_ORG_CODE,A.OPER_CODE,"
				+ "A.OPER_DEPT_CODE,A.OPER_ORG_CODE,A.OPER_TIME,A.FALG_ARCHIVE,A.IS_TOP   "
				+ "FROM SYS_ANN_INFO_MAIN A  "
				+ "JOIN SYS_ANN_INFO_SUBLIST B ON A.ANN_INFO_MAIN_ID = B.ANN_INFO_MAIN_ID  "
				+ "WHERE NOT EXISTS (SELECT C.ANN_INFO_MAIN_ID "
				+ "FROM SYS_ANN_INFO_ROLE C "
				+ "WHERE C.ANN_INFO_MAIN_ID = A.ANN_INFO_MAIN_ID) "
				+ "AND A.ANN_VALID_PD <= SYSDATE AND A.CANCEL_DATE >=SYSDATE ";
		StringBuilder stringBuilder = new StringBuilder(sql);
		if (orgLevel == companyCodeUtils.ORG_LEVEL_0) {
			// 总局用户登录 查询适用机构为总局的数据
			stringBuilder.append(" AND B.APPL_ORG_CODE = ?orgCode  UNION  ")
					.append(tempSql).append("AND B.APPL_ORG_CODE = ?orgCode ");
		} else if (orgLevel == companyCodeUtils.ORG_LEVEL_1) {
			// 直属局用户登录 查询本直属局公告及总局勾选了全部机构的公告
			stringBuilder
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) ) UNION ")
					.append(tempSql)
					.append("AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) ) ");
			params.put("allOrgFlag", "1");
			params.put("nationOrgCode", companyCodeUtils.NATION_ORG_CODE);
		} else if (orgLevel == companyCodeUtils.ORG_LEVEL_2) {
			// 分支局用户登录 查询本分支局及总局、上属直属局勾选了全部机构的公告
			stringBuilder
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  UNION ")
					.append(tempSql)
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  ");
			params.put("allOrgFlag", "1");
			params.put("nationOrgCode", companyCodeUtils.NATION_ORG_CODE);
			params.put("belongOrgCode",
					orgMap.get(companyCodeUtils.ORG_LEVEL_1));
		} else if (orgLevel == companyCodeUtils.ORG_LEVEL_3) {
			// 办事处用户登录 查詢本办事处、上属分支局及总局、上属直属局勾选了全部机构的公告
			stringBuilder
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCodeSwitch  AND  B.IS_ALL_ORG =  ?allOrgFlag  )  "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  UNION ")
					.append(tempSql)
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCodeSwitch  AND  B.IS_ALL_ORG =  ?allOrgFlag  ) "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  ");
			params.put("allOrgFlag", "1");
			params.put("nationOrgCode", companyCodeUtils.NATION_ORG_CODE);
			params.put("belongOrgCode",
					orgMap.get(companyCodeUtils.ORG_LEVEL_1));
			params.put("belongOrgCodeSwitch",
					orgMap.get(companyCodeUtils.ORG_LEVEL_2));
		} else if (orgLevel == companyCodeUtils.ORG_LEVEL_4) {
			// 处室用户登录 查询本处室以及本办事处、上级分支局、直属局、总局勾选了全部机构的公告
			stringBuilder
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCodeSwitch  AND  B.IS_ALL_ORG =  ?allOrgFlag  ) "
							+ "OR ( B.APPL_ORG_CODE = ?agencyOrgCode  AND  B.IS_ALL_ORG =  ?allOrgFlag  ) "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  UNION ")
					.append(tempSql)
					.append(" AND ( B.APPL_ORG_CODE = ?orgCode  "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCodeSwitch  AND  B.IS_ALL_ORG =  ?allOrgFlag  ) "
							+ "OR ( B.APPL_ORG_CODE = ?agencyOrgCode  AND  B.IS_ALL_ORG =  ?allOrgFlag  ) "
							+ "OR ( B.APPL_ORG_CODE = ?nationOrgCode  "
							+ "AND  B.IS_ALL_ORG =  ?allOrgFlag ) "
							+ "OR ( B.APPL_ORG_CODE = ?belongOrgCode  "
							+ "AND B.IS_ALL_ORG = ?allOrgFlag ) )  ");
			params.put("allOrgFlag", "1");
			params.put("nationOrgCode", companyCodeUtils.NATION_ORG_CODE);
			params.put("belongOrgCode",
					orgMap.get(companyCodeUtils.ORG_LEVEL_1));
			params.put("belongOrgCodeSwitch",
					orgMap.get(companyCodeUtils.ORG_LEVEL_2));
			params.put("agencyOrgCode",
					orgMap.get(companyCodeUtils.ORG_LEVEL_3));
		}
		// stringBuilder.append(") ORDER BY ANN_ISS_DATE DESC");
		stringBuilder
				.append(") ORDER BY cast(SERIAL_NUMBER as int) DESC NULLS LAST, OPER_TIME DESC"); // modify
																									// by
																									// TK
																									// on
																									// 2016/11/22
		params.put("orgCode", businOrgCode);
		params.put("userCode", userCode);
		return stringBuilder;
	}
}

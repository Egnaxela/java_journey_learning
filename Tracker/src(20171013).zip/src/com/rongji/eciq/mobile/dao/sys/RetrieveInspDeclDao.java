/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-25 上午9:32:07  
 *  
 */  

package com.rongji.eciq.mobile.dao.sys;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.system.common.dao.PubCommonDAO;
import com.rongji.system.common.util.DaoHelper;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-25 上午9:32:07  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-25      李晨阳                      1.0         1.0 Version  
 * 2017-6-02      才江男                      1.0         调单报错  
 * 2017-6-06      才江男                      1.0         校验数据是否已同步过
 * 2017-6-19      李晨阳                      1.0         调整代码，独立mag表模板归档数据，解决相同主键引发的问题
 */

@Repository
public class RetrieveInspDeclDao {

	PubCommonDAO dao = DaoHelper.getOriDAO();
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	
	public String[] getDecl(String declNo){
		String[] exist = {"0",""};
//		String sql = "select b.process_link from Itf_Ins_Decl_Mag a , itf_dcl_io_decl b where a.decl_no = b.decl_no and a.decl_no = '"+ declNo +"'";
		String sql = "select b.process_node, a.write_usec from Itf_Ins_Decl_Mag a , itf_sys_process_log b where a.decl_no = b.decl_no and a.decl_no = '"+ declNo +"' order by a.write_usec desc";
		List<Object[]> res = dao.getQuerySqlList(sql);
		if(res.isEmpty()){
			exist[0] = "-1";
		}else{
			int processLink = Integer.parseInt((String) res.get(0)[0]);
			exist[1] = (String) res.get(0)[1];
			if (processLink < 17 && processLink > 13) {
				exist[0] = "1";
			} else {
				exist[0] = "2";
			}
		}
		return exist;
	}
	
	/**
	* <p>描述:数据是否已同步过</p>
	* @param declNo 报检单号
	* @return
	* @author 才江男
	 */
	public String findDecl(String declNo){
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		String sql="select t.decl_No from Ins_Decl_Mag t where decl_no = ?";
		Query query=session.createSQLQuery(sql).setParameter(0, declNo);
		List list=query.list();
		session.close();
		if(CollectionUtils.isEmpty(list)) {
			return "";
		}
		return "1";
	} 
	
}

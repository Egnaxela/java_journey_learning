/**  
 * FileName:SysUserMgrDao.java
 * @Description: 用户查询类 
 * Company       rongji
 * @version      1.0
 * @author:      才江男 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */
package com.rongji.eciq.mobile.dao.sys;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysTableCacheConfig;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.vo.sys.SysTableCacheConfigVo;
import com.rongji.system.common.util.FrameworkHelper;
import com.rongji.system.entity.SysFeedback;
import com.rongji.system.entity.SysFunction;

/**
 * 
 * Description: 用户查询类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男 
 * @version:    1.0  
 * Create at:   2017-5-15 下午4:58:19  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0        取消用户分页 
 * 2017-5-08      才江男                      1.0        保存意见
 * 2017-5-17      才江男                      1.0        刷新缓存
 * 2017-5-26      才江男                      1.0        修改密码错误
 * 2017-6-08      才江男                      1.0        关闭session
 * 2017-7-24      吴有根                      1.0        增加企业的信息查看、密码修改
 * 2017-7-28      才江男                      1.0        前后台权限统一管理
 */
@Repository
public class SysUserMgrDao {
	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	/**
	 * 根据用户代码查询用户
	 * 
	 * @param userCode 用户代码
	 * @return 用户信息
	 */
	public SysUser checkUser(String userCode) {
		StringBuilder sql = new StringBuilder();
		sql.append("from SysUser d where d.userCode=?");
		List<SysUser> list = dao.getQueryList(sql.toString(), userCode);
		if(CollectionUtils.isNotEmpty(list)){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 根据用户代码查询用户权限信息
	 * 
	 * @param userCode 用户代码
	 * @return 用户权限信息
	 */
	public List<SysFunction> getUserPrivileges(String userCode) {
		if("root".equals(userCode)) {
			return getUserPrivileges();
		}
//		String sql = "SELECT * FROM ( SELECT DISTINCT P.*	"  +
//						" FROM SYS_PRIVILEGE         P,                                         "  +
//						"      SYS_ROLE_PRIV         RP,                                        "  +
//						"      SYS_ROLE              R,                                         "  +
//						"      SYS_USER_ROLE         UR,                                        "  +
//						"      SYS_ROLE_GROUP        RG,                                        "  +
//						"      SYS_ROLE_GROUP_DETAIL RGD                                        "  +
//						" WHERE UR.ROLE_GROUP_CODE = RG.ROLE_GROUP_CODE                         "  +
//						"  AND RG.ROLE_GROUP_CODE = RGD.ROLE_GROUP_CODE                         "  +
//						"  AND RGD.ROLE_CODE = R.ROLE_CODE                                      "  +
//						"  AND R.ROLE_CODE = RP.ROLE_CODE                                       "  +
//						"  AND RP.PRIVILEGE_CODE = P.PRIVILEGE_CODE                             "  +
//						"  AND UR.USER_CODE = :userCode                                        "  +
//						"  AND R.VALID = '1'                                                    "  +
//						"  AND RG.ENABLED = '1'                                                 "  +
//						"                                                                       "  +
//						" UNION                                                                  "  +
//						"                                                                       "  +
//						" SELECT P.*              "  +
//						"         FROM Sys_Privilege p                                          "  +
//						"        WHERE p.parent_Code = '99'                                     "  +
//						" UNION                                                                  "  +
//						" SELECT DISTINCT H.*     "  +
//						"                 FROM SYS_GROUP_USER        A,                         "  +
//						"                SYS_USER_GROUP        B,                               "  +
//						"                SYS_USER_GROUP_DETAIL C,                               "  +
//						"                SYS_ROLE_GROUP        D,                               "  +
//						"                SYS_ROLE_GROUP_DETAIL E,                               "  +
//						"                SYS_ROLE              F,                               "  +
//						"                SYS_ROLE_PRIV         G,                               "  +
//						"                SYS_PRIVILEGE         H                                "  +
//						"                WHERE A.GROUP_CODE = B.SYS_USER_GROUP_CODE             "  +
//						"                  AND B.SYS_USER_GROUP_CODE = C.GROUP_CODE             "  +
//						"                  AND C.ROLE_CODE = D.ROLE_GROUP_CODE                  "  +
//						"                  AND D.ROLE_GROUP_CODE = E.ROLE_GROUP_CODE            "  +
//						"                  AND E.ROLE_CODE = F.ROLE_CODE                        "  +
//						"                  AND F.ROLE_CODE = G.ROLE_CODE                        "  +
//						"                  AND G.PRIVILEGE_CODE = H.PRIVILEGE_CODE              "  +
//						"                  AND A.USER_CODE = :userCode                          "  +
//						"                  AND F.VALID = '1'                                    "  +
//						"                  AND B.ENABLED = '1'                                  "  +
//						"                  AND D.ENABLED = '1'                                  "  +
//						" UNION 																"  +
String sql=				" SELECT DISTINCT G.*															"  +
						" FROM SYS_ROLE R, SYS_PERMISSION P,SYS_FUNCTION G,SYS_ROLE_USER U		"  +
						" WHERE R.ROLE_CODE = P.ROLE_ID										"  +
						" AND P.OPER_ID = G.FUNCTION_ID								"  +
						" AND U.ROLE_CODE=R.ROLE_CODE											"  +
						" AND U.USER_CODE=:userCode												"  +
						" AND G.FUNCTION_CATEGORY='1'" +
						" AND G.FUNCTION_STATUS='0' "+
						"   ORDER BY FUNCTION_ID ASC   ";//公共代码管理，送检管理权限不需要
		
//		JdbcTemplate jdbc = (JdbcTemplate) SystemData.getInstance()
//				.getBeanFactory().getBean("chgJdbcTemplate");
//		return jdbc.query(sql, new Object[]{userCode,userCode}, new BeanPropertyRowMapper<SysPrivilege>(SysPrivilege.class));
		
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		Query query=session.createSQLQuery(sql).addEntity(SysFunction.class).setParameter("userCode",userCode);
		List<SysFunction> list = query.list();
		session.close();
		return list;
	}
	
	/**
	 * 根据用户代码查询用户权限信息-root用户
	 * 
	 * @param userCode 用户代码
	 * @return 用户权限信息
	 */
	public List<SysFunction> getUserPrivileges() {
		
		String sql = "select * from SYS_FUNCTION d where d.FUNCTION_CATEGORY='1' AND d.FUNCTION_STATUS='0' ORDER BY d.FUNCTION_ID ASC  ";
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		Query query=session.createSQLQuery(sql).addEntity(SysFunction.class);
		List<SysFunction> list = query.list();
		session.close();
		return list;
	}
	
	/**
	 * 根据用户代码修改密码
	 * 
	 * @param userCode 用户代码
	 * @param password 新密码
	 */
	public void modifyPwd(String userCode, String password) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="UPDATE SYS_USER_A SET PASSWORD = ? WHERE USER_CODE = ?";
		Query query=session.createSQLQuery(sql).setParameter(0,password).setParameter(1, userCode);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

	/**
	 * 根据部门代码、用户代码，首页获取用户信息
	 * 
	 * @param orgCode 部门代码
	 * @param userCode 用户代码
	 * @param cp 页码
	 * @return 用户信息
	 */
	public List getUsers(String orgCode, String userCode, String cp) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SysUser t where  1=1 ");
		List<String> param=new ArrayList<String>();
		sql.append(" AND t.orgCode =?");
		param.add(orgCode);
		
		if(StringUtils.isNotEmpty(userCode)){
			sql.append(" AND t.userCode =?");
			param.add(userCode);
		}
		
//		if(StringUtils.isEmpty(cp)){
//			cp="1";
//		}
//		Page page=MobileHelper.getPage(cp);
	
//		return dao.getQueryList(sql.toString(), page, param.toArray());
		return dao.getQueryList(sql.toString(), param.toArray());
	}
	
	/**
	 * 根据机构代码查询下属部门信息
	 * 
	 * @param orgCode 机构代码
	 * @return 下属部门信息
	 */
	public List<SysOrganizeEntity> getOrgs(String orgCode) {
		String sql = "from SysOrganizeEntity d where (d.seniorCategoryCode = (select s.categoryCode from SysOrganizeEntity s where s.orgCode=?) or d.orgCode = ?)  and d.state = ?  order by orgCode asc";
		return dao.getQueryList(sql, orgCode, orgCode, "1");
	}
	
	/**
	 * 根据机构代码查询子级下属部门信息
	 * 
	 * @param orgCodes 部门代码
	 * @return 子级下属部门信息
	 */
	public List<String> getSubOrgs(List<String> orgCodes) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql ="select * from (select distinct d.senior_category_code from Sys_Organize d where d.senior_category_code in (:list) and d.state = :state)";
		Query query=session.createSQLQuery(sql).setParameterList("list", orgCodes).setParameter("state", "1");
		List<String> list = query.list();
		session.close();
		return list;
	}
	
	/**
	 * 根据用户代码查询所在部门
	 * 
	 * @param userCode 用户代码
	 * @return 部门信息
	 */
	public SysOrganizeEntity getOrgByUserCode(String userCode) {
		String sql = "select d from SysOrganizeEntity d,SysUser u where d.orgCode = u.orgCode and u.userCode = ?)";
		List<SysOrganizeEntity> queryList = dao.getQueryList(sql, userCode);
		if(CollectionUtils.isNotEmpty(queryList)) {
			return queryList.get(0);
		}
		return null;
	}
	
	/**
	 * 保存意见
	 * @param sysFeedback 意见
	 */
	public void saveFeeBack(SysFeedback sysFeedback) {
		Session session=SessionFactoryUtils.getSession(hibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		session.save(sysFeedback);
		session.getTransaction().commit();
		session.close();
	}
	
	/**
	 * 
	* <p>描述:获取缓存配置项</p>
	* @return
	* @author 才江男
	 */
	public List<SysTableCacheConfig> getDbConfig() {
		String sql="from SysTableCacheConfig t";
		return dao.getQueryList(sql);
	}
	
	/**
	* <p>描述: 刷新缓存</p>
	* @param param
	* @return
	* @author 才江男
	 */
	public SysTableCacheConfig dbUpdate(StringBuilder sbql, String tableName, Date time) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		String sql ="from SysTableCacheConfig t ";
		if(StringUtils.isNotEmpty(sbql.toString())) {
			sql += sbql.toString();
		}
		List<SysTableCacheConfig> list = session.createQuery(sql).setParameter(0, tableName).setDate(1, time).list();
		session.close();
		if(CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}
		return null;
	}
	
	/**
	* <p>描述: 刷新缓存</p>
	* @param param
	* @return
	* @author 才江男
	 */
	public List<SysTableCacheConfigVo> queryDb(String sql, Date start, Date end) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		sql += " and lastupdate > ? and lastupdate <= ?";
		Query query=session.createSQLQuery(sql).setDate(0, start).setDate(1, end);
		List<SysTableCacheConfigVo> list = query.list();
		session.close();
		return list;
	}

	/**
	* <p>描述:修改企业用户密码</p>
	* @param entOrgCode
	* @param newpwd
	* @author 吴有根
	*/
	public void modifyEntBaseInfoPwd(String entOrgCode, String newpwd) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.beginTransaction();
		String sql="UPDATE ENT_BASE_INFO SET ENT_ORG_PWD = ? WHERE ENT_ORG_CODE = ?";
		Query query=session.createSQLQuery(sql).setParameter(0,newpwd).setParameter(1, entOrgCode);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();		
	}
}

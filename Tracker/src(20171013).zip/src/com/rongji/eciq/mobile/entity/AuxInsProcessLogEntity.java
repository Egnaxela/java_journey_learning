package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "AUX_INS_PROCESS_LOG")
public class AuxInsProcessLogEntity implements java.io.Serializable {

	// Fields

	private String auxInsProcessLogId;
	private String declMagId;
	private String declNo;
	private String processNode;
	private String processStatus;
	private String statusMemo;
	private String nodeMemo;
	private String operCode;
	private String operName;
	private Date operDate;
	private String falgArchive;
	private String remark;
	private Date endDate;
	private String treaOperCode;
	private String treaOperName;
	private String treaOrgCode;
	private String inspContCodes;
	private String exeInspOrgCode;
	private String excInspDeptCode;

	// Constructors

	/** default constructor */
	public AuxInsProcessLogEntity() {
	}

	/** minimal constructor */
	public AuxInsProcessLogEntity(String auxInsProcessLogId) {
		this.auxInsProcessLogId = auxInsProcessLogId;
	}

	/** full constructor */
	public AuxInsProcessLogEntity(String auxInsProcessLogId,
			String declMagId, String declNo, String processNode,
			String processStatus, String statusMemo, String nodeMemo,
			String operCode, String operName, Date operDate,
			String falgArchive, String remark, Date endDate,
			String treaOperCode, String treaOperName, String treaOrgCode,
			String inspContCodes, String exeInspOrgCode, String excInspDeptCode) {
		this.auxInsProcessLogId = auxInsProcessLogId;
		this.declMagId = declMagId;
		this.declNo = declNo;
		this.processNode = processNode;
		this.processStatus = processStatus;
		this.statusMemo = statusMemo;
		this.nodeMemo = nodeMemo;
		this.operCode = operCode;
		this.operName = operName;
		this.operDate = operDate;
		this.falgArchive = falgArchive;
		this.remark = remark;
		this.endDate = endDate;
		this.treaOperCode = treaOperCode;
		this.treaOperName = treaOperName;
		this.treaOrgCode = treaOrgCode;
		this.inspContCodes = inspContCodes;
		this.exeInspOrgCode = exeInspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
	}

	// Property accessors
	@Id
	@Column(name = "AUX_INS_PROCESS_LOG_ID", unique = true, nullable = false, length = 32)
	public String getAuxInsProcessLogId() {
		return this.auxInsProcessLogId;
	}

	public void setAuxInsProcessLogId(String auxInsProcessLogId) {
		this.auxInsProcessLogId = auxInsProcessLogId;
	}

	@Column(name = "DECL_MAG_ID", length = 32)
	public String getDeclMagId() {
		return this.declMagId;
	}

	public void setDeclMagId(String declMagId) {
		this.declMagId = declMagId;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "PROCESS_NODE", length = 8)
	public String getProcessNode() {
		return this.processNode;
	}

	public void setProcessNode(String processNode) {
		this.processNode = processNode;
	}

	@Column(name = "PROCESS_STATUS", length = 10)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name = "STATUS_MEMO", length = 100)
	public String getStatusMemo() {
		return this.statusMemo;
	}

	public void setStatusMemo(String statusMemo) {
		this.statusMemo = statusMemo;
	}

	@Column(name = "NODE_MEMO", length = 100)
	public String getNodeMemo() {
		return this.nodeMemo;
	}

	public void setNodeMemo(String nodeMemo) {
		this.nodeMemo = nodeMemo;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "OPER_NAME", length = 50)
	public String getOperName() {
		return this.operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_DATE", length = 7)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "END_DATE", length = 7)
	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Column(name = "TREA_OPER_CODE", length = 20)
	public String getTreaOperCode() {
		return this.treaOperCode;
	}

	public void setTreaOperCode(String treaOperCode) {
		this.treaOperCode = treaOperCode;
	}

	@Column(name = "TREA_OPER_NAME", length = 50)
	public String getTreaOperName() {
		return this.treaOperName;
	}

	public void setTreaOperName(String treaOperName) {
		this.treaOperName = treaOperName;
	}

	@Column(name = "TREA_ORG_CODE", length = 10)
	public String getTreaOrgCode() {
		return this.treaOrgCode;
	}

	public void setTreaOrgCode(String treaOrgCode) {
		this.treaOrgCode = treaOrgCode;
	}

	@Column(name = "INSP_CONT_CODES", length = 50)
	public String getInspContCodes() {
		return this.inspContCodes;
	}

	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}

	@Column(name = "EXE_INSP_ORG_CODE", length = 10)
	public String getExeInspOrgCode() {
		return this.exeInspOrgCode;
	}

	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DclCont entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_CONT")
public class DclContEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -7804912640275146364L;
	private String contDeclNo;
	private String stationRegiNo;
	private String stationName;
	private String stationAddr;
	private String declUnitCode;
	private String declRegName;
	private String declUnitContact;
	private String declUnitTel;
	private Timestamp declTime;
	private Timestamp preInspDate;
	private Double containerQty;
	private String contType;
	private String settingTemper;
	private String loadGoodsName;
	private String attDocName;
	private String declCode;
	private String inspOrgCode;
	private String excInspDeptCode;
	private String processStatus;
	private Timestamp operTime;
	private String falgArchive;
	private String processLink;
	private String orgCode;
	private String declGetNo;
	private String entDeclNo;
	private Timestamp archiveTime;
	private String entUuid;
	private String isFee;
	private String declType;
	private String orgCodePath;
	private String declStatus;
	private String convynceName;
	private Timestamp entDate;

	// Constructors

	/** default constructor */
	public DclContEntity() {
	}

	/** minimal constructor */
	public DclContEntity(String contDeclNo, Timestamp declTime,
			Timestamp preInspDate, Double containerQty, String contType) {
		this.contDeclNo = contDeclNo;
		this.declTime = declTime;
		this.preInspDate = preInspDate;
		this.containerQty = containerQty;
		this.contType = contType;
	}

	/** full constructor */
	public DclContEntity(String contDeclNo, String stationRegiNo, String stationName,
			String stationAddr, String declUnitCode, String declRegName,
			String declUnitContact, String declUnitTel, Timestamp declTime,
			Timestamp preInspDate, Double containerQty, String contType,
			String settingTemper, String loadGoodsName, String attDocName,
			String declCode, String inspOrgCode, String excInspDeptCode,
			String processStatus, Timestamp operTime, String falgArchive,
			String processLink, String orgCode, String declGetNo,
			String entDeclNo, Timestamp archiveTime, String entUuid,
			String isFee, String declType, String orgCodePath,
			String declStatus, String convynceName, Timestamp entDate) {
		this.contDeclNo = contDeclNo;
		this.stationRegiNo = stationRegiNo;
		this.stationName = stationName;
		this.stationAddr = stationAddr;
		this.declUnitCode = declUnitCode;
		this.declRegName = declRegName;
		this.declUnitContact = declUnitContact;
		this.declUnitTel = declUnitTel;
		this.declTime = declTime;
		this.preInspDate = preInspDate;
		this.containerQty = containerQty;
		this.contType = contType;
		this.settingTemper = settingTemper;
		this.loadGoodsName = loadGoodsName;
		this.attDocName = attDocName;
		this.declCode = declCode;
		this.inspOrgCode = inspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.processStatus = processStatus;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.processLink = processLink;
		this.orgCode = orgCode;
		this.declGetNo = declGetNo;
		this.entDeclNo = entDeclNo;
		this.archiveTime = archiveTime;
		this.entUuid = entUuid;
		this.isFee = isFee;
		this.declType = declType;
		this.orgCodePath = orgCodePath;
		this.declStatus = declStatus;
		this.convynceName = convynceName;
		this.entDate = entDate;
	}

	// Property accessors
	@Id
	@Column(name = "CONT_DECL_NO", unique = true, nullable = false, length = 20)
	public String getContDeclNo() {
		return this.contDeclNo;
	}

	public void setContDeclNo(String contDeclNo) {
		this.contDeclNo = contDeclNo;
	}

	@Column(name = "STATION_REGI_NO", length = 20)
	public String getStationRegiNo() {
		return this.stationRegiNo;
	}

	public void setStationRegiNo(String stationRegiNo) {
		this.stationRegiNo = stationRegiNo;
	}

	@Column(name = "STATION_NAME", length = 50)
	public String getStationName() {
		return this.stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	@Column(name = "STATION_ADDR", length = 500)
	public String getStationAddr() {
		return this.stationAddr;
	}

	public void setStationAddr(String stationAddr) {
		this.stationAddr = stationAddr;
	}

	@Column(name = "DECL_UNIT_CODE", length = 20)
	public String getDeclUnitCode() {
		return this.declUnitCode;
	}

	public void setDeclUnitCode(String declUnitCode) {
		this.declUnitCode = declUnitCode;
	}

	@Column(name = "DECL_REG_NAME", length = 100)
	public String getDeclRegName() {
		return this.declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	@Column(name = "DECL_UNIT_CONTACT", length = 50)
	public String getDeclUnitContact() {
		return this.declUnitContact;
	}

	public void setDeclUnitContact(String declUnitContact) {
		this.declUnitContact = declUnitContact;
	}

	@Column(name = "DECL_UNIT_TEL", length = 20)
	public String getDeclUnitTel() {
		return this.declUnitTel;
	}

	public void setDeclUnitTel(String declUnitTel) {
		this.declUnitTel = declUnitTel;
	}

	@Column(name = "DECL_TIME", nullable = false, length = 7)
	public Timestamp getDeclTime() {
		return this.declTime;
	}

	public void setDeclTime(Timestamp declTime) {
		this.declTime = declTime;
	}

	@Column(name = "PRE_INSP_DATE", nullable = false, length = 7)
	public Timestamp getPreInspDate() {
		return this.preInspDate;
	}

	public void setPreInspDate(Timestamp preInspDate) {
		this.preInspDate = preInspDate;
	}

	@Column(name = "CONTAINER_QTY", nullable = false, precision = 0)
	public Double getContainerQty() {
		return this.containerQty;
	}

	public void setContainerQty(Double containerQty) {
		this.containerQty = containerQty;
	}

	@Column(name = "CONT_TYPE", nullable = false, length = 2)
	public String getContType() {
		return this.contType;
	}

	public void setContType(String contType) {
		this.contType = contType;
	}

	@Column(name = "SETTING_TEMPER", length = 10)
	public String getSettingTemper() {
		return this.settingTemper;
	}

	public void setSettingTemper(String settingTemper) {
		this.settingTemper = settingTemper;
	}

	@Column(name = "LOAD_GOODS_NAME", length = 50)
	public String getLoadGoodsName() {
		return this.loadGoodsName;
	}

	public void setLoadGoodsName(String loadGoodsName) {
		this.loadGoodsName = loadGoodsName;
	}

	@Column(name = "ATT_DOC_NAME", length = 200)
	public String getAttDocName() {
		return this.attDocName;
	}

	public void setAttDocName(String attDocName) {
		this.attDocName = attDocName;
	}

	@Column(name = "DECL_CODE", length = 4)
	public String getDeclCode() {
		return this.declCode;
	}

	public void setDeclCode(String declCode) {
		this.declCode = declCode;
	}

	@Column(name = "INSP_ORG_CODE", length = 10)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "PROCESS_STATUS", length = 10)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "PROCESS_LINK", length = 4)
	public String getProcessLink() {
		return this.processLink;
	}

	public void setProcessLink(String processLink) {
		this.processLink = processLink;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "DECL_GET_NO", length = 20)
	public String getDeclGetNo() {
		return this.declGetNo;
	}

	public void setDeclGetNo(String declGetNo) {
		this.declGetNo = declGetNo;
	}

	@Column(name = "ENT_DECL_NO", length = 40)
	public String getEntDeclNo() {
		return this.entDeclNo;
	}

	public void setEntDeclNo(String entDeclNo) {
		this.entDeclNo = entDeclNo;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "ENT_UUID", length = 32)
	public String getEntUuid() {
		return this.entUuid;
	}

	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}

	@Column(name = "IS_FEE", length = 1)
	public String getIsFee() {
		return this.isFee;
	}

	public void setIsFee(String isFee) {
		this.isFee = isFee;
	}

	@Column(name = "DECL_TYPE", length = 1)
	public String getDeclType() {
		return this.declType;
	}

	public void setDeclType(String declType) {
		this.declType = declType;
	}

	@Column(name = "ORG_CODE_PATH", length = 200)
	public String getOrgCodePath() {
		return this.orgCodePath;
	}

	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}

	@Column(name = "DECL_STATUS", length = 1)
	public String getDeclStatus() {
		return this.declStatus;
	}

	public void setDeclStatus(String declStatus) {
		this.declStatus = declStatus;
	}

	@Column(name = "CONVYNCE_NAME", length = 200)
	public String getConvynceName() {
		return this.convynceName;
	}

	public void setConvynceName(String convynceName) {
		this.convynceName = convynceName;
	}

	@Column(name = "ENT_DATE", length = 7)
	public Timestamp getEntDate() {
		return this.entDate;
	}

	public void setEntDate(Timestamp entDate) {
		this.entDate = entDate;
	}

}
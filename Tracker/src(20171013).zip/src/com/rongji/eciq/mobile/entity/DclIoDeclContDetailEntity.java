package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclIoDeclContDetail entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_CONT_DETAIL")
public class DclIoDeclContDetailEntity implements java.io.Serializable {

	private static final long serialVersionUID = -8099848911294927975L;
	private String contDtId;
	private DclIoDeclContEntity dclIoDeclCont;
	private String declNo;
	private String cntnrModeCode;
	private String contNo;
	private String lclFlag;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private Double seqNo;
	private String dclIoDeclId;

	// Constructors

	/** default constructor */
	public DclIoDeclContDetailEntity() {
	}

	/** minimal constructor */
	public DclIoDeclContDetailEntity(String contDtId, String declNo,
			String cntnrModeCode) {
		this.contDtId = contDtId;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
	}

	/** full constructor */
	public DclIoDeclContDetailEntity(String contDtId, DclIoDeclContEntity dclIoDeclCont,
			String declNo, String cntnrModeCode, String contNo, String lclFlag,
			Timestamp operTime, String falgArchive, Timestamp archiveTime,
			Double seqNo, String dclIoDeclId) {
		this.contDtId = contDtId;
		this.dclIoDeclCont = dclIoDeclCont;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
		this.contNo = contNo;
		this.lclFlag = lclFlag;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.seqNo = seqNo;
		this.dclIoDeclId = dclIoDeclId;
	}

	// Property accessors
	@Id
	@Column(name = "CONT_DT_ID", unique = true, nullable = false, length = 32)
	public String getContDtId() {
		return this.contDtId;
	}

	public void setContDtId(String contDtId) {
		this.contDtId = contDtId;
	}

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "CONT_ID")
//	public DclIoDeclContEntity getDclIoDeclCont() {
//		return this.dclIoDeclCont;
//	}
//
//	public void setDclIoDeclCont(DclIoDeclContEntity dclIoDeclCont) {
//		this.dclIoDeclCont = dclIoDeclCont;
//	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "CNTNR_MODE_CODE", nullable = false, length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

	@Column(name = "CONT_NO", length = 100)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "LCL_FLAG", length = 1)
	public String getLclFlag() {
		return this.lclFlag;
	}

	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "SEQ_NO", precision = 0)
	public Double getSeqNo() {
		return this.seqNo;
	}

	public void setSeqNo(Double seqNo) {
		this.seqNo = seqNo;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

}
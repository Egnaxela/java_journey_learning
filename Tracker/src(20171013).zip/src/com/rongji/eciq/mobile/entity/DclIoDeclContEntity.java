package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * DclIoDeclCont entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_CONT")
public class DclIoDeclContEntity implements java.io.Serializable {


	private static final long serialVersionUID = -586602641185426861L;
	private String contId;
	private String declNo;
	private String cntnrModeCode;
	private Double containerQty;
	private String contNo;
	private String lclFlag;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private String wtUnitCode;
	private Double weight;
	private Double seqNo;
	private String dclIoDeclId;
	private String isFee;
	private Set<DclIoDeclContDetailEntity> dclIoDeclContDetails = new HashSet<DclIoDeclContDetailEntity>(
			0);

	// Constructors

	/** default constructor */
	public DclIoDeclContEntity() {
	}

	/** minimal constructor */
	public DclIoDeclContEntity(String contId, String declNo, String cntnrModeCode) {
		this.contId = contId;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
	}

	/** full constructor */
	public DclIoDeclContEntity(String contId, String declNo, String cntnrModeCode,
			Double containerQty, String contNo, String lclFlag,
			Timestamp operTime, String falgArchive, Timestamp archiveTime,
			String wtUnitCode, Double weight, Double seqNo, String dclIoDeclId,
			String isFee, Set<DclIoDeclContDetailEntity> dclIoDeclContDetails) {
		this.contId = contId;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
		this.containerQty = containerQty;
		this.contNo = contNo;
		this.lclFlag = lclFlag;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.wtUnitCode = wtUnitCode;
		this.weight = weight;
		this.seqNo = seqNo;
		this.dclIoDeclId = dclIoDeclId;
		this.isFee = isFee;
		this.dclIoDeclContDetails = dclIoDeclContDetails;
	}

	// Property accessors
	@Id
	@Column(name = "CONT_ID", unique = true, nullable = false, length = 32)
	public String getContId() {
		return this.contId;
	}

	public void setContId(String contId) {
		this.contId = contId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "CNTNR_MODE_CODE", nullable = false, length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

	@Column(name = "CONTAINER_QTY", precision = 0)
	public Double getContainerQty() {
		return this.containerQty;
	}

	public void setContainerQty(Double containerQty) {
		this.containerQty = containerQty;
	}

	@Column(name = "CONT_NO", length = 4000)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "LCL_FLAG", length = 1)
	public String getLclFlag() {
		return this.lclFlag;
	}

	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "WT_UNIT_CODE", length = 4)
	public String getWtUnitCode() {
		return this.wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	@Column(name = "WEIGHT", precision = 0)
	public Double getWeight() {
		return this.weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	@Column(name = "SEQ_NO", precision = 0)
	public Double getSeqNo() {
		return this.seqNo;
	}

	public void setSeqNo(Double seqNo) {
		this.seqNo = seqNo;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

	@Column(name = "IS_FEE", length = 1)
	public String getIsFee() {
		return this.isFee;
	}

	public void setIsFee(String isFee) {
		this.isFee = isFee;
	}

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclIoDeclCont")
//	public Set<DclIoDeclContDetailEntity> getDclIoDeclContDetails() {
//		return this.dclIoDeclContDetails;
//	}
//
//	public void setDclIoDeclContDetails(
//			Set<DclIoDeclContDetailEntity> dclIoDeclContDetails) {
//		this.dclIoDeclContDetails = dclIoDeclContDetails;
//	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * DclIoDecl entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL", uniqueConstraints = @UniqueConstraint(columnNames = "DECL_NO"))
public class DclIoDeclEntity implements java.io.Serializable {

	private static final long serialVersionUID = 8239347728827153886L;
	private String dclIoDeclId;
	private String declNo;
	private String tradeModeCode;
	private String contractNo;
	private String markNo;
	private String tradeCountryCode;
	private String despCtryCode;
	private String transModeCode;
	private String convynceName;
	private String transMeanNo;
	private String despPortCode;
	private String portStopCode;
	private String entyPortCode;
	private Timestamp gdsArvlDate;
	private Timestamp cmplDschrgDt;
	private String goodsPlace;
	private String destCode;
	private Timestamp counterClaim;
	private String billLadNo;
	private String deliveryOrder;
	private String inspOrgCode;
	private String excInspDeptCode;
	private String declCustm;
	private String specDeclFlag;
	private String purpOrgCode;
	private String correlationDeclNo;
	private String correlationReasonFlag;
	private String speclInspQuraRe;
	private String appCertCode;
	private String applOri;
	private String applCopyQuan;
	private String custmRegNo;
	private String declPersnCertNo;
	private String declPersonName;
	private String declRegName;
	private String contactperson;
	private String contTel;
	private String consigneeCode;
	private String consigneeCname;
	private String consigneeEname;
	private String consignorCname;
	private String consignorAddr;
	private String declCode;
	private Timestamp declDate;
	private String declGetNo;
	private String specPassFlag;
	private Timestamp despDate;
	private String arrivPortCode;
	private String consigneeAddr;
	private String consignorCode;
	private String attaCollectName;
	private String isListGood;
	private String isCont;
	private String ffjFlag;
	private String ffjStatus;
	private String resendNum;
	private String isDraw;
	private Double totalValUs;
	private Double totalValCn;
	private String contCancelFlag;
	private String feeHandleState;
	private String relsState;
	private String flgPortInland;
	private String enableTransFlag;
	private String falgArchive;
	private String situationCode;
	private String situationLevel;
	private String processStatus;
	private String operCode;
	private Timestamp operTime;
	private String appCertName;
	private String declRegNo;
	private String entDeclNo;
	private String processLink;
	private String orgCode;
	private String certCancelFlag;
	private String consignorEname;
	private Timestamp archiveTime;
	private String transFlag;
	private String splitBillLadNo;
	private String entUuid;
	private String declType;
	private String orgCodePath;
	private String declStatus;
	private String isFee;
	private String declWorkNo;
	private String purpDeptCode;
	private String vsaOrgCode;
	private String portOrgCode;
	private String portDeptCode;
	private String inteFlag;
	private String briFlag;
	private String checkOkFlag;
	private String disChargeFlag;
	private String origBoxFlag;
	private String vsaOrgCodePath;
	private String inspOrgCodePath;
	private String purpOrgCodePath;
	private String portOrgCodePath;
	private Timestamp entDate;

	// Constructors

	/** default constructor */
	public DclIoDeclEntity() {
	}

	/** minimal constructor */
	public DclIoDeclEntity(String dclIoDeclId, String declNo, String tradeModeCode,
			String goodsPlace, String inspOrgCode, String excInspDeptCode,
			String declRegName, String contactperson, String contTel,
			String declCode, Double totalValUs, Double totalValCn,
			String declRegNo) {
		this.dclIoDeclId = dclIoDeclId;
		this.declNo = declNo;
		this.tradeModeCode = tradeModeCode;
		this.goodsPlace = goodsPlace;
		this.inspOrgCode = inspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.declRegName = declRegName;
		this.contactperson = contactperson;
		this.contTel = contTel;
		this.declCode = declCode;
		this.totalValUs = totalValUs;
		this.totalValCn = totalValCn;
		this.declRegNo = declRegNo;
	}

	/** full constructor */
	public DclIoDeclEntity(String dclIoDeclId, String declNo, String tradeModeCode,
			String contractNo, String markNo, String tradeCountryCode,
			String despCtryCode, String transModeCode, String convynceName,
			String transMeanNo, String despPortCode, String portStopCode,
			String entyPortCode, Timestamp gdsArvlDate, Timestamp cmplDschrgDt,
			String goodsPlace, String destCode, Timestamp counterClaim,
			String billLadNo, String deliveryOrder, String inspOrgCode,
			String excInspDeptCode, String declCustm, String specDeclFlag,
			String purpOrgCode, String correlationDeclNo,
			String correlationReasonFlag, String speclInspQuraRe,
			String appCertCode, String applOri, String applCopyQuan,
			String custmRegNo, String declPersnCertNo, String declPersonName,
			String declRegName, String contactperson, String contTel,
			String consigneeCode, String consigneeCname, String consigneeEname,
			String consignorCname, String consignorAddr, String declCode,
			Timestamp declDate, String declGetNo, String specPassFlag,
			Timestamp despDate, String arrivPortCode, String consigneeAddr,
			String consignorCode, String attaCollectName, String isListGood,
			String isCont, String ffjFlag, String ffjStatus, String resendNum,
			String isDraw, Double totalValUs, Double totalValCn,
			String contCancelFlag, String feeHandleState, String relsState,
			String flgPortInland, String enableTransFlag, String falgArchive,
			String situationCode, String situationLevel, String processStatus,
			String operCode, Timestamp operTime, String appCertName,
			String declRegNo, String entDeclNo, String processLink,
			String orgCode, String certCancelFlag, String consignorEname,
			Timestamp archiveTime, String transFlag, String splitBillLadNo,
			String entUuid, String declType, String orgCodePath,
			String declStatus, String isFee, String declWorkNo,
			String purpDeptCode, String vsaOrgCode, String portOrgCode,
			String portDeptCode, String inteFlag, String briFlag,
			String checkOkFlag, String disChargeFlag, String origBoxFlag,
			String vsaOrgCodePath, String inspOrgCodePath,
			String purpOrgCodePath, String portOrgCodePath, Timestamp entDate) {
		this.dclIoDeclId = dclIoDeclId;
		this.declNo = declNo;
		this.tradeModeCode = tradeModeCode;
		this.contractNo = contractNo;
		this.markNo = markNo;
		this.tradeCountryCode = tradeCountryCode;
		this.despCtryCode = despCtryCode;
		this.transModeCode = transModeCode;
		this.convynceName = convynceName;
		this.transMeanNo = transMeanNo;
		this.despPortCode = despPortCode;
		this.portStopCode = portStopCode;
		this.entyPortCode = entyPortCode;
		this.gdsArvlDate = gdsArvlDate;
		this.cmplDschrgDt = cmplDschrgDt;
		this.goodsPlace = goodsPlace;
		this.destCode = destCode;
		this.counterClaim = counterClaim;
		this.billLadNo = billLadNo;
		this.deliveryOrder = deliveryOrder;
		this.inspOrgCode = inspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.declCustm = declCustm;
		this.specDeclFlag = specDeclFlag;
		this.purpOrgCode = purpOrgCode;
		this.correlationDeclNo = correlationDeclNo;
		this.correlationReasonFlag = correlationReasonFlag;
		this.speclInspQuraRe = speclInspQuraRe;
		this.appCertCode = appCertCode;
		this.applOri = applOri;
		this.applCopyQuan = applCopyQuan;
		this.custmRegNo = custmRegNo;
		this.declPersnCertNo = declPersnCertNo;
		this.declPersonName = declPersonName;
		this.declRegName = declRegName;
		this.contactperson = contactperson;
		this.contTel = contTel;
		this.consigneeCode = consigneeCode;
		this.consigneeCname = consigneeCname;
		this.consigneeEname = consigneeEname;
		this.consignorCname = consignorCname;
		this.consignorAddr = consignorAddr;
		this.declCode = declCode;
		this.declDate = declDate;
		this.declGetNo = declGetNo;
		this.specPassFlag = specPassFlag;
		this.despDate = despDate;
		this.arrivPortCode = arrivPortCode;
		this.consigneeAddr = consigneeAddr;
		this.consignorCode = consignorCode;
		this.attaCollectName = attaCollectName;
		this.isListGood = isListGood;
		this.isCont = isCont;
		this.ffjFlag = ffjFlag;
		this.ffjStatus = ffjStatus;
		this.resendNum = resendNum;
		this.isDraw = isDraw;
		this.totalValUs = totalValUs;
		this.totalValCn = totalValCn;
		this.contCancelFlag = contCancelFlag;
		this.feeHandleState = feeHandleState;
		this.relsState = relsState;
		this.flgPortInland = flgPortInland;
		this.enableTransFlag = enableTransFlag;
		this.falgArchive = falgArchive;
		this.situationCode = situationCode;
		this.situationLevel = situationLevel;
		this.processStatus = processStatus;
		this.operCode = operCode;
		this.operTime = operTime;
		this.appCertName = appCertName;
		this.declRegNo = declRegNo;
		this.entDeclNo = entDeclNo;
		this.processLink = processLink;
		this.orgCode = orgCode;
		this.certCancelFlag = certCancelFlag;
		this.consignorEname = consignorEname;
		this.archiveTime = archiveTime;
		this.transFlag = transFlag;
		this.splitBillLadNo = splitBillLadNo;
		this.entUuid = entUuid;
		this.declType = declType;
		this.orgCodePath = orgCodePath;
		this.declStatus = declStatus;
		this.isFee = isFee;
		this.declWorkNo = declWorkNo;
		this.purpDeptCode = purpDeptCode;
		this.vsaOrgCode = vsaOrgCode;
		this.portOrgCode = portOrgCode;
		this.portDeptCode = portDeptCode;
		this.inteFlag = inteFlag;
		this.briFlag = briFlag;
		this.checkOkFlag = checkOkFlag;
		this.disChargeFlag = disChargeFlag;
		this.origBoxFlag = origBoxFlag;
		this.vsaOrgCodePath = vsaOrgCodePath;
		this.inspOrgCodePath = inspOrgCodePath;
		this.purpOrgCodePath = purpOrgCodePath;
		this.portOrgCodePath = portOrgCodePath;
		this.entDate = entDate;
	}

	// Property accessors
	@Id
	@Column(name = "DCL_IO_DECL_ID", unique = true, nullable = false, length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

	@Column(name = "DECL_NO", unique = true, nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "TRADE_MODE_CODE", nullable = false, length = 4)
	public String getTradeModeCode() {
		return this.tradeModeCode;
	}

	public void setTradeModeCode(String tradeModeCode) {
		this.tradeModeCode = tradeModeCode;
	}

	@Column(name = "CONTRACT_NO", length = 200)
	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	@Column(name = "MARK_NO", length = 400)
	public String getMarkNo() {
		return this.markNo;
	}

	public void setMarkNo(String markNo) {
		this.markNo = markNo;
	}

	@Column(name = "TRADE_COUNTRY_CODE", length = 8)
	public String getTradeCountryCode() {
		return this.tradeCountryCode;
	}

	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}

	@Column(name = "DESP_CTRY_CODE", length = 8)
	public String getDespCtryCode() {
		return this.despCtryCode;
	}

	public void setDespCtryCode(String despCtryCode) {
		this.despCtryCode = despCtryCode;
	}

	@Column(name = "TRANS_MODE_CODE", length = 4)
	public String getTransModeCode() {
		return this.transModeCode;
	}

	public void setTransModeCode(String transModeCode) {
		this.transModeCode = transModeCode;
	}

	@Column(name = "CONVYNCE_NAME", length = 200)
	public String getConvynceName() {
		return this.convynceName;
	}

	public void setConvynceName(String convynceName) {
		this.convynceName = convynceName;
	}

	@Column(name = "TRANS_MEAN_NO", length = 200)
	public String getTransMeanNo() {
		return this.transMeanNo;
	}

	public void setTransMeanNo(String transMeanNo) {
		this.transMeanNo = transMeanNo;
	}

	@Column(name = "DESP_PORT_CODE", length = 8)
	public String getDespPortCode() {
		return this.despPortCode;
	}

	public void setDespPortCode(String despPortCode) {
		this.despPortCode = despPortCode;
	}

	@Column(name = "PORT_STOP_CODE", length = 8)
	public String getPortStopCode() {
		return this.portStopCode;
	}

	public void setPortStopCode(String portStopCode) {
		this.portStopCode = portStopCode;
	}

	@Column(name = "ENTY_PORT_CODE", length = 8)
	public String getEntyPortCode() {
		return this.entyPortCode;
	}

	public void setEntyPortCode(String entyPortCode) {
		this.entyPortCode = entyPortCode;
	}

	@Column(name = "GDS_ARVL_DATE", length = 7)
	public Timestamp getGdsArvlDate() {
		return this.gdsArvlDate;
	}

	public void setGdsArvlDate(Timestamp gdsArvlDate) {
		this.gdsArvlDate = gdsArvlDate;
	}

	@Column(name = "CMPL_DSCHRG_DT", length = 7)
	public Timestamp getCmplDschrgDt() {
		return this.cmplDschrgDt;
	}

	public void setCmplDschrgDt(Timestamp cmplDschrgDt) {
		this.cmplDschrgDt = cmplDschrgDt;
	}

	@Column(name = "GOODS_PLACE", nullable = false, length = 100)
	public String getGoodsPlace() {
		return this.goodsPlace;
	}

	public void setGoodsPlace(String goodsPlace) {
		this.goodsPlace = goodsPlace;
	}

	@Column(name = "DEST_CODE", length = 8)
	public String getDestCode() {
		return this.destCode;
	}

	public void setDestCode(String destCode) {
		this.destCode = destCode;
	}

	@Column(name = "COUNTER_CLAIM", length = 7)
	public Timestamp getCounterClaim() {
		return this.counterClaim;
	}

	public void setCounterClaim(Timestamp counterClaim) {
		this.counterClaim = counterClaim;
	}

	@Column(name = "BILL_LAD_NO", length = 50)
	public String getBillLadNo() {
		return this.billLadNo;
	}

	public void setBillLadNo(String billLadNo) {
		this.billLadNo = billLadNo;
	}

	@Column(name = "DELIVERY_ORDER", length = 20)
	public String getDeliveryOrder() {
		return this.deliveryOrder;
	}

	public void setDeliveryOrder(String deliveryOrder) {
		this.deliveryOrder = deliveryOrder;
	}

	@Column(name = "INSP_ORG_CODE", nullable = false, length = 10)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", nullable = false, length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "DECL_CUSTM", length = 10)
	public String getDeclCustm() {
		return this.declCustm;
	}

	public void setDeclCustm(String declCustm) {
		this.declCustm = declCustm;
	}

	@Column(name = "SPEC_DECL_FLAG", length = 10)
	public String getSpecDeclFlag() {
		return this.specDeclFlag;
	}

	public void setSpecDeclFlag(String specDeclFlag) {
		this.specDeclFlag = specDeclFlag;
	}

	@Column(name = "PURP_ORG_CODE", length = 10)
	public String getPurpOrgCode() {
		return this.purpOrgCode;
	}

	public void setPurpOrgCode(String purpOrgCode) {
		this.purpOrgCode = purpOrgCode;
	}

	@Column(name = "CORRELATION_DECL_NO", length = 500)
	public String getCorrelationDeclNo() {
		return this.correlationDeclNo;
	}

	public void setCorrelationDeclNo(String correlationDeclNo) {
		this.correlationDeclNo = correlationDeclNo;
	}

	@Column(name = "CORRELATION_REASON_FLAG", length = 2)
	public String getCorrelationReasonFlag() {
		return this.correlationReasonFlag;
	}

	public void setCorrelationReasonFlag(String correlationReasonFlag) {
		this.correlationReasonFlag = correlationReasonFlag;
	}

	@Column(name = "SPECL_INSP_QURA_RE", length = 500)
	public String getSpeclInspQuraRe() {
		return this.speclInspQuraRe;
	}

	public void setSpeclInspQuraRe(String speclInspQuraRe) {
		this.speclInspQuraRe = speclInspQuraRe;
	}

	@Column(name = "APP_CERT_CODE", length = 50)
	public String getAppCertCode() {
		return this.appCertCode;
	}

	public void setAppCertCode(String appCertCode) {
		this.appCertCode = appCertCode;
	}

	@Column(name = "APPL_ORI", length = 50)
	public String getApplOri() {
		return this.applOri;
	}

	public void setApplOri(String applOri) {
		this.applOri = applOri;
	}

	@Column(name = "APPL_COPY_QUAN", length = 50)
	public String getApplCopyQuan() {
		return this.applCopyQuan;
	}

	public void setApplCopyQuan(String applCopyQuan) {
		this.applCopyQuan = applCopyQuan;
	}

	@Column(name = "CUSTM_REG_NO", length = 10)
	public String getCustmRegNo() {
		return this.custmRegNo;
	}

	public void setCustmRegNo(String custmRegNo) {
		this.custmRegNo = custmRegNo;
	}

	@Column(name = "DECL_PERSN_CERT_NO", length = 10)
	public String getDeclPersnCertNo() {
		return this.declPersnCertNo;
	}

	public void setDeclPersnCertNo(String declPersnCertNo) {
		this.declPersnCertNo = declPersnCertNo;
	}

	@Column(name = "DECL_PERSON_NAME", length = 200)
	public String getDeclPersonName() {
		return this.declPersonName;
	}

	public void setDeclPersonName(String declPersonName) {
		this.declPersonName = declPersonName;
	}

	@Column(name = "DECL_REG_NAME", nullable = false, length = 100)
	public String getDeclRegName() {
		return this.declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	@Column(name = "CONTACTPERSON", nullable = false, length = 20)
	public String getContactperson() {
		return this.contactperson;
	}

	public void setContactperson(String contactperson) {
		this.contactperson = contactperson;
	}

	@Column(name = "CONT_TEL", nullable = false, length = 20)
	public String getContTel() {
		return this.contTel;
	}

	public void setContTel(String contTel) {
		this.contTel = contTel;
	}

	@Column(name = "CONSIGNEE_CODE", length = 20)
	public String getConsigneeCode() {
		return this.consigneeCode;
	}

	public void setConsigneeCode(String consigneeCode) {
		this.consigneeCode = consigneeCode;
	}

	@Column(name = "CONSIGNEE_CNAME", length = 150)
	public String getConsigneeCname() {
		return this.consigneeCname;
	}

	public void setConsigneeCname(String consigneeCname) {
		this.consigneeCname = consigneeCname;
	}

	@Column(name = "CONSIGNEE_ENAME", length = 400)
	public String getConsigneeEname() {
		return this.consigneeEname;
	}

	public void setConsigneeEname(String consigneeEname) {
		this.consigneeEname = consigneeEname;
	}

	@Column(name = "CONSIGNOR_CNAME", length = 150)
	public String getConsignorCname() {
		return this.consignorCname;
	}

	public void setConsignorCname(String consignorCname) {
		this.consignorCname = consignorCname;
	}

	@Column(name = "CONSIGNOR_ADDR", length = 100)
	public String getConsignorAddr() {
		return this.consignorAddr;
	}

	public void setConsignorAddr(String consignorAddr) {
		this.consignorAddr = consignorAddr;
	}

	@Column(name = "DECL_CODE", nullable = false, length = 4)
	public String getDeclCode() {
		return this.declCode;
	}

	public void setDeclCode(String declCode) {
		this.declCode = declCode;
	}

	@Column(name = "DECL_DATE", length = 7)
	public Timestamp getDeclDate() {
		return this.declDate;
	}

	public void setDeclDate(Timestamp declDate) {
		this.declDate = declDate;
	}

	@Column(name = "DECL_GET_NO", length = 20)
	public String getDeclGetNo() {
		return this.declGetNo;
	}

	public void setDeclGetNo(String declGetNo) {
		this.declGetNo = declGetNo;
	}

	@Column(name = "SPEC_PASS_FLAG", length = 5)
	public String getSpecPassFlag() {
		return this.specPassFlag;
	}

	public void setSpecPassFlag(String specPassFlag) {
		this.specPassFlag = specPassFlag;
	}

	@Column(name = "DESP_DATE", length = 7)
	public Timestamp getDespDate() {
		return this.despDate;
	}

	public void setDespDate(Timestamp despDate) {
		this.despDate = despDate;
	}

	@Column(name = "ARRIV_PORT_CODE", length = 8)
	public String getArrivPortCode() {
		return this.arrivPortCode;
	}

	public void setArrivPortCode(String arrivPortCode) {
		this.arrivPortCode = arrivPortCode;
	}

	@Column(name = "CONSIGNEE_ADDR", length = 100)
	public String getConsigneeAddr() {
		return this.consigneeAddr;
	}

	public void setConsigneeAddr(String consigneeAddr) {
		this.consigneeAddr = consigneeAddr;
	}

	@Column(name = "CONSIGNOR_CODE", length = 20)
	public String getConsignorCode() {
		return this.consignorCode;
	}

	public void setConsignorCode(String consignorCode) {
		this.consignorCode = consignorCode;
	}

	@Column(name = "ATTA_COLLECT_NAME", length = 500)
	public String getAttaCollectName() {
		return this.attaCollectName;
	}

	public void setAttaCollectName(String attaCollectName) {
		this.attaCollectName = attaCollectName;
	}

	@Column(name = "IS_LIST_GOOD", length = 1)
	public String getIsListGood() {
		return this.isListGood;
	}

	public void setIsListGood(String isListGood) {
		this.isListGood = isListGood;
	}

	@Column(name = "IS_CONT", length = 1)
	public String getIsCont() {
		return this.isCont;
	}

	public void setIsCont(String isCont) {
		this.isCont = isCont;
	}

	@Column(name = "FFJ_FLAG", length = 1)
	public String getFfjFlag() {
		return this.ffjFlag;
	}

	public void setFfjFlag(String ffjFlag) {
		this.ffjFlag = ffjFlag;
	}

	@Column(name = "FFJ_STATUS", length = 1)
	public String getFfjStatus() {
		return this.ffjStatus;
	}

	public void setFfjStatus(String ffjStatus) {
		this.ffjStatus = ffjStatus;
	}

	@Column(name = "RESEND_NUM", length = 1)
	public String getResendNum() {
		return this.resendNum;
	}

	public void setResendNum(String resendNum) {
		this.resendNum = resendNum;
	}

	@Column(name = "IS_DRAW", length = 1)
	public String getIsDraw() {
		return this.isDraw;
	}

	public void setIsDraw(String isDraw) {
		this.isDraw = isDraw;
	}

	@Column(name = "TOTAL_VAL_US", nullable = false, precision = 0)
	public Double getTotalValUs() {
		return this.totalValUs;
	}

	public void setTotalValUs(Double totalValUs) {
		this.totalValUs = totalValUs;
	}

	@Column(name = "TOTAL_VAL_CN", nullable = false, precision = 0)
	public Double getTotalValCn() {
		return this.totalValCn;
	}

	public void setTotalValCn(Double totalValCn) {
		this.totalValCn = totalValCn;
	}

	@Column(name = "CONT_CANCEL_FLAG", length = 1)
	public String getContCancelFlag() {
		return this.contCancelFlag;
	}

	public void setContCancelFlag(String contCancelFlag) {
		this.contCancelFlag = contCancelFlag;
	}

	@Column(name = "FEE_HANDLE_STATE", length = 4)
	public String getFeeHandleState() {
		return this.feeHandleState;
	}

	public void setFeeHandleState(String feeHandleState) {
		this.feeHandleState = feeHandleState;
	}

	@Column(name = "RELS_STATE", length = 4)
	public String getRelsState() {
		return this.relsState;
	}

	public void setRelsState(String relsState) {
		this.relsState = relsState;
	}

	@Column(name = "FLG_PORT_INLAND", length = 1)
	public String getFlgPortInland() {
		return this.flgPortInland;
	}

	public void setFlgPortInland(String flgPortInland) {
		this.flgPortInland = flgPortInland;
	}

	@Column(name = "ENABLE_TRANS_FLAG", length = 1)
	public String getEnableTransFlag() {
		return this.enableTransFlag;
	}

	public void setEnableTransFlag(String enableTransFlag) {
		this.enableTransFlag = enableTransFlag;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "SITUATION_CODE", length = 8)
	public String getSituationCode() {
		return this.situationCode;
	}

	public void setSituationCode(String situationCode) {
		this.situationCode = situationCode;
	}

	@Column(name = "SITUATION_LEVEL", length = 1)
	public String getSituationLevel() {
		return this.situationLevel;
	}

	public void setSituationLevel(String situationLevel) {
		this.situationLevel = situationLevel;
	}

	@Column(name = "PROCESS_STATUS", length = 10)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "APP_CERT_NAME", length = 500)
	public String getAppCertName() {
		return this.appCertName;
	}

	public void setAppCertName(String appCertName) {
		this.appCertName = appCertName;
	}

	@Column(name = "DECL_REG_NO", nullable = false, length = 20)
	public String getDeclRegNo() {
		return this.declRegNo;
	}

	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}

	@Column(name = "ENT_DECL_NO", length = 40)
	public String getEntDeclNo() {
		return this.entDeclNo;
	}

	public void setEntDeclNo(String entDeclNo) {
		this.entDeclNo = entDeclNo;
	}

	@Column(name = "PROCESS_LINK", length = 4)
	public String getProcessLink() {
		return this.processLink;
	}

	public void setProcessLink(String processLink) {
		this.processLink = processLink;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "CERT_CANCEL_FLAG", length = 1)
	public String getCertCancelFlag() {
		return this.certCancelFlag;
	}

	public void setCertCancelFlag(String certCancelFlag) {
		this.certCancelFlag = certCancelFlag;
	}

	@Column(name = "CONSIGNOR_ENAME", length = 100)
	public String getConsignorEname() {
		return this.consignorEname;
	}

	public void setConsignorEname(String consignorEname) {
		this.consignorEname = consignorEname;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "TRANS_FLAG", length = 10)
	public String getTransFlag() {
		return this.transFlag;
	}

	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}

	@Column(name = "SPLIT_BILL_LAD_NO", length = 200)
	public String getSplitBillLadNo() {
		return this.splitBillLadNo;
	}

	public void setSplitBillLadNo(String splitBillLadNo) {
		this.splitBillLadNo = splitBillLadNo;
	}

	@Column(name = "ENT_UUID", length = 40)
	public String getEntUuid() {
		return this.entUuid;
	}

	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}

	@Column(name = "DECL_TYPE", length = 1)
	public String getDeclType() {
		return this.declType;
	}

	public void setDeclType(String declType) {
		this.declType = declType;
	}

	@Column(name = "ORG_CODE_PATH", length = 2000)
	public String getOrgCodePath() {
		return this.orgCodePath;
	}

	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}

	@Column(name = "DECL_STATUS", length = 1)
	public String getDeclStatus() {
		return this.declStatus;
	}

	public void setDeclStatus(String declStatus) {
		this.declStatus = declStatus;
	}

	@Column(name = "IS_FEE", length = 1)
	public String getIsFee() {
		return this.isFee;
	}

	public void setIsFee(String isFee) {
		this.isFee = isFee;
	}

	@Column(name = "DECL_WORK_NO", length = 20)
	public String getDeclWorkNo() {
		return this.declWorkNo;
	}

	public void setDeclWorkNo(String declWorkNo) {
		this.declWorkNo = declWorkNo;
	}

	@Column(name = "PURP_DEPT_CODE", length = 20)
	public String getPurpDeptCode() {
		return this.purpDeptCode;
	}

	public void setPurpDeptCode(String purpDeptCode) {
		this.purpDeptCode = purpDeptCode;
	}

	@Column(name = "VSA_ORG_CODE", length = 20)
	public String getVsaOrgCode() {
		return this.vsaOrgCode;
	}

	public void setVsaOrgCode(String vsaOrgCode) {
		this.vsaOrgCode = vsaOrgCode;
	}

	@Column(name = "PORT_ORG_CODE", length = 20)
	public String getPortOrgCode() {
		return this.portOrgCode;
	}

	public void setPortOrgCode(String portOrgCode) {
		this.portOrgCode = portOrgCode;
	}

	@Column(name = "PORT_DEPT_CODE", length = 20)
	public String getPortDeptCode() {
		return this.portDeptCode;
	}

	public void setPortDeptCode(String portDeptCode) {
		this.portDeptCode = portDeptCode;
	}

	@Column(name = "INTE_FLAG", length = 1)
	public String getInteFlag() {
		return this.inteFlag;
	}

	public void setInteFlag(String inteFlag) {
		this.inteFlag = inteFlag;
	}

	@Column(name = "BRI_FLAG", length = 1)
	public String getBriFlag() {
		return this.briFlag;
	}

	public void setBriFlag(String briFlag) {
		this.briFlag = briFlag;
	}

	@Column(name = "CHECK_OK_FLAG", length = 1)
	public String getCheckOkFlag() {
		return this.checkOkFlag;
	}

	public void setCheckOkFlag(String checkOkFlag) {
		this.checkOkFlag = checkOkFlag;
	}

	@Column(name = "DIS_CHARGE_FLAG", length = 1)
	public String getDisChargeFlag() {
		return this.disChargeFlag;
	}

	public void setDisChargeFlag(String disChargeFlag) {
		this.disChargeFlag = disChargeFlag;
	}

	@Column(name = "ORIG_BOX_FLAG", length = 1)
	public String getOrigBoxFlag() {
		return this.origBoxFlag;
	}

	public void setOrigBoxFlag(String origBoxFlag) {
		this.origBoxFlag = origBoxFlag;
	}

	@Column(name = "VSA_ORG_CODE_PATH", length = 200)
	public String getVsaOrgCodePath() {
		return this.vsaOrgCodePath;
	}

	public void setVsaOrgCodePath(String vsaOrgCodePath) {
		this.vsaOrgCodePath = vsaOrgCodePath;
	}

	@Column(name = "INSP_ORG_CODE_PATH", length = 200)
	public String getInspOrgCodePath() {
		return this.inspOrgCodePath;
	}

	public void setInspOrgCodePath(String inspOrgCodePath) {
		this.inspOrgCodePath = inspOrgCodePath;
	}

	@Column(name = "PURP_ORG_CODE_PATH", length = 200)
	public String getPurpOrgCodePath() {
		return this.purpOrgCodePath;
	}

	public void setPurpOrgCodePath(String purpOrgCodePath) {
		this.purpOrgCodePath = purpOrgCodePath;
	}

	@Column(name = "PORT_ORG_CODE_PATH", length = 200)
	public String getPortOrgCodePath() {
		return this.portOrgCodePath;
	}

	public void setPortOrgCodePath(String portOrgCodePath) {
		this.portOrgCodePath = portOrgCodePath;
	}

	@Column(name = "ENT_DATE", length = 7)
	public Timestamp getEntDate() {
		return this.entDate;
	}

	public void setEntDate(Timestamp entDate) {
		this.entDate = entDate;
	}

}
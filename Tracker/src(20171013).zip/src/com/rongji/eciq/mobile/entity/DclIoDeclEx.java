package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 * DclIoDeclEx entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_EX")
public class DclIoDeclEx implements java.io.Serializable {

	// Fields

	private String declExId;
	private String declNo;
	private String expImpFlag;
	private String prodBatMode;
	private String entName;
	private String batchCauseCode;
	private String inspRequire;
	private String sanitTreatFlag;
	private String entTypeCode;
	private String relesState;
	private String declTypeCode;
	private String inspState;
	private Date operTime;
	private String falgArchive;
	private String inspFinishFlag;
	private String addInputFlag;
	private String entMgrNo;
	private Date archiveTime;
	private BigDecimal batchNumber;
	private String isLawChkProd;
	private String entUuid;
	private String goodsHsCode;
	private String goodsCiqCode;
	private String goodsName;
	private String dclIoDeclId;
	private String implPassFlag;
	private String implPassCheckFlag;
	private String implPertPass;
	private String filedOrgCode;

	// Constructors

	/** default constructor */
	public DclIoDeclEx() {
	}

	/** minimal constructor */
	public DclIoDeclEx(String declExId, String declNo) {
		this.declExId = declExId;
		this.declNo = declNo;
	}

	/** full constructor */
	public DclIoDeclEx(String declExId, String declNo, String expImpFlag,
			String prodBatMode, String entName, String batchCauseCode,
			String inspRequire, String sanitTreatFlag, String entTypeCode,
			String relesState, String declTypeCode, String inspState,
			Date operTime, String falgArchive, String inspFinishFlag,
			String addInputFlag, String entMgrNo, Date archiveTime,
			BigDecimal batchNumber, String isLawChkProd, String entUuid,
			String goodsHsCode, String goodsCiqCode, String goodsName,
			String dclIoDeclId, String implPassFlag, String implPassCheckFlag,
			String implPertPass, String filedOrgCode) {
		this.declExId = declExId;
		this.declNo = declNo;
		this.expImpFlag = expImpFlag;
		this.prodBatMode = prodBatMode;
		this.entName = entName;
		this.batchCauseCode = batchCauseCode;
		this.inspRequire = inspRequire;
		this.sanitTreatFlag = sanitTreatFlag;
		this.entTypeCode = entTypeCode;
		this.relesState = relesState;
		this.declTypeCode = declTypeCode;
		this.inspState = inspState;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.inspFinishFlag = inspFinishFlag;
		this.addInputFlag = addInputFlag;
		this.entMgrNo = entMgrNo;
		this.archiveTime = archiveTime;
		this.batchNumber = batchNumber;
		this.isLawChkProd = isLawChkProd;
		this.entUuid = entUuid;
		this.goodsHsCode = goodsHsCode;
		this.goodsCiqCode = goodsCiqCode;
		this.goodsName = goodsName;
		this.dclIoDeclId = dclIoDeclId;
		this.implPassFlag = implPassFlag;
		this.implPassCheckFlag = implPassCheckFlag;
		this.implPertPass = implPertPass;
		this.filedOrgCode = filedOrgCode;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_EX_ID", unique = true, nullable = false, length = 32)
	public String getDeclExId() {
		return this.declExId;
	}

	public void setDeclExId(String declExId) {
		this.declExId = declExId;
	}

	@Column(name = "DECL_NO", unique = true, nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "PROD_BAT_MODE", length = 1)
	public String getProdBatMode() {
		return this.prodBatMode;
	}

	public void setProdBatMode(String prodBatMode) {
		this.prodBatMode = prodBatMode;
	}

	@Column(name = "ENT_NAME", length = 100)
	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	@Column(name = "BATCH_CAUSE_CODE", length = 2)
	public String getBatchCauseCode() {
		return this.batchCauseCode;
	}

	public void setBatchCauseCode(String batchCauseCode) {
		this.batchCauseCode = batchCauseCode;
	}

	@Column(name = "INSP_REQUIRE", length = 1)
	public String getInspRequire() {
		return this.inspRequire;
	}

	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}

	@Column(name = "SANIT_TREAT_FLAG", length = 1)
	public String getSanitTreatFlag() {
		return this.sanitTreatFlag;
	}

	public void setSanitTreatFlag(String sanitTreatFlag) {
		this.sanitTreatFlag = sanitTreatFlag;
	}

	@Column(name = "ENT_TYPE_CODE", length = 4)
	public String getEntTypeCode() {
		return this.entTypeCode;
	}

	public void setEntTypeCode(String entTypeCode) {
		this.entTypeCode = entTypeCode;
	}

	@Column(name = "RELES_STATE", length = 1)
	public String getRelesState() {
		return this.relesState;
	}

	public void setRelesState(String relesState) {
		this.relesState = relesState;
	}

	@Column(name = "DECL_TYPE_CODE", length = 1)
	public String getDeclTypeCode() {
		return this.declTypeCode;
	}

	public void setDeclTypeCode(String declTypeCode) {
		this.declTypeCode = declTypeCode;
	}

	@Column(name = "INSP_STATE", length = 1)
	public String getInspState() {
		return this.inspState;
	}

	public void setInspState(String inspState) {
		this.inspState = inspState;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "INSP_FINISH_FLAG", length = 1)
	public String getInspFinishFlag() {
		return this.inspFinishFlag;
	}

	public void setInspFinishFlag(String inspFinishFlag) {
		this.inspFinishFlag = inspFinishFlag;
	}

	@Column(name = "ADD_INPUT_FLAG", length = 1)
	public String getAddInputFlag() {
		return this.addInputFlag;
	}

	public void setAddInputFlag(String addInputFlag) {
		this.addInputFlag = addInputFlag;
	}

	@Column(name = "ENT_MGR_NO", length = 20)
	public String getEntMgrNo() {
		return this.entMgrNo;
	}

	public void setEntMgrNo(String entMgrNo) {
		this.entMgrNo = entMgrNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "BATCH_NUMBER", precision = 22, scale = 0)
	public BigDecimal getBatchNumber() {
		return this.batchNumber;
	}

	public void setBatchNumber(BigDecimal batchNumber) {
		this.batchNumber = batchNumber;
	}

	@Column(name = "IS_LAW_CHK_PROD", length = 1)
	public String getIsLawChkProd() {
		return this.isLawChkProd;
	}

	public void setIsLawChkProd(String isLawChkProd) {
		this.isLawChkProd = isLawChkProd;
	}

	@Column(name = "ENT_UUID", length = 40)
	public String getEntUuid() {
		return this.entUuid;
	}

	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}

	@Column(name = "GOODS_HS_CODE", length = 2000)
	public String getGoodsHsCode() {
		return this.goodsHsCode;
	}

	public void setGoodsHsCode(String goodsHsCode) {
		this.goodsHsCode = goodsHsCode;
	}

	@Column(name = "GOODS_CIQ_CODE", length = 200)
	public String getGoodsCiqCode() {
		return this.goodsCiqCode;
	}

	public void setGoodsCiqCode(String goodsCiqCode) {
		this.goodsCiqCode = goodsCiqCode;
	}

	@Column(name = "GOODS_NAME", length = 4000)
	public String getGoodsName() {
		return this.goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

	@Column(name = "IMPL_PASS_FLAG", length = 1)
	public String getImplPassFlag() {
		return this.implPassFlag;
	}

	public void setImplPassFlag(String implPassFlag) {
		this.implPassFlag = implPassFlag;
	}

	@Column(name = "IMPL_PASS_CHECK_FLAG", length = 1)
	public String getImplPassCheckFlag() {
		return this.implPassCheckFlag;
	}

	public void setImplPassCheckFlag(String implPassCheckFlag) {
		this.implPassCheckFlag = implPassCheckFlag;
	}

	@Column(name = "IMPL_PERT_PASS", length = 1)
	public String getImplPertPass() {
		return this.implPertPass;
	}

	public void setImplPertPass(String implPertPass) {
		this.implPertPass = implPertPass;
	}

	@Column(name = "FILED_ORG_CODE", length = 20)
	public String getFiledOrgCode() {
		return this.filedOrgCode;
	}

	public void setFiledOrgCode(String filedOrgCode) {
		this.filedOrgCode = filedOrgCode;
	}

}
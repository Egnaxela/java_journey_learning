package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclIoDeclGoodsCont entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS_CONT")
public class DclIoDeclGoodsContEntity implements java.io.Serializable {

	private static final long serialVersionUID = 8733139165066959168L;
	private String goodsContId;
	private DclIoDeclGoodsEntity dclIoDeclGoods;
	private String declNo;
	private Double goodsNo;
	private String contCode;
	private String prodHsCode;
	private String transMeansType;
	private String cntnrModeCode;
	private Double qty;
	private String qtyMeasUnit;
	private Double stdMeasUnitQyt;
	private String stdMeasUnit;
	private Timestamp operTime;
	private String falgArchive;
	private Double weight;
	private String wtUnitCode;
	private Timestamp archiveTime;
	private String dclIoDeclId;

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsContEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsContEntity(String goodsContId, String declNo, Double goodsNo) {
		this.goodsContId = goodsContId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
	}

	/** full constructor */
	public DclIoDeclGoodsContEntity(String goodsContId,
			DclIoDeclGoodsEntity dclIoDeclGoods, String declNo, Double goodsNo,
			String contCode, String prodHsCode, String transMeansType,
			String cntnrModeCode, Double qty, String qtyMeasUnit,
			Double stdMeasUnitQyt, String stdMeasUnit, Timestamp operTime,
			String falgArchive, Double weight, String wtUnitCode,
			Timestamp archiveTime, String dclIoDeclId) {
		this.goodsContId = goodsContId;
		this.dclIoDeclGoods = dclIoDeclGoods;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.contCode = contCode;
		this.prodHsCode = prodHsCode;
		this.transMeansType = transMeansType;
		this.cntnrModeCode = cntnrModeCode;
		this.qty = qty;
		this.qtyMeasUnit = qtyMeasUnit;
		this.stdMeasUnitQyt = stdMeasUnitQyt;
		this.stdMeasUnit = stdMeasUnit;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.weight = weight;
		this.wtUnitCode = wtUnitCode;
		this.archiveTime = archiveTime;
		this.dclIoDeclId = dclIoDeclId;
	}

	// Property accessors
	@Id
	@Column(name = "GOODS_CONT_ID", unique = true, nullable = false, length = 32)
	public String getGoodsContId() {
		return this.goodsContId;
	}

	public void setGoodsContId(String goodsContId) {
		this.goodsContId = goodsContId;
	}

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "GOODS_ID")
//	public DclIoDeclGoodsEntity getDclIoDeclGoods() {
//		return this.dclIoDeclGoods;
//	}
//
//	public void setDclIoDeclGoods(DclIoDeclGoodsEntity dclIoDeclGoods) {
//		this.dclIoDeclGoods = dclIoDeclGoods;
//	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "CONT_CODE", length = 4000)
	public String getContCode() {
		return this.contCode;
	}

	public void setContCode(String contCode) {
		this.contCode = contCode;
	}

	@Column(name = "PROD_HS_CODE", length = 12)
	public String getProdHsCode() {
		return this.prodHsCode;
	}

	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}

	@Column(name = "TRANS_MEANS_TYPE", length = 2)
	public String getTransMeansType() {
		return this.transMeansType;
	}

	public void setTransMeansType(String transMeansType) {
		this.transMeansType = transMeansType;
	}

	@Column(name = "CNTNR_MODE_CODE", length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

	@Column(name = "QTY", precision = 0)
	public Double getQty() {
		return this.qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	@Column(name = "QTY_MEAS_UNIT", length = 4)
	public String getQtyMeasUnit() {
		return this.qtyMeasUnit;
	}

	public void setQtyMeasUnit(String qtyMeasUnit) {
		this.qtyMeasUnit = qtyMeasUnit;
	}

	@Column(name = "STD_MEAS_UNIT_QYT", precision = 0)
	public Double getStdMeasUnitQyt() {
		return this.stdMeasUnitQyt;
	}

	public void setStdMeasUnitQyt(Double stdMeasUnitQyt) {
		this.stdMeasUnitQyt = stdMeasUnitQyt;
	}

	@Column(name = "STD_MEAS_UNIT", length = 4)
	public String getStdMeasUnit() {
		return this.stdMeasUnit;
	}

	public void setStdMeasUnit(String stdMeasUnit) {
		this.stdMeasUnit = stdMeasUnit;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "WEIGHT", precision = 0)
	public Double getWeight() {
		return this.weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	@Column(name = "WT_UNIT_CODE", length = 4)
	public String getWtUnitCode() {
		return this.wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

}
package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * DclIoDeclGoods entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS")
public class DclIoDeclGoodsEntity implements java.io.Serializable {

	private static final long serialVersionUID = -4346897978033385325L;
	private String goodsId;
	private String declNo;
	private Double goodsNo;
	private String prodHsCode;
	private String hsCodeDesc;
	private String inspType;
	private String ciqCode;
	private String ciqName;
	private String ciqClassifyCode;
	private String ciqClassifyName;
	private String declGoodsCname;
	private String declGoodsEname;
	private BigDecimal qty;
	private String qtyMeasUnit;
	private Double weight;
	private String wtMeasUnit;
	private BigDecimal stdQty;
	private BigDecimal goodsTotalVal;
	private String currency;
	private Double pricePerUnit;
	private String goodsSpec;
	private String goodsModel;
	private String goodsBrand;
	private String oriCtryCode;
	private String origPlaceCode;
	private String purpose;
	private String produceDate;
	private String prodBatchNo;
	private Timestamp prodValidDt;
	private Double prodQgp;
	private String goodsAttr;
	private String stuff;
	private String unCode;
	private String dangName;
	private String packType;
	private String packSpec;
	private String custmSpvCond;
	private String prodTagPic;
	private String isListGoods;
	private String cabinNo;
	private String wagonNo;
	private Double totalValUs;
	private Double totalValCn;
	private String mnufctrRegNo;
	private String by1;
	private String by2;
	private Timestamp operTime;
	private String falgArchive;
	private String engManEntCnm;
	private String situationCode;
	private String situationLevel;
	private String stdQtyUnitCode;
	private Double stdWeight;
	private String stdWeightUnitCode;
	private Double rate;
	private String mnufctrRegName;
	private Timestamp archiveTime;
	private String noDangFlag;
	private String by3;
	private String by4;
	private String inspPatternCode;
	private String wtDetModeCode;
	private String wtDetWorkMode;
	private String dclIoDeclId;
	private String goodsCheckReq;
	private Set<DclIoDeclGoodsWoodEntity> dclIoDeclGoodsWoods = new HashSet<DclIoDeclGoodsWoodEntity>(
			0);
	private Set<DclIoDeclGoodsContEntity> dclIoDeclGoodsConts = new HashSet<DclIoDeclGoodsContEntity>(
			0);
	private Set<DclIoDeclGoodsPackEntity> dclIoDeclGoodsPacks = new HashSet<DclIoDeclGoodsPackEntity>(
			0);
	private Set<DclIoDeclGoodsLimitEntity> dclIoDeclGoodsLimits = new HashSet<DclIoDeclGoodsLimitEntity>(
			0);

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsEntity(String goodsId, String declNo, Double goodsNo,
			String prodHsCode, String ciqCode, String ciqClassifyCode,
			String declGoodsCname, String purpose) {
		this.goodsId = goodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.prodHsCode = prodHsCode;
		this.ciqCode = ciqCode;
		this.ciqClassifyCode = ciqClassifyCode;
		this.declGoodsCname = declGoodsCname;
		this.purpose = purpose;
	}

	/** full constructor */
	public DclIoDeclGoodsEntity(String goodsId, String declNo, Double goodsNo,
			String prodHsCode, String hsCodeDesc, String inspType,
			String ciqCode, String ciqName, String ciqClassifyCode,
			String ciqClassifyName, String declGoodsCname,
			String declGoodsEname, BigDecimal qty, String qtyMeasUnit,
			Double weight, String wtMeasUnit, BigDecimal stdQty,
			BigDecimal goodsTotalVal, String currency, Double pricePerUnit,
			String goodsSpec, String goodsModel, String goodsBrand,
			String oriCtryCode, String origPlaceCode, String purpose,
			String produceDate, String prodBatchNo, Timestamp prodValidDt,
			Double prodQgp, String goodsAttr, String stuff, String unCode,
			String dangName, String packType, String packSpec,
			String custmSpvCond, String prodTagPic, String isListGoods,
			String cabinNo, String wagonNo, Double totalValUs,
			Double totalValCn, String mnufctrRegNo, String by1, String by2,
			Timestamp operTime, String falgArchive, String engManEntCnm,
			String situationCode, String situationLevel, String stdQtyUnitCode,
			Double stdWeight, String stdWeightUnitCode, Double rate,
			String mnufctrRegName, Timestamp archiveTime, String noDangFlag,
			String by3, String by4, String inspPatternCode,
			String wtDetModeCode, String wtDetWorkMode, String dclIoDeclId,
			String goodsCheckReq, Set<DclIoDeclGoodsWoodEntity> dclIoDeclGoodsWoods,
			Set<DclIoDeclGoodsContEntity> dclIoDeclGoodsConts,
			Set<DclIoDeclGoodsPackEntity> dclIoDeclGoodsPacks,
			Set<DclIoDeclGoodsLimitEntity> dclIoDeclGoodsLimits) {
		this.goodsId = goodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.prodHsCode = prodHsCode;
		this.hsCodeDesc = hsCodeDesc;
		this.inspType = inspType;
		this.ciqCode = ciqCode;
		this.ciqName = ciqName;
		this.ciqClassifyCode = ciqClassifyCode;
		this.ciqClassifyName = ciqClassifyName;
		this.declGoodsCname = declGoodsCname;
		this.declGoodsEname = declGoodsEname;
		this.qty = qty;
		this.qtyMeasUnit = qtyMeasUnit;
		this.weight = weight;
		this.wtMeasUnit = wtMeasUnit;
		this.stdQty = stdQty;
		this.goodsTotalVal = goodsTotalVal;
		this.currency = currency;
		this.pricePerUnit = pricePerUnit;
		this.goodsSpec = goodsSpec;
		this.goodsModel = goodsModel;
		this.goodsBrand = goodsBrand;
		this.oriCtryCode = oriCtryCode;
		this.origPlaceCode = origPlaceCode;
		this.purpose = purpose;
		this.produceDate = produceDate;
		this.prodBatchNo = prodBatchNo;
		this.prodValidDt = prodValidDt;
		this.prodQgp = prodQgp;
		this.goodsAttr = goodsAttr;
		this.stuff = stuff;
		this.unCode = unCode;
		this.dangName = dangName;
		this.packType = packType;
		this.packSpec = packSpec;
		this.custmSpvCond = custmSpvCond;
		this.prodTagPic = prodTagPic;
		this.isListGoods = isListGoods;
		this.cabinNo = cabinNo;
		this.wagonNo = wagonNo;
		this.totalValUs = totalValUs;
		this.totalValCn = totalValCn;
		this.mnufctrRegNo = mnufctrRegNo;
		this.by1 = by1;
		this.by2 = by2;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.engManEntCnm = engManEntCnm;
		this.situationCode = situationCode;
		this.situationLevel = situationLevel;
		this.stdQtyUnitCode = stdQtyUnitCode;
		this.stdWeight = stdWeight;
		this.stdWeightUnitCode = stdWeightUnitCode;
		this.rate = rate;
		this.mnufctrRegName = mnufctrRegName;
		this.archiveTime = archiveTime;
		this.noDangFlag = noDangFlag;
		this.by3 = by3;
		this.by4 = by4;
		this.inspPatternCode = inspPatternCode;
		this.wtDetModeCode = wtDetModeCode;
		this.wtDetWorkMode = wtDetWorkMode;
		this.dclIoDeclId = dclIoDeclId;
		this.goodsCheckReq = goodsCheckReq;
		this.dclIoDeclGoodsWoods = dclIoDeclGoodsWoods;
		this.dclIoDeclGoodsConts = dclIoDeclGoodsConts;
		this.dclIoDeclGoodsPacks = dclIoDeclGoodsPacks;
		this.dclIoDeclGoodsLimits = dclIoDeclGoodsLimits;
	}

	// Property accessors
	@Id
	@Column(name = "GOODS_ID", unique = true, nullable = false, length = 32)
	public String getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PROD_HS_CODE", nullable = false, length = 12)
	public String getProdHsCode() {
		return this.prodHsCode;
	}

	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}

	@Column(name = "HS_CODE_DESC", length = 500)
	public String getHsCodeDesc() {
		return this.hsCodeDesc;
	}

	public void setHsCodeDesc(String hsCodeDesc) {
		this.hsCodeDesc = hsCodeDesc;
	}

	@Column(name = "INSP_TYPE", length = 20)
	public String getInspType() {
		return this.inspType;
	}

	public void setInspType(String inspType) {
		this.inspType = inspType;
	}

	@Column(name = "CIQ_CODE", nullable = false, length = 20)
	public String getCiqCode() {
		return this.ciqCode;
	}

	public void setCiqCode(String ciqCode) {
		this.ciqCode = ciqCode;
	}

	@Column(name = "CIQ_NAME", length = 50)
	public String getCiqName() {
		return this.ciqName;
	}

	public void setCiqName(String ciqName) {
		this.ciqName = ciqName;
	}

	@Column(name = "CIQ_CLASSIFY_CODE", nullable = false, length = 20)
	public String getCiqClassifyCode() {
		return this.ciqClassifyCode;
	}

	public void setCiqClassifyCode(String ciqClassifyCode) {
		this.ciqClassifyCode = ciqClassifyCode;
	}

	@Column(name = "CIQ_CLASSIFY_NAME", length = 100)
	public String getCiqClassifyName() {
		return this.ciqClassifyName;
	}

	public void setCiqClassifyName(String ciqClassifyName) {
		this.ciqClassifyName = ciqClassifyName;
	}

	@Column(name = "DECL_GOODS_CNAME", nullable = false, length = 300)
	public String getDeclGoodsCname() {
		return this.declGoodsCname;
	}

	public void setDeclGoodsCname(String declGoodsCname) {
		this.declGoodsCname = declGoodsCname;
	}

	@Column(name = "DECL_GOODS_ENAME", length = 100)
	public String getDeclGoodsEname() {
		return this.declGoodsEname;
	}

	public void setDeclGoodsEname(String declGoodsEname) {
		this.declGoodsEname = declGoodsEname;
	}

	@Column(name = "QTY", precision = 0)
	public BigDecimal getQty() {
		return this.qty;
	}

	public void setQty(BigDecimal qty) {
		this.qty = qty;
	}

	@Column(name = "QTY_MEAS_UNIT", length = 4)
	public String getQtyMeasUnit() {
		return this.qtyMeasUnit;
	}

	public void setQtyMeasUnit(String qtyMeasUnit) {
		this.qtyMeasUnit = qtyMeasUnit;
	}

	@Column(name = "WEIGHT", precision = 0)
	public Double getWeight() {
		return this.weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	@Column(name = "WT_MEAS_UNIT", length = 4)
	public String getWtMeasUnit() {
		return this.wtMeasUnit;
	}

	public void setWtMeasUnit(String wtMeasUnit) {
		this.wtMeasUnit = wtMeasUnit;
	}

	@Column(name = "STD_QTY", precision = 0)
	public BigDecimal getStdQty() {
		return this.stdQty;
	}

	public void setStdQty(BigDecimal stdQty) {
		this.stdQty = stdQty;
	}

	@Column(name = "GOODS_TOTAL_VAL", precision = 0)
	public BigDecimal getGoodsTotalVal() {
		return this.goodsTotalVal;
	}

	public void setGoodsTotalVal(BigDecimal goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}

	@Column(name = "CURRENCY", length = 4)
	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@Column(name = "PRICE_PER_UNIT", precision = 0)
	public Double getPricePerUnit() {
		return this.pricePerUnit;
	}

	public void setPricePerUnit(Double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	@Column(name = "GOODS_SPEC", length = 100)
	public String getGoodsSpec() {
		return this.goodsSpec;
	}

	public void setGoodsSpec(String goodsSpec) {
		this.goodsSpec = goodsSpec;
	}

	@Column(name = "GOODS_MODEL", length = 100)
	public String getGoodsModel() {
		return this.goodsModel;
	}

	public void setGoodsModel(String goodsModel) {
		this.goodsModel = goodsModel;
	}

	@Column(name = "GOODS_BRAND", length = 100)
	public String getGoodsBrand() {
		return this.goodsBrand;
	}

	public void setGoodsBrand(String goodsBrand) {
		this.goodsBrand = goodsBrand;
	}

	@Column(name = "ORI_CTRY_CODE", length = 10)
	public String getOriCtryCode() {
		return this.oriCtryCode;
	}

	public void setOriCtryCode(String oriCtryCode) {
		this.oriCtryCode = oriCtryCode;
	}

	@Column(name = "ORIG_PLACE_CODE", length = 50)
	public String getOrigPlaceCode() {
		return this.origPlaceCode;
	}

	public void setOrigPlaceCode(String origPlaceCode) {
		this.origPlaceCode = origPlaceCode;
	}

	@Column(name = "PURPOSE", nullable = false, length = 4)
	public String getPurpose() {
		return this.purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	@Column(name = "PRODUCE_DATE", length = 2000)
	public String getProduceDate() {
		return this.produceDate;
	}

	public void setProduceDate(String produceDate) {
		this.produceDate = produceDate;
	}

	@Column(name = "PROD_BATCH_NO", length = 2000)
	public String getProdBatchNo() {
		return this.prodBatchNo;
	}

	public void setProdBatchNo(String prodBatchNo) {
		this.prodBatchNo = prodBatchNo;
	}

	@Column(name = "PROD_VALID_DT", length = 7)
	public Timestamp getProdValidDt() {
		return this.prodValidDt;
	}

	public void setProdValidDt(Timestamp prodValidDt) {
		this.prodValidDt = prodValidDt;
	}

	@Column(name = "PROD_QGP", precision = 0)
	public Double getProdQgp() {
		return this.prodQgp;
	}

	public void setProdQgp(Double prodQgp) {
		this.prodQgp = prodQgp;
	}

	@Column(name = "GOODS_ATTR", length = 100)
	public String getGoodsAttr() {
		return this.goodsAttr;
	}

	public void setGoodsAttr(String goodsAttr) {
		this.goodsAttr = goodsAttr;
	}

	@Column(name = "STUFF", length = 400)
	public String getStuff() {
		return this.stuff;
	}

	public void setStuff(String stuff) {
		this.stuff = stuff;
	}

	@Column(name = "UN_CODE", length = 20)
	public String getUnCode() {
		return this.unCode;
	}

	public void setUnCode(String unCode) {
		this.unCode = unCode;
	}

	@Column(name = "DANG_NAME", length = 80)
	public String getDangName() {
		return this.dangName;
	}

	public void setDangName(String dangName) {
		this.dangName = dangName;
	}

	@Column(name = "PACK_TYPE", length = 4)
	public String getPackType() {
		return this.packType;
	}

	public void setPackType(String packType) {
		this.packType = packType;
	}

	@Column(name = "PACK_SPEC", length = 24)
	public String getPackSpec() {
		return this.packSpec;
	}

	public void setPackSpec(String packSpec) {
		this.packSpec = packSpec;
	}

	@Column(name = "CUSTM_SPV_COND", length = 10)
	public String getCustmSpvCond() {
		return this.custmSpvCond;
	}

	public void setCustmSpvCond(String custmSpvCond) {
		this.custmSpvCond = custmSpvCond;
	}

	@Column(name = "PROD_TAG_PIC", length = 400)
	public String getProdTagPic() {
		return this.prodTagPic;
	}

	public void setProdTagPic(String prodTagPic) {
		this.prodTagPic = prodTagPic;
	}

	@Column(name = "IS_LIST_GOODS", length = 1)
	public String getIsListGoods() {
		return this.isListGoods;
	}

	public void setIsListGoods(String isListGoods) {
		this.isListGoods = isListGoods;
	}

	@Column(name = "CABIN_NO", length = 100)
	public String getCabinNo() {
		return this.cabinNo;
	}

	public void setCabinNo(String cabinNo) {
		this.cabinNo = cabinNo;
	}

	@Column(name = "WAGON_NO", length = 100)
	public String getWagonNo() {
		return this.wagonNo;
	}

	public void setWagonNo(String wagonNo) {
		this.wagonNo = wagonNo;
	}

	@Column(name = "TOTAL_VAL_US", precision = 0)
	public Double getTotalValUs() {
		return this.totalValUs;
	}

	public void setTotalValUs(Double totalValUs) {
		this.totalValUs = totalValUs;
	}

	@Column(name = "TOTAL_VAL_CN", precision = 0)
	public Double getTotalValCn() {
		return this.totalValCn;
	}

	public void setTotalValCn(Double totalValCn) {
		this.totalValCn = totalValCn;
	}

	@Column(name = "MNUFCTR_REG_NO", length = 20)
	public String getMnufctrRegNo() {
		return this.mnufctrRegNo;
	}

	public void setMnufctrRegNo(String mnufctrRegNo) {
		this.mnufctrRegNo = mnufctrRegNo;
	}

	@Column(name = "BY1", length = 500)
	public String getBy1() {
		return this.by1;
	}

	public void setBy1(String by1) {
		this.by1 = by1;
	}

	@Column(name = "BY2", length = 500)
	public String getBy2() {
		return this.by2;
	}

	public void setBy2(String by2) {
		this.by2 = by2;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ENG_MAN_ENT_CNM", length = 100)
	public String getEngManEntCnm() {
		return this.engManEntCnm;
	}

	public void setEngManEntCnm(String engManEntCnm) {
		this.engManEntCnm = engManEntCnm;
	}

	@Column(name = "SITUATION_CODE", length = 200)
	public String getSituationCode() {
		return this.situationCode;
	}

	public void setSituationCode(String situationCode) {
		this.situationCode = situationCode;
	}

	@Column(name = "SITUATION_LEVEL", length = 20)
	public String getSituationLevel() {
		return this.situationLevel;
	}

	public void setSituationLevel(String situationLevel) {
		this.situationLevel = situationLevel;
	}

	@Column(name = "STD_QTY_UNIT_CODE", length = 4)
	public String getStdQtyUnitCode() {
		return this.stdQtyUnitCode;
	}

	public void setStdQtyUnitCode(String stdQtyUnitCode) {
		this.stdQtyUnitCode = stdQtyUnitCode;
	}

	@Column(name = "STD_WEIGHT", precision = 0)
	public Double getStdWeight() {
		return this.stdWeight;
	}

	public void setStdWeight(Double stdWeight) {
		this.stdWeight = stdWeight;
	}

	@Column(name = "STD_WEIGHT_UNIT_CODE", length = 4)
	public String getStdWeightUnitCode() {
		return this.stdWeightUnitCode;
	}

	public void setStdWeightUnitCode(String stdWeightUnitCode) {
		this.stdWeightUnitCode = stdWeightUnitCode;
	}

	@Column(name = "RATE", precision = 0)
	public Double getRate() {
		return this.rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	@Column(name = "MNUFCTR_REG_NAME", length = 150)
	public String getMnufctrRegName() {
		return this.mnufctrRegName;
	}

	public void setMnufctrRegName(String mnufctrRegName) {
		this.mnufctrRegName = mnufctrRegName;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "NO_DANG_FLAG", length = 1)
	public String getNoDangFlag() {
		return this.noDangFlag;
	}

	public void setNoDangFlag(String noDangFlag) {
		this.noDangFlag = noDangFlag;
	}

	@Column(name = "BY3", length = 500)
	public String getBy3() {
		return this.by3;
	}

	public void setBy3(String by3) {
		this.by3 = by3;
	}

	@Column(name = "BY4", length = 500)
	public String getBy4() {
		return this.by4;
	}

	public void setBy4(String by4) {
		this.by4 = by4;
	}

	@Column(name = "INSP_PATTERN_CODE", length = 4)
	public String getInspPatternCode() {
		return this.inspPatternCode;
	}

	public void setInspPatternCode(String inspPatternCode) {
		this.inspPatternCode = inspPatternCode;
	}

	@Column(name = "WT_DET_MODE_CODE", length = 4)
	public String getWtDetModeCode() {
		return this.wtDetModeCode;
	}

	public void setWtDetModeCode(String wtDetModeCode) {
		this.wtDetModeCode = wtDetModeCode;
	}

	@Column(name = "WT_DET_WORK_MODE", length = 1)
	public String getWtDetWorkMode() {
		return this.wtDetWorkMode;
	}

	public void setWtDetWorkMode(String wtDetWorkMode) {
		this.wtDetWorkMode = wtDetWorkMode;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

	@Column(name = "GOODS_CHECK_REQ", length = 200)
	public String getGoodsCheckReq() {
		return this.goodsCheckReq;
	}

	public void setGoodsCheckReq(String goodsCheckReq) {
		this.goodsCheckReq = goodsCheckReq;
	}

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclIoDeclGoods")
//	public Set<DclIoDeclGoodsWoodEntity> getDclIoDeclGoodsWoods() {
//		return this.dclIoDeclGoodsWoods;
//	}
//
//	public void setDclIoDeclGoodsWoods(
//			Set<DclIoDeclGoodsWoodEntity> dclIoDeclGoodsWoods) {
//		this.dclIoDeclGoodsWoods = dclIoDeclGoodsWoods;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclIoDeclGoods")
//	public Set<DclIoDeclGoodsContEntity> getDclIoDeclGoodsConts() {
//		return this.dclIoDeclGoodsConts;
//	}
//
//	public void setDclIoDeclGoodsConts(
//			Set<DclIoDeclGoodsContEntity> dclIoDeclGoodsConts) {
//		this.dclIoDeclGoodsConts = dclIoDeclGoodsConts;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclIoDeclGoods")
//	public Set<DclIoDeclGoodsPackEntity> getDclIoDeclGoodsPacks() {
//		return this.dclIoDeclGoodsPacks;
//	}
//
//	public void setDclIoDeclGoodsPacks(
//			Set<DclIoDeclGoodsPackEntity> dclIoDeclGoodsPacks) {
//		this.dclIoDeclGoodsPacks = dclIoDeclGoodsPacks;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclIoDeclGoods")
//	public Set<DclIoDeclGoodsLimitEntity> getDclIoDeclGoodsLimits() {
//		return this.dclIoDeclGoodsLimits;
//	}
//
//	public void setDclIoDeclGoodsLimits(
//			Set<DclIoDeclGoodsLimitEntity> dclIoDeclGoodsLimits) {
//		this.dclIoDeclGoodsLimits = dclIoDeclGoodsLimits;
//	}

}
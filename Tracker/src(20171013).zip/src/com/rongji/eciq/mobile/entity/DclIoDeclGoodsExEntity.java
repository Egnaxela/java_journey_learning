package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DclIoDeclGoodsEx entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS_EX")
public class DclIoDeclGoodsExEntity implements java.io.Serializable {

	private static final long serialVersionUID = 2517601602674055732L;
	private String declGoodsId;
	private String goodsId;
	private String inspRequire;
	private String riskEvalCode;
	private Double batchRatio;
	private String isExamsym;
	private String entName;
	private String evalResultAuto;
	private String evalResultMan;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private String declNo;
	private Double goodsNo;
	private String newGoodsFlag;
	private String dclIoDeclId;

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsExEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsExEntity(String declGoodsId, String goodsId) {
		this.declGoodsId = declGoodsId;
		this.goodsId = goodsId;
	}

	/** full constructor */
	public DclIoDeclGoodsExEntity(String declGoodsId, String goodsId,
			String inspRequire, String riskEvalCode, Double batchRatio,
			String isExamsym, String entName, String evalResultAuto,
			String evalResultMan, Timestamp operTime, String falgArchive,
			Timestamp archiveTime, String declNo, Double goodsNo,
			String newGoodsFlag, String dclIoDeclId) {
		this.declGoodsId = declGoodsId;
		this.goodsId = goodsId;
		this.inspRequire = inspRequire;
		this.riskEvalCode = riskEvalCode;
		this.batchRatio = batchRatio;
		this.isExamsym = isExamsym;
		this.entName = entName;
		this.evalResultAuto = evalResultAuto;
		this.evalResultMan = evalResultMan;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.newGoodsFlag = newGoodsFlag;
		this.dclIoDeclId = dclIoDeclId;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_GOODS_ID", unique = true, nullable = false, length = 32)
	public String getDeclGoodsId() {
		return this.declGoodsId;
	}

	public void setDeclGoodsId(String declGoodsId) {
		this.declGoodsId = declGoodsId;
	}

	@Column(name = "GOODS_ID", nullable = false, length = 32)
	public String getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "INSP_REQUIRE", length = 1)
	public String getInspRequire() {
		return this.inspRequire;
	}

	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}

	@Column(name = "RISK_EVAL_CODE", length = 10)
	public String getRiskEvalCode() {
		return this.riskEvalCode;
	}

	public void setRiskEvalCode(String riskEvalCode) {
		this.riskEvalCode = riskEvalCode;
	}

	@Column(name = "BATCH_RATIO", precision = 0)
	public Double getBatchRatio() {
		return this.batchRatio;
	}

	public void setBatchRatio(Double batchRatio) {
		this.batchRatio = batchRatio;
	}

	@Column(name = "IS_EXAMSYM", length = 1)
	public String getIsExamsym() {
		return this.isExamsym;
	}

	public void setIsExamsym(String isExamsym) {
		this.isExamsym = isExamsym;
	}

	@Column(name = "ENT_NAME", length = 100)
	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	@Column(name = "EVAL_RESULT_AUTO", length = 1)
	public String getEvalResultAuto() {
		return this.evalResultAuto;
	}

	public void setEvalResultAuto(String evalResultAuto) {
		this.evalResultAuto = evalResultAuto;
	}

	@Column(name = "EVAL_RESULT_MAN", length = 1)
	public String getEvalResultMan() {
		return this.evalResultMan;
	}

	public void setEvalResultMan(String evalResultMan) {
		this.evalResultMan = evalResultMan;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "NEW_GOODS_FLAG", length = 1)
	public String getNewGoodsFlag() {
		return this.newGoodsFlag;
	}

	public void setNewGoodsFlag(String newGoodsFlag) {
		this.newGoodsFlag = newGoodsFlag;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

}
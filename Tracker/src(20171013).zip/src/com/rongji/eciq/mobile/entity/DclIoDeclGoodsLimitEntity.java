package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclIoDeclGoodsLimit entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS_LIMIT")
public class DclIoDeclGoodsLimitEntity implements java.io.Serializable {

	private static final long serialVersionUID = 3198935309236463752L;
	private String limitId;
	private DclIoDeclGoodsEntity dclIoDeclGoods;
	private String declNo;
	private Double goodsNo;
	private String licTypeCode;
	private String licenceNo;
	private String licName;
	private String licWrtofDetailNo;
	private String licWrtofQty;
	private Double licDetailLeft;
	private Double licWrtofLeft;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private String dclIoDeclId;
	private String vinCode;

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsLimitEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsLimitEntity(String limitId, String declNo, Double goodsNo,
			String licTypeCode, String licenceNo) {
		this.limitId = limitId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.licTypeCode = licTypeCode;
		this.licenceNo = licenceNo;
	}

	/** full constructor */
	public DclIoDeclGoodsLimitEntity(String limitId, DclIoDeclGoodsEntity dclIoDeclGoods,
			String declNo, Double goodsNo, String licTypeCode,
			String licenceNo, String licName, String licWrtofDetailNo,
			String licWrtofQty, Double licDetailLeft, Double licWrtofLeft,
			Timestamp operTime, String falgArchive, Timestamp archiveTime,
			String dclIoDeclId, String vinCode) {
		this.limitId = limitId;
		this.dclIoDeclGoods = dclIoDeclGoods;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.licTypeCode = licTypeCode;
		this.licenceNo = licenceNo;
		this.licName = licName;
		this.licWrtofDetailNo = licWrtofDetailNo;
		this.licWrtofQty = licWrtofQty;
		this.licDetailLeft = licDetailLeft;
		this.licWrtofLeft = licWrtofLeft;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.dclIoDeclId = dclIoDeclId;
		this.vinCode = vinCode;
	}

	// Property accessors
	@Id
	@Column(name = "LIMIT_ID", unique = true, nullable = false, length = 32)
	public String getLimitId() {
		return this.limitId;
	}

	public void setLimitId(String limitId) {
		this.limitId = limitId;
	}

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "GOODS_ID")
//	public DclIoDeclGoodsEntity getDclIoDeclGoods() {
//		return this.dclIoDeclGoods;
//	}
//
//	public void setDclIoDeclGoods(DclIoDeclGoodsEntity dclIoDeclGoods) {
//		this.dclIoDeclGoods = dclIoDeclGoods;
//	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "LIC_TYPE_CODE", nullable = false, length = 5)
	public String getLicTypeCode() {
		return this.licTypeCode;
	}

	public void setLicTypeCode(String licTypeCode) {
		this.licTypeCode = licTypeCode;
	}

	@Column(name = "LICENCE_NO", nullable = false, length = 40)
	public String getLicenceNo() {
		return this.licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	@Column(name = "LIC_NAME", length = 100)
	public String getLicName() {
		return this.licName;
	}

	public void setLicName(String licName) {
		this.licName = licName;
	}

	@Column(name = "LIC_WRTOF_DETAIL_NO", length = 4)
	public String getLicWrtofDetailNo() {
		return this.licWrtofDetailNo;
	}

	public void setLicWrtofDetailNo(String licWrtofDetailNo) {
		this.licWrtofDetailNo = licWrtofDetailNo;
	}

	@Column(name = "LIC_WRTOF_QTY", length = 20)
	public String getLicWrtofQty() {
		return this.licWrtofQty;
	}

	public void setLicWrtofQty(String licWrtofQty) {
		this.licWrtofQty = licWrtofQty;
	}

	@Column(name = "LIC_DETAIL_LEFT", precision = 0)
	public Double getLicDetailLeft() {
		return this.licDetailLeft;
	}

	public void setLicDetailLeft(Double licDetailLeft) {
		this.licDetailLeft = licDetailLeft;
	}

	@Column(name = "LIC_WRTOF_LEFT", precision = 0)
	public Double getLicWrtofLeft() {
		return this.licWrtofLeft;
	}

	public void setLicWrtofLeft(Double licWrtofLeft) {
		this.licWrtofLeft = licWrtofLeft;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

	@Column(name = "VIN_CODE", length = 20)
	public String getVinCode() {
		return this.vinCode;
	}

	public void setVinCode(String vinCode) {
		this.vinCode = vinCode;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclIoDeclGoodsPack entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS_PACK")
public class DclIoDeclGoodsPackEntity implements java.io.Serializable {

	private static final long serialVersionUID = -8405209257459708378L;
	private String packId;
	private DclIoDeclGoodsEntity dclIoDeclGoods;
	private String declNo;
	private Double goodsNo;
	private Double packLenth;
	private Double packHigh;
	private Double packWide;
	private String packTypeCode;
	private String packCatgName;
	private String packTypeShort;
	private Double packQty;
	private String isMainPack;
	private String matType;
	private String procFactory;
	private Timestamp operTime;
	private String falgArchive;
	private String mattingCode;
	private Timestamp archiveTime;
	private String dclIoDeclId;

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsPackEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsPackEntity(String packId) {
		this.packId = packId;
	}

	/** full constructor */
	public DclIoDeclGoodsPackEntity(String packId, DclIoDeclGoodsEntity dclIoDeclGoods,
			String declNo, Double goodsNo, Double packLenth, Double packHigh,
			Double packWide, String packTypeCode, String packCatgName,
			String packTypeShort, Double packQty, String isMainPack,
			String matType, String procFactory, Timestamp operTime,
			String falgArchive, String mattingCode, Timestamp archiveTime,
			String dclIoDeclId) {
		this.packId = packId;
		this.dclIoDeclGoods = dclIoDeclGoods;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.packLenth = packLenth;
		this.packHigh = packHigh;
		this.packWide = packWide;
		this.packTypeCode = packTypeCode;
		this.packCatgName = packCatgName;
		this.packTypeShort = packTypeShort;
		this.packQty = packQty;
		this.isMainPack = isMainPack;
		this.matType = matType;
		this.procFactory = procFactory;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.mattingCode = mattingCode;
		this.archiveTime = archiveTime;
		this.dclIoDeclId = dclIoDeclId;
	}

	// Property accessors
	@Id
	@Column(name = "PACK_ID", unique = true, nullable = false, length = 32)
	public String getPackId() {
		return this.packId;
	}

	public void setPackId(String packId) {
		this.packId = packId;
	}

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "GOODS_ID")
//	public DclIoDeclGoodsEntity getDclIoDeclGoods() {
//		return this.dclIoDeclGoods;
//	}
//
//	public void setDclIoDeclGoods(DclIoDeclGoodsEntity dclIoDeclGoods) {
//		this.dclIoDeclGoods = dclIoDeclGoods;
//	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PACK_LENTH", precision = 0)
	public Double getPackLenth() {
		return this.packLenth;
	}

	public void setPackLenth(Double packLenth) {
		this.packLenth = packLenth;
	}

	@Column(name = "PACK_HIGH", precision = 0)
	public Double getPackHigh() {
		return this.packHigh;
	}

	public void setPackHigh(Double packHigh) {
		this.packHigh = packHigh;
	}

	@Column(name = "PACK_WIDE", precision = 0)
	public Double getPackWide() {
		return this.packWide;
	}

	public void setPackWide(Double packWide) {
		this.packWide = packWide;
	}

	@Column(name = "PACK_TYPE_CODE", length = 4)
	public String getPackTypeCode() {
		return this.packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	@Column(name = "PACK_CATG_NAME", length = 100)
	public String getPackCatgName() {
		return this.packCatgName;
	}

	public void setPackCatgName(String packCatgName) {
		this.packCatgName = packCatgName;
	}

	@Column(name = "PACK_TYPE_SHORT", length = 50)
	public String getPackTypeShort() {
		return this.packTypeShort;
	}

	public void setPackTypeShort(String packTypeShort) {
		this.packTypeShort = packTypeShort;
	}

	@Column(name = "PACK_QTY", precision = 0)
	public Double getPackQty() {
		return this.packQty;
	}

	public void setPackQty(Double packQty) {
		this.packQty = packQty;
	}

	@Column(name = "IS_MAIN_PACK", length = 1)
	public String getIsMainPack() {
		return this.isMainPack;
	}

	public void setIsMainPack(String isMainPack) {
		this.isMainPack = isMainPack;
	}

	@Column(name = "MAT_TYPE", length = 20)
	public String getMatType() {
		return this.matType;
	}

	public void setMatType(String matType) {
		this.matType = matType;
	}

	@Column(name = "PROC_FACTORY", length = 50)
	public String getProcFactory() {
		return this.procFactory;
	}

	public void setProcFactory(String procFactory) {
		this.procFactory = procFactory;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "MATTING_CODE", length = 4)
	public String getMattingCode() {
		return this.mattingCode;
	}

	public void setMattingCode(String mattingCode) {
		this.mattingCode = mattingCode;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

}
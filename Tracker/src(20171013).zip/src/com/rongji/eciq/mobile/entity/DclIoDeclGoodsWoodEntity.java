package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclIoDeclGoodsWood entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_IO_DECL_GOODS_WOOD")
public class DclIoDeclGoodsWoodEntity implements java.io.Serializable {

	private static final long serialVersionUID = 812946952582057567L;
	private String woodId;
	private DclIoDeclGoodsEntity dclIoDeclGoods;
	private String declNo;
	private Double goodsNo;
	private String packTypeCode;
	private String packCatgName;
	private Double packQty;
	private String originCode;
	private String ctryOriginCode;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private String dclIoDeclId;

	// Constructors

	/** default constructor */
	public DclIoDeclGoodsWoodEntity() {
	}

	/** minimal constructor */
	public DclIoDeclGoodsWoodEntity(String woodId, String declNo, Double goodsNo,
			String packTypeCode) {
		this.woodId = woodId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.packTypeCode = packTypeCode;
	}

	/** full constructor */
	public DclIoDeclGoodsWoodEntity(String woodId, DclIoDeclGoodsEntity dclIoDeclGoods,
			String declNo, Double goodsNo, String packTypeCode,
			String packCatgName, Double packQty, String originCode,
			String ctryOriginCode, Timestamp operTime, String falgArchive,
			Timestamp archiveTime, String dclIoDeclId) {
		this.woodId = woodId;
		this.dclIoDeclGoods = dclIoDeclGoods;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.packTypeCode = packTypeCode;
		this.packCatgName = packCatgName;
		this.packQty = packQty;
		this.originCode = originCode;
		this.ctryOriginCode = ctryOriginCode;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.dclIoDeclId = dclIoDeclId;
	}

	// Property accessors
	@Id
	@Column(name = "WOOD_ID", unique = true, nullable = false, length = 32)
	public String getWoodId() {
		return this.woodId;
	}

	public void setWoodId(String woodId) {
		this.woodId = woodId;
	}

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "GOODS_ID")
//	public DclIoDeclGoodsEntity getDclIoDeclGoods() {
//		return this.dclIoDeclGoods;
//	}
//
//	public void setDclIoDeclGoods(DclIoDeclGoodsEntity dclIoDeclGoods) {
//		this.dclIoDeclGoods = dclIoDeclGoods;
//	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PACK_TYPE_CODE", nullable = false, length = 4)
	public String getPackTypeCode() {
		return this.packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	@Column(name = "PACK_CATG_NAME", length = 100)
	public String getPackCatgName() {
		return this.packCatgName;
	}

	public void setPackCatgName(String packCatgName) {
		this.packCatgName = packCatgName;
	}

	@Column(name = "PACK_QTY", precision = 0)
	public Double getPackQty() {
		return this.packQty;
	}

	public void setPackQty(Double packQty) {
		this.packQty = packQty;
	}

	@Column(name = "ORIGIN_CODE", length = 50)
	public String getOriginCode() {
		return this.originCode;
	}

	public void setOriginCode(String originCode) {
		this.originCode = originCode;
	}

	@Column(name = "CTRY_ORIGIN_CODE", length = 4)
	public String getCtryOriginCode() {
		return this.ctryOriginCode;
	}

	public void setCtryOriginCode(String ctryOriginCode) {
		this.ctryOriginCode = ctryOriginCode;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "DCL_IO_DECL_ID", length = 32)
	public String getDclIoDeclId() {
		return this.dclIoDeclId;
	}

	public void setDclIoDeclId(String dclIoDeclId) {
		this.dclIoDeclId = dclIoDeclId;
	}

}
package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "DCL_ORD_BACK_DETAIL")
public class DclOrdBackDetailEntity implements java.io.Serializable {

	// Fields

	private String ordBackInfoNo;
	private String backType;
	private String declNo;
	private String backMainNo;
	private String orderNo;
	private String backCauseDesc;
	private Date operTime;
	private String falgArchive;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public DclOrdBackDetailEntity() {
	}

	/** minimal constructor */
	public DclOrdBackDetailEntity(String ordBackInfoNo,
		 String backType, String declNo) {
		this.ordBackInfoNo = ordBackInfoNo;
		this.backType = backType;
		this.declNo = declNo;
	}

	/** full constructor */
	public DclOrdBackDetailEntity(String ordBackInfoNo,
			String backType, String declNo, String backCauseDesc,
			Date operTime, String falgArchive, Date archiveTime) {
		this.ordBackInfoNo = ordBackInfoNo;
		this.backType = backType;
		this.declNo = declNo;
		this.backCauseDesc = backCauseDesc;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "ORD_BACK_INFO_NO", unique = true, nullable = false, length = 32)
	public String getOrdBackInfoNo() {
		return this.ordBackInfoNo;
	}

	public void setOrdBackInfoNo(String ordBackInfoNo) {
		this.ordBackInfoNo = ordBackInfoNo;
	}

	@Column(name = "BACK_TYPE", nullable = false, length = 2)
	public String getBackType() {
		return this.backType;
	}

	public void setBackType(String backType) {
		this.backType = backType;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "BACK_CAUSE_DESC", length = 4000)
	public String getBackCauseDesc() {
		return this.backCauseDesc;
	}

	public void setBackCauseDesc(String backCauseDesc) {
		this.backCauseDesc = backCauseDesc;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	@Column(name = "BACK_MAIN_NO", length = 32)
	public String getBackMainNo() {
		return backMainNo;
	}

	public void setBackMainNo(String backMainNo) {
		this.backMainNo = backMainNo;
	}
	@Column(name = "ORDER_NO", length = 32)
	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	@Override
	public String toString() {
		return "DclOrdBackDetailEntity [ordBackInfoNo=" + ordBackInfoNo
				+ ", backType=" + backType + ", declNo=" + declNo
				+ ", backCauseDesc=" + backCauseDesc + ", operTime=" + operTime
				+ ", falgArchive=" + falgArchive + ", archiveTime="
				+ archiveTime + "]";
	}

}
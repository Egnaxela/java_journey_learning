package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Column;
@Entity
@Table(name = "DCL_ORD_BACK_MAIN")
public class DclOrdBackMainEntity implements java.io.Serializable {

	// Fields

	private String backMainNo;
	private String ordBackInfoNo;
	private String declNo;
	private BigDecimal backSn;
	private String backApp;
	private String backLink;
	private String backOrg;
	private String backPerson;
	private Date backDate;
	private String suplement;
	private String treatFlag;
	private Date operTime;
	private String falgArchive;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public DclOrdBackMainEntity() {
	}

	/** minimal constructor */
	public DclOrdBackMainEntity(String backMainNo, String declNo,
			String backOrg, String backPerson, Date backDate) {
		this.backMainNo = backMainNo;
		this.declNo = declNo;
		this.backOrg = backOrg;
		this.backPerson = backPerson;
		this.backDate = backDate;
	}

	/** full constructor */
	public DclOrdBackMainEntity(String backMainNo, String ordBackInfoNo,
			String declNo, BigDecimal backSn, String backApp, String backLink,
			String backOrg, String backPerson, Date backDate, String suplement,
			String treatFlag, Date operTime, String falgArchive) {
		this.backMainNo = backMainNo;
		this.ordBackInfoNo = ordBackInfoNo;
		this.declNo = declNo;
		this.backSn = backSn;
		this.backApp = backApp;
		this.backLink = backLink;
		this.backOrg = backOrg;
		this.backPerson = backPerson;
		this.backDate = backDate;
		this.suplement = suplement;
		this.treatFlag = treatFlag;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "BACK_MAIN_NO", unique = true, nullable = false, length = 32)
	public String getBackMainNo() {
		return this.backMainNo;
	}

	public void setBackMainNo(String backMainNo) {
		this.backMainNo = backMainNo;
	}

	@Column(name = "ORD_BACK_INFO_NO", length = 32)
	public String getOrdBackInfoNo() {
		return this.ordBackInfoNo;
	}

	public void setOrdBackInfoNo(String ordBackInfoNo) {
		this.ordBackInfoNo = ordBackInfoNo;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "BACK_SN", precision = 22, scale = 0)
	public BigDecimal getBackSn() {
		return this.backSn;
	}

	public void setBackSn(BigDecimal backSn) {
		this.backSn = backSn;
	}

	@Column(name = "BACK_APP", length = 8)
	public String getBackApp() {
		return this.backApp;
	}

	public void setBackApp(String backApp) {
		this.backApp = backApp;
	}

	@Column(name = "BACK_LINK", length = 8)
	public String getBackLink() {
		return this.backLink;
	}

	public void setBackLink(String backLink) {
		this.backLink = backLink;
	}

	@Column(name = "BACK_ORG", nullable = false, length = 6)
	public String getBackOrg() {
		return this.backOrg;
	}

	public void setBackOrg(String backOrg) {
		this.backOrg = backOrg;
	}

	@Column(name = "BACK_PERSON", nullable = false, length = 20)
	public String getBackPerson() {
		return this.backPerson;
	}

	public void setBackPerson(String backPerson) {
		this.backPerson = backPerson;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "BACK_DATE", nullable = false, length = 7)
	public Date getBackDate() {
		return this.backDate;
	}

	public void setBackDate(Date backDate) {
		this.backDate = backDate;
	}

	@Column(name = "SUPLEMENT", length = 4000)
	public String getSuplement() {
		return this.suplement;
	}

	public void setSuplement(String suplement) {
		this.suplement = suplement;
	}

	@Column(name = "TREAT_FLAG", length = 2)
	public String getTreatFlag() {
		return this.treatFlag;
	}

	public void setTreatFlag(String treatFlag) {
		this.treatFlag = treatFlag;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

}

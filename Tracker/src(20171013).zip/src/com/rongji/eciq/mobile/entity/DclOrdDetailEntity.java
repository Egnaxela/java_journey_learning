package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DCL_ORD_DETAIL")
public class DclOrdDetailEntity implements java.io.Serializable{
	private static final long serialVersionUID = 1L;
	private String orderNo;
	private String declNo;
	private String censType;
	private String execLevel;
	private String concType;
	private String conclusionNo;
	private String conclusionName;
	private String concDesc;
	private String censOrg;
	private String censPerson;
	private String arriveApp;
	private String arrivLink;
	private Date sendTime;
	private String sendType;
	private String operType;
	private String addLink;
	private Date operTime;
	private String falgArchive;
	private Date archiveTime;
	private String uri;
	private String enabled;
	private String ruleId;
	
	public DclOrdDetailEntity() {
	}

	/** minimal constructor */
	public DclOrdDetailEntity(String orderNo, String declNo, String censType,
			String execLevel, String concType, String conclusionNo,
			String conclusionName) {
		this.orderNo = orderNo;
		this.declNo = declNo;
		this.censType = censType;
		this.execLevel = execLevel;
		this.concType = concType;
		this.conclusionNo = conclusionNo;
		this.conclusionName = conclusionName;
	}

	/** full constructor */
	public DclOrdDetailEntity(String orderNo, 
			String declNo, String censType, String execLevel, String concType,
			String conclusionNo, String conclusionName, String concDesc,
			String censOrg, String censPerson, String arriveApp,
			String arrivLink, Date sendTime, String sendType, String operType,
			String addLink, Date operTime, String falgArchive,
			Date archiveTime, String uri, String enabled, String ruleId) {
		this.orderNo = orderNo;
		this.declNo = declNo;
		this.censType = censType;
		this.execLevel = execLevel;
		this.concType = concType;
		this.conclusionNo = conclusionNo;
		this.conclusionName = conclusionName;
		this.concDesc = concDesc;
		this.censOrg = censOrg;
		this.censPerson = censPerson;
		this.arriveApp = arriveApp;
		this.arrivLink = arrivLink;
		this.sendTime = sendTime;
		this.sendType = sendType;
		this.operType = operType;
		this.addLink = addLink;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.uri = uri;
		this.enabled = enabled;
		this.ruleId = ruleId;
	}
	
	@Id
	@Column(name="ORDER_NO", unique = true, nullable = false,length=32 )
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	@Column(name = "DECL_NO",length= 20)
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	@Column(name = "CENS_TYPE",length= 4)
	public String getCensType() {
		return censType;
	}
	public void setCensType(String censType) {
		this.censType = censType;
	}
	@Column(name = "EXEC_LEVEL",length= 2)
	public String getExecLevel() {
		return execLevel;
	}
	public void setExecLevel(String execLevel) {
		this.execLevel = execLevel;
	}
	@Column(name = "CONC_TYPE",length= 32)
	public String getConcType() {
		return concType;
	}
	public void setConcType(String concType) {
		this.concType = concType;
	}
	@Column(name = "CONCLUSION_NO",length= 32)
	public String getConclusionNo() {
		return conclusionNo;
	}
	public void setConclusionNo(String conclusionNo) {
		this.conclusionNo = conclusionNo;
	}
	@Column(name = "CONCLUSION_NAME",length= 100)
	public String getConclusionName() {
		return conclusionName;
	}
	
	public void setConclusionName(String conclusionName) {
		this.conclusionName = conclusionName;
	}
	@Column(name = "CONC_DESC",length= 4000)
	public String getConcDesc() {
		return concDesc;
	}
	public void setConcDesc(String concDesc) {
		this.concDesc = concDesc;
	}
	@Column(name = "CENS_ORG",length= 10)
	public String getCensOrg() {
		return censOrg;
	}
	public void setCensOrg(String censOrg) {
		this.censOrg = censOrg;
	}
	@Column(name = "CENS_PERSON",length= 50)
	public String getCensPerson() {
		return censPerson;
	}
	public void setCensPerson(String censPerson) {
		this.censPerson = censPerson;
	}
	
	@Column(name = "ARRIVE_APP",length= 8)
	public String getArriveApp() {
		return arriveApp;
	}
	public void setArriveApp(String arriveApp) {
		this.arriveApp = arriveApp;
	}
	@Column(name = "ARRIV_LINK",length= 8)
	public String getArrivLink() {
		return arrivLink;
	}
	public void setArrivLink(String arrivLink) {
		this.arrivLink = arrivLink;
	}
	@Column(name = "SEND_TIME",length= 7)
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	@Column(name = "SEND_TYPE",length= 2)
	public String getSendType() {
		return sendType;
	}
	public void setSendType(String sendType) {
		this.sendType = sendType;
	}
	 @Column(name = "OPER_TYPE",length= 2)
	public String getOperType() {
		return operType;
	}
	public void setOperType(String operType) {
		this.operType = operType;
	}
	@Column(name = "ADD_LINK",length= 8)
	public String getAddLink() {
		return addLink;
	}
	public void setAddLink(String addLink) {
		this.addLink = addLink;
	}
	@Column(name = "OPER_TIME",length= 7)
	public Date getOperTime() {
		return operTime;
	}
	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	@Column(name = "FALG_ARCHIVE", length= 1)
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	@Column(name = "ARCHIVE_TIME",length= 7)
	public Date getArchiveTime() {
		return archiveTime;
	}
	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	@Column(name = "URI", nullable = false,length= 500)
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	@Column(name = "ENABLED", nullable = false,length= 1)
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	@Column(name = "RULE_ID", nullable = false,length= 32)
	public String getRuleId() {
		return ruleId;
	}
	
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	
	
	
	
	

}

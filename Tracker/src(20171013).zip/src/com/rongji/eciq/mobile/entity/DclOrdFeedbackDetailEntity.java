package com.rongji.eciq.mobile.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DCL_ORD_FEEDBACK_DETAIL")
public class DclOrdFeedbackDetailEntity implements Serializable {

	// Fields

	private String ordFeedbackInfoNo;
	private String orderNo;
	private String declNo;
	private String execRslt;
	private String unquReason;
	private String execRsltDesc;
	private Date operTime;
	private String falgArchive;
	private Date archiveTime;
	private String feedbackMainNo;

	// Constructors

	/** default constructor */
	public DclOrdFeedbackDetailEntity() {
	}

	/** minimal constructor */
	public DclOrdFeedbackDetailEntity(String ordFeedbackInfoNo) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
	}

	/** full constructor */
	public DclOrdFeedbackDetailEntity(String ordFeedbackInfoNo, String orderNo, String declNo, String execRslt,
			String unquReason, String execRsltDesc, Date operTime, String falgArchive, Date archiveTime) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
		this.orderNo = orderNo;
		this.declNo = declNo;
		this.execRslt = execRslt;
		this.unquReason = unquReason;
		this.execRsltDesc = execRsltDesc;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "ORD_FEEDBACK_INFO_NO", unique = true, nullable = false, length = 32)
	public String getOrdFeedbackInfoNo() {
		return this.ordFeedbackInfoNo;
	}

	public void setOrdFeedbackInfoNo(String ordFeedbackInfoNo) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
	}

	@Column(name = "ORDER_NO", length = 32)
	public String getOrderNo() {
		return this.orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "EXEC_RSLT", length = 4)
	public String getExecRslt() {
		return this.execRslt;
	}

	public void setExecRslt(String execRslt) {
		this.execRslt = execRslt;
	}

	@Column(name = "UNQU_REASON", length = 200)
	public String getUnquReason() {
		return this.unquReason;
	}

	public void setUnquReason(String unquReason) {
		this.unquReason = unquReason;
	}

	@Column(name = "EXEC_RSLT_DESC", length = 4000)
	public String getExecRsltDesc() {
		return this.execRsltDesc;
	}

	public void setExecRsltDesc(String execRsltDesc) {
		this.execRsltDesc = execRsltDesc;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "FEEDBACK_MAIN_NO", length = 32)
	public String getFeedbackMainNo() {
		return feedbackMainNo;
	}

	public void setFeedbackMainNo(String feedbackMainNo) {
		this.feedbackMainNo = feedbackMainNo;
	}

	@Override
	public String toString() {
		return "DclOrdFeedbackDetailEntity [ordFeedbackInfoNo="
				+ ordFeedbackInfoNo + ", orderNo=" + orderNo + ", declNo="
				+ declNo + ", execRslt=" + execRslt + ", unquReason="
				+ unquReason + ", execRsltDesc=" + execRsltDesc + ", operTime="
				+ operTime + ", falgArchive=" + falgArchive + ", archiveTime="
				+ archiveTime + ", feedbackMainNo=" + feedbackMainNo + "]";
	}

	
}

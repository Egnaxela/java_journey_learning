package com.rongji.eciq.mobile.entity;

import java.io.Serializable;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "DCL_ORD_FEEDBACK_MAIN")
public class DclOrdFeedbackMainEntity implements Serializable {
	private static final long serialVersionUID = -8099848911297727975L;
	// Fields

	private String feedbackMainNo;
	private String declNo;
	private Date feedbackTime;
	private String feedbackOrg;
	private String feedbackApp;
	private String feedbackLink;
	private String feedbackDept;
	private String fedbackPersn;
	private String assessStatus;
	private String suplement;
	private Date operTime;
	private String falgArchive;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public DclOrdFeedbackMainEntity() {
	}

	/** minimal constructor */
	public DclOrdFeedbackMainEntity(String feedbackMainNo, Date feedbackTime,
			String feedbackOrg, String fedbackPersn) {
		this.feedbackMainNo = feedbackMainNo;
		this.feedbackTime = feedbackTime;
		this.feedbackOrg = feedbackOrg;
		this.fedbackPersn = fedbackPersn;
	}

	/** full constructor */
	public DclOrdFeedbackMainEntity(String feedbackMainNo, String declNo,
			Date feedbackTime, String feedbackOrg, String feedbackApp,
			String feedbackLink, String feedbackDept, String fedbackPersn,
			String assessStatus, String suplement, Date operTime,
			String falgArchive, Date archiveTime) {
		this.feedbackMainNo = feedbackMainNo;
		this.declNo = declNo;
		this.feedbackTime = feedbackTime;
		this.feedbackOrg = feedbackOrg;
		this.feedbackApp = feedbackApp;
		this.feedbackLink = feedbackLink;
		this.feedbackDept = feedbackDept;
		this.fedbackPersn = fedbackPersn;
		this.assessStatus = assessStatus;
		this.suplement = suplement;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "FEEDBACK_MAIN_NO", unique = true, nullable = false, length = 32)
	public String getFeedbackMainNo() {
		return this.feedbackMainNo;
	}

	public void setFeedbackMainNo(String feedbackMainNo) {
		this.feedbackMainNo = feedbackMainNo;
	}
	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	@Column(name = "FEEDBACK_TIME" )
	public Date getFeedbackTime() {
		return this.feedbackTime;
	}

	public void setFeedbackTime(Date feedbackTime) {
		this.feedbackTime = feedbackTime;
	}
	@Column(name = "FEEDBACK_ORG", length = 6)
	public String getFeedbackOrg() {
		return this.feedbackOrg;
	}

	public void setFeedbackOrg(String feedbackOrg) {
		this.feedbackOrg = feedbackOrg;
	}
	@Column(name = "FEEDBACK_APP", length = 8)
	public String getFeedbackApp() {
		return this.feedbackApp;
	}

	public void setFeedbackApp(String feedbackApp) {
		this.feedbackApp = feedbackApp;
	}
	@Column(name = "FEEDBACK_LINK", length = 8)
	public String getFeedbackLink() {
		return this.feedbackLink;
	}

	public void setFeedbackLink(String feedbackLink) {
		this.feedbackLink = feedbackLink;
	}
	@Column(name = "FEEDBACK_DEPT", length = 50)
	public String getFeedbackDept() {
		return this.feedbackDept;
	}

	public void setFeedbackDept(String feedbackDept) {
		this.feedbackDept = feedbackDept;
	}
	@Column(name = "FEDBACK_PERSN", length = 50)
	public String getFedbackPersn() {
		return this.fedbackPersn;
	}

	public void setFedbackPersn(String fedbackPersn) {
		this.fedbackPersn = fedbackPersn;
	}
	@Column(name = "ASSESS_STATUS", length = 1)
	public String getAssessStatus() {
		return this.assessStatus;
	}

	public void setAssessStatus(String assessStatus) {
		this.assessStatus = assessStatus;
	}
	@Column(name = "SUPLEMENT", length = 4000)
	public String getSuplement() {
		return this.suplement;
	}

	public void setSuplement(String suplement) {
		this.suplement = suplement;
	}
	@Column(name = "OPER_TIME" )
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	@Column(name = "ARCHIVE_TIME" )
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Override
	public String toString() {
		return "DclOrdFeedbackMainEntity [feedbackMainNo=" + feedbackMainNo
				+ ", declNo=" + declNo + ", feedbackTime=" + feedbackTime
				+ ", feedbackOrg=" + feedbackOrg + ", feedbackApp="
				+ feedbackApp + ", feedbackLink=" + feedbackLink
				+ ", feedbackDept=" + feedbackDept + ", fedbackPersn="
				+ fedbackPersn + ", assessStatus=" + assessStatus
				+ ", suplement=" + suplement + ", operTime=" + operTime
				+ ", falgArchive=" + falgArchive + ", archiveTime="
				+ archiveTime + "]";
	}



}

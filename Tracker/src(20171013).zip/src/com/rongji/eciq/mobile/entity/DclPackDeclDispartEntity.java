package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclPackDeclDispart entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_PACK_DECL_DISPART")
public class DclPackDeclDispartEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 5292284159235502947L;
	private String dispartId;
	private DclPackDeclEntity dclPackDecl;
	private Double dispartNo;
	private String certDivideCode;
	private String certDvidEntName;
	private Double disptCertQty;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;

	// Constructors

	/** default constructor */
	public DclPackDeclDispartEntity() {
	}

	/** minimal constructor */
	public DclPackDeclDispartEntity(String dispartId, DclPackDeclEntity dclPackDecl,
			Double dispartNo) {
		this.dispartId = dispartId;
		this.dclPackDecl = dclPackDecl;
		this.dispartNo = dispartNo;
	}

	/** full constructor */
	public DclPackDeclDispartEntity(String dispartId, DclPackDeclEntity dclPackDecl,
			Double dispartNo, String certDivideCode, String certDvidEntName,
			Double disptCertQty, Timestamp operTime, String falgArchive,
			Timestamp archiveTime) {
		this.dispartId = dispartId;
		this.dclPackDecl = dclPackDecl;
		this.dispartNo = dispartNo;
		this.certDivideCode = certDivideCode;
		this.certDvidEntName = certDvidEntName;
		this.disptCertQty = disptCertQty;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "DISPART_ID", unique = true, nullable = false, length = 32)
	public String getDispartId() {
		return this.dispartId;
	}

	public void setDispartId(String dispartId) {
		this.dispartId = dispartId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DECL_NO", nullable = false)
	public DclPackDeclEntity getDclPackDecl() {
		return this.dclPackDecl;
	}

	public void setDclPackDecl(DclPackDeclEntity dclPackDecl) {
		this.dclPackDecl = dclPackDecl;
	}

	@Column(name = "DISPART_NO", nullable = false, precision = 0)
	public Double getDispartNo() {
		return this.dispartNo;
	}

	public void setDispartNo(Double dispartNo) {
		this.dispartNo = dispartNo;
	}

	@Column(name = "CERT_DIVIDE_CODE", length = 10)
	public String getCertDivideCode() {
		return this.certDivideCode;
	}

	public void setCertDivideCode(String certDivideCode) {
		this.certDivideCode = certDivideCode;
	}

	@Column(name = "CERT_DVID_ENT_NAME", length = 50)
	public String getCertDvidEntName() {
		return this.certDvidEntName;
	}

	public void setCertDvidEntName(String certDvidEntName) {
		this.certDvidEntName = certDvidEntName;
	}

	@Column(name = "DISPT_CERT_QTY", precision = 0)
	public Double getDisptCertQty() {
		return this.disptCertQty;
	}

	public void setDisptCertQty(Double disptCertQty) {
		this.disptCertQty = disptCertQty;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

}
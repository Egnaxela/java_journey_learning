package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * DclPackDecl entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_PACK_DECL")
public class DclPackDeclEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 2775197074508087851L;
	private String declNo;
	private String declRegName;
	private String appliInspName;
	private Timestamp declDate;
	private String packUseUnitCode;
	private String packUseUnitName;
	private String packFactoryCode;
	private String pkgMnufctrName;
	private String packContainerCode;
	private String pkgCntnrName;
	private String pkgCntnrSpec;
	private String rawMatName;
	private String matOrigCode;
	private String packLicenseCode;
	private String declCode;
	private Double qty;
	private Timestamp produceDate;
	private String packDgSpecCode;
	private String packPlaceCode;
	private String pkgStorePlace;
	private String checkupResuCodes;
	private String transType;
	private String loadGdsName;
	private String goodsShapeCode;
	private Double preldGdsDensity;
	private Double goodsWeight;
	private Double goodsValuesRmb;
	private String inerPkgCtnrName;
	private String inerPackContSpf;
	private String interMatrialMeth;
	private String shippingPortCode;
	private Timestamp shippingDate;
	private String codeCountry;
	private String containerLastName;
	private String sheetTypeCodes;
	private String inspOrgCode;
	private String excInspDeptCode;
	private String feeHandleState;
	private String declGetNo;
	private String packContainerNo;
	private String packMarkNo;
	private String orgCode;
	private String deptCode;
	private String disptCertFlag;
	private String specFlag;
	private String entDeclNo;
	private String declUnitContact;
	private String declUnitTel;
	private String specialRequire;
	private String resendNum;
	private String changeInspDeptFlag;
	private String processStatus;
	private Timestamp operTime;
	private String falgArchive;
	private String declRegNo;
	private String declareCode;
	private String wtUnitCode;
	private String processLink;
	private String prodTech;
	private String testRptNo;
	private Timestamp archiveTime;
	private String transFlag;
	private String entUuid;
	private String declType;
	private String orgCodePath;
	private String declStatus;
	private String isFee;
	private String declWorkNo;
	private Timestamp entDate;
	private Set<DclPackDeclModelEntity> dclPackDeclModels = new HashSet<DclPackDeclModelEntity>(
			0);
	private Set<DclPackDeclDispartEntity> dclPackDeclDisparts = new HashSet<DclPackDeclDispartEntity>(
			0);

	// Constructors

	/** default constructor */
	public DclPackDeclEntity() {
	}

	/** minimal constructor */
	public DclPackDeclEntity(String declNo, String resendNum,
			String changeInspDeptFlag) {
		this.declNo = declNo;
		this.resendNum = resendNum;
		this.changeInspDeptFlag = changeInspDeptFlag;
	}

	/** full constructor */
	public DclPackDeclEntity(String declNo, String declRegName, String appliInspName,
			Timestamp declDate, String packUseUnitCode, String packUseUnitName,
			String packFactoryCode, String pkgMnufctrName,
			String packContainerCode, String pkgCntnrName, String pkgCntnrSpec,
			String rawMatName, String matOrigCode, String packLicenseCode,
			String declCode, Double qty, Timestamp produceDate,
			String packDgSpecCode, String packPlaceCode, String pkgStorePlace,
			String checkupResuCodes, String transType, String loadGdsName,
			String goodsShapeCode, Double preldGdsDensity, Double goodsWeight,
			Double goodsValuesRmb, String inerPkgCtnrName,
			String inerPackContSpf, String interMatrialMeth,
			String shippingPortCode, Timestamp shippingDate,
			String codeCountry, String containerLastName,
			String sheetTypeCodes, String inspOrgCode, String excInspDeptCode,
			String feeHandleState, String declGetNo, String packContainerNo,
			String packMarkNo, String orgCode, String deptCode,
			String disptCertFlag, String specFlag, String entDeclNo,
			String declUnitContact, String declUnitTel, String specialRequire,
			String resendNum, String changeInspDeptFlag, String processStatus,
			Timestamp operTime, String falgArchive, String declRegNo,
			String declareCode, String wtUnitCode, String processLink,
			String prodTech, String testRptNo, Timestamp archiveTime,
			String transFlag, String entUuid, String declType,
			String orgCodePath, String declStatus, String isFee,
			String declWorkNo, Timestamp entDate,
			Set<DclPackDeclModelEntity> dclPackDeclModels,
			Set<DclPackDeclDispartEntity> dclPackDeclDisparts) {
		this.declNo = declNo;
		this.declRegName = declRegName;
		this.appliInspName = appliInspName;
		this.declDate = declDate;
		this.packUseUnitCode = packUseUnitCode;
		this.packUseUnitName = packUseUnitName;
		this.packFactoryCode = packFactoryCode;
		this.pkgMnufctrName = pkgMnufctrName;
		this.packContainerCode = packContainerCode;
		this.pkgCntnrName = pkgCntnrName;
		this.pkgCntnrSpec = pkgCntnrSpec;
		this.rawMatName = rawMatName;
		this.matOrigCode = matOrigCode;
		this.packLicenseCode = packLicenseCode;
		this.declCode = declCode;
		this.qty = qty;
		this.produceDate = produceDate;
		this.packDgSpecCode = packDgSpecCode;
		this.packPlaceCode = packPlaceCode;
		this.pkgStorePlace = pkgStorePlace;
		this.checkupResuCodes = checkupResuCodes;
		this.transType = transType;
		this.loadGdsName = loadGdsName;
		this.goodsShapeCode = goodsShapeCode;
		this.preldGdsDensity = preldGdsDensity;
		this.goodsWeight = goodsWeight;
		this.goodsValuesRmb = goodsValuesRmb;
		this.inerPkgCtnrName = inerPkgCtnrName;
		this.inerPackContSpf = inerPackContSpf;
		this.interMatrialMeth = interMatrialMeth;
		this.shippingPortCode = shippingPortCode;
		this.shippingDate = shippingDate;
		this.codeCountry = codeCountry;
		this.containerLastName = containerLastName;
		this.sheetTypeCodes = sheetTypeCodes;
		this.inspOrgCode = inspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.feeHandleState = feeHandleState;
		this.declGetNo = declGetNo;
		this.packContainerNo = packContainerNo;
		this.packMarkNo = packMarkNo;
		this.orgCode = orgCode;
		this.deptCode = deptCode;
		this.disptCertFlag = disptCertFlag;
		this.specFlag = specFlag;
		this.entDeclNo = entDeclNo;
		this.declUnitContact = declUnitContact;
		this.declUnitTel = declUnitTel;
		this.specialRequire = specialRequire;
		this.resendNum = resendNum;
		this.changeInspDeptFlag = changeInspDeptFlag;
		this.processStatus = processStatus;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.declRegNo = declRegNo;
		this.declareCode = declareCode;
		this.wtUnitCode = wtUnitCode;
		this.processLink = processLink;
		this.prodTech = prodTech;
		this.testRptNo = testRptNo;
		this.archiveTime = archiveTime;
		this.transFlag = transFlag;
		this.entUuid = entUuid;
		this.declType = declType;
		this.orgCodePath = orgCodePath;
		this.declStatus = declStatus;
		this.isFee = isFee;
		this.declWorkNo = declWorkNo;
		this.entDate = entDate;
		this.dclPackDeclModels = dclPackDeclModels;
		this.dclPackDeclDisparts = dclPackDeclDisparts;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_NO", unique = true, nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "DECL_REG_NAME", length = 100)
	public String getDeclRegName() {
		return this.declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	@Column(name = "APPLI_INSP_NAME", length = 200)
	public String getAppliInspName() {
		return this.appliInspName;
	}

	public void setAppliInspName(String appliInspName) {
		this.appliInspName = appliInspName;
	}

	@Column(name = "DECL_DATE", length = 7)
	public Timestamp getDeclDate() {
		return this.declDate;
	}

	public void setDeclDate(Timestamp declDate) {
		this.declDate = declDate;
	}

	@Column(name = "PACK_USE_UNIT_CODE", length = 20)
	public String getPackUseUnitCode() {
		return this.packUseUnitCode;
	}

	public void setPackUseUnitCode(String packUseUnitCode) {
		this.packUseUnitCode = packUseUnitCode;
	}

	@Column(name = "PACK_USE_UNIT_NAME", length = 100)
	public String getPackUseUnitName() {
		return this.packUseUnitName;
	}

	public void setPackUseUnitName(String packUseUnitName) {
		this.packUseUnitName = packUseUnitName;
	}

	@Column(name = "PACK_FACTORY_CODE", length = 20)
	public String getPackFactoryCode() {
		return this.packFactoryCode;
	}

	public void setPackFactoryCode(String packFactoryCode) {
		this.packFactoryCode = packFactoryCode;
	}

	@Column(name = "PKG_MNUFCTR_NAME", length = 100)
	public String getPkgMnufctrName() {
		return this.pkgMnufctrName;
	}

	public void setPkgMnufctrName(String pkgMnufctrName) {
		this.pkgMnufctrName = pkgMnufctrName;
	}

	@Column(name = "PACK_CONTAINER_CODE", length = 4)
	public String getPackContainerCode() {
		return this.packContainerCode;
	}

	public void setPackContainerCode(String packContainerCode) {
		this.packContainerCode = packContainerCode;
	}

	@Column(name = "PKG_CNTNR_NAME", length = 100)
	public String getPkgCntnrName() {
		return this.pkgCntnrName;
	}

	public void setPkgCntnrName(String pkgCntnrName) {
		this.pkgCntnrName = pkgCntnrName;
	}

	@Column(name = "PKG_CNTNR_SPEC", length = 50)
	public String getPkgCntnrSpec() {
		return this.pkgCntnrSpec;
	}

	public void setPkgCntnrSpec(String pkgCntnrSpec) {
		this.pkgCntnrSpec = pkgCntnrSpec;
	}

	@Column(name = "RAW_MAT_NAME", length = 50)
	public String getRawMatName() {
		return this.rawMatName;
	}

	public void setRawMatName(String rawMatName) {
		this.rawMatName = rawMatName;
	}

	@Column(name = "MAT_ORIG_CODE", length = 8)
	public String getMatOrigCode() {
		return this.matOrigCode;
	}

	public void setMatOrigCode(String matOrigCode) {
		this.matOrigCode = matOrigCode;
	}

	@Column(name = "PACK_LICENSE_CODE", length = 20)
	public String getPackLicenseCode() {
		return this.packLicenseCode;
	}

	public void setPackLicenseCode(String packLicenseCode) {
		this.packLicenseCode = packLicenseCode;
	}

	@Column(name = "DECL_CODE", length = 4)
	public String getDeclCode() {
		return this.declCode;
	}

	public void setDeclCode(String declCode) {
		this.declCode = declCode;
	}

	@Column(name = "QTY", precision = 0)
	public Double getQty() {
		return this.qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	@Column(name = "PRODUCE_DATE", length = 7)
	public Timestamp getProduceDate() {
		return this.produceDate;
	}

	public void setProduceDate(Timestamp produceDate) {
		this.produceDate = produceDate;
	}

	@Column(name = "PACK_DG_SPEC_CODE", length = 8)
	public String getPackDgSpecCode() {
		return this.packDgSpecCode;
	}

	public void setPackDgSpecCode(String packDgSpecCode) {
		this.packDgSpecCode = packDgSpecCode;
	}

	@Column(name = "PACK_PLACE_CODE", length = 8)
	public String getPackPlaceCode() {
		return this.packPlaceCode;
	}

	public void setPackPlaceCode(String packPlaceCode) {
		this.packPlaceCode = packPlaceCode;
	}

	@Column(name = "PKG_STORE_PLACE", length = 50)
	public String getPkgStorePlace() {
		return this.pkgStorePlace;
	}

	public void setPkgStorePlace(String pkgStorePlace) {
		this.pkgStorePlace = pkgStorePlace;
	}

	@Column(name = "CHECKUP_RESU_CODES", length = 100)
	public String getCheckupResuCodes() {
		return this.checkupResuCodes;
	}

	public void setCheckupResuCodes(String checkupResuCodes) {
		this.checkupResuCodes = checkupResuCodes;
	}

	@Column(name = "TRANS_TYPE", length = 4)
	public String getTransType() {
		return this.transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	@Column(name = "LOAD_GDS_NAME", length = 50)
	public String getLoadGdsName() {
		return this.loadGdsName;
	}

	public void setLoadGdsName(String loadGdsName) {
		this.loadGdsName = loadGdsName;
	}

	@Column(name = "GOODS_SHAPE_CODE", length = 4)
	public String getGoodsShapeCode() {
		return this.goodsShapeCode;
	}

	public void setGoodsShapeCode(String goodsShapeCode) {
		this.goodsShapeCode = goodsShapeCode;
	}

	@Column(name = "PRELD_GDS_DENSITY", precision = 0)
	public Double getPreldGdsDensity() {
		return this.preldGdsDensity;
	}

	public void setPreldGdsDensity(Double preldGdsDensity) {
		this.preldGdsDensity = preldGdsDensity;
	}

	@Column(name = "GOODS_WEIGHT", precision = 0)
	public Double getGoodsWeight() {
		return this.goodsWeight;
	}

	public void setGoodsWeight(Double goodsWeight) {
		this.goodsWeight = goodsWeight;
	}

	@Column(name = "GOODS_VALUES_RMB", precision = 0)
	public Double getGoodsValuesRmb() {
		return this.goodsValuesRmb;
	}

	public void setGoodsValuesRmb(Double goodsValuesRmb) {
		this.goodsValuesRmb = goodsValuesRmb;
	}

	@Column(name = "INER_PKG_CTNR_NAME", length = 50)
	public String getInerPkgCtnrName() {
		return this.inerPkgCtnrName;
	}

	public void setInerPkgCtnrName(String inerPkgCtnrName) {
		this.inerPkgCtnrName = inerPkgCtnrName;
	}

	@Column(name = "INER_PACK_CONT_SPF", length = 50)
	public String getInerPackContSpf() {
		return this.inerPackContSpf;
	}

	public void setInerPackContSpf(String inerPackContSpf) {
		this.inerPackContSpf = inerPackContSpf;
	}

	@Column(name = "INTER_MATRIAL_METH", length = 100)
	public String getInterMatrialMeth() {
		return this.interMatrialMeth;
	}

	public void setInterMatrialMeth(String interMatrialMeth) {
		this.interMatrialMeth = interMatrialMeth;
	}

	@Column(name = "SHIPPING_PORT_CODE", length = 8)
	public String getShippingPortCode() {
		return this.shippingPortCode;
	}

	public void setShippingPortCode(String shippingPortCode) {
		this.shippingPortCode = shippingPortCode;
	}

	@Column(name = "SHIPPING_DATE", length = 7)
	public Timestamp getShippingDate() {
		return this.shippingDate;
	}

	public void setShippingDate(Timestamp shippingDate) {
		this.shippingDate = shippingDate;
	}

	@Column(name = "CODE_COUNTRY", length = 8)
	public String getCodeCountry() {
		return this.codeCountry;
	}

	public void setCodeCountry(String codeCountry) {
		this.codeCountry = codeCountry;
	}

	@Column(name = "CONTAINER_LAST_NAME", length = 50)
	public String getContainerLastName() {
		return this.containerLastName;
	}

	public void setContainerLastName(String containerLastName) {
		this.containerLastName = containerLastName;
	}

	@Column(name = "SHEET_TYPE_CODES", length = 500)
	public String getSheetTypeCodes() {
		return this.sheetTypeCodes;
	}

	public void setSheetTypeCodes(String sheetTypeCodes) {
		this.sheetTypeCodes = sheetTypeCodes;
	}

	@Column(name = "INSP_ORG_CODE", length = 10)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "FEE_HANDLE_STATE", length = 4)
	public String getFeeHandleState() {
		return this.feeHandleState;
	}

	public void setFeeHandleState(String feeHandleState) {
		this.feeHandleState = feeHandleState;
	}

	@Column(name = "DECL_GET_NO", length = 20)
	public String getDeclGetNo() {
		return this.declGetNo;
	}

	public void setDeclGetNo(String declGetNo) {
		this.declGetNo = declGetNo;
	}

	@Column(name = "PACK_CONTAINER_NO", length = 20)
	public String getPackContainerNo() {
		return this.packContainerNo;
	}

	public void setPackContainerNo(String packContainerNo) {
		this.packContainerNo = packContainerNo;
	}

	@Column(name = "PACK_MARK_NO", length = 200)
	public String getPackMarkNo() {
		return this.packMarkNo;
	}

	public void setPackMarkNo(String packMarkNo) {
		this.packMarkNo = packMarkNo;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "DEPT_CODE", length = 10)
	public String getDeptCode() {
		return this.deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	@Column(name = "DISPT_CERT_FLAG", length = 1)
	public String getDisptCertFlag() {
		return this.disptCertFlag;
	}

	public void setDisptCertFlag(String disptCertFlag) {
		this.disptCertFlag = disptCertFlag;
	}

	@Column(name = "SPEC_FLAG", length = 1)
	public String getSpecFlag() {
		return this.specFlag;
	}

	public void setSpecFlag(String specFlag) {
		this.specFlag = specFlag;
	}

	@Column(name = "ENT_DECL_NO", length = 40)
	public String getEntDeclNo() {
		return this.entDeclNo;
	}

	public void setEntDeclNo(String entDeclNo) {
		this.entDeclNo = entDeclNo;
	}

	@Column(name = "DECL_UNIT_CONTACT", length = 50)
	public String getDeclUnitContact() {
		return this.declUnitContact;
	}

	public void setDeclUnitContact(String declUnitContact) {
		this.declUnitContact = declUnitContact;
	}

	@Column(name = "DECL_UNIT_TEL", length = 20)
	public String getDeclUnitTel() {
		return this.declUnitTel;
	}

	public void setDeclUnitTel(String declUnitTel) {
		this.declUnitTel = declUnitTel;
	}

	@Column(name = "SPECIAL_REQUIRE", length = 100)
	public String getSpecialRequire() {
		return this.specialRequire;
	}

	public void setSpecialRequire(String specialRequire) {
		this.specialRequire = specialRequire;
	}

	@Column(name = "RESEND_NUM", nullable = false, length = 1)
	public String getResendNum() {
		return this.resendNum;
	}

	public void setResendNum(String resendNum) {
		this.resendNum = resendNum;
	}

	@Column(name = "CHANGE_INSP_DEPT_FLAG", nullable = false, length = 1)
	public String getChangeInspDeptFlag() {
		return this.changeInspDeptFlag;
	}

	public void setChangeInspDeptFlag(String changeInspDeptFlag) {
		this.changeInspDeptFlag = changeInspDeptFlag;
	}

	@Column(name = "PROCESS_STATUS", length = 10)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "DECL_REG_NO", length = 20)
	public String getDeclRegNo() {
		return this.declRegNo;
	}

	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}

	@Column(name = "DECLARE_CODE", length = 20)
	public String getDeclareCode() {
		return this.declareCode;
	}

	public void setDeclareCode(String declareCode) {
		this.declareCode = declareCode;
	}

	@Column(name = "WT_UNIT_CODE", length = 4)
	public String getWtUnitCode() {
		return this.wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	@Column(name = "PROCESS_LINK", length = 4)
	public String getProcessLink() {
		return this.processLink;
	}

	public void setProcessLink(String processLink) {
		this.processLink = processLink;
	}

	@Column(name = "PROD_TECH", length = 100)
	public String getProdTech() {
		return this.prodTech;
	}

	public void setProdTech(String prodTech) {
		this.prodTech = prodTech;
	}

	@Column(name = "TEST_RPT_NO", length = 20)
	public String getTestRptNo() {
		return this.testRptNo;
	}

	public void setTestRptNo(String testRptNo) {
		this.testRptNo = testRptNo;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "TRANS_FLAG", length = 10)
	public String getTransFlag() {
		return this.transFlag;
	}

	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}

	@Column(name = "ENT_UUID", length = 40)
	public String getEntUuid() {
		return this.entUuid;
	}

	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}

	@Column(name = "DECL_TYPE", length = 1)
	public String getDeclType() {
		return this.declType;
	}

	public void setDeclType(String declType) {
		this.declType = declType;
	}

	@Column(name = "ORG_CODE_PATH", length = 200)
	public String getOrgCodePath() {
		return this.orgCodePath;
	}

	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}

	@Column(name = "DECL_STATUS", length = 1)
	public String getDeclStatus() {
		return this.declStatus;
	}

	public void setDeclStatus(String declStatus) {
		this.declStatus = declStatus;
	}

	@Column(name = "IS_FEE", length = 1)
	public String getIsFee() {
		return this.isFee;
	}

	public void setIsFee(String isFee) {
		this.isFee = isFee;
	}

	@Column(name = "DECL_WORK_NO", length = 20)
	public String getDeclWorkNo() {
		return this.declWorkNo;
	}

	public void setDeclWorkNo(String declWorkNo) {
		this.declWorkNo = declWorkNo;
	}

	@Column(name = "ENT_DATE", length = 7)
	public Timestamp getEntDate() {
		return this.entDate;
	}

	public void setEntDate(Timestamp entDate) {
		this.entDate = entDate;
	}

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclPackDecl")
//	public Set<DclPackDeclModelEntity> getDclPackDeclModels() {
//		return this.dclPackDeclModels;
//	}
//
//	public void setDclPackDeclModels(Set<DclPackDeclModelEntity> dclPackDeclModels) {
//		this.dclPackDeclModels = dclPackDeclModels;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "dclPackDecl")
//	public Set<DclPackDeclDispartEntity> getDclPackDeclDisparts() {
//		return this.dclPackDeclDisparts;
//	}
//
//	public void setDclPackDeclDisparts(
//			Set<DclPackDeclDispartEntity> dclPackDeclDisparts) {
//		this.dclPackDeclDisparts = dclPackDeclDisparts;
//	}

}
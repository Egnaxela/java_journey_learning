package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * DclPackDeclModel entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_PACK_DECL_MODEL")
public class DclPackDeclModelEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 2693285760045285497L;
	private String modelId;
	private DclPackDeclEntity dclPackDecl;
	private Double packNo;
	private String pkgCntnrSpec;
	private Double modelSize;
	private Double qty;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;

	// Constructors

	/** default constructor */
	public DclPackDeclModelEntity() {
	}

	/** minimal constructor */
	public DclPackDeclModelEntity(String modelId, DclPackDeclEntity dclPackDecl,
			Double packNo) {
		this.modelId = modelId;
		this.dclPackDecl = dclPackDecl;
		this.packNo = packNo;
	}

	/** full constructor */
	public DclPackDeclModelEntity(String modelId, DclPackDeclEntity dclPackDecl,
			Double packNo, String pkgCntnrSpec, Double modelSize, Double qty,
			Timestamp operTime, String falgArchive, Timestamp archiveTime) {
		this.modelId = modelId;
		this.dclPackDecl = dclPackDecl;
		this.packNo = packNo;
		this.pkgCntnrSpec = pkgCntnrSpec;
		this.modelSize = modelSize;
		this.qty = qty;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "MODEL_ID", unique = true, nullable = false, length = 32)
	public String getModelId() {
		return this.modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DECL_NO", nullable = false)
	public DclPackDeclEntity getDclPackDecl() {
		return this.dclPackDecl;
	}

	public void setDclPackDecl(DclPackDeclEntity dclPackDecl) {
		this.dclPackDecl = dclPackDecl;
	}

	@Column(name = "PACK_NO", nullable = false, precision = 0)
	public Double getPackNo() {
		return this.packNo;
	}

	public void setPackNo(Double packNo) {
		this.packNo = packNo;
	}

	@Column(name = "PKG_CNTNR_SPEC", length = 50)
	public String getPkgCntnrSpec() {
		return this.pkgCntnrSpec;
	}

	public void setPkgCntnrSpec(String pkgCntnrSpec) {
		this.pkgCntnrSpec = pkgCntnrSpec;
	}

	@Column(name = "MODEL_SIZE", precision = 0)
	public Double getModelSize() {
		return this.modelSize;
	}

	public void setModelSize(Double modelSize) {
		this.modelSize = modelSize;
	}

	@Column(name = "QTY", precision = 0)
	public Double getQty() {
		return this.qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DclProcessCount entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_PROCESS_COUNT")
public class DclProcessCountEntity implements java.io.Serializable {

	private static final long serialVersionUID = 8404687972300333506L;
	private String processCalendarId;
	private String orgCode;
	private String deptCode;
	private Timestamp operDate;
	private String year;
	private String monthJan;
	private String monthFeb;
	private String monthMar;
	private String monthApr;
	private String monthMay;
	private String monthJun;
	private String monthJul;
	private String monthAug;
	private String monthSep;
	private String monthOct;
	private String monthNov;
	private String monthDec;
	private String weekMon;
	private String weekTues;
	private String weekWed;
	private String weekThur;
	private String weekFri;
	private String weekSat;
	private String weekSun;
	private String hourOne;
	private String hourTwo;
	private String hourThree;
	private String hourFour;
	private String hourFive;
	private String hourSix;
	private String hourSeven;
	private String hourEight;
	private String hourNine;
	private String hourTen;
	private String hourEleven;
	private String hourTwelve;
	private String hourThirteen;
	private String hourForteen;
	private String hourFifteen;
	private String hourSixteen;
	private String hourSeventeen;
	private String hourEighteen;
	private String hourNineteen;
	private String hourTwenty;
	private String hourTwentyOne;
	private String hourTwentyTwo;
	private String hourTwentyThree;
	private String hourTwentyFour;

	// Constructors

	/** default constructor */
	public DclProcessCountEntity() {
	}

	/** minimal constructor */
	public DclProcessCountEntity(String processCalendarId) {
		this.processCalendarId = processCalendarId;
	}

	/** full constructor */
	public DclProcessCountEntity(String processCalendarId, String orgCode,
			String deptCode, Timestamp operDate, String monthJan,
			String monthFeb, String monthMar, String monthApr, String monthMay,
			String monthJun, String monthJul, String monthAug, String monthSep,
			String monthOct, String monthNov, String monthDec, String weekMon,
			String weekTues, String weekWed, String weekThur, String weekFri,
			String weekSat, String weekSun, String hourOne, String hourTwo,
			String hourThree, String hourFour, String hourFive, String hourSix,
			String hourSeven, String hourEight, String hourNine,
			String hourTen, String hourEleven, String hourTwelve,
			String hourThirteen, String hourForteen, String hourFifteen,
			String hourSixteen, String hourSeventeen, String hourEighteen,
			String hourNineteen, String hourTwenty, String hourTwentyOne,
			String hourTwentyTwo, String hourTwentyThree, String hourTwentyFour) {
		this.processCalendarId = processCalendarId;
		this.orgCode = orgCode;
		this.deptCode = deptCode;
		this.operDate = operDate;
		this.monthJan = monthJan;
		this.monthFeb = monthFeb;
		this.monthMar = monthMar;
		this.monthApr = monthApr;
		this.monthMay = monthMay;
		this.monthJun = monthJun;
		this.monthJul = monthJul;
		this.monthAug = monthAug;
		this.monthSep = monthSep;
		this.monthOct = monthOct;
		this.monthNov = monthNov;
		this.monthDec = monthDec;
		this.weekMon = weekMon;
		this.weekTues = weekTues;
		this.weekWed = weekWed;
		this.weekThur = weekThur;
		this.weekFri = weekFri;
		this.weekSat = weekSat;
		this.weekSun = weekSun;
		this.hourOne = hourOne;
		this.hourTwo = hourTwo;
		this.hourThree = hourThree;
		this.hourFour = hourFour;
		this.hourFive = hourFive;
		this.hourSix = hourSix;
		this.hourSeven = hourSeven;
		this.hourEight = hourEight;
		this.hourNine = hourNine;
		this.hourTen = hourTen;
		this.hourEleven = hourEleven;
		this.hourTwelve = hourTwelve;
		this.hourThirteen = hourThirteen;
		this.hourForteen = hourForteen;
		this.hourFifteen = hourFifteen;
		this.hourSixteen = hourSixteen;
		this.hourSeventeen = hourSeventeen;
		this.hourEighteen = hourEighteen;
		this.hourNineteen = hourNineteen;
		this.hourTwenty = hourTwenty;
		this.hourTwentyOne = hourTwentyOne;
		this.hourTwentyTwo = hourTwentyTwo;
		this.hourTwentyThree = hourTwentyThree;
		this.hourTwentyFour = hourTwentyFour;
	}

	// Property accessors
	@Id
	@Column(name = "PROCESS_CALENDAR_ID", unique = true, nullable = false, length = 32)
	public String getProcessCalendarId() {
		return this.processCalendarId;
	}

	public void setProcessCalendarId(String processCalendarId) {
		this.processCalendarId = processCalendarId;
	}

	@Column(name = "ORG_CODE", length = 20)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "DEPT_CODE", length = 20)
	public String getDeptCode() {
		return this.deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	@Column(name = "OPER_DATE", length = 7)
	public Timestamp getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Timestamp operDate) {
		this.operDate = operDate;
	}

	@Column(name = "MONTH_JAN", length = 20)
	public String getMonthJan() {
		return this.monthJan;
	}

	public void setMonthJan(String monthJan) {
		this.monthJan = monthJan;
	}

	@Column(name = "MONTH_FEB", length = 20)
	public String getMonthFeb() {
		return this.monthFeb;
	}

	public void setMonthFeb(String monthFeb) {
		this.monthFeb = monthFeb;
	}

	@Column(name = "MONTH_MAR", length = 20)
	public String getMonthMar() {
		return this.monthMar;
	}

	public void setMonthMar(String monthMar) {
		this.monthMar = monthMar;
	}

	@Column(name = "MONTH_APR", length = 20)
	public String getMonthApr() {
		return this.monthApr;
	}

	public void setMonthApr(String monthApr) {
		this.monthApr = monthApr;
	}

	@Column(name = "MONTH_MAY", length = 20)
	public String getMonthMay() {
		return this.monthMay;
	}

	public void setMonthMay(String monthMay) {
		this.monthMay = monthMay;
	}

	@Column(name = "MONTH_JUN", length = 20)
	public String getMonthJun() {
		return this.monthJun;
	}

	public void setMonthJun(String monthJun) {
		this.monthJun = monthJun;
	}

	@Column(name = "MONTH_JUL", length = 20)
	public String getMonthJul() {
		return this.monthJul;
	}

	public void setMonthJul(String monthJul) {
		this.monthJul = monthJul;
	}

	@Column(name = "MONTH_AUG", length = 20)
	public String getMonthAug() {
		return this.monthAug;
	}

	public void setMonthAug(String monthAug) {
		this.monthAug = monthAug;
	}

	@Column(name = "MONTH_SEP", length = 20)
	public String getMonthSep() {
		return this.monthSep;
	}

	public void setMonthSep(String monthSep) {
		this.monthSep = monthSep;
	}

	@Column(name = "MONTH_OCT", length = 20)
	public String getMonthOct() {
		return this.monthOct;
	}

	public void setMonthOct(String monthOct) {
		this.monthOct = monthOct;
	}

	@Column(name = "MONTH_NOV", length = 20)
	public String getMonthNov() {
		return this.monthNov;
	}

	public void setMonthNov(String monthNov) {
		this.monthNov = monthNov;
	}

	@Column(name = "MONTH_DEC", length = 20)
	public String getMonthDec() {
		return this.monthDec;
	}

	public void setMonthDec(String monthDec) {
		this.monthDec = monthDec;
	}

	@Column(name = "WEEK_MON", length = 20)
	public String getWeekMon() {
		return this.weekMon;
	}

	public void setWeekMon(String weekMon) {
		this.weekMon = weekMon;
	}

	@Column(name = "WEEK_TUES", length = 20)
	public String getWeekTues() {
		return this.weekTues;
	}

	public void setWeekTues(String weekTues) {
		this.weekTues = weekTues;
	}

	@Column(name = "WEEK_WED", length = 20)
	public String getWeekWed() {
		return this.weekWed;
	}

	public void setWeekWed(String weekWed) {
		this.weekWed = weekWed;
	}

	@Column(name = "WEEK_THUR", length = 20)
	public String getWeekThur() {
		return this.weekThur;
	}

	public void setWeekThur(String weekThur) {
		this.weekThur = weekThur;
	}

	@Column(name = "WEEK_FRI", length = 20)
	public String getWeekFri() {
		return this.weekFri;
	}

	public void setWeekFri(String weekFri) {
		this.weekFri = weekFri;
	}

	@Column(name = "WEEK_SAT", length = 20)
	public String getWeekSat() {
		return this.weekSat;
	}

	public void setWeekSat(String weekSat) {
		this.weekSat = weekSat;
	}

	@Column(name = "WEEK_SUN", length = 20)
	public String getWeekSun() {
		return this.weekSun;
	}

	public void setWeekSun(String weekSun) {
		this.weekSun = weekSun;
	}

	@Column(name = "HOUR_ONE", length = 20)
	public String getHourOne() {
		return this.hourOne;
	}

	public void setHourOne(String hourOne) {
		this.hourOne = hourOne;
	}

	@Column(name = "HOUR_TWO", length = 20)
	public String getHourTwo() {
		return this.hourTwo;
	}

	public void setHourTwo(String hourTwo) {
		this.hourTwo = hourTwo;
	}

	@Column(name = "HOUR_THREE", length = 20)
	public String getHourThree() {
		return this.hourThree;
	}

	public void setHourThree(String hourThree) {
		this.hourThree = hourThree;
	}

	@Column(name = "HOUR_FOUR", length = 20)
	public String getHourFour() {
		return this.hourFour;
	}

	public void setHourFour(String hourFour) {
		this.hourFour = hourFour;
	}

	@Column(name = "HOUR_FIVE", length = 20)
	public String getHourFive() {
		return this.hourFive;
	}

	public void setHourFive(String hourFive) {
		this.hourFive = hourFive;
	}

	@Column(name = "HOUR_SIX", length = 20)
	public String getHourSix() {
		return this.hourSix;
	}

	public void setHourSix(String hourSix) {
		this.hourSix = hourSix;
	}

	@Column(name = "HOUR_SEVEN", length = 20)
	public String getHourSeven() {
		return this.hourSeven;
	}

	public void setHourSeven(String hourSeven) {
		this.hourSeven = hourSeven;
	}

	@Column(name = "HOUR_EIGHT", length = 20)
	public String getHourEight() {
		return this.hourEight;
	}

	public void setHourEight(String hourEight) {
		this.hourEight = hourEight;
	}

	@Column(name = "HOUR_NINE", length = 20)
	public String getHourNine() {
		return this.hourNine;
	}

	public void setHourNine(String hourNine) {
		this.hourNine = hourNine;
	}

	@Column(name = "HOUR_TEN", length = 20)
	public String getHourTen() {
		return this.hourTen;
	}

	public void setHourTen(String hourTen) {
		this.hourTen = hourTen;
	}

	@Column(name = "HOUR_ELEVEN", length = 20)
	public String getHourEleven() {
		return this.hourEleven;
	}

	public void setHourEleven(String hourEleven) {
		this.hourEleven = hourEleven;
	}

	@Column(name = "HOUR_TWELVE", length = 20)
	public String getHourTwelve() {
		return this.hourTwelve;
	}

	public void setHourTwelve(String hourTwelve) {
		this.hourTwelve = hourTwelve;
	}

	@Column(name = "HOUR_THIRTEEN", length = 20)
	public String getHourThirteen() {
		return this.hourThirteen;
	}

	public void setHourThirteen(String hourThirteen) {
		this.hourThirteen = hourThirteen;
	}

	@Column(name = "HOUR_FORTEEN", length = 20)
	public String getHourForteen() {
		return this.hourForteen;
	}

	public void setHourForteen(String hourForteen) {
		this.hourForteen = hourForteen;
	}

	@Column(name = "HOUR_FIFTEEN", length = 20)
	public String getHourFifteen() {
		return this.hourFifteen;
	}

	public void setHourFifteen(String hourFifteen) {
		this.hourFifteen = hourFifteen;
	}

	@Column(name = "HOUR_SIXTEEN", length = 20)
	public String getHourSixteen() {
		return this.hourSixteen;
	}

	public void setHourSixteen(String hourSixteen) {
		this.hourSixteen = hourSixteen;
	}

	@Column(name = "HOUR_SEVENTEEN", length = 20)
	public String getHourSeventeen() {
		return this.hourSeventeen;
	}

	public void setHourSeventeen(String hourSeventeen) {
		this.hourSeventeen = hourSeventeen;
	}

	@Column(name = "HOUR_EIGHTEEN", length = 20)
	public String getHourEighteen() {
		return this.hourEighteen;
	}

	public void setHourEighteen(String hourEighteen) {
		this.hourEighteen = hourEighteen;
	}

	@Column(name = "HOUR_NINETEEN", length = 20)
	public String getHourNineteen() {
		return this.hourNineteen;
	}

	public void setHourNineteen(String hourNineteen) {
		this.hourNineteen = hourNineteen;
	}

	@Column(name = "HOUR_TWENTY", length = 20)
	public String getHourTwenty() {
		return this.hourTwenty;
	}

	public void setHourTwenty(String hourTwenty) {
		this.hourTwenty = hourTwenty;
	}

	@Column(name = "HOUR_TWENTY_ONE", length = 20)
	public String getHourTwentyOne() {
		return this.hourTwentyOne;
	}

	public void setHourTwentyOne(String hourTwentyOne) {
		this.hourTwentyOne = hourTwentyOne;
	}

	@Column(name = "HOUR_TWENTY_TWO", length = 20)
	public String getHourTwentyTwo() {
		return this.hourTwentyTwo;
	}

	public void setHourTwentyTwo(String hourTwentyTwo) {
		this.hourTwentyTwo = hourTwentyTwo;
	}

	@Column(name = "HOUR_TWENTY_THREE", length = 20)
	public String getHourTwentyThree() {
		return this.hourTwentyThree;
	}

	public void setHourTwentyThree(String hourTwentyThree) {
		this.hourTwentyThree = hourTwentyThree;
	}

	@Column(name = "HOUR_TWENTY_FOUR", length = 20)
	public String getHourTwentyFour() {
		return this.hourTwentyFour;
	}

	public void setHourTwentyFour(String hourTwentyFour) {
		this.hourTwentyFour = hourTwentyFour;
	}

	@Column(name = "YEAR", length = 20)
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
	
	
	
	
	
	

}
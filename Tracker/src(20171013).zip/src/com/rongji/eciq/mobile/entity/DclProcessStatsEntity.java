package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DclProcessStatsId entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DCL_PROCESS_STATS")
public class DclProcessStatsEntity implements java.io.Serializable {
	
	private static final long serialVersionUID = 1751100960564189701L;
	private String processStatsId;
	private String declNo;
	private String operCode;
	private String operName;
	private Timestamp operDate;
	private Timestamp firstOperDate;
	private String operNo;
	private String operCount;
	private String operIp;
	private String operAddress;
	private String falgArchive;
	private String remark;
	private String additional;
	private String orgCode;

	// Constructors

	/** default constructor */
	public DclProcessStatsEntity() {
	}

	/** minimal constructor */
	public DclProcessStatsEntity(String processStatsId) {
		this.processStatsId = processStatsId;
	}

	/** full constructor */
	public DclProcessStatsEntity(String processStatsId, String declNo,
			String operCode, String operName, Timestamp operDate,
			String operNo, String operCount, String operIp, String operAddress,
			String falgArchive, String remark, String additional) {
		this.processStatsId = processStatsId;
		this.declNo = declNo;
		this.operCode = operCode;
		this.operName = operName;
		this.operDate = operDate;
		this.operNo = operNo;
		this.operCount = operCount;
		this.operIp = operIp;
		this.operAddress = operAddress;
		this.falgArchive = falgArchive;
		this.remark = remark;
		this.additional = additional;
	}

	// Property accessors

	@Id
	@Column(name = "PROCESS_STATS_ID", nullable = false, length = 32)
	public String getProcessStatsId() {
		return this.processStatsId;
	}

	public void setProcessStatsId(String processStatsId) {
		this.processStatsId = processStatsId;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "OPER_NAME", length = 50)
	public String getOperName() {
		return this.operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	@Column(name = "OPER_DATE", length = 7)
	public Timestamp getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Timestamp operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FIRST_OPER_DATE", length = 7)
	public Timestamp getFirstOperDate() {
		return firstOperDate;
	}

	public void setFirstOperDate(Timestamp firstOperDate) {
		this.firstOperDate = firstOperDate;
	}

	@Column(name = "OPER_NO", length = 100)
	public String getOperNo() {
		return this.operNo;
	}

	public void setOperNo(String operNo) {
		this.operNo = operNo;
	}

	@Column(name = "OPER_COUNT", length = 2)
	public String getOperCount() {
		return this.operCount;
	}

	public void setOperCount(String operCount) {
		this.operCount = operCount;
	}

	@Column(name = "OPER_IP", length = 32)
	public String getOperIp() {
		return this.operIp;
	}

	public void setOperIp(String operIp) {
		this.operIp = operIp;
	}
	
	@Column(name = "ORG_CODE", length = 32)
	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "OPER_ADDRESS", length = 32)
	public String getOperAddress() {
		return this.operAddress;
	}

	public void setOperAddress(String operAddress) {
		this.operAddress = operAddress;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "ADDITIONAL", length = 1000)
	public String getAdditional() {
		return this.additional;
	}

	public void setAdditional(String additional) {
		this.additional = additional;
	}


}
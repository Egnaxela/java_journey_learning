/**  
 * FileName:   DeclLogicVo.java  
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月19日 下午4:47:19  
 *  
 */  

package com.rongji.eciq.mobile.entity;

/**  
 * Description: 拼接报检单基本信息表和扩展表用于数据处理  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月19日 下午4:47:19  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月19日      吴有根                      1.0         1.0 Version  
 */

public class DeclLogicVo {

	private String declNo;//报检单号
	private String processStatus;//报检流程状态
	private String inspRequire;//检验要求
	private String expImpFlag;//出入境标志
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public String getInspRequire() {
		return inspRequire;
	}
	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}
	public String getExpImpFlag() {
		return expImpFlag;
	}
	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}
	
	
}

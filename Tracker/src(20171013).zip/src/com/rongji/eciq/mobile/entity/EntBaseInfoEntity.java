/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-7-19 下午2:13:49  
 *  
 */  

package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-7-19 下午2:13:49  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-7-19      李云龙                      1.0         1.0 Version  
 */
@Entity
@Table(name = "ENT_BASE_INFO")
public class EntBaseInfoEntity implements
java.io.Serializable {
	
	private String entInfoId;
	private String entOrgCode;
	private Date regDate;
	private String declRegNo;
	private String regPlcAddr;
	private String regPlcPostCode;
	private String businessAddr;
	private String operatZip;
	private String unitNameCn;
	private String unitNameEn;
	private String unitShortNm;
	private String unitFax;
	private String unitEmail;
	private String entLeglPersn;
	private String leglPersnPhone;
	private String leglPersnFax;
	private String orgContactPersn;
	private String contTel;
	private String contMobile;
	private String contFax;
	private String custmRegCode;
	private BigDecimal regedCapital;
	private String bizScop;
	private String entTypeName;
	private String entNatureName;
	private String entStatus;
	private String entIntro;
	private String entLevelCode;
	private String entLevelName;
	private String changeState;
	private String subCiqOrgCode;
	private String subCiqOrgName;
	private String userPwd;
	private Date modifTime;
	private String modPersnUsrCode;
	private String abolishFlag;
	private String website;
	private String remark;
	private BigDecimal totalPersonAmt;
	private BigDecimal adminEmpQty;
	private BigDecimal empProdQty;
	private BigDecimal qulManagEmlyQty;
	private String totalArea;
	private String storageArea;
	private String testAbility;
	private String manageSys;
	private String otherManagSys;
	private String entCltType;
	private String entClientClass;
	private String honestyLevel;
	private String ciqEvaluate;
	private String expLevelCode;
	private String trustLevelCode;
	private String magDeptCode;
	private String magDeptName;
	private String prodProcess;
	private String supplierCategories;
	private String supWayName;
	private String certificationLicense;
	private String isNeedApprove;
	private String dailySupWay;
	private String impDeptCode;
	private String factoryArea;
	private String infoSourceWay;
	private String geographyCoordinate;
	private String falgArchive;
	private Date operTime;
	private String regCountryCode;
	private String isForeignEnt;
	private String regPlcAddrEn;
	private String personId;
	private String trafficNo;
	private Date trafficStartDate;
	private Date trafficEndDate;
	private String openBank;
	private String bankAccount;
	private String entType;
	private String verifierCode;
	private Date auditTime;
	private String updateFlag;
	private String agentType;
	private String foreignTradeNo;
	private String productCertificateNo;
	private String directFlag;
	private String autoPassFlag;
	private String password;
	private Date certFirstDate;
	private Date certStartDate;
	private Date certEndDate;
	private String entOldCode;
	private Date annualDate;
	private String auunExamConcl;
	private String isRecorded;
	private String branchPrincipal;
	private String branchPrincipalPhone;
	private String branchPrincipalFax;
	private String trafficNonlegalNo;
	private String systemAuthentications;
	private String outCottonEntGrade;
	private String admiPlaceCode;
	private String investCountryCode;
	private BigDecimal recordVersion;
	private String validFlag;
	private String orgTel;
	private String impLevelCode;
	private String payModeCode;
	private String ciqRegNo;
	private String safetyBaseZone;
	private Date archiveTime;
	private String timeFeeModeCode;
	private String entOrgCodeNew;
	private String operName;
	private String operOrgCode;
	private String operDeptCode;
	private String sendFlag;
	private String entOrgPwd;
	private String entOrgRegister;

	// Constructors

	/** default constructor */
	public EntBaseInfoEntity() {
	}

	/** minimal constructor */
	public EntBaseInfoEntity(String entInfoId) {
		this.entInfoId = entInfoId;
	}

	/** full constructor */
	public EntBaseInfoEntity(String entInfoId, String entOrgCode,
			Date regDate, String declRegNo, String regPlcAddr,
			String regPlcPostCode, String businessAddr, String operatZip,
			String unitNameCn, String unitNameEn, String unitShortNm,
			String unitFax, String unitEmail, String entLeglPersn,
			String leglPersnPhone, String leglPersnFax, String orgContactPersn,
			String contTel, String contMobile, String contFax,
			String custmRegCode, BigDecimal regedCapital, String bizScop,
			String entTypeName, String entNatureName, String entStatus,
			String entIntro, String entLevelCode, String entLevelName,
			String changeState, String subCiqOrgCode, String subCiqOrgName,
			String userPwd, Date modifTime, String modPersnUsrCode,
			String abolishFlag, String website, String remark,
			BigDecimal totalPersonAmt, BigDecimal adminEmpQty,
			BigDecimal empProdQty, BigDecimal qulManagEmlyQty,
			String totalArea, String storageArea, String testAbility,
			String manageSys, String otherManagSys, String entCltType,
			String entClientClass, String honestyLevel, String ciqEvaluate,
			String expLevelCode, String trustLevelCode, String magDeptCode,
			String magDeptName, String prodProcess, String supplierCategories,
			String supWayName, String certificationLicense,
			String isNeedApprove, String dailySupWay, String impDeptCode,
			String factoryArea, String infoSourceWay,
			String geographyCoordinate, String falgArchive, Date operTime,
			String regCountryCode, String isForeignEnt, String regPlcAddrEn,
			String personId, String trafficNo, Date trafficStartDate,
			Date trafficEndDate, String openBank, String bankAccount,
			String entType, String verifierCode, Date auditTime,
			String updateFlag, String agentType, String foreignTradeNo,
			String productCertificateNo, String directFlag,
			String autoPassFlag, String password, Date certFirstDate,
			Date certStartDate, Date certEndDate, String entOldCode,
			Date annualDate, String auunExamConcl, String isRecorded,
			String branchPrincipal, String branchPrincipalPhone,
			String branchPrincipalFax, String trafficNonlegalNo,
			String systemAuthentications, String outCottonEntGrade,
			String admiPlaceCode, String investCountryCode,
			BigDecimal recordVersion, String validFlag, String orgTel,
			String impLevelCode, String payModeCode, String ciqRegNo,
			String safetyBaseZone, Date archiveTime, String timeFeeModeCode,
			String entOrgCodeNew, String operName, String operOrgCode,
			String operDeptCode, String sendFlag, String entOrgPwd,
			String entOrgRegister) {
		this.entInfoId = entInfoId;
		this.entOrgCode = entOrgCode;
		this.regDate = regDate;
		this.declRegNo = declRegNo;
		this.regPlcAddr = regPlcAddr;
		this.regPlcPostCode = regPlcPostCode;
		this.businessAddr = businessAddr;
		this.operatZip = operatZip;
		this.unitNameCn = unitNameCn;
		this.unitNameEn = unitNameEn;
		this.unitShortNm = unitShortNm;
		this.unitFax = unitFax;
		this.unitEmail = unitEmail;
		this.entLeglPersn = entLeglPersn;
		this.leglPersnPhone = leglPersnPhone;
		this.leglPersnFax = leglPersnFax;
		this.orgContactPersn = orgContactPersn;
		this.contTel = contTel;
		this.contMobile = contMobile;
		this.contFax = contFax;
		this.custmRegCode = custmRegCode;
		this.regedCapital = regedCapital;
		this.bizScop = bizScop;
		this.entTypeName = entTypeName;
		this.entNatureName = entNatureName;
		this.entStatus = entStatus;
		this.entIntro = entIntro;
		this.entLevelCode = entLevelCode;
		this.entLevelName = entLevelName;
		this.changeState = changeState;
		this.subCiqOrgCode = subCiqOrgCode;
		this.subCiqOrgName = subCiqOrgName;
		this.userPwd = userPwd;
		this.modifTime = modifTime;
		this.modPersnUsrCode = modPersnUsrCode;
		this.abolishFlag = abolishFlag;
		this.website = website;
		this.remark = remark;
		this.totalPersonAmt = totalPersonAmt;
		this.adminEmpQty = adminEmpQty;
		this.empProdQty = empProdQty;
		this.qulManagEmlyQty = qulManagEmlyQty;
		this.totalArea = totalArea;
		this.storageArea = storageArea;
		this.testAbility = testAbility;
		this.manageSys = manageSys;
		this.otherManagSys = otherManagSys;
		this.entCltType = entCltType;
		this.entClientClass = entClientClass;
		this.honestyLevel = honestyLevel;
		this.ciqEvaluate = ciqEvaluate;
		this.expLevelCode = expLevelCode;
		this.trustLevelCode = trustLevelCode;
		this.magDeptCode = magDeptCode;
		this.magDeptName = magDeptName;
		this.prodProcess = prodProcess;
		this.supplierCategories = supplierCategories;
		this.supWayName = supWayName;
		this.certificationLicense = certificationLicense;
		this.isNeedApprove = isNeedApprove;
		this.dailySupWay = dailySupWay;
		this.impDeptCode = impDeptCode;
		this.factoryArea = factoryArea;
		this.infoSourceWay = infoSourceWay;
		this.geographyCoordinate = geographyCoordinate;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.regCountryCode = regCountryCode;
		this.isForeignEnt = isForeignEnt;
		this.regPlcAddrEn = regPlcAddrEn;
		this.personId = personId;
		this.trafficNo = trafficNo;
		this.trafficStartDate = trafficStartDate;
		this.trafficEndDate = trafficEndDate;
		this.openBank = openBank;
		this.bankAccount = bankAccount;
		this.entType = entType;
		this.verifierCode = verifierCode;
		this.auditTime = auditTime;
		this.updateFlag = updateFlag;
		this.agentType = agentType;
		this.foreignTradeNo = foreignTradeNo;
		this.productCertificateNo = productCertificateNo;
		this.directFlag = directFlag;
		this.autoPassFlag = autoPassFlag;
		this.password = password;
		this.certFirstDate = certFirstDate;
		this.certStartDate = certStartDate;
		this.certEndDate = certEndDate;
		this.entOldCode = entOldCode;
		this.annualDate = annualDate;
		this.auunExamConcl = auunExamConcl;
		this.isRecorded = isRecorded;
		this.branchPrincipal = branchPrincipal;
		this.branchPrincipalPhone = branchPrincipalPhone;
		this.branchPrincipalFax = branchPrincipalFax;
		this.trafficNonlegalNo = trafficNonlegalNo;
		this.systemAuthentications = systemAuthentications;
		this.outCottonEntGrade = outCottonEntGrade;
		this.admiPlaceCode = admiPlaceCode;
		this.investCountryCode = investCountryCode;
		this.recordVersion = recordVersion;
		this.validFlag = validFlag;
		this.orgTel = orgTel;
		this.impLevelCode = impLevelCode;
		this.payModeCode = payModeCode;
		this.ciqRegNo = ciqRegNo;
		this.safetyBaseZone = safetyBaseZone;
		this.archiveTime = archiveTime;
		this.timeFeeModeCode = timeFeeModeCode;
		this.entOrgCodeNew = entOrgCodeNew;
		this.operName = operName;
		this.operOrgCode = operOrgCode;
		this.operDeptCode = operDeptCode;
		this.sendFlag = sendFlag;
		this.entOrgPwd = entOrgPwd;
		this.entOrgRegister = entOrgRegister;
	}

	// Property accessors
	@Id
	@Column(name = "ENT_INFO_ID", unique = true, nullable = false, length = 32)
	public String getEntInfoId() {
		return this.entInfoId;
	}

	public void setEntInfoId(String entInfoId) {
		this.entInfoId = entInfoId;
	}

	@Column(name = "ENT_ORG_CODE", length = 20)
	public String getEntOrgCode() {
		return this.entOrgCode;
	}

	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "REG_DATE", length = 7)
	public Date getRegDate() {
		return this.regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@Column(name = "DECL_REG_NO", length = 20)
	public String getDeclRegNo() {
		return this.declRegNo;
	}

	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}

	@Column(name = "REG_PLC_ADDR", length = 100)
	public String getRegPlcAddr() {
		return this.regPlcAddr;
	}

	public void setRegPlcAddr(String regPlcAddr) {
		this.regPlcAddr = regPlcAddr;
	}

	@Column(name = "REG_PLC_POST_CODE", length = 10)
	public String getRegPlcPostCode() {
		return this.regPlcPostCode;
	}

	public void setRegPlcPostCode(String regPlcPostCode) {
		this.regPlcPostCode = regPlcPostCode;
	}

	@Column(name = "BUSINESS_ADDR", length = 500)
	public String getBusinessAddr() {
		return this.businessAddr;
	}

	public void setBusinessAddr(String businessAddr) {
		this.businessAddr = businessAddr;
	}

	@Column(name = "OPERAT_ZIP", length = 10)
	public String getOperatZip() {
		return this.operatZip;
	}

	public void setOperatZip(String operatZip) {
		this.operatZip = operatZip;
	}

	@Column(name = "UNIT_NAME_CN", length = 100)
	public String getUnitNameCn() {
		return this.unitNameCn;
	}

	public void setUnitNameCn(String unitNameCn) {
		this.unitNameCn = unitNameCn;
	}

	@Column(name = "UNIT_NAME_EN", length = 150)
	public String getUnitNameEn() {
		return this.unitNameEn;
	}

	public void setUnitNameEn(String unitNameEn) {
		this.unitNameEn = unitNameEn;
	}

	@Column(name = "UNIT_SHORT_NM", length = 50)
	public String getUnitShortNm() {
		return this.unitShortNm;
	}

	public void setUnitShortNm(String unitShortNm) {
		this.unitShortNm = unitShortNm;
	}

	@Column(name = "UNIT_FAX", length = 20)
	public String getUnitFax() {
		return this.unitFax;
	}

	public void setUnitFax(String unitFax) {
		this.unitFax = unitFax;
	}

	@Column(name = "UNIT_EMAIL", length = 50)
	public String getUnitEmail() {
		return this.unitEmail;
	}

	public void setUnitEmail(String unitEmail) {
		this.unitEmail = unitEmail;
	}

	@Column(name = "ENT_LEGL_PERSN", length = 50)
	public String getEntLeglPersn() {
		return this.entLeglPersn;
	}

	public void setEntLeglPersn(String entLeglPersn) {
		this.entLeglPersn = entLeglPersn;
	}

	@Column(name = "LEGL_PERSN_PHONE", length = 20)
	public String getLeglPersnPhone() {
		return this.leglPersnPhone;
	}

	public void setLeglPersnPhone(String leglPersnPhone) {
		this.leglPersnPhone = leglPersnPhone;
	}

	@Column(name = "LEGL_PERSN_FAX", length = 20)
	public String getLeglPersnFax() {
		return this.leglPersnFax;
	}

	public void setLeglPersnFax(String leglPersnFax) {
		this.leglPersnFax = leglPersnFax;
	}

	@Column(name = "ORG_CONTACT_PERSN", length = 20)
	public String getOrgContactPersn() {
		return this.orgContactPersn;
	}

	public void setOrgContactPersn(String orgContactPersn) {
		this.orgContactPersn = orgContactPersn;
	}

	@Column(name = "CONT_TEL", length = 20)
	public String getContTel() {
		return this.contTel;
	}

	public void setContTel(String contTel) {
		this.contTel = contTel;
	}

	@Column(name = "CONT_MOBILE", length = 20)
	public String getContMobile() {
		return this.contMobile;
	}

	public void setContMobile(String contMobile) {
		this.contMobile = contMobile;
	}

	@Column(name = "CONT_FAX", length = 20)
	public String getContFax() {
		return this.contFax;
	}

	public void setContFax(String contFax) {
		this.contFax = contFax;
	}

	@Column(name = "CUSTM_REG_CODE", length = 20)
	public String getCustmRegCode() {
		return this.custmRegCode;
	}

	public void setCustmRegCode(String custmRegCode) {
		this.custmRegCode = custmRegCode;
	}

	@Column(name = "REGED_CAPITAL", precision = 22, scale = 0)
	public BigDecimal getRegedCapital() {
		return this.regedCapital;
	}

	public void setRegedCapital(BigDecimal regedCapital) {
		this.regedCapital = regedCapital;
	}

	@Column(name = "BIZ_SCOP", length = 200)
	public String getBizScop() {
		return this.bizScop;
	}

	public void setBizScop(String bizScop) {
		this.bizScop = bizScop;
	}

	@Column(name = "ENT_TYPE_NAME", length = 10)
	public String getEntTypeName() {
		return this.entTypeName;
	}

	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	@Column(name = "ENT_NATURE_NAME", length = 10)
	public String getEntNatureName() {
		return this.entNatureName;
	}

	public void setEntNatureName(String entNatureName) {
		this.entNatureName = entNatureName;
	}

	@Column(name = "ENT_STATUS", length = 4)
	public String getEntStatus() {
		return this.entStatus;
	}

	public void setEntStatus(String entStatus) {
		this.entStatus = entStatus;
	}

	@Column(name = "ENT_INTRO", length = 2000)
	public String getEntIntro() {
		return this.entIntro;
	}

	public void setEntIntro(String entIntro) {
		this.entIntro = entIntro;
	}

	@Column(name = "ENT_LEVEL_CODE", length = 4)
	public String getEntLevelCode() {
		return this.entLevelCode;
	}

	public void setEntLevelCode(String entLevelCode) {
		this.entLevelCode = entLevelCode;
	}

	@Column(name = "ENT_LEVEL_NAME", length = 20)
	public String getEntLevelName() {
		return this.entLevelName;
	}

	public void setEntLevelName(String entLevelName) {
		this.entLevelName = entLevelName;
	}

	@Column(name = "CHANGE_STATE", length = 1)
	public String getChangeState() {
		return this.changeState;
	}

	public void setChangeState(String changeState) {
		this.changeState = changeState;
	}

	@Column(name = "SUB_CIQ_ORG_CODE", length = 10)
	public String getSubCiqOrgCode() {
		return this.subCiqOrgCode;
	}

	public void setSubCiqOrgCode(String subCiqOrgCode) {
		this.subCiqOrgCode = subCiqOrgCode;
	}

	@Column(name = "SUB_CIQ_ORG_NAME", length = 50)
	public String getSubCiqOrgName() {
		return this.subCiqOrgName;
	}

	public void setSubCiqOrgName(String subCiqOrgName) {
		this.subCiqOrgName = subCiqOrgName;
	}

	@Column(name = "USER_PWD", length = 20)
	public String getUserPwd() {
		return this.userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIF_TIME", length = 7)
	public Date getModifTime() {
		return this.modifTime;
	}

	public void setModifTime(Date modifTime) {
		this.modifTime = modifTime;
	}

	@Column(name = "MOD_PERSN_USR_CODE", length = 20)
	public String getModPersnUsrCode() {
		return this.modPersnUsrCode;
	}

	public void setModPersnUsrCode(String modPersnUsrCode) {
		this.modPersnUsrCode = modPersnUsrCode;
	}

	@Column(name = "ABOLISH_FLAG", length = 1)
	public String getAbolishFlag() {
		return this.abolishFlag;
	}

	public void setAbolishFlag(String abolishFlag) {
		this.abolishFlag = abolishFlag;
	}

	@Column(name = "WEBSITE", length = 50)
	public String getWebsite() {
		return this.website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "TOTAL_PERSON_AMT", precision = 22, scale = 0)
	public BigDecimal getTotalPersonAmt() {
		return this.totalPersonAmt;
	}

	public void setTotalPersonAmt(BigDecimal totalPersonAmt) {
		this.totalPersonAmt = totalPersonAmt;
	}

	@Column(name = "ADMIN_EMP_QTY", precision = 22, scale = 0)
	public BigDecimal getAdminEmpQty() {
		return this.adminEmpQty;
	}

	public void setAdminEmpQty(BigDecimal adminEmpQty) {
		this.adminEmpQty = adminEmpQty;
	}

	@Column(name = "EMP_PROD_QTY", precision = 22, scale = 0)
	public BigDecimal getEmpProdQty() {
		return this.empProdQty;
	}

	public void setEmpProdQty(BigDecimal empProdQty) {
		this.empProdQty = empProdQty;
	}

	@Column(name = "QUL_MANAG_EMLY_QTY", precision = 22, scale = 0)
	public BigDecimal getQulManagEmlyQty() {
		return this.qulManagEmlyQty;
	}

	public void setQulManagEmlyQty(BigDecimal qulManagEmlyQty) {
		this.qulManagEmlyQty = qulManagEmlyQty;
	}

	@Column(name = "TOTAL_AREA", length = 200)
	public String getTotalArea() {
		return this.totalArea;
	}

	public void setTotalArea(String totalArea) {
		this.totalArea = totalArea;
	}

	@Column(name = "STORAGE_AREA", length = 200)
	public String getStorageArea() {
		return this.storageArea;
	}

	public void setStorageArea(String storageArea) {
		this.storageArea = storageArea;
	}

	@Column(name = "TEST_ABILITY", length = 200)
	public String getTestAbility() {
		return this.testAbility;
	}

	public void setTestAbility(String testAbility) {
		this.testAbility = testAbility;
	}

	@Column(name = "MANAGE_SYS", length = 500)
	public String getManageSys() {
		return this.manageSys;
	}

	public void setManageSys(String manageSys) {
		this.manageSys = manageSys;
	}

	@Column(name = "OTHER_MANAG_SYS", length = 500)
	public String getOtherManagSys() {
		return this.otherManagSys;
	}

	public void setOtherManagSys(String otherManagSys) {
		this.otherManagSys = otherManagSys;
	}

	@Column(name = "ENT_CLT_TYPE", length = 2)
	public String getEntCltType() {
		return this.entCltType;
	}

	public void setEntCltType(String entCltType) {
		this.entCltType = entCltType;
	}

	@Column(name = "ENT_CLIENT_CLASS", length = 2)
	public String getEntClientClass() {
		return this.entClientClass;
	}

	public void setEntClientClass(String entClientClass) {
		this.entClientClass = entClientClass;
	}

	@Column(name = "HONESTY_LEVEL", length = 50)
	public String getHonestyLevel() {
		return this.honestyLevel;
	}

	public void setHonestyLevel(String honestyLevel) {
		this.honestyLevel = honestyLevel;
	}

	@Column(name = "CIQ_EVALUATE", length = 200)
	public String getCiqEvaluate() {
		return this.ciqEvaluate;
	}

	public void setCiqEvaluate(String ciqEvaluate) {
		this.ciqEvaluate = ciqEvaluate;
	}

	@Column(name = "EXP_LEVEL_CODE", length = 20)
	public String getExpLevelCode() {
		return this.expLevelCode;
	}

	public void setExpLevelCode(String expLevelCode) {
		this.expLevelCode = expLevelCode;
	}

	@Column(name = "TRUST_LEVEL_CODE", length = 20)
	public String getTrustLevelCode() {
		return this.trustLevelCode;
	}

	public void setTrustLevelCode(String trustLevelCode) {
		this.trustLevelCode = trustLevelCode;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "MAG_DEPT_NAME", length = 50)
	public String getMagDeptName() {
		return this.magDeptName;
	}

	public void setMagDeptName(String magDeptName) {
		this.magDeptName = magDeptName;
	}

	@Column(name = "PROD_PROCESS", length = 50)
	public String getProdProcess() {
		return this.prodProcess;
	}

	public void setProdProcess(String prodProcess) {
		this.prodProcess = prodProcess;
	}

	@Column(name = "SUPPLIER_CATEGORIES", length = 1)
	public String getSupplierCategories() {
		return this.supplierCategories;
	}

	public void setSupplierCategories(String supplierCategories) {
		this.supplierCategories = supplierCategories;
	}

	@Column(name = "SUP_WAY_NAME", length = 100)
	public String getSupWayName() {
		return this.supWayName;
	}

	public void setSupWayName(String supWayName) {
		this.supWayName = supWayName;
	}

	@Column(name = "CERTIFICATION_LICENSE", length = 500)
	public String getCertificationLicense() {
		return this.certificationLicense;
	}

	public void setCertificationLicense(String certificationLicense) {
		this.certificationLicense = certificationLicense;
	}

	@Column(name = "IS_NEED_APPROVE", length = 1)
	public String getIsNeedApprove() {
		return this.isNeedApprove;
	}

	public void setIsNeedApprove(String isNeedApprove) {
		this.isNeedApprove = isNeedApprove;
	}

	@Column(name = "DAILY_SUP_WAY", length = 100)
	public String getDailySupWay() {
		return this.dailySupWay;
	}

	public void setDailySupWay(String dailySupWay) {
		this.dailySupWay = dailySupWay;
	}

	@Column(name = "IMP_DEPT_CODE", length = 20)
	public String getImpDeptCode() {
		return this.impDeptCode;
	}

	public void setImpDeptCode(String impDeptCode) {
		this.impDeptCode = impDeptCode;
	}

	@Column(name = "FACTORY_AREA", length = 200)
	public String getFactoryArea() {
		return this.factoryArea;
	}

	public void setFactoryArea(String factoryArea) {
		this.factoryArea = factoryArea;
	}

	@Column(name = "INFO_SOURCE_WAY", length = 1)
	public String getInfoSourceWay() {
		return this.infoSourceWay;
	}

	public void setInfoSourceWay(String infoSourceWay) {
		this.infoSourceWay = infoSourceWay;
	}

	@Column(name = "GEOGRAPHY_COORDINATE", length = 100)
	public String getGeographyCoordinate() {
		return this.geographyCoordinate;
	}

	public void setGeographyCoordinate(String geographyCoordinate) {
		this.geographyCoordinate = geographyCoordinate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "REG_COUNTRY_CODE", length = 4)
	public String getRegCountryCode() {
		return this.regCountryCode;
	}

	public void setRegCountryCode(String regCountryCode) {
		this.regCountryCode = regCountryCode;
	}

	@Column(name = "IS_FOREIGN_ENT", length = 1)
	public String getIsForeignEnt() {
		return this.isForeignEnt;
	}

	public void setIsForeignEnt(String isForeignEnt) {
		this.isForeignEnt = isForeignEnt;
	}

	@Column(name = "REG_PLC_ADDR_EN", length = 100)
	public String getRegPlcAddrEn() {
		return this.regPlcAddrEn;
	}

	public void setRegPlcAddrEn(String regPlcAddrEn) {
		this.regPlcAddrEn = regPlcAddrEn;
	}

	@Column(name = "PERSON_ID", length = 20)
	public String getPersonId() {
		return this.personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	@Column(name = "TRAFFIC_NO", length = 20)
	public String getTrafficNo() {
		return this.trafficNo;
	}

	public void setTrafficNo(String trafficNo) {
		this.trafficNo = trafficNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "TRAFFIC_START_DATE", length = 7)
	public Date getTrafficStartDate() {
		return this.trafficStartDate;
	}

	public void setTrafficStartDate(Date trafficStartDate) {
		this.trafficStartDate = trafficStartDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "TRAFFIC_END_DATE", length = 7)
	public Date getTrafficEndDate() {
		return this.trafficEndDate;
	}

	public void setTrafficEndDate(Date trafficEndDate) {
		this.trafficEndDate = trafficEndDate;
	}

	@Column(name = "OPEN_BANK", length = 100)
	public String getOpenBank() {
		return this.openBank;
	}

	public void setOpenBank(String openBank) {
		this.openBank = openBank;
	}

	@Column(name = "BANK_ACCOUNT", length = 200)
	public String getBankAccount() {
		return this.bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	@Column(name = "ENT_TYPE", length = 1)
	public String getEntType() {
		return this.entType;
	}

	public void setEntType(String entType) {
		this.entType = entType;
	}

	@Column(name = "VERIFIER_CODE", length = 20)
	public String getVerifierCode() {
		return this.verifierCode;
	}

	public void setVerifierCode(String verifierCode) {
		this.verifierCode = verifierCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "AUDIT_TIME", length = 7)
	public Date getAuditTime() {
		return this.auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	@Column(name = "UPDATE_FLAG", length = 1)
	public String getUpdateFlag() {
		return this.updateFlag;
	}

	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}

	@Column(name = "AGENT_TYPE", length = 1)
	public String getAgentType() {
		return this.agentType;
	}

	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}

	@Column(name = "FOREIGN_TRADE_NO", length = 50)
	public String getForeignTradeNo() {
		return this.foreignTradeNo;
	}

	public void setForeignTradeNo(String foreignTradeNo) {
		this.foreignTradeNo = foreignTradeNo;
	}

	@Column(name = "PRODUCT_CERTIFICATE_NO", length = 50)
	public String getProductCertificateNo() {
		return this.productCertificateNo;
	}

	public void setProductCertificateNo(String productCertificateNo) {
		this.productCertificateNo = productCertificateNo;
	}

	@Column(name = "DIRECT_FLAG", length = 1)
	public String getDirectFlag() {
		return this.directFlag;
	}

	public void setDirectFlag(String directFlag) {
		this.directFlag = directFlag;
	}

	@Column(name = "AUTO_PASS_FLAG", length = 1)
	public String getAutoPassFlag() {
		return this.autoPassFlag;
	}

	public void setAutoPassFlag(String autoPassFlag) {
		this.autoPassFlag = autoPassFlag;
	}

	@Column(name = "PASSWORD", length = 64)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CERT_FIRST_DATE", length = 7)
	public Date getCertFirstDate() {
		return this.certFirstDate;
	}

	public void setCertFirstDate(Date certFirstDate) {
		this.certFirstDate = certFirstDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CERT_START_DATE", length = 7)
	public Date getCertStartDate() {
		return this.certStartDate;
	}

	public void setCertStartDate(Date certStartDate) {
		this.certStartDate = certStartDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CERT_END_DATE", length = 7)
	public Date getCertEndDate() {
		return this.certEndDate;
	}

	public void setCertEndDate(Date certEndDate) {
		this.certEndDate = certEndDate;
	}

	@Column(name = "ENT_OLD_CODE", length = 10)
	public String getEntOldCode() {
		return this.entOldCode;
	}

	public void setEntOldCode(String entOldCode) {
		this.entOldCode = entOldCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ANNUAL_DATE", length = 7)
	public Date getAnnualDate() {
		return this.annualDate;
	}

	public void setAnnualDate(Date annualDate) {
		this.annualDate = annualDate;
	}

	@Column(name = "AUUN_EXAM_CONCL", length = 100)
	public String getAuunExamConcl() {
		return this.auunExamConcl;
	}

	public void setAuunExamConcl(String auunExamConcl) {
		this.auunExamConcl = auunExamConcl;
	}

	@Column(name = "IS_RECORDED", length = 1)
	public String getIsRecorded() {
		return this.isRecorded;
	}

	public void setIsRecorded(String isRecorded) {
		this.isRecorded = isRecorded;
	}

	@Column(name = "BRANCH_PRINCIPAL", length = 20)
	public String getBranchPrincipal() {
		return this.branchPrincipal;
	}

	public void setBranchPrincipal(String branchPrincipal) {
		this.branchPrincipal = branchPrincipal;
	}

	@Column(name = "BRANCH_PRINCIPAL_PHONE", length = 20)
	public String getBranchPrincipalPhone() {
		return this.branchPrincipalPhone;
	}

	public void setBranchPrincipalPhone(String branchPrincipalPhone) {
		this.branchPrincipalPhone = branchPrincipalPhone;
	}

	@Column(name = "BRANCH_PRINCIPAL_FAX", length = 20)
	public String getBranchPrincipalFax() {
		return this.branchPrincipalFax;
	}

	public void setBranchPrincipalFax(String branchPrincipalFax) {
		this.branchPrincipalFax = branchPrincipalFax;
	}

	@Column(name = "TRAFFIC_NONLEGAL_NO", length = 20)
	public String getTrafficNonlegalNo() {
		return this.trafficNonlegalNo;
	}

	public void setTrafficNonlegalNo(String trafficNonlegalNo) {
		this.trafficNonlegalNo = trafficNonlegalNo;
	}

	@Column(name = "SYSTEM_AUTHENTICATIONS", length = 50)
	public String getSystemAuthentications() {
		return this.systemAuthentications;
	}

	public void setSystemAuthentications(String systemAuthentications) {
		this.systemAuthentications = systemAuthentications;
	}

	@Column(name = "OUT_COTTON_ENT_GRADE", length = 100)
	public String getOutCottonEntGrade() {
		return this.outCottonEntGrade;
	}

	public void setOutCottonEntGrade(String outCottonEntGrade) {
		this.outCottonEntGrade = outCottonEntGrade;
	}

	@Column(name = "ADMI_PLACE_CODE", length = 8)
	public String getAdmiPlaceCode() {
		return this.admiPlaceCode;
	}

	public void setAdmiPlaceCode(String admiPlaceCode) {
		this.admiPlaceCode = admiPlaceCode;
	}

	@Column(name = "INVEST_COUNTRY_CODE", length = 4)
	public String getInvestCountryCode() {
		return this.investCountryCode;
	}

	public void setInvestCountryCode(String investCountryCode) {
		this.investCountryCode = investCountryCode;
	}

	@Column(name = "RECORD_VERSION", precision = 22, scale = 0)
	public BigDecimal getRecordVersion() {
		return this.recordVersion;
	}

	public void setRecordVersion(BigDecimal recordVersion) {
		this.recordVersion = recordVersion;
	}

	@Column(name = "VALID_FLAG", length = 1)
	public String getValidFlag() {
		return this.validFlag;
	}

	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag;
	}

	@Column(name = "ORG_TEL", length = 20)
	public String getOrgTel() {
		return this.orgTel;
	}

	public void setOrgTel(String orgTel) {
		this.orgTel = orgTel;
	}

	@Column(name = "IMP_LEVEL_CODE", length = 20)
	public String getImpLevelCode() {
		return this.impLevelCode;
	}

	public void setImpLevelCode(String impLevelCode) {
		this.impLevelCode = impLevelCode;
	}

	@Column(name = "PAY_MODE_CODE", length = 4)
	public String getPayModeCode() {
		return this.payModeCode;
	}

	public void setPayModeCode(String payModeCode) {
		this.payModeCode = payModeCode;
	}

	@Column(name = "CIQ_REG_NO", length = 20)
	public String getCiqRegNo() {
		return this.ciqRegNo;
	}

	public void setCiqRegNo(String ciqRegNo) {
		this.ciqRegNo = ciqRegNo;
	}

	@Column(name = "SAFETY_BASE_ZONE", length = 100)
	public String getSafetyBaseZone() {
		return this.safetyBaseZone;
	}

	public void setSafetyBaseZone(String safetyBaseZone) {
		this.safetyBaseZone = safetyBaseZone;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "TIME_FEE_MODE_CODE", length = 4)
	public String getTimeFeeModeCode() {
		return this.timeFeeModeCode;
	}

	public void setTimeFeeModeCode(String timeFeeModeCode) {
		this.timeFeeModeCode = timeFeeModeCode;
	}

	@Column(name = "ENT_ORG_CODE_NEW", length = 20)
	public String getEntOrgCodeNew() {
		return this.entOrgCodeNew;
	}

	public void setEntOrgCodeNew(String entOrgCodeNew) {
		this.entOrgCodeNew = entOrgCodeNew;
	}

	@Column(name = "OPER_NAME", length = 500)
	public String getOperName() {
		return this.operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	@Column(name = "OPER_ORG_CODE", length = 20)
	public String getOperOrgCode() {
		return this.operOrgCode;
	}

	public void setOperOrgCode(String operOrgCode) {
		this.operOrgCode = operOrgCode;
	}

	@Column(name = "OPER_DEPT_CODE", length = 20)
	public String getOperDeptCode() {
		return this.operDeptCode;
	}

	public void setOperDeptCode(String operDeptCode) {
		this.operDeptCode = operDeptCode;
	}

	@Column(name = "SEND_FLAG", length = 1)
	public String getSendFlag() {
		return this.sendFlag;
	}

	public void setSendFlag(String sendFlag) {
		this.sendFlag = sendFlag;
	}

	@Column(name = "ENT_ORG_PWD", length = 100)
	public String getEntOrgPwd() {
		return this.entOrgPwd;
	}

	public void setEntOrgPwd(String entOrgPwd) {
		this.entOrgPwd = entOrgPwd;
	}

	@Column(name = "ENT_ORG_REGISTER", length = 1)
	public String getEntOrgRegister() {
		return this.entOrgRegister;
	}

	public void setEntOrgRegister(String entOrgRegister) {
		this.entOrgRegister = entOrgRegister;
	}

}

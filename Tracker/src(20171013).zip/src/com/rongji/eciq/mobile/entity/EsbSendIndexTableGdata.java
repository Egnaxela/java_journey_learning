package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * EsbSendIndexTableGdata entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "ESB_SEND_INDEX_TABLE_GDATA")
public class EsbSendIndexTableGdata implements java.io.Serializable {

	// Fields

	private String ediSendIndexId;
	private String sourceAppId;
	private String destAppId;
	private String reportType;
	private String tableName;
	private String condition;
	private String messageSourceType;
	private String messageSource;
	private String messageDestType;
	private String messageDest;
	private Date sendDate;
	private String status;
	private String actionType;
	private String additional1;
	private String additional2;
	private String additional3;
	private String operatorIp;
	private String filterCondition;
	private String bizField1;
	private String bizField2;
	private String bizField3;
	private String accountId;
	private String orderFlag;
	private String locationQueryId;
	private String authEntityId;
	private String authType;
	private String sourceDomainId;
	private String destinationDomainId;
	private String authPassword;
	private String drId;
	private String isMove;
	private Date lastHandleTime;

	// Constructors

	/** default constructor */
	public EsbSendIndexTableGdata() {
	}

	/** minimal constructor */
	public EsbSendIndexTableGdata(String ediSendIndexId, String sourceAppId,
			String destAppId, String reportType, String tableName,
			String condition, String messageSource, Date sendDate,
			String status, String actionType) {
		this.ediSendIndexId = ediSendIndexId;
		this.sourceAppId = sourceAppId;
		this.destAppId = destAppId;
		this.reportType = reportType;
		this.tableName = tableName;
		this.condition = condition;
		this.messageSource = messageSource;
		this.sendDate = sendDate;
		this.status = status;
		this.actionType = actionType;
	}

	/** full constructor */
	public EsbSendIndexTableGdata(String ediSendIndexId, String sourceAppId,
			String destAppId, String reportType, String tableName,
			String condition, String messageSourceType, String messageSource,
			String messageDestType, String messageDest, Date sendDate,
			String status, String actionType, String additional1,
			String additional2, String additional3, String operatorIp,
			String filterCondition, String bizField1, String bizField2,
			String bizField3, String accountId, String orderFlag,
			String locationQueryId, String authEntityId, String authType,
			String sourceDomainId, String destinationDomainId,
			String authPassword, String drId, String isMove, Date lastHandleTime) {
		this.ediSendIndexId = ediSendIndexId;
		this.sourceAppId = sourceAppId;
		this.destAppId = destAppId;
		this.reportType = reportType;
		this.tableName = tableName;
		this.condition = condition;
		this.messageSourceType = messageSourceType;
		this.messageSource = messageSource;
		this.messageDestType = messageDestType;
		this.messageDest = messageDest;
		this.sendDate = sendDate;
		this.status = status;
		this.actionType = actionType;
		this.additional1 = additional1;
		this.additional2 = additional2;
		this.additional3 = additional3;
		this.operatorIp = operatorIp;
		this.filterCondition = filterCondition;
		this.bizField1 = bizField1;
		this.bizField2 = bizField2;
		this.bizField3 = bizField3;
		this.accountId = accountId;
		this.orderFlag = orderFlag;
		this.locationQueryId = locationQueryId;
		this.authEntityId = authEntityId;
		this.authType = authType;
		this.sourceDomainId = sourceDomainId;
		this.destinationDomainId = destinationDomainId;
		this.authPassword = authPassword;
		this.drId = drId;
		this.isMove = isMove;
		this.lastHandleTime = lastHandleTime;
	}

	// Property accessors
	@Id
	@Column(name = "EDI_SEND_INDEX_ID", unique = true, nullable = false, length = 128)
	public String getEdiSendIndexId() {
		return this.ediSendIndexId;
	}

	public void setEdiSendIndexId(String ediSendIndexId) {
		this.ediSendIndexId = ediSendIndexId;
	}

	@Column(name = "SOURCE_APP_ID", nullable = false, length = 10)
	public String getSourceAppId() {
		return this.sourceAppId;
	}

	public void setSourceAppId(String sourceAppId) {
		this.sourceAppId = sourceAppId;
	}

	@Column(name = "DEST_APP_ID", nullable = false, length = 10)
	public String getDestAppId() {
		return this.destAppId;
	}

	public void setDestAppId(String destAppId) {
		this.destAppId = destAppId;
	}

	@Column(name = "REPORT_TYPE", nullable = false, length = 100)
	public String getReportType() {
		return this.reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	@Column(name = "TABLE_NAME", nullable = false, length = 100)
	public String getTableName() {
		return this.tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Column(name = "CONDITION", nullable = false, length = 1024)
	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	@Column(name = "MESSAGE_SOURCE_TYPE", length = 1)
	public String getMessageSourceType() {
		return this.messageSourceType;
	}

	public void setMessageSourceType(String messageSourceType) {
		this.messageSourceType = messageSourceType;
	}

	@Column(name = "MESSAGE_SOURCE", nullable = false, length = 50)
	public String getMessageSource() {
		return this.messageSource;
	}

	public void setMessageSource(String messageSource) {
		this.messageSource = messageSource;
	}

	@Column(name = "MESSAGE_DEST_TYPE", length = 1)
	public String getMessageDestType() {
		return this.messageDestType;
	}

	public void setMessageDestType(String messageDestType) {
		this.messageDestType = messageDestType;
	}

	@Column(name = "MESSAGE_DEST", length = 50)
	public String getMessageDest() {
		return this.messageDest;
	}

	public void setMessageDest(String messageDest) {
		this.messageDest = messageDest;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SEND_DATE", nullable = false, length = 7)
	public Date getSendDate() {
		return this.sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	@Column(name = "STATUS", nullable = false, length = 1)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ACTION_TYPE", nullable = false, length = 20)
	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	@Column(name = "ADDITIONAL1", length = 1024)
	public String getAdditional1() {
		return this.additional1;
	}

	public void setAdditional1(String additional1) {
		this.additional1 = additional1;
	}

	@Column(name = "ADDITIONAL2", length = 1024)
	public String getAdditional2() {
		return this.additional2;
	}

	public void setAdditional2(String additional2) {
		this.additional2 = additional2;
	}

	@Column(name = "ADDITIONAL3", length = 1024)
	public String getAdditional3() {
		return this.additional3;
	}

	public void setAdditional3(String additional3) {
		this.additional3 = additional3;
	}

	@Column(name = "OPERATOR_IP", length = 32)
	public String getOperatorIp() {
		return this.operatorIp;
	}

	public void setOperatorIp(String operatorIp) {
		this.operatorIp = operatorIp;
	}

	@Column(name = "FILTER_CONDITION", length = 1024)
	public String getFilterCondition() {
		return this.filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}

	@Column(name = "BIZ_FIELD1", length = 100)
	public String getBizField1() {
		return this.bizField1;
	}

	public void setBizField1(String bizField1) {
		this.bizField1 = bizField1;
	}

	@Column(name = "BIZ_FIELD2", length = 100)
	public String getBizField2() {
		return this.bizField2;
	}

	public void setBizField2(String bizField2) {
		this.bizField2 = bizField2;
	}

	@Column(name = "BIZ_FIELD3", length = 100)
	public String getBizField3() {
		return this.bizField3;
	}

	public void setBizField3(String bizField3) {
		this.bizField3 = bizField3;
	}

	@Column(name = "ACCOUNT_ID", length = 128)
	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	@Column(name = "ORDER_FLAG", length = 1)
	public String getOrderFlag() {
		return this.orderFlag;
	}

	public void setOrderFlag(String orderFlag) {
		this.orderFlag = orderFlag;
	}

	@Column(name = "LOCATION_QUERY_ID", length = 128)
	public String getLocationQueryId() {
		return this.locationQueryId;
	}

	public void setLocationQueryId(String locationQueryId) {
		this.locationQueryId = locationQueryId;
	}

	@Column(name = "AUTH_ENTITY_ID", length = 128)
	public String getAuthEntityId() {
		return this.authEntityId;
	}

	public void setAuthEntityId(String authEntityId) {
		this.authEntityId = authEntityId;
	}

	@Column(name = "AUTH_TYPE", length = 1)
	public String getAuthType() {
		return this.authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	@Column(name = "SOURCE_DOMAIN_ID", length = 128)
	public String getSourceDomainId() {
		return this.sourceDomainId;
	}

	public void setSourceDomainId(String sourceDomainId) {
		this.sourceDomainId = sourceDomainId;
	}

	@Column(name = "DESTINATION_DOMAIN_ID", length = 128)
	public String getDestinationDomainId() {
		return this.destinationDomainId;
	}

	public void setDestinationDomainId(String destinationDomainId) {
		this.destinationDomainId = destinationDomainId;
	}

	@Column(name = "AUTH_PASSWORD", length = 128)
	public String getAuthPassword() {
		return this.authPassword;
	}

	public void setAuthPassword(String authPassword) {
		this.authPassword = authPassword;
	}

	@Column(name = "DR_ID", length = 20)
	public String getDrId() {
		return this.drId;
	}

	public void setDrId(String drId) {
		this.drId = drId;
	}

	@Column(name = "IS_MOVE", length = 1)
	public String getIsMove() {
		return this.isMove;
	}

	public void setIsMove(String isMove) {
		this.isMove = isMove;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_HANDLE_TIME", length = 7)
	public Date getLastHandleTime() {
		return this.lastHandleTime;
	}

	public void setLastHandleTime(Date lastHandleTime) {
		this.lastHandleTime = lastHandleTime;
	}

}
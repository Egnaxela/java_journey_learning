package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "INS_AUTHENTICATE_PROC")
public class InsAuthenticateProcEntity implements
java.io.Serializable {

// Fields

private String authenticateProcId;
private String declNo;
private String declPerson;
private String inspOrgCode;
private String inspDeptCode;
private String inspModeCode;
private String externalOrgCode;
private String falgArchive;
private Date operTime;
private Date archiveTime;
private String isAuthFlag;

// Constructors

/** default constructor */
public InsAuthenticateProcEntity() {
}

/** minimal constructor */
public InsAuthenticateProcEntity(String authenticateProcId, String declNo) {
this.authenticateProcId = authenticateProcId;
this.declNo = declNo;
}

/** full constructor */
public InsAuthenticateProcEntity(String authenticateProcId,
	String declNo, String declPerson, String inspOrgCode,
	String inspDeptCode, String inspModeCode, String externalOrgCode,
	String falgArchive, Date operTime, Date archiveTime,
	String isAuthFlag) {
this.authenticateProcId = authenticateProcId;
this.declNo = declNo;
this.declPerson = declPerson;
this.inspOrgCode = inspOrgCode;
this.inspDeptCode = inspDeptCode;
this.inspModeCode = inspModeCode;
this.externalOrgCode = externalOrgCode;
this.falgArchive = falgArchive;
this.operTime = operTime;
this.archiveTime = archiveTime;
this.isAuthFlag = isAuthFlag;
}

// Property accessors
@Id
@Column(name = "AUTHENTICATE_PROC_ID", unique = true, nullable = false, length = 32)
public String getAuthenticateProcId() {
return this.authenticateProcId;
}

public void setAuthenticateProcId(String authenticateProcId) {
this.authenticateProcId = authenticateProcId;
}

@Column(name = "DECL_NO", nullable = false, length = 20)
public String getDeclNo() {
return this.declNo;
}

public void setDeclNo(String declNo) {
this.declNo = declNo;
}

@Column(name = "DECL_PERSON", length = 20)
public String getDeclPerson() {
return this.declPerson;
}

public void setDeclPerson(String declPerson) {
this.declPerson = declPerson;
}

@Column(name = "INSP_ORG_CODE", length = 10)
public String getInspOrgCode() {
return this.inspOrgCode;
}

public void setInspOrgCode(String inspOrgCode) {
this.inspOrgCode = inspOrgCode;
}

@Column(name = "INSP_DEPT_CODE", length = 10)
public String getInspDeptCode() {
return this.inspDeptCode;
}

public void setInspDeptCode(String inspDeptCode) {
this.inspDeptCode = inspDeptCode;
}

@Column(name = "INSP_MODE_CODE", length = 1)
public String getInspModeCode() {
return this.inspModeCode;
}

public void setInspModeCode(String inspModeCode) {
this.inspModeCode = inspModeCode;
}

@Column(name = "EXTERNAL_ORG_CODE", length = 10)
public String getExternalOrgCode() {
return this.externalOrgCode;
}

public void setExternalOrgCode(String externalOrgCode) {
this.externalOrgCode = externalOrgCode;
}

@Column(name = "FALG_ARCHIVE", length = 1)
public String getFalgArchive() {
return this.falgArchive;
}

public void setFalgArchive(String falgArchive) {
this.falgArchive = falgArchive;
}

@Temporal(TemporalType.DATE)
@Column(name = "OPER_TIME", length = 7)
public Date getOperTime() {
return this.operTime;
}

public void setOperTime(Date operTime) {
this.operTime = operTime;
}

@Temporal(TemporalType.DATE)
@Column(name = "ARCHIVE_TIME", length = 7)
public Date getArchiveTime() {
return this.archiveTime;
}

public void setArchiveTime(Date archiveTime) {
this.archiveTime = archiveTime;
}

@Column(name = "IS_AUTH_FLAG", length = 1)
public String getIsAuthFlag() {
return this.isAuthFlag;
}

public void setIsAuthFlag(String isAuthFlag) {
this.isAuthFlag = isAuthFlag;
}

}
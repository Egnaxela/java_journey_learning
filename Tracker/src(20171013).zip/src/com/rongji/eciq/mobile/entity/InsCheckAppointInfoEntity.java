package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsCheckAppointInfo entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_CHECK_APPOINT_INFO")
public class InsCheckAppointInfoEntity implements java.io.Serializable {
	
	private static final long serialVersionUID = 696289593301690225L;
	private String applyId;//申请ID
	private String applyNo;//申请单号
	private String applyType;//申请类别
	private Date applyTime;//申请时间
	private String plateNo;//车牌号
	private String contNo;//集装箱号
	private String entOrgCode;//组织机构代码
	private String declRegNo;//报检单位注册号
	private String declRegName;//报检单位名称
	private String inspOrgCode;//施检机构【对本批货物实施检验检疫的机构】
	private String declNo;//报检号
	private Date appointCheckDate;//预约日期
	private String appointCheckPlace;//预约查验地点
	private String appointContactPerson;//预约联系人
	private String appointContactTel;//预约联系电话
	private String remark;//备注
	private String checkOrgCode;//查验机构
	private Date checkDate;//查验日期
	private String checkContactTel;//查验联系电话
	private String checkPerson;//查验人员
	private String applyStatus;//申请状态
	private String acceptResult;//受理结果(0：未审批 1:同意 2：不同意)
	private String acceptRemark;//受理意见
	private Date operDate;//操作时间
	private String approvalPerson;//审批人员
	private Date approvalTime;//审批时间



	// Constructors

	/** default constructor */
	public InsCheckAppointInfoEntity() {
	}

	/** minimal constructor */
	public InsCheckAppointInfoEntity(String applyId) {
		this.applyId = applyId;
	}

	/** full constructor */
	public InsCheckAppointInfoEntity(String applyId, String applyNo,
			String applyType, Date applyTime, String plateNo,
			String contNo, String declRegNo, String declRegName,
			String inspOrgCode, String declNo, Date appointCheckDate,
			String appointCheckPlace, String appointContactPerson,
			String appointContactTel, String remark, String checkOrgCode,
			Date checkDate, String checkContactTel, String checkPerson,
			String applyStatus, String acceptResult, String acceptRemark,
			Date operDate) {
		this.applyId = applyId;
		this.applyNo = applyNo;
		this.applyType = applyType;
		this.applyTime = applyTime;
		this.plateNo = plateNo;
		this.contNo = contNo;
		this.declRegNo = declRegNo;
		this.declRegName = declRegName;
		this.inspOrgCode = inspOrgCode;
		this.declNo = declNo;
		this.appointCheckDate = appointCheckDate;
		this.appointCheckPlace = appointCheckPlace;
		this.appointContactPerson = appointContactPerson;
		this.appointContactTel = appointContactTel;
		this.remark = remark;
		this.checkOrgCode = checkOrgCode;
		this.checkDate = checkDate;
		this.checkContactTel = checkContactTel;
		this.checkPerson = checkPerson;
		this.applyStatus = applyStatus;
		this.acceptResult = acceptResult;
		this.acceptRemark = acceptRemark;
		this.operDate = operDate;
	}

	// Property accessors
	@Id
	@Column(name = "APPLY_ID", unique = true, nullable = false, length = 32)
	public String getApplyId() {
		return this.applyId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	@Column(name = "APPLY_NO", length = 40)
	public String getApplyNo() {
		return this.applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	@Column(name = "APPLY_TYPE", length = 1)
	public String getApplyType() {
		return this.applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	@Column(name = "APPLY_TIME", length = 7)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getApplyTime() {
		return this.applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	@Column(name = "PLATE_NO", length = 50)
	public String getPlateNo() {
		return this.plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	@Column(name = "CONT_NO", length = 2000)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "ENT_ORG_CODE", length = 20)
	public String getEntOrgCode() {
		return entOrgCode;
	}

	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}

	@Column(name = "DECL_REG_NO", length = 20)
	public String getDeclRegNo() {
		return this.declRegNo;
	}

	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}

	@Column(name = "DECL_REG_NAME", length = 100)
	public String getDeclRegName() {
		return this.declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	@Column(name = "INSP_ORG_CODE", length = 20)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "APPOINT_CHECK_DATE", length = 7)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getAppointCheckDate() {
		return this.appointCheckDate;
	}

	public void setAppointCheckDate(Date date) {
		this.appointCheckDate = date;
	}

	@Column(name = "APPOINT_CHECK_PLACE", length = 100)
	public String getAppointCheckPlace() {
		return this.appointCheckPlace;
	}

	public void setAppointCheckPlace(String appointCheckPlace) {
		this.appointCheckPlace = appointCheckPlace;
	}

	@Column(name = "APPOINT_CONTACT_PERSON", length = 20)
	public String getAppointContactPerson() {
		return this.appointContactPerson;
	}

	public void setAppointContactPerson(String appointContactPerson) {
		this.appointContactPerson = appointContactPerson;
	}

	@Column(name = "APPOINT_CONTACT_TEL", length = 20)
	public String getAppointContactTel() {
		return this.appointContactTel;
	}

	public void setAppointContactTel(String appointContactTel) {
		this.appointContactTel = appointContactTel;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "CHECK_ORG_CODE", length = 10)
	public String getCheckOrgCode() {
		return this.checkOrgCode;
	}

	public void setCheckOrgCode(String checkOrgCode) {
		this.checkOrgCode = checkOrgCode;
	}

	@Column(name = "CHECK_DATE", length = 7)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCheckDate() {
		return this.checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	@Column(name = "CHECK_CONTACT_TEL", length = 20)
	public String getCheckContactTel() {
		return this.checkContactTel;
	}

	public void setCheckContactTel(String checkContactTel) {
		this.checkContactTel = checkContactTel;
	}

	@Column(name = "CHECK_PERSON", length = 100)
	public String getCheckPerson() {
		return this.checkPerson;
	}

	public void setCheckPerson(String checkPerson) {
		this.checkPerson = checkPerson;
	}

	@Column(name = "APPLY_STATUS", length = 1)
	public String getApplyStatus() {
		return this.applyStatus;
	}

	public void setApplyStatus(String applyStatus) {
		this.applyStatus = applyStatus;
	}

	@Column(name = "ACCEPT_RESULT", length = 1)
	public String getAcceptResult() {
		return this.acceptResult;
	}

	public void setAcceptResult(String acceptResult) {
		this.acceptResult = acceptResult;
	}

	@Column(name = "ACCEPT_REMARK", length = 1000)
	public String getAcceptRemark() {
		return this.acceptRemark;
	}

	public void setAcceptRemark(String acceptRemark) {
		this.acceptRemark = acceptRemark;
	}

	@Column(name = "OPER_DATE", length = 7)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}
	@Column(name = "APPROVAL_PERSON", length = 100)
	public String getApprovalPerson() {
		return approvalPerson;
	}

	public void setApprovalPerson(String approvalPerson) {
		this.approvalPerson = approvalPerson;
	}
	@Column(name = "APPROVAL_TIME", length = 7)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getApprovalTime() {
		return approvalTime;
	}

	public void setApprovalTime(Date approvalTime) {
		this.approvalTime = approvalTime;
	}
	
	

}
package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsCheckCommand entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_CHECK_COMMAND")
public class InsCheckCommand implements java.io.Serializable {

	// Fields

	private String checkCmdId;
	private String declNo;
	private String checkSiteCode;
	private String checkSiteName;
	private String exeInspOrgCode;
	private String inspDeptCode;
	private String falgArchive;
	private Date operTime;
	private String releaseNo;
	private String isCheckFinished;
	private Date checkDate;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public InsCheckCommand() {
	}

	/** minimal constructor */
	public InsCheckCommand(String checkCmdId, String declNo) {
		this.checkCmdId = checkCmdId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsCheckCommand(String checkCmdId, String declNo, String checkSiteCode, String checkSiteName, String exeInspOrgCode, String inspDeptCode, String falgArchive, Date operTime, String releaseNo, String isCheckFinished, Date checkDate, Date archiveTime) {
		this.checkCmdId = checkCmdId;
		this.declNo = declNo;
		this.checkSiteCode = checkSiteCode;
		this.checkSiteName = checkSiteName;
		this.exeInspOrgCode = exeInspOrgCode;
		this.inspDeptCode = inspDeptCode;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.releaseNo = releaseNo;
		this.isCheckFinished = isCheckFinished;
		this.checkDate = checkDate;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "CHECK_CMD_ID", unique = true, nullable = false, length = 32)
	public String getCheckCmdId() {
		return this.checkCmdId;
	}

	public void setCheckCmdId(String checkCmdId) {
		this.checkCmdId = checkCmdId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "CHECK_SITE_CODE", length = 20)
	public String getCheckSiteCode() {
		return this.checkSiteCode;
	}

	public void setCheckSiteCode(String checkSiteCode) {
		this.checkSiteCode = checkSiteCode;
	}

	@Column(name = "CHECK_SITE_NAME", length = 100)
	public String getCheckSiteName() {
		return this.checkSiteName;
	}

	public void setCheckSiteName(String checkSiteName) {
		this.checkSiteName = checkSiteName;
	}

	@Column(name = "EXE_INSP_ORG_CODE", length = 10)
	public String getExeInspOrgCode() {
		return this.exeInspOrgCode;
	}

	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}

	@Column(name = "INSP_DEPT_CODE", length = 10)
	public String getInspDeptCode() {
		return this.inspDeptCode;
	}

	public void setInspDeptCode(String inspDeptCode) {
		this.inspDeptCode = inspDeptCode;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "RELEASE_NO", length = 32)
	public String getReleaseNo() {
		return this.releaseNo;
	}

	public void setReleaseNo(String releaseNo) {
		this.releaseNo = releaseNo;
	}

	@Column(name = "IS_CHECK_FINISHED", length = 1)
	public String getIsCheckFinished() {
		return this.isCheckFinished;
	}

	public void setIsCheckFinished(String isCheckFinished) {
		this.isCheckFinished = isCheckFinished;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CHECK_DATE", length = 7)
	public Date getCheckDate() {
		return this.checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

}
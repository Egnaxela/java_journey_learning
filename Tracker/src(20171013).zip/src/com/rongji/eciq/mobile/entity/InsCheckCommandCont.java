package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsCheckCommandCont entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_CHECK_COMMAND_CONT")
public class InsCheckCommandCont implements java.io.Serializable {

	// Fields

	private String checkCmdContId;
	private String checkCmdId;
	private String contNo;
	private String falgArchive;
	private Date operTime;
	private String isCheck;
	private String ifDrawBox;
	private String ifOpenBox;
	private String goodsNos;
	private String goodsNames;
	private Date archiveTime;
	private String cntnrModeCode;

	// Constructors

	/** default constructor */
	public InsCheckCommandCont() {
	}

	/** minimal constructor */
	public InsCheckCommandCont(String checkCmdContId, String checkCmdId) {
		this.checkCmdContId = checkCmdContId;
		this.checkCmdId = checkCmdId;
	}

	/** full constructor */
	public InsCheckCommandCont(String checkCmdContId, String checkCmdId, String contNo, String falgArchive, Date operTime, String isCheck, String ifDrawBox, String ifOpenBox, String goodsNos, String goodsNames, Date archiveTime, String cntnrModeCode) {
		this.checkCmdContId = checkCmdContId;
		this.checkCmdId = checkCmdId;
		this.contNo = contNo;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.isCheck = isCheck;
		this.ifDrawBox = ifDrawBox;
		this.ifOpenBox = ifOpenBox;
		this.goodsNos = goodsNos;
		this.goodsNames = goodsNames;
		this.archiveTime = archiveTime;
		this.cntnrModeCode = cntnrModeCode;
	}

	// Property accessors
	@Id
	@Column(name = "CHECK_CMD_CONT_ID", unique = true, nullable = false, length = 32)
	public String getCheckCmdContId() {
		return this.checkCmdContId;
	}

	public void setCheckCmdContId(String checkCmdContId) {
		this.checkCmdContId = checkCmdContId;
	}

	@Column(name = "CHECK_CMD_ID", nullable = false, length = 32)
	public String getCheckCmdId() {
		return this.checkCmdId;
	}

	public void setCheckCmdId(String checkCmdId) {
		this.checkCmdId = checkCmdId;
	}

	@Column(name = "CONT_NO", length = 100)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "IS_CHECK", length = 1)
	public String getIsCheck() {
		return this.isCheck;
	}

	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}

	@Column(name = "IF_DRAW_BOX", length = 1)
	public String getIfDrawBox() {
		return this.ifDrawBox;
	}

	public void setIfDrawBox(String ifDrawBox) {
		this.ifDrawBox = ifDrawBox;
	}

	@Column(name = "IF_OPEN_BOX", length = 1)
	public String getIfOpenBox() {
		return this.ifOpenBox;
	}

	public void setIfOpenBox(String ifOpenBox) {
		this.ifOpenBox = ifOpenBox;
	}

	@Column(name = "GOODS_NOS", length = 200)
	public String getGoodsNos() {
		return this.goodsNos;
	}

	public void setGoodsNos(String goodsNos) {
		this.goodsNos = goodsNos;
	}

	@Column(name = "GOODS_NAMES", length = 4000)
	public String getGoodsNames() {
		return this.goodsNames;
	}

	public void setGoodsNames(String goodsNames) {
		this.goodsNames = goodsNames;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "CNTNR_MODE_CODE", length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

}
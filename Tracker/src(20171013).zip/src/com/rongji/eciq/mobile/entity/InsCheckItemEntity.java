package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * InsCheckItem entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_CHECK_ITEM")
public class InsCheckItemEntity implements java.io.Serializable {
	private static final long serialVersionUID = 8298020164196570992L;
	private String checkItemId;
	private String declNo;
	private Double goodsNo;
	private String checkItemCode;
	private String checkItemName;
	private String checkItemResultCode;
	private String parentItemCode;
	private String parentItemName;
	private String batchDesc;
	private String inspProcStatus;
	private String falgArchive;
	private Timestamp operTime;
	private String sampleSch;
	private String whetherQualfy;
	private Timestamp archiveTime;
	private String checkFormCode;
	private String isAppFlag;
	private String scOrgCode;
	private String scOperatorCode;
	private String itemTypeCode;
	private String addInputFlag;
	private String checkCont;
	private String checkGoodsType;
	private String nodeCode;
//	@Transient
//	private String formName;

	// Constructors

	/** default constructor */
	public InsCheckItemEntity() {
	}

	/** minimal constructor */
	public InsCheckItemEntity(String checkItemId, String declNo) {
		this.checkItemId = checkItemId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsCheckItemEntity(String checkItemId, String declNo, Double goodsNo,
			String checkItemCode, String checkItemName,
			String checkItemResultCode, String parentItemCode,
			String parentItemName, String batchDesc, String inspProcStatus,
			String falgArchive, Timestamp operTime, String sampleSch,
			String whetherQualfy, Timestamp archiveTime, String checkFormCode,
			String isAppFlag, String scOrgCode, String scOperatorCode,
			String itemTypeCode, String addInputFlag, String checkCont,
			String checkGoodsType, String nodeCode, String formName) {
		this.checkItemId = checkItemId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.checkItemCode = checkItemCode;
		this.checkItemName = checkItemName;
		this.checkItemResultCode = checkItemResultCode;
		this.parentItemCode = parentItemCode;
		this.parentItemName = parentItemName;
		this.batchDesc = batchDesc;
		this.inspProcStatus = inspProcStatus;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.sampleSch = sampleSch;
		this.whetherQualfy = whetherQualfy;
		this.archiveTime = archiveTime;
		this.checkFormCode = checkFormCode;
		this.isAppFlag = isAppFlag;
		this.scOrgCode = scOrgCode;
		this.scOperatorCode = scOperatorCode;
		this.itemTypeCode = itemTypeCode;
		this.addInputFlag = addInputFlag;
		this.checkCont = checkCont;
		this.checkGoodsType = checkGoodsType;
		this.nodeCode = nodeCode;
//		this.formName = formName;
	}

	// Property accessors
	@Id
	@Column(name = "CHECK_ITEM_ID", unique = true, nullable = false, length = 32)
	public String getCheckItemId() {
		return this.checkItemId;
	}

	public void setCheckItemId(String checkItemId) {
		this.checkItemId = checkItemId;
	}
	
//	public String getFormName() {
//		return this.formName;
//	}
//
//	public void setFormName(String formName) {
//		this.formName = formName;
//	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "CHECK_ITEM_CODE", length = 20)
	public String getCheckItemCode() {
		return this.checkItemCode;
	}

	public void setCheckItemCode(String checkItemCode) {
		this.checkItemCode = checkItemCode;
	}

	@Column(name = "CHECK_ITEM_NAME", length = 500)
	public String getCheckItemName() {
		return this.checkItemName;
	}

	public void setCheckItemName(String checkItemName) {
		this.checkItemName = checkItemName;
	}

	@Column(name = "CHECK_ITEM_RESULT_CODE", length = 2)
	public String getCheckItemResultCode() {
		return this.checkItemResultCode;
	}

	public void setCheckItemResultCode(String checkItemResultCode) {
		this.checkItemResultCode = checkItemResultCode;
	}

	@Column(name = "PARENT_ITEM_CODE", length = 50)
	public String getParentItemCode() {
		return this.parentItemCode;
	}

	public void setParentItemCode(String parentItemCode) {
		this.parentItemCode = parentItemCode;
	}

	@Column(name = "PARENT_ITEM_NAME", length = 50)
	public String getParentItemName() {
		return this.parentItemName;
	}

	public void setParentItemName(String parentItemName) {
		this.parentItemName = parentItemName;
	}

	@Column(name = "BATCH_DESC", length = 200)
	public String getBatchDesc() {
		return this.batchDesc;
	}

	public void setBatchDesc(String batchDesc) {
		this.batchDesc = batchDesc;
	}

	@Column(name = "INSP_PROC_STATUS", length = 1)
	public String getInspProcStatus() {
		return this.inspProcStatus;
	}

	public void setInspProcStatus(String inspProcStatus) {
		this.inspProcStatus = inspProcStatus;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "SAMPLE_SCH", length = 200)
	public String getSampleSch() {
		return this.sampleSch;
	}

	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}

	@Column(name = "WHETHER_QUALFY", length = 1)
	public String getWhetherQualfy() {
		return this.whetherQualfy;
	}

	public void setWhetherQualfy(String whetherQualfy) {
		this.whetherQualfy = whetherQualfy;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "CHECK_FORM_CODE", length = 32)
	public String getCheckFormCode() {
		return this.checkFormCode;
	}

	public void setCheckFormCode(String checkFormCode) {
		this.checkFormCode = checkFormCode;
	}
	@Transient
	@Column(name = "IS_APP_FLAG", length = 1)
	public String getIsAppFlag() {
		return this.isAppFlag;
	}

	public void setIsAppFlag(String isAppFlag) {
		this.isAppFlag = isAppFlag;
	}

	@Column(name = "SC_ORG_CODE", length = 10)
	public String getScOrgCode() {
		return this.scOrgCode;
	}

	public void setScOrgCode(String scOrgCode) {
		this.scOrgCode = scOrgCode;
	}

	@Column(name = "SC_OPERATOR_CODE", length = 20)
	public String getScOperatorCode() {
		return this.scOperatorCode;
	}

	public void setScOperatorCode(String scOperatorCode) {
		this.scOperatorCode = scOperatorCode;
	}

	@Column(name = "ITEM_TYPE_CODE", length = 1)
	public String getItemTypeCode() {
		return this.itemTypeCode;
	}

	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	@Column(name = "ADD_INPUT_FLAG", length = 1)
	public String getAddInputFlag() {
		return this.addInputFlag;
	}

	public void setAddInputFlag(String addInputFlag) {
		this.addInputFlag = addInputFlag;
	}

	@Column(name = "CHECK_CONT", length = 4000)
	public String getCheckCont() {
		return this.checkCont;
	}

	public void setCheckCont(String checkCont) {
		this.checkCont = checkCont;
	}

	@Column(name = "CHECK_GOODS_TYPE", length = 1)
	public String getCheckGoodsType() {
		return this.checkGoodsType;
	}

	public void setCheckGoodsType(String checkGoodsType) {
		this.checkGoodsType = checkGoodsType;
	}

	@Column(name = "NODE_CODE", length = 50)
	public String getNodeCode() {
		return this.nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode;
	}

}
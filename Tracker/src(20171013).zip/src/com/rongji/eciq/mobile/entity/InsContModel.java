/**  
 * FileName:     InsContModel.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 下午2:59:12  
 *  
 */  

package com.rongji.eciq.mobile.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import javax.persistence.Entity;

import org.springframework.data.annotation.Persistent;

import com.itown.rcp.core.db.po.Transient;



/**  
 * Description: 集装箱、货物查验、开掏箱model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 下午2:59:12  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */
@Entity
public class InsContModel implements Serializable{
	@Column(name = "CONT_NO", length = 100)
	private String contNo;
	/*@Transient
	@Column(name = "FALG_ARCHIVE", length = 1)
	private String falgArchive;*/
	/*@Transient
	@Column(name = "LCL_FLAG", length = 1)
	private String lclFlag;*/
	@Column(name = "CNTNR_MODE_CODE", nullable = false, length = 4)
	private String cntnrModeCode;
	@Id
	@Column(name = "CONT_DT_ID", unique = true, nullable = false, length = 32)
	private String contDtId;
	@Column(name = "DECL_NO", nullable = false, length = 20)
	private String declNo;
	/*@Transient
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_DATE")
	private Date operDate;*/
	@Column(name = "IS_CHECK", length = 1)
	private String isCheck;
	@Column(name = "IF_OPEN_BOX", length = 1)
	private String ifOpenBox;
	@Column(name = "IF_DRAW_BOX", length = 1)
	private String ifDrawBox;
	@Column(name = "INS_DRAW_RECORD_ID", unique = true, nullable = false, length = 32)
	private String insDrawRecordId;
	@Column(name = "OPER_CODE", length = 20)
	private String operCode;
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getCntnrModeCode() {
		return cntnrModeCode;
	}
	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}
	public String getContDtId() {
		return contDtId;
	}
	public void setContDtId(String contDtId) {
		this.contDtId = contDtId;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	
	public String getIsCheck() {
		return isCheck;
	}
	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}
	public String getIfOpenBox() {
		return ifOpenBox;
	}
	public void setIfOpenBox(String ifOpenBox) {
		this.ifOpenBox = ifOpenBox;
	}
	public String getIfDrawBox() {
		return ifDrawBox;
	}
	public void setIfDrawBox(String ifDrawBox) {
		this.ifDrawBox = ifDrawBox;
	}
	public String getInsDrawRecordId() {
		return insDrawRecordId;
	}
	public void setInsDrawRecordId(String insDrawRecordId) {
		this.insDrawRecordId = insDrawRecordId;
	}
	public String getOperCode() {
		return operCode;
	}
	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}
	
}

package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsContainerResult entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_CONTAINER_RESULT")
public class InsContainerResultEntity implements java.io.Serializable {

	private static final long serialVersionUID = 3600176128277850049L;
	private String contResultId;
	private String declNo;
	private String cntnrModeCode;
	private Double containerQty;
	private Double dispsCtnrQty;
	private String contTestResEval;
	private String cntnrUnqlResnC;
	private String ctnrOrgCode;
	private String ctnrDeptCode;
	private String cntnrOpertoCode;
	private Timestamp contOpetnTime;
	private String prevtivTreatmt;
	private String cntnrTreatCodes;
	private String sanitTrtMethCodes;
	private String sntTrtOrgCode;
	private String treatDeptCode;
	private String sntTrtOperCode;
	private Timestamp treatOperateDate;
	private String apprslOrgCode;
	private String apprtDeptCode;
	private String idenOperCode;
	private Timestamp apprCondtTime;
	private Double unqulfdQuarQty;
	private Double unqulfCommQty;
	private Double unqualCommQtyCmp;
	private String disquaContCode;
	private String treatUnit;
	private Double declContQty;
	private Double inspContQty;
	private Double contagionContQty;
	private Double faunaFloraContQty;
	private Double detectionContQty;
	private Double healthProcContQty;
	private Double cargInspContQty;
	private String cargDisqualItemOne;
	private String epidSituCatg;
	private String contCategory;
	private String falgArchive;
	private Timestamp operTime;
	private Timestamp archiveTime;
	private String quarUnqualReasonCode;
	private String contNo;
	private String lclFlag;
	private String heavyFlag;
	private String checkQuaFlag;
	private String quaDisposeFlag;
	private String cargInsUnqualFlag;
	private String healthInsUnqualFlag;
	private String quarUnqualContentCodes;
	private String sntTrtFlag;
	private String pamQuaUnqualFlag;
	private String pamUnqualReasonCodes;
	private String pamTrtFlag;
	private String pamTrtMethCodes;
	private String pamTrtOrgCode;
	private String frInfRegFlag;
	private String frPamRegFlag;
	private String billLadNo;
	private String boxCompany;
	private String regNum;
	private String expImpFlag;
	private String tradeCountryCode;
	private String emptyFlag;
	private String contQuarUnqualFlag;
	private String contQuarUnqualDesc;

	// Constructors

	/** default constructor */
	public InsContainerResultEntity() {
	}

	/** minimal constructor */
	public InsContainerResultEntity(String contResultId, String declNo,
			String cntnrModeCode) {
		this.contResultId = contResultId;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
	}

	/** full constructor */
	public InsContainerResultEntity(String contResultId, String declNo,
			String cntnrModeCode, Double containerQty, Double dispsCtnrQty,
			String contTestResEval, String cntnrUnqlResnC, String ctnrOrgCode,
			String ctnrDeptCode, String cntnrOpertoCode,
			Timestamp contOpetnTime, String prevtivTreatmt,
			String cntnrTreatCodes, String sanitTrtMethCodes,
			String sntTrtOrgCode, String treatDeptCode, String sntTrtOperCode,
			Timestamp treatOperateDate, String apprslOrgCode,
			String apprtDeptCode, String idenOperCode, Timestamp apprCondtTime,
			Double unqulfdQuarQty, Double unqulfCommQty,
			Double unqualCommQtyCmp, String disquaContCode, String treatUnit,
			Double declContQty, Double inspContQty, Double contagionContQty,
			Double faunaFloraContQty, Double detectionContQty,
			Double healthProcContQty, Double cargInspContQty,
			String cargDisqualItemOne, String epidSituCatg,
			String contCategory, String falgArchive, Timestamp operTime,
			Timestamp archiveTime, String quarUnqualReasonCode, String contNo,
			String lclFlag, String heavyFlag, String checkQuaFlag,
			String quaDisposeFlag, String cargInsUnqualFlag,
			String healthInsUnqualFlag, String quarUnqualContentCodes,
			String sntTrtFlag, String pamQuaUnqualFlag,
			String pamUnqualReasonCodes, String pamTrtFlag,
			String pamTrtMethCodes, String pamTrtOrgCode, String frInfRegFlag,
			String frPamRegFlag, String billLadNo, String boxCompany,
			String regNum, String expImpFlag, String tradeCountryCode,
			String emptyFlag, String contQuarUnqualFlag,
			String contQuarUnqualDesc) {
		this.contResultId = contResultId;
		this.declNo = declNo;
		this.cntnrModeCode = cntnrModeCode;
		this.containerQty = containerQty;
		this.dispsCtnrQty = dispsCtnrQty;
		this.contTestResEval = contTestResEval;
		this.cntnrUnqlResnC = cntnrUnqlResnC;
		this.ctnrOrgCode = ctnrOrgCode;
		this.ctnrDeptCode = ctnrDeptCode;
		this.cntnrOpertoCode = cntnrOpertoCode;
		this.contOpetnTime = contOpetnTime;
		this.prevtivTreatmt = prevtivTreatmt;
		this.cntnrTreatCodes = cntnrTreatCodes;
		this.sanitTrtMethCodes = sanitTrtMethCodes;
		this.sntTrtOrgCode = sntTrtOrgCode;
		this.treatDeptCode = treatDeptCode;
		this.sntTrtOperCode = sntTrtOperCode;
		this.treatOperateDate = treatOperateDate;
		this.apprslOrgCode = apprslOrgCode;
		this.apprtDeptCode = apprtDeptCode;
		this.idenOperCode = idenOperCode;
		this.apprCondtTime = apprCondtTime;
		this.unqulfdQuarQty = unqulfdQuarQty;
		this.unqulfCommQty = unqulfCommQty;
		this.unqualCommQtyCmp = unqualCommQtyCmp;
		this.disquaContCode = disquaContCode;
		this.treatUnit = treatUnit;
		this.declContQty = declContQty;
		this.inspContQty = inspContQty;
		this.contagionContQty = contagionContQty;
		this.faunaFloraContQty = faunaFloraContQty;
		this.detectionContQty = detectionContQty;
		this.healthProcContQty = healthProcContQty;
		this.cargInspContQty = cargInspContQty;
		this.cargDisqualItemOne = cargDisqualItemOne;
		this.epidSituCatg = epidSituCatg;
		this.contCategory = contCategory;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.archiveTime = archiveTime;
		this.quarUnqualReasonCode = quarUnqualReasonCode;
		this.contNo = contNo;
		this.lclFlag = lclFlag;
		this.heavyFlag = heavyFlag;
		this.checkQuaFlag = checkQuaFlag;
		this.quaDisposeFlag = quaDisposeFlag;
		this.cargInsUnqualFlag = cargInsUnqualFlag;
		this.healthInsUnqualFlag = healthInsUnqualFlag;
		this.quarUnqualContentCodes = quarUnqualContentCodes;
		this.sntTrtFlag = sntTrtFlag;
		this.pamQuaUnqualFlag = pamQuaUnqualFlag;
		this.pamUnqualReasonCodes = pamUnqualReasonCodes;
		this.pamTrtFlag = pamTrtFlag;
		this.pamTrtMethCodes = pamTrtMethCodes;
		this.pamTrtOrgCode = pamTrtOrgCode;
		this.frInfRegFlag = frInfRegFlag;
		this.frPamRegFlag = frPamRegFlag;
		this.billLadNo = billLadNo;
		this.boxCompany = boxCompany;
		this.regNum = regNum;
		this.expImpFlag = expImpFlag;
		this.tradeCountryCode = tradeCountryCode;
		this.emptyFlag = emptyFlag;
		this.contQuarUnqualFlag = contQuarUnqualFlag;
		this.contQuarUnqualDesc = contQuarUnqualDesc;
	}

	// Property accessors
	@Id
	@Column(name = "CONT_RESULT_ID", unique = true, nullable = false, length = 32)
	public String getContResultId() {
		return this.contResultId;
	}

	public void setContResultId(String contResultId) {
		this.contResultId = contResultId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "CNTNR_MODE_CODE", nullable = false, length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

	@Column(name = "CONTAINER_QTY", precision = 0)
	public Double getContainerQty() {
		return this.containerQty;
	}

	public void setContainerQty(Double containerQty) {
		this.containerQty = containerQty;
	}

	@Column(name = "DISPS_CTNR_QTY", precision = 0)
	public Double getDispsCtnrQty() {
		return this.dispsCtnrQty;
	}

	public void setDispsCtnrQty(Double dispsCtnrQty) {
		this.dispsCtnrQty = dispsCtnrQty;
	}

	@Column(name = "CONT_TEST_RES_EVAL", length = 4)
	public String getContTestResEval() {
		return this.contTestResEval;
	}

	public void setContTestResEval(String contTestResEval) {
		this.contTestResEval = contTestResEval;
	}

	@Column(name = "CNTNR_UNQL_RESN_C", length = 100)
	public String getCntnrUnqlResnC() {
		return this.cntnrUnqlResnC;
	}

	public void setCntnrUnqlResnC(String cntnrUnqlResnC) {
		this.cntnrUnqlResnC = cntnrUnqlResnC;
	}

	@Column(name = "CTNR_ORG_CODE", length = 10)
	public String getCtnrOrgCode() {
		return this.ctnrOrgCode;
	}

	public void setCtnrOrgCode(String ctnrOrgCode) {
		this.ctnrOrgCode = ctnrOrgCode;
	}

	@Column(name = "CTNR_DEPT_CODE", length = 10)
	public String getCtnrDeptCode() {
		return this.ctnrDeptCode;
	}

	public void setCtnrDeptCode(String ctnrDeptCode) {
		this.ctnrDeptCode = ctnrDeptCode;
	}

	@Column(name = "CNTNR_OPERTO_CODE", length = 20)
	public String getCntnrOpertoCode() {
		return this.cntnrOpertoCode;
	}

	public void setCntnrOpertoCode(String cntnrOpertoCode) {
		this.cntnrOpertoCode = cntnrOpertoCode;
	}

	@Column(name = "CONT_OPETN_TIME", length = 7)
	public Timestamp getContOpetnTime() {
		return this.contOpetnTime;
	}

	public void setContOpetnTime(Timestamp contOpetnTime) {
		this.contOpetnTime = contOpetnTime;
	}

	@Column(name = "PREVTIV_TREATMT", length = 4)
	public String getPrevtivTreatmt() {
		return this.prevtivTreatmt;
	}

	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}

	@Column(name = "CNTNR_TREAT_CODES", length = 300)
	public String getCntnrTreatCodes() {
		return this.cntnrTreatCodes;
	}

	public void setCntnrTreatCodes(String cntnrTreatCodes) {
		this.cntnrTreatCodes = cntnrTreatCodes;
	}

	@Column(name = "SANIT_TRT_METH_CODES", length = 300)
	public String getSanitTrtMethCodes() {
		return this.sanitTrtMethCodes;
	}

	public void setSanitTrtMethCodes(String sanitTrtMethCodes) {
		this.sanitTrtMethCodes = sanitTrtMethCodes;
	}

	@Column(name = "SNT_TRT_ORG_CODE", length = 10)
	public String getSntTrtOrgCode() {
		return this.sntTrtOrgCode;
	}

	public void setSntTrtOrgCode(String sntTrtOrgCode) {
		this.sntTrtOrgCode = sntTrtOrgCode;
	}

	@Column(name = "TREAT_DEPT_CODE", length = 10)
	public String getTreatDeptCode() {
		return this.treatDeptCode;
	}

	public void setTreatDeptCode(String treatDeptCode) {
		this.treatDeptCode = treatDeptCode;
	}

	@Column(name = "SNT_TRT_OPER_CODE", length = 20)
	public String getSntTrtOperCode() {
		return this.sntTrtOperCode;
	}

	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}

	@Column(name = "TREAT_OPERATE_DATE", length = 7)
	public Timestamp getTreatOperateDate() {
		return this.treatOperateDate;
	}

	public void setTreatOperateDate(Timestamp treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}

	@Column(name = "APPRSL_ORG_CODE", length = 10)
	public String getApprslOrgCode() {
		return this.apprslOrgCode;
	}

	public void setApprslOrgCode(String apprslOrgCode) {
		this.apprslOrgCode = apprslOrgCode;
	}

	@Column(name = "APPRT_DEPT_CODE", length = 10)
	public String getApprtDeptCode() {
		return this.apprtDeptCode;
	}

	public void setApprtDeptCode(String apprtDeptCode) {
		this.apprtDeptCode = apprtDeptCode;
	}

	@Column(name = "IDEN_OPER_CODE", length = 20)
	public String getIdenOperCode() {
		return this.idenOperCode;
	}

	public void setIdenOperCode(String idenOperCode) {
		this.idenOperCode = idenOperCode;
	}

	@Column(name = "APPR_CONDT_TIME", length = 7)
	public Timestamp getApprCondtTime() {
		return this.apprCondtTime;
	}

	public void setApprCondtTime(Timestamp apprCondtTime) {
		this.apprCondtTime = apprCondtTime;
	}

	@Column(name = "UNQULFD_QUAR_QTY", precision = 0)
	public Double getUnqulfdQuarQty() {
		return this.unqulfdQuarQty;
	}

	public void setUnqulfdQuarQty(Double unqulfdQuarQty) {
		this.unqulfdQuarQty = unqulfdQuarQty;
	}

	@Column(name = "UNQULF_COMM_QTY", precision = 0)
	public Double getUnqulfCommQty() {
		return this.unqulfCommQty;
	}

	public void setUnqulfCommQty(Double unqulfCommQty) {
		this.unqulfCommQty = unqulfCommQty;
	}

	@Column(name = "UNQUAL_COMM_QTY_CMP", precision = 0)
	public Double getUnqualCommQtyCmp() {
		return this.unqualCommQtyCmp;
	}

	public void setUnqualCommQtyCmp(Double unqualCommQtyCmp) {
		this.unqualCommQtyCmp = unqualCommQtyCmp;
	}

	@Column(name = "DISQUA_CONT_CODE", length = 200)
	public String getDisquaContCode() {
		return this.disquaContCode;
	}

	public void setDisquaContCode(String disquaContCode) {
		this.disquaContCode = disquaContCode;
	}

	@Column(name = "TREAT_UNIT", length = 50)
	public String getTreatUnit() {
		return this.treatUnit;
	}

	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}

	@Column(name = "DECL_CONT_QTY", precision = 0)
	public Double getDeclContQty() {
		return this.declContQty;
	}

	public void setDeclContQty(Double declContQty) {
		this.declContQty = declContQty;
	}

	@Column(name = "INSP_CONT_QTY", precision = 0)
	public Double getInspContQty() {
		return this.inspContQty;
	}

	public void setInspContQty(Double inspContQty) {
		this.inspContQty = inspContQty;
	}

	@Column(name = "CONTAGION_CONT_QTY", precision = 0)
	public Double getContagionContQty() {
		return this.contagionContQty;
	}

	public void setContagionContQty(Double contagionContQty) {
		this.contagionContQty = contagionContQty;
	}

	@Column(name = "FAUNA_FLORA_CONT_QTY", precision = 0)
	public Double getFaunaFloraContQty() {
		return this.faunaFloraContQty;
	}

	public void setFaunaFloraContQty(Double faunaFloraContQty) {
		this.faunaFloraContQty = faunaFloraContQty;
	}

	@Column(name = "DETECTION_CONT_QTY", precision = 0)
	public Double getDetectionContQty() {
		return this.detectionContQty;
	}

	public void setDetectionContQty(Double detectionContQty) {
		this.detectionContQty = detectionContQty;
	}

	@Column(name = "HEALTH_PROC_CONT_QTY", precision = 0)
	public Double getHealthProcContQty() {
		return this.healthProcContQty;
	}

	public void setHealthProcContQty(Double healthProcContQty) {
		this.healthProcContQty = healthProcContQty;
	}

	@Column(name = "CARG_INSP_CONT_QTY", precision = 0)
	public Double getCargInspContQty() {
		return this.cargInspContQty;
	}

	public void setCargInspContQty(Double cargInspContQty) {
		this.cargInspContQty = cargInspContQty;
	}

	@Column(name = "CARG_DISQUAL_ITEM_ONE", length = 200)
	public String getCargDisqualItemOne() {
		return this.cargDisqualItemOne;
	}

	public void setCargDisqualItemOne(String cargDisqualItemOne) {
		this.cargDisqualItemOne = cargDisqualItemOne;
	}

	@Column(name = "EPID_SITU_CATG", length = 2)
	public String getEpidSituCatg() {
		return this.epidSituCatg;
	}

	public void setEpidSituCatg(String epidSituCatg) {
		this.epidSituCatg = epidSituCatg;
	}

	@Column(name = "CONT_CATEGORY", length = 2)
	public String getContCategory() {
		return this.contCategory;
	}

	public void setContCategory(String contCategory) {
		this.contCategory = contCategory;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "QUAR_UNQUAL_REASON_CODE", length = 1000)
	public String getQuarUnqualReasonCode() {
		return this.quarUnqualReasonCode;
	}

	public void setQuarUnqualReasonCode(String quarUnqualReasonCode) {
		this.quarUnqualReasonCode = quarUnqualReasonCode;
	}

	@Column(name = "CONT_NO", length = 4000)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "LCL_FLAG", length = 1)
	public String getLclFlag() {
		return this.lclFlag;
	}

	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}

	@Column(name = "HEAVY_FLAG", length = 1)
	public String getHeavyFlag() {
		return this.heavyFlag;
	}

	public void setHeavyFlag(String heavyFlag) {
		this.heavyFlag = heavyFlag;
	}

	@Column(name = "CHECK_QUA_FLAG", length = 1)
	public String getCheckQuaFlag() {
		return this.checkQuaFlag;
	}

	public void setCheckQuaFlag(String checkQuaFlag) {
		this.checkQuaFlag = checkQuaFlag;
	}

	@Column(name = "QUA_DISPOSE_FLAG", length = 1)
	public String getQuaDisposeFlag() {
		return this.quaDisposeFlag;
	}

	public void setQuaDisposeFlag(String quaDisposeFlag) {
		this.quaDisposeFlag = quaDisposeFlag;
	}

	@Column(name = "CARG_INS_UNQUAL_FLAG", length = 1)
	public String getCargInsUnqualFlag() {
		return this.cargInsUnqualFlag;
	}

	public void setCargInsUnqualFlag(String cargInsUnqualFlag) {
		this.cargInsUnqualFlag = cargInsUnqualFlag;
	}

	@Column(name = "HEALTH_INS_UNQUAL_FLAG", length = 1)
	public String getHealthInsUnqualFlag() {
		return this.healthInsUnqualFlag;
	}

	public void setHealthInsUnqualFlag(String healthInsUnqualFlag) {
		this.healthInsUnqualFlag = healthInsUnqualFlag;
	}

	@Column(name = "QUAR_UNQUAL_CONTENT_CODES", length = 200)
	public String getQuarUnqualContentCodes() {
		return this.quarUnqualContentCodes;
	}

	public void setQuarUnqualContentCodes(String quarUnqualContentCodes) {
		this.quarUnqualContentCodes = quarUnqualContentCodes;
	}

	@Column(name = "SNT_TRT_FLAG", length = 1)
	public String getSntTrtFlag() {
		return this.sntTrtFlag;
	}

	public void setSntTrtFlag(String sntTrtFlag) {
		this.sntTrtFlag = sntTrtFlag;
	}

	@Column(name = "PAM_QUA_UNQUAL_FLAG", length = 1)
	public String getPamQuaUnqualFlag() {
		return this.pamQuaUnqualFlag;
	}

	public void setPamQuaUnqualFlag(String pamQuaUnqualFlag) {
		this.pamQuaUnqualFlag = pamQuaUnqualFlag;
	}

	@Column(name = "PAM_UNQUAL_REASON_CODES", length = 200)
	public String getPamUnqualReasonCodes() {
		return this.pamUnqualReasonCodes;
	}

	public void setPamUnqualReasonCodes(String pamUnqualReasonCodes) {
		this.pamUnqualReasonCodes = pamUnqualReasonCodes;
	}

	@Column(name = "PAM_TRT_FLAG", length = 1)
	public String getPamTrtFlag() {
		return this.pamTrtFlag;
	}

	public void setPamTrtFlag(String pamTrtFlag) {
		this.pamTrtFlag = pamTrtFlag;
	}

	@Column(name = "PAM_TRT_METH_CODES", length = 300)
	public String getPamTrtMethCodes() {
		return this.pamTrtMethCodes;
	}

	public void setPamTrtMethCodes(String pamTrtMethCodes) {
		this.pamTrtMethCodes = pamTrtMethCodes;
	}

	@Column(name = "PAM_TRT_ORG_CODE", length = 10)
	public String getPamTrtOrgCode() {
		return this.pamTrtOrgCode;
	}

	public void setPamTrtOrgCode(String pamTrtOrgCode) {
		this.pamTrtOrgCode = pamTrtOrgCode;
	}

	@Column(name = "FR_INF_REG_FLAG", length = 1)
	public String getFrInfRegFlag() {
		return this.frInfRegFlag;
	}

	public void setFrInfRegFlag(String frInfRegFlag) {
		this.frInfRegFlag = frInfRegFlag;
	}

	@Column(name = "FR_PAM_REG_FLAG", length = 1)
	public String getFrPamRegFlag() {
		return this.frPamRegFlag;
	}

	public void setFrPamRegFlag(String frPamRegFlag) {
		this.frPamRegFlag = frPamRegFlag;
	}

	@Column(name = "BILL_LAD_NO", length = 2000)
	public String getBillLadNo() {
		return this.billLadNo;
	}

	public void setBillLadNo(String billLadNo) {
		this.billLadNo = billLadNo;
	}

	@Column(name = "BOX_COMPANY", length = 400)
	public String getBoxCompany() {
		return this.boxCompany;
	}

	public void setBoxCompany(String boxCompany) {
		this.boxCompany = boxCompany;
	}

	@Column(name = "REG_NUM", length = 30)
	public String getRegNum() {
		return this.regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "TRADE_COUNTRY_CODE", length = 8)
	public String getTradeCountryCode() {
		return this.tradeCountryCode;
	}

	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}

	@Column(name = "EMPTY_FLAG", length = 1)
	public String getEmptyFlag() {
		return this.emptyFlag;
	}

	public void setEmptyFlag(String emptyFlag) {
		this.emptyFlag = emptyFlag;
	}

	@Column(name = "CONT_QUAR_UNQUAL_FLAG", length = 1)
	public String getContQuarUnqualFlag() {
		return this.contQuarUnqualFlag;
	}

	public void setContQuarUnqualFlag(String contQuarUnqualFlag) {
		this.contQuarUnqualFlag = contQuarUnqualFlag;
	}

	@Column(name = "CONT_QUAR_UNQUAL_DESC", length = 500)
	public String getContQuarUnqualDesc() {
		return this.contQuarUnqualDesc;
	}

	public void setContQuarUnqualDesc(String contQuarUnqualDesc) {
		this.contQuarUnqualDesc = contQuarUnqualDesc;
	}

}
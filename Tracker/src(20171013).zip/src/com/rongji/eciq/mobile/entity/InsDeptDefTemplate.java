package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsDeptDefTemplate entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_DEPT_DEF_TEMPLATE")
public class InsDeptDefTemplate implements java.io.Serializable {

	// Fields

	private String insDeptDefTemplateId;
	private String defDeptCode;
	private String templateId;
	private String falgArchive;
	private Date operTime;

	// Constructors

	/** default constructor */
	public InsDeptDefTemplate() {
	}

	/** minimal constructor */
	public InsDeptDefTemplate(String insDeptDefTemplateId) {
		this.insDeptDefTemplateId = insDeptDefTemplateId;
	}

	/** full constructor */
	public InsDeptDefTemplate(String insDeptDefTemplateId, String defDeptCode, String templateId, String falgArchive, Date operTime) {
		this.insDeptDefTemplateId = insDeptDefTemplateId;
		this.defDeptCode = defDeptCode;
		this.templateId = templateId;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
	}

	// Property accessors
	@Id
	@Column(name = "INS_DEPT_DEF_TEMPLATE_ID", unique = true, nullable = false, length = 32)
	public String getInsDeptDefTemplateId() {
		return this.insDeptDefTemplateId;
	}

	public void setInsDeptDefTemplateId(String insDeptDefTemplateId) {
		this.insDeptDefTemplateId = insDeptDefTemplateId;
	}

	@Column(name = "DEF_DEPT_CODE", length = 10)
	public String getDefDeptCode() {
		return this.defDeptCode;
	}

	public void setDefDeptCode(String defDeptCode) {
		this.defDeptCode = defDeptCode;
	}

	@Column(name = "TEMPLATE_ID", length = 32)
	public String getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

}
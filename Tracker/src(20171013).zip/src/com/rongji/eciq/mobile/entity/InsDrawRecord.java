package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsDrawRecord entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_DRAW_RECORD")
public class InsDrawRecord implements java.io.Serializable {

	// Fields

	private String insDrawRecordId;
	private String declNo;
	private String contNo;
	private String isCheck;
	private String ifOpenBox;
	private String ifDrawBox;
	private String goodsNos;
	private String goodsNames;
	private Date operDate;
	private String falgArchive;
	private String operCode;
	private String cntnrModeCode;

	// Constructors

	/** default constructor */
	public InsDrawRecord() {
	}

	/** minimal constructor */
	public InsDrawRecord(String insDrawRecordId) {
		this.insDrawRecordId = insDrawRecordId;
	}

	/** full constructor */
	public InsDrawRecord(String insDrawRecordId, String declNo, String contNo, String isCheck, String ifOpenBox, String ifDrawBox, String goodsNos, String goodsNames, Date operDate, String falgArchive, String operCode, String cntnrModeCode) {
		this.insDrawRecordId = insDrawRecordId;
		this.declNo = declNo;
		this.contNo = contNo;
		this.isCheck = isCheck;
		this.ifOpenBox = ifOpenBox;
		this.ifDrawBox = ifDrawBox;
		this.goodsNos = goodsNos;
		this.goodsNames = goodsNames;
		this.operDate = operDate;
		this.falgArchive = falgArchive;
		this.operCode = operCode;
		this.cntnrModeCode = cntnrModeCode;
	}

	// Property accessors
	@Id
	@Column(name = "INS_DRAW_RECORD_ID", unique = true, nullable = false, length = 32)
	public String getInsDrawRecordId() {
		return this.insDrawRecordId;
	}

	public void setInsDrawRecordId(String insDrawRecordId) {
		this.insDrawRecordId = insDrawRecordId;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "CONT_NO", length = 100)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "IS_CHECK", length = 1)
	public String getIsCheck() {
		return this.isCheck;
	}

	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}

	@Column(name = "IF_OPEN_BOX", length = 1)
	public String getIfOpenBox() {
		return this.ifOpenBox;
	}

	public void setIfOpenBox(String ifOpenBox) {
		this.ifOpenBox = ifOpenBox;
	}

	@Column(name = "IF_DRAW_BOX", length = 1)
	public String getIfDrawBox() {
		return this.ifDrawBox;
	}

	public void setIfDrawBox(String ifDrawBox) {
		this.ifDrawBox = ifDrawBox;
	}

	@Column(name = "GOODS_NOS", length = 200)
	public String getGoodsNos() {
		return this.goodsNos;
	}

	public void setGoodsNos(String goodsNos) {
		this.goodsNos = goodsNos;
	}

	@Column(name = "GOODS_NAMES", length = 4000)
	public String getGoodsNames() {
		return this.goodsNames;
	}

	public void setGoodsNames(String goodsNames) {
		this.goodsNames = goodsNames;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_DATE")
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "CNTNR_MODE_CODE", length = 4)
	public String getCntnrModeCode() {
		return this.cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

}
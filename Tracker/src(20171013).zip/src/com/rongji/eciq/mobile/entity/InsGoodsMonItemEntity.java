package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsGoodsMonItem entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_GOODS_MON_ITEM")
public class InsGoodsMonItemEntity implements java.io.Serializable {

	private static final long serialVersionUID = -268712681677726695L;
	private String monItemId;
	private String moniItemCode;
	private String monitItemName;
	private String monitItemDesc;
	private String moniItemTypeC;
	private String monitItemTypeN;
	private String declNo;
	private Double goodsNo;
	private String evalFormula;
	private String itemEvaluateType;
	private String moniModeCode;
	private String enfocLevelCode;
	private String multiParaFlag;
	private String validFlag;
	private Timestamp rsValidProid;
	private Timestamp createTime;
	private String testPartCode;
	private String chkPointName;
	private String evlResCditVal;
	private String declareSym;
	private String partAsesmentSym;
	private String fillMode;
	private Double gatheringFreq;
	private Double collectPeriod;
	private String cycleUnit;
	private Double alwErr;
	private String canFixFlag;
	private String conclsTypeCode;
	private String conclsTypeName;
	private String testItemEname;
	private String testItemEnameSht;
	private String ifCnas;
	private String uncertainty;
	private String isNstdTestitem;
	private String itemRiskLevel;
	private String itemSourceCode;
	private String sourceItemId;
	private String falgArchive;
	private Timestamp operTime;
	private Double itemBatchRatio;
	private String goodsId;
	private String itemTypeCode;
	private Timestamp archiveTime;
	private String inspOrgCode;
	private String ctlitemFormCode;
	private String formName;

	// Constructors

	/** default constructor */
	public InsGoodsMonItemEntity() {
	}

	/** minimal constructor */
	public InsGoodsMonItemEntity(String monItemId) {
		this.monItemId = monItemId;
	}

	/** full constructor */
	public InsGoodsMonItemEntity(String monItemId, String moniItemCode,
			String monitItemName, String monitItemDesc, String moniItemTypeC,
			String monitItemTypeN, String declNo, Double goodsNo,
			String evalFormula, String itemEvaluateType, String moniModeCode,
			String enfocLevelCode, String multiParaFlag, String validFlag,
			Timestamp rsValidProid, Timestamp createTime, String testPartCode,
			String chkPointName, String evlResCditVal, String declareSym,
			String partAsesmentSym, String fillMode, Double gatheringFreq,
			Double collectPeriod, String cycleUnit, Double alwErr,
			String canFixFlag, String conclsTypeCode, String conclsTypeName,
			String testItemEname, String testItemEnameSht, String ifCnas,
			String uncertainty, String isNstdTestitem, String itemRiskLevel,
			String itemSourceCode, String sourceItemId, String falgArchive,
			Timestamp operTime, Double itemBatchRatio, String goodsId,
			String itemTypeCode, Timestamp archiveTime, String inspOrgCode,
			String ctlitemFormCode, String formName) {
		this.monItemId = monItemId;
		this.moniItemCode = moniItemCode;
		this.monitItemName = monitItemName;
		this.monitItemDesc = monitItemDesc;
		this.moniItemTypeC = moniItemTypeC;
		this.monitItemTypeN = monitItemTypeN;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.evalFormula = evalFormula;
		this.itemEvaluateType = itemEvaluateType;
		this.moniModeCode = moniModeCode;
		this.enfocLevelCode = enfocLevelCode;
		this.multiParaFlag = multiParaFlag;
		this.validFlag = validFlag;
		this.rsValidProid = rsValidProid;
		this.createTime = createTime;
		this.testPartCode = testPartCode;
		this.chkPointName = chkPointName;
		this.evlResCditVal = evlResCditVal;
		this.declareSym = declareSym;
		this.partAsesmentSym = partAsesmentSym;
		this.fillMode = fillMode;
		this.gatheringFreq = gatheringFreq;
		this.collectPeriod = collectPeriod;
		this.cycleUnit = cycleUnit;
		this.alwErr = alwErr;
		this.canFixFlag = canFixFlag;
		this.conclsTypeCode = conclsTypeCode;
		this.conclsTypeName = conclsTypeName;
		this.testItemEname = testItemEname;
		this.testItemEnameSht = testItemEnameSht;
		this.ifCnas = ifCnas;
		this.uncertainty = uncertainty;
		this.isNstdTestitem = isNstdTestitem;
		this.itemRiskLevel = itemRiskLevel;
		this.itemSourceCode = itemSourceCode;
		this.sourceItemId = sourceItemId;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.itemBatchRatio = itemBatchRatio;
		this.goodsId = goodsId;
		this.itemTypeCode = itemTypeCode;
		this.archiveTime = archiveTime;
		this.inspOrgCode = inspOrgCode;
		this.ctlitemFormCode = ctlitemFormCode;
		this.formName = formName;
	}

	// Property accessors
	@Id
	@Column(name = "MON_ITEM_ID", unique = true, nullable = false, length = 32)
	public String getMonItemId() {
		return this.monItemId;
	}

	public void setMonItemId(String monItemId) {
		this.monItemId = monItemId;
	}

	@Column(name = "MONI_ITEM_CODE", length = 30)
	public String getMoniItemCode() {
		return this.moniItemCode;
	}

	public void setMoniItemCode(String moniItemCode) {
		this.moniItemCode = moniItemCode;
	}

	@Column(name = "MONIT_ITEM_NAME", length = 200)
	public String getMonitItemName() {
		return this.monitItemName;
	}

	public void setMonitItemName(String monitItemName) {
		this.monitItemName = monitItemName;
	}

	@Column(name = "MONIT_ITEM_DESC", length = 800)
	public String getMonitItemDesc() {
		return this.monitItemDesc;
	}

	public void setMonitItemDesc(String monitItemDesc) {
		this.monitItemDesc = monitItemDesc;
	}

	@Column(name = "MONI_ITEM_TYPE_C", length = 30)
	public String getMoniItemTypeC() {
		return this.moniItemTypeC;
	}

	public void setMoniItemTypeC(String moniItemTypeC) {
		this.moniItemTypeC = moniItemTypeC;
	}

	@Column(name = "MONIT_ITEM_TYPE_N", length = 60)
	public String getMonitItemTypeN() {
		return this.monitItemTypeN;
	}

	public void setMonitItemTypeN(String monitItemTypeN) {
		this.monitItemTypeN = monitItemTypeN;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "EVAL_FORMULA", length = 1000)
	public String getEvalFormula() {
		return this.evalFormula;
	}

	public void setEvalFormula(String evalFormula) {
		this.evalFormula = evalFormula;
	}

	@Column(name = "ITEM_EVALUATE_TYPE", length = 1)
	public String getItemEvaluateType() {
		return this.itemEvaluateType;
	}

	public void setItemEvaluateType(String itemEvaluateType) {
		this.itemEvaluateType = itemEvaluateType;
	}

	@Column(name = "MONI_MODE_CODE", length = 1)
	public String getMoniModeCode() {
		return this.moniModeCode;
	}

	public void setMoniModeCode(String moniModeCode) {
		this.moniModeCode = moniModeCode;
	}

	@Column(name = "ENFOC_LEVEL_CODE", length = 2)
	public String getEnfocLevelCode() {
		return this.enfocLevelCode;
	}

	public void setEnfocLevelCode(String enfocLevelCode) {
		this.enfocLevelCode = enfocLevelCode;
	}

	@Column(name = "MULTI_PARA_FLAG", length = 1)
	public String getMultiParaFlag() {
		return this.multiParaFlag;
	}

	public void setMultiParaFlag(String multiParaFlag) {
		this.multiParaFlag = multiParaFlag;
	}

	@Column(name = "VALID_FLAG", length = 1)
	public String getValidFlag() {
		return this.validFlag;
	}

	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag;
	}

	@Column(name = "RS_VALID_PROID", length = 7)
	public Timestamp getRsValidProid() {
		return this.rsValidProid;
	}

	public void setRsValidProid(Timestamp rsValidProid) {
		this.rsValidProid = rsValidProid;
	}

	@Column(name = "CREATE_TIME", length = 7)
	public Timestamp getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	@Column(name = "TEST_PART_CODE", length = 4)
	public String getTestPartCode() {
		return this.testPartCode;
	}

	public void setTestPartCode(String testPartCode) {
		this.testPartCode = testPartCode;
	}

	@Column(name = "CHK_POINT_NAME", length = 40)
	public String getChkPointName() {
		return this.chkPointName;
	}

	public void setChkPointName(String chkPointName) {
		this.chkPointName = chkPointName;
	}

	@Column(name = "EVL_RES_CDIT_VAL", length = 200)
	public String getEvlResCditVal() {
		return this.evlResCditVal;
	}

	public void setEvlResCditVal(String evlResCditVal) {
		this.evlResCditVal = evlResCditVal;
	}

	@Column(name = "DECLARE_SYM", length = 1)
	public String getDeclareSym() {
		return this.declareSym;
	}

	public void setDeclareSym(String declareSym) {
		this.declareSym = declareSym;
	}

	@Column(name = "PART_ASESMENT_SYM", length = 1)
	public String getPartAsesmentSym() {
		return this.partAsesmentSym;
	}

	public void setPartAsesmentSym(String partAsesmentSym) {
		this.partAsesmentSym = partAsesmentSym;
	}

	@Column(name = "FILL_MODE", length = 20)
	public String getFillMode() {
		return this.fillMode;
	}

	public void setFillMode(String fillMode) {
		this.fillMode = fillMode;
	}

	@Column(name = "GATHERING_FREQ", precision = 0)
	public Double getGatheringFreq() {
		return this.gatheringFreq;
	}

	public void setGatheringFreq(Double gatheringFreq) {
		this.gatheringFreq = gatheringFreq;
	}

	@Column(name = "COLLECT_PERIOD", precision = 0)
	public Double getCollectPeriod() {
		return this.collectPeriod;
	}

	public void setCollectPeriod(Double collectPeriod) {
		this.collectPeriod = collectPeriod;
	}

	@Column(name = "CYCLE_UNIT", length = 20)
	public String getCycleUnit() {
		return this.cycleUnit;
	}

	public void setCycleUnit(String cycleUnit) {
		this.cycleUnit = cycleUnit;
	}

	@Column(name = "ALW_ERR", precision = 0)
	public Double getAlwErr() {
		return this.alwErr;
	}

	public void setAlwErr(Double alwErr) {
		this.alwErr = alwErr;
	}

	@Column(name = "CAN_FIX_FLAG", length = 1)
	public String getCanFixFlag() {
		return this.canFixFlag;
	}

	public void setCanFixFlag(String canFixFlag) {
		this.canFixFlag = canFixFlag;
	}

	@Column(name = "CONCLS_TYPE_CODE", length = 20)
	public String getConclsTypeCode() {
		return this.conclsTypeCode;
	}

	public void setConclsTypeCode(String conclsTypeCode) {
		this.conclsTypeCode = conclsTypeCode;
	}

	@Column(name = "CONCLS_TYPE_NAME", length = 24)
	public String getConclsTypeName() {
		return this.conclsTypeName;
	}

	public void setConclsTypeName(String conclsTypeName) {
		this.conclsTypeName = conclsTypeName;
	}

	@Column(name = "TEST_ITEM_ENAME", length = 200)
	public String getTestItemEname() {
		return this.testItemEname;
	}

	public void setTestItemEname(String testItemEname) {
		this.testItemEname = testItemEname;
	}

	@Column(name = "TEST_ITEM_ENAME_SHT", length = 50)
	public String getTestItemEnameSht() {
		return this.testItemEnameSht;
	}

	public void setTestItemEnameSht(String testItemEnameSht) {
		this.testItemEnameSht = testItemEnameSht;
	}

	@Column(name = "IF_CNAS", length = 1)
	public String getIfCnas() {
		return this.ifCnas;
	}

	public void setIfCnas(String ifCnas) {
		this.ifCnas = ifCnas;
	}

	@Column(name = "UNCERTAINTY", length = 50)
	public String getUncertainty() {
		return this.uncertainty;
	}

	public void setUncertainty(String uncertainty) {
		this.uncertainty = uncertainty;
	}

	@Column(name = "IS_NSTD_TESTITEM", length = 1)
	public String getIsNstdTestitem() {
		return this.isNstdTestitem;
	}

	public void setIsNstdTestitem(String isNstdTestitem) {
		this.isNstdTestitem = isNstdTestitem;
	}

	@Column(name = "ITEM_RISK_LEVEL", length = 1)
	public String getItemRiskLevel() {
		return this.itemRiskLevel;
	}

	public void setItemRiskLevel(String itemRiskLevel) {
		this.itemRiskLevel = itemRiskLevel;
	}

	@Column(name = "ITEM_SOURCE_CODE", length = 4)
	public String getItemSourceCode() {
		return this.itemSourceCode;
	}

	public void setItemSourceCode(String itemSourceCode) {
		this.itemSourceCode = itemSourceCode;
	}

	@Column(name = "SOURCE_ITEM_ID", length = 32)
	public String getSourceItemId() {
		return this.sourceItemId;
	}

	public void setSourceItemId(String sourceItemId) {
		this.sourceItemId = sourceItemId;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "ITEM_BATCH_RATIO", precision = 0)
	public Double getItemBatchRatio() {
		return this.itemBatchRatio;
	}

	public void setItemBatchRatio(Double itemBatchRatio) {
		this.itemBatchRatio = itemBatchRatio;
	}

	@Column(name = "GOODS_ID", length = 32)
	public String getGoodsId() {
		return this.goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	@Column(name = "ITEM_TYPE_CODE", length = 1)
	public String getItemTypeCode() {
		return this.itemTypeCode;
	}

	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "INSP_ORG_CODE", length = 10)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "CTLITEM_FORM_CODE", length = 32)
	public String getCtlitemFormCode() {
		return this.ctlitemFormCode;
	}

	public void setCtlitemFormCode(String ctlitemFormCode) {
		this.ctlitemFormCode = ctlitemFormCode;
	}

	@Column(name = "FORM_NAME", length = 60)
	public String getFormName() {
		return this.formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

}
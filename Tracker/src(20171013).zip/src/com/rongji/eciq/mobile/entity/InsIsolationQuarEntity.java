package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "INS_ISOLATION_QUAR")
public class InsIsolationQuarEntity implements java.io.Serializable {

	// Fields

	private String isolationQuarId;
	private String declNo;
	private String resultEvaluate;
	private String quarSituDesc;
	private Date beginTime;
	private Date closureTime;
	private String falgArchive;
	private Date operTime;
	private String chngResn;
	private String quarOfficeName;
	private String quarOfficeCode;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public InsIsolationQuarEntity() {
	}

	/** minimal constructor */
	public InsIsolationQuarEntity(String isolationQuarId, String declNo) {
		this.isolationQuarId = isolationQuarId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsIsolationQuarEntity(String isolationQuarId, String declNo,
			String resultEvaluate, String quarSituDesc, Date beginTime,
			Date closureTime, String falgArchive, Date operTime,
			String chngResn, String quarOfficeName, String quarOfficeCode,
			Date archiveTime) {
		this.isolationQuarId = isolationQuarId;
		this.declNo = declNo;
		this.resultEvaluate = resultEvaluate;
		this.quarSituDesc = quarSituDesc;
		this.beginTime = beginTime;
		this.closureTime = closureTime;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.chngResn = chngResn;
		this.quarOfficeName = quarOfficeName;
		this.quarOfficeCode = quarOfficeCode;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "ISOLATION_QUAR_ID", unique = true, nullable = false, length = 32)
	public String getIsolationQuarId() {
		return this.isolationQuarId;
	}

	public void setIsolationQuarId(String isolationQuarId) {
		this.isolationQuarId = isolationQuarId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "RESULT_EVALUATE", length = 1)
	public String getResultEvaluate() {
		return this.resultEvaluate;
	}

	public void setResultEvaluate(String resultEvaluate) {
		this.resultEvaluate = resultEvaluate;
	}

	@Column(name = "QUAR_SITU_DESC", length = 4000)
	public String getQuarSituDesc() {
		return this.quarSituDesc;
	}

	public void setQuarSituDesc(String quarSituDesc) {
		this.quarSituDesc = quarSituDesc;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "BEGIN_TIME", length = 7)
	public Date getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CLOSURE_TIME", length = 7)
	public Date getClosureTime() {
		return this.closureTime;
	}

	public void setClosureTime(Date closureTime) {
		this.closureTime = closureTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "CHNG_RESN", length = 200)
	public String getChngResn() {
		return this.chngResn;
	}

	public void setChngResn(String chngResn) {
		this.chngResn = chngResn;
	}

	@Column(name = "QUAR_OFFICE_NAME", length = 2000)
	public String getQuarOfficeName() {
		return this.quarOfficeName;
	}

	public void setQuarOfficeName(String quarOfficeName) {
		this.quarOfficeName = quarOfficeName;
	}

	@Column(name = "QUAR_OFFICE_CODE", length = 1000)
	public String getQuarOfficeCode() {
		return this.quarOfficeCode;
	}

	public void setQuarOfficeCode(String quarOfficeCode) {
		this.quarOfficeCode = quarOfficeCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsMonItemEvalStd entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_MON_ITEM_EVAL_STD")
public class InsMonItemEvalStdEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 2227925483928017265L;
	private String evalStdId;
	private String moniItemCode;
	private String moniItemParCode;
	private String monitItemParN;
	private String operType;
	private String targVal;
	private String targOperSymbl;
	private String indUppLim;
	private String operSymblUp;
	private String indLowrLim;
	private String operSymblLow;
	private String inputUppLimit;
	private String inputLowLimit;
	private String assMeasureUnit;
	private Double serialNo;
	private Double groupNo;
	private String evalResult;
	private String wheCondPara;
	private String warnUpLim;
	private String warnLowLim;
	private String falgArchive;
	private Timestamp operTime;
	private String monItemId;
	private Timestamp archiveTime;
	private String lawStdNo;
	private String testMethCode;

	// Constructors

	/** default constructor */
	public InsMonItemEvalStdEntity() {
	}

	/** minimal constructor */
	public InsMonItemEvalStdEntity(String evalStdId, String moniItemCode,
			String moniItemParCode) {
		this.evalStdId = evalStdId;
		this.moniItemCode = moniItemCode;
		this.moniItemParCode = moniItemParCode;
	}

	/** full constructor */
	public InsMonItemEvalStdEntity(String evalStdId, String moniItemCode,
			String moniItemParCode, String monitItemParN, String operType,
			String targVal, String targOperSymbl, String indUppLim,
			String operSymblUp, String indLowrLim, String operSymblLow,
			String inputUppLimit, String inputLowLimit, String assMeasureUnit,
			Double serialNo, Double groupNo, String evalResult,
			String wheCondPara, String warnUpLim, String warnLowLim,
			String falgArchive, Timestamp operTime, String monItemId,
			Timestamp archiveTime, String lawStdNo, String testMethCode) {
		this.evalStdId = evalStdId;
		this.moniItemCode = moniItemCode;
		this.moniItemParCode = moniItemParCode;
		this.monitItemParN = monitItemParN;
		this.operType = operType;
		this.targVal = targVal;
		this.targOperSymbl = targOperSymbl;
		this.indUppLim = indUppLim;
		this.operSymblUp = operSymblUp;
		this.indLowrLim = indLowrLim;
		this.operSymblLow = operSymblLow;
		this.inputUppLimit = inputUppLimit;
		this.inputLowLimit = inputLowLimit;
		this.assMeasureUnit = assMeasureUnit;
		this.serialNo = serialNo;
		this.groupNo = groupNo;
		this.evalResult = evalResult;
		this.wheCondPara = wheCondPara;
		this.warnUpLim = warnUpLim;
		this.warnLowLim = warnLowLim;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.monItemId = monItemId;
		this.archiveTime = archiveTime;
		this.lawStdNo = lawStdNo;
		this.testMethCode = testMethCode;
	}

	// Property accessors
	@Id
	@Column(name = "EVAL_STD_ID", unique = true, nullable = false, length = 32)
	public String getEvalStdId() {
		return this.evalStdId;
	}

	public void setEvalStdId(String evalStdId) {
		this.evalStdId = evalStdId;
	}

	@Column(name = "MONI_ITEM_CODE", nullable = false, length = 30)
	public String getMoniItemCode() {
		return this.moniItemCode;
	}

	public void setMoniItemCode(String moniItemCode) {
		this.moniItemCode = moniItemCode;
	}

	@Column(name = "MONI_ITEM_PAR_CODE", nullable = false, length = 10)
	public String getMoniItemParCode() {
		return this.moniItemParCode;
	}

	public void setMoniItemParCode(String moniItemParCode) {
		this.moniItemParCode = moniItemParCode;
	}

	@Column(name = "MONIT_ITEM_PAR_N", length = 500)
	public String getMonitItemParN() {
		return this.monitItemParN;
	}

	public void setMonitItemParN(String monitItemParN) {
		this.monitItemParN = monitItemParN;
	}

	@Column(name = "OPER_TYPE", length = 20)
	public String getOperType() {
		return this.operType;
	}

	public void setOperType(String operType) {
		this.operType = operType;
	}

	@Column(name = "TARG_VAL", length = 40)
	public String getTargVal() {
		return this.targVal;
	}

	public void setTargVal(String targVal) {
		this.targVal = targVal;
	}

	@Column(name = "TARG_OPER_SYMBL", length = 10)
	public String getTargOperSymbl() {
		return this.targOperSymbl;
	}

	public void setTargOperSymbl(String targOperSymbl) {
		this.targOperSymbl = targOperSymbl;
	}

	@Column(name = "IND_UPP_LIM", length = 40)
	public String getIndUppLim() {
		return this.indUppLim;
	}

	public void setIndUppLim(String indUppLim) {
		this.indUppLim = indUppLim;
	}

	@Column(name = "OPER_SYMBL_UP", length = 10)
	public String getOperSymblUp() {
		return this.operSymblUp;
	}

	public void setOperSymblUp(String operSymblUp) {
		this.operSymblUp = operSymblUp;
	}

	@Column(name = "IND_LOWR_LIM", length = 40)
	public String getIndLowrLim() {
		return this.indLowrLim;
	}

	public void setIndLowrLim(String indLowrLim) {
		this.indLowrLim = indLowrLim;
	}

	@Column(name = "OPER_SYMBL_LOW", length = 10)
	public String getOperSymblLow() {
		return this.operSymblLow;
	}

	public void setOperSymblLow(String operSymblLow) {
		this.operSymblLow = operSymblLow;
	}

	@Column(name = "INPUT_UPP_LIMIT", length = 40)
	public String getInputUppLimit() {
		return this.inputUppLimit;
	}

	public void setInputUppLimit(String inputUppLimit) {
		this.inputUppLimit = inputUppLimit;
	}

	@Column(name = "INPUT_LOW_LIMIT", length = 40)
	public String getInputLowLimit() {
		return this.inputLowLimit;
	}

	public void setInputLowLimit(String inputLowLimit) {
		this.inputLowLimit = inputLowLimit;
	}

	@Column(name = "ASS_MEASURE_UNIT", length = 200)
	public String getAssMeasureUnit() {
		return this.assMeasureUnit;
	}

	public void setAssMeasureUnit(String assMeasureUnit) {
		this.assMeasureUnit = assMeasureUnit;
	}

	@Column(name = "SERIAL_NO", precision = 0)
	public Double getSerialNo() {
		return this.serialNo;
	}

	public void setSerialNo(Double serialNo) {
		this.serialNo = serialNo;
	}

	@Column(name = "GROUP_NO", precision = 0)
	public Double getGroupNo() {
		return this.groupNo;
	}

	public void setGroupNo(Double groupNo) {
		this.groupNo = groupNo;
	}

	@Column(name = "EVAL_RESULT", length = 40)
	public String getEvalResult() {
		return this.evalResult;
	}

	public void setEvalResult(String evalResult) {
		this.evalResult = evalResult;
	}

	@Column(name = "WHE_COND_PARA", length = 1)
	public String getWheCondPara() {
		return this.wheCondPara;
	}

	public void setWheCondPara(String wheCondPara) {
		this.wheCondPara = wheCondPara;
	}

	@Column(name = "WARN_UP_LIM", length = 40)
	public String getWarnUpLim() {
		return this.warnUpLim;
	}

	public void setWarnUpLim(String warnUpLim) {
		this.warnUpLim = warnUpLim;
	}

	@Column(name = "WARN_LOW_LIM", length = 40)
	public String getWarnLowLim() {
		return this.warnLowLim;
	}

	public void setWarnLowLim(String warnLowLim) {
		this.warnLowLim = warnLowLim;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "MON_ITEM_ID", length = 32)
	public String getMonItemId() {
		return this.monItemId;
	}

	public void setMonItemId(String monItemId) {
		this.monItemId = monItemId;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "LAW_STD_NO", length = 4000)
	public String getLawStdNo() {
		return this.lawStdNo;
	}

	public void setLawStdNo(String lawStdNo) {
		this.lawStdNo = lawStdNo;
	}

	@Column(name = "TEST_METH_CODE", length = 4000)
	public String getTestMethCode() {
		return this.testMethCode;
	}

	public void setTestMethCode(String testMethCode) {
		this.testMethCode = testMethCode;
	}

//    public String getStdValue() {
//        return this.targVal;
//    }
//
//    public String getCtlitemParaCode() {
//        return this.moniItemParCode;
//    }
//
//    public String getParaType() {
//        return wheCondPara;
//    }
//
//    public String getDataType() {
//        return operType;
//    }
//
//    public String getStdOperateSymbol() {
//        return this.targOperSymbl;
//    }
//
//    public String getValueLower() {
//        return indLowrLim;
//    }
//
//    public String getOperateSymbolLower() {
//        return this.operSymblLow;
//    }
//
//    public String getValueUpper() {
//        return this.indUppLim;
//    }
//
//    public String getOperateSymbolUpper() {
//        return this.operSymblUp;
//    }
}
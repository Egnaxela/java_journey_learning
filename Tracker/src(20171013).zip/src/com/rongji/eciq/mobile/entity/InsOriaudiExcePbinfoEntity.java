package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsOriaudiExcePbinfo entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_ORIAUDI_EXCE_PBINFO")
public class InsOriaudiExcePbinfoEntity implements java.io.Serializable {

	private static final long serialVersionUID = -1186314613195423872L;
	private String insFauditExceId;
	private String declNo;
	private Double goodsNo;
	private String prodBatNo;
	private String entOrgCode;
	private String entName;
	private String abnormalType;
	private String abnormalCause;
	private String whetherEffect;
	private String creator;
	private Timestamp cretDate;
	private String modifyPerson;
	private Timestamp modifyDate;
	private String exceptionDetail;
	private String falgArchive;
	private Timestamp operTime;
	private String exceObjectPkey;
	private Timestamp archiveTime;
	private String sourceType;

	// Constructors

	/** default constructor */
	public InsOriaudiExcePbinfoEntity() {
	}

	/** minimal constructor */
	public InsOriaudiExcePbinfoEntity(String insFauditExceId) {
		this.insFauditExceId = insFauditExceId;
	}

	/** full constructor */
	public InsOriaudiExcePbinfoEntity(String insFauditExceId, String declNo,
			Double goodsNo, String prodBatNo, String entOrgCode,
			String entName, String abnormalType, String abnormalCause,
			String whetherEffect, String creator, Timestamp cretDate,
			String modifyPerson, Timestamp modifyDate, String exceptionDetail,
			String falgArchive, Timestamp operTime, String exceObjectPkey,
			Timestamp archiveTime, String sourceType) {
		this.insFauditExceId = insFauditExceId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.prodBatNo = prodBatNo;
		this.entOrgCode = entOrgCode;
		this.entName = entName;
		this.abnormalType = abnormalType;
		this.abnormalCause = abnormalCause;
		this.whetherEffect = whetherEffect;
		this.creator = creator;
		this.cretDate = cretDate;
		this.modifyPerson = modifyPerson;
		this.modifyDate = modifyDate;
		this.exceptionDetail = exceptionDetail;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.exceObjectPkey = exceObjectPkey;
		this.archiveTime = archiveTime;
		this.sourceType = sourceType;
	}

	// Property accessors
	@Id
	@Column(name = "INS_FAUDIT_EXCE_ID", unique = true, nullable = false, length = 32)
	public String getInsFauditExceId() {
		return this.insFauditExceId;
	}

	public void setInsFauditExceId(String insFauditExceId) {
		this.insFauditExceId = insFauditExceId;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PROD_BAT_NO", length = 20)
	public String getProdBatNo() {
		return this.prodBatNo;
	}

	public void setProdBatNo(String prodBatNo) {
		this.prodBatNo = prodBatNo;
	}

	@Column(name = "ENT_ORG_CODE", length = 20)
	public String getEntOrgCode() {
		return this.entOrgCode;
	}

	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}

	@Column(name = "ENT_NAME", length = 100)
	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	@Column(name = "ABNORMAL_TYPE", length = 4)
	public String getAbnormalType() {
		return this.abnormalType;
	}

	public void setAbnormalType(String abnormalType) {
		this.abnormalType = abnormalType;
	}

	@Column(name = "ABNORMAL_CAUSE", length = 4000)
	public String getAbnormalCause() {
		return this.abnormalCause;
	}

	public void setAbnormalCause(String abnormalCause) {
		this.abnormalCause = abnormalCause;
	}

	@Column(name = "WHETHER_EFFECT", length = 1)
	public String getWhetherEffect() {
		return this.whetherEffect;
	}

	public void setWhetherEffect(String whetherEffect) {
		this.whetherEffect = whetherEffect;
	}

	@Column(name = "CREATOR", length = 20)
	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	@Column(name = "CRET_DATE", length = 7)
	public Timestamp getCretDate() {
		return this.cretDate;
	}

	public void setCretDate(Timestamp cretDate) {
		this.cretDate = cretDate;
	}

	@Column(name = "MODIFY_PERSON", length = 20)
	public String getModifyPerson() {
		return this.modifyPerson;
	}

	public void setModifyPerson(String modifyPerson) {
		this.modifyPerson = modifyPerson;
	}

	@Column(name = "MODIFY_DATE", length = 7)
	public Timestamp getModifyDate() {
		return this.modifyDate;
	}

	public void setModifyDate(Timestamp modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Column(name = "EXCEPTION_DETAIL", length = 1000)
	public String getExceptionDetail() {
		return this.exceptionDetail;
	}

	public void setExceptionDetail(String exceptionDetail) {
		this.exceptionDetail = exceptionDetail;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "EXCE_OBJECT_PKEY", length = 32)
	public String getExceObjectPkey() {
		return this.exceObjectPkey;
	}

	public void setExceObjectPkey(String exceObjectPkey) {
		this.exceObjectPkey = exceObjectPkey;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "SOURCE_TYPE", length = 1)
	public String getSourceType() {
		return this.sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsResultGoods entity. @author MyEclipse Persistence Tools 
 */
@Entity
@Table(name = "INS_RESULT_GOODS")
public class InsResultGoodsXmlEntity implements java.io.Serializable {

	private static final long serialVersionUID = -4570696638723749108L;
	private String resultGoodsId;
	private String declNo;
	private Double goodsNo;
	private String prodHsCode;
	private String statKindCode;
	private String spec;
	private String mesuUnTypCode;
	private Double weightNet;
	private Double weightGross;
	private String wtUnitCode;
	private Double stdWt;
	private String stdWtUnitCode;
	private Double statclWtValue;
	private String statWtUnitCode;
	private Double qty;
	private String qtyUnitCode;
	private Double stdQty;
	private String stdQtyUnitCode;
	private Double statclQtyValue;
	private String statQuatyUnCo;
	private Double packQty;
	private String packTypeCode;
	private String currency;
	private Double goodsTotalVal;
	private Double totalValUs;
	private Double totalValCn;
	private String goodsPlace;
	private Timestamp entryDate;
	private Timestamp cmplDschrgDt;
	private Double unquaWt;
	private Double unqualQty;
	private Double unqualAmt;
	private Double unquAmntUsd;
	private Double disquaAmtRmb;
	private Double claimAmt;
	private Double claimAmtUsd;
	private Double claimAmtRmb;
	private String disquaContCodes;
	private String inspUnqResn;
	private String inpUnqualHaCode;
	private String inspPatternCode;
	private String wtDetModeCode;
	private String wtDetWorkModeC;
	private String damagIdProCode;
	private String damgedResnCode;
	private Double damagedAmt;
	private Double damageAmtUsd;
	private Double damageAmtRmb;
	private String qurUnqulRsnCode;
	private String qurUnqProcCode;
	private String speQuarTrmtMecC;
	private String quarTrtOrgCode;
	private String quarTrtDeptCode;
	private String statUnitName;
	private String inspContCodes;
	private String goodsNameCn;
	private String goodsNameEn;
	private String goodsflag;
	private String inspResEval;
	private String inspOrgCode;
	private String inspDeptCode;
	private Double inspUnquafWt;
	private Double unqulCommInsQty;
	private Double inspUnquaAmt;
	private Double inspUnquAmntUs;
	private Double inspDisquaAmtRmb;
	private String quarResEval;
	private String quaraOrgCode;
	private String quarDeptCode;
	private Double quaranUnquaWt;
	private Double unqulfdQuarQty;
	private Double unqualQuarAmt;
	private Double unqulQuarAmtUs;
	private Double unqulQuarAmtCn;
	private Double relsWtValue;
	private Double relsQtyValue;
	private Double releaseAmt;
	private Double relsAmountUsd;
	private Double relsAmountRmb;
	private Double relsPackQty;
	private Double relsStdWt;
	private Double relsStdQty;
	private String apprslOrgCode;
	private String apprtDeptCode;
	private String inspContStr;
	private String quarContStr;
	private String inspDisquaContCodes;
	private String quarDisquaContCodes;
	private String prevtivTreatmt;
	private String mnufctrCode;
	private String prodBatchNo;
	private String inspOperCode;
	private Timestamp insOpertDate;
	private String quarOperCode;
	private Timestamp quarCondtTime;
	private String idenOperCode;
	private Timestamp apprCondtTime;
	private String sntTrtOperCode;
	private Timestamp treatOperateDate;
	private String treatUnit;
	private Double treatTime;
	private String treatTimeUnit;
	private Double treatTemper;
	private String medicName;
	private Double prevTreatTm;
	private String preTreatTmUnit;
	private Double prvntTreatTemp;
	private String prevMedicName;
	private Double treatMedicDens;
	private Double medicConcen;
	private Double actualQty;
	private Double realWeight;
	private Double actSmplNum;
	private Double suggSmplNum;
	private Double inspQty;
	private Double declWt;
	private Double declGoodsValues;
	private Double declValuesUsd;
	private Double declValuesRmb;
	private String produceDate;
	private String extDisquaCauseCode;
	private String extDisquaCauseDesc;
	private String extDisquCauseCode;
	private String extDisquCauseDesc;
	private String standardNo;
	private String disDetailInfo;
	private String riskInfoLevelCode;
	private String reportOrgCode;
	private String disquaTypeCode;
	private String falgArchive;
	private Timestamp operTime;
	private String contNo;
	private String preMeasBasisCode;
	private Timestamp archiveTime;
	private String inspResSpot;
	private String quarResSpot;

	// Constructors

	/** default constructor */
	public InsResultGoodsXmlEntity() {
	}

	/** minimal constructor */
	public InsResultGoodsXmlEntity(String resultGoodsId, String declNo, Double goodsNo) {
		this.resultGoodsId = resultGoodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
	}

	/** full constructor */
	public InsResultGoodsXmlEntity(String resultGoodsId, String declNo, Double goodsNo,
			String prodHsCode, String statKindCode, String spec,
			String mesuUnTypCode, Double weightNet, Double weightGross,
			String wtUnitCode, Double stdWt, String stdWtUnitCode,
			Double statclWtValue, String statWtUnitCode, Double qty,
			String qtyUnitCode, Double stdQty, String stdQtyUnitCode,
			Double statclQtyValue, String statQuatyUnCo, Double packQty,
			String packTypeCode, String currency, Double goodsTotalVal,
			Double totalValUs, Double totalValCn, String goodsPlace,
			Timestamp entryDate, Timestamp cmplDschrgDt, Double unquaWt,
			Double unqualQty, Double unqualAmt, Double unquAmntUsd,
			Double disquaAmtRmb, Double claimAmt, Double claimAmtUsd,
			Double claimAmtRmb, String disquaContCodes, String inspUnqResn,
			String inpUnqualHaCode, String inspPatternCode,
			String wtDetModeCode, String wtDetWorkModeC, String damagIdProCode,
			String damgedResnCode, Double damagedAmt, Double damageAmtUsd,
			Double damageAmtRmb, String qurUnqulRsnCode, String qurUnqProcCode,
			String speQuarTrmtMecC, String quarTrtOrgCode,
			String quarTrtDeptCode, String statUnitName, String inspContCodes,
			String goodsNameCn, String goodsNameEn, String goodsflag,
			String inspResEval, String inspOrgCode, String inspDeptCode,
			Double inspUnquafWt, Double unqulCommInsQty, Double inspUnquaAmt,
			Double inspUnquAmntUs, Double inspDisquaAmtRmb, String quarResEval,
			String quaraOrgCode, String quarDeptCode, Double quaranUnquaWt,
			Double unqulfdQuarQty, Double unqualQuarAmt, Double unqulQuarAmtUs,
			Double unqulQuarAmtCn, Double relsWtValue, Double relsQtyValue,
			Double releaseAmt, Double relsAmountUsd, Double relsAmountRmb,
			Double relsPackQty, Double relsStdWt, Double relsStdQty,
			String apprslOrgCode, String apprtDeptCode, String inspContStr,
			String quarContStr, String inspDisquaContCodes,
			String quarDisquaContCodes, String prevtivTreatmt,
			String mnufctrCode, String prodBatchNo, String inspOperCode,
			Timestamp insOpertDate, String quarOperCode,
			Timestamp quarCondtTime, String idenOperCode,
			Timestamp apprCondtTime, String sntTrtOperCode,
			Timestamp treatOperateDate, String treatUnit, Double treatTime,
			String treatTimeUnit, Double treatTemper, String medicName,
			Double prevTreatTm, String preTreatTmUnit, Double prvntTreatTemp,
			String prevMedicName, Double treatMedicDens, Double medicConcen,
			Double actualQty, Double realWeight, Double actSmplNum,
			Double suggSmplNum, Double inspQty, Double declWt,
			Double declGoodsValues, Double declValuesUsd, Double declValuesRmb,
			String produceDate, String extDisquaCauseCode,
			String extDisquaCauseDesc, String extDisquCauseCode,
			String extDisquCauseDesc, String standardNo, String disDetailInfo,
			String riskInfoLevelCode, String reportOrgCode,
			String disquaTypeCode, String falgArchive, Timestamp operTime,
			String contNo, String preMeasBasisCode, Timestamp archiveTime,
			String inspResSpot, String quarResSpot) {
		this.resultGoodsId = resultGoodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.prodHsCode = prodHsCode;
		this.statKindCode = statKindCode;
		this.spec = spec;
		this.mesuUnTypCode = mesuUnTypCode;
		this.weightNet = weightNet;
		this.weightGross = weightGross;
		this.wtUnitCode = wtUnitCode;
		this.stdWt = stdWt;
		this.stdWtUnitCode = stdWtUnitCode;
		this.statclWtValue = statclWtValue;
		this.statWtUnitCode = statWtUnitCode;
		this.qty = qty;
		this.qtyUnitCode = qtyUnitCode;
		this.stdQty = stdQty;
		this.stdQtyUnitCode = stdQtyUnitCode;
		this.statclQtyValue = statclQtyValue;
		this.statQuatyUnCo = statQuatyUnCo;
		this.packQty = packQty;
		this.packTypeCode = packTypeCode;
		this.currency = currency;
		this.goodsTotalVal = goodsTotalVal;
		this.totalValUs = totalValUs;
		this.totalValCn = totalValCn;
		this.goodsPlace = goodsPlace;
		this.entryDate = entryDate;
		this.cmplDschrgDt = cmplDschrgDt;
		this.unquaWt = unquaWt;
		this.unqualQty = unqualQty;
		this.unqualAmt = unqualAmt;
		this.unquAmntUsd = unquAmntUsd;
		this.disquaAmtRmb = disquaAmtRmb;
		this.claimAmt = claimAmt;
		this.claimAmtUsd = claimAmtUsd;
		this.claimAmtRmb = claimAmtRmb;
		this.disquaContCodes = disquaContCodes;
		this.inspUnqResn = inspUnqResn;
		this.inpUnqualHaCode = inpUnqualHaCode;
		this.inspPatternCode = inspPatternCode;
		this.wtDetModeCode = wtDetModeCode;
		this.wtDetWorkModeC = wtDetWorkModeC;
		this.damagIdProCode = damagIdProCode;
		this.damgedResnCode = damgedResnCode;
		this.damagedAmt = damagedAmt;
		this.damageAmtUsd = damageAmtUsd;
		this.damageAmtRmb = damageAmtRmb;
		this.qurUnqulRsnCode = qurUnqulRsnCode;
		this.qurUnqProcCode = qurUnqProcCode;
		this.speQuarTrmtMecC = speQuarTrmtMecC;
		this.quarTrtOrgCode = quarTrtOrgCode;
		this.quarTrtDeptCode = quarTrtDeptCode;
		this.statUnitName = statUnitName;
		this.inspContCodes = inspContCodes;
		this.goodsNameCn = goodsNameCn;
		this.goodsNameEn = goodsNameEn;
		this.goodsflag = goodsflag;
		this.inspResEval = inspResEval;
		this.inspOrgCode = inspOrgCode;
		this.inspDeptCode = inspDeptCode;
		this.inspUnquafWt = inspUnquafWt;
		this.unqulCommInsQty = unqulCommInsQty;
		this.inspUnquaAmt = inspUnquaAmt;
		this.inspUnquAmntUs = inspUnquAmntUs;
		this.inspDisquaAmtRmb = inspDisquaAmtRmb;
		this.quarResEval = quarResEval;
		this.quaraOrgCode = quaraOrgCode;
		this.quarDeptCode = quarDeptCode;
		this.quaranUnquaWt = quaranUnquaWt;
		this.unqulfdQuarQty = unqulfdQuarQty;
		this.unqualQuarAmt = unqualQuarAmt;
		this.unqulQuarAmtUs = unqulQuarAmtUs;
		this.unqulQuarAmtCn = unqulQuarAmtCn;
		this.relsWtValue = relsWtValue;
		this.relsQtyValue = relsQtyValue;
		this.releaseAmt = releaseAmt;
		this.relsAmountUsd = relsAmountUsd;
		this.relsAmountRmb = relsAmountRmb;
		this.relsPackQty = relsPackQty;
		this.relsStdWt = relsStdWt;
		this.relsStdQty = relsStdQty;
		this.apprslOrgCode = apprslOrgCode;
		this.apprtDeptCode = apprtDeptCode;
		this.inspContStr = inspContStr;
		this.quarContStr = quarContStr;
		this.inspDisquaContCodes = inspDisquaContCodes;
		this.quarDisquaContCodes = quarDisquaContCodes;
		this.prevtivTreatmt = prevtivTreatmt;
		this.mnufctrCode = mnufctrCode;
		this.prodBatchNo = prodBatchNo;
		this.inspOperCode = inspOperCode;
		this.insOpertDate = insOpertDate;
		this.quarOperCode = quarOperCode;
		this.quarCondtTime = quarCondtTime;
		this.idenOperCode = idenOperCode;
		this.apprCondtTime = apprCondtTime;
		this.sntTrtOperCode = sntTrtOperCode;
		this.treatOperateDate = treatOperateDate;
		this.treatUnit = treatUnit;
		this.treatTime = treatTime;
		this.treatTimeUnit = treatTimeUnit;
		this.treatTemper = treatTemper;
		this.medicName = medicName;
		this.prevTreatTm = prevTreatTm;
		this.preTreatTmUnit = preTreatTmUnit;
		this.prvntTreatTemp = prvntTreatTemp;
		this.prevMedicName = prevMedicName;
		this.treatMedicDens = treatMedicDens;
		this.medicConcen = medicConcen;
		this.actualQty = actualQty;
		this.realWeight = realWeight;
		this.actSmplNum = actSmplNum;
		this.suggSmplNum = suggSmplNum;
		this.inspQty = inspQty;
		this.declWt = declWt;
		this.declGoodsValues = declGoodsValues;
		this.declValuesUsd = declValuesUsd;
		this.declValuesRmb = declValuesRmb;
		this.produceDate = produceDate;
		this.extDisquaCauseCode = extDisquaCauseCode;
		this.extDisquaCauseDesc = extDisquaCauseDesc;
		this.extDisquCauseCode = extDisquCauseCode;
		this.extDisquCauseDesc = extDisquCauseDesc;
		this.standardNo = standardNo;
		this.disDetailInfo = disDetailInfo;
		this.riskInfoLevelCode = riskInfoLevelCode;
		this.reportOrgCode = reportOrgCode;
		this.disquaTypeCode = disquaTypeCode;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.contNo = contNo;
		this.preMeasBasisCode = preMeasBasisCode;
		this.archiveTime = archiveTime;
		this.inspResSpot = inspResSpot;
		this.quarResSpot = quarResSpot;
	}

	// Property accessors
	@Id
	@Column(name = "RESULT_GOODS_ID", unique = true, nullable = false, length = 32)
	public String getResultGoodsId() {
		return this.resultGoodsId;
	}

	public void setResultGoodsId(String resultGoodsId) {
		this.resultGoodsId = resultGoodsId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PROD_HS_CODE", length = 12)
	public String getProdHsCode() {
		return this.prodHsCode;
	}

	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}

	@Column(name = "STAT_KIND_CODE", length = 20)
	public String getStatKindCode() {
		return this.statKindCode;
	}

	public void setStatKindCode(String statKindCode) {
		this.statKindCode = statKindCode;
	}

	@Column(name = "SPEC", length = 100)
	public String getSpec() {
		return this.spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	@Column(name = "MESU_UN_TYP_CODE", length = 4)
	public String getMesuUnTypCode() {
		return this.mesuUnTypCode;
	}

	public void setMesuUnTypCode(String mesuUnTypCode) {
		this.mesuUnTypCode = mesuUnTypCode;
	}

	@Column(name = "WEIGHT_NET", precision = 0)
	public Double getWeightNet() {
		return this.weightNet;
	}

	public void setWeightNet(Double weightNet) {
		this.weightNet = weightNet;
	}

	@Column(name = "WEIGHT_GROSS", precision = 0)
	public Double getWeightGross() {
		return this.weightGross;
	}

	public void setWeightGross(Double weightGross) {
		this.weightGross = weightGross;
	}

	@Column(name = "WT_UNIT_CODE", length = 4)
	public String getWtUnitCode() {
		return this.wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	@Column(name = "STD_WT", precision = 0)
	public Double getStdWt() {
		return this.stdWt;
	}

	public void setStdWt(Double stdWt) {
		this.stdWt = stdWt;
	}

	@Column(name = "STD_WT_UNIT_CODE", length = 4)
	public String getStdWtUnitCode() {
		return this.stdWtUnitCode;
	}

	public void setStdWtUnitCode(String stdWtUnitCode) {
		this.stdWtUnitCode = stdWtUnitCode;
	}

	@Column(name = "STATCL_WT_VALUE", precision = 0)
	public Double getStatclWtValue() {
		return this.statclWtValue;
	}

	public void setStatclWtValue(Double statclWtValue) {
		this.statclWtValue = statclWtValue;
	}

	@Column(name = "STAT_WT_UNIT_CODE", length = 4)
	public String getStatWtUnitCode() {
		return this.statWtUnitCode;
	}

	public void setStatWtUnitCode(String statWtUnitCode) {
		this.statWtUnitCode = statWtUnitCode;
	}

	@Column(name = "QTY", precision = 0)
	public Double getQty() {
		return this.qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	@Column(name = "QTY_UNIT_CODE", length = 4)
	public String getQtyUnitCode() {
		return this.qtyUnitCode;
	}

	public void setQtyUnitCode(String qtyUnitCode) {
		this.qtyUnitCode = qtyUnitCode;
	}

	@Column(name = "STD_QTY", precision = 0)
	public Double getStdQty() {
		return this.stdQty;
	}

	public void setStdQty(Double stdQty) {
		this.stdQty = stdQty;
	}

	@Column(name = "STD_QTY_UNIT_CODE", length = 4)
	public String getStdQtyUnitCode() {
		return this.stdQtyUnitCode;
	}

	public void setStdQtyUnitCode(String stdQtyUnitCode) {
		this.stdQtyUnitCode = stdQtyUnitCode;
	}

	@Column(name = "STATCL_QTY_VALUE", precision = 0)
	public Double getStatclQtyValue() {
		return this.statclQtyValue;
	}

	public void setStatclQtyValue(Double statclQtyValue) {
		this.statclQtyValue = statclQtyValue;
	}

	@Column(name = "STAT_QUATY_UN_CO", length = 4)
	public String getStatQuatyUnCo() {
		return this.statQuatyUnCo;
	}

	public void setStatQuatyUnCo(String statQuatyUnCo) {
		this.statQuatyUnCo = statQuatyUnCo;
	}

	@Column(name = "PACK_QTY", precision = 0)
	public Double getPackQty() {
		return this.packQty;
	}

	public void setPackQty(Double packQty) {
		this.packQty = packQty;
	}

	@Column(name = "PACK_TYPE_CODE", length = 4)
	public String getPackTypeCode() {
		return this.packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	@Column(name = "CURRENCY", length = 4)
	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@Column(name = "GOODS_TOTAL_VAL", precision = 0)
	public Double getGoodsTotalVal() {
		return this.goodsTotalVal;
	}

	public void setGoodsTotalVal(Double goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}

	@Column(name = "TOTAL_VAL_US", precision = 0)
	public Double getTotalValUs() {
		return this.totalValUs;
	}

	public void setTotalValUs(Double totalValUs) {
		this.totalValUs = totalValUs;
	}

	@Column(name = "TOTAL_VAL_CN", precision = 0)
	public Double getTotalValCn() {
		return this.totalValCn;
	}

	public void setTotalValCn(Double totalValCn) {
		this.totalValCn = totalValCn;
	}

	@Column(name = "GOODS_PLACE", length = 100)
	public String getGoodsPlace() {
		return this.goodsPlace;
	}

	public void setGoodsPlace(String goodsPlace) {
		this.goodsPlace = goodsPlace;
	}

	@Column(name = "ENTRY_DATE", length = 7)
	public Timestamp getEntryDate() {
		return this.entryDate;
	}

	public void setEntryDate(Timestamp entryDate) {
		this.entryDate = entryDate;
	}

	@Column(name = "CMPL_DSCHRG_DT", length = 7)
	public Timestamp getCmplDschrgDt() {
		return this.cmplDschrgDt;
	}

	public void setCmplDschrgDt(Timestamp cmplDschrgDt) {
		this.cmplDschrgDt = cmplDschrgDt;
	}

	@Column(name = "UNQUA_WT", precision = 0)
	public Double getUnquaWt() {
		return this.unquaWt;
	}

	public void setUnquaWt(Double unquaWt) {
		this.unquaWt = unquaWt;
	}

	@Column(name = "UNQUAL_QTY", precision = 0)
	public Double getUnqualQty() {
		return this.unqualQty;
	}

	public void setUnqualQty(Double unqualQty) {
		this.unqualQty = unqualQty;
	}

	@Column(name = "UNQUAL_AMT", precision = 0)
	public Double getUnqualAmt() {
		return this.unqualAmt;
	}

	public void setUnqualAmt(Double unqualAmt) {
		this.unqualAmt = unqualAmt;
	}

	@Column(name = "UNQU_AMNT_USD", precision = 0)
	public Double getUnquAmntUsd() {
		return this.unquAmntUsd;
	}

	public void setUnquAmntUsd(Double unquAmntUsd) {
		this.unquAmntUsd = unquAmntUsd;
	}

	@Column(name = "DISQUA_AMT_RMB", precision = 0)
	public Double getDisquaAmtRmb() {
		return this.disquaAmtRmb;
	}

	public void setDisquaAmtRmb(Double disquaAmtRmb) {
		this.disquaAmtRmb = disquaAmtRmb;
	}

	@Column(name = "CLAIM_AMT", precision = 0)
	public Double getClaimAmt() {
		return this.claimAmt;
	}

	public void setClaimAmt(Double claimAmt) {
		this.claimAmt = claimAmt;
	}

	@Column(name = "CLAIM_AMT_USD", precision = 0)
	public Double getClaimAmtUsd() {
		return this.claimAmtUsd;
	}

	public void setClaimAmtUsd(Double claimAmtUsd) {
		this.claimAmtUsd = claimAmtUsd;
	}

	@Column(name = "CLAIM_AMT_RMB", precision = 0)
	public Double getClaimAmtRmb() {
		return this.claimAmtRmb;
	}

	public void setClaimAmtRmb(Double claimAmtRmb) {
		this.claimAmtRmb = claimAmtRmb;
	}

	@Column(name = "DISQUA_CONT_CODES", length = 50)
	public String getDisquaContCodes() {
		return this.disquaContCodes;
	}

	public void setDisquaContCodes(String disquaContCodes) {
		this.disquaContCodes = disquaContCodes;
	}

	@Column(name = "INSP_UNQ_RESN", length = 300)
	public String getInspUnqResn() {
		return this.inspUnqResn;
	}

	public void setInspUnqResn(String inspUnqResn) {
		this.inspUnqResn = inspUnqResn;
	}

	@Column(name = "INP_UNQUAL_HA_CODE", length = 300)
	public String getInpUnqualHaCode() {
		return this.inpUnqualHaCode;
	}

	public void setInpUnqualHaCode(String inpUnqualHaCode) {
		this.inpUnqualHaCode = inpUnqualHaCode;
	}

	@Column(name = "INSP_PATTERN_CODE", length = 4)
	public String getInspPatternCode() {
		return this.inspPatternCode;
	}

	public void setInspPatternCode(String inspPatternCode) {
		this.inspPatternCode = inspPatternCode;
	}

	@Column(name = "WT_DET_MODE_CODE", length = 4)
	public String getWtDetModeCode() {
		return this.wtDetModeCode;
	}

	public void setWtDetModeCode(String wtDetModeCode) {
		this.wtDetModeCode = wtDetModeCode;
	}

	@Column(name = "WT_DET_WORK_MODE_C", length = 4)
	public String getWtDetWorkModeC() {
		return this.wtDetWorkModeC;
	}

	public void setWtDetWorkModeC(String wtDetWorkModeC) {
		this.wtDetWorkModeC = wtDetWorkModeC;
	}

	@Column(name = "DAMAG_ID_PRO_CODE", length = 4)
	public String getDamagIdProCode() {
		return this.damagIdProCode;
	}

	public void setDamagIdProCode(String damagIdProCode) {
		this.damagIdProCode = damagIdProCode;
	}

	@Column(name = "DAMGED_RESN_CODE", length = 4)
	public String getDamgedResnCode() {
		return this.damgedResnCode;
	}

	public void setDamgedResnCode(String damgedResnCode) {
		this.damgedResnCode = damgedResnCode;
	}

	@Column(name = "DAMAGED_AMT", precision = 0)
	public Double getDamagedAmt() {
		return this.damagedAmt;
	}

	public void setDamagedAmt(Double damagedAmt) {
		this.damagedAmt = damagedAmt;
	}

	@Column(name = "DAMAGE_AMT_USD", precision = 0)
	public Double getDamageAmtUsd() {
		return this.damageAmtUsd;
	}

	public void setDamageAmtUsd(Double damageAmtUsd) {
		this.damageAmtUsd = damageAmtUsd;
	}

	@Column(name = "DAMAGE_AMT_RMB", precision = 0)
	public Double getDamageAmtRmb() {
		return this.damageAmtRmb;
	}

	public void setDamageAmtRmb(Double damageAmtRmb) {
		this.damageAmtRmb = damageAmtRmb;
	}

	@Column(name = "QUR_UNQUL_RSN_CODE", length = 300)
	public String getQurUnqulRsnCode() {
		return this.qurUnqulRsnCode;
	}

	public void setQurUnqulRsnCode(String qurUnqulRsnCode) {
		this.qurUnqulRsnCode = qurUnqulRsnCode;
	}

	@Column(name = "QUR_UNQ_PROC_CODE", length = 300)
	public String getQurUnqProcCode() {
		return this.qurUnqProcCode;
	}

	public void setQurUnqProcCode(String qurUnqProcCode) {
		this.qurUnqProcCode = qurUnqProcCode;
	}

	@Column(name = "SPE_QUAR_TRMT_MEC_C", length = 300)
	public String getSpeQuarTrmtMecC() {
		return this.speQuarTrmtMecC;
	}

	public void setSpeQuarTrmtMecC(String speQuarTrmtMecC) {
		this.speQuarTrmtMecC = speQuarTrmtMecC;
	}

	@Column(name = "QUAR_TRT_ORG_CODE", length = 10)
	public String getQuarTrtOrgCode() {
		return this.quarTrtOrgCode;
	}

	public void setQuarTrtOrgCode(String quarTrtOrgCode) {
		this.quarTrtOrgCode = quarTrtOrgCode;
	}

	@Column(name = "QUAR_TRT_DEPT_CODE", length = 10)
	public String getQuarTrtDeptCode() {
		return this.quarTrtDeptCode;
	}

	public void setQuarTrtDeptCode(String quarTrtDeptCode) {
		this.quarTrtDeptCode = quarTrtDeptCode;
	}

	@Column(name = "STAT_UNIT_NAME", length = 20)
	public String getStatUnitName() {
		return this.statUnitName;
	}

	public void setStatUnitName(String statUnitName) {
		this.statUnitName = statUnitName;
	}

	@Column(name = "INSP_CONT_CODES", length = 50)
	public String getInspContCodes() {
		return this.inspContCodes;
	}

	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}

	@Column(name = "GOODS_NAME_CN", length = 300)
	public String getGoodsNameCn() {
		return this.goodsNameCn;
	}

	public void setGoodsNameCn(String goodsNameCn) {
		this.goodsNameCn = goodsNameCn;
	}

	@Column(name = "GOODS_NAME_EN", length = 100)
	public String getGoodsNameEn() {
		return this.goodsNameEn;
	}

	public void setGoodsNameEn(String goodsNameEn) {
		this.goodsNameEn = goodsNameEn;
	}

	@Column(name = "GOODSFLAG", length = 4)
	public String getGoodsflag() {
		return this.goodsflag;
	}

	public void setGoodsflag(String goodsflag) {
		this.goodsflag = goodsflag;
	}

	@Column(name = "INSP_RES_EVAL", length = 4)
	public String getInspResEval() {
		return this.inspResEval;
	}

	public void setInspResEval(String inspResEval) {
		this.inspResEval = inspResEval;
	}

	@Column(name = "INSP_ORG_CODE", length = 10)
	public String getInspOrgCode() {
		return this.inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	@Column(name = "INSP_DEPT_CODE", length = 10)
	public String getInspDeptCode() {
		return this.inspDeptCode;
	}

	public void setInspDeptCode(String inspDeptCode) {
		this.inspDeptCode = inspDeptCode;
	}

	@Column(name = "INSP_UNQUAF_WT", precision = 0)
	public Double getInspUnquafWt() {
		return this.inspUnquafWt;
	}

	public void setInspUnquafWt(Double inspUnquafWt) {
		this.inspUnquafWt = inspUnquafWt;
	}

	@Column(name = "UNQUL_COMM_INS_QTY", precision = 0)
	public Double getUnqulCommInsQty() {
		return this.unqulCommInsQty;
	}

	public void setUnqulCommInsQty(Double unqulCommInsQty) {
		this.unqulCommInsQty = unqulCommInsQty;
	}

	@Column(name = "INSP_UNQUA_AMT", precision = 0)
	public Double getInspUnquaAmt() {
		return this.inspUnquaAmt;
	}

	public void setInspUnquaAmt(Double inspUnquaAmt) {
		this.inspUnquaAmt = inspUnquaAmt;
	}

	@Column(name = "INSP_UNQU_AMNT_US", precision = 0)
	public Double getInspUnquAmntUs() {
		return this.inspUnquAmntUs;
	}

	public void setInspUnquAmntUs(Double inspUnquAmntUs) {
		this.inspUnquAmntUs = inspUnquAmntUs;
	}

	@Column(name = "INSP_DISQUA_AMT_RMB", precision = 0)
	public Double getInspDisquaAmtRmb() {
		return this.inspDisquaAmtRmb;
	}

	public void setInspDisquaAmtRmb(Double inspDisquaAmtRmb) {
		this.inspDisquaAmtRmb = inspDisquaAmtRmb;
	}

	@Column(name = "QUAR_RES_EVAL", length = 4)
	public String getQuarResEval() {
		return this.quarResEval;
	}

	public void setQuarResEval(String quarResEval) {
		this.quarResEval = quarResEval;
	}

	@Column(name = "QUARA_ORG_CODE", length = 10)
	public String getQuaraOrgCode() {
		return this.quaraOrgCode;
	}

	public void setQuaraOrgCode(String quaraOrgCode) {
		this.quaraOrgCode = quaraOrgCode;
	}

	@Column(name = "QUAR_DEPT_CODE", length = 10)
	public String getQuarDeptCode() {
		return this.quarDeptCode;
	}

	public void setQuarDeptCode(String quarDeptCode) {
		this.quarDeptCode = quarDeptCode;
	}

	@Column(name = "QUARAN_UNQUA_WT", precision = 0)
	public Double getQuaranUnquaWt() {
		return this.quaranUnquaWt;
	}

	public void setQuaranUnquaWt(Double quaranUnquaWt) {
		this.quaranUnquaWt = quaranUnquaWt;
	}

	@Column(name = "UNQULFD_QUAR_QTY", precision = 0)
	public Double getUnqulfdQuarQty() {
		return this.unqulfdQuarQty;
	}

	public void setUnqulfdQuarQty(Double unqulfdQuarQty) {
		this.unqulfdQuarQty = unqulfdQuarQty;
	}

	@Column(name = "UNQUAL_QUAR_AMT", precision = 0)
	public Double getUnqualQuarAmt() {
		return this.unqualQuarAmt;
	}

	public void setUnqualQuarAmt(Double unqualQuarAmt) {
		this.unqualQuarAmt = unqualQuarAmt;
	}

	@Column(name = "UNQUL_QUAR_AMT_US", precision = 0)
	public Double getUnqulQuarAmtUs() {
		return this.unqulQuarAmtUs;
	}

	public void setUnqulQuarAmtUs(Double unqulQuarAmtUs) {
		this.unqulQuarAmtUs = unqulQuarAmtUs;
	}

	@Column(name = "UNQUL_QUAR_AMT_CN", precision = 0)
	public Double getUnqulQuarAmtCn() {
		return this.unqulQuarAmtCn;
	}

	public void setUnqulQuarAmtCn(Double unqulQuarAmtCn) {
		this.unqulQuarAmtCn = unqulQuarAmtCn;
	}

	@Column(name = "RELS_WT_VALUE", precision = 0)
	public Double getRelsWtValue() {
		return this.relsWtValue;
	}

	public void setRelsWtValue(Double relsWtValue) {
		this.relsWtValue = relsWtValue;
	}

	@Column(name = "RELS_QTY_VALUE", precision = 0)
	public Double getRelsQtyValue() {
		return this.relsQtyValue;
	}

	public void setRelsQtyValue(Double relsQtyValue) {
		this.relsQtyValue = relsQtyValue;
	}

	@Column(name = "RELEASE_AMT", precision = 0)
	public Double getReleaseAmt() {
		return this.releaseAmt;
	}

	public void setReleaseAmt(Double releaseAmt) {
		this.releaseAmt = releaseAmt;
	}

	@Column(name = "RELS_AMOUNT_USD", precision = 0)
	public Double getRelsAmountUsd() {
		return this.relsAmountUsd;
	}

	public void setRelsAmountUsd(Double relsAmountUsd) {
		this.relsAmountUsd = relsAmountUsd;
	}

	@Column(name = "RELS_AMOUNT_RMB", precision = 0)
	public Double getRelsAmountRmb() {
		return this.relsAmountRmb;
	}

	public void setRelsAmountRmb(Double relsAmountRmb) {
		this.relsAmountRmb = relsAmountRmb;
	}

	@Column(name = "RELS_PACK_QTY", precision = 0)
	public Double getRelsPackQty() {
		return this.relsPackQty;
	}

	public void setRelsPackQty(Double relsPackQty) {
		this.relsPackQty = relsPackQty;
	}

	@Column(name = "RELS_STD_WT", precision = 0)
	public Double getRelsStdWt() {
		return this.relsStdWt;
	}

	public void setRelsStdWt(Double relsStdWt) {
		this.relsStdWt = relsStdWt;
	}

	@Column(name = "RELS_STD_QTY", precision = 0)
	public Double getRelsStdQty() {
		return this.relsStdQty;
	}

	public void setRelsStdQty(Double relsStdQty) {
		this.relsStdQty = relsStdQty;
	}

	@Column(name = "APPRSL_ORG_CODE", length = 10)
	public String getApprslOrgCode() {
		return this.apprslOrgCode;
	}

	public void setApprslOrgCode(String apprslOrgCode) {
		this.apprslOrgCode = apprslOrgCode;
	}

	@Column(name = "APPRT_DEPT_CODE", length = 10)
	public String getApprtDeptCode() {
		return this.apprtDeptCode;
	}

	public void setApprtDeptCode(String apprtDeptCode) {
		this.apprtDeptCode = apprtDeptCode;
	}

	@Column(name = "INSP_CONT_STR", length = 50)
	public String getInspContStr() {
		return this.inspContStr;
	}

	public void setInspContStr(String inspContStr) {
		this.inspContStr = inspContStr;
	}

	@Column(name = "QUAR_CONT_STR", length = 50)
	public String getQuarContStr() {
		return this.quarContStr;
	}

	public void setQuarContStr(String quarContStr) {
		this.quarContStr = quarContStr;
	}

	@Column(name = "INSP_DISQUA_CONT_CODES", length = 50)
	public String getInspDisquaContCodes() {
		return this.inspDisquaContCodes;
	}

	public void setInspDisquaContCodes(String inspDisquaContCodes) {
		this.inspDisquaContCodes = inspDisquaContCodes;
	}

	@Column(name = "QUAR_DISQUA_CONT_CODES", length = 50)
	public String getQuarDisquaContCodes() {
		return this.quarDisquaContCodes;
	}

	public void setQuarDisquaContCodes(String quarDisquaContCodes) {
		this.quarDisquaContCodes = quarDisquaContCodes;
	}

	@Column(name = "PREVTIV_TREATMT", length = 4)
	public String getPrevtivTreatmt() {
		return this.prevtivTreatmt;
	}

	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}

	@Column(name = "MNUFCTR_CODE", length = 20)
	public String getMnufctrCode() {
		return this.mnufctrCode;
	}

	public void setMnufctrCode(String mnufctrCode) {
		this.mnufctrCode = mnufctrCode;
	}

	@Column(name = "PROD_BATCH_NO", length = 2000)
	public String getProdBatchNo() {
		return this.prodBatchNo;
	}

	public void setProdBatchNo(String prodBatchNo) {
		this.prodBatchNo = prodBatchNo;
	}

	@Column(name = "INSP_OPER_CODE", length = 20)
	public String getInspOperCode() {
		return this.inspOperCode;
	}

	public void setInspOperCode(String inspOperCode) {
		this.inspOperCode = inspOperCode;
	}

	@Column(name = "INS_OPERT_DATE", length = 7)
	public Timestamp getInsOpertDate() {
		return this.insOpertDate;
	}

	public void setInsOpertDate(Timestamp insOpertDate) {
		this.insOpertDate = insOpertDate;
	}

	@Column(name = "QUAR_OPER_CODE", length = 20)
	public String getQuarOperCode() {
		return this.quarOperCode;
	}

	public void setQuarOperCode(String quarOperCode) {
		this.quarOperCode = quarOperCode;
	}

	@Column(name = "QUAR_CONDT_TIME", length = 7)
	public Timestamp getQuarCondtTime() {
		return this.quarCondtTime;
	}

	public void setQuarCondtTime(Timestamp quarCondtTime) {
		this.quarCondtTime = quarCondtTime;
	}

	@Column(name = "IDEN_OPER_CODE", length = 20)
	public String getIdenOperCode() {
		return this.idenOperCode;
	}

	public void setIdenOperCode(String idenOperCode) {
		this.idenOperCode = idenOperCode;
	}

	@Column(name = "APPR_CONDT_TIME", length = 7)
	public Timestamp getApprCondtTime() {
		return this.apprCondtTime;
	}

	public void setApprCondtTime(Timestamp apprCondtTime) {
		this.apprCondtTime = apprCondtTime;
	}

	@Column(name = "SNT_TRT_OPER_CODE", length = 20)
	public String getSntTrtOperCode() {
		return this.sntTrtOperCode;
	}

	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}

	@Column(name = "TREAT_OPERATE_DATE", length = 7)
	public Timestamp getTreatOperateDate() {
		return this.treatOperateDate;
	}

	public void setTreatOperateDate(Timestamp treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}

	@Column(name = "TREAT_UNIT", length = 50)
	public String getTreatUnit() {
		return this.treatUnit;
	}

	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}

	@Column(name = "TREAT_TIME", precision = 0)
	public Double getTreatTime() {
		return this.treatTime;
	}

	public void setTreatTime(Double treatTime) {
		this.treatTime = treatTime;
	}

	@Column(name = "TREAT_TIME_UNIT", length = 20)
	public String getTreatTimeUnit() {
		return this.treatTimeUnit;
	}

	public void setTreatTimeUnit(String treatTimeUnit) {
		this.treatTimeUnit = treatTimeUnit;
	}

	@Column(name = "TREAT_TEMPER", precision = 0)
	public Double getTreatTemper() {
		return this.treatTemper;
	}

	public void setTreatTemper(Double treatTemper) {
		this.treatTemper = treatTemper;
	}

	@Column(name = "MEDIC_NAME", length = 20)
	public String getMedicName() {
		return this.medicName;
	}

	public void setMedicName(String medicName) {
		this.medicName = medicName;
	}

	@Column(name = "PREV_TREAT_TM", precision = 0)
	public Double getPrevTreatTm() {
		return this.prevTreatTm;
	}

	public void setPrevTreatTm(Double prevTreatTm) {
		this.prevTreatTm = prevTreatTm;
	}

	@Column(name = "PRE_TREAT_TM_UNIT", length = 20)
	public String getPreTreatTmUnit() {
		return this.preTreatTmUnit;
	}

	public void setPreTreatTmUnit(String preTreatTmUnit) {
		this.preTreatTmUnit = preTreatTmUnit;
	}

	@Column(name = "PRVNT_TREAT_TEMP", precision = 0)
	public Double getPrvntTreatTemp() {
		return this.prvntTreatTemp;
	}

	public void setPrvntTreatTemp(Double prvntTreatTemp) {
		this.prvntTreatTemp = prvntTreatTemp;
	}

	@Column(name = "PREV_MEDIC_NAME", length = 20)
	public String getPrevMedicName() {
		return this.prevMedicName;
	}

	public void setPrevMedicName(String prevMedicName) {
		this.prevMedicName = prevMedicName;
	}

	@Column(name = "TREAT_MEDIC_DENS", precision = 0)
	public Double getTreatMedicDens() {
		return this.treatMedicDens;
	}

	public void setTreatMedicDens(Double treatMedicDens) {
		this.treatMedicDens = treatMedicDens;
	}

	@Column(name = "MEDIC_CONCEN", precision = 0)
	public Double getMedicConcen() {
		return this.medicConcen;
	}

	public void setMedicConcen(Double medicConcen) {
		this.medicConcen = medicConcen;
	}

	@Column(name = "ACTUAL_QTY", precision = 0)
	public Double getActualQty() {
		return this.actualQty;
	}

	public void setActualQty(Double actualQty) {
		this.actualQty = actualQty;
	}

	@Column(name = "REAL_WEIGHT", precision = 0)
	public Double getRealWeight() {
		return this.realWeight;
	}

	public void setRealWeight(Double realWeight) {
		this.realWeight = realWeight;
	}

	@Column(name = "ACT_SMPL_NUM", precision = 0)
	public Double getActSmplNum() {
		return this.actSmplNum;
	}

	public void setActSmplNum(Double actSmplNum) {
		this.actSmplNum = actSmplNum;
	}

	@Column(name = "SUGG_SMPL_NUM", precision = 0)
	public Double getSuggSmplNum() {
		return this.suggSmplNum;
	}

	public void setSuggSmplNum(Double suggSmplNum) {
		this.suggSmplNum = suggSmplNum;
	}

	@Column(name = "INSP_QTY", precision = 0)
	public Double getInspQty() {
		return this.inspQty;
	}

	public void setInspQty(Double inspQty) {
		this.inspQty = inspQty;
	}

	@Column(name = "DECL_WT", precision = 0)
	public Double getDeclWt() {
		return this.declWt;
	}

	public void setDeclWt(Double declWt) {
		this.declWt = declWt;
	}

	@Column(name = "DECL_GOODS_VALUES", precision = 0)
	public Double getDeclGoodsValues() {
		return this.declGoodsValues;
	}

	public void setDeclGoodsValues(Double declGoodsValues) {
		this.declGoodsValues = declGoodsValues;
	}

	@Column(name = "DECL_VALUES_USD", precision = 0)
	public Double getDeclValuesUsd() {
		return this.declValuesUsd;
	}

	public void setDeclValuesUsd(Double declValuesUsd) {
		this.declValuesUsd = declValuesUsd;
	}

	@Column(name = "DECL_VALUES_RMB", precision = 0)
	public Double getDeclValuesRmb() {
		return this.declValuesRmb;
	}

	public void setDeclValuesRmb(Double declValuesRmb) {
		this.declValuesRmb = declValuesRmb;
	}

	@Column(name = "PRODUCE_DATE", length = 2000)
	public String getProduceDate() {
		return this.produceDate;
	}

	public void setProduceDate(String produceDate) {
		this.produceDate = produceDate;
	}

	@Column(name = "EXT_DISQUA_CAUSE_CODE", length = 50)
	public String getExtDisquaCauseCode() {
		return this.extDisquaCauseCode;
	}

	public void setExtDisquaCauseCode(String extDisquaCauseCode) {
		this.extDisquaCauseCode = extDisquaCauseCode;
	}

	@Column(name = "EXT_DISQUA_CAUSE_DESC", length = 500)
	public String getExtDisquaCauseDesc() {
		return this.extDisquaCauseDesc;
	}

	public void setExtDisquaCauseDesc(String extDisquaCauseDesc) {
		this.extDisquaCauseDesc = extDisquaCauseDesc;
	}

	@Column(name = "EXT_DISQU_CAUSE_CODE", length = 50)
	public String getExtDisquCauseCode() {
		return this.extDisquCauseCode;
	}

	public void setExtDisquCauseCode(String extDisquCauseCode) {
		this.extDisquCauseCode = extDisquCauseCode;
	}

	@Column(name = "EXT_DISQU_CAUSE_DESC", length = 500)
	public String getExtDisquCauseDesc() {
		return this.extDisquCauseDesc;
	}

	public void setExtDisquCauseDesc(String extDisquCauseDesc) {
		this.extDisquCauseDesc = extDisquCauseDesc;
	}

	@Column(name = "STANDARD_NO", length = 50)
	public String getStandardNo() {
		return this.standardNo;
	}

	public void setStandardNo(String standardNo) {
		this.standardNo = standardNo;
	}

	@Column(name = "DIS_DETAIL_INFO", length = 500)
	public String getDisDetailInfo() {
		return this.disDetailInfo;
	}

	public void setDisDetailInfo(String disDetailInfo) {
		this.disDetailInfo = disDetailInfo;
	}

	@Column(name = "RISK_INFO_LEVEL_CODE", length = 12)
	public String getRiskInfoLevelCode() {
		return this.riskInfoLevelCode;
	}

	public void setRiskInfoLevelCode(String riskInfoLevelCode) {
		this.riskInfoLevelCode = riskInfoLevelCode;
	}

	@Column(name = "REPORT_ORG_CODE", length = 200)
	public String getReportOrgCode() {
		return this.reportOrgCode;
	}

	public void setReportOrgCode(String reportOrgCode) {
		this.reportOrgCode = reportOrgCode;
	}

	@Column(name = "DISQUA_TYPE_CODE", length = 4)
	public String getDisquaTypeCode() {
		return this.disquaTypeCode;
	}

	public void setDisquaTypeCode(String disquaTypeCode) {
		this.disquaTypeCode = disquaTypeCode;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "CONT_NO", length = 4000)
	public String getContNo() {
		return this.contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	@Column(name = "PRE_MEAS_BASIS_CODE", length = 4)
	public String getPreMeasBasisCode() {
		return this.preMeasBasisCode;
	}

	public void setPreMeasBasisCode(String preMeasBasisCode) {
		this.preMeasBasisCode = preMeasBasisCode;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "INSP_RES_SPOT", length = 4)
	public String getInspResSpot() {
		return this.inspResSpot;
	}

	public void setInspResSpot(String inspResSpot) {
		this.inspResSpot = inspResSpot;
	}

	@Column(name = "QUAR_RES_SPOT", length = 4)
	public String getQuarResSpot() {
		return this.quarResSpot;
	}

	public void setQuarResSpot(String quarResSpot) {
		this.quarResSpot = quarResSpot;
	}

}
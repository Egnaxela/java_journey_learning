package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsResultRecord entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_RESULT_RECORD", schema = "ECIQ_APP")
public class InsResultRecord implements java.io.Serializable {

	// Fields

	private String resultRecordId;
	private Date insDate;
	private String declNo;
	private String dandNo;
	private String entName;
	private String batchNo;
	private String tradeCountry;
	private String prodLevel;
	private BigDecimal qty;
	private BigDecimal weight;
	private String container;
	private String unNo;
	private BigDecimal packLength;
	private BigDecimal packWidth;
	private BigDecimal packHeight;
	private Double weightGross;
	private Double weightNet;
	private String content;
	private String shipMark;
	private String prodType;
	private String prodDesc;
	private String goodsNo;
	private String inspBasCatCode;
	private String dangBasCatCode;
	private String detectFlag;
	private String detectResult;
	private BigDecimal dangSmplNum;
	private String isMatch;
	private String isCover;
	private String isHold;
	private String isClean;
	private String isContain;
	private String isSuit;
	private String isTag;
	private String isLess;
	private String isNail;
	private String inspMode;
	private String inspDefect;
	private String dangDefect;
	private String inspCommEval;
	private String fireworkEval;
	private String dangEval;
	private String hugeFirework;
	private String inspEval;
	private String specCheckNo;
	private String dropCheckNo;
	private Date specCheckDate;
	private Date dropCheckDate;
	private String drugSafeNo;
	private String drugProhNo;
	private Date drugSafeDate;
	private Date drugProhDate;
	private String remark;
	private Date operDate;
	private String flagArchive;
	private String unName;
	private String prodName;
	private String inspBasCatName;
	private String dangBasCatName;
	private String inspOthCatCode;
	private String inspOthCatName;
	private String dangSmplNo;
	private String inspCommEvalName;
	private String fireworkEvalName;
	private String dangEvalName;
	private String inspEvalName;
	private BigDecimal containerGy;
	private BigDecimal containerS;
	private BigDecimal containerCn;
	private BigDecimal containerBlk;
	private BigDecimal containerPi;

	// Constructors

	/** default constructor */
	public InsResultRecord() {
	}

	/** minimal constructor */
	public InsResultRecord(String resultRecordId) {
		this.resultRecordId = resultRecordId;
	}

	/** full constructor */
	public InsResultRecord(String resultRecordId, Date insDate, String declNo,
			String dandNo, String entName, String batchNo, String tradeCountry,
			String prodLevel, BigDecimal qty, BigDecimal weight,
			String container, String unNo, BigDecimal packLength,
			BigDecimal packWidth, BigDecimal packHeight, Double weightGross,
			Double weightNet, String content, String shipMark, String prodType,
			String prodDesc, String goodsNo, String inspBasCatCode,
			String dangBasCatCode, String detectFlag, String detectResult,
			BigDecimal dangSmplNum, String isMatch, String isCover,
			String isHold, String isClean, String isContain, String isSuit,
			String isTag, String isLess, String isNail, String inspMode,
			String inspDefect, String dangDefect, String inspCommEval,
			String fireworkEval, String dangEval, String hugeFirework,
			String inspEval, String specCheckNo, String dropCheckNo,
			Date specCheckDate, Date dropCheckDate, String drugSafeNo,
			String drugProhNo, Date drugSafeDate, Date drugProhDate,
			String remark, Date operDate, String flagArchive, String unName,
			String prodName, String inspBasCatName, String dangBasCatName,
			String inspOthCatCode, String inspOthCatName, String dangSmplNo,
			String inspCommEvalName, String fireworkEvalName,
			String dangEvalName, String inspEvalName, BigDecimal containerGy,
			BigDecimal containerS, BigDecimal containerCn,
			BigDecimal containerBlk, BigDecimal containerPi) {
		this.resultRecordId = resultRecordId;
		this.insDate = insDate;
		this.declNo = declNo;
		this.dandNo = dandNo;
		this.entName = entName;
		this.batchNo = batchNo;
		this.tradeCountry = tradeCountry;
		this.prodLevel = prodLevel;
		this.qty = qty;
		this.weight = weight;
		this.container = container;
		this.unNo = unNo;
		this.packLength = packLength;
		this.packWidth = packWidth;
		this.packHeight = packHeight;
		this.weightGross = weightGross;
		this.weightNet = weightNet;
		this.content = content;
		this.shipMark = shipMark;
		this.prodType = prodType;
		this.prodDesc = prodDesc;
		this.goodsNo = goodsNo;
		this.inspBasCatCode = inspBasCatCode;
		this.dangBasCatCode = dangBasCatCode;
		this.detectFlag = detectFlag;
		this.detectResult = detectResult;
		this.dangSmplNum = dangSmplNum;
		this.isMatch = isMatch;
		this.isCover = isCover;
		this.isHold = isHold;
		this.isClean = isClean;
		this.isContain = isContain;
		this.isSuit = isSuit;
		this.isTag = isTag;
		this.isLess = isLess;
		this.isNail = isNail;
		this.inspMode = inspMode;
		this.inspDefect = inspDefect;
		this.dangDefect = dangDefect;
		this.inspCommEval = inspCommEval;
		this.fireworkEval = fireworkEval;
		this.dangEval = dangEval;
		this.hugeFirework = hugeFirework;
		this.inspEval = inspEval;
		this.specCheckNo = specCheckNo;
		this.dropCheckNo = dropCheckNo;
		this.specCheckDate = specCheckDate;
		this.dropCheckDate = dropCheckDate;
		this.drugSafeNo = drugSafeNo;
		this.drugProhNo = drugProhNo;
		this.drugSafeDate = drugSafeDate;
		this.drugProhDate = drugProhDate;
		this.remark = remark;
		this.operDate = operDate;
		this.flagArchive = flagArchive;
		this.unName = unName;
		this.prodName = prodName;
		this.inspBasCatName = inspBasCatName;
		this.dangBasCatName = dangBasCatName;
		this.inspOthCatCode = inspOthCatCode;
		this.inspOthCatName = inspOthCatName;
		this.dangSmplNo = dangSmplNo;
		this.inspCommEvalName = inspCommEvalName;
		this.fireworkEvalName = fireworkEvalName;
		this.dangEvalName = dangEvalName;
		this.inspEvalName = inspEvalName;
		this.containerGy = containerGy;
		this.containerS = containerS;
		this.containerCn = containerCn;
		this.containerBlk = containerBlk;
		this.containerPi = containerPi;
	}

	// Property accessors
	@Id
	@Column(name = "RESULT_RECORD_ID", unique = true, nullable = false, length = 32)
	public String getResultRecordId() {
		return this.resultRecordId;
	}

	public void setResultRecordId(String resultRecordId) {
		this.resultRecordId = resultRecordId;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "INS_DATE", length = 7)
	public Date getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Date insDate) {
		this.insDate = insDate;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "DAND_NO", length = 20)
	public String getDandNo() {
		return this.dandNo;
	}

	public void setDandNo(String dandNo) {
		this.dandNo = dandNo;
	}

	@Column(name = "ENT_NAME", length = 100)
	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	@Column(name = "BATCH_NO", length = 50)
	public String getBatchNo() {
		return this.batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	@Column(name = "TRADE_COUNTRY", length = 128)
	public String getTradeCountry() {
		return this.tradeCountry;
	}

	public void setTradeCountry(String tradeCountry) {
		this.tradeCountry = tradeCountry;
	}

	@Column(name = "PROD_LEVEL", length = 1)
	public String getProdLevel() {
		return this.prodLevel;
	}

	public void setProdLevel(String prodLevel) {
		this.prodLevel = prodLevel;
	}

	@Column(name = "QTY", precision = 22, scale = 0)
	public BigDecimal getQty() {
		return this.qty;
	}

	public void setQty(BigDecimal qty) {
		this.qty = qty;
	}

	@Column(name = "WEIGHT", precision = 22, scale = 0)
	public BigDecimal getWeight() {
		return this.weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	@Column(name = "CONTAINER", length = 100)
	public String getContainer() {
		return this.container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	@Column(name = "UN_NO", length = 100)
	public String getUnNo() {
		return this.unNo;
	}

	public void setUnNo(String unNo) {
		this.unNo = unNo;
	}

	@Column(name = "PACK_LENGTH", precision = 22, scale = 0)
	public BigDecimal getPackLength() {
		return this.packLength;
	}

	public void setPackLength(BigDecimal packLength) {
		this.packLength = packLength;
	}

	@Column(name = "PACK_WIDTH", precision = 22, scale = 0)
	public BigDecimal getPackWidth() {
		return this.packWidth;
	}

	public void setPackWidth(BigDecimal packWidth) {
		this.packWidth = packWidth;
	}

	@Column(name = "PACK_HEIGHT", precision = 22, scale = 0)
	public BigDecimal getPackHeight() {
		return this.packHeight;
	}

	public void setPackHeight(BigDecimal packHeight) {
		this.packHeight = packHeight;
	}

	@Column(name = "WEIGHT_GROSS", precision = 20)
	public Double getWeightGross() {
		return this.weightGross;
	}

	public void setWeightGross(Double weightGross) {
		this.weightGross = weightGross;
	}

	@Column(name = "WEIGHT_NET", precision = 10)
	public Double getWeightNet() {
		return this.weightNet;
	}

	public void setWeightNet(Double weightNet) {
		this.weightNet = weightNet;
	}

	@Column(name = "CONTENT", length = 20)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "SHIP_MARK", length = 100)
	public String getShipMark() {
		return this.shipMark;
	}

	public void setShipMark(String shipMark) {
		this.shipMark = shipMark;
	}

	@Column(name = "PROD_TYPE", length = 100)
	public String getProdType() {
		return this.prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	@Column(name = "PROD_DESC", length = 1000)
	public String getProdDesc() {
		return this.prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	@Column(name = "GOODS_NO", length = 100)
	public String getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "INSP_BAS_CAT_CODE", length = 20)
	public String getInspBasCatCode() {
		return this.inspBasCatCode;
	}

	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}

	@Column(name = "DANG_BAS_CAT_CODE", length = 20)
	public String getDangBasCatCode() {
		return this.dangBasCatCode;
	}

	public void setDangBasCatCode(String dangBasCatCode) {
		this.dangBasCatCode = dangBasCatCode;
	}

	@Column(name = "DETECT_FLAG", length = 1)
	public String getDetectFlag() {
		return this.detectFlag;
	}

	public void setDetectFlag(String detectFlag) {
		this.detectFlag = detectFlag;
	}

	@Column(name = "DETECT_RESULT", length = 100)
	public String getDetectResult() {
		return this.detectResult;
	}

	public void setDetectResult(String detectResult) {
		this.detectResult = detectResult;
	}

	@Column(name = "DANG_SMPL_NUM", precision = 22, scale = 0)
	public BigDecimal getDangSmplNum() {
		return this.dangSmplNum;
	}

	public void setDangSmplNum(BigDecimal dangSmplNum) {
		this.dangSmplNum = dangSmplNum;
	}

	@Column(name = "IS_MATCH", length = 1)
	public String getIsMatch() {
		return this.isMatch;
	}

	public void setIsMatch(String isMatch) {
		this.isMatch = isMatch;
	}

	@Column(name = "IS_COVER", length = 1)
	public String getIsCover() {
		return this.isCover;
	}

	public void setIsCover(String isCover) {
		this.isCover = isCover;
	}

	@Column(name = "IS_HOLD", length = 1)
	public String getIsHold() {
		return this.isHold;
	}

	public void setIsHold(String isHold) {
		this.isHold = isHold;
	}

	@Column(name = "IS_CLEAN", length = 1)
	public String getIsClean() {
		return this.isClean;
	}

	public void setIsClean(String isClean) {
		this.isClean = isClean;
	}

	@Column(name = "IS_CONTAIN", length = 1)
	public String getIsContain() {
		return this.isContain;
	}

	public void setIsContain(String isContain) {
		this.isContain = isContain;
	}

	@Column(name = "IS_SUIT", length = 1)
	public String getIsSuit() {
		return this.isSuit;
	}

	public void setIsSuit(String isSuit) {
		this.isSuit = isSuit;
	}

	@Column(name = "IS_TAG", length = 1)
	public String getIsTag() {
		return this.isTag;
	}

	public void setIsTag(String isTag) {
		this.isTag = isTag;
	}

	@Column(name = "IS_LESS", length = 1)
	public String getIsLess() {
		return this.isLess;
	}

	public void setIsLess(String isLess) {
		this.isLess = isLess;
	}

	@Column(name = "IS_NAIL", length = 1)
	public String getIsNail() {
		return this.isNail;
	}

	public void setIsNail(String isNail) {
		this.isNail = isNail;
	}

	@Column(name = "INSP_MODE", length = 1)
	public String getInspMode() {
		return this.inspMode;
	}

	public void setInspMode(String inspMode) {
		this.inspMode = inspMode;
	}

	@Column(name = "INSP_DEFECT", length = 100)
	public String getInspDefect() {
		return this.inspDefect;
	}

	public void setInspDefect(String inspDefect) {
		this.inspDefect = inspDefect;
	}

	@Column(name = "DANG_DEFECT", length = 100)
	public String getDangDefect() {
		return this.dangDefect;
	}

	public void setDangDefect(String dangDefect) {
		this.dangDefect = dangDefect;
	}

	@Column(name = "INSP_COMM_EVAL", length = 1)
	public String getInspCommEval() {
		return this.inspCommEval;
	}

	public void setInspCommEval(String inspCommEval) {
		this.inspCommEval = inspCommEval;
	}

	@Column(name = "FIREWORK_EVAL", length = 1)
	public String getFireworkEval() {
		return this.fireworkEval;
	}

	public void setFireworkEval(String fireworkEval) {
		this.fireworkEval = fireworkEval;
	}

	@Column(name = "DANG_EVAL", length = 1)
	public String getDangEval() {
		return this.dangEval;
	}

	public void setDangEval(String dangEval) {
		this.dangEval = dangEval;
	}

	@Column(name = "HUGE_FIREWORK", length = 100)
	public String getHugeFirework() {
		return this.hugeFirework;
	}

	public void setHugeFirework(String hugeFirework) {
		this.hugeFirework = hugeFirework;
	}

	@Column(name = "INSP_EVAL", length = 1)
	public String getInspEval() {
		return this.inspEval;
	}

	public void setInspEval(String inspEval) {
		this.inspEval = inspEval;
	}

	@Column(name = "SPEC_CHECK_NO", length = 20)
	public String getSpecCheckNo() {
		return this.specCheckNo;
	}

	public void setSpecCheckNo(String specCheckNo) {
		this.specCheckNo = specCheckNo;
	}

	@Column(name = "DROP_CHECK_NO", length = 20)
	public String getDropCheckNo() {
		return this.dropCheckNo;
	}

	public void setDropCheckNo(String dropCheckNo) {
		this.dropCheckNo = dropCheckNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SPEC_CHECK_DATE", length = 7)
	public Date getSpecCheckDate() {
		return this.specCheckDate;
	}

	public void setSpecCheckDate(Date specCheckDate) {
		this.specCheckDate = specCheckDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DROP_CHECK_DATE", length = 7)
	public Date getDropCheckDate() {
		return this.dropCheckDate;
	}

	public void setDropCheckDate(Date dropCheckDate) {
		this.dropCheckDate = dropCheckDate;
	}

	@Column(name = "DRUG_SAFE_NO", length = 20)
	public String getDrugSafeNo() {
		return this.drugSafeNo;
	}

	public void setDrugSafeNo(String drugSafeNo) {
		this.drugSafeNo = drugSafeNo;
	}

	@Column(name = "DRUG_PROH_NO", length = 20)
	public String getDrugProhNo() {
		return this.drugProhNo;
	}

	public void setDrugProhNo(String drugProhNo) {
		this.drugProhNo = drugProhNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DRUG_SAFE_DATE", length = 7)
	public Date getDrugSafeDate() {
		return this.drugSafeDate;
	}

	public void setDrugSafeDate(Date drugSafeDate) {
		this.drugSafeDate = drugSafeDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DRUG_PROH_DATE", length = 7)
	public Date getDrugProhDate() {
		return this.drugProhDate;
	}

	public void setDrugProhDate(Date drugProhDate) {
		this.drugProhDate = drugProhDate;
	}

	@Column(name = "REMARK", length = 2000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_DATE", length = 7)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FLAG_ARCHIVE", length = 1)
	public String getFlagArchive() {
		return this.flagArchive;
	}

	public void setFlagArchive(String flagArchive) {
		this.flagArchive = flagArchive;
	}

	@Column(name = "UN_NAME", length = 100)
	public String getUnName() {
		return this.unName;
	}

	public void setUnName(String unName) {
		this.unName = unName;
	}

	@Column(name = "PROD_NAME", length = 100)
	public String getProdName() {
		return this.prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	@Column(name = "INSP_BAS_CAT_NAME", length = 500)
	public String getInspBasCatName() {
		return this.inspBasCatName;
	}

	public void setInspBasCatName(String inspBasCatName) {
		this.inspBasCatName = inspBasCatName;
	}

	@Column(name = "DANG_BAS_CAT_NAME", length = 20)
	public String getDangBasCatName() {
		return this.dangBasCatName;
	}

	public void setDangBasCatName(String dangBasCatName) {
		this.dangBasCatName = dangBasCatName;
	}

	@Column(name = "INSP_OTH_CAT_CODE", length = 20)
	public String getInspOthCatCode() {
		return this.inspOthCatCode;
	}

	public void setInspOthCatCode(String inspOthCatCode) {
		this.inspOthCatCode = inspOthCatCode;
	}

	@Column(name = "INSP_OTH_CAT_NAME", length = 20)
	public String getInspOthCatName() {
		return this.inspOthCatName;
	}

	public void setInspOthCatName(String inspOthCatName) {
		this.inspOthCatName = inspOthCatName;
	}

	@Column(name = "DANG_SMPL_NO", length = 20)
	public String getDangSmplNo() {
		return this.dangSmplNo;
	}

	public void setDangSmplNo(String dangSmplNo) {
		this.dangSmplNo = dangSmplNo;
	}

	@Column(name = "INSP_COMM_EVAL_NAME", length = 10)
	public String getInspCommEvalName() {
		return this.inspCommEvalName;
	}

	public void setInspCommEvalName(String inspCommEvalName) {
		this.inspCommEvalName = inspCommEvalName;
	}

	@Column(name = "FIREWORK_EVAL_NAME", length = 10)
	public String getFireworkEvalName() {
		return this.fireworkEvalName;
	}

	public void setFireworkEvalName(String fireworkEvalName) {
		this.fireworkEvalName = fireworkEvalName;
	}

	@Column(name = "DANG_EVAL_NAME", length = 10)
	public String getDangEvalName() {
		return this.dangEvalName;
	}

	public void setDangEvalName(String dangEvalName) {
		this.dangEvalName = dangEvalName;
	}

	@Column(name = "INSP_EVAL_NAME", length = 10)
	public String getInspEvalName() {
		return this.inspEvalName;
	}

	public void setInspEvalName(String inspEvalName) {
		this.inspEvalName = inspEvalName;
	}

	@Column(name = "CONTAINER_GY", precision = 22, scale = 0)
	public BigDecimal getContainerGy() {
		return this.containerGy;
	}

	public void setContainerGy(BigDecimal containerGy) {
		this.containerGy = containerGy;
	}

	@Column(name = "CONTAINER_S", precision = 22, scale = 0)
	public BigDecimal getContainerS() {
		return this.containerS;
	}

	public void setContainerS(BigDecimal containerS) {
		this.containerS = containerS;
	}

	@Column(name = "CONTAINER_CN", precision = 22, scale = 0)
	public BigDecimal getContainerCn() {
		return this.containerCn;
	}

	public void setContainerCn(BigDecimal containerCn) {
		this.containerCn = containerCn;
	}

	@Column(name = "CONTAINER_BLK", precision = 22, scale = 0)
	public BigDecimal getContainerBlk() {
		return this.containerBlk;
	}

	public void setContainerBlk(BigDecimal containerBlk) {
		this.containerBlk = containerBlk;
	}

	@Column(name = "CONTAINER_PI", precision = 22, scale = 0)
	public BigDecimal getContainerPi() {
		return this.containerPi;
	}

	public void setContainerPi(BigDecimal containerPi) {
		this.containerPi = containerPi;
	}

}
package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsResultRecordItem entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_RESULT_RECORD_ITEM", schema = "ECIQ_APP")
public class InsResultRecordItem implements java.io.Serializable {

	// Fields

	private String entUuid;
	private BigDecimal resultRecordItemId;
	private String resultRecordId;
	private String itemCode;
	private String defectCode;
	private String sampleSch;
	private String inspEval;
	private String remark;
	private String flagArchive;
	private BigDecimal smplNum;
	private String sampleSchName;

	// Constructors

	/** default constructor */
	public InsResultRecordItem() {
	}

	/** minimal constructor */
	public InsResultRecordItem(String entUuid, BigDecimal resultRecordItemId) {
		this.entUuid = entUuid;
		this.resultRecordItemId = resultRecordItemId;
	}

	/** full constructor */
	public InsResultRecordItem(String entUuid, BigDecimal resultRecordItemId,
			String resultRecordId, String itemCode, String defectCode,
			String sampleSch, String inspEval, String remark, 
			String flagArchive, BigDecimal smplNum, String sampleSchName) {
		this.entUuid = entUuid;
		this.resultRecordItemId = resultRecordItemId;
		this.resultRecordId = resultRecordId;
		this.itemCode = itemCode;
		this.defectCode = defectCode;
		this.sampleSch = sampleSch;
		this.inspEval = inspEval;
		this.remark = remark;
		this.flagArchive = flagArchive;
		this.smplNum = smplNum;
		this.sampleSchName = sampleSchName;
	}

	// Property accessors
	@Id
	@Column(name = "ENT_UUID", unique = true, nullable = false, length = 32)
	public String getEntUuid() {
		return this.entUuid;
	}

	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}

	@Column(name = "RESULT_RECORD_ITEM_ID", nullable = false, precision = 22, scale = 0)
	public BigDecimal getResultRecordItemId() {
		return this.resultRecordItemId;
	}

	public void setResultRecordItemId(BigDecimal resultRecordItemId) {
		this.resultRecordItemId = resultRecordItemId;
	}

	@Column(name = "RESULT_RECORD_ID", length = 32)
	public String getResultRecordId() {
		return this.resultRecordId;
	}

	public void setResultRecordId(String resultRecordId) {
		this.resultRecordId = resultRecordId;
	}

	@Column(name = "ITEM_CODE", length = 10)
	public String getItemCode() {
		return this.itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	@Column(name = "DEFECT_CODE", length = 10)
	public String getDefectCode() {
		return this.defectCode;
	}

	public void setDefectCode(String defectCode) {
		this.defectCode = defectCode;
	}

	@Column(name = "SAMPLE_SCH", length = 100)
	public String getSampleSch() {
		return this.sampleSch;
	}

	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}

	@Column(name = "INSP_EVAL", length = 10)
	public String getInspEval() {
		return this.inspEval;
	}

	public void setInspEval(String inspEval) {
		this.inspEval = inspEval;
	}

	@Column(name = "REMARK", length = 2000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}



	@Column(name = "FLAG_ARCHIVE", length = 1)
	public String getFlagArchive() {
		return this.flagArchive;
	}

	public void setFlagArchive(String flagArchive) {
		this.flagArchive = flagArchive;
	}

	@Column(name = "SMPL_NUM", precision = 22, scale = 0)
	public BigDecimal getSmplNum() {
		return this.smplNum;
	}

	public void setSmplNum(BigDecimal smplNum) {
		this.smplNum = smplNum;
	}

	@Column(name = "SAMPLE_SCH_NAME", length = 100)
	public String getSampleSchName() {
		return this.sampleSchName;
	}

	public void setSampleSchName(String sampleSchName) {
		this.sampleSchName = sampleSchName;
	}

}
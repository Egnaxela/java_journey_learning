package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "INS_RESULT_SUM_SC")
public class InsResultSumScEntity implements java.io.Serializable {

	// Fields

	private String resultSumScId;
	private String declNo;
	private Date insBeginDate;
	private Date inspEndDate;
	private String mnufctrRegNo;
	private String inspBasCatCode;
	private String exeInspOrgCode;
	private String excInspDeptCode;
	private String whetherExteIns;
	private String whether2ndIns;
	private String kepIsolat;
	private String ciqResultCode;
	private String inspResltCode;
	private String certTypeCodes;
	private String markNo;
	private Integer ciqValidPeri;
	private String operatorCode;
	private String certOriginals;
	private String certCopies;
	private String transFlag;
	private String inspResEval;
	private String quarResEval;
	private String wodPackResEval;
	private String inspModeCode;
	private String operateTypeCode;
	private String fstRelsSrtCode;
	private String noticeFlag;
	private String markNoStr;
	private String flagNoStr;
	private String quarResult;
	private String quarProcResult;
	private String basisCoding;
	private String checkPlace;
	private String checker;
	private String spotDesc;
	private String woodpackQuarResult;
	private String contQuarResult;
	private String goodsEvalResult;
	private String contRegiStatus;
	private String remark;
	private String falgArchive;
	private Date operTime;
	private String weatherCode;
	private String preMeasBasisCode;
	private String contNoStr;
	private String chngResn;
	private String inspContCodes;
	private String inspScNo;
	private String inspScFlag;
	private Date archiveTime;
	private String scOrgCode;
	private String scOperatorCode;
	private String whether2ndInsSource;

	// Constructors

	/** default constructor */
	public InsResultSumScEntity() {
	}

	/** minimal constructor */
	public InsResultSumScEntity(String resultSumScId) {
		this.resultSumScId = resultSumScId;
	}

	/** full constructor */
	public InsResultSumScEntity(String resultSumScId, String declNo,
			Date insBeginDate, Date inspEndDate, String mnufctrRegNo,
			String inspBasCatCode, String exeInspOrgCode,
			String excInspDeptCode, String whetherExteIns,
			String whether2ndIns, String kepIsolat, String ciqResultCode,
			String inspResltCode, String certTypeCodes, String markNo,
			Integer ciqValidPeri, String operatorCode, String certOriginals,
			String certCopies, String transFlag, String inspResEval,
			String quarResEval, String wodPackResEval, String inspModeCode,
			String operateTypeCode, String fstRelsSrtCode, String noticeFlag,
			String markNoStr, String flagNoStr, String quarResult,
			String quarProcResult, String basisCoding, String checkPlace,
			String checker, String spotDesc, String woodpackQuarResult,
			String contQuarResult, String goodsEvalResult,
			String contRegiStatus, String remark, String falgArchive,
			Date operTime, String weatherCode, String preMeasBasisCode,
			String contNoStr, String chngResn, String inspContCodes,
			String inspScNo, String inspScFlag, Date archiveTime,
			String scOrgCode, String scOperatorCode, String whether2ndInsSource) {
		this.resultSumScId = resultSumScId;
		this.declNo = declNo;
		this.insBeginDate = insBeginDate;
		this.inspEndDate = inspEndDate;
		this.mnufctrRegNo = mnufctrRegNo;
		this.inspBasCatCode = inspBasCatCode;
		this.exeInspOrgCode = exeInspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.whetherExteIns = whetherExteIns;
		this.whether2ndIns = whether2ndIns;
		this.kepIsolat = kepIsolat;
		this.ciqResultCode = ciqResultCode;
		this.inspResltCode = inspResltCode;
		this.certTypeCodes = certTypeCodes;
		this.markNo = markNo;
		this.ciqValidPeri = ciqValidPeri;
		this.operatorCode = operatorCode;
		this.certOriginals = certOriginals;
		this.certCopies = certCopies;
		this.transFlag = transFlag;
		this.inspResEval = inspResEval;
		this.quarResEval = quarResEval;
		this.wodPackResEval = wodPackResEval;
		this.inspModeCode = inspModeCode;
		this.operateTypeCode = operateTypeCode;
		this.fstRelsSrtCode = fstRelsSrtCode;
		this.noticeFlag = noticeFlag;
		this.markNoStr = markNoStr;
		this.flagNoStr = flagNoStr;
		this.quarResult = quarResult;
		this.quarProcResult = quarProcResult;
		this.basisCoding = basisCoding;
		this.checkPlace = checkPlace;
		this.checker = checker;
		this.spotDesc = spotDesc;
		this.woodpackQuarResult = woodpackQuarResult;
		this.contQuarResult = contQuarResult;
		this.goodsEvalResult = goodsEvalResult;
		this.contRegiStatus = contRegiStatus;
		this.remark = remark;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.weatherCode = weatherCode;
		this.preMeasBasisCode = preMeasBasisCode;
		this.contNoStr = contNoStr;
		this.chngResn = chngResn;
		this.inspContCodes = inspContCodes;
		this.inspScNo = inspScNo;
		this.inspScFlag = inspScFlag;
		this.archiveTime = archiveTime;
		this.scOrgCode = scOrgCode;
		this.scOperatorCode = scOperatorCode;
		this.whether2ndInsSource = whether2ndInsSource;
	}

	// Property accessors
	@Id
	@Column(name = "RESULT_SUM_SC_ID", unique = true, nullable = false, length = 32)
	public String getResultSumScId() {
		return this.resultSumScId;
	}

	public void setResultSumScId(String resultSumScId) {
		this.resultSumScId = resultSumScId;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "INS_BEGIN_DATE", length = 7)
	public Date getInsBeginDate() {
		return this.insBeginDate;
	}

	public void setInsBeginDate(Date insBeginDate) {
		this.insBeginDate = insBeginDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "INSP_END_DATE", length = 7)
	public Date getInspEndDate() {
		return this.inspEndDate;
	}

	public void setInspEndDate(Date inspEndDate) {
		this.inspEndDate = inspEndDate;
	}

	@Column(name = "MNUFCTR_REG_NO", length = 20)
	public String getMnufctrRegNo() {
		return this.mnufctrRegNo;
	}

	public void setMnufctrRegNo(String mnufctrRegNo) {
		this.mnufctrRegNo = mnufctrRegNo;
	}

	@Column(name = "INSP_BAS_CAT_CODE", length = 20)
	public String getInspBasCatCode() {
		return this.inspBasCatCode;
	}

	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}

	@Column(name = "EXE_INSP_ORG_CODE", length = 10)
	public String getExeInspOrgCode() {
		return this.exeInspOrgCode;
	}

	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "WHETHER_EXTE_INS", length = 1)
	public String getWhetherExteIns() {
		return this.whetherExteIns;
	}

	public void setWhetherExteIns(String whetherExteIns) {
		this.whetherExteIns = whetherExteIns;
	}

	@Column(name = "WHETHER2ND_INS", length = 1)
	public String getWhether2ndIns() {
		return this.whether2ndIns;
	}

	public void setWhether2ndIns(String whether2ndIns) {
		this.whether2ndIns = whether2ndIns;
	}

	@Column(name = "KEP_ISOLAT", length = 1)
	public String getKepIsolat() {
		return this.kepIsolat;
	}

	public void setKepIsolat(String kepIsolat) {
		this.kepIsolat = kepIsolat;
	}

	@Column(name = "CIQ_RESULT_CODE", length = 4)
	public String getCiqResultCode() {
		return this.ciqResultCode;
	}

	public void setCiqResultCode(String ciqResultCode) {
		this.ciqResultCode = ciqResultCode;
	}

	@Column(name = "INSP_RESLT_CODE", length = 4)
	public String getInspResltCode() {
		return this.inspResltCode;
	}

	public void setInspResltCode(String inspResltCode) {
		this.inspResltCode = inspResltCode;
	}

	@Column(name = "CERT_TYPE_CODES", length = 500)
	public String getCertTypeCodes() {
		return this.certTypeCodes;
	}

	public void setCertTypeCodes(String certTypeCodes) {
		this.certTypeCodes = certTypeCodes;
	}

	@Column(name = "MARK_NO", length = 400)
	public String getMarkNo() {
		return this.markNo;
	}

	public void setMarkNo(String markNo) {
		this.markNo = markNo;
	}

	@Column(name = "CIQ_VALID_PERI", precision = 22, scale = 0)
	public Integer getCiqValidPeri() {
		return this.ciqValidPeri;
	}

	public void setCiqValidPeri(Integer ciqValidPeri) {
		this.ciqValidPeri = ciqValidPeri;
	}

	@Column(name = "OPERATOR_CODE", length = 20)
	public String getOperatorCode() {
		return this.operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	@Column(name = "CERT_ORIGINALS", length = 50)
	public String getCertOriginals() {
		return this.certOriginals;
	}

	public void setCertOriginals(String certOriginals) {
		this.certOriginals = certOriginals;
	}

	@Column(name = "CERT_COPIES", length = 50)
	public String getCertCopies() {
		return this.certCopies;
	}

	public void setCertCopies(String certCopies) {
		this.certCopies = certCopies;
	}

	@Column(name = "TRANS_FLAG", length = 10)
	public String getTransFlag() {
		return this.transFlag;
	}

	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}

	@Column(name = "INSP_RES_EVAL", length = 4)
	public String getInspResEval() {
		return this.inspResEval;
	}

	public void setInspResEval(String inspResEval) {
		this.inspResEval = inspResEval;
	}

	@Column(name = "QUAR_RES_EVAL", length = 4)
	public String getQuarResEval() {
		return this.quarResEval;
	}

	public void setQuarResEval(String quarResEval) {
		this.quarResEval = quarResEval;
	}

	@Column(name = "WOD_PACK_RES_EVAL", length = 4)
	public String getWodPackResEval() {
		return this.wodPackResEval;
	}

	public void setWodPackResEval(String wodPackResEval) {
		this.wodPackResEval = wodPackResEval;
	}

	@Column(name = "INSP_MODE_CODE", length = 4)
	public String getInspModeCode() {
		return this.inspModeCode;
	}

	public void setInspModeCode(String inspModeCode) {
		this.inspModeCode = inspModeCode;
	}

	@Column(name = "OPERATE_TYPE_CODE", length = 4)
	public String getOperateTypeCode() {
		return this.operateTypeCode;
	}

	public void setOperateTypeCode(String operateTypeCode) {
		this.operateTypeCode = operateTypeCode;
	}

	@Column(name = "FST_RELS_SRT_CODE", length = 1)
	public String getFstRelsSrtCode() {
		return this.fstRelsSrtCode;
	}

	public void setFstRelsSrtCode(String fstRelsSrtCode) {
		this.fstRelsSrtCode = fstRelsSrtCode;
	}

	@Column(name = "NOTICE_FLAG", length = 1)
	public String getNoticeFlag() {
		return this.noticeFlag;
	}

	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}

	@Column(name = "MARK_NO_STR", length = 100)
	public String getMarkNoStr() {
		return this.markNoStr;
	}

	public void setMarkNoStr(String markNoStr) {
		this.markNoStr = markNoStr;
	}

	@Column(name = "FLAG_NO_STR", length = 100)
	public String getFlagNoStr() {
		return this.flagNoStr;
	}

	public void setFlagNoStr(String flagNoStr) {
		this.flagNoStr = flagNoStr;
	}

	@Column(name = "QUAR_RESULT", length = 1)
	public String getQuarResult() {
		return this.quarResult;
	}

	public void setQuarResult(String quarResult) {
		this.quarResult = quarResult;
	}

	@Column(name = "QUAR_PROC_RESULT", length = 1)
	public String getQuarProcResult() {
		return this.quarProcResult;
	}

	public void setQuarProcResult(String quarProcResult) {
		this.quarProcResult = quarProcResult;
	}

	@Column(name = "BASIS_CODING", length = 50)
	public String getBasisCoding() {
		return this.basisCoding;
	}

	public void setBasisCoding(String basisCoding) {
		this.basisCoding = basisCoding;
	}

	@Column(name = "CHECK_PLACE", length = 100)
	public String getCheckPlace() {
		return this.checkPlace;
	}

	public void setCheckPlace(String checkPlace) {
		this.checkPlace = checkPlace;
	}

	@Column(name = "CHECKER", length = 500)
	public String getChecker() {
		return this.checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	@Column(name = "SPOT_DESC", length = 4000)
	public String getSpotDesc() {
		return this.spotDesc;
	}

	public void setSpotDesc(String spotDesc) {
		this.spotDesc = spotDesc;
	}

	@Column(name = "WOODPACK_QUAR_RESULT", length = 1)
	public String getWoodpackQuarResult() {
		return this.woodpackQuarResult;
	}

	public void setWoodpackQuarResult(String woodpackQuarResult) {
		this.woodpackQuarResult = woodpackQuarResult;
	}

	@Column(name = "CONT_QUAR_RESULT", length = 1)
	public String getContQuarResult() {
		return this.contQuarResult;
	}

	public void setContQuarResult(String contQuarResult) {
		this.contQuarResult = contQuarResult;
	}

	@Column(name = "GOODS_EVAL_RESULT", length = 1)
	public String getGoodsEvalResult() {
		return this.goodsEvalResult;
	}

	public void setGoodsEvalResult(String goodsEvalResult) {
		this.goodsEvalResult = goodsEvalResult;
	}

	@Column(name = "CONT_REGI_STATUS", length = 1)
	public String getContRegiStatus() {
		return this.contRegiStatus;
	}

	public void setContRegiStatus(String contRegiStatus) {
		this.contRegiStatus = contRegiStatus;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "WEATHER_CODE", length = 20)
	public String getWeatherCode() {
		return this.weatherCode;
	}

	public void setWeatherCode(String weatherCode) {
		this.weatherCode = weatherCode;
	}

	@Column(name = "PRE_MEAS_BASIS_CODE", length = 4)
	public String getPreMeasBasisCode() {
		return this.preMeasBasisCode;
	}

	public void setPreMeasBasisCode(String preMeasBasisCode) {
		this.preMeasBasisCode = preMeasBasisCode;
	}

	@Column(name = "CONT_NO_STR", length = 1000)
	public String getContNoStr() {
		return this.contNoStr;
	}

	public void setContNoStr(String contNoStr) {
		this.contNoStr = contNoStr;
	}

	@Column(name = "CHNG_RESN", length = 200)
	public String getChngResn() {
		return this.chngResn;
	}

	public void setChngResn(String chngResn) {
		this.chngResn = chngResn;
	}

	@Column(name = "INSP_CONT_CODES", length = 50)
	public String getInspContCodes() {
		return this.inspContCodes;
	}

	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}

	@Column(name = "INSP_SC_NO", length = 50)
	public String getInspScNo() {
		return this.inspScNo;
	}

	public void setInspScNo(String inspScNo) {
		this.inspScNo = inspScNo;
	}

	@Column(name = "INSP_SC_FLAG", length = 10)
	public String getInspScFlag() {
		return this.inspScFlag;
	}

	public void setInspScFlag(String inspScFlag) {
		this.inspScFlag = inspScFlag;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "SC_ORG_CODE", length = 10)
	public String getScOrgCode() {
		return this.scOrgCode;
	}

	public void setScOrgCode(String scOrgCode) {
		this.scOrgCode = scOrgCode;
	}

	@Column(name = "SC_OPERATOR_CODE", length = 20)
	public String getScOperatorCode() {
		return this.scOperatorCode;
	}

	public void setScOperatorCode(String scOperatorCode) {
		this.scOperatorCode = scOperatorCode;
	}

	@Column(name = "WHETHER2ND_INS_SOURCE", length = 1)
	public String getWhether2ndInsSource() {
		return this.whether2ndInsSource;
	}

	public void setWhether2ndInsSource(String whether2ndInsSource) {
		this.whether2ndInsSource = whether2ndInsSource;
	}

}
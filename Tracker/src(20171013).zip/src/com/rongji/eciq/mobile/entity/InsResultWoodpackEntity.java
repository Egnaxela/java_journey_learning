package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsResultWoodpack entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_RESULT_WOODPACK")
public class InsResultWoodpackEntity implements java.io.Serializable {

	private static final long serialVersionUID = -9046105084049853156L;
	private String wodPkResultId;
	private String declNo;
	private Double goodsNo;
	private String packTypeCode;
	private Double packQty;
	private String woodContCodes;
	private String wodPackResEval;
	private String woodPackMak;
	private String confsWodPackMak;
	private String wodPkgUnquResnC;
	private String wodPkOrgCode;
	private String wodPkDeptCode;
	private String wdPkgInspCode;
	private Timestamp wodPkOperTime;
	private String prevtivTreatmt;
	private String quarTrmtMeasC;
	private String sanitTrtMethCode;
	private String sntTrtOrgCode;
	private String treatDeptCode;
	private String sntTrtOperCode;
	private Timestamp treatOperateDate;
	private String treatUnit;
	private String falgArchive;
	private Timestamp operTime;
	private Timestamp archiveTime;
	private String transFlag;

	// Constructors

	/** default constructor */
	public InsResultWoodpackEntity() {
	}

	/** minimal constructor */
	public InsResultWoodpackEntity(String wodPkResultId, String declNo,
			Double goodsNo, String packTypeCode) {
		this.wodPkResultId = wodPkResultId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.packTypeCode = packTypeCode;
	}

	/** full constructor */
	public InsResultWoodpackEntity(String wodPkResultId, String declNo,
			Double goodsNo, String packTypeCode, Double packQty,
			String woodContCodes, String wodPackResEval, String woodPackMak,
			String confsWodPackMak, String wodPkgUnquResnC,
			String wodPkOrgCode, String wodPkDeptCode, String wdPkgInspCode,
			Timestamp wodPkOperTime, String prevtivTreatmt,
			String quarTrmtMeasC, String sanitTrtMethCode,
			String sntTrtOrgCode, String treatDeptCode, String sntTrtOperCode,
			Timestamp treatOperateDate, String treatUnit, String falgArchive,
			Timestamp operTime, Timestamp archiveTime, String transFlag) {
		this.wodPkResultId = wodPkResultId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.packTypeCode = packTypeCode;
		this.packQty = packQty;
		this.woodContCodes = woodContCodes;
		this.wodPackResEval = wodPackResEval;
		this.woodPackMak = woodPackMak;
		this.confsWodPackMak = confsWodPackMak;
		this.wodPkgUnquResnC = wodPkgUnquResnC;
		this.wodPkOrgCode = wodPkOrgCode;
		this.wodPkDeptCode = wodPkDeptCode;
		this.wdPkgInspCode = wdPkgInspCode;
		this.wodPkOperTime = wodPkOperTime;
		this.prevtivTreatmt = prevtivTreatmt;
		this.quarTrmtMeasC = quarTrmtMeasC;
		this.sanitTrtMethCode = sanitTrtMethCode;
		this.sntTrtOrgCode = sntTrtOrgCode;
		this.treatDeptCode = treatDeptCode;
		this.sntTrtOperCode = sntTrtOperCode;
		this.treatOperateDate = treatOperateDate;
		this.treatUnit = treatUnit;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.archiveTime = archiveTime;
		this.transFlag = transFlag;
	}

	// Property accessors
	@Id
	@Column(name = "WOD_PK_RESULT_ID", unique = true, nullable = false, length = 32)
	public String getWodPkResultId() {
		return this.wodPkResultId;
	}

	public void setWodPkResultId(String wodPkResultId) {
		this.wodPkResultId = wodPkResultId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "GOODS_NO", nullable = false, precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "PACK_TYPE_CODE", nullable = false, length = 4)
	public String getPackTypeCode() {
		return this.packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	@Column(name = "PACK_QTY", precision = 0)
	public Double getPackQty() {
		return this.packQty;
	}

	public void setPackQty(Double packQty) {
		this.packQty = packQty;
	}

	@Column(name = "WOOD_CONT_CODES", length = 20)
	public String getWoodContCodes() {
		return this.woodContCodes;
	}

	public void setWoodContCodes(String woodContCodes) {
		this.woodContCodes = woodContCodes;
	}

	@Column(name = "WOD_PACK_RES_EVAL", length = 4)
	public String getWodPackResEval() {
		return this.wodPackResEval;
	}

	public void setWodPackResEval(String wodPackResEval) {
		this.wodPackResEval = wodPackResEval;
	}

	@Column(name = "WOOD_PACK_MAK", length = 1)
	public String getWoodPackMak() {
		return this.woodPackMak;
	}

	public void setWoodPackMak(String woodPackMak) {
		this.woodPackMak = woodPackMak;
	}

	@Column(name = "CONFS_WOD_PACK_MAK", length = 1)
	public String getConfsWodPackMak() {
		return this.confsWodPackMak;
	}

	public void setConfsWodPackMak(String confsWodPackMak) {
		this.confsWodPackMak = confsWodPackMak;
	}

	@Column(name = "WOD_PKG_UNQU_RESN_C", length = 4)
	public String getWodPkgUnquResnC() {
		return this.wodPkgUnquResnC;
	}

	public void setWodPkgUnquResnC(String wodPkgUnquResnC) {
		this.wodPkgUnquResnC = wodPkgUnquResnC;
	}

	@Column(name = "WOD_PK_ORG_CODE", length = 10)
	public String getWodPkOrgCode() {
		return this.wodPkOrgCode;
	}

	public void setWodPkOrgCode(String wodPkOrgCode) {
		this.wodPkOrgCode = wodPkOrgCode;
	}

	@Column(name = "WOD_PK_DEPT_CODE", length = 10)
	public String getWodPkDeptCode() {
		return this.wodPkDeptCode;
	}

	public void setWodPkDeptCode(String wodPkDeptCode) {
		this.wodPkDeptCode = wodPkDeptCode;
	}

	@Column(name = "WD_PKG_INSP_CODE", length = 20)
	public String getWdPkgInspCode() {
		return this.wdPkgInspCode;
	}

	public void setWdPkgInspCode(String wdPkgInspCode) {
		this.wdPkgInspCode = wdPkgInspCode;
	}

	@Column(name = "WOD_PK_OPER_TIME", length = 7)
	public Timestamp getWodPkOperTime() {
		return this.wodPkOperTime;
	}

	public void setWodPkOperTime(Timestamp wodPkOperTime) {
		this.wodPkOperTime = wodPkOperTime;
	}

	@Column(name = "PREVTIV_TREATMT", length = 4)
	public String getPrevtivTreatmt() {
		return this.prevtivTreatmt;
	}

	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}

	@Column(name = "QUAR_TRMT_MEAS_C", length = 4)
	public String getQuarTrmtMeasC() {
		return this.quarTrmtMeasC;
	}

	public void setQuarTrmtMeasC(String quarTrmtMeasC) {
		this.quarTrmtMeasC = quarTrmtMeasC;
	}

	@Column(name = "SANIT_TRT_METH_CODE", length = 4)
	public String getSanitTrtMethCode() {
		return this.sanitTrtMethCode;
	}

	public void setSanitTrtMethCode(String sanitTrtMethCode) {
		this.sanitTrtMethCode = sanitTrtMethCode;
	}

	@Column(name = "SNT_TRT_ORG_CODE", length = 10)
	public String getSntTrtOrgCode() {
		return this.sntTrtOrgCode;
	}

	public void setSntTrtOrgCode(String sntTrtOrgCode) {
		this.sntTrtOrgCode = sntTrtOrgCode;
	}

	@Column(name = "TREAT_DEPT_CODE", length = 10)
	public String getTreatDeptCode() {
		return this.treatDeptCode;
	}

	public void setTreatDeptCode(String treatDeptCode) {
		this.treatDeptCode = treatDeptCode;
	}

	@Column(name = "SNT_TRT_OPER_CODE", length = 20)
	public String getSntTrtOperCode() {
		return this.sntTrtOperCode;
	}

	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}

	@Column(name = "TREAT_OPERATE_DATE", length = 7)
	public Timestamp getTreatOperateDate() {
		return this.treatOperateDate;
	}

	public void setTreatOperateDate(Timestamp treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}

	@Column(name = "TREAT_UNIT", length = 50)
	public String getTreatUnit() {
		return this.treatUnit;
	}

	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "TRANS_FLAG", length = 10)
	public String getTransFlag() {
		return this.transFlag;
	}

	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsReturnReason entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_RETURN_REASON")
public class InsReturnReasonEntity implements java.io.Serializable {
	
	private static final long serialVersionUID = -5267898799636609134L;
	private String returnReasonId;
	private String declNo;
	private String returnReason;
	private String inspectorCode;
	private String exeInspOrgCode;
	private String excInspDeptCode;
	private String returnRecord;
	private String falgArchive;
	private Timestamp operTime;
	private String docmtreturnCode;
	private String returnType;
	private Timestamp archiveTime;

	// Constructors

	/** default constructor */
	public InsReturnReasonEntity() {
	}

	/** minimal constructor */
	public InsReturnReasonEntity(String returnReasonId, String declNo) {
		this.returnReasonId = returnReasonId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsReturnReasonEntity(String returnReasonId, String declNo,
			String returnReason, String inspectorCode, String exeInspOrgCode,
			String excInspDeptCode, String returnRecord, String falgArchive,
			Timestamp operTime, String docmtreturnCode, String returnType,
			Timestamp archiveTime) {
		this.returnReasonId = returnReasonId;
		this.declNo = declNo;
		this.returnReason = returnReason;
		this.inspectorCode = inspectorCode;
		this.exeInspOrgCode = exeInspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.returnRecord = returnRecord;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.docmtreturnCode = docmtreturnCode;
		this.returnType = returnType;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "RETURN_REASON_ID", unique = true, nullable = false, length = 32)
	public String getReturnReasonId() {
		return this.returnReasonId;
	}

	public void setReturnReasonId(String returnReasonId) {
		this.returnReasonId = returnReasonId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "RETURN_REASON", length = 100)
	public String getReturnReason() {
		return this.returnReason;
	}

	public void setReturnReason(String returnReason) {
		this.returnReason = returnReason;
	}

	@Column(name = "INSPECTOR_CODE", length = 20)
	public String getInspectorCode() {
		return this.inspectorCode;
	}

	public void setInspectorCode(String inspectorCode) {
		this.inspectorCode = inspectorCode;
	}

	@Column(name = "EXE_INSP_ORG_CODE", length = 10)
	public String getExeInspOrgCode() {
		return this.exeInspOrgCode;
	}

	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "RETURN_RECORD", length = 100)
	public String getReturnRecord() {
		return this.returnRecord;
	}

	public void setReturnRecord(String returnRecord) {
		this.returnRecord = returnRecord;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "DOCMTRETURN_CODE", length = 20)
	public String getDocmtreturnCode() {
		return this.docmtreturnCode;
	}

	public void setDocmtreturnCode(String docmtreturnCode) {
		this.docmtreturnCode = docmtreturnCode;
	}

	@Column(name = "RETURN_TYPE", length = 2)
	public String getReturnType() {
		return this.returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

}
package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * InsSampleItemResult entity. @author MyEclipse Persistence Tools
 */
/**  
 * Description: 样品检测项目及结果  
 * Copyright:   Copyright (c)2017  
 * Company:     
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017年4月19日 下午5:24:38  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月19日      吴有根                     1.0         1.0 Version 
 */

@Entity
@Table(name = "INS_SAMPLE_ITEM_RESULT")
public class InsSampleItemResultEntity implements java.io.Serializable {
	private static final long serialVersionUID = -6929208426430422774L;
	private String inspSampleItemId;
	private String declNo;
	private String prodBatchNo;
	private Double goodsNo;
	private String inspItemCode;
	private String itemName;
	private String aqlValue;
	private String labCode;
	private String laborary;
	private String evalIndex;
	private String evalResult;
	private String reformResult;
	private String sampleNo;
	private String testMethCode;
	private String testConclusion;
	private String testResSorcType;
	private String stdValue;
	private String validFlag;
	private String creator;
	private Timestamp cretDate;
	private String taskNo;
	private String finishiedFlag;
	private String evalRuleId;
	private String itemSourceCode;
	private String descChinese;
	private String falgArchive;
	private Timestamp operTime;
	private String isEvaluate;
	private String itemTypeCode;
	private String entMgrNo;
	private Timestamp archiveTime;
	private String operOrg;

	// Constructors

	/** default constructor */
	public InsSampleItemResultEntity() {
	}

	/** minimal constructor */
	public InsSampleItemResultEntity(String inspSampleItemId, String declNo) {
		this.inspSampleItemId = inspSampleItemId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsSampleItemResultEntity(String inspSampleItemId, String declNo,
			String prodBatchNo, Double goodsNo, String inspItemCode,
			String itemName, String aqlValue, String labCode, String laborary,
			String evalIndex, String evalResult, String reformResult,
			String sampleNo, String testMethCode, String testConclusion,
			String testResSorcType, String stdValue, String validFlag,
			String creator, Timestamp cretDate, String taskNo,
			String finishiedFlag, String evalRuleId, String itemSourceCode,
			String descChinese, String falgArchive, Timestamp operTime,
			String isEvaluate, String itemTypeCode, String entMgrNo,
			Timestamp archiveTime, String operOrg) {
		this.inspSampleItemId = inspSampleItemId;
		this.declNo = declNo;
		this.prodBatchNo = prodBatchNo;
		this.goodsNo = goodsNo;
		this.inspItemCode = inspItemCode;
		this.itemName = itemName;
		this.aqlValue = aqlValue;
		this.labCode = labCode;
		this.laborary = laborary;
		this.evalIndex = evalIndex;
		this.evalResult = evalResult;
		this.reformResult = reformResult;
		this.sampleNo = sampleNo;
		this.testMethCode = testMethCode;
		this.testConclusion = testConclusion;
		this.testResSorcType = testResSorcType;
		this.stdValue = stdValue;
		this.validFlag = validFlag;
		this.creator = creator;
		this.cretDate = cretDate;
		this.taskNo = taskNo;
		this.finishiedFlag = finishiedFlag;
		this.evalRuleId = evalRuleId;
		this.itemSourceCode = itemSourceCode;
		this.descChinese = descChinese;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.isEvaluate = isEvaluate;
		this.itemTypeCode = itemTypeCode;
		this.entMgrNo = entMgrNo;
		this.archiveTime = archiveTime;
		this.operOrg = operOrg;
	}

	// Property accessors
	@Id
	@Column(name = "INSP_SAMPLE_ITEM_ID", unique = true, nullable = false, length = 32)
	public String getInspSampleItemId() {
		return this.inspSampleItemId;
	}

	public void setInspSampleItemId(String inspSampleItemId) {
		this.inspSampleItemId = inspSampleItemId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "PROD_BATCH_NO", length = 2000)
	public String getProdBatchNo() {
		return this.prodBatchNo;
	}

	public void setProdBatchNo(String prodBatchNo) {
		this.prodBatchNo = prodBatchNo;
	}

	@Column(name = "GOODS_NO", precision = 0)
	public Double getGoodsNo() {
		return this.goodsNo;
	}

	public void setGoodsNo(Double goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Column(name = "INSP_ITEM_CODE", length = 30)
	public String getInspItemCode() {
		return this.inspItemCode;
	}

	public void setInspItemCode(String inspItemCode) {
		this.inspItemCode = inspItemCode;
	}

	@Column(name = "ITEM_NAME", length = 200)
	public String getItemName() {
		return this.itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Column(name = "AQL_VALUE", length = 10)
	public String getAqlValue() {
		return this.aqlValue;
	}

	public void setAqlValue(String aqlValue) {
		this.aqlValue = aqlValue;
	}

	@Column(name = "LAB_CODE", length = 20)
	public String getLabCode() {
		return this.labCode;
	}

	public void setLabCode(String labCode) {
		this.labCode = labCode;
	}

	@Column(name = "LABORARY", length = 200)
	public String getLaborary() {
		return this.laborary;
	}

	public void setLaborary(String laborary) {
		this.laborary = laborary;
	}

	@Column(name = "EVAL_INDEX", length = 2000)
	public String getEvalIndex() {
		return this.evalIndex;
	}

	public void setEvalIndex(String evalIndex) {
		this.evalIndex = evalIndex;
	}

	@Column(name = "EVAL_RESULT", length = 1)
	public String getEvalResult() {
		return this.evalResult;
	}

	public void setEvalResult(String evalResult) {
		this.evalResult = evalResult;
	}

	@Column(name = "REFORM_RESULT", length = 40)
	public String getReformResult() {
		return this.reformResult;
	}

	public void setReformResult(String reformResult) {
		this.reformResult = reformResult;
	}

	@Column(name = "SAMPLE_NO", length = 20)
	public String getSampleNo() {
		return this.sampleNo;
	}

	public void setSampleNo(String sampleNo) {
		this.sampleNo = sampleNo;
	}

	@Column(name = "TEST_METH_CODE", length = 50)
	public String getTestMethCode() {
		return this.testMethCode;
	}

	public void setTestMethCode(String testMethCode) {
		this.testMethCode = testMethCode;
	}

	@Column(name = "TEST_CONCLUSION", length = 100)
	public String getTestConclusion() {
		return this.testConclusion;
	}

	public void setTestConclusion(String testConclusion) {
		this.testConclusion = testConclusion;
	}

	@Column(name = "TEST_RES_SORC_TYPE", length = 4)
	public String getTestResSorcType() {
		return this.testResSorcType;
	}

	public void setTestResSorcType(String testResSorcType) {
		this.testResSorcType = testResSorcType;
	}

	@Column(name = "STD_VALUE", length = 40)
	public String getStdValue() {
		return this.stdValue;
	}

	public void setStdValue(String stdValue) {
		this.stdValue = stdValue;
	}

	@Column(name = "VALID_FLAG", length = 1)
	public String getValidFlag() {
		return this.validFlag;
	}

	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag;
	}

	@Column(name = "CREATOR", length = 20)
	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	@Column(name = "CRET_DATE", length = 7)
	public Timestamp getCretDate() {
		return this.cretDate;
	}

	public void setCretDate(Timestamp cretDate) {
		this.cretDate = cretDate;
	}

	@Column(name = "TASK_NO", length = 32)
	public String getTaskNo() {
		return this.taskNo;
	}

	public void setTaskNo(String taskNo) {
		this.taskNo = taskNo;
	}

	@Column(name = "FINISHIED_FLAG", length = 1)
	public String getFinishiedFlag() {
		return this.finishiedFlag;
	}

	public void setFinishiedFlag(String finishiedFlag) {
		this.finishiedFlag = finishiedFlag;
	}

	@Column(name = "EVAL_RULE_ID", length = 32)
	public String getEvalRuleId() {
		return this.evalRuleId;
	}

	public void setEvalRuleId(String evalRuleId) {
		this.evalRuleId = evalRuleId;
	}

	@Column(name = "ITEM_SOURCE_CODE", length = 4)
	public String getItemSourceCode() {
		return this.itemSourceCode;
	}

	public void setItemSourceCode(String itemSourceCode) {
		this.itemSourceCode = itemSourceCode;
	}

	@Column(name = "DESC_CHINESE", length = 200)
	public String getDescChinese() {
		return this.descChinese;
	}

	public void setDescChinese(String descChinese) {
		this.descChinese = descChinese;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "IS_EVALUATE", length = 1)
	public String getIsEvaluate() {
		return this.isEvaluate;
	}

	public void setIsEvaluate(String isEvaluate) {
		this.isEvaluate = isEvaluate;
	}

	@Column(name = "ITEM_TYPE_CODE", length = 1)
	public String getItemTypeCode() {
		return this.itemTypeCode;
	}

	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	@Column(name = "ENT_MGR_NO", length = 20)
	public String getEntMgrNo() {
		return this.entMgrNo;
	}

	public void setEntMgrNo(String entMgrNo) {
		this.entMgrNo = entMgrNo;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "OPER_ORG", length = 20)
	public String getOperOrg() {
		return this.operOrg;
	}

	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}

}
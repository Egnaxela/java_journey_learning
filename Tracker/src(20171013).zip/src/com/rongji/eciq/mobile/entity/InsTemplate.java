package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsTemplate entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_TEMPLATE")
public class InsTemplate implements java.io.Serializable {

	// Fields
	private String templateId;
	private BigDecimal tmpltNo;
	private String ciqOrgCode;
	private String inspUserCode;
	private String whetherEffect;
	private String makers;
	private Date makeTime;
	private String templateTitle;
	private String templateType;
	private String expImpFlag;
	private String templateContent;
	private String falgArchive;
	private Date operTime;
	private String useDeptCode;
	private String useDeptName;
	private Date archiveTime;
	private String isDefTemplate;
	private String operDeptCode;
	private String operOrgCode;
	private String operUserCode;
	private String operDeptName;
	private String operOrgName;
	private String operUserName;

	// Constructors

	/** default constructor */
	public InsTemplate() {
	}

	/** minimal constructor */
	public InsTemplate(String templateId, BigDecimal tmpltNo) {
		this.templateId = templateId;
		this.tmpltNo = tmpltNo;
	}

	/** full constructor */
	public InsTemplate(String templateId, BigDecimal tmpltNo, String ciqOrgCode, String inspUserCode, String whetherEffect, String makers, Date makeTime, String templateTitle, String templateType, String expImpFlag, String templateContent, String falgArchive, Date operTime, String useDeptCode, String useDeptName, Date archiveTime, String isDefTemplate, String operDeptCode, String operOrgCode, String operUserCode, String operDeptName, String operOrgName, String operUserName) {
		this.templateId = templateId;
		this.tmpltNo = tmpltNo;
		this.ciqOrgCode = ciqOrgCode;
		this.inspUserCode = inspUserCode;
		this.whetherEffect = whetherEffect;
		this.makers = makers;
		this.makeTime = makeTime;
		this.templateTitle = templateTitle;
		this.templateType = templateType;
		this.expImpFlag = expImpFlag;
		this.templateContent = templateContent;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.useDeptCode = useDeptCode;
		this.useDeptName = useDeptName;
		this.archiveTime = archiveTime;
		this.isDefTemplate = isDefTemplate;
		this.operDeptCode = operDeptCode;
		this.operOrgCode = operOrgCode;
		this.operUserCode = operUserCode;
		this.operDeptName = operDeptName;
		this.operOrgName = operOrgName;
		this.operUserName = operUserName;
	}

	// Property accessors
	@Id
	@Column(name = "TEMPLATE_ID", unique = true, nullable = false, length = 32)
	public String getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	@Column(name = "TMPLT_NO", nullable = false, precision = 22, scale = 0)
	public BigDecimal getTmpltNo() {
		return this.tmpltNo;
	}

	public void setTmpltNo(BigDecimal tmpltNo) {
		this.tmpltNo = tmpltNo;
	}

	@Column(name = "CIQ_ORG_CODE", length = 10)
	public String getCiqOrgCode() {
		return this.ciqOrgCode;
	}

	public void setCiqOrgCode(String ciqOrgCode) {
		this.ciqOrgCode = ciqOrgCode;
	}

	@Column(name = "INSP_USER_CODE", length = 20)
	public String getInspUserCode() {
		return this.inspUserCode;
	}

	public void setInspUserCode(String inspUserCode) {
		this.inspUserCode = inspUserCode;
	}

	@Column(name = "WHETHER_EFFECT", length = 1)
	public String getWhetherEffect() {
		return this.whetherEffect;
	}

	public void setWhetherEffect(String whetherEffect) {
		this.whetherEffect = whetherEffect;
	}

	@Column(name = "MAKERS", length = 50)
	public String getMakers() {
		return this.makers;
	}

	public void setMakers(String makers) {
		this.makers = makers;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MAKE_TIME")
	public Date getMakeTime() {
		return this.makeTime;
	}

	public void setMakeTime(Date makeTime) {
		this.makeTime = makeTime;
	}

	@Column(name = "TEMPLATE_TITLE", length = 50)
	public String getTemplateTitle() {
		return this.templateTitle;
	}

	public void setTemplateTitle(String templateTitle) {
		this.templateTitle = templateTitle;
	}

	@Column(name = "TEMPLATE_TYPE", length = 2)
	public String getTemplateType() {
		return this.templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "TEMPLATE_CONTENT", length = 4000)
	public String getTemplateContent() {
		return this.templateContent;
	}

	public void setTemplateContent(String templateContent) {
		this.templateContent = templateContent;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPER_TIME")
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "USE_DEPT_CODE", length = 1000)
	public String getUseDeptCode() {
		return this.useDeptCode;
	}

	public void setUseDeptCode(String useDeptCode) {
		this.useDeptCode = useDeptCode;
	}

	@Column(name = "USE_DEPT_NAME", length = 1000)
	public String getUseDeptName() {
		return this.useDeptName;
	}

	public void setUseDeptName(String useDeptName) {
		this.useDeptName = useDeptName;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ARCHIVE_TIME")
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "IS_DEF_TEMPLATE", length = 1)
	public String getIsDefTemplate() {
		return this.isDefTemplate;
	}

	public void setIsDefTemplate(String isDefTemplate) {
		this.isDefTemplate = isDefTemplate;
	}

	@Column(name = "OPER_DEPT_CODE", length = 20)
	public String getOperDeptCode() {
		return this.operDeptCode;
	}

	public void setOperDeptCode(String operDeptCode) {
		this.operDeptCode = operDeptCode;
	}

	@Column(name = "OPER_ORG_CODE", length = 20)
	public String getOperOrgCode() {
		return this.operOrgCode;
	}

	public void setOperOrgCode(String operOrgCode) {
		this.operOrgCode = operOrgCode;
	}

	@Column(name = "OPER_USER_CODE", length = 20)
	public String getOperUserCode() {
		return this.operUserCode;
	}

	public void setOperUserCode(String operUserCode) {
		this.operUserCode = operUserCode;
	}

	@Column(name = "OPER_DEPT_NAME", length = 50)
	public String getOperDeptName() {
		return this.operDeptName;
	}

	public void setOperDeptName(String operDeptName) {
		this.operDeptName = operDeptName;
	}

	@Column(name = "OPER_ORG_NAME", length = 50)
	public String getOperOrgName() {
		return this.operOrgName;
	}

	public void setOperOrgName(String operOrgName) {
		this.operOrgName = operOrgName;
	}

	@Column(name = "OPER_USER_NAME", length = 50)
	public String getOperUserName() {
		return this.operUserName;
	}

	public void setOperUserName(String operUserName) {
		this.operUserName = operUserName;
	}

}
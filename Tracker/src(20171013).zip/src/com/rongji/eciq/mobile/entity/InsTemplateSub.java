package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InsTemplateSub entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "INS_TEMPLATE_SUB")
public class InsTemplateSub implements java.io.Serializable {

	// Fields

	private String templateSubId;
	private String templateId;
	private String useDeptCode;
	private String useDeptName;
	private String falgArchive;
	private Date operTime;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public InsTemplateSub() {
	}

	/** minimal constructor */
	public InsTemplateSub(String templateSubId, String templateId) {
		this.templateSubId = templateSubId;
		this.templateId = templateId;
	}

	/** full constructor */
	public InsTemplateSub(String templateSubId, String templateId, String useDeptCode, String useDeptName, String falgArchive, Date operTime, Date archiveTime) {
		this.templateSubId = templateSubId;
		this.templateId = templateId;
		this.useDeptCode = useDeptCode;
		this.useDeptName = useDeptName;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "TEMPLATE_SUB_ID", unique = true, nullable = false, length = 32)
	public String getTemplateSubId() {
		return this.templateSubId;
	}

	public void setTemplateSubId(String templateSubId) {
		this.templateSubId = templateSubId;
	}

	@Column(name = "TEMPLATE_ID", nullable = false, length = 32)
	public String getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	@Column(name = "USE_DEPT_CODE", length = 10)
	public String getUseDeptCode() {
		return this.useDeptCode;
	}

	public void setUseDeptCode(String useDeptCode) {
		this.useDeptCode = useDeptCode;
	}

	@Column(name = "USE_DEPT_NAME", length = 200)
	public String getUseDeptName() {
		return this.useDeptName;
	}

	public void setUseDeptName(String useDeptName) {
		this.useDeptName = useDeptName;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

}
package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * SysLoginLogInfo entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_LOGIN_LOG_INFO")
public class LoginLogInfo implements java.io.Serializable {

	// Fields

	private String id;
	private String userId;
	private Date loginTime;
	private String loginIp;
	private String addr;
	private String equipment;
	private String deviceType;
	private String deviceOs;
	private String deviceInfo;

	// Constructors

	/** default constructor */
	public LoginLogInfo() {
	}

	/** minimal constructor */
	public LoginLogInfo(String id) {
		this.id = id;
	}

	/** full constructor */
	public LoginLogInfo(String id, String userId, Date loginTime, String loginIp, String addr, String equipment, String deviceType, String deviceOs, String deviceInfo) {
		this.id = id;
		this.userId = userId;
		this.loginTime = loginTime;
		this.loginIp = loginIp;
		this.addr = addr;
		this.equipment = equipment;
		this.deviceType = deviceType;
		this.deviceOs = deviceOs;
		this.deviceInfo = deviceInfo;
	}

	// Property accessors
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 32)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "USER_ID", length = 16)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LOGIN_TIME", length = 7)
	public Date getLoginTime() {
		return this.loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	@Column(name = "LOGIN_IP", length = 100)
	public String getLoginIp() {
		return this.loginIp;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	@Column(name = "ADDR", length = 100)
	public String getAddr() {
		return this.addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	@Column(name = "EQUIPMENT", length = 150)
	public String getEquipment() {
		return this.equipment;
	}

	public void setEquipment(String equipment) {
		this.equipment = equipment;
	}

	@Column(name = "DEVICE_TYPE", length = 100)
	public String getDeviceType() {
		return this.deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@Column(name = "DEVICE_OS", length = 100)
	public String getDeviceOs() {
		return this.deviceOs;
	}

	public void setDeviceOs(String deviceOs) {
		this.deviceOs = deviceOs;
	}

	@Column(name = "DEVICE_INFO", length = 100)
	public String getDeviceInfo() {
		return this.deviceInfo;
	}

	public void setDeviceInfo(String deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

}
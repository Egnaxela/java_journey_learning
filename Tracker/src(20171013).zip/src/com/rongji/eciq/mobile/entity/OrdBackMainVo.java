package com.rongji.eciq.mobile.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 布控回退信息VO
 *
 * @author 李云龙
 * @since 1.0
 */
@Entity
public class OrdBackMainVo implements Serializable{
	

    private static final long serialVersionUID = 1L;
    @Column(name = "ORDER_MAIN_NO",length = 32)
    private String orderMainNo;
    @Column(name = "DECL_NO",length = 20)
    private String declNo;
    @Column(name = "CENS_TYPE",length = 4)
    private String censType;
    @Column(name = "EXEC_LEVEL",length = 2)
    private String execLevel;//执行级别
    @Column(name = "CONC_TYPE",length = 32)
    private String concType;
    @Column(name = "CONCLUSION_NO",length = 32)
    private String conclusionNo;
    @Column(name = "CONCLUSION_NAME",length = 100)
    private String conclusionName;//结论名称
    @Column(name = "CONC_DESC",length = 500)
    private String concDesc;//结论内容
    @Column(name = "CENS_ORG",length = 10)
    private String censOrg;
    @Column(name = "CENS_PERSON",length = 20)
    private String censPerson;
    @Column(name = "ARRIVE_APP",length = 8)
    private String arriveApp;
    @Column(name = "ARRIV_LINK",length = 8)
    private String arrivLink;//到达环节
    @Column(name = "SEND_TIME",length = 7)
    private java.util.Date sendTime;
    @Column(name = "SEND_TYPE",length = 2)
    private String sendType;
    @Column(name = "OPER_TYPE",length = 2)
    private String operType;
    @Column(name = "ADD_LINK",length = 8)
    private String addLink;
    @Column(name = "OPER_TIME",length = 7)
    private java.util.Date operTime;
    @Column(name = "FALG_ARCHIVE", insertable = false,length = 1)
    private String falgArchive;
    @Id
    @Column(name = "ORDER_NO", nullable = false,length = 32)
    private String orderNo;
    @Column(name = "BACK_MAIN_NO",length = 32)
    private String backMainNo;
    @Column(name = "BACK_CAUSE_DESC",length = 4000)
    private String backCauseDesc;//回退原因
    @Column(name = "BACK_TYPE",length= 2)
    private String backType;
    @Column(name = "ORD_BACK_INFO_NO",length = 32)
    private String ordBackInfoNo;

    public String getBackCauseDesc() {
        return backCauseDesc;
    }

    public void setBackCauseDesc(String backCauseDesc) {
        this.backCauseDesc = backCauseDesc;
    }

    public String getOrdBackInfoNo() {
        return ordBackInfoNo;
    }

    public void setOrdBackInfoNo(String ordBackInfoNo) {
        this.ordBackInfoNo = ordBackInfoNo;
    }

    public String getBackType() {
        return backType;
    }

    public void setBackType(String backType) {
        this.backType = backType;
    }
    
    
    public String getBackMainNo() {
        return backMainNo;
    }

    public void setBackMainNo(String backMainNo) {
        this.backMainNo = backMainNo;
    }

    public String getOrderMainNo() {
        return orderMainNo;
    }

    public void setOrderMainNo(String orderMainNo) {
        this.orderMainNo = orderMainNo;
    }

    public String getDeclNo() {
        return declNo;
    }

    public void setDeclNo(String declNo) {
        this.declNo = declNo;
    }

    public String getCensType() {
        return censType;
    }

    public void setCensType(String censType) {
        this.censType = censType;
    }

    public String getExecLevel() {
        return execLevel;
    }

    public void setExecLevel(String execLevel) {
        this.execLevel = execLevel;
    }

    public String getConcType() {
        return concType;
    }

    public void setConcType(String concType) {
        this.concType = concType;
    }

    public String getConclusionNo() {
        return conclusionNo;
    }

    public void setConclusionNo(String conclusionNo) {
        this.conclusionNo = conclusionNo;
    }

    public String getConclusionName() {
        return conclusionName;
    }

    public void setConclusionName(String conclusionName) {
        this.conclusionName = conclusionName;
    }

    public String getConcDesc() {
        return concDesc;
    }

    public void setConcDesc(String concDesc) {
        this.concDesc = concDesc;
    }

    public String getCensOrg() {
        return censOrg;
    }

    public void setCensOrg(String censOrg) {
        this.censOrg = censOrg;
    }

    public String getCensPerson() {
        return censPerson;
    }

    public void setCensPerson(String censPerson) {
        this.censPerson = censPerson;
    }

    public String getArriveApp() {
        return arriveApp;
    }

    public void setArriveApp(String arriveApp) {
        this.arriveApp = arriveApp;
    }

    public String getArrivLink() {
        return arrivLink;
    }

    public void setArrivLink(String arrivLink) {
        this.arrivLink = arrivLink;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public String getAddLink() {
        return addLink;
    }

    public void setAddLink(String addLink) {
        this.addLink = addLink;
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    public String getFalgArchive() {
        return falgArchive;
    }

    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + (this.orderNo != null ? this.orderNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrdBackMainVo other = (OrdBackMainVo) obj;
        if ((this.orderNo == null) ? (other.orderNo != null) : !this.orderNo.equals(other.orderNo)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "OrdBackMainVo{" + "orderNo=" + orderNo + '}';
    }
    

}

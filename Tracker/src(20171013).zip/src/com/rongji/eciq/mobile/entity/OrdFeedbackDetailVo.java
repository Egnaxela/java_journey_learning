package com.rongji.eciq.mobile.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrdFeedbackDetailVo implements Serializable{
    @Column(name = "FEEDBACK_MAIN_NO",length= 32)
    private String feedbackMainNo;
    @Column(name = "ORDER_NO",length= 32)
    private String orderNo;
    @Column(name = "DECL_NO",length= 20)
    private String declNo;
    @Column(name = "EXEC_RSLT",length= 4)
    private String execRslt;
    @Column(name = "UNQU_REASON",length= 200)
    private String unquReason;
    @Column(name = "EXEC_RSLT_DESC",length= 500)
    private String execRsltDesc;
    @Column(name = "OPER_TIME")
    private java.util.Date operTime;
    @Column(name = "FALG_ARCHIVE", insertable = false,length= 1)
    private String falgArchive;
    @Id
    @Column(name = "ORD_FEEDBACK_INFO_NO", nullable = false,length= 32)
    private String ordFeedbackInfoNo;
    @Column(name = "EXEC_LEVEL",length= 2)
    private String execLevel;
    @Column(name = "CONC_TYPE",length= 32)
    private String concType;
    @Column(name = "CONCLUSION_NO",length= 32)
    private String conclusionNo;
    @Column(name = "CONCLUSION_NAME",length= 100)
    private String conclusionName;
    @Column(name = "CONC_DESC",length= 500)
    private String concDesc;

    public String getFeedbackMainNo() {
        return feedbackMainNo;
    }

    public void setFeedbackMainNo(String feedbackMainNo) {
        this.feedbackMainNo = feedbackMainNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getDeclNo() {
        return declNo;
    }

    public void setDeclNo(String declNo) {
        this.declNo = declNo;
    }

    public String getExecRslt() {
        return execRslt;
    }

    public void setExecRslt(String execRslt) {
        this.execRslt = execRslt;
    }

    public String getUnquReason() {
        return unquReason;
    }

    public void setUnquReason(String unquReason) {
        this.unquReason = unquReason;
    }

    public String getExecRsltDesc() {
        return execRsltDesc;
    }

    public void setExecRsltDesc(String execRsltDesc) {
        this.execRsltDesc = execRsltDesc;
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    public String getFalgArchive() {
        return falgArchive;
    }

    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }

    public String getOrdFeedbackInfoNo() {
        return ordFeedbackInfoNo;
    }

    public void setOrdFeedbackInfoNo(String ordFeedbackInfoNo) {
        this.ordFeedbackInfoNo = ordFeedbackInfoNo;
    }

    public String getExecLevel() {
        return execLevel;
    }

    public void setExecLevel(String execLevel) {
        this.execLevel = execLevel;
    }

    public String getConcType() {
        return concType;
    }

    public void setConcType(String concType) {
        this.concType = concType;
    }

    public String getConclusionNo() {
        return conclusionNo;
    }

    public void setConclusionNo(String conclusionNo) {
        this.conclusionNo = conclusionNo;
    }

    public String getConclusionName() {
        return conclusionName;
    }

    public void setConclusionName(String conclusionName) {
        this.conclusionName = conclusionName;
    }

    public String getConcDesc() {
        return concDesc;
    }

    public void setConcDesc(String concDesc) {
        this.concDesc = concDesc;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + (this.ordFeedbackInfoNo != null ? this.ordFeedbackInfoNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrdFeedbackDetailVo other = (OrdFeedbackDetailVo) obj;
        if ((this.ordFeedbackInfoNo == null) ? (other.ordFeedbackInfoNo != null) : !this.ordFeedbackInfoNo.equals(other.ordFeedbackInfoNo)) {
            return false;
        }
        return true;
    }
}
    
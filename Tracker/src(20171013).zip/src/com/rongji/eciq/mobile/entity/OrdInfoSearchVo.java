/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-26 上午10:54:50  
 *  
 */  

package com.rongji.eciq.mobile.entity;

import java.io.Serializable;

import com.itown.rcp.validator.annotation.StringLength;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.Transient;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波  
 * @version:    1.0  
 * Create at:   2017-5-26 上午10:54:50  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-26      魏波                     1.0         1.0 Version  
 */

@Entity
public class OrdInfoSearchVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ***DclOrdDetailEntity***
     */
    @Transient
    @Column(name = "NODE_NAME",length = 100)
    private String nodeName;
    @Transient
    @Column(name = "RESULT_NODE_ID",length = 32, nullable = false)
    private String resultNodeId;
    @Column(name = "ORDER_MAIN_NO",length = 32)
    private String orderMainNo;
    @Column(name = "DECL_NO",length = 20)
    private String declNo;
    @Column(name = "CENS_TYPE",length = 4)
    private String censType;
    @Column(name = "EXEC_LEVEL",length = 2)
    private String execLevel;
    @Column(name = "CONC_TYPE",length = 32)
    private String concType;
    @Column(name = "CONCLUSION_NO",length = 32)
    private String conclusionNo;
    @Column(name = "CONCLUSION_NAME",length = 100)
    private String conclusionName;
    @Column(name = "CONC_DESC",length = 500)
    private String concDesc;
    @Column(name = "CENS_ORG",length = 10)
    private String censOrg;
    @Column(name = "CENS_PERSON")
    @StringLength(length = 20)
    private String censPerson;
    @Transient
    @Column(name = "ARRIVE_APP")
    @StringLength(length = 8)
    private String arriveApp;
    @Column(name = "ARRIV_LINK")
    @StringLength(length = 8)
    private String arrivLink;
    @Column(name = "SEND_TIME")
    private java.util.Date sendTime;
    @Transient
    @Column(name = "SEND_TYPE")
    @StringLength(length = 2)
    private String sendType;
    @Column(name = "OPER_TYPE")
    @StringLength(length = 2)
    private String operType;
    @Column(name = "ADD_LINK")
    @StringLength(length = 8)
    private String addLink;
    @Transient
    @Column(name = "OPER_TIME")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private java.util.Date operTime;
    @Transient
    @Column(name = "FALG_ARCHIVE")
    @StringLength(length = 1)
    private String falgArchive;
    @Id
    @Column(name = "ORDER_NO", nullable = false)
    @StringLength(length = 32)
    private String orderNo;
    @Transient
    @Column(name = "URI")
    @StringLength(length = 500)
    private String uri;
    @Column(name = "ENABLED")
    @StringLength(length = 1)
    private String enabled;
    @Transient
    private String enabledName;
    @Column(name = "RULE_ID")
    @StringLength(length = 32)
    private String ruleId;
    /**
     * ***********************************************DclOrdMainEntity******************************************************
     */
    @Column(name = "ORDER_DATE")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private java.util.Date orderDate;
    @Transient
    @Column(name = "REMARK")
    @StringLength(length = 1000)
    private String remark;
    /**
     * **********************************************DclOrdFeedbackDetailEntity*****************************************************************
     */
    @Transient
    @Column(name = "FEEDBACK_MAIN_NO")
    @StringLength(length = 32)
    private String feedbackMainNo;
    @Column(name = "EXEC_RSLT")
    @StringLength(length = 4)
    private String execRslt;
    @Column(name = "UNQU_REASON")
    @StringLength(length = 200)
    private String unquReason;
    @Column(name = "EXEC_RSLT_DESC")
    @StringLength(length = 500)
    private String execRsltDesc;
    @Column(name = "ORD_FEEDBACK_INFO_NO", nullable = false)
    @StringLength(length = 32)
    private String ordFeedbackInfoNo;
    @Transient
    @Column(name = "ORG_CODE", nullable = false)
    private String orgCode;

    public OrdInfoSearchVo() {
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getEnabledName() {
        return enabledName;
    }

    public void setEnabledName(String enabledName) {
        this.enabledName = enabledName;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrderMainNo() {
        return orderMainNo;
    }

    public void setOrderMainNo(String orderMainNo) {
        this.orderMainNo = orderMainNo;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getResultNodeId() {
        return resultNodeId;
    }

    public void setResultNodeId(String resultNodeId) {
        this.resultNodeId = resultNodeId;
    }

    public String getDeclNo() {
        return declNo;
    }

    public void setDeclNo(String declNo) {
        this.declNo = declNo;
    }

    public String getCensType() {
        return censType;
    }

    public void setCensType(String censType) {
        this.censType = censType;
    }

    public String getExecLevel() {
        return execLevel;
    }

    public void setExecLevel(String execLevel) {
        this.execLevel = execLevel;
    }

    public String getConcType() {
        return concType;
    }

    public void setConcType(String concType) {
        this.concType = concType;
    }

    public String getConclusionNo() {
        return conclusionNo;
    }

    public void setConclusionNo(String conclusionNo) {
        this.conclusionNo = conclusionNo;
    }

    public String getConclusionName() {
        return conclusionName;
    }

    public void setConclusionName(String conclusionName) {
        this.conclusionName = conclusionName;
    }

    public String getConcDesc() {
        return concDesc;
    }

    public void setConcDesc(String concDesc) {
        this.concDesc = concDesc;
    }

    public String getCensOrg() {
        return censOrg;
    }

    public void setCensOrg(String censOrg) {
        this.censOrg = censOrg;
    }

    public String getCensPerson() {
        return censPerson;
    }

    public void setCensPerson(String censPerson) {
        this.censPerson = censPerson;
    }

    public String getArriveApp() {
        return arriveApp;
    }

    public void setArriveApp(String arriveApp) {
        this.arriveApp = arriveApp;
    }

    public String getArrivLink() {
        return arrivLink;
    }

    public void setArrivLink(String arrivLink) {
        this.arrivLink = arrivLink;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public String getAddLink() {
        return addLink;
    }

    public void setAddLink(String addLink) {
        this.addLink = addLink;
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    public String getFalgArchive() {
        return falgArchive;
    }

    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getFeedbackMainNo() {
        return feedbackMainNo;
    }

    public void setFeedbackMainNo(String feedbackMainNo) {
        this.feedbackMainNo = feedbackMainNo;
    }

    public String getExecRslt() {
        return execRslt;
    }

    public void setExecRslt(String execRslt) {
        this.execRslt = execRslt;
    }

    public String getUnquReason() {
        return unquReason;
    }

    public void setUnquReason(String unquReason) {
        this.unquReason = unquReason;
    }

    public String getExecRsltDesc() {
        return execRsltDesc;
    }

    public void setExecRsltDesc(String execRsltDesc) {
        this.execRsltDesc = execRsltDesc;
    }

    public String getOrdFeedbackInfoNo() {
        return ordFeedbackInfoNo;
    }

    public void setOrdFeedbackInfoNo(String ordFeedbackInfoNo) {
        this.ordFeedbackInfoNo = ordFeedbackInfoNo;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (this.orderNo != null ? this.orderNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrdInfoSearchVo other = (OrdInfoSearchVo) obj;
        if ((this.orderNo == null) ? (other.orderNo != null) : !this.orderNo.equals(other.orderNo)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "OrdInfoSearchVo{" + "nodeName=" + nodeName + ", resultNodeId=" + resultNodeId + ", orderMainNo=" + orderMainNo + ", declNo=" + declNo + ", censType=" + censType + ", execLevel=" + execLevel + ", concType=" + concType + ", conclusionNo=" + conclusionNo + ", conclusionName=" + conclusionName + ", concDesc=" + concDesc + ", censOrg=" + censOrg + ", censPerson=" + censPerson + ", arriveApp=" + arriveApp + ", arrivLink=" + arrivLink + ", sendTime=" + sendTime + ", sendType=" + sendType + ", operType=" + operType + ", addLink=" + addLink + ", operTime=" + operTime + ", falgArchive=" + falgArchive + ", orderNo=" + orderNo + ", uri=" + uri + ", enabled=" + enabled + ", enabledName=" + enabledName + ", orderDate=" + orderDate + ", remark=" + remark + ", feedbackMainNo=" + feedbackMainNo + ", execRslt=" + execRslt + ", unquReason=" + unquReason + ", execRsltDesc=" + execRsltDesc + ", ordFeedbackInfoNo=" + ordFeedbackInfoNo + ", orgCode=" + orgCode + '}';
    }
}

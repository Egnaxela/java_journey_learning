package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * RewMonDeclHitPlan entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="REW_MON_DECL_HIT_PLAN")

public class RewMonDeclHitPlan  implements java.io.Serializable {


    // Fields    

     private String hitPlanId;
     private String monPlanId;
     private String declNo;
     private BigDecimal goodsNo;
     private String pitchOnReason;
     private String pitchOnType;
     private Date pitchOnTime;
     private String isManualOption;
     private String falgArchive;
     private Date operTime;
     private String applOrgCode;
     private Date archiveTime;
     private String reasonDesc;


    // Constructors

    /** default constructor */
    public RewMonDeclHitPlan() {
    }

	/** minimal constructor */
    public RewMonDeclHitPlan(String hitPlanId, String monPlanId, String declNo) {
        this.hitPlanId = hitPlanId;
        this.monPlanId = monPlanId;
        this.declNo = declNo;
    }
    
    /** full constructor */
    public RewMonDeclHitPlan(String hitPlanId, String monPlanId, String declNo, BigDecimal goodsNo, String pitchOnReason, String pitchOnType, Date pitchOnTime, String isManualOption, String falgArchive, Date operTime, String applOrgCode, Date archiveTime, String reasonDesc) {
        this.hitPlanId = hitPlanId;
        this.monPlanId = monPlanId;
        this.declNo = declNo;
        this.goodsNo = goodsNo;
        this.pitchOnReason = pitchOnReason;
        this.pitchOnType = pitchOnType;
        this.pitchOnTime = pitchOnTime;
        this.isManualOption = isManualOption;
        this.falgArchive = falgArchive;
        this.operTime = operTime;
        this.applOrgCode = applOrgCode;
        this.archiveTime = archiveTime;
        this.reasonDesc = reasonDesc;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="HIT_PLAN_ID", unique=true, nullable=false, length=32)

    public String getHitPlanId() {
        return this.hitPlanId;
    }
    
    public void setHitPlanId(String hitPlanId) {
        this.hitPlanId = hitPlanId;
    }
    
    @Column(name="MON_PLAN_ID", nullable=false, length=32)

    public String getMonPlanId() {
        return this.monPlanId;
    }
    
    public void setMonPlanId(String monPlanId) {
        this.monPlanId = monPlanId;
    }
    
    @Column(name="DECL_NO", nullable=false, length=20)

    public String getDeclNo() {
        return this.declNo;
    }
    
    public void setDeclNo(String declNo) {
        this.declNo = declNo;
    }
    
    @Column(name="GOODS_NO", precision=22, scale=0)

    public BigDecimal getGoodsNo() {
        return this.goodsNo;
    }
    
    public void setGoodsNo(BigDecimal goodsNo) {
        this.goodsNo = goodsNo;
    }
    
    @Column(name="PITCH_ON_REASON", length=2)

    public String getPitchOnReason() {
        return this.pitchOnReason;
    }
    
    public void setPitchOnReason(String pitchOnReason) {
        this.pitchOnReason = pitchOnReason;
    }
    
    @Column(name="PITCH_ON_TYPE", length=2)

    public String getPitchOnType() {
        return this.pitchOnType;
    }
    
    public void setPitchOnType(String pitchOnType) {
        this.pitchOnType = pitchOnType;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="PITCH_ON_TIME", length=7)

    public Date getPitchOnTime() {
        return this.pitchOnTime;
    }
    
    public void setPitchOnTime(Date pitchOnTime) {
        this.pitchOnTime = pitchOnTime;
    }
    
    @Column(name="IS_MANUAL_OPTION", length=1)

    public String getIsManualOption() {
        return this.isManualOption;
    }
    
    public void setIsManualOption(String isManualOption) {
        this.isManualOption = isManualOption;
    }
    
    @Column(name="FALG_ARCHIVE", length=1)

    public String getFalgArchive() {
        return this.falgArchive;
    }
    
    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPER_TIME", length=7)

    public Date getOperTime() {
        return this.operTime;
    }
    
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    
    @Column(name="APPL_ORG_CODE", length=10)

    public String getApplOrgCode() {
        return this.applOrgCode;
    }
    
    public void setApplOrgCode(String applOrgCode) {
        this.applOrgCode = applOrgCode;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ARCHIVE_TIME", length=7)

    public Date getArchiveTime() {
        return this.archiveTime;
    }
    
    public void setArchiveTime(Date archiveTime) {
        this.archiveTime = archiveTime;
    }
    
    @Column(name="REASON_DESC", length=4000)

    public String getReasonDesc() {
        return this.reasonDesc;
    }
    
    public void setReasonDesc(String reasonDesc) {
        this.reasonDesc = reasonDesc;
    }
   








}
package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * RewMonPlan entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="REW_MON_PLAN")

public class RewMonPlan  implements java.io.Serializable {


    // Fields    

     private String monPlanId;
     private String monPlanName;
     private String rewMonTypeCode;
     private BigDecimal monCycle;
     private BigDecimal executPlanTm;
     private String planDesc;
     private String setPerson;
     private Date setDate;
     private Date effectiveDate;
     private String setOrgCode;
     private Date endDate;
     private String magDeptCode;
     private String applEntGradeCode;
     private String expImpFlag;
     private String declBatchMonFlag;
     private BigDecimal batchRatio;
     private String effectiveFlag;
     private Date newTaskCreateTime;
     private String taskExeType;
     private String spotCheckExeWay;
     private String timesExeWay;
     private BigDecimal itemExeNumber;
     private String isExeNumEffect;
     private String planTaskFlag;
     private String souMonPlanId;
     private String belongOrgCode;
     private String belongOrgType;
     private String falgArchive;
     private Date operTime;
     private Date archiveTime;
     private String typeCodePath;


    // Constructors

    /** default constructor */
    public RewMonPlan() {
    }

	/** minimal constructor */
    public RewMonPlan(String monPlanId, String monPlanName, String rewMonTypeCode, BigDecimal monCycle, String setPerson, Date setDate, Date effectiveDate, String setOrgCode, String expImpFlag, String declBatchMonFlag, String effectiveFlag) {
        this.monPlanId = monPlanId;
        this.monPlanName = monPlanName;
        this.rewMonTypeCode = rewMonTypeCode;
        this.monCycle = monCycle;
        this.setPerson = setPerson;
        this.setDate = setDate;
        this.effectiveDate = effectiveDate;
        this.setOrgCode = setOrgCode;
        this.expImpFlag = expImpFlag;
        this.declBatchMonFlag = declBatchMonFlag;
        this.effectiveFlag = effectiveFlag;
    }
    
    /** full constructor */
    public RewMonPlan(String monPlanId, String monPlanName, String rewMonTypeCode, BigDecimal monCycle, BigDecimal executPlanTm, String planDesc, String setPerson, Date setDate, Date effectiveDate, String setOrgCode, Date endDate, String magDeptCode, String applEntGradeCode, String expImpFlag, String declBatchMonFlag, BigDecimal batchRatio, String effectiveFlag, Date newTaskCreateTime, String taskExeType, String spotCheckExeWay, String timesExeWay, BigDecimal itemExeNumber, String isExeNumEffect, String planTaskFlag, String souMonPlanId, String belongOrgCode, String belongOrgType, String falgArchive, Date operTime, Date archiveTime, String typeCodePath) {
        this.monPlanId = monPlanId;
        this.monPlanName = monPlanName;
        this.rewMonTypeCode = rewMonTypeCode;
        this.monCycle = monCycle;
        this.executPlanTm = executPlanTm;
        this.planDesc = planDesc;
        this.setPerson = setPerson;
        this.setDate = setDate;
        this.effectiveDate = effectiveDate;
        this.setOrgCode = setOrgCode;
        this.endDate = endDate;
        this.magDeptCode = magDeptCode;
        this.applEntGradeCode = applEntGradeCode;
        this.expImpFlag = expImpFlag;
        this.declBatchMonFlag = declBatchMonFlag;
        this.batchRatio = batchRatio;
        this.effectiveFlag = effectiveFlag;
        this.newTaskCreateTime = newTaskCreateTime;
        this.taskExeType = taskExeType;
        this.spotCheckExeWay = spotCheckExeWay;
        this.timesExeWay = timesExeWay;
        this.itemExeNumber = itemExeNumber;
        this.isExeNumEffect = isExeNumEffect;
        this.planTaskFlag = planTaskFlag;
        this.souMonPlanId = souMonPlanId;
        this.belongOrgCode = belongOrgCode;
        this.belongOrgType = belongOrgType;
        this.falgArchive = falgArchive;
        this.operTime = operTime;
        this.archiveTime = archiveTime;
        this.typeCodePath = typeCodePath;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="MON_PLAN_ID", unique=true, nullable=false, length=32)

    public String getMonPlanId() {
        return this.monPlanId;
    }
    
    public void setMonPlanId(String monPlanId) {
        this.monPlanId = monPlanId;
    }
    
    @Column(name="MON_PLAN_NAME", nullable=false, length=60)

    public String getMonPlanName() {
        return this.monPlanName;
    }
    
    public void setMonPlanName(String monPlanName) {
        this.monPlanName = monPlanName;
    }
    
    @Column(name="REW_MON_TYPE_CODE", nullable=false, length=32)

    public String getRewMonTypeCode() {
        return this.rewMonTypeCode;
    }
    
    public void setRewMonTypeCode(String rewMonTypeCode) {
        this.rewMonTypeCode = rewMonTypeCode;
    }
    
    @Column(name="MON_CYCLE", nullable=false, precision=22, scale=0)

    public BigDecimal getMonCycle() {
        return this.monCycle;
    }
    
    public void setMonCycle(BigDecimal monCycle) {
        this.monCycle = monCycle;
    }
    
    @Column(name="EXECUT_PLAN_TM", precision=22, scale=0)

    public BigDecimal getExecutPlanTm() {
        return this.executPlanTm;
    }
    
    public void setExecutPlanTm(BigDecimal executPlanTm) {
        this.executPlanTm = executPlanTm;
    }
    
    @Column(name="PLAN_DESC", length=200)

    public String getPlanDesc() {
        return this.planDesc;
    }
    
    public void setPlanDesc(String planDesc) {
        this.planDesc = planDesc;
    }
    
    @Column(name="SET_PERSON", nullable=false, length=20)

    public String getSetPerson() {
        return this.setPerson;
    }
    
    public void setSetPerson(String setPerson) {
        this.setPerson = setPerson;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="SET_DATE", nullable=false, length=7)

    public Date getSetDate() {
        return this.setDate;
    }
    
    public void setSetDate(Date setDate) {
        this.setDate = setDate;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="EFFECTIVE_DATE", nullable=false, length=7)

    public Date getEffectiveDate() {
        return this.effectiveDate;
    }
    
    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }
    
    @Column(name="SET_ORG_CODE", nullable=false, length=10)

    public String getSetOrgCode() {
        return this.setOrgCode;
    }
    
    public void setSetOrgCode(String setOrgCode) {
        this.setOrgCode = setOrgCode;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="END_DATE", length=7)

    public Date getEndDate() {
        return this.endDate;
    }
    
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    
    @Column(name="MAG_DEPT_CODE", length=20)

    public String getMagDeptCode() {
        return this.magDeptCode;
    }
    
    public void setMagDeptCode(String magDeptCode) {
        this.magDeptCode = magDeptCode;
    }
    
    @Column(name="APPL_ENT_GRADE_CODE", length=10)

    public String getApplEntGradeCode() {
        return this.applEntGradeCode;
    }
    
    public void setApplEntGradeCode(String applEntGradeCode) {
        this.applEntGradeCode = applEntGradeCode;
    }
    
    @Column(name="EXP_IMP_FLAG", nullable=false, length=1)

    public String getExpImpFlag() {
        return this.expImpFlag;
    }
    
    public void setExpImpFlag(String expImpFlag) {
        this.expImpFlag = expImpFlag;
    }
    
    @Column(name="DECL_BATCH_MON_FLAG", nullable=false, length=1)

    public String getDeclBatchMonFlag() {
        return this.declBatchMonFlag;
    }
    
    public void setDeclBatchMonFlag(String declBatchMonFlag) {
        this.declBatchMonFlag = declBatchMonFlag;
    }
    
    @Column(name="BATCH_RATIO", precision=22, scale=0)

    public BigDecimal getBatchRatio() {
        return this.batchRatio;
    }
    
    public void setBatchRatio(BigDecimal batchRatio) {
        this.batchRatio = batchRatio;
    }
    
    @Column(name="EFFECTIVE_FLAG", nullable=false, length=1)

    public String getEffectiveFlag() {
        return this.effectiveFlag;
    }
    
    public void setEffectiveFlag(String effectiveFlag) {
        this.effectiveFlag = effectiveFlag;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="NEW_TASK_CREATE_TIME", length=7)

    public Date getNewTaskCreateTime() {
        return this.newTaskCreateTime;
    }
    
    public void setNewTaskCreateTime(Date newTaskCreateTime) {
        this.newTaskCreateTime = newTaskCreateTime;
    }
    
    @Column(name="TASK_EXE_TYPE", length=1)

    public String getTaskExeType() {
        return this.taskExeType;
    }
    
    public void setTaskExeType(String taskExeType) {
        this.taskExeType = taskExeType;
    }
    
    @Column(name="SPOT_CHECK_EXE_WAY", length=1)

    public String getSpotCheckExeWay() {
        return this.spotCheckExeWay;
    }
    
    public void setSpotCheckExeWay(String spotCheckExeWay) {
        this.spotCheckExeWay = spotCheckExeWay;
    }
    
    @Column(name="TIMES_EXE_WAY", length=1)

    public String getTimesExeWay() {
        return this.timesExeWay;
    }
    
    public void setTimesExeWay(String timesExeWay) {
        this.timesExeWay = timesExeWay;
    }
    
    @Column(name="ITEM_EXE_NUMBER", precision=22, scale=0)

    public BigDecimal getItemExeNumber() {
        return this.itemExeNumber;
    }
    
    public void setItemExeNumber(BigDecimal itemExeNumber) {
        this.itemExeNumber = itemExeNumber;
    }
    
    @Column(name="IS_EXE_NUM_EFFECT", length=1)

    public String getIsExeNumEffect() {
        return this.isExeNumEffect;
    }
    
    public void setIsExeNumEffect(String isExeNumEffect) {
        this.isExeNumEffect = isExeNumEffect;
    }
    
    @Column(name="PLAN_TASK_FLAG", length=1)

    public String getPlanTaskFlag() {
        return this.planTaskFlag;
    }
    
    public void setPlanTaskFlag(String planTaskFlag) {
        this.planTaskFlag = planTaskFlag;
    }
    
    @Column(name="SOU_MON_PLAN_ID", length=32)

    public String getSouMonPlanId() {
        return this.souMonPlanId;
    }
    
    public void setSouMonPlanId(String souMonPlanId) {
        this.souMonPlanId = souMonPlanId;
    }
    
    @Column(name="BELONG_ORG_CODE", length=10)

    public String getBelongOrgCode() {
        return this.belongOrgCode;
    }
    
    public void setBelongOrgCode(String belongOrgCode) {
        this.belongOrgCode = belongOrgCode;
    }
    
    @Column(name="BELONG_ORG_TYPE", length=1)

    public String getBelongOrgType() {
        return this.belongOrgType;
    }
    
    public void setBelongOrgType(String belongOrgType) {
        this.belongOrgType = belongOrgType;
    }
    
    @Column(name="FALG_ARCHIVE", length=1)

    public String getFalgArchive() {
        return this.falgArchive;
    }
    
    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPER_TIME", length=7)

    public Date getOperTime() {
        return this.operTime;
    }
    
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ARCHIVE_TIME", length=7)

    public Date getArchiveTime() {
        return this.archiveTime;
    }
    
    public void setArchiveTime(Date archiveTime) {
        this.archiveTime = archiveTime;
    }
    
    @Column(name="TYPE_CODE_PATH", length=2000)

    public String getTypeCodePath() {
        return this.typeCodePath;
    }
    
    public void setTypeCodePath(String typeCodePath) {
        this.typeCodePath = typeCodePath;
    }
   








}
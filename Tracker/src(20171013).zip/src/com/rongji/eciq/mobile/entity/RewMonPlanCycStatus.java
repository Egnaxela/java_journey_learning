package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * RewMonPlanCycStatus entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="REW_MON_PLAN_CYC_STATUS")

public class RewMonPlanCycStatus  implements java.io.Serializable {


    // Fields    

     private String monPlanCycStatusId;
     private String monPlanId;
     private String entMgrNo;
     private BigDecimal monCycle;
     private BigDecimal executPlanTm;
     private BigDecimal executedNums;
     private BigDecimal residualDays;
     private Date cycleBeginTime;
     private Date cycleEndTime;
     private BigDecimal cycleQuaNums;
     private BigDecimal batchRatio;
     private BigDecimal decldBatchNums;
     private Date lastTaskCreaTime;
     private String falgArchive;
     private Date operTime;
     private String applOrgCode;
     private String taskType;
     private Date archiveTime;


    // Constructors

    /** default constructor */
    public RewMonPlanCycStatus() {
    }

	/** minimal constructor */
    public RewMonPlanCycStatus(String monPlanCycStatusId, String monPlanId) {
        this.monPlanCycStatusId = monPlanCycStatusId;
        this.monPlanId = monPlanId;
    }
    
    /** full constructor */
    public RewMonPlanCycStatus(String monPlanCycStatusId, String monPlanId, String entMgrNo, BigDecimal monCycle, BigDecimal executPlanTm, BigDecimal executedNums, BigDecimal residualDays, Date cycleBeginTime, Date cycleEndTime, BigDecimal cycleQuaNums, BigDecimal batchRatio, BigDecimal decldBatchNums, Date lastTaskCreaTime, String falgArchive, Date operTime, String applOrgCode, String taskType, Date archiveTime) {
        this.monPlanCycStatusId = monPlanCycStatusId;
        this.monPlanId = monPlanId;
        this.entMgrNo = entMgrNo;
        this.monCycle = monCycle;
        this.executPlanTm = executPlanTm;
        this.executedNums = executedNums;
        this.residualDays = residualDays;
        this.cycleBeginTime = cycleBeginTime;
        this.cycleEndTime = cycleEndTime;
        this.cycleQuaNums = cycleQuaNums;
        this.batchRatio = batchRatio;
        this.decldBatchNums = decldBatchNums;
        this.lastTaskCreaTime = lastTaskCreaTime;
        this.falgArchive = falgArchive;
        this.operTime = operTime;
        this.applOrgCode = applOrgCode;
        this.taskType = taskType;
        this.archiveTime = archiveTime;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="MON_PLAN_CYC_STATUS_ID", unique=true, nullable=false, length=32)

    public String getMonPlanCycStatusId() {
        return this.monPlanCycStatusId;
    }
    
    public void setMonPlanCycStatusId(String monPlanCycStatusId) {
        this.monPlanCycStatusId = monPlanCycStatusId;
    }
    
    @Column(name="MON_PLAN_ID", nullable=false, length=32)

    public String getMonPlanId() {
        return this.monPlanId;
    }
    
    public void setMonPlanId(String monPlanId) {
        this.monPlanId = monPlanId;
    }
    
    @Column(name="ENT_MGR_NO", length=20)

    public String getEntMgrNo() {
        return this.entMgrNo;
    }
    
    public void setEntMgrNo(String entMgrNo) {
        this.entMgrNo = entMgrNo;
    }
    
    @Column(name="MON_CYCLE", precision=22, scale=0)

    public BigDecimal getMonCycle() {
        return this.monCycle;
    }
    
    public void setMonCycle(BigDecimal monCycle) {
        this.monCycle = monCycle;
    }
    
    @Column(name="EXECUT_PLAN_TM", precision=22, scale=0)

    public BigDecimal getExecutPlanTm() {
        return this.executPlanTm;
    }
    
    public void setExecutPlanTm(BigDecimal executPlanTm) {
        this.executPlanTm = executPlanTm;
    }
    
    @Column(name="EXECUTED_NUMS", precision=22, scale=0)

    public BigDecimal getExecutedNums() {
        return this.executedNums;
    }
    
    public void setExecutedNums(BigDecimal executedNums) {
        this.executedNums = executedNums;
    }
    
    @Column(name="RESIDUAL_DAYS", precision=22, scale=0)

    public BigDecimal getResidualDays() {
        return this.residualDays;
    }
    
    public void setResidualDays(BigDecimal residualDays) {
        this.residualDays = residualDays;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="CYCLE_BEGIN_TIME", length=7)

    public Date getCycleBeginTime() {
        return this.cycleBeginTime;
    }
    
    public void setCycleBeginTime(Date cycleBeginTime) {
        this.cycleBeginTime = cycleBeginTime;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="CYCLE_END_TIME", length=7)

    public Date getCycleEndTime() {
        return this.cycleEndTime;
    }
    
    public void setCycleEndTime(Date cycleEndTime) {
        this.cycleEndTime = cycleEndTime;
    }
    
    @Column(name="CYCLE_QUA_NUMS", precision=22, scale=0)

    public BigDecimal getCycleQuaNums() {
        return this.cycleQuaNums;
    }
    
    public void setCycleQuaNums(BigDecimal cycleQuaNums) {
        this.cycleQuaNums = cycleQuaNums;
    }
    
    @Column(name="BATCH_RATIO", precision=22, scale=0)

    public BigDecimal getBatchRatio() {
        return this.batchRatio;
    }
    
    public void setBatchRatio(BigDecimal batchRatio) {
        this.batchRatio = batchRatio;
    }
    
    @Column(name="DECLD_BATCH_NUMS", precision=22, scale=0)

    public BigDecimal getDecldBatchNums() {
        return this.decldBatchNums;
    }
    
    public void setDecldBatchNums(BigDecimal decldBatchNums) {
        this.decldBatchNums = decldBatchNums;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="LAST_TASK_CREA_TIME", length=7)

    public Date getLastTaskCreaTime() {
        return this.lastTaskCreaTime;
    }
    
    public void setLastTaskCreaTime(Date lastTaskCreaTime) {
        this.lastTaskCreaTime = lastTaskCreaTime;
    }
    
    @Column(name="FALG_ARCHIVE", length=1)

    public String getFalgArchive() {
        return this.falgArchive;
    }
    
    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPER_TIME", length=7)

    public Date getOperTime() {
        return this.operTime;
    }
    
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    
    @Column(name="APPL_ORG_CODE", length=10)

    public String getApplOrgCode() {
        return this.applOrgCode;
    }
    
    public void setApplOrgCode(String applOrgCode) {
        this.applOrgCode = applOrgCode;
    }
    
    @Column(name="TASK_TYPE", length=1)

    public String getTaskType() {
        return this.taskType;
    }
    
    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ARCHIVE_TIME", length=7)

    public Date getArchiveTime() {
        return this.archiveTime;
    }
    
    public void setArchiveTime(Date archiveTime) {
        this.archiveTime = archiveTime;
    }
   








}
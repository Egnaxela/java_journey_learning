package com.rongji.eciq.mobile.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class RewMonPlanLotedVo implements Serializable{

	@Column(name = "MON_PLAN_ID",length= 32)
	private String monPlanId;//风险监控规划ID
	@Column(name = "DECL_NO",length= 20)
	private String declNo;//报检号
	@Column(name = "GOODS_NO")
	private double goodsNo;//货物序号
	@Column(name = "PITCH_ON_REASON",length=2)
	private String pitchOnReason;//抽中原因
	@Column(name = "PITCH_ON_TYPE",length=2)
	private String pitchOnType;//抽中类型
	@Column(name = "PITCH_ON_TIME")
	private java.util.Date pitchOnTime;//抽中时间
	@Column(name = "IS_MANUAL_OPTION",length=1)
	private String isManualOption;//是否人工选项
	@Column(name = "FALG_ARCHIVE", insertable = false,length=1)
	private String falgArchive;//归档标志【0:未归档 1:已归档】
	@Column(name = "OPER_TIME")
	private java.util.Date operTime;//操作时间
	@Id
	@Column(name = "HIT_PLAN_ID", nullable = false,length = 32)
	private String hitPlanId;//命中规划记录ID
	@Transient
	private String pitchType;//状态
	@Column(name = "MON_PLAN_NAME",length=60)
	private String monPlanName;//风险监控规划名称
	@Column(name = "EXP_IMP_FLAG",length=1)
	private String expImpFlag;//出入境标志
	@Column(name = "EXECUT_PLAN_TM")
	@Transient
	private int executPlanTm;//计划执行次数
	@Transient
	private int executNms;//已执行次数
	@Column(name = "MON_CYCLE")
	private int monCycle;//监控周期
	@Column(name = "IS_EXE_NUM_EFFECT",length=1)
	private String isExeNumEffect;//执行次数是否作用到逐个企业【1=是 2=否】


	public String getMonPlanId() {
		return monPlanId;
	}

	public void setMonPlanId(String monPlanId) {
		this.monPlanId = monPlanId;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public double getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(double goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getPitchOnReason() {
		return pitchOnReason;
	}

	public void setPitchOnReason(String pitchOnReason) {
		this.pitchOnReason = pitchOnReason;
	}

	public String getPitchOnType() {
		return pitchOnType;
	}

	public void setPitchOnType(String pitchOnType) {
		this.pitchOnType = pitchOnType;
	}

	public java.util.Date getPitchOnTime() {
		return pitchOnTime;
	}

	public void setPitchOnTime(java.util.Date pitchOnTime) {
		this.pitchOnTime = pitchOnTime;
	}

	public String getIsManualOption() {
		return isManualOption;
	}

	public void setIsManualOption(String isManualOption) {
		this.isManualOption = isManualOption;
	}

	public String getFalgArchive() {
		return falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	public java.util.Date getOperTime() {
		return operTime;
	}

	public void setOperTime(java.util.Date operTime) {
		this.operTime = operTime;
	}

	public String getHitPlanId() {
		return hitPlanId;
	}

	public void setHitPlanId(String hitPlanId) {
		this.hitPlanId = hitPlanId;
	}

	public String getPitchType() {
		return pitchType;
	}

	public void setPitchType(String pitchType) {
		this.pitchType = pitchType;
	}

	public String getMonPlanName() {
		return monPlanName;
	}

	public void setMonPlanName(String monPlanName) {
		this.monPlanName = monPlanName;
	}

	public String getExpImpFlag() {
		return expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	public int getExecutPlanTm() {
		return executPlanTm;
	}

	public void setExecutPlanTm(int executPlanTm) {
		this.executPlanTm = executPlanTm;
	}

	public int getExecutNms() {
		return executNms;
	}

	public void setExecutNms(int executNms) {
		this.executNms = executNms;
	}

	public int getMonCycle() {
		return monCycle;
	}

	public void setMonCycle(int monCycle) {
		this.monCycle = monCycle;
	}

	public String getIsExeNumEffect() {
		return isExeNumEffect;
	}

	public void setIsExeNumEffect(String isExeNumEffect) {
		this.isExeNumEffect = isExeNumEffect;
	}

	
}

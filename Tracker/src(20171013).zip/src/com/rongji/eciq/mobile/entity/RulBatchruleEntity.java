package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * RulBatchrule entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_BATCHRULE")
public class RulBatchruleEntity implements java.io.Serializable {

	private static final long serialVersionUID = -6114889724643717466L;
	private String batchruleId;
	private String batchruleName;
	private String entLevelCode;
	private Double bhRatioLower;
	private Double bhRatioUpper;
	private Double bhCycLower;
	private Double bhCycUpper;
	private Double enfocBhUpper;
	private Double enfocBhLower;
	private String isEnfoc;
	private String isEnfocInsp;
	private Double labRatioUpper;
	private Double labRatioLower;
	private Timestamp beginDate;
	private Timestamp endDate;
	private String magDeptCode;
	private String prodRiskLevel;
	private String expImpFlag;
	private String isBhLimit;
	private Timestamp operTime;
	private String falgArchive;
	private Double bhCycbatchLower;
	private Double bhCycbatchUpper;
	private String batchruleLstate;
	private String operCode;
	private String versionNo;
	private String sampleSch;
	private String orgCode;
	private Timestamp archiveTime;
	private Double enfocExaminedUpper;
	private Double enfocExaminedLower;
	private Set<RulBatchruleLocalEntity> rulBatchruleLocals = new HashSet<RulBatchruleLocalEntity>(
			0);

	// Constructors

	/** default constructor */
	public RulBatchruleEntity() {
	}

	/** minimal constructor */
	public RulBatchruleEntity(String batchruleId) {
		this.batchruleId = batchruleId;
	}

	/** full constructor */
	public RulBatchruleEntity(String batchruleId, String batchruleName,
			String entLevelCode, Double bhRatioLower, Double bhRatioUpper,
			Double bhCycLower, Double bhCycUpper, Double enfocBhUpper,
			Double enfocBhLower, String isEnfoc, String isEnfocInsp,
			Double labRatioUpper, Double labRatioLower, Timestamp beginDate,
			Timestamp endDate, String magDeptCode, String prodRiskLevel,
			String expImpFlag, String isBhLimit, Timestamp operTime,
			String falgArchive, Double bhCycbatchLower, Double bhCycbatchUpper,
			String batchruleLstate, String operCode, String versionNo,
			String sampleSch, String orgCode, Timestamp archiveTime,
			Double enfocExaminedUpper, Double enfocExaminedLower,
			Set<RulBatchruleLocalEntity> rulBatchruleLocals) {
		this.batchruleId = batchruleId;
		this.batchruleName = batchruleName;
		this.entLevelCode = entLevelCode;
		this.bhRatioLower = bhRatioLower;
		this.bhRatioUpper = bhRatioUpper;
		this.bhCycLower = bhCycLower;
		this.bhCycUpper = bhCycUpper;
		this.enfocBhUpper = enfocBhUpper;
		this.enfocBhLower = enfocBhLower;
		this.isEnfoc = isEnfoc;
		this.isEnfocInsp = isEnfocInsp;
		this.labRatioUpper = labRatioUpper;
		this.labRatioLower = labRatioLower;
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.magDeptCode = magDeptCode;
		this.prodRiskLevel = prodRiskLevel;
		this.expImpFlag = expImpFlag;
		this.isBhLimit = isBhLimit;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.bhCycbatchLower = bhCycbatchLower;
		this.bhCycbatchUpper = bhCycbatchUpper;
		this.batchruleLstate = batchruleLstate;
		this.operCode = operCode;
		this.versionNo = versionNo;
		this.sampleSch = sampleSch;
		this.orgCode = orgCode;
		this.archiveTime = archiveTime;
		this.enfocExaminedUpper = enfocExaminedUpper;
		this.enfocExaminedLower = enfocExaminedLower;
		this.rulBatchruleLocals = rulBatchruleLocals;
	}

	// Property accessors
	@Id
	@Column(name = "BATCHRULE_ID", unique = true, nullable = false, length = 32)
	public String getBatchruleId() {
		return this.batchruleId;
	}

	public void setBatchruleId(String batchruleId) {
		this.batchruleId = batchruleId;
	}

	@Column(name = "BATCHRULE_NAME", length = 80)
	public String getBatchruleName() {
		return this.batchruleName;
	}

	public void setBatchruleName(String batchruleName) {
		this.batchruleName = batchruleName;
	}

	@Column(name = "ENT_LEVEL_CODE", length = 20)
	public String getEntLevelCode() {
		return this.entLevelCode;
	}

	public void setEntLevelCode(String entLevelCode) {
		this.entLevelCode = entLevelCode;
	}

	@Column(name = "BH_RATIO_LOWER", precision = 0)
	public Double getBhRatioLower() {
		return this.bhRatioLower;
	}

	public void setBhRatioLower(Double bhRatioLower) {
		this.bhRatioLower = bhRatioLower;
	}

	@Column(name = "BH_RATIO_UPPER", precision = 0)
	public Double getBhRatioUpper() {
		return this.bhRatioUpper;
	}

	public void setBhRatioUpper(Double bhRatioUpper) {
		this.bhRatioUpper = bhRatioUpper;
	}

	@Column(name = "BH_CYC_LOWER", precision = 0)
	public Double getBhCycLower() {
		return this.bhCycLower;
	}

	public void setBhCycLower(Double bhCycLower) {
		this.bhCycLower = bhCycLower;
	}

	@Column(name = "BH_CYC_UPPER", precision = 0)
	public Double getBhCycUpper() {
		return this.bhCycUpper;
	}

	public void setBhCycUpper(Double bhCycUpper) {
		this.bhCycUpper = bhCycUpper;
	}

	@Column(name = "ENFOC_BH_UPPER", precision = 0)
	public Double getEnfocBhUpper() {
		return this.enfocBhUpper;
	}

	public void setEnfocBhUpper(Double enfocBhUpper) {
		this.enfocBhUpper = enfocBhUpper;
	}

	@Column(name = "ENFOC_BH_LOWER", precision = 0)
	public Double getEnfocBhLower() {
		return this.enfocBhLower;
	}

	public void setEnfocBhLower(Double enfocBhLower) {
		this.enfocBhLower = enfocBhLower;
	}

	@Column(name = "IS_ENFOC", length = 1)
	public String getIsEnfoc() {
		return this.isEnfoc;
	}

	public void setIsEnfoc(String isEnfoc) {
		this.isEnfoc = isEnfoc;
	}

	@Column(name = "IS_ENFOC_INSP", length = 1)
	public String getIsEnfocInsp() {
		return this.isEnfocInsp;
	}

	public void setIsEnfocInsp(String isEnfocInsp) {
		this.isEnfocInsp = isEnfocInsp;
	}

	@Column(name = "LAB_RATIO_UPPER", precision = 0)
	public Double getLabRatioUpper() {
		return this.labRatioUpper;
	}

	public void setLabRatioUpper(Double labRatioUpper) {
		this.labRatioUpper = labRatioUpper;
	}

	@Column(name = "LAB_RATIO_LOWER", precision = 0)
	public Double getLabRatioLower() {
		return this.labRatioLower;
	}

	public void setLabRatioLower(Double labRatioLower) {
		this.labRatioLower = labRatioLower;
	}

	@Column(name = "BEGIN_DATE", length = 7)
	public Timestamp getBeginDate() {
		return this.beginDate;
	}

	public void setBeginDate(Timestamp beginDate) {
		this.beginDate = beginDate;
	}

	@Column(name = "END_DATE", length = 7)
	public Timestamp getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "PROD_RISK_LEVEL", length = 1)
	public String getProdRiskLevel() {
		return this.prodRiskLevel;
	}

	public void setProdRiskLevel(String prodRiskLevel) {
		this.prodRiskLevel = prodRiskLevel;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "IS_BH_LIMIT", length = 1)
	public String getIsBhLimit() {
		return this.isBhLimit;
	}

	public void setIsBhLimit(String isBhLimit) {
		this.isBhLimit = isBhLimit;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "BH_CYCBATCH_LOWER", precision = 0)
	public Double getBhCycbatchLower() {
		return this.bhCycbatchLower;
	}

	public void setBhCycbatchLower(Double bhCycbatchLower) {
		this.bhCycbatchLower = bhCycbatchLower;
	}

	@Column(name = "BH_CYCBATCH_UPPER", precision = 0)
	public Double getBhCycbatchUpper() {
		return this.bhCycbatchUpper;
	}

	public void setBhCycbatchUpper(Double bhCycbatchUpper) {
		this.bhCycbatchUpper = bhCycbatchUpper;
	}

	@Column(name = "BATCHRULE_LSTATE", length = 1)
	public String getBatchruleLstate() {
		return this.batchruleLstate;
	}

	public void setBatchruleLstate(String batchruleLstate) {
		this.batchruleLstate = batchruleLstate;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "VERSION_NO", length = 32)
	public String getVersionNo() {
		return this.versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	@Column(name = "SAMPLE_SCH", length = 200)
	public String getSampleSch() {
		return this.sampleSch;
	}

	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "ENFOC_EXAMINED_UPPER", precision = 0)
	public Double getEnfocExaminedUpper() {
		return this.enfocExaminedUpper;
	}

	public void setEnfocExaminedUpper(Double enfocExaminedUpper) {
		this.enfocExaminedUpper = enfocExaminedUpper;
	}

	@Column(name = "ENFOC_EXAMINED_LOWER", precision = 0)
	public Double getEnfocExaminedLower() {
		return this.enfocExaminedLower;
	}

	public void setEnfocExaminedLower(Double enfocExaminedLower) {
		this.enfocExaminedLower = enfocExaminedLower;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "rulBatchrule")
	public Set<RulBatchruleLocalEntity> getRulBatchruleLocals() {
		return this.rulBatchruleLocals;
	}

	public void setRulBatchruleLocals(Set<RulBatchruleLocalEntity> rulBatchruleLocals) {
		this.rulBatchruleLocals = rulBatchruleLocals;
	}

}
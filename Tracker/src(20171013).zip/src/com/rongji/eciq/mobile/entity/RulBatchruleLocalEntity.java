package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * RulBatchruleLocal entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_BATCHRULE_LOCAL")
public class RulBatchruleLocalEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -3153507217153890025L;
	private String batchruleLId;
	private RulBatchruleEntity rulBatchrule;
	private String batchruleDesc;
	private String isEnfocInsp;
	private String batchruleType;
	private Double batchruleLRatio;
	private Double cycDay;
	private Double cycBatch;
	private Double unqulEnfocBatch;
	private Double labBatchruleLRatio;
	private Timestamp effectiveDate;
	private Timestamp obsoleteDate;
	private String orgCode;
	private String orgName;
	private String batchruleLstate;
	private Timestamp operTime;
	private String falgArchive;
	private String operCode;
	private String versionNo;
	private String expImpFlag;
	private Timestamp archiveTime;
	private String magDeptCode;
	private String operOrgCode;
	private String tmpltId;
	private String tmpltType;
	private String localOrgCode;
	private String entLevelCode;

	// Constructors

	/** default constructor */
	public RulBatchruleLocalEntity() {
	}

	/** minimal constructor */
	public RulBatchruleLocalEntity(String batchruleLId) {
		this.batchruleLId = batchruleLId;
	}

	/** full constructor */
	public RulBatchruleLocalEntity(String batchruleLId, RulBatchruleEntity rulBatchrule,
			String batchruleDesc, String isEnfocInsp, String batchruleType,
			Double batchruleLRatio, Double cycDay, Double cycBatch,
			Double unqulEnfocBatch, Double labBatchruleLRatio,
			Timestamp effectiveDate, Timestamp obsoleteDate, String orgCode,
			String orgName, String batchruleLstate, Timestamp operTime,
			String falgArchive, String operCode, String versionNo,
			String expImpFlag, Timestamp archiveTime, String magDeptCode,
			String operOrgCode, String tmpltId, String tmpltType,
			String localOrgCode, String entLevelCode) {
		this.batchruleLId = batchruleLId;
		this.rulBatchrule = rulBatchrule;
		this.batchruleDesc = batchruleDesc;
		this.isEnfocInsp = isEnfocInsp;
		this.batchruleType = batchruleType;
		this.batchruleLRatio = batchruleLRatio;
		this.cycDay = cycDay;
		this.cycBatch = cycBatch;
		this.unqulEnfocBatch = unqulEnfocBatch;
		this.labBatchruleLRatio = labBatchruleLRatio;
		this.effectiveDate = effectiveDate;
		this.obsoleteDate = obsoleteDate;
		this.orgCode = orgCode;
		this.orgName = orgName;
		this.batchruleLstate = batchruleLstate;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.operCode = operCode;
		this.versionNo = versionNo;
		this.expImpFlag = expImpFlag;
		this.archiveTime = archiveTime;
		this.magDeptCode = magDeptCode;
		this.operOrgCode = operOrgCode;
		this.tmpltId = tmpltId;
		this.tmpltType = tmpltType;
		this.localOrgCode = localOrgCode;
		this.entLevelCode = entLevelCode;
	}

	// Property accessors
	@Id
	@Column(name = "BATCHRULE_L_ID", unique = true, nullable = false, length = 32)
	public String getBatchruleLId() {
		return this.batchruleLId;
	}

	public void setBatchruleLId(String batchruleLId) {
		this.batchruleLId = batchruleLId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BATCHRULE_ID")
	public RulBatchruleEntity getRulBatchrule() {
		return this.rulBatchrule;
	}

	public void setRulBatchrule(RulBatchruleEntity rulBatchrule) {
		this.rulBatchrule = rulBatchrule;
	}

	@Column(name = "BATCHRULE_DESC", length = 200)
	public String getBatchruleDesc() {
		return this.batchruleDesc;
	}

	public void setBatchruleDesc(String batchruleDesc) {
		this.batchruleDesc = batchruleDesc;
	}

	@Column(name = "IS_ENFOC_INSP", length = 1)
	public String getIsEnfocInsp() {
		return this.isEnfocInsp;
	}

	public void setIsEnfocInsp(String isEnfocInsp) {
		this.isEnfocInsp = isEnfocInsp;
	}

	@Column(name = "BATCHRULE_TYPE", length = 1)
	public String getBatchruleType() {
		return this.batchruleType;
	}

	public void setBatchruleType(String batchruleType) {
		this.batchruleType = batchruleType;
	}

	@Column(name = "BATCHRULE_L_RATIO", precision = 0)
	public Double getBatchruleLRatio() {
		return this.batchruleLRatio;
	}

	public void setBatchruleLRatio(Double batchruleLRatio) {
		this.batchruleLRatio = batchruleLRatio;
	}

	@Column(name = "CYC_DAY", precision = 0)
	public Double getCycDay() {
		return this.cycDay;
	}

	public void setCycDay(Double cycDay) {
		this.cycDay = cycDay;
	}

	@Column(name = "CYC_BATCH", precision = 0)
	public Double getCycBatch() {
		return this.cycBatch;
	}

	public void setCycBatch(Double cycBatch) {
		this.cycBatch = cycBatch;
	}

	@Column(name = "UNQUL_ENFOC_BATCH", precision = 0)
	public Double getUnqulEnfocBatch() {
		return this.unqulEnfocBatch;
	}

	public void setUnqulEnfocBatch(Double unqulEnfocBatch) {
		this.unqulEnfocBatch = unqulEnfocBatch;
	}

	@Column(name = "LAB_BATCHRULE_L_RATIO", precision = 0)
	public Double getLabBatchruleLRatio() {
		return this.labBatchruleLRatio;
	}

	public void setLabBatchruleLRatio(Double labBatchruleLRatio) {
		this.labBatchruleLRatio = labBatchruleLRatio;
	}

	@Column(name = "EFFECTIVE_DATE", length = 7)
	public Timestamp getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Timestamp effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Column(name = "OBSOLETE_DATE", length = 7)
	public Timestamp getObsoleteDate() {
		return this.obsoleteDate;
	}

	public void setObsoleteDate(Timestamp obsoleteDate) {
		this.obsoleteDate = obsoleteDate;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "ORG_NAME", length = 50)
	public String getOrgName() {
		return this.orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	@Column(name = "BATCHRULE_LSTATE", length = 1)
	public String getBatchruleLstate() {
		return this.batchruleLstate;
	}

	public void setBatchruleLstate(String batchruleLstate) {
		this.batchruleLstate = batchruleLstate;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "VERSION_NO", length = 32)
	public String getVersionNo() {
		return this.versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "OPER_ORG_CODE", length = 10)
	public String getOperOrgCode() {
		return this.operOrgCode;
	}

	public void setOperOrgCode(String operOrgCode) {
		this.operOrgCode = operOrgCode;
	}

	@Column(name = "TMPLT_ID", length = 32)
	public String getTmpltId() {
		return this.tmpltId;
	}

	public void setTmpltId(String tmpltId) {
		this.tmpltId = tmpltId;
	}

	@Column(name = "TMPLT_TYPE", length = 1)
	public String getTmpltType() {
		return this.tmpltType;
	}

	public void setTmpltType(String tmpltType) {
		this.tmpltType = tmpltType;
	}

	@Column(name = "LOCAL_ORG_CODE", length = 10)
	public String getLocalOrgCode() {
		return this.localOrgCode;
	}

	public void setLocalOrgCode(String localOrgCode) {
		this.localOrgCode = localOrgCode;
	}

	@Column(name = "ENT_LEVEL_CODE", length = 20)
	public String getEntLevelCode() {
		return this.entLevelCode;
	}

	public void setEntLevelCode(String entLevelCode) {
		this.entLevelCode = entLevelCode;
	}

}
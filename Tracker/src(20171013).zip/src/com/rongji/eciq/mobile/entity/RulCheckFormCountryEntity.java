package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * RulCheckFormCountry entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_CHECK_FORM_COUNTRY")
public class RulCheckFormCountryEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 5898284503602459459L;
	private String rulCountryId;
	private RulCheckFormEntity rulCheckForm;
	private String countryCode;
	private String countryName;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;

	// Constructors

	/** default constructor */
	public RulCheckFormCountryEntity() {
	}

	/** minimal constructor */
	public RulCheckFormCountryEntity(String rulCountryId, RulCheckFormEntity rulCheckForm,
			String countryCode) {
		this.rulCountryId = rulCountryId;
		this.rulCheckForm = rulCheckForm;
		this.countryCode = countryCode;
	}

	/** full constructor */
	public RulCheckFormCountryEntity(String rulCountryId, RulCheckFormEntity rulCheckForm,
			String countryCode, String countryName, Timestamp operTime,
			String falgArchive, Timestamp archiveTime) {
		this.rulCountryId = rulCountryId;
		this.rulCheckForm = rulCheckForm;
		this.countryCode = countryCode;
		this.countryName = countryName;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "RUL_COUNTRY_ID", unique = true, nullable = false, length = 32)
	public String getRulCountryId() {
		return this.rulCountryId;
	}

	public void setRulCountryId(String rulCountryId) {
		this.rulCountryId = rulCountryId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHECK_FORM_CODE", nullable = false)
	public RulCheckFormEntity getRulCheckForm() {
		return this.rulCheckForm;
	}

	public void setRulCheckForm(RulCheckFormEntity rulCheckForm) {
		this.rulCheckForm = rulCheckForm;
	}

	@Column(name = "COUNTRY_CODE", nullable = false, length = 8)
	public String getCountryCode() {
		return this.countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@Column(name = "COUNTRY_NAME", length = 80)
	public String getCountryName() {
		return this.countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

}
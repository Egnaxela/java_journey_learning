package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * RulCheckForm entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_CHECK_FORM")
public class RulCheckFormEntity implements java.io.Serializable {

	private static final long serialVersionUID = -3275767714268997466L;
	private String checkFormCode;
	private String formName;
	private String inspBasCatCode;
	private String inspBasisName;
	private String expImpFlag;
	private String mtnType;
	private String parentCode;
	private Timestamp effectiveDate;
	private Timestamp obsoleteDate;
	private String goodsAttr;
	private String applCiqOrgCode;
	private String applCiqOrgName;
	private String magDeptCode;
	private String magDeptName;
	private String remark;
	private Timestamp operTime;
	private String falgArchive;
	private String checkState;
	private Timestamp archiveTime;
	private String orgCode;
	private String applEntLevel;
	private String localOrgCode;
	private String operCode;
	private Set<RulCheckFormCountryEntity> rulCheckFormCountries = new HashSet<RulCheckFormCountryEntity>(
			0);
	private Set<RulCheckFormProdciqEntity> rulCheckFormProdciqs = new HashSet<RulCheckFormProdciqEntity>(
			0);
	private Set<RulCheckItemEntity> rulCheckItems = new HashSet<RulCheckItemEntity>(0);

	// Constructors

	/** default constructor */
	public RulCheckFormEntity() {
	}

	/** minimal constructor */
	public RulCheckFormEntity(String checkFormCode) {
		this.checkFormCode = checkFormCode;
	}

	/** full constructor */
	public RulCheckFormEntity(String checkFormCode, String formName,
			String inspBasCatCode, String inspBasisName, String expImpFlag,
			String mtnType, String parentCode, Timestamp effectiveDate,
			Timestamp obsoleteDate, String goodsAttr, String applCiqOrgCode,
			String applCiqOrgName, String magDeptCode, String magDeptName,
			String remark, Timestamp operTime, String falgArchive,
			String checkState, Timestamp archiveTime, String orgCode,
			String applEntLevel, String localOrgCode, String operCode,
			Set<RulCheckFormCountryEntity> rulCheckFormCountries,
			Set<RulCheckFormProdciqEntity> rulCheckFormProdciqs,
			Set<RulCheckItemEntity> rulCheckItems) {
		this.checkFormCode = checkFormCode;
		this.formName = formName;
		this.inspBasCatCode = inspBasCatCode;
		this.inspBasisName = inspBasisName;
		this.expImpFlag = expImpFlag;
		this.mtnType = mtnType;
		this.parentCode = parentCode;
		this.effectiveDate = effectiveDate;
		this.obsoleteDate = obsoleteDate;
		this.goodsAttr = goodsAttr;
		this.applCiqOrgCode = applCiqOrgCode;
		this.applCiqOrgName = applCiqOrgName;
		this.magDeptCode = magDeptCode;
		this.magDeptName = magDeptName;
		this.remark = remark;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.checkState = checkState;
		this.archiveTime = archiveTime;
		this.orgCode = orgCode;
		this.applEntLevel = applEntLevel;
		this.localOrgCode = localOrgCode;
		this.operCode = operCode;
		this.rulCheckFormCountries = rulCheckFormCountries;
		this.rulCheckFormProdciqs = rulCheckFormProdciqs;
		this.rulCheckItems = rulCheckItems;
	}

	// Property accessors
	@Id
	@Column(name = "CHECK_FORM_CODE", unique = true, nullable = false, length = 32)
	public String getCheckFormCode() {
		return this.checkFormCode;
	}

	public void setCheckFormCode(String checkFormCode) {
		this.checkFormCode = checkFormCode;
	}

	@Column(name = "FORM_NAME", length = 60)
	public String getFormName() {
		return this.formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	@Column(name = "INSP_BAS_CAT_CODE", length = 20)
	public String getInspBasCatCode() {
		return this.inspBasCatCode;
	}

	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}

	@Column(name = "INSP_BASIS_NAME", length = 50)
	public String getInspBasisName() {
		return this.inspBasisName;
	}

	public void setInspBasisName(String inspBasisName) {
		this.inspBasisName = inspBasisName;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "MTN_TYPE", length = 1)
	public String getMtnType() {
		return this.mtnType;
	}

	public void setMtnType(String mtnType) {
		this.mtnType = mtnType;
	}

	@Column(name = "PARENT_CODE", length = 50)
	public String getParentCode() {
		return this.parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	@Column(name = "EFFECTIVE_DATE", length = 7)
	public Timestamp getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Timestamp effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Column(name = "OBSOLETE_DATE", length = 7)
	public Timestamp getObsoleteDate() {
		return this.obsoleteDate;
	}

	public void setObsoleteDate(Timestamp obsoleteDate) {
		this.obsoleteDate = obsoleteDate;
	}

	@Column(name = "GOODS_ATTR", length = 100)
	public String getGoodsAttr() {
		return this.goodsAttr;
	}

	public void setGoodsAttr(String goodsAttr) {
		this.goodsAttr = goodsAttr;
	}

	@Column(name = "APPL_CIQ_ORG_CODE", length = 10)
	public String getApplCiqOrgCode() {
		return this.applCiqOrgCode;
	}

	public void setApplCiqOrgCode(String applCiqOrgCode) {
		this.applCiqOrgCode = applCiqOrgCode;
	}

	@Column(name = "APPL_CIQ_ORG_NAME", length = 50)
	public String getApplCiqOrgName() {
		return this.applCiqOrgName;
	}

	public void setApplCiqOrgName(String applCiqOrgName) {
		this.applCiqOrgName = applCiqOrgName;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "MAG_DEPT_NAME", length = 50)
	public String getMagDeptName() {
		return this.magDeptName;
	}

	public void setMagDeptName(String magDeptName) {
		this.magDeptName = magDeptName;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "CHECK_STATE", length = 1)
	public String getCheckState() {
		return this.checkState;
	}

	public void setCheckState(String checkState) {
		this.checkState = checkState;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "APPL_ENT_LEVEL", length = 10)
	public String getApplEntLevel() {
		return this.applEntLevel;
	}

	public void setApplEntLevel(String applEntLevel) {
		this.applEntLevel = applEntLevel;
	}

	@Column(name = "LOCAL_ORG_CODE", length = 10)
	public String getLocalOrgCode() {
		return this.localOrgCode;
	}

	public void setLocalOrgCode(String localOrgCode) {
		this.localOrgCode = localOrgCode;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "rulCheckForm")
//	public Set<RulCheckFormCountry> getRulCheckFormCountries() {
//		return this.rulCheckFormCountries;
//	}
//
//	public void setRulCheckFormCountries(
//			Set<RulCheckFormCountry> rulCheckFormCountries) {
//		this.rulCheckFormCountries = rulCheckFormCountries;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "rulCheckForm")
//	public Set<RulCheckFormProdciq> getRulCheckFormProdciqs() {
//		return this.rulCheckFormProdciqs;
//	}
//
//	public void setRulCheckFormProdciqs(
//			Set<RulCheckFormProdciq> rulCheckFormProdciqs) {
//		this.rulCheckFormProdciqs = rulCheckFormProdciqs;
//	}
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "rulCheckForm")
//	public Set<RulCheckItem> getRulCheckItems() {
//		return this.rulCheckItems;
//	}
//
//	public void setRulCheckItems(Set<RulCheckItem> rulCheckItems) {
//		this.rulCheckItems = rulCheckItems;
//	}

}
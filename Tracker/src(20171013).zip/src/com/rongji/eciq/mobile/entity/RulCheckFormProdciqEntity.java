package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * RulCheckFormProdciq entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_CHECK_FORM_PRODCIQ")
public class RulCheckFormProdciqEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 6241117790180698465L;
	private String chkProdId;
	private RulCheckFormEntity rulCheckForm;
	private String ciqCode;
	private String ciqName;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;

	// Constructors

	/** default constructor */
	public RulCheckFormProdciqEntity() {
	}

	/** minimal constructor */
	public RulCheckFormProdciqEntity(String chkProdId, RulCheckFormEntity rulCheckForm,
			String ciqCode) {
		this.chkProdId = chkProdId;
		this.rulCheckForm = rulCheckForm;
		this.ciqCode = ciqCode;
	}

	/** full constructor */
	public RulCheckFormProdciqEntity(String chkProdId, RulCheckFormEntity rulCheckForm,
			String ciqCode, String ciqName, Timestamp operTime,
			String falgArchive, Timestamp archiveTime) {
		this.chkProdId = chkProdId;
		this.rulCheckForm = rulCheckForm;
		this.ciqCode = ciqCode;
		this.ciqName = ciqName;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "CHK_PROD_ID", unique = true, nullable = false, length = 32)
	public String getChkProdId() {
		return this.chkProdId;
	}

	public void setChkProdId(String chkProdId) {
		this.chkProdId = chkProdId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHECK_FORM_CODE", nullable = false)
	public RulCheckFormEntity getRulCheckForm() {
		return this.rulCheckForm;
	}

	public void setRulCheckForm(RulCheckFormEntity rulCheckForm) {
		this.rulCheckForm = rulCheckForm;
	}

	@Column(name = "CIQ_CODE", nullable = false, length = 20)
	public String getCiqCode() {
		return this.ciqCode;
	}

	public void setCiqCode(String ciqCode) {
		this.ciqCode = ciqCode;
	}

	@Column(name = "CIQ_NAME", length = 50)
	public String getCiqName() {
		return this.ciqName;
	}

	public void setCiqName(String ciqName) {
		this.ciqName = ciqName;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

}
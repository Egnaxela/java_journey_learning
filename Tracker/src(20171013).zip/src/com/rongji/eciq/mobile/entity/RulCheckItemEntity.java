package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * RulCheckItem entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "RUL_CHECK_ITEM")
public class RulCheckItemEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -3122392007824117517L;
	private String checkItemId;
	private RulCheckFormEntity rulCheckForm;
	private String checkItemCode;
	private String checkItemName;
	private String checkItemType;
	private String checkItemDesc;
	private String sampleSch;
	private String isSubset;
	private String parentCode;
	private Timestamp operTime;
	private String falgArchive;
	private Timestamp archiveTime;
	private String itemTaxisCode;
	private String inspBasCatCode;
	private String inspBasisName;

	// Constructors

	/** default constructor */
	public RulCheckItemEntity() {
	}

	/** minimal constructor */
	public RulCheckItemEntity(String checkItemId) {
		this.checkItemId = checkItemId;
	}

	/** full constructor */
	public RulCheckItemEntity(String checkItemId, RulCheckFormEntity rulCheckForm,
			String checkItemCode, String checkItemName, String checkItemType,
			String checkItemDesc, String sampleSch, String isSubset,
			String parentCode, Timestamp operTime, String falgArchive,
			Timestamp archiveTime, String itemTaxisCode, String inspBasCatCode,
			String inspBasisName) {
		this.checkItemId = checkItemId;
		this.rulCheckForm = rulCheckForm;
		this.checkItemCode = checkItemCode;
		this.checkItemName = checkItemName;
		this.checkItemType = checkItemType;
		this.checkItemDesc = checkItemDesc;
		this.sampleSch = sampleSch;
		this.isSubset = isSubset;
		this.parentCode = parentCode;
		this.operTime = operTime;
		this.falgArchive = falgArchive;
		this.archiveTime = archiveTime;
		this.itemTaxisCode = itemTaxisCode;
		this.inspBasCatCode = inspBasCatCode;
		this.inspBasisName = inspBasisName;
	}

	// Property accessors
	@Id
	@Column(name = "CHECK_ITEM_ID", unique = true, nullable = false, length = 32)
	public String getCheckItemId() {
		return this.checkItemId;
	}

	public void setCheckItemId(String checkItemId) {
		this.checkItemId = checkItemId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHECK_FORM_CODE")
	public RulCheckFormEntity getRulCheckForm() {
		return this.rulCheckForm;
	}

	public void setRulCheckForm(RulCheckFormEntity rulCheckForm) {
		this.rulCheckForm = rulCheckForm;
	}

	@Column(name = "CHECK_ITEM_CODE", length = 20)
	public String getCheckItemCode() {
		return this.checkItemCode;
	}

	public void setCheckItemCode(String checkItemCode) {
		this.checkItemCode = checkItemCode;
	}

	@Column(name = "CHECK_ITEM_NAME", length = 500)
	public String getCheckItemName() {
		return this.checkItemName;
	}

	public void setCheckItemName(String checkItemName) {
		this.checkItemName = checkItemName;
	}

	@Column(name = "CHECK_ITEM_TYPE", length = 1)
	public String getCheckItemType() {
		return this.checkItemType;
	}

	public void setCheckItemType(String checkItemType) {
		this.checkItemType = checkItemType;
	}

	@Column(name = "CHECK_ITEM_DESC", length = 1000)
	public String getCheckItemDesc() {
		return this.checkItemDesc;
	}

	public void setCheckItemDesc(String checkItemDesc) {
		this.checkItemDesc = checkItemDesc;
	}

	@Column(name = "SAMPLE_SCH", length = 200)
	public String getSampleSch() {
		return this.sampleSch;
	}

	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}

	@Column(name = "IS_SUBSET", length = 1)
	public String getIsSubset() {
		return this.isSubset;
	}

	public void setIsSubset(String isSubset) {
		this.isSubset = isSubset;
	}

	@Column(name = "PARENT_CODE", length = 50)
	public String getParentCode() {
		return this.parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "ITEM_TAXIS_CODE", length = 12)
	public String getItemTaxisCode() {
		return this.itemTaxisCode;
	}

	public void setItemTaxisCode(String itemTaxisCode) {
		this.itemTaxisCode = itemTaxisCode;
	}

	@Column(name = "INSP_BAS_CAT_CODE", length = 20)
	public String getInspBasCatCode() {
		return this.inspBasCatCode;
	}

	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}

	@Column(name = "INSP_BASIS_NAME", length = 50)
	public String getInspBasisName() {
		return this.inspBasisName;
	}

	public void setInspBasisName(String inspBasisName) {
		this.inspBasisName = inspBasisName;
	}

}
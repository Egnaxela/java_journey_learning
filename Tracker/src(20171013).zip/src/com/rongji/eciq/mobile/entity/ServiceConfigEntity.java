/**  
 * FileName: ServiceConfigEntity.java    
 * @Description: service配置文件
 * Company       rongji
 * @version      1.0
 * @author:      黄庆炬  
 * @version:     1.0
 * Createdate:   2017-5-10 下午4:26:06  
 *  
 */  

package com.rongji.eciq.mobile.entity;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**  
 * Description: service配置文件
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙 
 * @version:    1.0  
 * Create at:   2017-5-10 下午4:26:06  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10     李云龙                      1.0         1.0 Version  
 */
@Component("service") 
public class ServiceConfigEntity {
	@Value("${assess.service}")  
	private String assessService;//服务地址
	@Value("${assess.service.name}")
	private String assessServiceName;//外部接口路径
	
	public String getAssessService() {
		return assessService;
	}
	public void setAssessService(String assessService) {
		this.assessService = assessService;
	}
	public String getAssessServiceName() {
		return assessServiceName;
	}
	public void setAssessServiceName(String assessServiceName) {
		this.assessServiceName = assessServiceName;
	}
	
	
}

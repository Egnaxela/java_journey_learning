package com.rongji.eciq.mobile.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "INS_DECL_MAG")
public class SubOrReasEntity implements java.io.Serializable {

	private static final long serialVersionUID = -2405225285994922105L;

	private String declMagId;
	private String declNo;
	private String exeInspOrgCode;
	private String excInspDeptCode;
	private String asInpTkOrgCode;
	private String asInpTkDeptCode;
	private String flowPathStatus;
	private String receiverDocCode;
	private Timestamp acceptApprTm;
	private String inspAsgnPrsnC;
	private Timestamp inspAssignTm;
	private String inspectorCode;
	private Timestamp confmTime;
	private String otherInspOperator;
	private String inspContCodes;
	private String certTypeCodes;
	private Timestamp finishTime;
	private String inspPassOperatorCode;
	private Timestamp impowerDate;
	private String impowerFlag;
	private String impowerAudit;
	private String passedMode;
	private Timestamp releaseDate;
	private String magDeptCode;
	private Timestamp auditTime;
	private String verifier;
	private String auditContent;
	private String isAudit;
	private String operType;
	private String workContentCode;
	private String cancelFlag;
	private String remark;
	private String falgArchive;
	private Timestamp operTime;
	private Timestamp archiveTime;
	private String expImpFlag;
	private String subType;
	private String goodsName;
	private String retReason;
	private String orgCodePath;
	private String subPriv;
	private String certTypeNames;
	private String isHaveAux;
	private Timestamp declDate;
	private String processStatus;
	private String consigneeCname;
	private String inspRequire;
	private String declRegName;
	private String entName;
	private String auditPriv;
	private String checkPriv;
	private String evalPriv;
	private String unquaPriv;
	private String declWorkNo;
	private String entMgrNo;
	private String certOriginals;
	private String certCopies;
	private String regiPriv;

	// Constructors

	/** default constructor */
	public SubOrReasEntity() {
	}

	/** minimal constructor */
	public SubOrReasEntity(String declMagId, String declNo, String exeInspOrgCode, String excInspDeptCode) {
		this.declMagId = declMagId;
		this.declNo = declNo;
		this.exeInspOrgCode = exeInspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
	}

	/** full constructor */
	public SubOrReasEntity(String declMagId, String declNo, String exeInspOrgCode, String excInspDeptCode,
			String asInpTkOrgCode, String asInpTkDeptCode, String flowPathStatus, String receiverDocCode,
			Timestamp acceptApprTm, String inspAsgnPrsnC, Timestamp inspAssignTm, String inspectorCode,
			Timestamp confmTime, String otherInspOperator, String inspContCodes, String certTypeCodes,
			Timestamp finishTime, String inspPassOperatorCode, Timestamp impowerDate, String impowerFlag,
			String impowerAudit, String passedMode, Timestamp releaseDate, String magDeptCode, Timestamp auditTime,
			String verifier, String auditContent, String isAudit, String operType, String workContentCode,
			String cancelFlag, String remark, String falgArchive, Timestamp operTime, Timestamp archiveTime,
			String expImpFlag, String subType, String goodsName, String retReason, String orgCodePath, String subPriv,
			String certTypeNames, String isHaveAux, Timestamp declDate, String processStatus, String consigneeCname,
			String inspRequire, String declRegName, String entName, String auditPriv, String checkPriv, String evalPriv,
			String unquaPriv, String declWorkNo, String entMgrNo, String certOriginals, String certCopies) {
		this.declMagId = declMagId;
		this.declNo = declNo;
		this.exeInspOrgCode = exeInspOrgCode;
		this.excInspDeptCode = excInspDeptCode;
		this.asInpTkOrgCode = asInpTkOrgCode;
		this.asInpTkDeptCode = asInpTkDeptCode;
		this.flowPathStatus = flowPathStatus;
		this.receiverDocCode = receiverDocCode;
		this.acceptApprTm = acceptApprTm;
		this.inspAsgnPrsnC = inspAsgnPrsnC;
		this.inspAssignTm = inspAssignTm;
		this.inspectorCode = inspectorCode;
		this.confmTime = confmTime;
		this.otherInspOperator = otherInspOperator;
		this.inspContCodes = inspContCodes;
		this.certTypeCodes = certTypeCodes;
		this.finishTime = finishTime;
		this.inspPassOperatorCode = inspPassOperatorCode;
		this.impowerDate = impowerDate;
		this.impowerFlag = impowerFlag;
		this.impowerAudit = impowerAudit;
		this.passedMode = passedMode;
		this.releaseDate = releaseDate;
		this.magDeptCode = magDeptCode;
		this.auditTime = auditTime;
		this.verifier = verifier;
		this.auditContent = auditContent;
		this.isAudit = isAudit;
		this.operType = operType;
		this.workContentCode = workContentCode;
		this.cancelFlag = cancelFlag;
		this.remark = remark;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.archiveTime = archiveTime;
		this.expImpFlag = expImpFlag;
		this.subType = subType;
		this.goodsName = goodsName;
		this.retReason = retReason;
		this.orgCodePath = orgCodePath;
		this.subPriv = subPriv;
		this.certTypeNames = certTypeNames;
		this.isHaveAux = isHaveAux;
		this.declDate = declDate;
		this.processStatus = processStatus;
		this.consigneeCname = consigneeCname;
		this.inspRequire = inspRequire;
		this.declRegName = declRegName;
		this.entName = entName;
		this.auditPriv = auditPriv;
		this.checkPriv = checkPriv;
		this.evalPriv = evalPriv;
		this.unquaPriv = unquaPriv;
		this.declWorkNo = declWorkNo;
		this.entMgrNo = entMgrNo;
		this.certOriginals = certOriginals;
		this.certCopies = certCopies;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_MAG_ID", unique = true, nullable = false, length = 32)
	public String getDeclMagId() {
		return this.declMagId;
	}

	public void setDeclMagId(String declMagId) {
		this.declMagId = declMagId;
	}

	@Column(name = "DECL_NO", nullable = false, length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "EXE_INSP_ORG_CODE", nullable = false, length = 10)
	public String getExeInspOrgCode() {
		return this.exeInspOrgCode;
	}

	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}

	@Column(name = "EXC_INSP_DEPT_CODE", nullable = false, length = 10)
	public String getExcInspDeptCode() {
		return this.excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	@Column(name = "AS_INP_TK_ORG_CODE", length = 10)
	public String getAsInpTkOrgCode() {
		return this.asInpTkOrgCode;
	}

	public void setAsInpTkOrgCode(String asInpTkOrgCode) {
		this.asInpTkOrgCode = asInpTkOrgCode;
	}

	@Column(name = "AS_INP_TK_DEPT_CODE", length = 10)
	public String getAsInpTkDeptCode() {
		return this.asInpTkDeptCode;
	}

	public void setAsInpTkDeptCode(String asInpTkDeptCode) {
		this.asInpTkDeptCode = asInpTkDeptCode;
	}

	@Column(name = "FLOW_PATH_STATUS", length = 4)
	public String getFlowPathStatus() {
		return this.flowPathStatus;
	}

	public void setFlowPathStatus(String flowPathStatus) {
		this.flowPathStatus = flowPathStatus;
	}

	@Column(name = "RECEIVER_DOC_CODE", length = 20)
	public String getReceiverDocCode() {
		return this.receiverDocCode;
	}

	public void setReceiverDocCode(String receiverDocCode) {
		this.receiverDocCode = receiverDocCode;
	}

	@Column(name = "ACCEPT_APPR_TM", length = 7)
	public Timestamp getAcceptApprTm() {
		return this.acceptApprTm;
	}

	public void setAcceptApprTm(Timestamp acceptApprTm) {
		this.acceptApprTm = acceptApprTm;
	}

	@Column(name = "INSP_ASGN_PRSN_C", length = 20)
	public String getInspAsgnPrsnC() {
		return this.inspAsgnPrsnC;
	}

	public void setInspAsgnPrsnC(String inspAsgnPrsnC) {
		this.inspAsgnPrsnC = inspAsgnPrsnC;
	}

	@Column(name = "INSP_ASSIGN_TM", length = 7)
	public Timestamp getInspAssignTm() {
		return this.inspAssignTm;
	}

	public void setInspAssignTm(Timestamp inspAssignTm) {
		this.inspAssignTm = inspAssignTm;
	}

	@Column(name = "INSPECTOR_CODE", length = 20)
	public String getInspectorCode() {
		return this.inspectorCode;
	}

	public void setInspectorCode(String inspectorCode) {
		this.inspectorCode = inspectorCode;
	}

	@Column(name = "CONFM_TIME", length = 7)
	public Timestamp getConfmTime() {
		return this.confmTime;
	}

	public void setConfmTime(Timestamp confmTime) {
		this.confmTime = confmTime;
	}

	@Column(name = "OTHER_INSP_OPERATOR", length = 50)
	public String getOtherInspOperator() {
		return this.otherInspOperator;
	}

	public void setOtherInspOperator(String otherInspOperator) {
		this.otherInspOperator = otherInspOperator;
	}

	@Column(name = "INSP_CONT_CODES", length = 50)
	public String getInspContCodes() {
		return this.inspContCodes;
	}

	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}

	@Column(name = "CERT_TYPE_CODES", length = 500)
	public String getCertTypeCodes() {
		return this.certTypeCodes;
	}

	public void setCertTypeCodes(String certTypeCodes) {
		this.certTypeCodes = certTypeCodes;
	}

	@Column(name = "FINISH_TIME", length = 7)
	public Timestamp getFinishTime() {
		return this.finishTime;
	}

	public void setFinishTime(Timestamp finishTime) {
		this.finishTime = finishTime;
	}

	@Column(name = "INSP_PASS_OPERATOR_CODE", length = 20)
	public String getInspPassOperatorCode() {
		return this.inspPassOperatorCode;
	}

	public void setInspPassOperatorCode(String inspPassOperatorCode) {
		this.inspPassOperatorCode = inspPassOperatorCode;
	}

	@Column(name = "IMPOWER_DATE", length = 7)
	public Timestamp getImpowerDate() {
		return this.impowerDate;
	}

	public void setImpowerDate(Timestamp impowerDate) {
		this.impowerDate = impowerDate;
	}

	@Column(name = "IMPOWER_FLAG", length = 1)
	public String getImpowerFlag() {
		return this.impowerFlag;
	}

	public void setImpowerFlag(String impowerFlag) {
		this.impowerFlag = impowerFlag;
	}

	@Column(name = "IMPOWER_AUDIT", length = 1)
	public String getImpowerAudit() {
		return this.impowerAudit;
	}

	public void setImpowerAudit(String impowerAudit) {
		this.impowerAudit = impowerAudit;
	}

	@Column(name = "PASSED_MODE", length = 1)
	public String getPassedMode() {
		return this.passedMode;
	}

	public void setPassedMode(String passedMode) {
		this.passedMode = passedMode;
	}

	@Column(name = "RELEASE_DATE", length = 7)
	public Timestamp getReleaseDate() {
		return this.releaseDate;
	}

	public void setReleaseDate(Timestamp releaseDate) {
		this.releaseDate = releaseDate;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "AUDIT_TIME", length = 7)
	public Timestamp getAuditTime() {
		return this.auditTime;
	}

	public void setAuditTime(Timestamp auditTime) {
		this.auditTime = auditTime;
	}

	@Column(name = "VERIFIER", length = 20)
	public String getVerifier() {
		return this.verifier;
	}

	public void setVerifier(String verifier) {
		this.verifier = verifier;
	}

	@Column(name = "AUDIT_CONTENT", length = 2000)
	public String getAuditContent() {
		return this.auditContent;
	}

	public void setAuditContent(String auditContent) {
		this.auditContent = auditContent;
	}

	@Column(name = "IS_AUDIT", length = 1)
	public String getIsAudit() {
		return this.isAudit;
	}

	public void setIsAudit(String isAudit) {
		this.isAudit = isAudit;
	}

	@Column(name = "OPER_TYPE", length = 1)
	public String getOperType() {
		return this.operType;
	}

	public void setOperType(String operType) {
		this.operType = operType;
	}

	@Column(name = "WORK_CONTENT_CODE", length = 1)
	public String getWorkContentCode() {
		return this.workContentCode;
	}

	public void setWorkContentCode(String workContentCode) {
		this.workContentCode = workContentCode;
	}

	@Column(name = "CANCEL_FLAG", length = 1)
	public String getCancelFlag() {
		return this.cancelFlag;
	}

	public void setCancelFlag(String cancelFlag) {
		this.cancelFlag = cancelFlag;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "EXP_IMP_FLAG", length = 1)
	public String getExpImpFlag() {
		return this.expImpFlag;
	}

	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}

	@Column(name = "SUB_TYPE", length = 1)
	public String getSubType() {
		return this.subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	@Column(name = "GOODS_NAME", length = 500)
	public String getGoodsName() {
		return this.goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	@Column(name = "RET_REASON", length = 500)
	public String getRetReason() {
		return this.retReason;
	}

	public void setRetReason(String retReason) {
		this.retReason = retReason;
	}

	@Column(name = "ORG_CODE_PATH", length = 2000)
	public String getOrgCodePath() {
		return this.orgCodePath;
	}

	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}

	@Column(name = "SUB_PRIV", length = 1)
	public String getSubPriv() {
		return this.subPriv;
	}

	public void setSubPriv(String subPriv) {
		this.subPriv = subPriv;
	}

	@Column(name = "CERT_TYPE_NAMES", length = 500)
	public String getCertTypeNames() {
		return this.certTypeNames;
	}

	public void setCertTypeNames(String certTypeNames) {
		this.certTypeNames = certTypeNames;
	}

	@Column(name = "IS_HAVE_AUX", length = 1)
	public String getIsHaveAux() {
		return this.isHaveAux;
	}

	public void setIsHaveAux(String isHaveAux) {
		this.isHaveAux = isHaveAux;
	}

	@Column(name = "DECL_DATE", length = 7)
	public Timestamp getDeclDate() {
		return this.declDate;
	}

	public void setDeclDate(Timestamp declDate) {
		this.declDate = declDate;
	}

	@Column(name = "PROCESS_STATUS", length = 10)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name = "CONSIGNEE_CNAME", length = 150)
	public String getConsigneeCname() {
		return this.consigneeCname;
	}

	public void setConsigneeCname(String consigneeCname) {
		this.consigneeCname = consigneeCname;
	}

	@Column(name = "INSP_REQUIRE", length = 1)
	public String getInspRequire() {
		return this.inspRequire;
	}

	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}

	@Column(name = "DECL_REG_NAME", length = 100)
	public String getDeclRegName() {
		return this.declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	@Column(name = "ENT_NAME", length = 100)
	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	@Column(name = "AUDIT_PRIV", length = 1)
	public String getAuditPriv() {
		return this.auditPriv;
	}

	public void setAuditPriv(String auditPriv) {
		this.auditPriv = auditPriv;
	}

	@Column(name = "CHECK_PRIV", length = 1)
	public String getCheckPriv() {
		return this.checkPriv;
	}

	public void setCheckPriv(String checkPriv) {
		this.checkPriv = checkPriv;
	}

	@Column(name = "EVAL_PRIV", length = 1)
	public String getEvalPriv() {
		return this.evalPriv;
	}

	public void setEvalPriv(String evalPriv) {
		this.evalPriv = evalPriv;
	}

	@Column(name = "UNQUA_PRIV", length = 1)
	public String getUnquaPriv() {
		return this.unquaPriv;
	}

	public void setUnquaPriv(String unquaPriv) {
		this.unquaPriv = unquaPriv;
	}

	@Column(name = "DECL_WORK_NO", length = 20)
	public String getDeclWorkNo() {
		return this.declWorkNo;
	}

	public void setDeclWorkNo(String declWorkNo) {
		this.declWorkNo = declWorkNo;
	}

	@Column(name = "ENT_MGR_NO", length = 20)
	public String getEntMgrNo() {
		return this.entMgrNo;
	}

	public void setEntMgrNo(String entMgrNo) {
		this.entMgrNo = entMgrNo;
	}

	@Column(name = "CERT_ORIGINALS", length = 50)
	public String getCertOriginals() {
		return this.certOriginals;
	}

	public void setCertOriginals(String certOriginals) {
		this.certOriginals = certOriginals;
	}

	@Column(name = "CERT_COPIES", length = 50)
	public String getCertCopies() {
		return this.certCopies;
	}

	public void setCertCopies(String certCopies) {
		this.certCopies = certCopies;
	}

	@Column(name = "REGI_PRIV", length = 1)
	public String getRegiPriv() {
		return regiPriv;
	}

	public void setRegiPriv(String regiPriv) {
		this.regiPriv = regiPriv;
	}
	
	

}

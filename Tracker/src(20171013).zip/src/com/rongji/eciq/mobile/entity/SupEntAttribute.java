package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SupEntAttribute entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SUP_ENT_ATTRIBUTE")

public class SupEntAttribute  implements java.io.Serializable {


    // Fields    

     private String entAttributeId;
     private String entOrgCode;
     private String entName;
     private String ciqCode;
     private String ciqName;
     private String prodHsCode;
     private String hsName;
     private String riskGradeCode;
     private String corrOrgCode;
     private String corrOrgName;
     private String corrInspectorCode;
     private String corrInspectorName;
     private Date spvBgnDate;
     private Date spvEndDate;
     private String prodBatMode;
     private String isNeedManualEval;
     private String validFlag;
     private String cerOffSwtch;
     private String isManualWpAudit;
     private String isManualWpSpveval;
     private String psnLabelWodPack;
     private BigDecimal inspCertProid;
     private String inspPatternCode;
     private String modifyPersonCode;
     private Date modifTime;
     private String abolishFlag;
     private BigDecimal pbArchiveTime;
     private String dataSource;
     private String expImpFlag;
     private String falgArchive;
     private Date operTime;
     private String templateMakerCode;
     private String templateMakerName;
     private String templateMakerDeptCode;
     private String templateMakerDeptName;
     private String isEvaluate;
     private String declRegNo;
     private Date archiveTime;
     private String corrDeptCode;
     private String draVisaArtificial;
     private String sentStatus;


    // Constructors

    /** default constructor */
    public SupEntAttribute() {
    }

	/** minimal constructor */
    public SupEntAttribute(String entAttributeId) {
        this.entAttributeId = entAttributeId;
    }
    
    /** full constructor */
    public SupEntAttribute(String entAttributeId, String entOrgCode, String entName, String ciqCode, String ciqName, String prodHsCode, String hsName, String riskGradeCode, String corrOrgCode, String corrOrgName, String corrInspectorCode, String corrInspectorName, Date spvBgnDate, Date spvEndDate, String prodBatMode, String isNeedManualEval, String validFlag, String cerOffSwtch, String isManualWpAudit, String isManualWpSpveval, String psnLabelWodPack, BigDecimal inspCertProid, String inspPatternCode, String modifyPersonCode, Date modifTime, String abolishFlag, BigDecimal pbArchiveTime, String dataSource, String expImpFlag, String falgArchive, Date operTime, String templateMakerCode, String templateMakerName, String templateMakerDeptCode, String templateMakerDeptName, String isEvaluate, String declRegNo, Date archiveTime, String corrDeptCode, String draVisaArtificial, String sentStatus) {
        this.entAttributeId = entAttributeId;
        this.entOrgCode = entOrgCode;
        this.entName = entName;
        this.ciqCode = ciqCode;
        this.ciqName = ciqName;
        this.prodHsCode = prodHsCode;
        this.hsName = hsName;
        this.riskGradeCode = riskGradeCode;
        this.corrOrgCode = corrOrgCode;
        this.corrOrgName = corrOrgName;
        this.corrInspectorCode = corrInspectorCode;
        this.corrInspectorName = corrInspectorName;
        this.spvBgnDate = spvBgnDate;
        this.spvEndDate = spvEndDate;
        this.prodBatMode = prodBatMode;
        this.isNeedManualEval = isNeedManualEval;
        this.validFlag = validFlag;
        this.cerOffSwtch = cerOffSwtch;
        this.isManualWpAudit = isManualWpAudit;
        this.isManualWpSpveval = isManualWpSpveval;
        this.psnLabelWodPack = psnLabelWodPack;
        this.inspCertProid = inspCertProid;
        this.inspPatternCode = inspPatternCode;
        this.modifyPersonCode = modifyPersonCode;
        this.modifTime = modifTime;
        this.abolishFlag = abolishFlag;
        this.pbArchiveTime = pbArchiveTime;
        this.dataSource = dataSource;
        this.expImpFlag = expImpFlag;
        this.falgArchive = falgArchive;
        this.operTime = operTime;
        this.templateMakerCode = templateMakerCode;
        this.templateMakerName = templateMakerName;
        this.templateMakerDeptCode = templateMakerDeptCode;
        this.templateMakerDeptName = templateMakerDeptName;
        this.isEvaluate = isEvaluate;
        this.declRegNo = declRegNo;
        this.archiveTime = archiveTime;
        this.corrDeptCode = corrDeptCode;
        this.draVisaArtificial = draVisaArtificial;
        this.sentStatus = sentStatus;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="ENT_ATTRIBUTE_ID", unique=true, nullable=false, length=32)

    public String getEntAttributeId() {
        return this.entAttributeId;
    }
    
    public void setEntAttributeId(String entAttributeId) {
        this.entAttributeId = entAttributeId;
    }
    
    @Column(name="ENT_ORG_CODE", length=10)

    public String getEntOrgCode() {
        return this.entOrgCode;
    }
    
    public void setEntOrgCode(String entOrgCode) {
        this.entOrgCode = entOrgCode;
    }
    
    @Column(name="ENT_NAME", length=100)

    public String getEntName() {
        return this.entName;
    }
    
    public void setEntName(String entName) {
        this.entName = entName;
    }
    
    @Column(name="CIQ_CODE", length=20)

    public String getCiqCode() {
        return this.ciqCode;
    }
    
    public void setCiqCode(String ciqCode) {
        this.ciqCode = ciqCode;
    }
    
    @Column(name="CIQ_NAME", length=500)

    public String getCiqName() {
        return this.ciqName;
    }
    
    public void setCiqName(String ciqName) {
        this.ciqName = ciqName;
    }
    
    @Column(name="PROD_HS_CODE", length=12)

    public String getProdHsCode() {
        return this.prodHsCode;
    }
    
    public void setProdHsCode(String prodHsCode) {
        this.prodHsCode = prodHsCode;
    }
    
    @Column(name="HS_NAME", length=300)

    public String getHsName() {
        return this.hsName;
    }
    
    public void setHsName(String hsName) {
        this.hsName = hsName;
    }
    
    @Column(name="RISK_GRADE_CODE", length=1)

    public String getRiskGradeCode() {
        return this.riskGradeCode;
    }
    
    public void setRiskGradeCode(String riskGradeCode) {
        this.riskGradeCode = riskGradeCode;
    }
    
    @Column(name="CORR_ORG_CODE", length=10)

    public String getCorrOrgCode() {
        return this.corrOrgCode;
    }
    
    public void setCorrOrgCode(String corrOrgCode) {
        this.corrOrgCode = corrOrgCode;
    }
    
    @Column(name="CORR_ORG_NAME", length=50)

    public String getCorrOrgName() {
        return this.corrOrgName;
    }
    
    public void setCorrOrgName(String corrOrgName) {
        this.corrOrgName = corrOrgName;
    }
    
    @Column(name="CORR_INSPECTOR_CODE", length=20)

    public String getCorrInspectorCode() {
        return this.corrInspectorCode;
    }
    
    public void setCorrInspectorCode(String corrInspectorCode) {
        this.corrInspectorCode = corrInspectorCode;
    }
    
    @Column(name="CORR_INSPECTOR_NAME", length=50)

    public String getCorrInspectorName() {
        return this.corrInspectorName;
    }
    
    public void setCorrInspectorName(String corrInspectorName) {
        this.corrInspectorName = corrInspectorName;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="SPV_BGN_DATE", length=7)

    public Date getSpvBgnDate() {
        return this.spvBgnDate;
    }
    
    public void setSpvBgnDate(Date spvBgnDate) {
        this.spvBgnDate = spvBgnDate;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="SPV_END_DATE", length=7)

    public Date getSpvEndDate() {
        return this.spvEndDate;
    }
    
    public void setSpvEndDate(Date spvEndDate) {
        this.spvEndDate = spvEndDate;
    }
    
    @Column(name="PROD_BAT_MODE", length=1)

    public String getProdBatMode() {
        return this.prodBatMode;
    }
    
    public void setProdBatMode(String prodBatMode) {
        this.prodBatMode = prodBatMode;
    }
    
    @Column(name="IS_NEED_MANUAL_EVAL", length=1)

    public String getIsNeedManualEval() {
        return this.isNeedManualEval;
    }
    
    public void setIsNeedManualEval(String isNeedManualEval) {
        this.isNeedManualEval = isNeedManualEval;
    }
    
    @Column(name="VALID_FLAG", length=1)

    public String getValidFlag() {
        return this.validFlag;
    }
    
    public void setValidFlag(String validFlag) {
        this.validFlag = validFlag;
    }
    
    @Column(name="CER_OFF_SWTCH", length=1)

    public String getCerOffSwtch() {
        return this.cerOffSwtch;
    }
    
    public void setCerOffSwtch(String cerOffSwtch) {
        this.cerOffSwtch = cerOffSwtch;
    }
    
    @Column(name="IS_MANUAL_WP_AUDIT", length=1)

    public String getIsManualWpAudit() {
        return this.isManualWpAudit;
    }
    
    public void setIsManualWpAudit(String isManualWpAudit) {
        this.isManualWpAudit = isManualWpAudit;
    }
    
    @Column(name="IS_MANUAL_WP_SPVEVAL", length=1)

    public String getIsManualWpSpveval() {
        return this.isManualWpSpveval;
    }
    
    public void setIsManualWpSpveval(String isManualWpSpveval) {
        this.isManualWpSpveval = isManualWpSpveval;
    }
    
    @Column(name="PSN_LABEL_WOD_PACK", length=1)

    public String getPsnLabelWodPack() {
        return this.psnLabelWodPack;
    }
    
    public void setPsnLabelWodPack(String psnLabelWodPack) {
        this.psnLabelWodPack = psnLabelWodPack;
    }
    
    @Column(name="INSP_CERT_PROID", precision=22, scale=0)

    public BigDecimal getInspCertProid() {
        return this.inspCertProid;
    }
    
    public void setInspCertProid(BigDecimal inspCertProid) {
        this.inspCertProid = inspCertProid;
    }
    
    @Column(name="INSP_PATTERN_CODE", length=4)

    public String getInspPatternCode() {
        return this.inspPatternCode;
    }
    
    public void setInspPatternCode(String inspPatternCode) {
        this.inspPatternCode = inspPatternCode;
    }
    
    @Column(name="MODIFY_PERSON_CODE", length=20)

    public String getModifyPersonCode() {
        return this.modifyPersonCode;
    }
    
    public void setModifyPersonCode(String modifyPersonCode) {
        this.modifyPersonCode = modifyPersonCode;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="MODIF_TIME", length=7)

    public Date getModifTime() {
        return this.modifTime;
    }
    
    public void setModifTime(Date modifTime) {
        this.modifTime = modifTime;
    }
    
    @Column(name="ABOLISH_FLAG", length=1)

    public String getAbolishFlag() {
        return this.abolishFlag;
    }
    
    public void setAbolishFlag(String abolishFlag) {
        this.abolishFlag = abolishFlag;
    }
    
    @Column(name="PB_ARCHIVE_TIME", precision=22, scale=0)

    public BigDecimal getPbArchiveTime() {
        return this.pbArchiveTime;
    }
    
    public void setPbArchiveTime(BigDecimal pbArchiveTime) {
        this.pbArchiveTime = pbArchiveTime;
    }
    
    @Column(name="DATA_SOURCE", length=50)

    public String getDataSource() {
        return this.dataSource;
    }
    
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }
    
    @Column(name="EXP_IMP_FLAG", length=1)

    public String getExpImpFlag() {
        return this.expImpFlag;
    }
    
    public void setExpImpFlag(String expImpFlag) {
        this.expImpFlag = expImpFlag;
    }
    
    @Column(name="FALG_ARCHIVE", length=1)

    public String getFalgArchive() {
        return this.falgArchive;
    }
    
    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPER_TIME", length=7)

    public Date getOperTime() {
        return this.operTime;
    }
    
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    
    @Column(name="TEMPLATE_MAKER_CODE", length=20)

    public String getTemplateMakerCode() {
        return this.templateMakerCode;
    }
    
    public void setTemplateMakerCode(String templateMakerCode) {
        this.templateMakerCode = templateMakerCode;
    }
    
    @Column(name="TEMPLATE_MAKER_NAME", length=50)

    public String getTemplateMakerName() {
        return this.templateMakerName;
    }
    
    public void setTemplateMakerName(String templateMakerName) {
        this.templateMakerName = templateMakerName;
    }
    
    @Column(name="TEMPLATE_MAKER_DEPT_CODE", length=10)

    public String getTemplateMakerDeptCode() {
        return this.templateMakerDeptCode;
    }
    
    public void setTemplateMakerDeptCode(String templateMakerDeptCode) {
        this.templateMakerDeptCode = templateMakerDeptCode;
    }
    
    @Column(name="TEMPLATE_MAKER_DEPT_NAME", length=100)

    public String getTemplateMakerDeptName() {
        return this.templateMakerDeptName;
    }
    
    public void setTemplateMakerDeptName(String templateMakerDeptName) {
        this.templateMakerDeptName = templateMakerDeptName;
    }
    
    @Column(name="IS_EVALUATE", length=1)

    public String getIsEvaluate() {
        return this.isEvaluate;
    }
    
    public void setIsEvaluate(String isEvaluate) {
        this.isEvaluate = isEvaluate;
    }
    
    @Column(name="DECL_REG_NO", length=20)

    public String getDeclRegNo() {
        return this.declRegNo;
    }
    
    public void setDeclRegNo(String declRegNo) {
        this.declRegNo = declRegNo;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ARCHIVE_TIME", length=7)

    public Date getArchiveTime() {
        return this.archiveTime;
    }
    
    public void setArchiveTime(Date archiveTime) {
        this.archiveTime = archiveTime;
    }
    
    @Column(name="CORR_DEPT_CODE", length=10)

    public String getCorrDeptCode() {
        return this.corrDeptCode;
    }
    
    public void setCorrDeptCode(String corrDeptCode) {
        this.corrDeptCode = corrDeptCode;
    }
    
    @Column(name="DRA_VISA_ARTIFICIAL", length=1)

    public String getDraVisaArtificial() {
        return this.draVisaArtificial;
    }
    
    public void setDraVisaArtificial(String draVisaArtificial) {
        this.draVisaArtificial = draVisaArtificial;
    }
    
    @Column(name="SENT_STATUS", length=1)

    public String getSentStatus() {
        return this.sentStatus;
    }
    
    public void setSentStatus(String sentStatus) {
        this.sentStatus = sentStatus;
    }
   








}
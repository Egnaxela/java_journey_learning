package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * SupEntClassify entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SUP_ENT_CLASSIFY")
public class SupEntClassify implements java.io.Serializable {

	// Fields

	private String declRegNo;
	private String entOrgCode;
	private String subCiqOrgCode;
	private String isNeedcertChkability;
	private Date modifTime;
	private String modPersnUsrCode;
	private String abolishFlag;
	private String expEntCategory;
	private String impEntCategory;
	private String trustLevelCode;
	private String magDeptCode;
	private String magDeptName;
	private BigDecimal cycSupNum;
	private BigDecimal disqualInspBatch;
	private BigDecimal supCycleNum;
	private BigDecimal supCycleDays;
	private String chngResn;
	private String falgArchive;
	private Date operTime;
	private BigDecimal supBatchNum;
	private String expEntCategoryNm;
	private String impEntCategoryNm;
	private String dailySupWay;
	private String isOuterUnit;
	private Date archiveTime;

	// Constructors

	/** default constructor */
	public SupEntClassify() {
	}

	/** minimal constructor */
	public SupEntClassify(String declRegNo, String entOrgCode) {
		this.declRegNo = declRegNo;
		this.entOrgCode = entOrgCode;
	}

	/** full constructor */
	public SupEntClassify(String declRegNo, String entOrgCode,
			String subCiqOrgCode, String isNeedcertChkability, Date modifTime,
			String modPersnUsrCode, String abolishFlag, String expEntCategory,
			String impEntCategory, String trustLevelCode, String magDeptCode,
			String magDeptName, BigDecimal cycSupNum,
			BigDecimal disqualInspBatch, BigDecimal supCycleNum,
			BigDecimal supCycleDays, String chngResn, String falgArchive,
			Date operTime, BigDecimal supBatchNum, String expEntCategoryNm,
			String impEntCategoryNm, String dailySupWay, String isOuterUnit,
			Date archiveTime) {
		this.declRegNo = declRegNo;
		this.entOrgCode = entOrgCode;
		this.subCiqOrgCode = subCiqOrgCode;
		this.isNeedcertChkability = isNeedcertChkability;
		this.modifTime = modifTime;
		this.modPersnUsrCode = modPersnUsrCode;
		this.abolishFlag = abolishFlag;
		this.expEntCategory = expEntCategory;
		this.impEntCategory = impEntCategory;
		this.trustLevelCode = trustLevelCode;
		this.magDeptCode = magDeptCode;
		this.magDeptName = magDeptName;
		this.cycSupNum = cycSupNum;
		this.disqualInspBatch = disqualInspBatch;
		this.supCycleNum = supCycleNum;
		this.supCycleDays = supCycleDays;
		this.chngResn = chngResn;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.supBatchNum = supBatchNum;
		this.expEntCategoryNm = expEntCategoryNm;
		this.impEntCategoryNm = impEntCategoryNm;
		this.dailySupWay = dailySupWay;
		this.isOuterUnit = isOuterUnit;
		this.archiveTime = archiveTime;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_REG_NO", unique = true, nullable = false, length = 20)
	public String getDeclRegNo() {
		return this.declRegNo;
	}

	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}

	@Column(name = "ENT_ORG_CODE", nullable = false, length = 10)
	public String getEntOrgCode() {
		return this.entOrgCode;
	}

	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}

	@Column(name = "SUB_CIQ_ORG_CODE", length = 10)
	public String getSubCiqOrgCode() {
		return this.subCiqOrgCode;
	}

	public void setSubCiqOrgCode(String subCiqOrgCode) {
		this.subCiqOrgCode = subCiqOrgCode;
	}

	@Column(name = "IS_NEEDCERT_CHKABILITY", length = 1)
	public String getIsNeedcertChkability() {
		return this.isNeedcertChkability;
	}

	public void setIsNeedcertChkability(String isNeedcertChkability) {
		this.isNeedcertChkability = isNeedcertChkability;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIF_TIME", length = 7)
	public Date getModifTime() {
		return this.modifTime;
	}

	public void setModifTime(Date modifTime) {
		this.modifTime = modifTime;
	}

	@Column(name = "MOD_PERSN_USR_CODE", length = 20)
	public String getModPersnUsrCode() {
		return this.modPersnUsrCode;
	}

	public void setModPersnUsrCode(String modPersnUsrCode) {
		this.modPersnUsrCode = modPersnUsrCode;
	}

	@Column(name = "ABOLISH_FLAG", length = 1)
	public String getAbolishFlag() {
		return this.abolishFlag;
	}

	public void setAbolishFlag(String abolishFlag) {
		this.abolishFlag = abolishFlag;
	}

	@Column(name = "EXP_ENT_CATEGORY", length = 20)
	public String getExpEntCategory() {
		return this.expEntCategory;
	}

	public void setExpEntCategory(String expEntCategory) {
		this.expEntCategory = expEntCategory;
	}

	@Column(name = "IMP_ENT_CATEGORY", length = 20)
	public String getImpEntCategory() {
		return this.impEntCategory;
	}

	public void setImpEntCategory(String impEntCategory) {
		this.impEntCategory = impEntCategory;
	}

	@Column(name = "TRUST_LEVEL_CODE", length = 20)
	public String getTrustLevelCode() {
		return this.trustLevelCode;
	}

	public void setTrustLevelCode(String trustLevelCode) {
		this.trustLevelCode = trustLevelCode;
	}

	@Column(name = "MAG_DEPT_CODE", length = 20)
	public String getMagDeptCode() {
		return this.magDeptCode;
	}

	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}

	@Column(name = "MAG_DEPT_NAME", length = 50)
	public String getMagDeptName() {
		return this.magDeptName;
	}

	public void setMagDeptName(String magDeptName) {
		this.magDeptName = magDeptName;
	}

	@Column(name = "CYC_SUP_NUM", precision = 22, scale = 0)
	public BigDecimal getCycSupNum() {
		return this.cycSupNum;
	}

	public void setCycSupNum(BigDecimal cycSupNum) {
		this.cycSupNum = cycSupNum;
	}

	@Column(name = "DISQUAL_INSP_BATCH", precision = 22, scale = 0)
	public BigDecimal getDisqualInspBatch() {
		return this.disqualInspBatch;
	}

	public void setDisqualInspBatch(BigDecimal disqualInspBatch) {
		this.disqualInspBatch = disqualInspBatch;
	}

	@Column(name = "SUP_CYCLE_NUM", precision = 22, scale = 0)
	public BigDecimal getSupCycleNum() {
		return this.supCycleNum;
	}

	public void setSupCycleNum(BigDecimal supCycleNum) {
		this.supCycleNum = supCycleNum;
	}

	@Column(name = "SUP_CYCLE_DAYS", precision = 22, scale = 0)
	public BigDecimal getSupCycleDays() {
		return this.supCycleDays;
	}

	public void setSupCycleDays(BigDecimal supCycleDays) {
		this.supCycleDays = supCycleDays;
	}

	@Column(name = "CHNG_RESN", length = 200)
	public String getChngResn() {
		return this.chngResn;
	}

	public void setChngResn(String chngResn) {
		this.chngResn = chngResn;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_TIME", length = 7)
	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	@Column(name = "SUP_BATCH_NUM", precision = 22, scale = 0)
	public BigDecimal getSupBatchNum() {
		return this.supBatchNum;
	}

	public void setSupBatchNum(BigDecimal supBatchNum) {
		this.supBatchNum = supBatchNum;
	}

	@Column(name = "EXP_ENT_CATEGORY_NM", length = 50)
	public String getExpEntCategoryNm() {
		return this.expEntCategoryNm;
	}

	public void setExpEntCategoryNm(String expEntCategoryNm) {
		this.expEntCategoryNm = expEntCategoryNm;
	}

	@Column(name = "IMP_ENT_CATEGORY_NM", length = 50)
	public String getImpEntCategoryNm() {
		return this.impEntCategoryNm;
	}

	public void setImpEntCategoryNm(String impEntCategoryNm) {
		this.impEntCategoryNm = impEntCategoryNm;
	}

	@Column(name = "DAILY_SUP_WAY", length = 100)
	public String getDailySupWay() {
		return this.dailySupWay;
	}

	public void setDailySupWay(String dailySupWay) {
		this.dailySupWay = dailySupWay;
	}

	@Column(name = "IS_OUTER_UNIT", length = 1)
	public String getIsOuterUnit() {
		return this.isOuterUnit;
	}

	public void setIsOuterUnit(String isOuterUnit) {
		this.isOuterUnit = isOuterUnit;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ARCHIVE_TIME", length = 7)
	public Date getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

}
package com.rongji.eciq.mobile.entity;
// default package

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysAnnInfoMainEntity entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_ANN_INFO_MAIN")

public class SysAnnInfoMainEntity  implements java.io.Serializable {


    // Fields    

     private String annInfoMainId;
     private String serialNumber;
     private String annTitle;
     private String annContent;
     private Date annIssDate;
     private Date annValidPd;
     private Date cancelDate;
     private String annIssuerCode;
     private String annDeptCode;
     private String isueOrgCode;
     private String operCode;
     private String operDeptCode;
     private String operOrgCode;
     private Date operTime;
     private String falgArchive;
     private String isTop;


    // Constructors

    /** default constructor */
    public SysAnnInfoMainEntity() {
    }

	/** minimal constructor */
    public SysAnnInfoMainEntity(String annInfoMainId) {
        this.annInfoMainId = annInfoMainId;
    }
    
    /** full constructor */
    public SysAnnInfoMainEntity(String annInfoMainId, String serialNumber, String annTitle, String annContent, Date annIssDate, Date annValidPd, Date cancelDate, String annIssuerCode, String annDeptCode, String isueOrgCode, String operCode, String operDeptCode, String operOrgCode, Date operTime, String falgArchive, String isTop) {
        this.annInfoMainId = annInfoMainId;
        this.serialNumber = serialNumber;
        this.annTitle = annTitle;
        this.annContent = annContent;
        this.annIssDate = annIssDate;
        this.annValidPd = annValidPd;
        this.cancelDate = cancelDate;
        this.annIssuerCode = annIssuerCode;
        this.annDeptCode = annDeptCode;
        this.isueOrgCode = isueOrgCode;
        this.operCode = operCode;
        this.operDeptCode = operDeptCode;
        this.operOrgCode = operOrgCode;
        this.operTime = operTime;
        this.falgArchive = falgArchive;
        this.isTop = isTop;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="ANN_INFO_MAIN_ID", unique=true, nullable=false, length=32)

    public String getAnnInfoMainId() {
        return this.annInfoMainId;
    }
    
    public void setAnnInfoMainId(String annInfoMainId) {
        this.annInfoMainId = annInfoMainId;
    }
    
    @Column(name="SERIAL_NUMBER", length=20)

    public String getSerialNumber() {
        return this.serialNumber;
    }
    
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    
    @Column(name="ANN_TITLE", length=200)

    public String getAnnTitle() {
        return this.annTitle;
    }
    
    public void setAnnTitle(String annTitle) {
        this.annTitle = annTitle;
    }
    
    @Column(name="ANN_CONTENT", length=4000)

    public String getAnnContent() {
        return this.annContent;
    }
    
    public void setAnnContent(String annContent) {
        this.annContent = annContent;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ANN_ISS_DATE", length=7)

    public Date getAnnIssDate() {
        return this.annIssDate;
    }
    
    public void setAnnIssDate(Date annIssDate) {
        this.annIssDate = annIssDate;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="ANN_VALID_PD", length=7)

    public Date getAnnValidPd() {
        return this.annValidPd;
    }
    
    public void setAnnValidPd(Date annValidPd) {
        this.annValidPd = annValidPd;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="CANCEL_DATE", length=7)

    public Date getCancelDate() {
        return this.cancelDate;
    }
    
    public void setCancelDate(Date cancelDate) {
        this.cancelDate = cancelDate;
    }
    
    @Column(name="ANN_ISSUER_CODE", length=20)

    public String getAnnIssuerCode() {
        return this.annIssuerCode;
    }
    
    public void setAnnIssuerCode(String annIssuerCode) {
        this.annIssuerCode = annIssuerCode;
    }
    
    @Column(name="ANN_DEPT_CODE", length=10)

    public String getAnnDeptCode() {
        return this.annDeptCode;
    }
    
    public void setAnnDeptCode(String annDeptCode) {
        this.annDeptCode = annDeptCode;
    }
    
    @Column(name="ISUE_ORG_CODE", length=10)

    public String getIsueOrgCode() {
        return this.isueOrgCode;
    }
    
    public void setIsueOrgCode(String isueOrgCode) {
        this.isueOrgCode = isueOrgCode;
    }
    
    @Column(name="OPER_CODE", length=20)

    public String getOperCode() {
        return this.operCode;
    }
    
    public void setOperCode(String operCode) {
        this.operCode = operCode;
    }
    
    @Column(name="OPER_DEPT_CODE", length=10)

    public String getOperDeptCode() {
        return this.operDeptCode;
    }
    
    public void setOperDeptCode(String operDeptCode) {
        this.operDeptCode = operDeptCode;
    }
    
    @Column(name="OPER_ORG_CODE", length=10)

    public String getOperOrgCode() {
        return this.operOrgCode;
    }
    
    public void setOperOrgCode(String operOrgCode) {
        this.operOrgCode = operOrgCode;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPER_TIME", length=7)

    public Date getOperTime() {
        return this.operTime;
    }
    
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    
    @Column(name="FALG_ARCHIVE", length=1)

    public String getFalgArchive() {
        return this.falgArchive;
    }
    
    public void setFalgArchive(String falgArchive) {
        this.falgArchive = falgArchive;
    }
    
    @Column(name="IS_TOP", length=1)

    public String getIsTop() {
        return this.isTop;
    }
    
    public void setIsTop(String isTop) {
        this.isTop = isTop;
    }
   








}
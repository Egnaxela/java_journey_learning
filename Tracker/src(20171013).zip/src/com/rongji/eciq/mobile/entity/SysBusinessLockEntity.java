package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SYS_BUSINESS_LOCK")
public class SysBusinessLockEntity implements java.io.Serializable{

	// Fields

	private String oid;
	private String keyId;
	private String userId;
	private String sessionId;
	private String type;
	private Date insertTime;
	private String buttonName;
	private String valid;
	private String status;
	private String orgCode;

	// Constructors

	/** default constructor */
	public SysBusinessLockEntity() {
	}

	/** minimal constructor */
	public SysBusinessLockEntity(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public SysBusinessLockEntity(String oid, String keyId, String userId,
			String sessionId, String type, Date insertTime, String buttonName,
			String valid, String status, String orgCode) {
		this.oid = oid;
		this.keyId = keyId;
		this.userId = userId;
		this.sessionId = sessionId;
		this.type = type;
		this.insertTime = insertTime;
		this.buttonName = buttonName;
		this.valid = valid;
		this.status = status;
		this.orgCode = orgCode;
	}

	// Property accessors
	@Id
	@Column(name = "OID", nullable = false, length = 32)
	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	@Column(name = "KEY_ID", length = 32)
	public String getKeyId() {
		return this.keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	@Column(name = "USER_ID", length = 32)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "SESSION_ID", length = 32)
	public String getSessionId() {
		return this.sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	@Column(name = "TYPE", length = 10)
	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "INSERT_TIME", length = 7)
	public Date getInsertTime() {
		return this.insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	@Column(name = "BUTTON_NAME", length = 100)
	public String getButtonName() {
		return this.buttonName;
	}

	public void setButtonName(String buttonName) {
		this.buttonName = buttonName;
	}

	@Column(name = "VALID", length = 1)
	public String getValid() {
		return this.valid;
	}

	public void setValid(String valid) {
		this.valid = valid;
	}

	@Column(name = "STATUS", length = 10)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}


}

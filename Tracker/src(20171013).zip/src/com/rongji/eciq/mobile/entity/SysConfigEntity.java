package com.rongji.eciq.mobile.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * SysConfigEntity entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_CONFIG")
public class SysConfigEntity implements java.io.Serializable {

	private static final long serialVersionUID = 7671838886542916175L;
	private SysConfigId id;
	private String description;
	private String configValue;
	private Double valid;
	private String configFlag;

	// Constructors

	/** default constructor */
	public SysConfigEntity() {
	}

	/** minimal constructor */
	public SysConfigEntity(SysConfigId id) {
		this.id = id;
	}

	/** full constructor */
	public SysConfigEntity(SysConfigId id, String description, String configValue,
			Double valid, String configFlag) {
		this.id = id;
		this.description = description;
		this.configValue = configValue;
		this.valid = valid;
		this.configFlag = configFlag;
	}

	// Property accessors
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "configCode", column = @Column(name = "CONFIG_CODE", nullable = false, length = 100)),
			@AttributeOverride(name = "companyCode", column = @Column(name = "COMPANY_CODE", nullable = false, length = 10)) })
	public SysConfigId getId() {
		return this.id;
	}

	public void setId(SysConfigId id) {
		this.id = id;
	}

	@Column(name = "DESCRIPTION", length = 1000)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "CONFIG_VALUE", length = 512)
	public String getConfigValue() {
		return this.configValue;
	}

	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	@Column(name = "VALID", precision = 0)
	public Double getValid() {
		return this.valid;
	}

	public void setValid(Double valid) {
		this.valid = valid;
	}

	@Column(name = "CONFIG_FLAG", length = 10)
	public String getConfigFlag() {
		return this.configFlag;
	}

	public void setConfigFlag(String configFlag) {
		this.configFlag = configFlag;
	}

}
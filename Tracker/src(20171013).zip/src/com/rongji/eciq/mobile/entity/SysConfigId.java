package com.rongji.eciq.mobile.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * SysConfigId entity. @author MyEclipse Persistence Tools
 */
@Embeddable
public class SysConfigId implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -4576288509061822605L;
	private String configCode;
	private String companyCode;

	// Constructors

	/** default constructor */
	public SysConfigId() {
	}

	/** full constructor */
	public SysConfigId(String configCode, String companyCode) {
		this.configCode = configCode;
		this.companyCode = companyCode;
	}

	// Property accessors

	@Column(name = "CONFIG_CODE", nullable = false, length = 100)
	public String getConfigCode() {
		return this.configCode;
	}

	public void setConfigCode(String configCode) {
		this.configCode = configCode;
	}

	@Column(name = "COMPANY_CODE", nullable = false, length = 10)
	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof SysConfigId))
			return false;
		SysConfigId castOther = (SysConfigId) other;

		return ((this.getConfigCode() == castOther.getConfigCode()) || (this
				.getConfigCode() != null
				&& castOther.getConfigCode() != null && this.getConfigCode()
				.equals(castOther.getConfigCode())))
				&& ((this.getCompanyCode() == castOther.getCompanyCode()) || (this
						.getCompanyCode() != null
						&& castOther.getCompanyCode() != null && this
						.getCompanyCode().equals(castOther.getCompanyCode())));
	}

	public int hashCode() {
		int result = 17;

		result = 37
				* result
				+ (getConfigCode() == null ? 0 : this.getConfigCode()
						.hashCode());
		result = 37
				* result
				+ (getCompanyCode() == null ? 0 : this.getCompanyCode()
						.hashCode());
		return result;
	}

}
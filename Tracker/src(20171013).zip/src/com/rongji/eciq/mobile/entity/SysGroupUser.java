package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysGroupUser entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_GROUP_USER")
public class SysGroupUser  implements java.io.Serializable {


    // Fields    

     private String sysGroupUserId;
     private String groupCode;
     private String userCode;
     private String grantor;
     private Date grantTime;


    // Constructors

    /** default constructor */
    public SysGroupUser() {
    }

    /** full constructor */
    public SysGroupUser(String sysGroupUserId, String grantor, Date grantTime) {
        this.sysGroupUserId = sysGroupUserId;
        this.grantor = grantor;
        this.grantTime = grantTime;
    }

   
    // Property accessors
   
    @Id
    @Column(name="SYS_GROUP_USER_ID", nullable=false, length=32)

    public String getSysGroupUserId() {
        return this.sysGroupUserId;
    }
    
    public void setSysGroupUserId(String sysGroupUserId) {
        this.sysGroupUserId = sysGroupUserId;
    }
    
    @Column(name="GROUP_CODE", nullable=false, length=64)

    public String getGroupCode() {
        return this.groupCode;
    }
    
    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    @Column(name="USER_CODE", nullable=false, length=64)

    public String getUserCode() {
        return this.userCode;
    }
    
    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }
    
    @Column(name="GRANTOR", length=20)

    public String getGrantor() {
        return this.grantor;
    }
    
    public void setGrantor(String grantor) {
        this.grantor = grantor;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="GRANT_TIME", length=7)

    public Date getGrantTime() {
        return this.grantTime;
    }
    
    public void setGrantTime(Date grantTime) {
        this.grantTime = grantTime;
    }

}
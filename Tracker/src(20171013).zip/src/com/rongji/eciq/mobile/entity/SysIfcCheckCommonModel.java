/**  
 * FileName:     SysIfcCheckCommonModel.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-12 下午2:50:13  
 *  
 */  

package com.rongji.eciq.mobile.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**  
 * Description: 查验场信息维护  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-12 下午2:50:13  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-12      夏晨琳                      1.0         1.0 Version  
 */
@Entity
public class SysIfcCheckCommonModel implements Serializable{
	@Id
    @Column(name = "CHECK_FIELD_NO", nullable = false)
    private String checkFieldNo;
    @Column(name = "CHECK_ORG")
    private String checkOrg;
    @Column(name = "CHECK_NAME")
    private String checkName;
    @Column(name = "CHECK_FIELD_NAME")
    private String checkFieldName;
    @Column(name = "PAGE_CHECK_RATIO")
    private Double pageCheckRatio;
   // @Column(name = "OWNER_PORT")
   // private String ownerPort;
    @Column(name = "PORT_CODE")
    private String portCode;
    @Column(name = "PORT_NAME")
    private String portName;
	public String getCheckFieldNo() {
		return checkFieldNo;
	}
	public void setCheckFieldNo(String checkFieldNo) {
		this.checkFieldNo = checkFieldNo;
	}
	public String getCheckOrg() {
		return checkOrg;
	}
	public void setCheckOrg(String checkOrg) {
		this.checkOrg = checkOrg;
	}
	public String getCheckName() {
		return checkName;
	}
	public void setCheckName(String checkName) {
		this.checkName = checkName;
	}
	public String getCheckFieldName() {
		return checkFieldName;
	}
	public void setCheckFieldName(String checkFieldName) {
		this.checkFieldName = checkFieldName;
	}
	public Double getPageCheckRatio() {
		return pageCheckRatio;
	}
	public void setPageCheckRatio(Double pageCheckRatio) {
		this.pageCheckRatio = pageCheckRatio;
	}
	
	public String getPortCode() {
		return portCode;
	}
	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}
	public String getPortName() {
		return portName;
	}
	public void setPortName(String portName) {
		this.portName = portName;
	}
	
}

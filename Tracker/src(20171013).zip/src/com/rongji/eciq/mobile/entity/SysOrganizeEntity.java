package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SYS_ORGANIZE")
public class SysOrganizeEntity implements java.io.Serializable{

	private static final long serialVersionUID = 3161211251960071598L;
	
	private String orgCode;
	private String orgType;
	private String orgAttr;
	private String orgNameSc;
	private String orgNameFc;
	private String orgNameE;
	private String address;
	private String zip;
	private String contact;
	private String contactPhone;
	private String fax;
	private String bankName;
	private String bankAccount;
	private Timestamp createDate;
	private String state;
	private String note;
	private String creator;
	private Timestamp updateDate;
	private String categoryCode;
	private String categoryName;
	private String seniorCategoryCode;
	private String seniorOrgCode;
	private String isDelete;
	private String orgCodePath;
	private String ciq2000DeptCode;

	// Constructors

	/** default constructor */
	public SysOrganizeEntity() {
	}

	/** minimal constructor */
	public SysOrganizeEntity(String orgCode) {
		this.orgCode = orgCode;
	}

	/** full constructor */
	public SysOrganizeEntity(String orgCode, String orgType, String orgAttr,
			String orgNameSc, String orgNameFc, String orgNameE,
			String address, String zip, String contact, String contactPhone,
			String fax, String bankName, String bankAccount,
			Timestamp createDate, String state, String note, String creator,
			Timestamp updateDate, String categoryCode, String categoryName,
			String seniorCategoryCode, String seniorOrgCode, String isDelete,
			String orgCodePath, String ciq2000DeptCode) {
		this.orgCode = orgCode;
		this.orgType = orgType;
		this.orgAttr = orgAttr;
		this.orgNameSc = orgNameSc;
		this.orgNameFc = orgNameFc;
		this.orgNameE = orgNameE;
		this.address = address;
		this.zip = zip;
		this.contact = contact;
		this.contactPhone = contactPhone;
		this.fax = fax;
		this.bankName = bankName;
		this.bankAccount = bankAccount;
		this.createDate = createDate;
		this.state = state;
		this.note = note;
		this.creator = creator;
		this.updateDate = updateDate;
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
		this.seniorCategoryCode = seniorCategoryCode;
		this.seniorOrgCode = seniorOrgCode;
		this.isDelete = isDelete;
		this.orgCodePath = orgCodePath;
		this.ciq2000DeptCode = ciq2000DeptCode;
	}

	// Property accessors
	@Id
	@Column(name = "ORG_CODE", unique = true, nullable = false, length = 20)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "ORG_TYPE", length = 1)
	public String getOrgType() {
		return this.orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	@Column(name = "ORG_ATTR", length = 32)
	public String getOrgAttr() {
		return this.orgAttr;
	}

	public void setOrgAttr(String orgAttr) {
		this.orgAttr = orgAttr;
	}

	@Column(name = "ORG_NAME_SC", length = 200)
	public String getOrgNameSc() {
		return this.orgNameSc;
	}

	public void setOrgNameSc(String orgNameSc) {
		this.orgNameSc = orgNameSc;
	}

	@Column(name = "ORG_NAME_FC", length = 1000)
	public String getOrgNameFc() {
		return this.orgNameFc;
	}

	public void setOrgNameFc(String orgNameFc) {
		this.orgNameFc = orgNameFc;
	}

	@Column(name = "ORG_NAME_E", length = 200)
	public String getOrgNameE() {
		return this.orgNameE;
	}

	public void setOrgNameE(String orgNameE) {
		this.orgNameE = orgNameE;
	}

	@Column(name = "ADDRESS", length = 100)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "ZIP", length = 6)
	public String getZip() {
		return this.zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Column(name = "CONTACT", length = 20)
	public String getContact() {
		return this.contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Column(name = "CONTACT_PHONE", length = 20)
	public String getContactPhone() {
		return this.contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	@Column(name = "FAX", length = 20)
	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "BANK_NAME", length = 50)
	public String getBankName() {
		return this.bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Column(name = "BANK_ACCOUNT", length = 50)
	public String getBankAccount() {
		return this.bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	@Column(name = "CREATE_DATE", length = 7)
	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	@Column(name = "STATE", length = 1)
	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "NOTE", length = 1000)
	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Column(name = "CREATOR", length = 20)
	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	@Column(name = "UPDATE_DATE", length = 7)
	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	@Column(name = "CATEGORY_CODE", length = 20)
	public String getCategoryCode() {
		return this.categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	@Column(name = "CATEGORY_NAME", length = 200)
	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	@Column(name = "SENIOR_CATEGORY_CODE", length = 20)
	public String getSeniorCategoryCode() {
		return this.seniorCategoryCode;
	}

	public void setSeniorCategoryCode(String seniorCategoryCode) {
		this.seniorCategoryCode = seniorCategoryCode;
	}

	@Column(name = "SENIOR_ORG_CODE", length = 20)
	public String getSeniorOrgCode() {
		return this.seniorOrgCode;
	}

	public void setSeniorOrgCode(String seniorOrgCode) {
		this.seniorOrgCode = seniorOrgCode;
	}

	@Column(name = "IS_DELETE", length = 1)
	public String getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}

	@Column(name = "ORG_CODE_PATH", length = 2000)
	public String getOrgCodePath() {
		return this.orgCodePath;
	}

	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}

	@Column(name = "CIQ2000_DEPT_CODE", length = 10)
	public String getCiq2000DeptCode() {
		return this.ciq2000DeptCode;
	}

	public void setCiq2000DeptCode(String ciq2000DeptCode) {
		this.ciq2000DeptCode = ciq2000DeptCode;
	}
}

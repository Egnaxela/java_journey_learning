package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysPrivilege entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_PRIVILEGE")
public class SysPrivilege  implements java.io.Serializable {


    // Fields    

     private String privilegeCode;
     private String navigateVisible;
     private String description;
     private String parentCode;
     private String privilegeName;
     private String mapping;
     private Long seq;
     private String icon;
     private String enabled;
     private String defaultOpen;
     private String shortcuts;
     private String auth;
     private String operatingPersonnel;
     private Date operatingDate;
     private String operatingMethod;


    // Constructors

    /** default constructor */
    public SysPrivilege() {
    }

	/** minimal constructor */
    public SysPrivilege(String privilegeCode) {
        this.privilegeCode = privilegeCode;
    }
    
    /** full constructor */
    public SysPrivilege(String privilegeCode, String navigateVisible, String description, String parentCode, String privilegeName, String mapping, Long seq, String icon, String enabled, String defaultOpen, String shortcuts, String auth, String operatingPersonnel, Date operatingDate, String operatingMethod) {
        this.privilegeCode = privilegeCode;
        this.navigateVisible = navigateVisible;
        this.description = description;
        this.parentCode = parentCode;
        this.privilegeName = privilegeName;
        this.mapping = mapping;
        this.seq = seq;
        this.icon = icon;
        this.enabled = enabled;
        this.defaultOpen = defaultOpen;
        this.shortcuts = shortcuts;
        this.auth = auth;
        this.operatingPersonnel = operatingPersonnel;
        this.operatingDate = operatingDate;
        this.operatingMethod = operatingMethod;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="PRIVILEGE_CODE", unique=true, nullable=false, length=64)

    public String getPrivilegeCode() {
        return this.privilegeCode;
    }
    
    public void setPrivilegeCode(String privilegeCode) {
        this.privilegeCode = privilegeCode;
    }
    
    @Column(name="NAVIGATE_VISIBLE", precision=1, scale=0)

    public String getNavigateVisible() {
        return this.navigateVisible;
    }
    
    public void setNavigateVisible(String navigateVisible) {
        this.navigateVisible = navigateVisible;
    }
    
    @Column(name="DESCRIPTION", length=512)

    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    @Column(name="PARENT_CODE", length=64)

    public String getParentCode() {
        return this.parentCode;
    }
    
    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }
    
    @Column(name="PRIVILEGE_NAME", length=512)

    public String getPrivilegeName() {
        return this.privilegeName;
    }
    
    public void setPrivilegeName(String privilegeName) {
        this.privilegeName = privilegeName;
    }
    
    @Column(name="MAPPING", length=512)

    public String getMapping() {
        return this.mapping;
    }
    
    public void setMapping(String mapping) {
        this.mapping = mapping;
    }
    
    @Column(name="SEQ", precision=10, scale=0)

    public Long getSeq() {
        return this.seq;
    }
    
    public void setSeq(Long seq) {
        this.seq = seq;
    }
    
    @Column(name="ICON", length=512)

    public String getIcon() {
        return this.icon;
    }
    
    public void setIcon(String icon) {
        this.icon = icon;
    }
    
    @Column(name="ENABLED", precision=1, scale=0)

    public String getEnabled() {
        return this.enabled;
    }
    
    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
    
    @Column(name="DEFAULT_OPEN", precision=1, scale=0)

    public String getDefaultOpen() {
        return this.defaultOpen;
    }
    
    public void setDefaultOpen(String defaultOpen) {
        this.defaultOpen = defaultOpen;
    }
    
    @Column(name="SHORTCUTS", precision=1, scale=0)

    public String getShortcuts() {
        return this.shortcuts;
    }
    
    public void setShortcuts(String shortcuts) {
        this.shortcuts = shortcuts;
    }
    
    @Column(name="AUTH", length=1)

    public String getAuth() {
        return this.auth;
    }
    
    public void setAuth(String auth) {
        this.auth = auth;
    }
    
    @Column(name="OPERATING_PERSONNEL", length=32)

    public String getOperatingPersonnel() {
        return this.operatingPersonnel;
    }
    
    public void setOperatingPersonnel(String operatingPersonnel) {
        this.operatingPersonnel = operatingPersonnel;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="OPERATING_DATE", length=7)

    public Date getOperatingDate() {
        return this.operatingDate;
    }
    
    public void setOperatingDate(Date operatingDate) {
        this.operatingDate = operatingDate;
    }
    
    @Column(name="OPERATING_METHOD", length=20)

    public String getOperatingMethod() {
        return this.operatingMethod;
    }
    
    public void setOperatingMethod(String operatingMethod) {
        this.operatingMethod = operatingMethod;
    }
   








}
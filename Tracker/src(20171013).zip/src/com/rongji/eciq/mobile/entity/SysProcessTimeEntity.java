package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="SYS_PROCESS_TIME")
public class SysProcessTimeEntity implements java.io.Serializable {

	// Fields

	private String declNo;
	private String declType;
	private String orgCode;
	private Date selfDeclDate;
	private Date autoDeclDate;
	private Date selfCheckDate;
	private Date declDate;
	private Date submenuDate;
	private Date insDate;
	private Date spotDate;
	private Date sendDate;
	private Date evaluateDate;
	private Date unqulifiedDate;
	private Date qulifiedDate;
	private Date draftDate;
	private Date attestationDate;
	private Date acquirDate;
	private Date recheckDate;
	private Date makeDate;
	private Date verifyDate;
	private Date signDate;
	private Date docDate;
	private Date cancelDocDate;
	private Date custClearanceDate;
	private Date passDate;
	private Date chargDate;
	private String remark;
	private Date operDate;
	private String falgArchive;
	private Date declAcceptDate;

	// Constructors

	/** default constructor */
	public SysProcessTimeEntity() {
	}

	/** minimal constructor */
	public SysProcessTimeEntity(String declNo) {
		this.declNo = declNo;
	}

	/** full constructor */
	public SysProcessTimeEntity(String declNo, String declType,
			String orgCode, Date selfDeclDate, Date autoDeclDate,
			Date selfCheckDate, Date declDate, Date submenuDate, Date insDate,
			Date spotDate, Date sendDate, Date evaluateDate,
			Date unqulifiedDate, Date qulifiedDate, Date draftDate,
			Date attestationDate, Date acquirDate, Date recheckDate,
			Date makeDate, Date verifyDate, Date signDate, Date docDate,
			Date cancelDocDate, Date custClearanceDate, Date passDate,
			Date chargDate, String remark, Date operDate, String falgArchive,
			Date declAcceptDate) {
		this.declNo = declNo;
		this.declType = declType;
		this.orgCode = orgCode;
		this.selfDeclDate = selfDeclDate;
		this.autoDeclDate = autoDeclDate;
		this.selfCheckDate = selfCheckDate;
		this.declDate = declDate;
		this.submenuDate = submenuDate;
		this.insDate = insDate;
		this.spotDate = spotDate;
		this.sendDate = sendDate;
		this.evaluateDate = evaluateDate;
		this.unqulifiedDate = unqulifiedDate;
		this.qulifiedDate = qulifiedDate;
		this.draftDate = draftDate;
		this.attestationDate = attestationDate;
		this.acquirDate = acquirDate;
		this.recheckDate = recheckDate;
		this.makeDate = makeDate;
		this.verifyDate = verifyDate;
		this.signDate = signDate;
		this.docDate = docDate;
		this.cancelDocDate = cancelDocDate;
		this.custClearanceDate = custClearanceDate;
		this.passDate = passDate;
		this.chargDate = chargDate;
		this.remark = remark;
		this.operDate = operDate;
		this.falgArchive = falgArchive;
		this.declAcceptDate = declAcceptDate;
	}

	// Property accessors
	@Id
	@Column(name = "DECL_NO", nullable = false, length = 32)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "DECL_TYPE", length = 4)
	public String getDeclType() {
		return this.declType;
	}

	public void setDeclType(String declType) {
		this.declType = declType;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SELF_DECL_DATE", length = 7)
	public Date getSelfDeclDate() {
		return this.selfDeclDate;
	}

	public void setSelfDeclDate(Date selfDeclDate) {
		this.selfDeclDate = selfDeclDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "AUTO_DECL_DATE", length = 7)
	public Date getAutoDeclDate() {
		return this.autoDeclDate;
	}

	public void setAutoDeclDate(Date autoDeclDate) {
		this.autoDeclDate = autoDeclDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SELF_CHECK_DATE", length = 7)
	public Date getSelfCheckDate() {
		return this.selfCheckDate;
	}

	public void setSelfCheckDate(Date selfCheckDate) {
		this.selfCheckDate = selfCheckDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DECL_DATE", length = 7)
	public Date getDeclDate() {
		return this.declDate;
	}

	public void setDeclDate(Date declDate) {
		this.declDate = declDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SUBMENU_DATE", length = 7)
	public Date getSubmenuDate() {
		return this.submenuDate;
	}

	public void setSubmenuDate(Date submenuDate) {
		this.submenuDate = submenuDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "INS_DATE", length = 7)
	public Date getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Date insDate) {
		this.insDate = insDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SPOT_DATE", length = 7)
	public Date getSpotDate() {
		return this.spotDate;
	}

	public void setSpotDate(Date spotDate) {
		this.spotDate = spotDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SEND_DATE", length = 7)
	public Date getSendDate() {
		return this.sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "EVALUATE_DATE", length = 7)
	public Date getEvaluateDate() {
		return this.evaluateDate;
	}

	public void setEvaluateDate(Date evaluateDate) {
		this.evaluateDate = evaluateDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "UNQULIFIED_DATE", length = 7)
	public Date getUnqulifiedDate() {
		return this.unqulifiedDate;
	}

	public void setUnqulifiedDate(Date unqulifiedDate) {
		this.unqulifiedDate = unqulifiedDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "QULIFIED_DATE", length = 7)
	public Date getQulifiedDate() {
		return this.qulifiedDate;
	}

	public void setQulifiedDate(Date qulifiedDate) {
		this.qulifiedDate = qulifiedDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DRAFT_DATE", length = 7)
	public Date getDraftDate() {
		return this.draftDate;
	}

	public void setDraftDate(Date draftDate) {
		this.draftDate = draftDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ATTESTATION_DATE", length = 7)
	public Date getAttestationDate() {
		return this.attestationDate;
	}

	public void setAttestationDate(Date attestationDate) {
		this.attestationDate = attestationDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "ACQUIR_DATE", length = 7)
	public Date getAcquirDate() {
		return this.acquirDate;
	}

	public void setAcquirDate(Date acquirDate) {
		this.acquirDate = acquirDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "RECHECK_DATE", length = 7)
	public Date getRecheckDate() {
		return this.recheckDate;
	}

	public void setRecheckDate(Date recheckDate) {
		this.recheckDate = recheckDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MAKE_DATE", length = 7)
	public Date getMakeDate() {
		return this.makeDate;
	}

	public void setMakeDate(Date makeDate) {
		this.makeDate = makeDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "VERIFY_DATE", length = 7)
	public Date getVerifyDate() {
		return this.verifyDate;
	}

	public void setVerifyDate(Date verifyDate) {
		this.verifyDate = verifyDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "SIGN_DATE", length = 7)
	public Date getSignDate() {
		return this.signDate;
	}

	public void setSignDate(Date signDate) {
		this.signDate = signDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DOC_DATE", length = 7)
	public Date getDocDate() {
		return this.docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CANCEL_DOC_DATE", length = 7)
	public Date getCancelDocDate() {
		return this.cancelDocDate;
	}

	public void setCancelDocDate(Date cancelDocDate) {
		this.cancelDocDate = cancelDocDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CUST_CLEARANCE_DATE", length = 7)
	public Date getCustClearanceDate() {
		return this.custClearanceDate;
	}

	public void setCustClearanceDate(Date custClearanceDate) {
		this.custClearanceDate = custClearanceDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "PASS_DATE", length = 7)
	public Date getPassDate() {
		return this.passDate;
	}

	public void setPassDate(Date passDate) {
		this.passDate = passDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CHARG_DATE", length = 7)
	public Date getChargDate() {
		return this.chargDate;
	}

	public void setChargDate(Date chargDate) {
		this.chargDate = chargDate;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_DATE", length = 7)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "DECL_ACCEPT_DATE", length = 7)
	public Date getDeclAcceptDate() {
		return this.declAcceptDate;
	}

	public void setDeclAcceptDate(Date declAcceptDate) {
		this.declAcceptDate = declAcceptDate;
	}

}

package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * SysReleaseRecord entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_RELEASE_RECORD")
public class SysReleaseRecordEntity implements java.io.Serializable {

	private static final long serialVersionUID = -1928447648742609562L;
	private String sysReleaseRecordNo;
	private String declNo;
	private Timestamp recTime;
	private String treatState;
	private Timestamp operDate;
	private String falgArchive;
	private String operState;
	private String declAcceptPerson;
	private String declAcceptDept;

	// Constructors

	/** default constructor */
	public SysReleaseRecordEntity() {
	}

	/** minimal constructor */
	public SysReleaseRecordEntity(String sysReleaseRecordNo) {
		this.sysReleaseRecordNo = sysReleaseRecordNo;
	}

	/** full constructor */
	public SysReleaseRecordEntity(String sysReleaseRecordNo, String declNo,
			Timestamp recTime, String treatState, Timestamp operDate,
			String falgArchive, String operState, String declAcceptPerson,
			String declAcceptDept) {
		this.sysReleaseRecordNo = sysReleaseRecordNo;
		this.declNo = declNo;
		this.recTime = recTime;
		this.treatState = treatState;
		this.operDate = operDate;
		this.falgArchive = falgArchive;
		this.operState = operState;
		this.declAcceptPerson = declAcceptPerson;
		this.declAcceptDept = declAcceptDept;
	}

	// Property accessors
	@Id
	@Column(name = "SYS_RELEASE_RECORD_NO", unique = true, nullable = false, length = 32)
	public String getSysReleaseRecordNo() {
		return this.sysReleaseRecordNo;
	}

	public void setSysReleaseRecordNo(String sysReleaseRecordNo) {
		this.sysReleaseRecordNo = sysReleaseRecordNo;
	}

	@Column(name = "DECL_NO", length = 20)
	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	@Column(name = "REC_TIME", length = 7)
	public Timestamp getRecTime() {
		return this.recTime;
	}

	public void setRecTime(Timestamp recTime) {
		this.recTime = recTime;
	}

	@Column(name = "TREAT_STATE", length = 1)
	public String getTreatState() {
		return this.treatState;
	}

	public void setTreatState(String treatState) {
		this.treatState = treatState;
	}

	@Column(name = "OPER_DATE", length = 7)
	public Timestamp getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Timestamp operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "OPER_STATE", length = 1)
	public String getOperState() {
		return this.operState;
	}

	public void setOperState(String operState) {
		this.operState = operState;
	}

	@Column(name = "DECL_ACCEPT_PERSON", length = 20)
	public String getDeclAcceptPerson() {
		return this.declAcceptPerson;
	}

	public void setDeclAcceptPerson(String declAcceptPerson) {
		this.declAcceptPerson = declAcceptPerson;
	}

	@Column(name = "DECL_ACCEPT_DEPT", length = 10)
	public String getDeclAcceptDept() {
		return this.declAcceptDept;
	}

	public void setDeclAcceptDept(String declAcceptDept) {
		this.declAcceptDept = declAcceptDept;
	}

}
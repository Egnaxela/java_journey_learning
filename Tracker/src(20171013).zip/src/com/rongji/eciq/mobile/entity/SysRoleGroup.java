package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysRoleGroup entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_ROLE_GROUP")
public class SysRoleGroup  implements java.io.Serializable {


    // Fields    

     private String roleGroupCode;
     private String roleGroupName;
     private String orgCode;
     private String enabled;
     private String createUser;
     private Date createTime;
     private String nextOrgChecked;


    // Constructors

    /** default constructor */
    public SysRoleGroup() {
    }

	/** minimal constructor */
    public SysRoleGroup(String roleGroupCode) {
        this.roleGroupCode = roleGroupCode;
    }
    
    /** full constructor */
    public SysRoleGroup(String roleGroupCode, String roleGroupName, String orgCode, String enabled, String createUser, Date createTime, String nextOrgChecked) {
        this.roleGroupCode = roleGroupCode;
        this.roleGroupName = roleGroupName;
        this.orgCode = orgCode;
        this.enabled = enabled;
        this.createUser = createUser;
        this.createTime = createTime;
        this.nextOrgChecked = nextOrgChecked;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="ROLE_GROUP_CODE", unique=true, nullable=false, length=64)

    public String getRoleGroupCode() {
        return this.roleGroupCode;
    }
    
    public void setRoleGroupCode(String roleGroupCode) {
        this.roleGroupCode = roleGroupCode;
    }
    
    @Column(name="ROLE_GROUP_NAME", length=64)

    public String getRoleGroupName() {
        return this.roleGroupName;
    }
    
    public void setRoleGroupName(String roleGroupName) {
        this.roleGroupName = roleGroupName;
    }
    
    @Column(name="ORG_CODE", length=10)

    public String getOrgCode() {
        return this.orgCode;
    }
    
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
    
    @Column(name="ENABLED", length=1)

    public String getEnabled() {
        return this.enabled;
    }
    
    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
    
    @Column(name="CREATE_USER", length=20)

    public String getCreateUser() {
        return this.createUser;
    }
    
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="CREATE_TIME", length=7)

    public Date getCreateTime() {
        return this.createTime;
    }
    
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    @Column(name="NEXT_ORG_CHECKED", length=1)

    public String getNextOrgChecked() {
        return this.nextOrgChecked;
    }
    
    public void setNextOrgChecked(String nextOrgChecked) {
        this.nextOrgChecked = nextOrgChecked;
    }
   








}
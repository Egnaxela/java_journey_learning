package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysRoleGroupDetail entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_ROLE_GROUP_DETAIL")
public class SysRoleGroupDetail  implements java.io.Serializable {


    // Fields    

     private String sysRoleGroupDetailId;
     private String roleGroupCode;
     private String roleCode;
     private String grantor;
     private Date grantTime;


    // Constructors

    /** default constructor */
    public SysRoleGroupDetail() {
    }

	/** minimal constructor */
    public SysRoleGroupDetail(String sysRoleGroupDetailId, String roleGroupCode, String roleCode) {
        this.sysRoleGroupDetailId = sysRoleGroupDetailId;
        this.roleGroupCode = roleGroupCode;
        this.roleCode = roleCode;
    }
    
    /** full constructor */
    public SysRoleGroupDetail(String sysRoleGroupDetailId, String roleGroupCode, String roleCode, String grantor, Date grantTime) {
        this.sysRoleGroupDetailId = sysRoleGroupDetailId;
        this.roleGroupCode = roleGroupCode;
        this.roleCode = roleCode;
        this.grantor = grantor;
        this.grantTime = grantTime;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="SYS_ROLE_GROUP_DETAIL_ID", unique=true, nullable=false, length=32)

    public String getSysRoleGroupDetailId() {
        return this.sysRoleGroupDetailId;
    }
    
    public void setSysRoleGroupDetailId(String sysRoleGroupDetailId) {
        this.sysRoleGroupDetailId = sysRoleGroupDetailId;
    }
    
    @Column(name="ROLE_GROUP_CODE", nullable=false, length=64)

    public String getRoleGroupCode() {
        return this.roleGroupCode;
    }
    
    public void setRoleGroupCode(String roleGroupCode) {
        this.roleGroupCode = roleGroupCode;
    }
    
    @Column(name="ROLE_CODE", nullable=false, length=64)

    public String getRoleCode() {
        return this.roleCode;
    }
    
    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
    
    @Column(name="GRANTOR", length=20)

    public String getGrantor() {
        return this.grantor;
    }
    
    public void setGrantor(String grantor) {
        this.grantor = grantor;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="GRANT_TIME", length=7)

    public Date getGrantTime() {
        return this.grantTime;
    }
    
    public void setGrantTime(Date grantTime) {
        this.grantTime = grantTime;
    }
   








}
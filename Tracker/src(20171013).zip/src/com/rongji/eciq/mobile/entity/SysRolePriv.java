package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysRolePriv entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_ROLE_PRIV")
public class SysRolePriv  implements java.io.Serializable {


    // Fields    

     private String oid;
     private String roleCode;
     private String privilegeCode;
     private String grantor;
     private Date grantTime;


    // Constructors

    /** default constructor */
    public SysRolePriv() {
    }

	/** minimal constructor */
    public SysRolePriv(String oid, String roleCode, String privilegeCode) {
        this.oid = oid;
        this.roleCode = roleCode;
        this.privilegeCode = privilegeCode;
    }
    
    /** full constructor */
    public SysRolePriv(String oid, String roleCode, String privilegeCode, String grantor, Date grantTime) {
        this.oid = oid;
        this.roleCode = roleCode;
        this.privilegeCode = privilegeCode;
        this.grantor = grantor;
        this.grantTime = grantTime;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="OID", unique=true, nullable=false, length=64)

    public String getOid() {
        return this.oid;
    }
    
    public void setOid(String oid) {
        this.oid = oid;
    }
    
    @Column(name="ROLE_CODE", nullable=false, length=64)

    public String getRoleCode() {
        return this.roleCode;
    }
    
    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
    
    @Column(name="PRIVILEGE_CODE", nullable=false, length=64)

    public String getPrivilegeCode() {
        return this.privilegeCode;
    }
    
    public void setPrivilegeCode(String privilegeCode) {
        this.privilegeCode = privilegeCode;
    }
    
    @Column(name="GRANTOR", length=64)

    public String getGrantor() {
        return this.grantor;
    }
    
    public void setGrantor(String grantor) {
        this.grantor = grantor;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="GRANT_TIME", length=7)

    public Date getGrantTime() {
        return this.grantTime;
    }
    
    public void setGrantTime(Date grantTime) {
        this.grantTime = grantTime;
    }
   








}
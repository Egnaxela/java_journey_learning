package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "SYS_SWITCH_ORG")
public class SysSwitchOrg implements java.io.Serializable {

	// Fields

	private String sysSwitchOrgId;
	private String sysSwitchId;
	private String orgCode;
	private String orgName;
	private Date operDate;
	private String falgArchive;
	private String remark;
	private String switchValue;
	private String operCode;
	private String operOrgDept;

	// Constructors

	/** default constructor */
	public SysSwitchOrg() {
	}

	/** minimal constructor */
	public SysSwitchOrg(String sysSwitchOrgId) {
		this.sysSwitchOrgId = sysSwitchOrgId;
	}

	/** full constructor */
	public SysSwitchOrg(String sysSwitchOrgId, String sysSwitchId,
			String orgCode, String orgName, Date operDate, String falgArchive,
			String remark, String switchValue, String operCode,
			String operOrgDept) {
		this.sysSwitchOrgId = sysSwitchOrgId;
		this.sysSwitchId = sysSwitchId;
		this.orgCode = orgCode;
		this.orgName = orgName;
		this.operDate = operDate;
		this.falgArchive = falgArchive;
		this.remark = remark;
		this.switchValue = switchValue;
		this.operCode = operCode;
		this.operOrgDept = operOrgDept;
	}

	// Property accessors
	@Id
	@Column(name = "SYS_SWITCH_ORG_ID", unique = true, nullable = false, length = 32)
	public String getSysSwitchOrgId() {
		return this.sysSwitchOrgId;
	}

	public void setSysSwitchOrgId(String sysSwitchOrgId) {
		this.sysSwitchOrgId = sysSwitchOrgId;
	}

	@Column(name = "SYS_SWITCH_ID", length = 20)
	public String getSysSwitchId() {
		return this.sysSwitchId;
	}

	public void setSysSwitchId(String sysSwitchId) {
		this.sysSwitchId = sysSwitchId;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "ORG_NAME", length = 50)
	public String getOrgName() {
		return this.orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPER_DATE", length = 7)
	public Date getOperDate() {
		return this.operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	@Column(name = "FALG_ARCHIVE", length = 1)
	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	@Column(name = "REMARK", length = 1000)
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "SWITCH_VALUE", length = 1)
	public String getSwitchValue() {
		return this.switchValue;
	}

	public void setSwitchValue(String switchValue) {
		this.switchValue = switchValue;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "OPER_ORG_DEPT", length = 20)
	public String getOperOrgDept() {
		return this.operOrgDept;
	}

	public void setOperOrgDept(String operOrgDept) {
		this.operOrgDept = operOrgDept;
	}

}

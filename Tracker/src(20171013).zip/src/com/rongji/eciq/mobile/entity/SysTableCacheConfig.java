package com.rongji.eciq.mobile.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * SysTableCacheConfig entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_TABLE_CACHE_CONFIG")
public class SysTableCacheConfig implements java.io.Serializable {

	// Fields

	private String tableName;
	private String tableDesc;
	private String version;
	private BigDecimal refreshMode;
	private Date lastUpdateTime;
	private BigDecimal reserveDays;
	private Date createTime;
	private String primaryKeys;
	private String condition;

	// Constructors

	/** default constructor */
	public SysTableCacheConfig() {
	}

	/** minimal constructor */
	public SysTableCacheConfig(String tableName) {
		this.tableName = tableName;
	}

	/** full constructor */
	public SysTableCacheConfig(String tableName, String tableDesc,
			String version, BigDecimal refreshMode, Date lastUpdateTime,
			BigDecimal reserveDays, Date createTime, String primaryKeys,
			String condition) {
		this.tableName = tableName;
		this.tableDesc = tableDesc;
		this.version = version;
		this.refreshMode = refreshMode;
		this.lastUpdateTime = lastUpdateTime;
		this.reserveDays = reserveDays;
		this.createTime = createTime;
		this.primaryKeys = primaryKeys;
		this.condition = condition;
	}

	// Property accessors
	@Id
	@Column(name = "TABLE_NAME", unique = true, nullable = false, length = 64)
	public String getTableName() {
		return this.tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Column(name = "TABLE_DESC", length = 128)
	public String getTableDesc() {
		return this.tableDesc;
	}

	public void setTableDesc(String tableDesc) {
		this.tableDesc = tableDesc;
	}

	@Column(name = "VERSION", length = 32)
	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Column(name = "REFRESH_MODE", precision = 22, scale = 0)
	public BigDecimal getRefreshMode() {
		return this.refreshMode;
	}

	public void setRefreshMode(BigDecimal refreshMode) {
		this.refreshMode = refreshMode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_UPDATE_TIME", length = 7)
	public Date getLastUpdateTime() {
		return this.lastUpdateTime;
	}

	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	@Column(name = "RESERVE_DAYS", precision = 22, scale = 0)
	public BigDecimal getReserveDays() {
		return this.reserveDays;
	}

	public void setReserveDays(BigDecimal reserveDays) {
		this.reserveDays = reserveDays;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_TIME", length = 7)
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "PRIMARY_KEYS", length = 64)
	public String getPrimaryKeys() {
		return this.primaryKeys;
	}

	public void setPrimaryKeys(String primaryKeys) {
		this.primaryKeys = primaryKeys;
	}

	@Column(name = "CONDITION", length = 1000)
	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

}
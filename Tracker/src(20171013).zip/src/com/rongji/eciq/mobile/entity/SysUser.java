package com.rongji.eciq.mobile.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * SysUser entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_USER_A")
public class SysUser implements java.io.Serializable {

	// Fields

	private String userCode;
	private String orgCode;
	private String userName;
	private String idNo;
	private String workerNo;
	private String password;
	private String telephone;
	private String mobile;
	private String email;
	private String title;
	private String profession;
	private String keyId;
	private String onDuty;
	private String enabled;
	private String note;
	private String creator;
	private Date createTime;
	private String userCert;
	private String ciq2000UserCode;

	// Constructors

	/** default constructor */
	public SysUser() {
	}

	/** minimal constructor */
	public SysUser(String userCode, String orgCode, String userName) {
		this.userCode = userCode;
		this.orgCode = orgCode;
		this.userName = userName;
	}

	/** full constructor */
	public SysUser(String userCode, String orgCode, String userName,
			String idNo, String workerNo, String password, String telephone,
			String mobile, String email, String title, String profession,
			String keyId, String onDuty, String enabled, String note,
			String creator, Date createTime, String userCert,
			String ciq2000UserCode) {
		this.userCode = userCode;
		this.orgCode = orgCode;
		this.userName = userName;
		this.idNo = idNo;
		this.workerNo = workerNo;
		this.password = password;
		this.telephone = telephone;
		this.mobile = mobile;
		this.email = email;
		this.title = title;
		this.profession = profession;
		this.keyId = keyId;
		this.onDuty = onDuty;
		this.enabled = enabled;
		this.note = note;
		this.creator = creator;
		this.createTime = createTime;
		this.userCert = userCert;
		this.ciq2000UserCode = ciq2000UserCode;
	}

	// Property accessors
	@Id
	@Column(name = "USER_CODE", unique = true, nullable = false, length = 20)
	public String getUserCode() {
		return this.userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	@Column(name = "ORG_CODE", nullable = false, length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "USER_NAME", nullable = false, length = 50)
	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Column(name = "ID_NO", length = 64)
	public String getIdNo() {
		return this.idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	@Column(name = "WORKER_NO", length = 64)
	public String getWorkerNo() {
		return this.workerNo;
	}

	public void setWorkerNo(String workerNo) {
		this.workerNo = workerNo;
	}

	@Column(name = "PASSWORD", length = 64)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "TELEPHONE", length = 32)
	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	@Column(name = "MOBILE", length = 32)
	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Column(name = "EMAIL", length = 128)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "TITLE", length = 128)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "PROFESSION", length = 128)
	public String getProfession() {
		return this.profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	@Column(name = "KEY_ID", length = 128)
	public String getKeyId() {
		return this.keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	@Column(name = "ON_DUTY", precision = 1, scale = 0)
	public String getOnDuty() {
		return this.onDuty;
	}

	public void setOnDuty(String onDuty) {
		this.onDuty = onDuty;
	}

	@Column(name = "ENABLED", precision = 1, scale = 0)
	public String getEnabled() {
		return this.enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Column(name = "NOTE", length = 512)
	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Column(name = "CREATOR", length = 64)
	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_TIME", length = 7)
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "USER_CERT", length = 2048)
	public String getUserCert() {
		return this.userCert;
	}

	public void setUserCert(String userCert) {
		this.userCert = userCert;
	}

	@Column(name = "CIQ2000_USER_CODE", length = 20)
	public String getCiq2000UserCode() {
		return this.ciq2000UserCode;
	}

	public void setCiq2000UserCode(String ciq2000UserCode) {
		this.ciq2000UserCode = ciq2000UserCode;
	}

}
package com.rongji.eciq.mobile.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * SysUserGroupId entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_USER_GROUP")
public class SysUserGroup implements java.io.Serializable {

	// Fields

	private String groupId;
	private String groupName;
	private String groupUser;
	private String sysUserGroupCode;
	private String sysUserGroupName;
	private String orgCode;
	private String enabled;
	private String createUser;
	private Date createTime;

	// Constructors

	/** default constructor */
	public SysUserGroup() {
	}

	/** minimal constructor */
	public SysUserGroup(String groupId) {
		this.groupId = groupId;
	}

	/** full constructor */
	public SysUserGroup(String groupId, String groupName, String groupUser,
			String sysUserGroupCode, String sysUserGroupName, String orgCode,
			String enabled, String createUser, Date createTime) {
		this.groupId = groupId;
		this.groupName = groupName;
		this.groupUser = groupUser;
		this.sysUserGroupCode = sysUserGroupCode;
		this.sysUserGroupName = sysUserGroupName;
		this.orgCode = orgCode;
		this.enabled = enabled;
		this.createUser = createUser;
		this.createTime = createTime;
	}

	// Property accessors
	@Id
	@Column(name = "GROUP_ID", nullable = false, length = 32)
	public String getGroupId() {
		return this.groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	@Column(name = "GROUP_NAME", length = 20)
	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	@Column(name = "GROUP_USER", length = 20)
	public String getGroupUser() {
		return this.groupUser;
	}

	public void setGroupUser(String groupUser) {
		this.groupUser = groupUser;
	}

	@Column(name = "SYS_USER_GROUP_CODE", length = 64)
	public String getSysUserGroupCode() {
		return this.sysUserGroupCode;
	}

	public void setSysUserGroupCode(String sysUserGroupCode) {
		this.sysUserGroupCode = sysUserGroupCode;
	}

	@Column(name = "SYS_USER_GROUP_NAME", length = 64)
	public String getSysUserGroupName() {
		return this.sysUserGroupName;
	}

	public void setSysUserGroupName(String sysUserGroupName) {
		this.sysUserGroupName = sysUserGroupName;
	}

	@Column(name = "ORG_CODE", length = 10)
	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Column(name = "ENABLED", length = 1)
	public String getEnabled() {
		return this.enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Column(name = "CREATE_USER", length = 20)
	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_TIME", length = 7)
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
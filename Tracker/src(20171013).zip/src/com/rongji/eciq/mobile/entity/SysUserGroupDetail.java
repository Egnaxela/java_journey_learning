package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * SysUserGroupDetail entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SYS_USER_GROUP_DETAIL")
public class SysUserGroupDetail implements java.io.Serializable {

	// Fields

	private String sysUserGroupDetailId;
	private String groupCode;
	private String roleCode;
	private String grantor;
	private Date grantTime;

	// Constructors

	/** default constructor */
	public SysUserGroupDetail() {
	}

	/** minimal constructor */
	public SysUserGroupDetail(String sysUserGroupDetailId) {
		this.sysUserGroupDetailId = sysUserGroupDetailId;
	}

	/** full constructor */
	public SysUserGroupDetail(String sysUserGroupDetailId, String grantor, Date grantTime) {
		this.sysUserGroupDetailId = sysUserGroupDetailId;
		this.grantor = grantor;
		this.grantTime = grantTime;
	}

	// Property accessors

	@Id
	@Column(name = "SYS_USER_GROUP_DETAIL_ID", nullable = false, length = 64)
	public String getSysUserGroupDetailId() {
		return this.sysUserGroupDetailId;
	}

	public void setSysUserGroupDetailId(String sysUserGroupDetailId) {
		this.sysUserGroupDetailId = sysUserGroupDetailId;
	}
	
	@Column(name = "GROUP_CODE", nullable = false, length = 64)
	public String getGroupCode() {
		return this.groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	@Column(name = "ROLE_CODE", nullable = false, length = 64)
	public String getRoleCode() {
		return this.roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	@Column(name = "GRANTOR", length = 20)
	public String getGrantor() {
		return this.grantor;
	}

	public void setGrantor(String grantor) {
		this.grantor = grantor;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "GRANT_TIME", length = 7)
	public Date getGrantTime() {
		return this.grantTime;
	}

	public void setGrantTime(Date grantTime) {
		this.grantTime = grantTime;
	}

}
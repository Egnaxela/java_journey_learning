package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * SysUserRole entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="SYS_USER_ROLE")
public class SysUserRole  implements java.io.Serializable {


    // Fields    

     private String oid;
     private String userCode;
     private String grantor;
     private Date grantTime;
     private String roleGroupCode;
     private String roleCode;


    // Constructors

    /** default constructor */
    public SysUserRole() {
    }

	/** minimal constructor */
    public SysUserRole(String oid, String userCode) {
        this.oid = oid;
        this.userCode = userCode;
    }
    
    /** full constructor */
    public SysUserRole(String oid, String userCode, String grantor, Date grantTime, String roleGroupCode, String roleCode) {
        this.oid = oid;
        this.userCode = userCode;
        this.grantor = grantor;
        this.grantTime = grantTime;
        this.roleGroupCode = roleGroupCode;
        this.roleCode = roleCode;
    }

   
    // Property accessors
    @Id 
    
    @Column(name="OID", unique=true, nullable=false, length=64)

    public String getOid() {
        return this.oid;
    }
    
    public void setOid(String oid) {
        this.oid = oid;
    }
    
    @Column(name="USER_CODE", nullable=false, length=64)

    public String getUserCode() {
        return this.userCode;
    }
    
    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }
    
    @Column(name="GRANTOR", length=64)

    public String getGrantor() {
        return this.grantor;
    }
    
    public void setGrantor(String grantor) {
        this.grantor = grantor;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="GRANT_TIME", length=7)

    public Date getGrantTime() {
        return this.grantTime;
    }
    
    public void setGrantTime(Date grantTime) {
        this.grantTime = grantTime;
    }
    
    @Column(name="ROLE_GROUP_CODE", length=64)

    public String getRoleGroupCode() {
        return this.roleGroupCode;
    }
    
    public void setRoleGroupCode(String roleGroupCode) {
        this.roleGroupCode = roleGroupCode;
    }
    
    @Column(name="ROLE_CODE", length=64)

    public String getRoleCode() {
        return this.roleCode;
    }
    
    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
   








}
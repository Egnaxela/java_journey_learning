package com.rongji.eciq.mobile.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * TraControl entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "TRA_CONTROL")
public class TraControlEntity implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -9179832478630983229L;
	private String controlId;
	private String tranNo;
	private String tranType;
	private String declNoOut;
	private String declNoIn;
	private String trsOutOrgCode;
	private String transOrgCode;
	private String treatState;
	private String outOperCode;
	private String transStatus;
	private Timestamp operTime;
	private String operOrgCode;
	private String operCode;
	private String oldTransCode;
	private String cancleResn;
	private String eciqFlag;
	private Timestamp tranDate;
	private String transPwd;
	private String ciqCertNo;
	private Timestamp archiveTime;
	private String certNo;

	// Constructors

	/** default constructor */
	public TraControlEntity() {
	}

	/** minimal constructor */
	public TraControlEntity(String controlId, String tranNo, String tranType,
			String declNoOut, String trsOutOrgCode, String treatState,
			String outOperCode) {
		this.controlId = controlId;
		this.tranNo = tranNo;
		this.tranType = tranType;
		this.declNoOut = declNoOut;
		this.trsOutOrgCode = trsOutOrgCode;
		this.treatState = treatState;
		this.outOperCode = outOperCode;
	}

	/** full constructor */
	public TraControlEntity(String controlId, String tranNo, String tranType,
			String declNoOut, String declNoIn, String trsOutOrgCode,
			String transOrgCode, String treatState, String outOperCode,
			String transStatus, Timestamp operTime, String operOrgCode,
			String operCode, String oldTransCode, String cancleResn,
			String eciqFlag, Timestamp tranDate, String transPwd,
			String ciqCertNo, Timestamp archiveTime, String certNo) {
		this.controlId = controlId;
		this.tranNo = tranNo;
		this.tranType = tranType;
		this.declNoOut = declNoOut;
		this.declNoIn = declNoIn;
		this.trsOutOrgCode = trsOutOrgCode;
		this.transOrgCode = transOrgCode;
		this.treatState = treatState;
		this.outOperCode = outOperCode;
		this.transStatus = transStatus;
		this.operTime = operTime;
		this.operOrgCode = operOrgCode;
		this.operCode = operCode;
		this.oldTransCode = oldTransCode;
		this.cancleResn = cancleResn;
		this.eciqFlag = eciqFlag;
		this.tranDate = tranDate;
		this.transPwd = transPwd;
		this.ciqCertNo = ciqCertNo;
		this.archiveTime = archiveTime;
		this.certNo = certNo;
	}

	// Property accessors
	@Id
	@Column(name = "CONTROL_ID", unique = true, nullable = false, length = 32)
	public String getControlId() {
		return this.controlId;
	}

	public void setControlId(String controlId) {
		this.controlId = controlId;
	}

	@Column(name = "TRAN_NO", nullable = false, length = 20)
	public String getTranNo() {
		return this.tranNo;
	}

	public void setTranNo(String tranNo) {
		this.tranNo = tranNo;
	}

	@Column(name = "TRAN_TYPE", nullable = false, length = 10)
	public String getTranType() {
		return this.tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	@Column(name = "DECL_NO_OUT", nullable = false, length = 20)
	public String getDeclNoOut() {
		return this.declNoOut;
	}

	public void setDeclNoOut(String declNoOut) {
		this.declNoOut = declNoOut;
	}

	@Column(name = "DECL_NO_IN", length = 20)
	public String getDeclNoIn() {
		return this.declNoIn;
	}

	public void setDeclNoIn(String declNoIn) {
		this.declNoIn = declNoIn;
	}

	@Column(name = "TRS_OUT_ORG_CODE", nullable = false, length = 10)
	public String getTrsOutOrgCode() {
		return this.trsOutOrgCode;
	}

	public void setTrsOutOrgCode(String trsOutOrgCode) {
		this.trsOutOrgCode = trsOutOrgCode;
	}

	@Column(name = "TRANS_ORG_CODE", length = 10)
	public String getTransOrgCode() {
		return this.transOrgCode;
	}

	public void setTransOrgCode(String transOrgCode) {
		this.transOrgCode = transOrgCode;
	}

	@Column(name = "TREAT_STATE", nullable = false, length = 1)
	public String getTreatState() {
		return this.treatState;
	}

	public void setTreatState(String treatState) {
		this.treatState = treatState;
	}

	@Column(name = "OUT_OPER_CODE", nullable = false, length = 20)
	public String getOutOperCode() {
		return this.outOperCode;
	}

	public void setOutOperCode(String outOperCode) {
		this.outOperCode = outOperCode;
	}

	@Column(name = "TRANS_STATUS", length = 1)
	public String getTransStatus() {
		return this.transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	@Column(name = "OPER_TIME", length = 7)
	public Timestamp getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Timestamp operTime) {
		this.operTime = operTime;
	}

	@Column(name = "OPER_ORG_CODE", length = 10)
	public String getOperOrgCode() {
		return this.operOrgCode;
	}

	public void setOperOrgCode(String operOrgCode) {
		this.operOrgCode = operOrgCode;
	}

	@Column(name = "OPER_CODE", length = 20)
	public String getOperCode() {
		return this.operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	@Column(name = "OLD_TRANS_CODE", length = 20)
	public String getOldTransCode() {
		return this.oldTransCode;
	}

	public void setOldTransCode(String oldTransCode) {
		this.oldTransCode = oldTransCode;
	}

	@Column(name = "CANCLE_RESN", length = 200)
	public String getCancleResn() {
		return this.cancleResn;
	}

	public void setCancleResn(String cancleResn) {
		this.cancleResn = cancleResn;
	}

	@Column(name = "ECIQ_FLAG", length = 1)
	public String getEciqFlag() {
		return this.eciqFlag;
	}

	public void setEciqFlag(String eciqFlag) {
		this.eciqFlag = eciqFlag;
	}

	@Column(name = "TRAN_DATE", length = 7)
	public Timestamp getTranDate() {
		return this.tranDate;
	}

	public void setTranDate(Timestamp tranDate) {
		this.tranDate = tranDate;
	}

	@Column(name = "TRANS_PWD", length = 10)
	public String getTransPwd() {
		return this.transPwd;
	}

	public void setTransPwd(String transPwd) {
		this.transPwd = transPwd;
	}

	@Column(name = "CIQ_CERT_NO", length = 20)
	public String getCiqCertNo() {
		return this.ciqCertNo;
	}

	public void setCiqCertNo(String ciqCertNo) {
		this.ciqCertNo = ciqCertNo;
	}

	@Column(name = "ARCHIVE_TIME", length = 7)
	public Timestamp getArchiveTime() {
		return this.archiveTime;
	}

	public void setArchiveTime(Timestamp archiveTime) {
		this.archiveTime = archiveTime;
	}

	@Column(name = "CERT_NO", length = 30)
	public String getCertNo() {
		return this.certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

}
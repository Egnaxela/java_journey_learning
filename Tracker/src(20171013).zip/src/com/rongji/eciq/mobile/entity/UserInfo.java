package com.rongji.eciq.mobile.entity;

public class UserInfo {
	public String userCode;

    public String userName;

    public String companyCode;
    
    public String businessOrgCode;
    

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getBusinessOrgCode() {
		return businessOrgCode;
	}

	public void setBusinessOrgCode(String businessOrgCode) {
		this.businessOrgCode = businessOrgCode;
	}



}

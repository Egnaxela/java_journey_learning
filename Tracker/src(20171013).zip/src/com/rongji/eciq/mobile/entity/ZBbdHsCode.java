package com.rongji.eciq.mobile.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ZBbdHsCode entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "Z_BBD_HS_CODE", schema = "ECIQ_APP")
public class ZBbdHsCode implements java.io.Serializable {

	// Fields

	private String hsCode;
	private String hsCname;
	private String hsEname;
	private String monitorCondition;
	private String dangerFlag;
	private String entryImportanceFlag;
	private String exitImportanceFlag;
	private String entryStapleFlag;
	private String exitStapleFlag;
	private String entryInspFlag;
	private String exitInspFlag;
	private String entryLicenseFlag;
	private String exitLicenseFlag;
	private String rubbishFlagCode;
	private String goodsFlagCode;
	private String civilFlag;
	private String stdMeasureCode;
	private String measureTypeCode;
	private String inspItemCodes;
	private String operatorCode;
	private Date operateDate;
	private String feeItemCodes;
	private String limitCondition;
	private String inspMonitorCond;
	private String goodsFlagCode2;
	private Short validTerm;
	private Short inspTerm;
	private Short inspCyc;
	private String monitorCondNew;
	private String verRcd;
	private String checkFlag;
	private Short certCyc;
	private String autoPassFlag;
	private String wasteOldCode;
	private String importCheckFlag;
	private String packTypeCode;
	private String antiHsCode;
	private String rottable;
	private String model;
	private String wood;
	private String food;
	private String foodFacility;
	private String feeItemCodesNew;
	private String oil;
	private String radio;
	private String dangerNew;
	private String textile;
	private String cancelFlag;
	private String chgFlag;
	private String specificFeeFlag;
	private String otherFlag;
	private String flag;
	private String ciqMeasureType;
	private String ciqStdMeasure;
	private String feeItemCodes2013;
	private String conHsCode;

	// Constructors

	/** default constructor */
	public ZBbdHsCode() {
	}

	/** minimal constructor */
	public ZBbdHsCode(String hsCode) {
		this.hsCode = hsCode;
	}

	/** full constructor */
	public ZBbdHsCode(String hsCode, String hsCname, String hsEname,
			String monitorCondition, String dangerFlag,
			String entryImportanceFlag, String exitImportanceFlag,
			String entryStapleFlag, String exitStapleFlag,
			String entryInspFlag, String exitInspFlag, String entryLicenseFlag,
			String exitLicenseFlag, String rubbishFlagCode,
			String goodsFlagCode, String civilFlag, String stdMeasureCode,
			String measureTypeCode, String inspItemCodes, String operatorCode,
			Date operateDate, String feeItemCodes, String limitCondition,
			String inspMonitorCond, String goodsFlagCode2, Short validTerm,
			Short inspTerm, Short inspCyc, String monitorCondNew,
			String verRcd, String checkFlag, Short certCyc,
			String autoPassFlag, String wasteOldCode, String importCheckFlag,
			String packTypeCode, String antiHsCode, String rottable,
			String model, String wood, String food, String foodFacility,
			String feeItemCodesNew, String oil, String radio, String dangerNew,
			String textile, String cancelFlag, String chgFlag,
			String specificFeeFlag, String otherFlag, String flag,
			String ciqMeasureType, String ciqStdMeasure,
			String feeItemCodes2013, String conHsCode) {
		this.hsCode = hsCode;
		this.hsCname = hsCname;
		this.hsEname = hsEname;
		this.monitorCondition = monitorCondition;
		this.dangerFlag = dangerFlag;
		this.entryImportanceFlag = entryImportanceFlag;
		this.exitImportanceFlag = exitImportanceFlag;
		this.entryStapleFlag = entryStapleFlag;
		this.exitStapleFlag = exitStapleFlag;
		this.entryInspFlag = entryInspFlag;
		this.exitInspFlag = exitInspFlag;
		this.entryLicenseFlag = entryLicenseFlag;
		this.exitLicenseFlag = exitLicenseFlag;
		this.rubbishFlagCode = rubbishFlagCode;
		this.goodsFlagCode = goodsFlagCode;
		this.civilFlag = civilFlag;
		this.stdMeasureCode = stdMeasureCode;
		this.measureTypeCode = measureTypeCode;
		this.inspItemCodes = inspItemCodes;
		this.operatorCode = operatorCode;
		this.operateDate = operateDate;
		this.feeItemCodes = feeItemCodes;
		this.limitCondition = limitCondition;
		this.inspMonitorCond = inspMonitorCond;
		this.goodsFlagCode2 = goodsFlagCode2;
		this.validTerm = validTerm;
		this.inspTerm = inspTerm;
		this.inspCyc = inspCyc;
		this.monitorCondNew = monitorCondNew;
		this.verRcd = verRcd;
		this.checkFlag = checkFlag;
		this.certCyc = certCyc;
		this.autoPassFlag = autoPassFlag;
		this.wasteOldCode = wasteOldCode;
		this.importCheckFlag = importCheckFlag;
		this.packTypeCode = packTypeCode;
		this.antiHsCode = antiHsCode;
		this.rottable = rottable;
		this.model = model;
		this.wood = wood;
		this.food = food;
		this.foodFacility = foodFacility;
		this.feeItemCodesNew = feeItemCodesNew;
		this.oil = oil;
		this.radio = radio;
		this.dangerNew = dangerNew;
		this.textile = textile;
		this.cancelFlag = cancelFlag;
		this.chgFlag = chgFlag;
		this.specificFeeFlag = specificFeeFlag;
		this.otherFlag = otherFlag;
		this.flag = flag;
		this.ciqMeasureType = ciqMeasureType;
		this.ciqStdMeasure = ciqStdMeasure;
		this.feeItemCodes2013 = feeItemCodes2013;
		this.conHsCode = conHsCode;
	}

	// Property accessors
	@Id
	@Column(name = "HS_CODE", unique = true, nullable = false, length = 12)
	public String getHsCode() {
		return this.hsCode;
	}

	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}

	@Column(name = "HS_CNAME", length = 500)
	public String getHsCname() {
		return this.hsCname;
	}

	public void setHsCname(String hsCname) {
		this.hsCname = hsCname;
	}

	@Column(name = "HS_ENAME", length = 50)
	public String getHsEname() {
		return this.hsEname;
	}

	public void setHsEname(String hsEname) {
		this.hsEname = hsEname;
	}

	@Column(name = "MONITOR_CONDITION", length = 20)
	public String getMonitorCondition() {
		return this.monitorCondition;
	}

	public void setMonitorCondition(String monitorCondition) {
		this.monitorCondition = monitorCondition;
	}

	@Column(name = "DANGER_FLAG", length = 1)
	public String getDangerFlag() {
		return this.dangerFlag;
	}

	public void setDangerFlag(String dangerFlag) {
		this.dangerFlag = dangerFlag;
	}

	@Column(name = "ENTRY_IMPORTANCE_FLAG", length = 1)
	public String getEntryImportanceFlag() {
		return this.entryImportanceFlag;
	}

	public void setEntryImportanceFlag(String entryImportanceFlag) {
		this.entryImportanceFlag = entryImportanceFlag;
	}

	@Column(name = "EXIT_IMPORTANCE_FLAG", length = 1)
	public String getExitImportanceFlag() {
		return this.exitImportanceFlag;
	}

	public void setExitImportanceFlag(String exitImportanceFlag) {
		this.exitImportanceFlag = exitImportanceFlag;
	}

	@Column(name = "ENTRY_STAPLE_FLAG", length = 1)
	public String getEntryStapleFlag() {
		return this.entryStapleFlag;
	}

	public void setEntryStapleFlag(String entryStapleFlag) {
		this.entryStapleFlag = entryStapleFlag;
	}

	@Column(name = "EXIT_STAPLE_FLAG", length = 1)
	public String getExitStapleFlag() {
		return this.exitStapleFlag;
	}

	public void setExitStapleFlag(String exitStapleFlag) {
		this.exitStapleFlag = exitStapleFlag;
	}

	@Column(name = "ENTRY_INSP_FLAG", length = 1)
	public String getEntryInspFlag() {
		return this.entryInspFlag;
	}

	public void setEntryInspFlag(String entryInspFlag) {
		this.entryInspFlag = entryInspFlag;
	}

	@Column(name = "EXIT_INSP_FLAG", length = 1)
	public String getExitInspFlag() {
		return this.exitInspFlag;
	}

	public void setExitInspFlag(String exitInspFlag) {
		this.exitInspFlag = exitInspFlag;
	}

	@Column(name = "ENTRY_LICENSE_FLAG", length = 4)
	public String getEntryLicenseFlag() {
		return this.entryLicenseFlag;
	}

	public void setEntryLicenseFlag(String entryLicenseFlag) {
		this.entryLicenseFlag = entryLicenseFlag;
	}

	@Column(name = "EXIT_LICENSE_FLAG", length = 4)
	public String getExitLicenseFlag() {
		return this.exitLicenseFlag;
	}

	public void setExitLicenseFlag(String exitLicenseFlag) {
		this.exitLicenseFlag = exitLicenseFlag;
	}

	@Column(name = "RUBBISH_FLAG_CODE", length = 4)
	public String getRubbishFlagCode() {
		return this.rubbishFlagCode;
	}

	public void setRubbishFlagCode(String rubbishFlagCode) {
		this.rubbishFlagCode = rubbishFlagCode;
	}

	@Column(name = "GOODS_FLAG_CODE", length = 4)
	public String getGoodsFlagCode() {
		return this.goodsFlagCode;
	}

	public void setGoodsFlagCode(String goodsFlagCode) {
		this.goodsFlagCode = goodsFlagCode;
	}

	@Column(name = "CIVIL_FLAG", length = 1)
	public String getCivilFlag() {
		return this.civilFlag;
	}

	public void setCivilFlag(String civilFlag) {
		this.civilFlag = civilFlag;
	}

	@Column(name = "STD_MEASURE_CODE", length = 4)
	public String getStdMeasureCode() {
		return this.stdMeasureCode;
	}

	public void setStdMeasureCode(String stdMeasureCode) {
		this.stdMeasureCode = stdMeasureCode;
	}

	@Column(name = "MEASURE_TYPE_CODE", length = 4)
	public String getMeasureTypeCode() {
		return this.measureTypeCode;
	}

	public void setMeasureTypeCode(String measureTypeCode) {
		this.measureTypeCode = measureTypeCode;
	}

	@Column(name = "INSP_ITEM_CODES", length = 50)
	public String getInspItemCodes() {
		return this.inspItemCodes;
	}

	public void setInspItemCodes(String inspItemCodes) {
		this.inspItemCodes = inspItemCodes;
	}

	@Column(name = "OPERATOR_CODE", length = 20)
	public String getOperatorCode() {
		return this.operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "OPERATE_DATE", length = 7)
	public Date getOperateDate() {
		return this.operateDate;
	}

	public void setOperateDate(Date operateDate) {
		this.operateDate = operateDate;
	}

	@Column(name = "FEE_ITEM_CODES", length = 100)
	public String getFeeItemCodes() {
		return this.feeItemCodes;
	}

	public void setFeeItemCodes(String feeItemCodes) {
		this.feeItemCodes = feeItemCodes;
	}

	@Column(name = "LIMIT_CONDITION", length = 200)
	public String getLimitCondition() {
		return this.limitCondition;
	}

	public void setLimitCondition(String limitCondition) {
		this.limitCondition = limitCondition;
	}

	@Column(name = "INSP_MONITOR_COND", length = 20)
	public String getInspMonitorCond() {
		return this.inspMonitorCond;
	}

	public void setInspMonitorCond(String inspMonitorCond) {
		this.inspMonitorCond = inspMonitorCond;
	}

	@Column(name = "GOODS_FLAG_CODE_2", length = 4)
	public String getGoodsFlagCode2() {
		return this.goodsFlagCode2;
	}

	public void setGoodsFlagCode2(String goodsFlagCode2) {
		this.goodsFlagCode2 = goodsFlagCode2;
	}

	@Column(name = "VALID_TERM", precision = 4, scale = 0)
	public Short getValidTerm() {
		return this.validTerm;
	}

	public void setValidTerm(Short validTerm) {
		this.validTerm = validTerm;
	}

	@Column(name = "INSP_TERM", precision = 4, scale = 0)
	public Short getInspTerm() {
		return this.inspTerm;
	}

	public void setInspTerm(Short inspTerm) {
		this.inspTerm = inspTerm;
	}

	@Column(name = "INSP_CYC", precision = 4, scale = 0)
	public Short getInspCyc() {
		return this.inspCyc;
	}

	public void setInspCyc(Short inspCyc) {
		this.inspCyc = inspCyc;
	}

	@Column(name = "MONITOR_COND_NEW", length = 20)
	public String getMonitorCondNew() {
		return this.monitorCondNew;
	}

	public void setMonitorCondNew(String monitorCondNew) {
		this.monitorCondNew = monitorCondNew;
	}

	@Column(name = "VER_RCD", length = 10)
	public String getVerRcd() {
		return this.verRcd;
	}

	public void setVerRcd(String verRcd) {
		this.verRcd = verRcd;
	}

	@Column(name = "CHECK_FLAG", length = 1)
	public String getCheckFlag() {
		return this.checkFlag;
	}

	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}

	@Column(name = "CERT_CYC", precision = 4, scale = 0)
	public Short getCertCyc() {
		return this.certCyc;
	}

	public void setCertCyc(Short certCyc) {
		this.certCyc = certCyc;
	}

	@Column(name = "AUTO_PASS_FLAG", length = 1)
	public String getAutoPassFlag() {
		return this.autoPassFlag;
	}

	public void setAutoPassFlag(String autoPassFlag) {
		this.autoPassFlag = autoPassFlag;
	}

	@Column(name = "WASTE_OLD_CODE", length = 4)
	public String getWasteOldCode() {
		return this.wasteOldCode;
	}

	public void setWasteOldCode(String wasteOldCode) {
		this.wasteOldCode = wasteOldCode;
	}

	@Column(name = "IMPORT_CHECK_FLAG", length = 1)
	public String getImportCheckFlag() {
		return this.importCheckFlag;
	}

	public void setImportCheckFlag(String importCheckFlag) {
		this.importCheckFlag = importCheckFlag;
	}

	@Column(name = "PACK_TYPE_CODE", length = 4)
	public String getPackTypeCode() {
		return this.packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	@Column(name = "ANTI_HS_CODE", length = 12)
	public String getAntiHsCode() {
		return this.antiHsCode;
	}

	public void setAntiHsCode(String antiHsCode) {
		this.antiHsCode = antiHsCode;
	}

	@Column(name = "ROTTABLE", length = 1)
	public String getRottable() {
		return this.rottable;
	}

	public void setRottable(String rottable) {
		this.rottable = rottable;
	}

	@Column(name = "MODEL", length = 1)
	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	@Column(name = "WOOD", length = 1)
	public String getWood() {
		return this.wood;
	}

	public void setWood(String wood) {
		this.wood = wood;
	}

	@Column(name = "FOOD", length = 1)
	public String getFood() {
		return this.food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	@Column(name = "FOOD_FACILITY", length = 1)
	public String getFoodFacility() {
		return this.foodFacility;
	}

	public void setFoodFacility(String foodFacility) {
		this.foodFacility = foodFacility;
	}

	@Column(name = "FEE_ITEM_CODES_NEW", length = 100)
	public String getFeeItemCodesNew() {
		return this.feeItemCodesNew;
	}

	public void setFeeItemCodesNew(String feeItemCodesNew) {
		this.feeItemCodesNew = feeItemCodesNew;
	}

	@Column(name = "OIL", length = 1)
	public String getOil() {
		return this.oil;
	}

	public void setOil(String oil) {
		this.oil = oil;
	}

	@Column(name = "RADIO", length = 1)
	public String getRadio() {
		return this.radio;
	}

	public void setRadio(String radio) {
		this.radio = radio;
	}

	@Column(name = "DANGER_NEW", length = 1)
	public String getDangerNew() {
		return this.dangerNew;
	}

	public void setDangerNew(String dangerNew) {
		this.dangerNew = dangerNew;
	}

	@Column(name = "TEXTILE", length = 1)
	public String getTextile() {
		return this.textile;
	}

	public void setTextile(String textile) {
		this.textile = textile;
	}

	@Column(name = "CANCEL_FLAG", length = 1)
	public String getCancelFlag() {
		return this.cancelFlag;
	}

	public void setCancelFlag(String cancelFlag) {
		this.cancelFlag = cancelFlag;
	}

	@Column(name = "CHG_FLAG", length = 1)
	public String getChgFlag() {
		return this.chgFlag;
	}

	public void setChgFlag(String chgFlag) {
		this.chgFlag = chgFlag;
	}

	@Column(name = "SPECIFIC_FEE_FLAG", length = 1)
	public String getSpecificFeeFlag() {
		return this.specificFeeFlag;
	}

	public void setSpecificFeeFlag(String specificFeeFlag) {
		this.specificFeeFlag = specificFeeFlag;
	}

	@Column(name = "OTHER_FLAG", length = 1)
	public String getOtherFlag() {
		return this.otherFlag;
	}

	public void setOtherFlag(String otherFlag) {
		this.otherFlag = otherFlag;
	}

	@Column(name = "FLAG", length = 1)
	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Column(name = "CIQ_MEASURE_TYPE", length = 4)
	public String getCiqMeasureType() {
		return this.ciqMeasureType;
	}

	public void setCiqMeasureType(String ciqMeasureType) {
		this.ciqMeasureType = ciqMeasureType;
	}

	@Column(name = "CIQ_STD_MEASURE", length = 4)
	public String getCiqStdMeasure() {
		return this.ciqStdMeasure;
	}

	public void setCiqStdMeasure(String ciqStdMeasure) {
		this.ciqStdMeasure = ciqStdMeasure;
	}

	@Column(name = "FEE_ITEM_CODES_2013", length = 100)
	public String getFeeItemCodes2013() {
		return this.feeItemCodes2013;
	}

	public void setFeeItemCodes2013(String feeItemCodes2013) {
		this.feeItemCodes2013 = feeItemCodes2013;
	}

	@Column(name = "CON_HS_CODE", length = 12)
	public String getConHsCode() {
		return this.conHsCode;
	}

	public void setConHsCode(String conHsCode) {
		this.conHsCode = conHsCode;
	}

}
/**  
 * FileName:  BigDataModel.java   
 * @Description: 现场查验-查看返回大对象 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月10日 下午4:09:28  
 *  
 */  

package com.rongji.eciq.mobile.model.base;

import java.util.ArrayList;

import com.rongji.eciq.mobile.model.insp.scene.InsCheckItemModel;
import com.rongji.eciq.mobile.model.insp.scene.InsResultGoodsModel;

/**  
 * Description: 现场查验-查看返回大对象  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月10日 下午4:09:28  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-10      吴有根                      1.0         1.0 Version  
 */

public class BigDataModel {
	//货物基本信息
	private ArrayList<InsResultGoodsModel> insResultGoods;
	
	//查验项目
	private ArrayList<InsCheckItemModel> insCheckItemPorts;
	
	//货物检疫
	private ArrayList<InsCheckItemModel> insCheckItemPorts1;
	//货物检验
	private ArrayList<InsCheckItemModel> insCheckItemPorts2;
	//货物鉴定
	private ArrayList<InsCheckItemModel> insCheckItemPorts3;
	//木质包装检疫
	private ArrayList<InsCheckItemModel> insCheckItemPorts4;
	
	//集装箱项目
	private ArrayList<InsCheckItemModel> insCheckItemConts;
	
	//卫生检疫
	private ArrayList<InsCheckItemModel> insCheckItemHealths;
	
	//检疫检疫
	private ArrayList<InsCheckItemModel> insCheckItemCheckGoods;

	
	public ArrayList<InsCheckItemModel> getInsCheckItemPorts1() {
		return insCheckItemPorts1;
	}

	public void setInsCheckItemPorts1(ArrayList<InsCheckItemModel> insCheckItemPorts1) {
		this.insCheckItemPorts1 = insCheckItemPorts1;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemPorts2() {
		return insCheckItemPorts2;
	}

	public void setInsCheckItemPorts2(ArrayList<InsCheckItemModel> insCheckItemPorts2) {
		this.insCheckItemPorts2 = insCheckItemPorts2;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemPorts3() {
		return insCheckItemPorts3;
	}

	public void setInsCheckItemPorts3(ArrayList<InsCheckItemModel> insCheckItemPorts3) {
		this.insCheckItemPorts3 = insCheckItemPorts3;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemPorts4() {
		return insCheckItemPorts4;
	}

	public void setInsCheckItemPorts4(ArrayList<InsCheckItemModel> insCheckItemPorts4) {
		this.insCheckItemPorts4 = insCheckItemPorts4;
	}

	public ArrayList<InsResultGoodsModel> getInsResultGoods() {
		return insResultGoods;
	}

	public void setInsResultGoods(ArrayList<InsResultGoodsModel> insResultGoods) {
		this.insResultGoods = insResultGoods;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemPorts() {
		return insCheckItemPorts;
	}

	public void setInsCheckItemPorts(ArrayList<InsCheckItemModel> insCheckItemPorts) {
		this.insCheckItemPorts = insCheckItemPorts;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemConts() {
		return insCheckItemConts;
	}

	public void setInsCheckItemConts(ArrayList<InsCheckItemModel> insCheckItemConts) {
		this.insCheckItemConts = insCheckItemConts;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemHealths() {
		return insCheckItemHealths;
	}

	public void setInsCheckItemHealths(ArrayList<InsCheckItemModel> insCheckItemHealths) {
		this.insCheckItemHealths = insCheckItemHealths;
	}

	public ArrayList<InsCheckItemModel> getInsCheckItemCheckGoods() {
		return insCheckItemCheckGoods;
	}

	public void setInsCheckItemCheckGoods(ArrayList<InsCheckItemModel> insCheckItemCheckGoods) {
		this.insCheckItemCheckGoods = insCheckItemCheckGoods;
	}

}

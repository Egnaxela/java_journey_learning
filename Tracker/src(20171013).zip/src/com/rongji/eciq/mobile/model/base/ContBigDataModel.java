/**  
 * FileName:  ContBigDataModel.java   
 * @Description: 集装箱不合格登记大对象model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月15日 下午4:10:37  
 *  
 */  

package com.rongji.eciq.mobile.model.base;

import java.util.List;

import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModel;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelAnimal;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelCont;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelDetail;
import com.rongji.eciq.mobile.model.insp.scene.InsContainerResultModelHealth;

/**  
 * Description: 集装箱不合格登记大对象model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月15日 下午4:10:37  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月15日      吴有根                      1.0         1.0 Version  
 */

public class ContBigDataModel {
	private List<InsContainerResultModel> insContainerResultModelList; //集装箱检验结果列表
	private InsContainerResultModelDetail  insContainerResultModelDetail;//集装箱基本信息
	private InsContainerResultModelCont insContainerResultModelCont;//集装箱检疫情况
	private InsContainerResultModelHealth insContainerResultModelHealth;//卫生检疫查验情况
	private InsContainerResultModelAnimal insContainerResultModelAnimal;//动植物检疫情况
	
	
	public List<InsContainerResultModel> getInsContainerResultModelList() {
		return insContainerResultModelList;
	}

	public void setInsContainerResultModelList(List<InsContainerResultModel> insContainerResultModelList) {
		this.insContainerResultModelList = insContainerResultModelList;
	}

	public InsContainerResultModelDetail getInsContainerResultModelDetail() {
		return insContainerResultModelDetail;
	}

	public void setInsContainerResultModelDetail(InsContainerResultModelDetail insContainerResultModelDetail) {
		this.insContainerResultModelDetail = insContainerResultModelDetail;
	}

	public InsContainerResultModelCont getInsContainerResultModelCont() {
		return insContainerResultModelCont;
	}

	public void setInsContainerResultModelCont(InsContainerResultModelCont insContainerResultModelCont) {
		this.insContainerResultModelCont = insContainerResultModelCont;
	}

	public InsContainerResultModelHealth getInsContainerResultModelHealth() {
		return insContainerResultModelHealth;
	}

	public void setInsContainerResultModelHealth(InsContainerResultModelHealth insContainerResultModelHealth) {
		this.insContainerResultModelHealth = insContainerResultModelHealth;
	}

	public InsContainerResultModelAnimal getInsContainerResultModelAnimal() {
		return insContainerResultModelAnimal;
	}

	public void setInsContainerResultModelAnimal(InsContainerResultModelAnimal insContainerResultModelAnimal) {
		this.insContainerResultModelAnimal = insContainerResultModelAnimal;
	}
	
	
}

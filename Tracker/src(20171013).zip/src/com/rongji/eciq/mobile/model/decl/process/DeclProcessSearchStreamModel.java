package com.rongji.eciq.mobile.model.decl.process;

/**
 * 
 * Description: 报检单流程查询model
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波
 * @version:    1.0  
 * Create at:   2017-5-15 上午11:25:10  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                     1.0         1.0 Version
 */
public class DeclProcessSearchStreamModel {

	private String declNo;//报检号
	private String processState;//流程状态
	private String processLink;//流程环节
	private String operName;//操作人
	private String deptName;//部门名称
	private String orgName;//机构名称
	private String declDate;//操作日期
	
	public DeclProcessSearchStreamModel(String declNo, String processState,
			String processLink, String operName, String deptName, String orgName,String declDate) {
		super();
		this.declNo = declNo;
		this.processState = processState;
		this.processLink = processLink;
		this.operName = operName;
		this.deptName = deptName;
		this.orgName = orgName;
		this.declDate = declDate;
	}
	public DeclProcessSearchStreamModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getProcessState() {
		return processState;
	}
	public void setProcessState(String processState) {
		this.processState = processState;
	}
	public String getProcessLink() {
		return processLink;
	}
	public void setProcessLink(String processLink) {
		this.processLink = processLink;
	}
	public String getOperName() {
		return operName;
	}
	public void setOperName(String operName) {
		this.operName = operName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getDeclDate() {
		return declDate;
	}
	public void setDeclDate(String declDate) {
		this.declDate = declDate;
	}
	
	
	
}

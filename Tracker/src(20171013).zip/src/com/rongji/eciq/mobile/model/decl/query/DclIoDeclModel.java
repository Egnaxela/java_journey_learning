package com.rongji.eciq.mobile.model.decl.query;

/**
 * 
 * Description: 报检单信息model
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波  
 * @version:    1.0  
 * Create at:   2017-5-15 上午11:25:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                     1.0         1.0 Version
 * 2017-9-26      智文龙                 2.0         流程查询增加主辅施检标识
 */
public class DclIoDeclModel {

	private String declNo;//报检号
	private String processCode;//流程状态编码
	private String processName;//流程状态
	private String linkName;//环节名称
	private String declCodeName;//报检类别
	private String declDate;//报检日期
	private String tradeCountryCode;//国家
	private String goodsName;//货物名
	private String flowPathStatus;//主辅检标记
	private String flowPathStatusCode;//主辅检标记代码
	private String flowPathStatusName;//主辅检标记名称
	
	public DclIoDeclModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DclIoDeclModel(String declNo, String processCode,
			String processName, String linkName, String declCodeName,
			String declDate, String tradeCountryCode, String goodsName) {
		super();
		this.declNo = declNo;
		this.processCode = processCode;
		this.processName = processName;
		this.linkName = linkName;
		this.declCodeName = declCodeName;
		this.declDate = declDate;
		this.tradeCountryCode = tradeCountryCode;
		this.goodsName = goodsName;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getLinkName() {
		return linkName;
	}
	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}
	public String getDeclCodeName() {
		return declCodeName;
	}
	public void setDeclCodeName(String declCodeName) {
		this.declCodeName = declCodeName;
	}
	public String getDeclDate() {
		return declDate;
	}
	public void setDeclDate(String declDate) {
		this.declDate = declDate;
	}
	public String getTradeCountryCode() {
		return tradeCountryCode;
	}
	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}
	public String getFlowPathStatus() {
		return flowPathStatus;
	}
	public void setFlowPathStatus(String flowPathStatus) {
		this.flowPathStatus = flowPathStatus;
	}
	public String getFlowPathStatusCode() {
		return flowPathStatusCode;
	}
	public void setFlowPathStatusCode(String flowPathStatusCode) {
		this.flowPathStatusCode = flowPathStatusCode;
	}
	public String getFlowPathStatusName() {
		return flowPathStatusName;
	}
	public void setFlowPathStatusName(String flowPathStatusName) {
		this.flowPathStatusName = flowPathStatusName;
	}
}

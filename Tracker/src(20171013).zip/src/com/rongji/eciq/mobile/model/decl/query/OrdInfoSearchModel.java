/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-26 下午1:49:15  
 *  
 */  

package com.rongji.eciq.mobile.model.decl.query;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波 
 * @version:    1.0  
 * Create at:   2017-5-26 下午1:49:15  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-26      魏波                     1.0         1.0 Version  
 */

public class OrdInfoSearchModel {
	private String conclusionName;//结论名称
	private String contDesc;//结论内容
	private String arriveLink;//到达环节
	private String centType;//审单类型
	private String orderDate;//布控时间
	private String enableed;//是否生效
	private String orgCodeName;//所属机构
	
	public OrdInfoSearchModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrdInfoSearchModel(String conclusionName, String contDesc,
			String arriveLink, String centType, String orderDate,
			String enableed, String orgCodeName) {
		super();
		this.conclusionName = conclusionName;
		this.contDesc = contDesc;
		this.arriveLink = arriveLink;
		this.centType = centType;
		this.orderDate = orderDate;
		this.enableed = enableed;
		this.orgCodeName = orgCodeName;
	}

	public String getConclusionName() {
		return conclusionName;
	}

	public void setConclusionName(String conclusionName) {
		this.conclusionName = conclusionName;
	}

	public String getContDesc() {
		return contDesc;
	}

	public void setContDesc(String contDesc) {
		this.contDesc = contDesc;
	}

	public String getArriveLink() {
		return arriveLink;
	}

	public void setArriveLink(String arriveLink) {
		this.arriveLink = arriveLink;
	}

	public String getCentType() {
		return centType;
	}

	public void setCentType(String centType) {
		this.centType = centType;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getEnableed() {
		return enableed;
	}

	public void setEnableed(String enableed) {
		this.enableed = enableed;
	}

	public String getOrgCodeName() {
		return orgCodeName;
	}

	public void setOrgCodeName(String orgCodeName) {
		this.orgCodeName = orgCodeName;
	}
	
}

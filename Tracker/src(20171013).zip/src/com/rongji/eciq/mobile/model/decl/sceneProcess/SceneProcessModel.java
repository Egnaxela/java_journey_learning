/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-9 下午5:02:56  
 *  
 */  

package com.rongji.eciq.mobile.model.decl.sceneProcess;

/**
 * 
 * Description: 查验信息model
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波  
 * @version:    1.0  
 * Create at:   2017-5-15 上午11:26:29  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-15      魏波                     1.0         1.0 Version
 */
public class SceneProcessModel {

	/**
	 * 报检号
	 */
	private String declNo;
	
	/**
	 * 报检时间
	 */
	private String declDate;
	
	/**
	 * 操作人
	 */
	private String operName;
	
	/**
	 * 流程状态
	 */
	private String processName;

	/**
	 * 流程环节
	 */
	private String linkName;
	
	/**
	 * 机构名
	 */
	private String orgName;

	/**
	 * 部门名
	 */
	private String deptName;
	
	public SceneProcessModel() {
		super();
		// TODO Auto-generated constructor stub
	}


	public SceneProcessModel(String declNo, String declDate, String operName,
			String processName, String linkName, String orgName,String deptName) {
		super();
		this.declNo = declNo;
		this.declDate = declDate;
		this.operName = operName;
		this.processName = processName;
		this.linkName = linkName;
		this.orgName = orgName;
		this.deptName = deptName;
	}


	
	public String getDeptName() {
		return deptName;
	}


	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


	public String getDeclNo() {
		return declNo;
	}


	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}


	public String getDeclDate() {
		return declDate;
	}


	public void setDeclDate(String declDate) {
		this.declDate = declDate;
	}


	public String getOperName() {
		return operName;
	}


	public void setOperName(String operName) {
		this.operName = operName;
	}


	public String getProcessName() {
		return processName;
	}


	public void setProcessName(String processName) {
		this.processName = processName;
	}


	public String getLinkName() {
		return linkName;
	}


	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}


	public String getOrgName() {
		return orgName;
	}


	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	
}

package com.rongji.eciq.mobile.model.insp;

import java.util.List;

import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;

/**
 * 集装箱基本信息model
 * @author 吴有根
 *
 */
public class DclIoDeclContModel {

	private String declNo;//报检单号
	private String seqNo;//序号
	private String cntnrModeCode;//集装箱规格
	private String containerQty;//集装箱数量
	private String contNo;//号码
	private String lclFlag;//拼箱标志
	private List<DclIoDeclContDetailEntity> details;//集装箱明细
	
	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	public String getCntnrModeCode() {
		return cntnrModeCode;
	}

	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}

	public String getContainerQty() {
		return containerQty;
	}

	public void setContainerQty(String containerQty) {
		this.containerQty = containerQty;
	}

	public String getContNo() {
		return contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	public String getLclFlag() {
		return lclFlag;
	}

	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}

	public List<DclIoDeclContDetailEntity> getDetails() {
		return details;
	}

	public void setDetails(List<DclIoDeclContDetailEntity> details) {
		this.details = details;
	}
	
}

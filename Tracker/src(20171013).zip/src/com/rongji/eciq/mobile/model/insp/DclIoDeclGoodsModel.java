package com.rongji.eciq.mobile.model.insp;

/**
 * 报检货物基本信息model
 * @author 吴有根
 *
 */
public class DclIoDeclGoodsModel {

	private String declNo;//报检单号
	private String goodsNo;//货物序号
	private String declGoodsCname;//货物名称
	private String prodHsCode;//HS 编码
	private String hsCodeDesc;//HS名称描述
	private String ciqCode;//ciq 编码
	private String ciqName;//ciq 名称
	private String goodsTotalVal;//货物总值
	private String currency;//币种
	private String qty; //数量
	private String qtyMeasUnit;//数量计量单位
	private String weight;//重量
	private String wtMeasUnit;//重量计量单位
	private Double stdWeight;//标准重量
	private String stdWeightUnitCode;//标准重量单位
	private String oriCtryCode;//原产国代码
	private String purpose;//用途
	private String origPlaceCode;//入境原产地区
	private String mnufctrRegName;//生产单位
	private String placeCode;//出境产地
	private String packqty;//包装数量
	private String packCatgName;//包装数量单位
	
	public String getPackqty() {
		return packqty;
	}

	public void setPackqty(String packqty) {
		this.packqty = packqty;
	}

	public String getPackCatgName() {
		return packCatgName;
	}

	public void setPackCatgName(String packCatgName) {
		this.packCatgName = packCatgName;
	}

	public String getPlaceCode() {
		return placeCode;
	}

	public void setPlaceCode(String placeCode) {
		this.placeCode = placeCode;
	}

	public String getMnufctrRegName() {
		return mnufctrRegName;
	}

	public void setMnufctrRegName(String mnufctrRegName) {
		this.mnufctrRegName = mnufctrRegName;
	}

	public String getOrigPlaceCode() {
		return origPlaceCode;
	}

	public void setOrigPlaceCode(String origPlaceCode) {
		this.origPlaceCode = origPlaceCode;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getDeclGoodsCname() {
		return declGoodsCname;
	}

	public void setDeclGoodsCname(String declGoodsCname) {
		this.declGoodsCname = declGoodsCname;
	}

	public String getProdHsCode() {
		return prodHsCode;
	}

	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}

	public String getHsCodeDesc() {
		return hsCodeDesc;
	}

	public void setHsCodeDesc(String hsCodeDesc) {
		this.hsCodeDesc = hsCodeDesc;
	}

	public String getCiqCode() {
		return ciqCode;
	}

	public void setCiqCode(String ciqCode) {
		this.ciqCode = ciqCode;
	}

	public String getCiqName() {
		return ciqName;
	}

	public void setCiqName(String ciqName) {
		this.ciqName = ciqName;
	}

	public String getGoodsTotalVal() {
		return goodsTotalVal;
	}

	public void setGoodsTotalVal(String goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}

	public String getQtyMeasUnit() {
		return qtyMeasUnit;
	}

	public void setQtyMeasUnit(String qtyMeasUnit) {
		this.qtyMeasUnit = qtyMeasUnit;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getWtMeasUnit() {
		return wtMeasUnit;
	}

	public void setWtMeasUnit(String wtMeasUnit) {
		this.wtMeasUnit = wtMeasUnit;
	}

	public Double getStdWeight() {
		return stdWeight;
	}

	public void setStdWeight(Double stdWeight) {
		this.stdWeight = stdWeight;
	}

	public String getStdWeightUnitCode() {
		return stdWeightUnitCode;
	}

	public void setStdWeightUnitCode(String stdWeightUnitCode) {
		this.stdWeightUnitCode = stdWeightUnitCode;
	}

	public String getOriCtryCode() {
		return oriCtryCode;
	}

	public void setOriCtryCode(String oriCtryCode) {
		this.oriCtryCode = oriCtryCode;
	}
	
	
}

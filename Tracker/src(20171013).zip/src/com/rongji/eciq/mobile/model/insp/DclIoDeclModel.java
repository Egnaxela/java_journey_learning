package com.rongji.eciq.mobile.model.insp;

/**
 * 报检单基本信息model
 * @author 吴有根
 *
 */
public class DclIoDeclModel {

	private String declNo;//报检单号
	private String declDate;//报检单位
	private String declRegName;  //报检单位
//	private String contactperson;//联系人
//	private String contTel;//联系人电话
	private String tradeCountryCode;//贸易国家/地区
	private String despCtryCode;//启运国家/地区
	private String tradeModeCode;//贸易方式
	private String contractNo;//合同号
	private String markNo;//标记及号码
	private String inspOrgCode;//施检地  口岸机构
	private String excInspDeptCode;//施检部门代码 口岸部门
	private String consigneeCode;//收货人代码
	private String consigneeCname;//收货人名称(中文)
	private String consigneeEname;//收货人名称(外文)
	private String consignorCname;//发货人名称(中文)
	private String consignorEname;//发货人名称(外文)
	private String consignorAddr;//发货人地址
	private String transModeCode;//运输方式
	private String attaCollectName;//随附单据
	private String appCertName;//所需单证
	private String orgCode;//报检地
	private String vsaOrgCode;//领证地
	private String purpOrgCode;//目的地机构
	private String purpDeptCode;//目的地部门
	private String speclInspQuraRe;//特殊要求
	private String outDeclCode;//出境报检类别
	private String inDeclCode;//入境报检类别
	

	public String getOutDeclCode() {
		return outDeclCode;
	}

	public void setOutDeclCode(String outDeclCode) {
		this.outDeclCode = outDeclCode;
	}

	public String getInDeclCode() {
		return inDeclCode;
	}

	public void setInDeclCode(String inDeclCode) {
		this.inDeclCode = inDeclCode;
	}

	public String getSpeclInspQuraRe() {
		return speclInspQuraRe;
	}

	public void setSpeclInspQuraRe(String speclInspQuraRe) {
		this.speclInspQuraRe = speclInspQuraRe;
	}

	public String getVsaOrgCode() {
		return vsaOrgCode;
	}

	public void setVsaOrgCode(String vsaOrgCode) {
		this.vsaOrgCode = vsaOrgCode;
	}

	public String getAttaCollectName() {
		return attaCollectName;
	}

	public void setAttaCollectName(String attaCollectName) {
		this.attaCollectName = attaCollectName;
	}

	public String getAppCertName() {
		return appCertName;
	}

	public void setAppCertName(String appCertName) {
		this.appCertName = appCertName;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getPurpOrgCode() {
		return purpOrgCode;
	}

	public void setPurpOrgCode(String purpOrgCode) {
		this.purpOrgCode = purpOrgCode;
	}

	public String getPurpDeptCode() {
		return purpDeptCode;
	}

	public void setPurpDeptCode(String purpDeptCode) {
		this.purpDeptCode = purpDeptCode;
	}

	public String getTransModeCode() {
		return transModeCode;
	}

	public void setTransModeCode(String transModeCode) {
		this.transModeCode = transModeCode;
	}

	public String getConsignorEname() {
		return consignorEname;
	}

	public void setConsignorEname(String consignorEname) {
		this.consignorEname = consignorEname;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getDeclDate() {
		return declDate;
	}

	public void setDeclDate(String declDate) {
		this.declDate = declDate;
	}

	public String getDeclRegName() {
		return declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

//	public String getContactperson() {
//		return contactperson;
//	}
//
//	public void setContactperson(String contactperson) {
//		this.contactperson = contactperson;
//	}
//
//	public String getContTel() {
//		return contTel;
//	}
//
//	public void setContTel(String contTel) {
//		this.contTel = contTel;
//	}

	public String getTradeCountryCode() {
		return tradeCountryCode;
	}

	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}

	public String getDespCtryCode() {
		return despCtryCode;
	}

	public void setDespCtryCode(String despCtryCode) {
		this.despCtryCode = despCtryCode;
	}

	public String getTradeModeCode() {
		return tradeModeCode;
	}

	public void setTradeModeCode(String tradeModeCode) {
		this.tradeModeCode = tradeModeCode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getMarkNo() {
		return markNo;
	}

	public void setMarkNo(String markNo) {
		this.markNo = markNo;
	}

	public String getInspOrgCode() {
		return inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	public String getExcInspDeptCode() {
		return excInspDeptCode;
	}

	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}

	public String getConsigneeCode() {
		return consigneeCode;
	}

	public void setConsigneeCode(String consigneeCode) {
		this.consigneeCode = consigneeCode;
	}

	public String getConsigneeCname() {
		return consigneeCname;
	}

	public void setConsigneeCname(String consigneeCname) {
		this.consigneeCname = consigneeCname;
	}

	public String getConsigneeEname() {
		return consigneeEname;
	}

	public void setConsigneeEname(String consigneeEname) {
		this.consigneeEname = consigneeEname;
	}

	public String getConsignorCname() {
		return consignorCname;
	}

	public void setConsignorCname(String consignorCname) {
		this.consignorCname = consignorCname;
	}

	public String getConsignorAddr() {
		return consignorAddr;
	}

	public void setConsignorAddr(String consignorAddr) {
		this.consignorAddr = consignorAddr;
	}
	
	
}

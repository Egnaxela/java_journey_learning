/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳 
 * @version:     1.0
 * Createdate:   2017-5-23 下午4:52:49  
 *  
 */  

package com.rongji.eciq.mobile.model.insp;

import java.util.ArrayList;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳 
 * @version:    1.0  
 * Create at:   2017-5-23 下午4:52:49  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-23      李晨阳                     1.0         1.0 Version  
 */

public class DetailInfoModel {
	
	private ArrayList<DclIoDeclModel> DclIoDeclList;//报检单信息
	private ArrayList<DclIoDeclGoodsModel> DclIoDeclGoodsList;//货物信息
	private ArrayList<DclIoDeclContModel> DclIoDeclContList;//集装箱信息
	
	
	public void setDclIoDeclList(ArrayList<DclIoDeclModel> DclIoDeclList) {
		this.DclIoDeclList = DclIoDeclList;
	}

	public ArrayList<DclIoDeclModel> getDclIoDeclList() {
		return DclIoDeclList;
	}
	
	public void setDclIoDeclGoodsList(ArrayList<DclIoDeclGoodsModel> DclIoDeclGoodsList) {
		this.DclIoDeclGoodsList = DclIoDeclGoodsList;
	}

	public ArrayList<DclIoDeclGoodsModel> getDclIoDeclGoodsList() {
		return DclIoDeclGoodsList;
	}
	
	public void setDclIoDeclContList(ArrayList<DclIoDeclContModel> DclIoDeclContListl) {
		this.DclIoDeclContList = DclIoDeclContListl;
	}

	public ArrayList<DclIoDeclContModel> getDclIoDeclContList() {
		return DclIoDeclContList;
	}
}

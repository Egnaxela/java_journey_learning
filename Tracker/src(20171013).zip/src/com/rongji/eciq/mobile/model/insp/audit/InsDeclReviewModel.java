/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * CreateString:   2017-4-27 下午4:15:06  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.audit;

/**  
 * Description: 审核记录
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-27 下午4:15:06  
 *  
 * Modification History:  
 * String         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-27      才江男                      1.0         1.0 Version  
 * 2017-05-05     才江男                      1.0          增加审核状态
 */

public class InsDeclReviewModel {
	
	private String processStatus;//审核环节
	private String auditAdvice;//审核意见
	private String auditCode;//审核人
	private String auditTime;//审核时间
	private String operTime;//操作时间
	private String isAudit;//审核状态
	
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public String getAuditAdvice() {
		return auditAdvice;
	}
	public void setAuditAdvice(String auditAdvice) {
		this.auditAdvice = auditAdvice;
	}
	public String getAuditCode() {
		return auditCode;
	}
	public void setAuditCode(String auditCode) {
		this.auditCode = auditCode;
	}
	public String getAuditTime() {
		return auditTime;
	}
	public void setAuditTime(String auditTime) {
		this.auditTime = auditTime;
	}
	public String getOperTime() {
		return operTime;
	}
	public void setOperTime(String operTime) {
		this.operTime = operTime;
	}
	public String getIsAudit() {
		return isAudit;
	}
	public void setIsAudit(String isAudit) {
		this.isAudit = isAudit;
	}
	
}

/**  
 * FileName:CheckAppointBaseInfoModel.java     
 * @Description: 企业基本信息model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月21日 上午10:04:20  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.check;

/**  
 * Description: 企业基本信息model   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月21日 上午10:04:20  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月21日      吴有根                      1.0         1.0 Version  
 */

public class CheckAppointBaseInfoModel {

	private String declRegNo;//报价单位注册号
	private String unitNameCn;//报检单位名称中文
//	private String unitNameEn;//报检单位名称英文
	
	public String getDeclRegNo() {
		return declRegNo;
	}
	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}
	public String getUnitNameCn() {
		return unitNameCn;
	}
	public void setUnitNameCn(String unitNameCn) {
		this.unitNameCn = unitNameCn;
	}
//	public String getUnitNameEn() {
//		return unitNameEn;
//	}
//	public void setUnitNameEn(String unitNameEn) {
//		this.unitNameEn = unitNameEn;
//	}
	
}

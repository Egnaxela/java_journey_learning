/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年6月27日 下午6:26:02  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.check;

import java.util.Date;


/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年6月27日 下午6:26:02  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-06-27    吴有根                      1.0         1.0 Version  
 * 2017-07-07    李云龙                      1.0         添加申请id与组织机构代码字段
 * 2017-07-07    李云龙                       1.0         添加审批人员与审批时间 
 * 
 */

public class CheckAppointmentInfoModel {

	private String applyId;//申请id
	private String applyNo;//申请单号
	private String applyType;//申请类别 1：预约申请 2：撤销申请
	private String applyStatus;//申请状态  (0:待受理、1:已受理、3:待审批、4:已审批)
	private String declNo;//报检号
	private String plateNo;//车牌号
	private String contNo;//集装箱号
	private String entOrgCode;//组织机构代码 
	private String declRegNo;//报检单位注册号
	private String declRegName;//报检单位名称
	private String applyTime;//申请时间
	private String appointCheckDate;//预约时间
	private String inspOrgCode;//施检机构【对本批货物实施检验检疫的机构】
	private String inspOrgName;//施检机构名称【对本批货物实施检验检疫的机构】
	private String appointCheckPlace;//预约查验地点
	private String appointContactPerson;//预约联系人
	private String appointContactPersonName;//预约联系人
	private String appointContactTel;//预约联系电话
	private String remark;//备注
	private String checkOrgCode;//查验结构
	private String checkOrgCodeName;//查验结构名称
	private String checkDate;//查验日期
	private String checkContactTel;//查验联系电话
	private String checkPerson;//查验人员
	private String checkPersonName;//查验人员
	private String acceptResult;//受理结果 (0：未审批 1:同意 2：不同意)
	private String acceptRemark;//受理意见
	private String approvalPerson;//审批人员
	private String approvalPersonName;//审批人员
	private String approvalTime;//审批时间
	
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getApplyNo() {
		return applyNo;
	}
	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}
	public String getApplyType() {
		return applyType;
	}
	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getPlateNo() {
		return plateNo;
	}
	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getDeclRegNo() {
		return declRegNo;
	}
	
	public String getEntOrgCode() {
		return entOrgCode;
	}
	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}
	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}
	public String getDeclRegName() {
		return declRegName;
	}
	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}
	public String getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(String applyTime) {
		this.applyTime = applyTime;
	}
	public String getAppointCheckDate() {
		return appointCheckDate;
	}
	public void setAppointCheckDate(String appointCheckDate) {
		this.appointCheckDate = appointCheckDate;
	}
	public String getInspOrgCode() {
		return inspOrgCode;
	}
	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}
	public String getAppointCheckPlace() {
		return appointCheckPlace;
	}
	public void setAppointCheckPlace(String appointCheckPlace) {
		this.appointCheckPlace = appointCheckPlace;
	}
	public String getAppointContactPerson() {
		return appointContactPerson;
	}
	public void setAppointContactPerson(String appointContactPerson) {
		this.appointContactPerson = appointContactPerson;
	}
	public String getAppointContactTel() {
		return appointContactTel;
	}
	public void setAppointContactTel(String appointContactTel) {
		this.appointContactTel = appointContactTel;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getCheckOrgCode() {
		return checkOrgCode;
	}
	public void setCheckOrgCode(String checkOrgCode) {
		this.checkOrgCode = checkOrgCode;
	}
	public String getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}
	public String getCheckContactTel() {
		return checkContactTel;
	}
	public void setCheckContactTel(String checkContactTel) {
		this.checkContactTel = checkContactTel;
	}
	public String getCheckPerson() {
		return checkPerson;
	}
	public void setCheckPerson(String checkPerson) {
		this.checkPerson = checkPerson;
	}
	public String getAcceptResult() {
		return acceptResult;
	}
	public void setAcceptResult(String acceptResult) {
		this.acceptResult = acceptResult;
	}
	public String getAcceptRemark() {
		return acceptRemark;
	}
	public void setAcceptRemark(String acceptRemark) {
		this.acceptRemark = acceptRemark;
	}
	public String getApplyStatus() {
		return applyStatus;
	}
	public void setApplyStatus(String applyStatus) {
		this.applyStatus = applyStatus;
	}
	public String getApprovalPerson() {
		return approvalPerson;
	}
	public void setApprovalPerson(String approvalPerson) {
		this.approvalPerson = approvalPerson;
	}
	public String getApprovalTime() {
		return approvalTime;
	}
	public void setApprovalTime(String approvalTime) {
		this.approvalTime = approvalTime;
	}
	public String getInspOrgName() {
		return inspOrgName;
	}
	public void setInspOrgName(String inspOrgName) {
		this.inspOrgName = inspOrgName;
	}
	public String getCheckOrgCodeName() {
		return checkOrgCodeName;
	}
	public void setCheckOrgCodeName(String checkOrgCodeName) {
		this.checkOrgCodeName = checkOrgCodeName;
	}
	public String getAppointContactPersonName() {
		return appointContactPersonName;
	}
	public void setAppointContactPersonName(String appointContactPersonName) {
		this.appointContactPersonName = appointContactPersonName;
	}
	public String getCheckPersonName() {
		return checkPersonName;
	}
	public void setCheckPersonName(String checkPersonName) {
		this.checkPersonName = checkPersonName;
	}
	public String getApprovalPersonName() {
		return approvalPersonName;
	}
	public void setApprovalPersonName(String approvalPersonName) {
		this.approvalPersonName = approvalPersonName;
	}
	
	
}

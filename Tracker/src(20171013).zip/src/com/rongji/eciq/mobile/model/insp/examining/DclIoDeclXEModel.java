package com.rongji.eciq.mobile.model.insp.examining;

/**
 * 审单数据model
 * @author  魏波
 * @version 1.0
 */
public class DclIoDeclXEModel {

	private String declNo;//报检单号
	private String entName;//企业名称
	private String entTypeCode;//企业类型
	private String inspRequire;//检验要求
	private String country;//国家地区
	private String certTypeName;//所需证书
	
	public DclIoDeclXEModel() {
		super();
	}

	public DclIoDeclXEModel(String declNo, String entName, String entTypeCode,
			String inspRequire, String country,String cretTypeName) {
		super();
		this.declNo = declNo;
		this.entName = entName;
		this.entTypeCode = entTypeCode;
		this.inspRequire = inspRequire;
		this.country = country;
		this.certTypeName = cretTypeName;
	}

	public String getCertTypeName() {
		return certTypeName;
	}

	public void setCertTypeName(String certTypeName) {
		this.certTypeName = certTypeName;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getEntTypeCode() {
		return entTypeCode;
	}

	public void setEntTypeCode(String entTypeCode) {
		this.entTypeCode = entTypeCode;
	}

	public String getInspRequire() {
		return inspRequire;
	}

	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	
}

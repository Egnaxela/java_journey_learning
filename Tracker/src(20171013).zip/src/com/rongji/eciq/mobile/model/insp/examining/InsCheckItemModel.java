package com.rongji.eciq.mobile.model.insp.examining;

/**
 * 查验项目model
 * @author 李晨阳
 *
 */
public class InsCheckItemModel {

	private String checkItemName;//查验项目名称
	private String whetherQualfy;//是否合格
	private String sampleSch;//抽样方案类别
	private String formName;//表单名称
	private String checkCont;//查验内容
	
	public String getCheckItemName() {
		return checkItemName;
	}
	public void setCheckItemName(String checkItemName) {
		this.checkItemName = checkItemName;
	}
	public String getWhetherQualfy() {
		return whetherQualfy;
	}
	public void setWhetherQualfy(String whetherQualfy) {
		this.whetherQualfy = whetherQualfy;
	}
	public String getSampleSch() {
		return sampleSch;
	}
	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getCheckCont() {
		return checkCont;
	}
	public void setCheckCont(String checkCont) {
		this.checkCont = checkCont;
	}
	
	
}

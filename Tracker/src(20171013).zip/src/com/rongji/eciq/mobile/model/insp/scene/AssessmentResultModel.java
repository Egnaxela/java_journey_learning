/**  
 * FileName:  AssessmentResultModel.java   
 * @Description: 综合评定结果 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-5-11 上午10:10:03  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 综合评定结果  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-11 上午10:10:03  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-11      李云龙                      1.0         1.0 Version  
 */

public class AssessmentResultModel {
	private String result;//综合评定结果
	private String message;//综合评定异常信息
	private String promptMessage;//综合评定环节提示信息
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getPromptMessage() {
		return promptMessage;
	}
	public void setPromptMessage(String promptMessage) {
		this.promptMessage = promptMessage;
	}
	

}

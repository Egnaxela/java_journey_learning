package com.rongji.eciq.mobile.model.insp.scene;

/**
 * 基本模型
 * 
 * @author 才江男
 * @since 1.0
 */
public class BaseModel {
	
	private String msg;//消息
	
	private boolean flag;//标志

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

}

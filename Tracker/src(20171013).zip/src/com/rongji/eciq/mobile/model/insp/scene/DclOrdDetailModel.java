package com.rongji.eciq.mobile.model.insp.scene;

/**
 * 全部布控数据model
 * @author  李云龙
 * @version 1.0
 */
public class DclOrdDetailModel {

	private String arriveApp;//到达的应用
	private String arrivLink;//到达的环节
	private String arrivLinkName;//到达的环节名称
	private String conclusionName;//结论名称
	private String execLevel;//执行级别
	private String concDesc;//结论内容
	
	public DclOrdDetailModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DclOrdDetailModel(String arriveApp, String arrivLink, String conclusionName, String execLevel,
			String concDesc) {
		super();
		this.arriveApp = arriveApp;
		this.arrivLink = arrivLink;
		this.conclusionName = conclusionName;
		this.execLevel = execLevel;
		this.concDesc = concDesc;
	}
	public String getArriveApp() {
		return arriveApp;
	}
	public void setArriveApp(String arriveApp) {
		this.arriveApp = arriveApp;
	}
	public String getArrivLink() {
		return arrivLink;
	}
	public void setArrivLink(String arrivLink) {
		this.arrivLink = arrivLink;
	}
	public String getConclusionName() {
		return conclusionName;
	}
	public void setConclusionName(String conclusionName) {
		this.conclusionName = conclusionName;
	}
	public String getExecLevel() {
		return execLevel;
	}
	public void setExecLevel(String execLevel) {
		this.execLevel = execLevel;
	}
	public String getConcDesc() {
		return concDesc;
	}
	public void setConcDesc(String concDesc) {
		this.concDesc = concDesc;
	}
	public String getArrivLinkName() {
		return arrivLinkName;
	}
	public void setArrivLinkName(String arrivLinkName) {
		this.arrivLinkName = arrivLinkName;
	}
	
	
}

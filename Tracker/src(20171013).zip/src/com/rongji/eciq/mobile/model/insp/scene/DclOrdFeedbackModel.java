package com.rongji.eciq.mobile.model.insp.scene;

import java.util.List;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.vo.insp.OrdFeedbacklVo;
/**
 * 布控反馈数据model
 * @author  李云龙
 * @version 1.0
 * Modification History:  
 * Date          Author     Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-20    李晨阳                     1.0         添加综合评定名称字段
 */
public class DclOrdFeedbackModel {
	private String declNo;//报检单号
	private String fedbackPersn;//反馈人代码
	private String fedbackPersnName;//反馈人名称
	private String assessStatus;//综合评定代码
	private String assessStatusName;//综合评定名称
	private String suplement;//补充说明
	private String operTime;//操作时间
	private List<OrdFeedbacklVo> feebackDetailVoList;//布控信息列表
	
	public DclOrdFeedbackModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DclOrdFeedbackModel(String declNo, String fedbackPersn, String assessStatus, String suplement,
			String operTime ,List<DclOrdFeedbackDetailEntity> feebackDetailList) {
		super();
		this.declNo = declNo;
		this.fedbackPersn = fedbackPersn;
		this.assessStatus = assessStatus;
		this.suplement = suplement;
		this.operTime = operTime;
		this.feebackDetailVoList = feebackDetailVoList;
	}
	
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getFedbackPersn() {
		return fedbackPersn;
	}
	public void setFedbackPersn(String fedbackPersn) {
		this.fedbackPersn = fedbackPersn;
	}
	public String getAssessStatus() {
		return assessStatus;
	}
	public void setAssessStatus(String assessStatus) {
		this.assessStatus = assessStatus;
	}
	public String getSuplement() {
		return suplement;
	}
	public void setSuplement(String suplement) {
		this.suplement = suplement;
	}
	public String getOperTime() {
		return operTime;
	}
	public void setOperTime(String operTime) {
		this.operTime = operTime;
	}
	public String getFedbackPersnName() {
		return fedbackPersnName;
	}
	public void setFedbackPersnName(String fedbackPersnName) {
		this.fedbackPersnName = fedbackPersnName;
	}
	public List<OrdFeedbacklVo> getFeebackDetailVoList() {
		return feebackDetailVoList;
	}
	public String getAssessStatusName() {
		return assessStatusName;
	}
	public void setAssessStatusName(String assessStatusName) {
		this.assessStatusName = assessStatusName;
	}
	public void setFeebackDetailVoList(List<OrdFeedbacklVo> feebackDetailVoList) {
		this.feebackDetailVoList = feebackDetailVoList;
	}
}

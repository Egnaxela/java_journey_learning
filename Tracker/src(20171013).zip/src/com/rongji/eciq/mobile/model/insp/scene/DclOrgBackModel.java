package com.rongji.eciq.mobile.model.insp.scene;

import java.util.List;
import com.rongji.eciq.mobile.vo.insp.OrdBackVo;
/**
 * 布控回退信息列表
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 上午9:43:43  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version
 */
public class DclOrgBackModel {

	private String declNo;//报检单号
	private String suplement;//补充说明
	private String fedbackPersn;//回退人
	private String fedbackPersnName;//回退人
	private String feedbackOrg;//回退机构代码
	private String feedbackOrgName;//回退机构名称
	private List<OrdBackVo> ordBacklist;//布控回退信息
	
	public DclOrgBackModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DclOrgBackModel(String declNo, String suplement, String fedbackPersn, String feedbackOrg,
			List<OrdBackVo> ordBacklist) {
		super();
		this.declNo = declNo;
		this.suplement = suplement;
		this.fedbackPersn = fedbackPersn;
		this.feedbackOrg = feedbackOrg;
		this.ordBacklist = ordBacklist;
	}
	
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getSuplement() {
		return suplement;
	}
	public void setSuplement(String suplement) {
		this.suplement = suplement;
	}
	public String getFedbackPersn() {
		return fedbackPersn;
	}
	public void setFedbackPersn(String fedbackPersn) {
		this.fedbackPersn = fedbackPersn;
	}
	public String getFeedbackOrg() {
		return feedbackOrg;
	}
	public void setFeedbackOrg(String feedbackOrg) {
		this.feedbackOrg = feedbackOrg;
	}
	public List<OrdBackVo> getOrdBacklist() {
		return ordBacklist;
	}
	public void setOrdBacklist(List<OrdBackVo> ordBacklist) {
		this.ordBacklist = ordBacklist;
	}
	public String getFedbackPersnName() {
		return fedbackPersnName;
	}
	public void setFedbackPersnName(String fedbackPersnName) {
		this.fedbackPersnName = fedbackPersnName;
	}
	public String getFeedbackOrgName() {
		return feedbackOrgName;
	}
	public void setFeedbackOrgName(String feedbackOrgName) {
		this.feedbackOrgName = feedbackOrgName;
	}
	
	
}

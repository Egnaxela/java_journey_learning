/**  
 * FileName:DeclBaseInfoModel.java     
 * @Description: 由报价单号带出企业、生产批号等基本信息model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月26日 下午3:17:12  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;



/**  
 * Description: 由报价单号带出企业、生产批号等基本信息model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月26日 下午3:17:12  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月26日      吴有根                      1.0         1.0 Version  
 */

@Entity
public class DeclBaseInfoModel {

	private String declRegNo; //报价单位注册号
	private String declRegName;//报检单位名称
	private String tradeCountryCode;//贸易国别
	private String despCtryCode;//启运国家
	private String qty;//数量
	private String qtyMeasUnit;//数量单位
	private String weight;//重量
	private String wtMeasUnit;//重量单位
	private String prodBatchNo;//生产批号
	private String goodsNo;//货物序号
	private String goodsId;//货物ID
	private String mnufctrRegName;//生产企业
	
	public DeclBaseInfoModel() {
		super();
	}

	public DeclBaseInfoModel(String declRegNo, String declRegName, String tradeCountryCode, String despCtryCode,
			String qty, String qtyMeasUnit, String weight, String wtMeasUnit, String prodBatchNo, String goodsNo,String mnufctrRegName) {
		super();
		this.declRegNo = declRegNo;
		this.declRegName = declRegName;
		this.tradeCountryCode = tradeCountryCode;
		this.despCtryCode = despCtryCode;
		this.qty = qty;
		this.qtyMeasUnit = qtyMeasUnit;
		this.weight = weight;
		this.wtMeasUnit = wtMeasUnit;
		this.prodBatchNo = prodBatchNo;
		this.goodsNo = goodsNo;
		this.mnufctrRegName = mnufctrRegName;
	}
	
	@Column(name = "MNUFCTR_REG_NAME")
	public String getMnufctrRegName() {
		return mnufctrRegName;
	}

	public void setMnufctrRegName(String mnufctrRegName) {
		this.mnufctrRegName = mnufctrRegName;
	}

	@Column(name = "DECL_REG_NO")
	public String getDeclRegNo() {
		return declRegNo;
	}
	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}
	
	@Column(name = "DECL_REG_NAME")
	public String getDeclRegName() {
		return declRegName;
	}
	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}
	
	@Column(name = "TRADE_COUNTRY_CODE")
	public String getTradeCountryCode() {
		return tradeCountryCode;
	}
	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}
	
	@Column(name = "DESP_CTRY_CODE")
	public String getDespCtryCode() {
		return despCtryCode;
	}
	public void setDespCtryCode(String despCtryCode) {
		this.despCtryCode = despCtryCode;
	}
	
	@Column(name = "QTY")
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	
	@Column(name = "QTY_MEAS_UNIT")
	public String getQtyMeasUnit() {
		return qtyMeasUnit;
	}
	public void setQtyMeasUnit(String qtyMeasUnit) {
		this.qtyMeasUnit = qtyMeasUnit;
	}
	
	@Column(name = "WEIGHT")
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	@Column(name = "WT_MEAS_UNIT")
	public String getWtMeasUnit() {
		return wtMeasUnit;
	}
	public void setWtMeasUnit(String wtMeasUnit) {
		this.wtMeasUnit = wtMeasUnit;
	}
	
	@Column(name = "PROD_BATCH_NO")
	public String getProdBatchNo() {
		return prodBatchNo;
	}
	public void setProdBatchNo(String prodBatchNo) {
		this.prodBatchNo = prodBatchNo;
	}
	
	@Column(name = "GOODS_NO")
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}

	@Id
	@Column(name = "GOODS_ID")
	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
	
	
}

/**  
 * FileName: DialogPromptMessage.java    
 * @Description: 现场查验界面底部提示信息
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-6-2 下午3:41:35  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 现场查验界面底部提示信息  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-6-2 下午3:41:35  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-6-2      李云龙                      1.0         1.0 Version  
 */

public class DialogPromptMessageModel {
	private String message;//信息
	private String inspCountNames;//工作内容
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public String getInspCountNames() {
		return inspCountNames;
	}
	public void setInspCountNames(String inspCountNames) {
		this.inspCountNames = inspCountNames;
	}
	
	

}

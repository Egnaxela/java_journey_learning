/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-4-19 下午7:34:26  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

import java.util.List;

import com.rongji.eciq.mobile.vo.insp.FileVo;

/**  
 * Description: 附件模型
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-19 下午7:34:26  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0         1.0 Version  
 * 2017-7-20      才江男                      1.0         附件模型
 */

public class FileModel extends BaseModel {
	
	private List<FileVo> files;//附件

	public List<FileVo> getFiles() {
		return files;
	}

	public void setFiles(List<FileVo> files) {
		this.files = files;
	}
	
	

}

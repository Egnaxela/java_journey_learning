package com.rongji.eciq.mobile.model.insp.scene;


/**  
 * Description:   货物不合格登记模型
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-25 上午11:42:47  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-25      才江男                      1.0         1.0 Version  
 */
public class GoodsResultRegisterModel implements java.io.Serializable {

	private static final long serialVersionUID = -4570696638723749108L;
	private String resultGoodsId;//货物id
	private String declNo;//报检单号
	private String goodsNo;//货物序号
	
	private String inpUnqualHaCode;//检验不合格处理
	private String inpUnqualHaName;//检验不合格处理名称
	private Double inspUnquafWt;//检验不合格重量
	private Double unqulCommInsQty;//检验不合格数量
	private Double inspUnquaAmt;//检验不合格金额
	private String inspUnqResn;//检验不合格原因
	private String inspUnqResnName;//检验不合格原因名称
	private String inspDisquaContCodes;//检验不合格内容
	private String inspDisquaContNames;//检验不合格内容名称

	private String qurUnqProcCode;//检疫不合格处理
	private String qurUnqProcName;//检疫不合格处理名称
	private String speQuarTrmtMecC;//检疫不合格处理方法
	private String speQuarTrmtMecCName;//检疫不合格处理方法名称
	private Double quaranUnquaWt;//检疫不合格重量
	private Double unqulfdQuarQty;//检疫不合格数量
	private Double unqualQuarAmt;//检疫不合格金额
	private String qurUnqulRsnCode;//检疫不合格原因
	private String qurUnqulRsnName;//检疫不合格原因名称
	private String quarDisquaContCodes;//检疫不合格内容
	private String quarDisquaContNames;//检疫不合格内容名称

	private Double unqualQty;//综合不合格数量
	private Double unqualAmt;//综合不合格金额
	private Double unquaWt;//综合不合格重量
	
	private String wtUnitCode;//重量单位
	private String qtyUnitName;//数量单位
	private String currency;//货币种类
	
	private String mesuUnTypCode;//计量单位类别

	// Constructors

	/** default constructor */
	public GoodsResultRegisterModel() {
	}

	
	public String getMesuUnTypCode() {
		return mesuUnTypCode;
	}


	public void setMesuUnTypCode(String mesuUnTypCode) {
		this.mesuUnTypCode = mesuUnTypCode;
	}


	public Double getInspUnquafWt() {
		return inspUnquafWt;
	}


	public void setInspUnquafWt(Double inspUnquafWt) {
		this.inspUnquafWt = inspUnquafWt;
	}


	public Double getQuaranUnquaWt() {
		return quaranUnquaWt;
	}


	public void setQuaranUnquaWt(Double quaranUnquaWt) {
		this.quaranUnquaWt = quaranUnquaWt;
	}


	public Double getUnquaWt() {
		return unquaWt;
	}


	public void setUnquaWt(Double unquaWt) {
		this.unquaWt = unquaWt;
	}


	public String getWtUnitCode() {
		return wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	public String getQtyUnitName() {
		return qtyUnitName;
	}

	public void setQtyUnitName(String qtyUnitName) {
		this.qtyUnitName = qtyUnitName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getResultGoodsId() {
		return resultGoodsId;
	}

	public void setResultGoodsId(String resultGoodsId) {
		this.resultGoodsId = resultGoodsId;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getInpUnqualHaCode() {
		return inpUnqualHaCode;
	}

	public void setInpUnqualHaCode(String inpUnqualHaCode) {
		this.inpUnqualHaCode = inpUnqualHaCode;
	}

	public String getInpUnqualHaName() {
		return inpUnqualHaName;
	}

	public void setInpUnqualHaName(String inpUnqualHaName) {
		this.inpUnqualHaName = inpUnqualHaName;
	}

	public Double getUnqulCommInsQty() {
		return unqulCommInsQty;
	}

	public void setUnqulCommInsQty(Double unqulCommInsQty) {
		this.unqulCommInsQty = unqulCommInsQty;
	}

	public Double getInspUnquaAmt() {
		return inspUnquaAmt;
	}

	public void setInspUnquaAmt(Double inspUnquaAmt) {
		this.inspUnquaAmt = inspUnquaAmt;
	}

	public String getInspUnqResn() {
		return inspUnqResn;
	}

	public void setInspUnqResn(String inspUnqResn) {
		this.inspUnqResn = inspUnqResn;
	}

	public String getInspUnqResnName() {
		return inspUnqResnName;
	}

	public void setInspUnqResnName(String inspUnqResnName) {
		this.inspUnqResnName = inspUnqResnName;
	}

	public String getInspDisquaContCodes() {
		return inspDisquaContCodes;
	}

	public void setInspDisquaContCodes(String inspDisquaContCodes) {
		this.inspDisquaContCodes = inspDisquaContCodes;
	}

	public String getInspDisquaContNames() {
		return inspDisquaContNames;
	}

	public void setInspDisquaContNames(String inspDisquaContNames) {
		this.inspDisquaContNames = inspDisquaContNames;
	}

	public String getQurUnqProcCode() {
		return qurUnqProcCode;
	}

	public void setQurUnqProcCode(String qurUnqProcCode) {
		this.qurUnqProcCode = qurUnqProcCode;
	}

	public String getQurUnqProcName() {
		return qurUnqProcName;
	}

	public void setQurUnqProcName(String qurUnqProcName) {
		this.qurUnqProcName = qurUnqProcName;
	}

	public String getSpeQuarTrmtMecC() {
		return speQuarTrmtMecC;
	}

	public void setSpeQuarTrmtMecC(String speQuarTrmtMecC) {
		this.speQuarTrmtMecC = speQuarTrmtMecC;
	}

	public String getSpeQuarTrmtMecCName() {
		return speQuarTrmtMecCName;
	}

	public void setSpeQuarTrmtMecCName(String speQuarTrmtMecCName) {
		this.speQuarTrmtMecCName = speQuarTrmtMecCName;
	}

	public Double getUnqulfdQuarQty() {
		return unqulfdQuarQty;
	}

	public void setUnqulfdQuarQty(Double unqulfdQuarQty) {
		this.unqulfdQuarQty = unqulfdQuarQty;
	}

	public Double getUnqualQuarAmt() {
		return unqualQuarAmt;
	}

	public void setUnqualQuarAmt(Double unqualQuarAmt) {
		this.unqualQuarAmt = unqualQuarAmt;
	}

	public String getQurUnqulRsnCode() {
		return qurUnqulRsnCode;
	}

	public void setQurUnqulRsnCode(String qurUnqulRsnCode) {
		this.qurUnqulRsnCode = qurUnqulRsnCode;
	}

	public String getQurUnqulRsnName() {
		return qurUnqulRsnName;
	}

	public void setQurUnqulRsnName(String qurUnqulRsnName) {
		this.qurUnqulRsnName = qurUnqulRsnName;
	}

	public String getQuarDisquaContCodes() {
		return quarDisquaContCodes;
	}

	public void setQuarDisquaContCodes(String quarDisquaContCodes) {
		this.quarDisquaContCodes = quarDisquaContCodes;
	}

	public String getQuarDisquaContNames() {
		return quarDisquaContNames;
	}

	public void setQuarDisquaContNames(String quarDisquaContNames) {
		this.quarDisquaContNames = quarDisquaContNames;
	}

	public Double getUnqualQty() {
		return unqualQty;
	}

	public void setUnqualQty(Double unqualQty) {
		this.unqualQty = unqualQty;
	}

	public Double getUnqualAmt() {
		return unqualAmt;
	}

	public void setUnqualAmt(Double unqualAmt) {
		this.unqualAmt = unqualAmt;
	}

}
package com.rongji.eciq.mobile.model.insp.scene;

/**
 * 查验项目model
 * @author 吴有根
 * Modification History:  
 * Date        Author     Version     Description  
 * ------------------------------------------------------------------  
 * 20170413    李晨阳                       1.0        添加-是否合格代码、抽样方案类别代码-两个字段
 */
public class InsCheckItemModel {
	private String checkItemId;
	private String checkItemCode;//查验项目编号
	private String checkItemName;//查验项目名称
	private String goodsNo;//货物编号
	private String checkCont;//查验内容
	private String whetherQualfy;//是否合格
	private String whetherQualfyCode;//是否合格代码
	private String batchDesc;//查验情况描述
	private String sampleSch;//抽样方案类别
	private String sampleSchCode;//抽样方案类别代码
	private String formName;//表单名称
	private String addInputFlag;//是否补录
	private String parentItemCode;//父节点项目代码
	private String nodeCode;//节点代码
	
	//private InsCheckItemModel insCheckItemModel;
	
//	public InsCheckItemModel getInsCheckItemModel() {
//		return insCheckItemModel;
//	}
//	public void setInsCheckItemModel(InsCheckItemModel insCheckItemModel) {
//		this.insCheckItemModel = insCheckItemModel;
//	}
	
	public String getNodeCode() {
		return nodeCode;
	}
	public String getCheckItemId() {
		return checkItemId;
	}
	public void setCheckItemId(String checkItemId) {
		this.checkItemId = checkItemId;
	}
	public String getCheckItemCode() {
		return checkItemCode;
	}
	public void setCheckItemCode(String checkItemCode) {
		this.checkItemCode = checkItemCode;
	}
	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode;
	}
	public String getParentItemCode() {
		return parentItemCode;
	}
	public void setParentItemCode(String parentItemCode) {
		this.parentItemCode = parentItemCode;
	}
	public String getCheckItemName() {
		return checkItemName;
	}
	public void setCheckItemName(String checkItemName) {
		this.checkItemName = checkItemName;
	}
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}
	public String getCheckCont() {
		return checkCont;
	}
	public void setCheckCont(String checkCont) {
		this.checkCont = checkCont;
	}
	public String getWhetherQualfy() {
		return whetherQualfy;
	}
	public void setWhetherQualfy(String whetherQualfy) {
		this.whetherQualfy = whetherQualfy;
	}
	public String getWhetherQualfyCode() {
		return whetherQualfyCode;
	}
	public void setWhetherQualfyCode(String whetherQualfyCode) {
		this.whetherQualfyCode = whetherQualfyCode;
	}
	public String getBatchDesc() {
		return batchDesc;
	}
	public void setBatchDesc(String batchDesc) {
		this.batchDesc = batchDesc;
	}
	public String getSampleSch() {
		return sampleSch;
	}
	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}
	public String getSampleSchCode() {
		return sampleSchCode;
	}
	public void setSampleSchCode(String sampleSchCode) {
		this.sampleSchCode = sampleSchCode;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getAddInputFlag() {
		return addInputFlag;
	}
	public void setAddInputFlag(String addInputFlag) {
		this.addInputFlag = addInputFlag;
	}
	
	
}

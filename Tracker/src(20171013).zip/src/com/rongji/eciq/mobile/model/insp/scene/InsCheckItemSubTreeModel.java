package com.rongji.eciq.mobile.model.insp.scene;

import com.rongji.eciq.mobile.entity.InsCheckItemEntity;

/**
 * 现场查验-口岸查验-查验项目子节点树
 * @author 吴有根
 * @since  1.0
 */
public class InsCheckItemSubTreeModel extends InsCheckItemModel {

	private Object sub;

	public Object getSub() {
		return sub;
	}

	public void setSub(Object sub) {
		this.sub = sub;
	}
	
}

/**  
 * FileName:  InsContainerResultModel.java   
 * @Description: 集装箱不合格登记-集装箱信息model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月15日 下午3:46:41  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;


/**  
 * Description: 集装箱不合格登记-集装箱信息model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月15日 下午3:46:41  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-15      吴有根                      1.0         1.0 Version  
 */

public class InsContainerResultModel {

	private String contResultId;//集装箱UID
	private String cntnrModeCode;//集装箱规格
	private String cntnrModeCodeName;//集装箱规格名称
	private String contNo;//集装箱号码
	private String lclFlag;//是否拼箱
	private String heavyFlag;//是否重箱
	private String emptyFlag;//是否空箱
	private String contCategory;//集装箱种类
	private String healthInsUnqualFlag;//是否卫生检疫不合格
	private String pamQuaUnqualFlag;//是否动植物检疫不合格
	private String quaDisposeFlag;//是否检疫处理
	
	public String getCntnrModeCode() {
		return cntnrModeCode;
	}
	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getLclFlag() {
		return lclFlag;
	}
	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}
	public String getHeavyFlag() {
		return heavyFlag;
	}
	public void setHeavyFlag(String heavyFlag) {
		this.heavyFlag = heavyFlag;
	}
	public String getEmptyFlag() {
		return emptyFlag;
	}
	public void setEmptyFlag(String emptyFlag) {
		this.emptyFlag = emptyFlag;
	}
	public String getContCategory() {
		return contCategory;
	}
	public void setContCategory(String contCategory) {
		this.contCategory = contCategory;
	}
	public String getHealthInsUnqualFlag() {
		return healthInsUnqualFlag;
	}
	public void setHealthInsUnqualFlag(String healthInsUnqualFlag) {
		this.healthInsUnqualFlag = healthInsUnqualFlag;
	}
	public String getPamQuaUnqualFlag() {
		return pamQuaUnqualFlag;
	}
	public void setPamQuaUnqualFlag(String pamQuaUnqualFlag) {
		this.pamQuaUnqualFlag = pamQuaUnqualFlag;
	}
	public String getQuaDisposeFlag() {
		return quaDisposeFlag;
	}
	public void setQuaDisposeFlag(String quaDisposeFlag) {
		this.quaDisposeFlag = quaDisposeFlag;
	}
	public String getCntnrModeCodeName() {
		return cntnrModeCodeName;
	}
	public void setCntnrModeCodeName(String cntnrModeCodeName) {
		this.cntnrModeCodeName = cntnrModeCodeName;
	}
	public String getContResultId() {
		return contResultId;
	}
	public void setContResultId(String contResultId) {
		this.contResultId = contResultId;
	}
	
}

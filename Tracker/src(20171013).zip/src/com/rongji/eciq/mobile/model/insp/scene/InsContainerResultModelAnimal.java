/**  
 * FileName:  InsContainerResultModelAnimal.java   
 * @Description: 集装箱不合格登记-动植物检疫情况model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月16日 上午10:51:29  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 集装箱不合格登记-动植物检疫情况model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月16日 上午10:51:29  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-16      吴有根                      1.0         1.0 Version  
 */

public class InsContainerResultModelAnimal {

	private String pamUnqualReasonCodes;//动植物检疫不合格原因
	private String pamTrtMethCodes;//处理方法
	private String pamTrtMethCodesName;//处理方法名称
	private String pamTrtOrgCode;//除害处理机构
	private String pamTrtOrgCodeName;//除害处理机构名称
	public String getPamUnqualReasonCodes() {
		return pamUnqualReasonCodes;
	}
	public void setPamUnqualReasonCodes(String pamUnqualReasonCodes) {
		this.pamUnqualReasonCodes = pamUnqualReasonCodes;
	}
	public String getPamTrtMethCodes() {
		return pamTrtMethCodes;
	}
	public void setPamTrtMethCodes(String pamTrtMethCodes) {
		this.pamTrtMethCodes = pamTrtMethCodes;
	}
	public String getPamTrtOrgCode() {
		return pamTrtOrgCode;
	}
	public void setPamTrtOrgCode(String pamTrtOrgCode) {
		this.pamTrtOrgCode = pamTrtOrgCode;
	}
	public String getPamTrtMethCodesName() {
		return pamTrtMethCodesName;
	}
	public void setPamTrtMethCodesName(String pamTrtMethCodesName) {
		this.pamTrtMethCodesName = pamTrtMethCodesName;
	}
	public String getPamTrtOrgCodeName() {
		return pamTrtOrgCodeName;
	}
	public void setPamTrtOrgCodeName(String pamTrtOrgCodeName) {
		this.pamTrtOrgCodeName = pamTrtOrgCodeName;
	}
	
	
}

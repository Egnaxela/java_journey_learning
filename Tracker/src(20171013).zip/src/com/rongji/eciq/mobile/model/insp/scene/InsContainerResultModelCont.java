/**  
 * FileName:  InsContainerResultModelCont.java   
 * @Description: 集装箱不合格登记-集装箱检疫情况model  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月16日 上午10:46:01  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 集装箱不合格登记-集装箱检疫情况model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月16日 上午10:46:01  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-16      吴有根                      1.0         1.0 Version  
 */

public class InsContainerResultModelCont {
	private String cntnrUnqlResnC;//集装箱检疫不合格原因
	private String cntnrUnqlResnCName;//集装箱检疫不合格原因名称
//	private String cargDisqualItemOne;//适载检验不合格原因
//	private String cargDisqualItemOneName;//适载检验不合格原因名称
	private String epidSituCatg;//疫情种类
	private String epidSituCatgName;//疫情种类名称
	private String cntnrTreatCodes;//检疫处理措施
	private String cntnrTreatCodesName;//检疫处理措施名称
	private String contQuarUnqualDesc;//不合格原因描述
	public String getCntnrUnqlResnC() {
		return cntnrUnqlResnC;
	}
	public void setCntnrUnqlResnC(String cntnrUnqlResnC) {
		this.cntnrUnqlResnC = cntnrUnqlResnC;
	}
//	public String getCargDisqualItemOne() {
//		return cargDisqualItemOne;
//	}
//	public void setCargDisqualItemOne(String cargDisqualItemOne) {
//		this.cargDisqualItemOne = cargDisqualItemOne;
//	}
	public String getEpidSituCatg() {
		return epidSituCatg;
	}
	public void setEpidSituCatg(String epidSituCatg) {
		this.epidSituCatg = epidSituCatg;
	}
	public String getCntnrTreatCodes() {
		return cntnrTreatCodes;
	}
	public void setCntnrTreatCodes(String cntnrTreatCodes) {
		this.cntnrTreatCodes = cntnrTreatCodes;
	}
	public String getContQuarUnqualDesc() {
		return contQuarUnqualDesc;
	}
	public void setContQuarUnqualDesc(String contQuarUnqualDesc) {
		this.contQuarUnqualDesc = contQuarUnqualDesc;
	}
	public String getCntnrUnqlResnCName() {
		return cntnrUnqlResnCName;
	}
	public void setCntnrUnqlResnCName(String cntnrUnqlResnCName) {
		this.cntnrUnqlResnCName = cntnrUnqlResnCName;
	}
//	public String getCargDisqualItemOneName() {
//		return cargDisqualItemOneName;
//	}
//	public void setCargDisqualItemOneName(String cargDisqualItemOneName) {
//		this.cargDisqualItemOneName = cargDisqualItemOneName;
//	}
	public String getEpidSituCatgName() {
		return epidSituCatgName;
	}
	public void setEpidSituCatgName(String epidSituCatgName) {
		this.epidSituCatgName = epidSituCatgName;
	}
	public String getCntnrTreatCodesName() {
		return cntnrTreatCodesName;
	}
	public void setCntnrTreatCodesName(String cntnrTreatCodesName) {
		this.cntnrTreatCodesName = cntnrTreatCodesName;
	}
	
	

}

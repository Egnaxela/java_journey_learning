/**  
 * FileName: InsContainerResultModelDetail.java    
 * @Description: 集装箱不合格登记详细信息model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月15日 下午7:20:40  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;


/**  
 * Description: 集装箱不合格登记详细信息model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月15日 下午7:20:40  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-15      吴有根                      1.0         1.0 Version  
 */

public class InsContainerResultModelDetail {

	//详细信息
	private String regNum;//登记编号
	private String declNo;//报检单号
	private String expImpFlag;//出入境标记
	private String   contOpetnTime;//查验日期
	private String billLadNo;//提运单号
	private String cntnrModeCode;// 集装箱规格代码
	private String cntnrModeCodeName;// 集装箱规格名称
	private String contNo;// 集装箱号码
	private String contCategory;// 集装箱类别
	private String contCategoryName;// 集装箱类别名称
	private String lclFlag;//是否拼箱
	private String boxCompany;//箱所属公司
	private String tradeCountryCode;//来源国家和地区
	private String tradeCountryCodeName;//来源国家和地区名称
	public String getRegNum() {
		return regNum;
	}
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getExpImpFlag() {
		return expImpFlag;
	}
	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}
	public String getContOpetnTime() {
		return contOpetnTime;
	}
	public void setContOpetnTime(String contOpetnTime) {
		this.contOpetnTime = contOpetnTime;
	}
	public String getBillLadNo() {
		return billLadNo;
	}
	public void setBillLadNo(String billLadNo) {
		this.billLadNo = billLadNo;
	}
	public String getCntnrModeCode() {
		return cntnrModeCode;
	}
	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}
	public String getCntnrModeCodeName() {
		return cntnrModeCodeName;
	}
	public void setCntnrModeCodeName(String cntnrModeCodeName) {
		this.cntnrModeCodeName = cntnrModeCodeName;
	}
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getContCategory() {
		return contCategory;
	}
	public void setContCategory(String contCategory) {
		this.contCategory = contCategory;
	}
	public String getContCategoryName() {
		return contCategoryName;
	}
	public void setContCategoryName(String contCategoryName) {
		this.contCategoryName = contCategoryName;
	}
	public String getLclFlag() {
		return lclFlag;
	}
	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}
	public String getBoxCompany() {
		return boxCompany;
	}
	public void setBoxCompany(String boxCompany) {
		this.boxCompany = boxCompany;
	}
	public String getTradeCountryCode() {
		return tradeCountryCode;
	}
	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}
	public String getTradeCountryCodeName() {
		return tradeCountryCodeName;
	}
	public void setTradeCountryCodeName(String tradeCountryCodeName) {
		this.tradeCountryCodeName = tradeCountryCodeName;
	}
	
	
}

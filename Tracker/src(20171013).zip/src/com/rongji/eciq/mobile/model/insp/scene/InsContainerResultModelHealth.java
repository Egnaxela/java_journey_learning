/**  
 * FileName: InsContainerResultModelHealth.java    
 * @Description: 集装箱不合格登记-卫生检疫查验情况model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月16日 上午10:48:41  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 集装箱不合格登记-卫生检疫查验情况model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月16日 上午10:48:41  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-16      吴有根                      1.0         1.0 Version  
 */

public class InsContainerResultModelHealth {
	
	private String quarUnqualReasonCode;//卫生检疫查验不合格原因
	private String quarUnqualReasonCodeName;//卫生检疫查验不合格原因名称
	private String quarUnqualContentCodes;//卫生检疫查验不合格内容
	private String sanitTrtMethCodes;//卫生除害处理方法
	private String sanitTrtMethCodesName;//卫生除害处理方法名称
	private String sntTrtOrgCode;//卫生除害处理机构
	private String sntTrtOrgCodeName;//卫生除害处理机构名称
	public String getQuarUnqualReasonCode() {
		return quarUnqualReasonCode;
	}
	public void setQuarUnqualReasonCode(String quarUnqualReasonCode) {
		this.quarUnqualReasonCode = quarUnqualReasonCode;
	}
	public String getQuarUnqualContentCodes() {
		return quarUnqualContentCodes;
	}
	public void setQuarUnqualContentCodes(String quarUnqualContentCodes) {
		this.quarUnqualContentCodes = quarUnqualContentCodes;
	}
	public String getSanitTrtMethCodes() {
		return sanitTrtMethCodes;
	}
	public void setSanitTrtMethCodes(String sanitTrtMethCodes) {
		this.sanitTrtMethCodes = sanitTrtMethCodes;
	}
	public String getSntTrtOrgCode() {
		return sntTrtOrgCode;
	}
	public void setSntTrtOrgCode(String sntTrtOrgCode) {
		this.sntTrtOrgCode = sntTrtOrgCode;
	}
	public String getQuarUnqualReasonCodeName() {
		return quarUnqualReasonCodeName;
	}
	public void setQuarUnqualReasonCodeName(String quarUnqualReasonCodeName) {
		this.quarUnqualReasonCodeName = quarUnqualReasonCodeName;
	}
	public String getSanitTrtMethCodesName() {
		return sanitTrtMethCodesName;
	}
	public void setSanitTrtMethCodesName(String sanitTrtMethCodesName) {
		this.sanitTrtMethCodesName = sanitTrtMethCodesName;
	}
	public String getSntTrtOrgCodeName() {
		return sntTrtOrgCodeName;
	}
	public void setSntTrtOrgCodeName(String sntTrtOrgCodeName) {
		this.sntTrtOrgCodeName = sntTrtOrgCodeName;
	}
	
	
	
}

package com.rongji.eciq.mobile.model.insp.scene;

/**
 * 现场查验-货物信息查看model
 * @author 吴有根
 * Modification History:  
 * Date        Author     Version     Description  
 * ------------------------------------------------------------------  
 * 20170413    李晨阳                       1.0        添加-检疫结果代码、检验结果代码、检验方式代码-三个字段
 */
public class InsResultGoodsModel {

	private String declNo;//报检单号
	private String goodsNo;//货物序号
	private String goodsNameCn;//货物名称
	private String statKindCode;//商品统计分类代码
	private String declGoodsValues;//报检货物总值
	private String currency;//币种
	private String goodsTotalVal;//实际货币总值
	private String packQty;//包装件数量
	private String riskInfoLevelCode;//产品风险等级
	private String inspRequire;//检验要求
	private String batchRatio;//抽批率
	private String realWeight;//实际重量
	private String actualQty;//实际数量
	private String actSmplNum;//实际抽样量
    private String quarResSpot;//检疫结果
    private String quarResSpotCode;//检疫结果代码
    private String inspResSpot;//检验结果
    private String inspResSpotCode;//检验结果代码
    private String inspPattern;//检验方式
    private String inspPatternCode;//检验方式代码
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}
	public String getGoodsNameCn() {
		return goodsNameCn;
	}
	public void setGoodsNameCn(String goodsNameCn) {
		this.goodsNameCn = goodsNameCn;
	}
	public String getStatKindCode() {
		return statKindCode;
	}
	public void setStatKindCode(String statKindCode) {
		this.statKindCode = statKindCode;
	}
	public String getDeclGoodsValues() {
		return declGoodsValues;
	}
	public void setDeclGoodsValues(String declGoodsValues) {
		this.declGoodsValues = declGoodsValues;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getGoodsTotalVal() {
		return goodsTotalVal;
	}
	public void setGoodsTotalVal(String goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}
	public String getPackQty() {
		return packQty;
	}
	public void setPackQty(String packQty) {
		this.packQty = packQty;
	}
	public String getRiskInfoLevelCode() {
		return riskInfoLevelCode;
	}
	public void setRiskInfoLevelCode(String riskInfoLevelCode) {
		this.riskInfoLevelCode = riskInfoLevelCode;
	}
	public String getInspRequire() {
		return inspRequire;
	}
	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}
	public String getBatchRatio() {
		return batchRatio;
	}
	public void setBatchRatio(String batchRatio) {
		this.batchRatio = batchRatio;
	}
	public String getRealWeight() {
		return realWeight;
	}
	public void setRealWeight(String realWeight) {
		this.realWeight = realWeight;
	}
	public String getActualQty() {
		return actualQty;
	}
	public void setActualQty(String actualQty) {
		this.actualQty = actualQty;
	}
	public String getActSmplNum() {
		return actSmplNum;
	}
	public void setActSmplNum(String actSmplNum) {
		this.actSmplNum = actSmplNum;
	}
	public String getQuarResSpot() {
		return quarResSpot;
	}
	public void setQuarResSpot(String quarResSpot) {
		this.quarResSpot = quarResSpot;
	}
	public String getQuarResSpotCode() {
		return quarResSpotCode;
	}
	public void setQuarResSpotCode(String quarResSpotCode) {
		this.quarResSpotCode = quarResSpotCode;
	}
	public String getInspResSpot() {
		return inspResSpot;
	}
	public void setInspResSpot(String inspResSpot) {
		this.inspResSpot = inspResSpot;
	}
	public String getInspResSpotCode() {
		return inspResSpotCode;
	}
	public void setInspResSpotCode(String inspResSpotCode) {
		this.inspResSpotCode = inspResSpotCode;
	}
	public String getInspPattern() {
		return inspPattern;
	}
	public void setInspPattern(String inspPattern) {
		this.inspPattern = inspPattern;
	}
	public String getInspPatternCode() {
		return inspPatternCode;
	}
	public void setInspPatternCode(String inspPatternCode) {
		this.inspPatternCode = inspPatternCode;
	}
    
	
	
	
}

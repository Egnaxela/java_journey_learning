/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      weibo  
 * @version:     1.0
 * Createdate:   2017-7-24 下午4:53:21  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

import java.math.BigDecimal;
import java.util.Date;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo  
 * @version:    1.0  
 * Create at:   2017-7-24 下午4:53:21  
 *  
 */

public class InsResultRecordItemModel {

	private String entUuid;
	private BigDecimal resultRecordItemId;
	private String resultRecordId;
	private String itemCode;
	private String defectCode;
	private String sampleSch;
	private String inspEval;
	private String remark;
	private Date operDate;
	private String flagArchive;
	private BigDecimal smplNum;
	private String sampleSchName;
	public InsResultRecordItemModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public InsResultRecordItemModel(String entUuid,
			BigDecimal resultRecordItemId, String resultRecordId,
			String itemCode, String defectCode, String sampleSch,
			String inspEval, String remark, Date operDate, String flagArchive,
			BigDecimal smplNum, String sampleSchName) {
		super();
		this.entUuid = entUuid;
		this.resultRecordItemId = resultRecordItemId;
		this.resultRecordId = resultRecordId;
		this.itemCode = itemCode;
		this.defectCode = defectCode;
		this.sampleSch = sampleSch;
		this.inspEval = inspEval;
		this.remark = remark;
		this.operDate = operDate;
		this.flagArchive = flagArchive;
		this.smplNum = smplNum;
		this.sampleSchName = sampleSchName;
	}
	public String getEntUuid() {
		return entUuid;
	}
	public void setEntUuid(String entUuid) {
		this.entUuid = entUuid;
	}
	public BigDecimal getResultRecordItemId() {
		return resultRecordItemId;
	}
	public void setResultRecordItemId(BigDecimal resultRecordItemId) {
		this.resultRecordItemId = resultRecordItemId;
	}
	public String getResultRecordId() {
		return resultRecordId;
	}
	public void setResultRecordId(String resultRecordId) {
		this.resultRecordId = resultRecordId;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDefectCode() {
		return defectCode;
	}
	public void setDefectCode(String defectCode) {
		this.defectCode = defectCode;
	}
	public String getSampleSch() {
		return sampleSch;
	}
	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}
	public String getInspEval() {
		return inspEval;
	}
	public void setInspEval(String inspEval) {
		this.inspEval = inspEval;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getOperDate() {
		return operDate;
	}
	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}
	public String getFlagArchive() {
		return flagArchive;
	}
	public void setFlagArchive(String flagArchive) {
		this.flagArchive = flagArchive;
	}
	public BigDecimal getSmplNum() {
		return smplNum;
	}
	public void setSmplNum(BigDecimal smplNum) {
		this.smplNum = smplNum;
	}
	public String getSampleSchName() {
		return sampleSchName;
	}
	public void setSampleSchName(String sampleSchName) {
		this.sampleSchName = sampleSchName;
	}
	
	
}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      weibo 
 * @version:     1.0
 * Createdate:   2017-7-24 下午4:52:47  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

import java.math.BigDecimal;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo
 * @version:    1.0  
 * Create at:   2017-7-24 下午4:52:47  
 *  
 */

public class InsResultRecordModel {

	private String resultRecordId;
	private String insDate;
	private String declNo;
	private String dandNo;
	private String entName;
	private String batchNo;
	private String tradeCountry;
	private String prodLevel;
	private BigDecimal qty;
	private BigDecimal weight;
	private String container;
	private String unNo;
	private BigDecimal packLength;
	private BigDecimal packWidth;
	private BigDecimal packHeight;
	private Double weightGross;
	private Double weightNet;
	private String content;
	private String shipMark;
	private String prodType;
	private String prodDesc;
	private String goodsNo;
	private String inspBasCatCode;
	private String dangBasCatCode;
	private String detectFlag;
	private String detectResult;
	private BigDecimal dangSmplNum;
	private String isMatch;
	private String isCover;
	private String isHold;
	private String isClean;
	private String isContain;
	private String isSuit;
	private String isTag;
	private String isLess;
	private String isNail;
	private String inspMode;
	private String inspDefect;
	private String dangDefect;
	private String inspCommEval;
	private String fireworkEval;
	private String dangEval;
	private String hugeFirework;
	private String inspEval;
	private String specCheckNo;
	private String dropCheckNo;
	private String specCheckDate;
	private String dropCheckDate;
	private String drugSafeNo;
	private String drugProhNo;
	private String drugSafeDate;
	private String drugProhDate;
	private String remark;
	private String operDate;
	private String flagArchive;
	private String unName;
	private String prodName;
	private String inspBasCatName;
	private String dangBasCatName;
	private String inspOthCatCode;
	private String inspOthCatName;
	private String dangSmplNo;
	private String inspCommEvalName;
	private String fireworkEvalName;
	private String dangEvalName;
	private String inspEvalName;
	private BigDecimal containerGy;
	private BigDecimal containerS;
	private BigDecimal containerCn;
	private BigDecimal containerBlk;
	private BigDecimal containerPi;
	

	public InsResultRecordModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public InsResultRecordModel(String resultRecordId, String insDate,
			String declNo, String dandNo, String entName, String batchNo,
			String tradeCountry, String prodLevel, BigDecimal qty,
			BigDecimal weight, String container, String unNo,
			BigDecimal packLength, BigDecimal packWidth, BigDecimal packHeight,
			Double weightGross, Double weightNet, String content,
			String shipMark, String prodType, String prodDesc, String goodsNo,
			String inspBasCatCode, String dangBasCatCode, String detectFlag,
			String detectResult, BigDecimal dangSmplNum, String isMatch,
			String isCover, String isHold, String isClean, String isContain,
			String isSuit, String isTag, String isLess, String isNail,
			String inspMode, String inspDefect, String dangDefect,
			String inspCommEval, String fireworkEval, String dangEval,
			String hugeFirework, String inspEval, String specCheckNo,
			String dropCheckNo, String specCheckDate, String dropCheckDate,
			String drugSafeNo, String drugProhNo, String drugSafeDate,
			String drugProhDate, String remark, String operDate,
			String flagArchive, String unName, String prodName,
			String inspBasCatName, String dangBasCatName,
			String inspOthCatCode, String inspOthCatName, String dangSmplNo,
			String inspCommEvalName, String fireworkEvalName,
			String dangEvalName, String inspEvalName, BigDecimal containerGy,
			BigDecimal containerS, BigDecimal containerCn,
			BigDecimal containerBlk, BigDecimal containerPi) {
		super();
		this.resultRecordId = resultRecordId;
		this.insDate = insDate;
		this.declNo = declNo;
		this.dandNo = dandNo;
		this.entName = entName;
		this.batchNo = batchNo;
		this.tradeCountry = tradeCountry;
		this.prodLevel = prodLevel;
		this.qty = qty;
		this.weight = weight;
		this.container = container;
		this.unNo = unNo;
		this.packLength = packLength;
		this.packWidth = packWidth;
		this.packHeight = packHeight;
		this.weightGross = weightGross;
		this.weightNet = weightNet;
		this.content = content;
		this.shipMark = shipMark;
		this.prodType = prodType;
		this.prodDesc = prodDesc;
		this.goodsNo = goodsNo;
		this.inspBasCatCode = inspBasCatCode;
		this.dangBasCatCode = dangBasCatCode;
		this.detectFlag = detectFlag;
		this.detectResult = detectResult;
		this.dangSmplNum = dangSmplNum;
		this.isMatch = isMatch;
		this.isCover = isCover;
		this.isHold = isHold;
		this.isClean = isClean;
		this.isContain = isContain;
		this.isSuit = isSuit;
		this.isTag = isTag;
		this.isLess = isLess;
		this.isNail = isNail;
		this.inspMode = inspMode;
		this.inspDefect = inspDefect;
		this.dangDefect = dangDefect;
		this.inspCommEval = inspCommEval;
		this.fireworkEval = fireworkEval;
		this.dangEval = dangEval;
		this.hugeFirework = hugeFirework;
		this.inspEval = inspEval;
		this.specCheckNo = specCheckNo;
		this.dropCheckNo = dropCheckNo;
		this.specCheckDate = specCheckDate;
		this.dropCheckDate = dropCheckDate;
		this.drugSafeNo = drugSafeNo;
		this.drugProhNo = drugProhNo;
		this.drugSafeDate = drugSafeDate;
		this.drugProhDate = drugProhDate;
		this.remark = remark;
		this.operDate = operDate;
		this.flagArchive = flagArchive;
		this.unName = unName;
		this.prodName = prodName;
		this.inspBasCatName = inspBasCatName;
		this.dangBasCatName = dangBasCatName;
		this.inspOthCatCode = inspOthCatCode;
		this.inspOthCatName = inspOthCatName;
		this.dangSmplNo = dangSmplNo;
		this.inspCommEvalName = inspCommEvalName;
		this.fireworkEvalName = fireworkEvalName;
		this.dangEvalName = dangEvalName;
		this.inspEvalName = inspEvalName;
		this.containerGy = containerGy;
		this.containerS = containerS;
		this.containerCn = containerCn;
		this.containerBlk = containerBlk;
		this.containerPi = containerPi;
	}


	public String getResultRecordId() {
		return resultRecordId;
	}

	public void setResultRecordId(String resultRecordId) {
		this.resultRecordId = resultRecordId;
	}

	public String getInsDate() {
		return insDate;
	}

	public void setInsDate(String insDate) {
		this.insDate = insDate;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getDandNo() {
		return dandNo;
	}

	public void setDandNo(String dandNo) {
		this.dandNo = dandNo;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getTradeCountry() {
		return tradeCountry;
	}

	public void setTradeCountry(String tradeCountry) {
		this.tradeCountry = tradeCountry;
	}

	public String getProdLevel() {
		return prodLevel;
	}

	public void setProdLevel(String prodLevel) {
		this.prodLevel = prodLevel;
	}

	public BigDecimal getQty() {
		return qty;
	}

	public void setQty(BigDecimal qty) {
		this.qty = qty;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public String getContainer() {
		return container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	public String getUnNo() {
		return unNo;
	}

	public void setUnNo(String unNo) {
		this.unNo = unNo;
	}

	public BigDecimal getPackLength() {
		return packLength;
	}

	public void setPackLength(BigDecimal packLength) {
		this.packLength = packLength;
	}

	public BigDecimal getPackWidth() {
		return packWidth;
	}

	public void setPackWidth(BigDecimal packWidth) {
		this.packWidth = packWidth;
	}

	public BigDecimal getPackHeight() {
		return packHeight;
	}

	public void setPackHeight(BigDecimal packHeight) {
		this.packHeight = packHeight;
	}

	public Double getWeightGross() {
		return weightGross;
	}

	public void setWeightGross(Double weightGross) {
		this.weightGross = weightGross;
	}

	public Double getWeightNet() {
		return weightNet;
	}

	public void setWeightNet(Double weightNet) {
		this.weightNet = weightNet;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getShipMark() {
		return shipMark;
	}

	public void setShipMark(String shipMark) {
		this.shipMark = shipMark;
	}

	public String getProdType() {
		return prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getInspBasCatCode() {
		return inspBasCatCode;
	}

	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}

	public String getDangBasCatCode() {
		return dangBasCatCode;
	}

	public void setDangBasCatCode(String dangBasCatCode) {
		this.dangBasCatCode = dangBasCatCode;
	}

	public String getDetectFlag() {
		return detectFlag;
	}

	public void setDetectFlag(String detectFlag) {
		this.detectFlag = detectFlag;
	}

	public String getDetectResult() {
		return detectResult;
	}

	public void setDetectResult(String detectResult) {
		this.detectResult = detectResult;
	}

	public BigDecimal getDangSmplNum() {
		return dangSmplNum;
	}

	public void setDangSmplNum(BigDecimal dangSmplNum) {
		this.dangSmplNum = dangSmplNum;
	}

	public String getIsMatch() {
		return isMatch;
	}

	public void setIsMatch(String isMatch) {
		this.isMatch = isMatch;
	}

	public String getIsCover() {
		return isCover;
	}

	public void setIsCover(String isCover) {
		this.isCover = isCover;
	}

	public String getIsHold() {
		return isHold;
	}

	public void setIsHold(String isHold) {
		this.isHold = isHold;
	}

	public String getIsClean() {
		return isClean;
	}

	public void setIsClean(String isClean) {
		this.isClean = isClean;
	}

	public String getIsContain() {
		return isContain;
	}

	public void setIsContain(String isContain) {
		this.isContain = isContain;
	}

	public String getIsSuit() {
		return isSuit;
	}

	public void setIsSuit(String isSuit) {
		this.isSuit = isSuit;
	}

	public String getIsTag() {
		return isTag;
	}

	public void setIsTag(String isTag) {
		this.isTag = isTag;
	}

	public String getIsLess() {
		return isLess;
	}

	public void setIsLess(String isLess) {
		this.isLess = isLess;
	}

	public String getIsNail() {
		return isNail;
	}

	public void setIsNail(String isNail) {
		this.isNail = isNail;
	}

	public String getInspMode() {
		return inspMode;
	}

	public void setInspMode(String inspMode) {
		this.inspMode = inspMode;
	}

	public String getInspDefect() {
		return inspDefect;
	}

	public void setInspDefect(String inspDefect) {
		this.inspDefect = inspDefect;
	}

	public String getDangDefect() {
		return dangDefect;
	}

	public void setDangDefect(String dangDefect) {
		this.dangDefect = dangDefect;
	}

	public String getInspCommEval() {
		return inspCommEval;
	}

	public void setInspCommEval(String inspCommEval) {
		this.inspCommEval = inspCommEval;
	}

	public String getFireworkEval() {
		return fireworkEval;
	}

	public void setFireworkEval(String fireworkEval) {
		this.fireworkEval = fireworkEval;
	}

	public String getDangEval() {
		return dangEval;
	}

	public void setDangEval(String dangEval) {
		this.dangEval = dangEval;
	}

	public String getHugeFirework() {
		return hugeFirework;
	}

	public void setHugeFirework(String hugeFirework) {
		this.hugeFirework = hugeFirework;
	}

	public String getInspEval() {
		return inspEval;
	}

	public void setInspEval(String inspEval) {
		this.inspEval = inspEval;
	}

	public String getSpecCheckNo() {
		return specCheckNo;
	}

	public void setSpecCheckNo(String specCheckNo) {
		this.specCheckNo = specCheckNo;
	}

	public String getDropCheckNo() {
		return dropCheckNo;
	}

	public void setDropCheckNo(String dropCheckNo) {
		this.dropCheckNo = dropCheckNo;
	}

	public String getSpecCheckDate() {
		return specCheckDate;
	}

	public void setSpecCheckDate(String specCheckDate) {
		this.specCheckDate = specCheckDate;
	}

	public String getDropCheckDate() {
		return dropCheckDate;
	}

	public void setDropCheckDate(String dropCheckDate) {
		this.dropCheckDate = dropCheckDate;
	}

	public String getDrugSafeNo() {
		return drugSafeNo;
	}

	public void setDrugSafeNo(String drugSafeNo) {
		this.drugSafeNo = drugSafeNo;
	}

	public String getDrugProhNo() {
		return drugProhNo;
	}

	public void setDrugProhNo(String drugProhNo) {
		this.drugProhNo = drugProhNo;
	}

	public String getDrugSafeDate() {
		return drugSafeDate;
	}

	public void setDrugSafeDate(String drugSafeDate) {
		this.drugSafeDate = drugSafeDate;
	}

	public String getDrugProhDate() {
		return drugProhDate;
	}

	public void setDrugProhDate(String drugProhDate) {
		this.drugProhDate = drugProhDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getOperDate() {
		return operDate;
	}

	public void setOperDate(String operDate) {
		this.operDate = operDate;
	}

	public String getFlagArchive() {
		return flagArchive;
	}

	public void setFlagArchive(String flagArchive) {
		this.flagArchive = flagArchive;
	}

	public String getUnName() {
		return unName;
	}

	public void setUnName(String unName) {
		this.unName = unName;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getInspBasCatName() {
		return inspBasCatName;
	}

	public void setInspBasCatName(String inspBasCatName) {
		this.inspBasCatName = inspBasCatName;
	}

	public String getDangBasCatName() {
		return dangBasCatName;
	}

	public void setDangBasCatName(String dangBasCatName) {
		this.dangBasCatName = dangBasCatName;
	}

	public String getInspOthCatCode() {
		return inspOthCatCode;
	}

	public void setInspOthCatCode(String inspOthCatCode) {
		this.inspOthCatCode = inspOthCatCode;
	}

	public String getInspOthCatName() {
		return inspOthCatName;
	}

	public void setInspOthCatName(String inspOthCatName) {
		this.inspOthCatName = inspOthCatName;
	}

	public String getDangSmplNo() {
		return dangSmplNo;
	}

	public void setDangSmplNo(String dangSmplNo) {
		this.dangSmplNo = dangSmplNo;
	}

	public String getInspCommEvalName() {
		return inspCommEvalName;
	}

	public void setInspCommEvalName(String inspCommEvalName) {
		this.inspCommEvalName = inspCommEvalName;
	}

	public String getFireworkEvalName() {
		return fireworkEvalName;
	}

	public void setFireworkEvalName(String fireworkEvalName) {
		this.fireworkEvalName = fireworkEvalName;
	}

	public String getDangEvalName() {
		return dangEvalName;
	}

	public void setDangEvalName(String dangEvalName) {
		this.dangEvalName = dangEvalName;
	}

	public String getInspEvalName() {
		return inspEvalName;
	}

	public void setInspEvalName(String inspEvalName) {
		this.inspEvalName = inspEvalName;
	}


	public BigDecimal getContainerGy() {
		return containerGy;
	}


	public void setContainerGy(BigDecimal containerGy) {
		this.containerGy = containerGy;
	}


	public BigDecimal getContainerS() {
		return containerS;
	}


	public void setContainerS(BigDecimal containerS) {
		this.containerS = containerS;
	}


	public BigDecimal getContainerCn() {
		return containerCn;
	}


	public void setContainerCn(BigDecimal containerCn) {
		this.containerCn = containerCn;
	}


	public BigDecimal getContainerBlk() {
		return containerBlk;
	}


	public void setContainerBlk(BigDecimal containerBlk) {
		this.containerBlk = containerBlk;
	}


	public BigDecimal getContainerPi() {
		return containerPi;
	}


	public void setContainerPi(BigDecimal containerPi) {
		this.containerPi = containerPi;
	}
	
	
	
}

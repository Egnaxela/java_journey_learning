package com.rongji.eciq.mobile.model.insp.scene;

/**
 * 现场查验记录-结果model
 * @author 吴有根
 * @since  1.0
 *
 */
public class InsResultSumModel {
	private String checker;//查验人员
	private String checkerName;//查验人员名称
	private String insBeginDate;//查验日期
	private String inspEndDate;//检毕日期
	private String checkPlace;//查验地点
	private String inspBasCatCode;//检验依据代码
	private String inspBasCatName;//检验依据名称
	private String whether2ndIns;//是否二次查验
	private String kepIsolat;//隔离检疫
	private String weatherCode;//天气代码
	private String weatherName;//天气名称
	private String goodsEvalResult;//货物评定代码
	private String goodsEvalResultName;//货物评定名称
	private String spotDesc;//现场情况描述  VARCHAR2(4000)
	private String woodpackQuarResult;//木质包装检疫结果代码
	private String woodpackQuarResultName;//木质包装检疫结果名称
	private String contQuarResult;//集装箱检疫结果代码
	private String contQuarResultName;//集装箱检疫结果名称
	private boolean contQuarResultEditFlag;//集装箱检疫结果是否可以编辑状态
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public String getCheckerName() {
		return checkerName;
	}
	public void setCheckerName(String checkerName) {
		this.checkerName = checkerName;
	}
	public String getInsBeginDate() {
		return insBeginDate;
	}
	public void setInsBeginDate(String insBeginDate) {
		this.insBeginDate = insBeginDate;
	}
	public String getInspEndDate() {
		return inspEndDate;
	}
	public void setInspEndDate(String inspEndDate) {
		this.inspEndDate = inspEndDate;
	}
	public String getCheckPlace() {
		return checkPlace;
	}
	public void setCheckPlace(String checkPlace) {
		this.checkPlace = checkPlace;
	}
	public String getInspBasCatCode() {
		return inspBasCatCode;
	}
	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}
	public String getInspBasCatName() {
		return inspBasCatName;
	}
	public void setInspBasCatName(String inspBasCatName) {
		this.inspBasCatName = inspBasCatName;
	}
	public String getWhether2ndIns() {
		return whether2ndIns;
	}
	public void setWhether2ndIns(String whether2ndIns) {
		this.whether2ndIns = whether2ndIns;
	}
	public String getKepIsolat() {
		return kepIsolat;
	}
	public void setKepIsolat(String kepIsolat) {
		this.kepIsolat = kepIsolat;
	}
	public String getWeatherCode() {
		return weatherCode;
	}
	public void setWeatherCode(String weatherCode) {
		this.weatherCode = weatherCode;
	}
	public String getWeatherName() {
		return weatherName;
	}
	public void setWeatherName(String weatherName) {
		this.weatherName = weatherName;
	}
	public String getGoodsEvalResult() {
		return goodsEvalResult;
	}
	public void setGoodsEvalResult(String goodsEvalResult) {
		this.goodsEvalResult = goodsEvalResult;
	}
	public String getGoodsEvalResultName() {
		return goodsEvalResultName;
	}
	public void setGoodsEvalResultName(String goodsEvalResultName) {
		this.goodsEvalResultName = goodsEvalResultName;
	}
	public String getSpotDesc() {
		return spotDesc;
	}
	public void setSpotDesc(String spotDesc) {
		this.spotDesc = spotDesc;
	}
	public String getWoodpackQuarResult() {
		return woodpackQuarResult;
	}
	public void setWoodpackQuarResult(String woodpackQuarResult) {
		this.woodpackQuarResult = woodpackQuarResult;
	}
	public String getWoodpackQuarResultName() {
		return woodpackQuarResultName;
	}
	public void setWoodpackQuarResultName(String woodpackQuarResultName) {
		this.woodpackQuarResultName = woodpackQuarResultName;
	}
	public String getContQuarResult() {
		return contQuarResult;
	}
	public void setContQuarResult(String contQuarResult) {
		this.contQuarResult = contQuarResult;
	}
	public String getContQuarResultName() {
		return contQuarResultName;
	}
	public void setContQuarResultName(String contQuarResultName) {
		this.contQuarResultName = contQuarResultName;
	}
	public boolean getContQuarResultEditFlag() {
		return contQuarResultEditFlag;
	}
	public void setContQuarResultEditFlag(boolean contQuarResultEditFlag) {
		this.contQuarResultEditFlag = contQuarResultEditFlag;
	}
	
	
	
}

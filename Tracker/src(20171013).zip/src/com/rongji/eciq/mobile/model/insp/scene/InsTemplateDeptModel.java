/**  
 * FileName:     InsTemplateDeptModel.java
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 上午9:30:44  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

/**  
 * Description: 模板使用部门model 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 上午9:30:44  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */

public class InsTemplateDeptModel {
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

/**  
 * FileName:     InsTemplateModel.java
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 上午9:26:07  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.scene;

import java.math.BigDecimal;
import java.util.List;

/**  
 * Description: 模板model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 上午9:26:07  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */

public class InsTemplateModel {
	private String tmpltNo;//模板编号
	private String templateTitle;//模板标题
	private String whetherEffect;//是否有效
	private String templateType;//模板类别
	private String templateContent;//模板内容
	private List<InsTemplateDeptModel> deptList;
	public String getTmpltNo() {
		return tmpltNo;
	}
	public void setTmpltNo(String tmpltNo) {
		this.tmpltNo = tmpltNo;
	}
	public String getTemplateTitle() {
		return templateTitle;
	}
	public void setTemplateTitle(String templateTitle) {
		this.templateTitle = templateTitle;
	}
	public String getWhetherEffect() {
		return whetherEffect;
	}
	public void setWhetherEffect(String whetherEffect) {
		this.whetherEffect = whetherEffect;
	}
	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public String getTemplateContent() {
		return templateContent;
	}
	public void setTemplateContent(String templateContent) {
		this.templateContent = templateContent;
	}
	public List<InsTemplateDeptModel> getDeptList() {
		return deptList;
	}
	public void setDeptList(List<InsTemplateDeptModel> deptList) {
		this.deptList = deptList;
	}
	
}

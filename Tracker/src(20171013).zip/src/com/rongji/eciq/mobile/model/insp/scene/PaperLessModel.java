package com.rongji.eciq.mobile.model.insp.scene;

import java.util.Map;

/**
 * 查看无纸化信息model
 * @author 吴有根
 * @since  1.0
 */
public class PaperLessModel {

	private String paperLessUrl;//url
	private String title;//查看页面标头
	private String entDeclNo;//企业报检号
	private Map<String, String> map;
	private String orgCode;//机构代码
	public String getPaperLessUrl() {
		return paperLessUrl;
	}
	public void setPaperLessUrl(String paperLessUrl) {
		this.paperLessUrl = paperLessUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEntDeclNo() {
		return entDeclNo;
	}
	public void setEntDeclNo(String entDeclNo) {
		this.entDeclNo = entDeclNo;
	}
	public Map<String, String> getMap() {
		return map;
	}
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	
	
}

package com.rongji.eciq.mobile.model.insp.scene;

/**
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-28    才江男                     1.0.0       增加主辅检标志代码
 */
public class SceneCheckInitTableModel {
    
	private String declNo; //报检号
	private String declRegName;  //报检单位
	private String goodsName;//报检货物名称
	private String tradeCountryCode;//贸易国家  dcl_io_decl
	private String flowPathStatus;//主辅检标记
	private String flowPathStatusCode;//主辅检标记代码
	private String declDate;//报检日期
	private String insRequire;//检验要求
	private String flowPathStatusName;//主辅检标记名称
	private String receiverDocCode;//接单员
	//HS编码
	private String declMagId; 
	
	
	
	public String getFlowPathStatusName() {
		return flowPathStatusName;
	}

	public void setFlowPathStatusName(String flowPathStatusName) {
		this.flowPathStatusName = flowPathStatusName;
	}

	public String getReceiverDocCode() {
		return receiverDocCode;
	}

	public void setReceiverDocCode(String receiverDocCode) {
		this.receiverDocCode = receiverDocCode;
	}

	public String getInsRequire() {
		return insRequire;
	}

	public void setInsRequire(String insRequire) {
		this.insRequire = insRequire;
	}

	public String getDeclMagId() {
		return declMagId;
	}

	public void setDeclMagId(String declMagId) {
		this.declMagId = declMagId;
	}

	public SceneCheckInitTableModel(){
		super();
	}
	
	public SceneCheckInitTableModel(String declNo, String declRegName, String goodsName, String tradeCountryCode,
			String flowPathStatus) {
		super();
		this.declNo = declNo;
		this.declRegName = declRegName;
		this.goodsName = goodsName;
		this.tradeCountryCode = tradeCountryCode;
		this.flowPathStatus = flowPathStatus;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getDeclRegName() {
		return declRegName;
	}

	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getTradeCountryCode() {
		return tradeCountryCode;
	}

	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}

	public String getFlowPathStatus() {
		return flowPathStatus;
	}

	public void setFlowPathStatus(String flowPathStatus) {
		this.flowPathStatus = flowPathStatus;
	}

	public String getDeclDate() {
		return declDate;
	}

	public void setDeclDate(String declDate) {
		this.declDate = declDate;
	}

	public String getFlowPathStatusCode() {
		return flowPathStatusCode;
	}

	public void setFlowPathStatusCode(String flowPathStatusCode) {
		this.flowPathStatusCode = flowPathStatusCode;
	}
	
	
}

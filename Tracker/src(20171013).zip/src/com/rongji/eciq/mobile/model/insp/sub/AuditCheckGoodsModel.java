package com.rongji.eciq.mobile.model.insp.sub;

/**
 * 分单改派单-审单信息查看-货物信息model
 * @author   吴有根
 * @version  1.0
 *
 */
public class AuditCheckGoodsModel {
	
	private String goodsNo;//货物序号
	private String ciqCode;//ciq编码
	private String ciqName;//ciq名称
	private String declGoodsCname;//货物名称(中文)
	private String prodHsCode;//HS 编码
	private String hsCodeDesc;//HS 名称描述
	private String inspType;//检验检疫类别
	private String goodsTotalVal;//货物总值
	private String currency;//币种
	private String qty; //数量
	private String qtyMeasUnit;//数量计量单位
	private String weight;//重量
	private String wtMeasUnit;//重量计量单位
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}
	public String getCiqCode() {
		return ciqCode;
	}
	public void setCiqCode(String ciqCode) {
		this.ciqCode = ciqCode;
	}
	public String getCiqName() {
		return ciqName;
	}
	public void setCiqName(String ciqName) {
		this.ciqName = ciqName;
	}
	public String getDeclGoodsCname() {
		return declGoodsCname;
	}
	public void setDeclGoodsCname(String declGoodsCname) {
		this.declGoodsCname = declGoodsCname;
	}
	public String getProdHsCode() {
		return prodHsCode;
	}
	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}
	public String getHsCodeDesc() {
		return hsCodeDesc;
	}
	public void setHsCodeDesc(String hsCodeDesc) {
		this.hsCodeDesc = hsCodeDesc;
	}
	public String getInspType() {
		return inspType;
	}
	public void setInspType(String inspType) {
		this.inspType = inspType;
	}
	public String getGoodsTotalVal() {
		return goodsTotalVal;
	}
	public void setGoodsTotalVal(String goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getQtyMeasUnit() {
		return qtyMeasUnit;
	}
	public void setQtyMeasUnit(String qtyMeasUnit) {
		this.qtyMeasUnit = qtyMeasUnit;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getWtMeasUnit() {
		return wtMeasUnit;
	}
	public void setWtMeasUnit(String wtMeasUnit) {
		this.wtMeasUnit = wtMeasUnit;
	}
	
	

}

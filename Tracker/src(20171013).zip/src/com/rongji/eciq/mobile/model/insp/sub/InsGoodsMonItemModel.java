package com.rongji.eciq.mobile.model.insp.sub;

/**
 * 审单查看-检测项目model
 * @author 吴有根
 * @since  1.0
 *
 */
public class InsGoodsMonItemModel {

	private String monitItemName;//监控项目名称
	private String monitItemTypeN;//监控项目类别名称
	private String declareSymName;//是否参与评定
	private String evaluationStandard;//评定标准
	private String statuteTitle;//法规标题
	private String formName;//表单名称
	public String getMonitItemName() {
		return monitItemName;
	}
	public void setMonitItemName(String monitItemName) {
		this.monitItemName = monitItemName;
	}
	public String getMonitItemTypeN() {
		return monitItemTypeN;
	}
	public void setMonitItemTypeN(String monitItemTypeN) {
		this.monitItemTypeN = monitItemTypeN;
	}
	public String getDeclareSymName() {
		return declareSymName;
	}
	public void setDeclareSymName(String declareSymName) {
		this.declareSymName = declareSymName;
	}
	public String getEvaluationStandard() {
		return evaluationStandard;
	}
	public void setEvaluationStandard(String evaluationStandard) {
		this.evaluationStandard = evaluationStandard;
	}
	public String getStatuteTitle() {
		return statuteTitle;
	}
	public void setStatuteTitle(String statuteTitle) {
		this.statuteTitle = statuteTitle;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	
	
}

package com.rongji.eciq.mobile.model.insp.sub;

/**
 * 审单查看-布控信息model
 * @author  吴有根
 * @version 1.0
 *
 */
public class InsOriaudiExcePbinfoModel {

	private String abnormalType;//布控拦截信息
	private String abnormalCause;//异常原因
	private String exceptionDetail;//信息描述
	private String declNo;//报检号
	private String goodsNo;//货物序号
	public String getAbnormalType() {
		return abnormalType;
	}
	public void setAbnormalType(String abnormalType) {
		this.abnormalType = abnormalType;
	}
	public String getAbnormalCause() {
		return abnormalCause;
	}
	public void setAbnormalCause(String abnormalCause) {
		this.abnormalCause = abnormalCause;
	}
	public String getExceptionDetail() {
		return exceptionDetail;
	}
	public void setExceptionDetail(String exceptionDetail) {
		this.exceptionDetail = exceptionDetail;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(String goodsNo) {
		this.goodsNo = goodsNo;
	}
	
	
}

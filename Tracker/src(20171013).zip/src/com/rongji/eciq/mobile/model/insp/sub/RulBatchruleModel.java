/**  
 * FileName:  RulBatchruleModel.java   
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月14日 下午6:09:35  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.sub;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月14日 下午6:09:35  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月14日      吴有根                      1.0         1.0 Version  
 */

public class RulBatchruleModel {
	private String batchruleName;//法定抽批规则名称
	private String sampleSch;//抽样方案
	private String batchruleLstate;//法定抽批状态【1：已维护 2：已发布 3：已解除】
	public String getBatchruleName() {
		return batchruleName;
	}
	public void setBatchruleName(String batchruleName) {
		this.batchruleName = batchruleName;
	}
	public String getSampleSch() {
		return sampleSch;
	}
	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}
	public String getBatchruleLstate() {
		return batchruleLstate;
	}
	public void setBatchruleLstate(String batchruleLstate) {
		this.batchruleLstate = batchruleLstate;
	}

}

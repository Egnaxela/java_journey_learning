package com.rongji.eciq.mobile.model.insp.sub;

import java.util.List;

import com.rongji.eciq.mobile.vo.insp.InsDeclMagVo;

/**
 * 辅施检分单界面全部信息
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 上午9:44:44  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version
 */
public class SubAuxiliaryModel {
	private String declNo; //报检号
	private String entName;//企业名称
	private String inspRequire;//检验要求
	private String tradeCountryName;//贸易国家
	private String entTypeName;//企业分类
	private List<InsDeclMagVo>  insDeclMaglist;//施检管理记录
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getEntName() {
		return entName;
	}
	public void setEntName(String entName) {
		this.entName = entName;
	}
	public String getInspRequire() {
		return inspRequire;
	}
	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}
	public String getTradeCountryName() {
		return tradeCountryName;
	}
	public void setTradeCountryName(String tradeCountryName) {
		this.tradeCountryName = tradeCountryName;
	}
	public String getEntTypeName() {
		return entTypeName;
	}
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}
	public List<InsDeclMagVo> getInsDeclMaglist() {
		return insDeclMaglist;
	}
	public void setInsDeclMaglist(List<InsDeclMagVo> insDeclMaglist) {
		this.insDeclMaglist = insDeclMaglist;
	}
	
	
	
	
	

}

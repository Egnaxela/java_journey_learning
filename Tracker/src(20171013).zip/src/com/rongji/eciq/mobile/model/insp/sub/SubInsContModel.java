/**  
 * FileName:     SubInsContModel.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 下午4:58:56  
 *  
 */  

package com.rongji.eciq.mobile.model.insp.sub;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

/**  
 * Description: 分单改派单  发送查验指令
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 下午4:58:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */

public class SubInsContModel {
	private String contNo;
    private String falgArchive;
    private String lclFlag;
    private String cntnrModeCode;
    private String cntnrModeName;
    private String contDtId;
    private String contId;
    private String declNo;
    private java.util.Date operTime;
    private String goodsIds;
    private String goodsNos;
    private String declGoodsCnames;
    private String entName;
    private String billLadNo;
    private String ifOpenBox;
    private String isCheck;
    private String ifDrawBox;
    private boolean ifOpeBox;
    private boolean ifDrwBox;
    private boolean chekIs;
    private String insDrawRecordId;
    private String isSendCheckCommand;//是否发送查验指令
    private String operCode;
    
	public boolean isChekIs() {
		return chekIs;
	}
	public void setChekIs(boolean chekIs) {
		this.chekIs = chekIs;
	}
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	public String getLclFlag() {
		return lclFlag;
	}
	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}
	public String getCntnrModeCode() {
		return cntnrModeCode;
	}
	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}
	public String getCntnrModeName() {
		return cntnrModeName;
	}
	public void setCntnrModeName(String cntnrModeName) {
		this.cntnrModeName = cntnrModeName;
	}
	public String getContDtId() {
		return contDtId;
	}
	public void setContDtId(String contDtId) {
		this.contDtId = contDtId;
	}
	public String getContId() {
		return contId;
	}
	public void setContId(String contId) {
		this.contId = contId;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public java.util.Date getOperTime() {
		return operTime;
	}
	public void setOperTime(java.util.Date operTime) {
		this.operTime = operTime;
	}
	public String getGoodsIds() {
		return goodsIds;
	}
	public void setGoodsIds(String goodsIds) {
		this.goodsIds = goodsIds;
	}
	public String getGoodsNos() {
		return goodsNos;
	}
	public void setGoodsNos(String goodsNos) {
		this.goodsNos = goodsNos;
	}
	public String getDeclGoodsCnames() {
		return declGoodsCnames;
	}
	public void setDeclGoodsCnames(String declGoodsCnames) {
		this.declGoodsCnames = declGoodsCnames;
	}
	public String getEntName() {
		return entName;
	}
	public void setEntName(String entName) {
		this.entName = entName;
	}
	public String getBillLadNo() {
		return billLadNo;
	}
	public void setBillLadNo(String billLadNo) {
		this.billLadNo = billLadNo;
	}
	public String getIfOpenBox() {
		return ifOpenBox;
	}
	public void setIfOpenBox(String ifOpenBox) {
		this.ifOpenBox = ifOpenBox;
	}
	public String getIsCheck() {
		return isCheck;
	}
	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}
	public String getIfDrawBox() {
		return ifDrawBox;
	}
	public void setIfDrawBox(String ifDrawBox) {
		this.ifDrawBox = ifDrawBox;
	}
	public boolean isIfOpeBox() {
		return ifOpeBox;
	}
	public void setIfOpeBox(boolean ifOpeBox) {
		this.ifOpeBox = ifOpeBox;
	}
	public boolean isIfDrwBox() {
		return ifDrwBox;
	}
	public void setIfDrwBox(boolean ifDrwBox) {
		this.ifDrwBox = ifDrwBox;
	}
	
	public String getInsDrawRecordId() {
		return insDrawRecordId;
	}
	public void setInsDrawRecordId(String insDrawRecordId) {
		this.insDrawRecordId = insDrawRecordId;
	}
	public String getIsSendCheckCommand() {
		return isSendCheckCommand;
	}
	public void setIsSendCheckCommand(String isSendCheckCommand) {
		this.isSendCheckCommand = isSendCheckCommand;
	}
	public String getOperCode() {
		return operCode;
	}
	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}
}

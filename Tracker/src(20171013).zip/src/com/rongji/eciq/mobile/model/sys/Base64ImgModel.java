/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-9-1 上午10:10:55  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-9-1 上午10:10:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-9-1      李晨阳                      1.0         1.0 Version  
 */

public class Base64ImgModel {
	
	private String imgID; //图片标识
	private String imgDate;  //更新时间
	private String[] title; //推广标题
	private String[] base64Str;  //64位编码字符串
	
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	
	public String getImgDate() {
		return imgDate;
	}
	public void setImgDate(String imgDate) {
		this.imgDate = imgDate;
	}
	
	public String[] getTitle() {
		return title;
	}
	public void setTitle(String[] title) {
		this.title = title;
	}
	
	public String[] getBase64Str() {
		return base64Str;
	}
	public void setBase64Str(String[] base64Str) {
		this.base64Str = base64Str;
	}
}

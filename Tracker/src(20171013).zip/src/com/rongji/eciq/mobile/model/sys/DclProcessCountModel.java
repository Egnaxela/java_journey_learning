/**  
 * FileName:     DclProcessCountModel.java
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-12-1 下午3:57:35  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

import java.util.List;

/**  
 * Description: 报检单统计处理model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-12-1 下午3:57:35  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-12-1      夏晨琳                      1.0         1.0 Version  
 */

public class DclProcessCountModel {
	private List<String> weekCount;
	private List<String> monthCount;
	private List<String> hourCount;
	private String yearCount;
	private String orgNameSc;
	
	public String getOrgNameSc() {
		return orgNameSc;
	}
	public void setOrgNameSc(String orgNameSc) {
		this.orgNameSc = orgNameSc;
	}
	public String getYearCount() {
		return yearCount;
	}
	public void setYearCount(String yearCount) {
		this.yearCount = yearCount;
	}
	public List<String> getWeekCount() {
		return weekCount;
	}
	public void setWeekCount(List<String> weekCount) {
		this.weekCount = weekCount;
	}
	public List<String> getMonthCount() {
		return monthCount;
	}
	public void setMonthCount(List<String> monthCount) {
		this.monthCount = monthCount;
	}
	public List<String> getHourCount() {
		return hourCount;
	}
	public void setHourCount(List<String> hourCount) {
		this.hourCount = hourCount;
	}
}

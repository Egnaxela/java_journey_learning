/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月24日 上午11:11:17  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

import com.fasterxml.jackson.annotation.JsonProperty;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月24日 上午11:11:17  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月24日      吴有根                      1.0         1.0 Version  
 */

public class EnterpriseModel {
	@JsonProperty("isLogin")
	private boolean isLogin;//是否登录成功
	private String entInfoId;//企业信息ID
	private String entOrgCode;//企业组织机构代码
	private String declRegNo;//报检单位注册号
	private String unitNameCn;//企业名称(中文)
	private String unitNameEn;//企业名称(英文)
	
	private String id;//企业组织机构代码
	private String hexCode;//hash防伪码
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getHexCode() {
		return hexCode;
	}
	public void setHexCode(String hexCode) {
		this.hexCode = hexCode;
	}
	public boolean isLogin() {
		return isLogin;
	}
	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}
	public String getEntInfoId() {
		return entInfoId;
	}
	public void setEntInfoId(String entInfoId) {
		this.entInfoId = entInfoId;
	}
	public String getEntOrgCode() {
		return entOrgCode;
	}
	public void setEntOrgCode(String entOrgCode) {
		this.entOrgCode = entOrgCode;
	}
	public String getDeclRegNo() {
		return declRegNo;
	}
	public void setDeclRegNo(String declRegNo) {
		this.declRegNo = declRegNo;
	}
	public String getUnitNameCn() {
		return unitNameCn;
	}
	public void setUnitNameCn(String unitNameCn) {
		this.unitNameCn = unitNameCn;
	}
	public String getUnitNameEn() {
		return unitNameEn;
	}
	public void setUnitNameEn(String unitNameEn) {
		this.unitNameEn = unitNameEn;
	}
	
	
}

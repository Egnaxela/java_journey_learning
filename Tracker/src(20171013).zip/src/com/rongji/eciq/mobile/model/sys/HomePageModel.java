/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨用  
 * @version:     1.0
 * Createdate:   2017-5-22 上午11:30:09  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

import java.util.List;
import java.util.Map;

/**  
 * Description:   主页实体
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-22 上午11:30:09  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-22      李晨阳                      1.0         1.0 Version 
 * 2017-6-07      才江男                      1.0         证书过期 
 * 2017-8-30      才江男                      1.0         任务完成统计
 */

public class HomePageModel {

	private SysHomePageTodoModel sysHomePageTodoModel;
	private List<PortalNoticeModel> portalNoticeModel;
	private String expire;//证书过期时间
	private Map done;//统计
	
	public SysHomePageTodoModel getSysHomePageTodoModel() {
        return this.sysHomePageTodoModel;
    }
    
    public void setSysHomePageTodoModel(SysHomePageTodoModel sysHomePageTodoModel) {
        this.sysHomePageTodoModel = sysHomePageTodoModel;
    }
    
    public List<PortalNoticeModel> getPortalNoticeModel() {
        return this.portalNoticeModel;
    }
    
    public void setPortalNoticeModel(List<PortalNoticeModel> portalNoticeModel) {
        this.portalNoticeModel = portalNoticeModel;
    }

	public String getExpire() {
		return expire;
	}

	public void setExpire(String expire) {
		this.expire = expire;
	}

	public Map getDone() {
		return done;
	}

	public void setDone(Map done) {
		this.done = done;
	}
	
}

package com.rongji.eciq.mobile.model.sys;

import java.util.List;

/**
 * 集合模型
 * 
 * @author 才江男
 * @since 1.0
 */
public class ListModel {

	private List<Object> list;//集合
	
	private String msg;//信息

	/**
	 * @return the list
	 */
	public List<Object> getList() {
		return list;
	}

	/**
	 * @param list the list to set
	 */
	public void setList(List<Object> list) {
		this.list = list;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

}

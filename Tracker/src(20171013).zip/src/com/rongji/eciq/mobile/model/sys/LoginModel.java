/**
 * CREATE DATE:2017-3-22 上午11:19:42
 */
package com.rongji.eciq.mobile.model.sys;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 用户登录模型
 *
 * @author 才江男
 * @since 1.0
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0         修改用户信息模型 
 * 2017-6-07      才江男                      1.0         证书过期
 */
public class LoginModel {
	
	@JsonProperty("isLogin")
	private boolean isLogin;//是否登录成功
	
	private String msg;//错误信息
	
	private SysUserModel user;//用户信息
	
	private List<PrivilegeModel> privileges;//权限
	
	private String id;//用户代码
	
	private String hexCode;//防伪码
	
	private String orgName;//部门名称
	
	private String expire;//证书过期

	/**
	 * @return the isLogin
	 */
	public boolean isLogin() {
		return isLogin;
	}

	/**
	 * @param isLogin the isLogin to set
	 */
	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the user
	 */
	public SysUserModel getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(SysUserModel user) {
		this.user = user;
	}

	/**
	 * @return the privileges
	 */
	public List<PrivilegeModel> getPrivileges() {
		return privileges;
	}

	/**
	 * @param privileges the privileges to set
	 */
	public void setPrivileges(List<PrivilegeModel> privileges) {
		this.privileges = privileges;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the hexCode
	 */
	public String getHexCode() {
		return hexCode;
	}

	/**
	 * @param hexCode the hexCode to set
	 */
	public void setHexCode(String hexCode) {
		this.hexCode = hexCode;
	}

	/**
	 * @return the orgName
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * @param orgName the orgName to set
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getExpire() {
		return expire;
	}

	public void setExpire(String expire) {
		this.expire = expire;
	}
	
}

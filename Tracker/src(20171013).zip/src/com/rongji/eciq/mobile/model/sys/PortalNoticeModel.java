/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

import java.util.Date;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-12 上午10:29:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      李晨阳                      1.0         1.0 Version  
 */

public class PortalNoticeModel {
	
    private String annTitle;//公告标题
    private String annContent;//公告内容
    private Date annIssDate;//发布时间
    private String annIssuerCode;//发布人
    private String isueOrgCode;//发布机构
    private String fileCode;//文件ID
    
    public String getAnnTitle() {
        return this.annTitle;
    }
    
    public void setAnnTitle(String annTitle) {
        this.annTitle = annTitle;
    }
    
    public String getAnnContent() {
        return this.annContent;
    }
    
    public void setAnnContent(String annContent) {
        this.annContent = annContent;
    }
   
    public Date getAnnIssDate() {
        return this.annIssDate;
    }
    public void setAnnIssDate(Date annIssDate) {
        this.annIssDate = annIssDate;
    }
    
    public String getAnnIssuerCode() {
        return this.annIssuerCode;
    }
    
    public void setAnnIssuerCode(String annIssuerCode) {
        this.annIssuerCode = annIssuerCode;
    }
    
    public String getIsueOrgCode() {
        return this.isueOrgCode;
    }
    
    public void setIsueOrgCode(String isueOrgCode) {
        this.isueOrgCode = isueOrgCode;
    }
    
    public String getFileCode() {
        return this.fileCode;
    }
    
    public void setFileCode(String fileCode) {
        this.fileCode = fileCode;
    }
      
}

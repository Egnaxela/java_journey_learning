/**
 * CREATE DATE:2017-3-22 下午1:51:14
 */
package com.rongji.eciq.mobile.model.sys;


/**
 * 用户权限模型
 *
 * @author 才江男
 * @since 1.0
 */
public class PrivilegeModel {
	
	//权限名称
	private String name;
	
	//权限代码
	private String code;
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

}

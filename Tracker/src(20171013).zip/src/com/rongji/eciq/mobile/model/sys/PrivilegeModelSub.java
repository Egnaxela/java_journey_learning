/**
 * CREATE DATE:2017-3-22 下午1:51:14
 */
package com.rongji.eciq.mobile.model.sys;


/**
 * 用户权限模型-有子级
 *
 * @author 才江男
 * @since 1.0
 * Modification History:  
 * Date          Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-16      才江男                      1.0         增加路径
 */
public class PrivilegeModelSub extends PrivilegeModel{
	
	//子权限
	private Object sub;
	//无子权限，显示具体界面
	private String url;

	public Object getSub() {
		return sub;
	}

	public void setSub(Object sub) {
		this.sub = sub;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}

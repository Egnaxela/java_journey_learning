/**
 * CREATE DATE:2017-3-22 下午1:51:14
 */
package com.rongji.eciq.mobile.model.sys;


/**
 * 用户权限模型-无子级
 *
 * @author 才江男
 * @since 1.0
 */
public class PrivilegeModelUrl extends PrivilegeModel{
	
	//无子权限，显示具体界面
	private String url;

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	
	
}

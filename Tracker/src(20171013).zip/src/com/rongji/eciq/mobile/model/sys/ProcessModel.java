/**  
 * FileName:  ProcessModel.java   
 * @Description: 流程状态
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-5-17 上午11:09:12  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

/**  
 * Description: 流程状态 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-17 上午11:09:12  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-17      李云龙                      1.0         1.0 Version  
 */

public class ProcessModel {
	private String processStatusCode;//流程状态代码
	private String processStatusName;//流程状态名称
	public String getProcessStatusCode() {
		return processStatusCode;
	}
	public void setProcessStatusCode(String processStatusCode) {
		this.processStatusCode = processStatusCode;
	}
	public String getProcessStatusName() {
		return processStatusName;
	}
	public void setProcessStatusName(String processStatusName) {
		this.processStatusName = processStatusName;
	}
}

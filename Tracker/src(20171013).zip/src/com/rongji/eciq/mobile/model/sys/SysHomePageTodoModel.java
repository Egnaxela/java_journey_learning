/**  
 * FileName:SysHomePageTodoModel.java     
 * @Description: 系统首页待办事项返回model
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月19日 下午4:04:21  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;

/**  
 * Description: 系统首页待办事项返回model  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月19日 下午4:04:21  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月19日      吴有根                      1.0         1.0 Version  
 */

public class SysHomePageTodoModel {

	private String IMP_PUMP_GROUP;// 入境待分单
	private String IMP_WAIT_INS_CHECK;// 入境待施检审单
	private String IMP_WAIT_CHECK;// 入境待查验
	private String IMP_WAIT_INS_RESULT;// 入境待登记
	private String IMP_WAIT_INSP_AUDIT;// 入境待审核
	private String IMP_WAIT_DEPT_AUDIT;// 入境待科长审核
	private String IMP_WAIT_SECT_AUDIT;// 入境待处长审核

	private String EXP_PUMP_GROUP;// 出境待分单
	private String EXP_WAIT_INS_CHECK;// 出境待施检审单
	private String EXP_WAIT_CHECK;// 出境待查验
	private String EXP_WAIT_INS_RESULT;// 出境待登记
	private String EXP_WAIT_INSP_AUDIT;// 出境待审核
	private String EXP_WAIT_DEPT_AUDIT;// 出境待科长审核
	private String EXP_WAIT_SECT_AUDIT;// 出境待处长审核
	public String getIMP_PUMP_GROUP() {
		return IMP_PUMP_GROUP;
	}
	public void setIMP_PUMP_GROUP(String iMP_PUMP_GROUP) {
		IMP_PUMP_GROUP = iMP_PUMP_GROUP;
	}
	public String getIMP_WAIT_INS_CHECK() {
		return IMP_WAIT_INS_CHECK;
	}
	public void setIMP_WAIT_INS_CHECK(String iMP_WAIT_INS_CHECK) {
		IMP_WAIT_INS_CHECK = iMP_WAIT_INS_CHECK;
	}
	public String getIMP_WAIT_CHECK() {
		return IMP_WAIT_CHECK;
	}
	public void setIMP_WAIT_CHECK(String iMP_WAIT_CHECK) {
		IMP_WAIT_CHECK = iMP_WAIT_CHECK;
	}
	public String getIMP_WAIT_INS_RESULT() {
		return IMP_WAIT_INS_RESULT;
	}
	public void setIMP_WAIT_INS_RESULT(String iMP_WAIT_INS_RESULT) {
		IMP_WAIT_INS_RESULT = iMP_WAIT_INS_RESULT;
	}
	public String getIMP_WAIT_INSP_AUDIT() {
		return IMP_WAIT_INSP_AUDIT;
	}
	public void setIMP_WAIT_INSP_AUDIT(String iMP_WAIT_INSP_AUDIT) {
		IMP_WAIT_INSP_AUDIT = iMP_WAIT_INSP_AUDIT;
	}
	public String getIMP_WAIT_DEPT_AUDIT() {
		return IMP_WAIT_DEPT_AUDIT;
	}
	public void setIMP_WAIT_DEPT_AUDIT(String iMP_WAIT_DEPT_AUDIT) {
		IMP_WAIT_DEPT_AUDIT = iMP_WAIT_DEPT_AUDIT;
	}
	public String getIMP_WAIT_SECT_AUDIT() {
		return IMP_WAIT_SECT_AUDIT;
	}
	public void setIMP_WAIT_SECT_AUDIT(String iMP_WAIT_SECT_AUDIT) {
		IMP_WAIT_SECT_AUDIT = iMP_WAIT_SECT_AUDIT;
	}
	public String getEXP_PUMP_GROUP() {
		return EXP_PUMP_GROUP;
	}
	public void setEXP_PUMP_GROUP(String eXP_PUMP_GROUP) {
		EXP_PUMP_GROUP = eXP_PUMP_GROUP;
	}
	public String getEXP_WAIT_INS_CHECK() {
		return EXP_WAIT_INS_CHECK;
	}
	public void setEXP_WAIT_INS_CHECK(String eXP_WAIT_INS_CHECK) {
		EXP_WAIT_INS_CHECK = eXP_WAIT_INS_CHECK;
	}
	public String getEXP_WAIT_CHECK() {
		return EXP_WAIT_CHECK;
	}
	public void setEXP_WAIT_CHECK(String eXP_WAIT_CHECK) {
		EXP_WAIT_CHECK = eXP_WAIT_CHECK;
	}
	public String getEXP_WAIT_INS_RESULT() {
		return EXP_WAIT_INS_RESULT;
	}
	public void setEXP_WAIT_INS_RESULT(String eXP_WAIT_INS_RESULT) {
		EXP_WAIT_INS_RESULT = eXP_WAIT_INS_RESULT;
	}
	public String getEXP_WAIT_INSP_AUDIT() {
		return EXP_WAIT_INSP_AUDIT;
	}
	public void setEXP_WAIT_INSP_AUDIT(String eXP_WAIT_INSP_AUDIT) {
		EXP_WAIT_INSP_AUDIT = eXP_WAIT_INSP_AUDIT;
	}
	public String getEXP_WAIT_DEPT_AUDIT() {
		return EXP_WAIT_DEPT_AUDIT;
	}
	public void setEXP_WAIT_DEPT_AUDIT(String eXP_WAIT_DEPT_AUDIT) {
		EXP_WAIT_DEPT_AUDIT = eXP_WAIT_DEPT_AUDIT;
	}
	public String getEXP_WAIT_SECT_AUDIT() {
		return EXP_WAIT_SECT_AUDIT;
	}
	public void setEXP_WAIT_SECT_AUDIT(String eXP_WAIT_SECT_AUDIT) {
		EXP_WAIT_SECT_AUDIT = eXP_WAIT_SECT_AUDIT;
	}
	
	
}

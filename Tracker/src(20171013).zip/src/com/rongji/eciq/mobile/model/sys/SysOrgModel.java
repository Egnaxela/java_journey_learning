package com.rongji.eciq.mobile.model.sys;

import java.util.List;

/**
 * 机构模型
 *
 * @author 才江男
 * @since 1.0
 */
public class SysOrgModel{

	private String msg;//信息
	
	private String orgCode;//机构代码
	
	private String orgNameSc;//机构名称
	
	private List<SysOrgSubModel> sub;//子级部门信息
	
	private List<SysOrgModel> orgs;//机构信息
	
	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return the orgNameSc
	 */
	public String getOrgNameSc() {
		return orgNameSc;
	}

	/**
	 * @param orgNameSc the orgNameSc to set
	 */
	public void setOrgNameSc(String orgNameSc) {
		this.orgNameSc = orgNameSc;
	}

	/**
	 * @return the sub
	 */
	public List<SysOrgSubModel> getSub() {
		return sub;
	}

	/**
	 * @param sub the sub to set
	 */
	public void setSub(List<SysOrgSubModel> sub) {
		this.sub = sub;
	}

	/**
	 * @return the orgs
	 */
	public List<SysOrgModel> getOrgs() {
		return orgs;
	}

	/**
	 * @param orgs the orgs to set
	 */
	public void setOrgs(List<SysOrgModel> orgs) {
		this.orgs = orgs;
	}

}

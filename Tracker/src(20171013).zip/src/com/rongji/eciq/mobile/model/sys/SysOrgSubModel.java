package com.rongji.eciq.mobile.model.sys;


/**
 * 机构下属部门模型
 *
 * @author 才江男
 * @since 1.0
 */
public class SysOrgSubModel{

	private String orgCode;//机构代码
	
	private String orgNameSc;//机构名称
	
	private boolean sub;//机构信息
	
	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**
	 * @param orgCode the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * @return the orgNameSc
	 */
	public String getOrgNameSc() {
		return orgNameSc;
	}

	/**
	 * @param orgNameSc the orgNameSc to set
	 */
	public void setOrgNameSc(String orgNameSc) {
		this.orgNameSc = orgNameSc;
	}

	/**
	 * @return the sub
	 */
	public boolean isSub() {
		return sub;
	}

	/**
	 * @param sub the sub to set
	 */
	public void setSub(boolean sub) {
		this.sub = sub;
	}

}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-4-19 下午3:12:14  
 *  
 */  

package com.rongji.eciq.mobile.model.sys;


/**  
 * Description: 用户模型
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-19 下午3:12:14  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0         1.0 Version  
 * 2017-5-17      魏波                           1.0         添加入职日期和机构部门名称 
 */

public class SysUserModel {

	private String userCode;//用户代码
	private String userName;//用户名称
	private String orgCode;//部门代码
	private String orgName;//部门名称
	private String orgDeptName;//所属机构/部门
	private String date;//创建时间
	
	
	
	public String getOrgDeptName() {
		return orgDeptName;
	}
	public void setOrgDeptName(String orgDeptName) {
		this.orgDeptName = orgDeptName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
}

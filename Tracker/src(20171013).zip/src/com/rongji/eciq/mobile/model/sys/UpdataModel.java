package com.rongji.eciq.mobile.model.sys;

/**
 * 更新数据模型
 * 
 * @author 李晨阳
 * @since 1.0
 */
public class UpdataModel {
	// 主键
	private String versionId;
	
	// 版本号
	private Double version;
		
	// 更新地址
	private String url;

	// 更新说明
	private String updateExplain;

	
	public String getVersionId() {
		return versionId;
	}

	
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	
	public Double getVersion() {
		return version;
	}

	
	public void setVersion(Double version) {
		this.version = version;
	}
	
	public String getUrl() {
		return url;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getUpdateExplain() {
		return updateExplain;
	}

	
	public void setUpdateExplain(String updateExplain) {
		this.updateExplain = updateExplain;
	}
}

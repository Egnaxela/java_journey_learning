/**  
 * FileName:  DclOrdFeedbackDetail.java   
 * @Description: 布控反馈明细表 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:11:56  
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.bean;

import java.util.Date;

/**
 * 
 * Description: 布控反馈明细表 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:11:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                      1.0         1.0 Version
 */
public class DclOrdFeedbackDetail implements java.io.Serializable {

	public static final long serialVersionUID = 6573480428634748741L;
	public String ordFeedbackInfoNo;
	public String feedbackMainNo;
	public String orderNo;
	public String declNo;
	public String execRslt;
	public String unquReason;
	public String execRsltDesc;
	public Date operTime;

	// Constructors

	/** default constructor */
	public DclOrdFeedbackDetail() {
	}

	/** minimal constructor */
	public DclOrdFeedbackDetail(String ordFeedbackInfoNo) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
	}

	/** full constructor */
	public DclOrdFeedbackDetail(String ordFeedbackInfoNo,
			String feedbackMainNo, String orderNo,
			String declNo, String execRslt, String unquReason,
			String execRsltDesc, Date operTime) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
		this.feedbackMainNo = feedbackMainNo;
		this.orderNo = orderNo;
		this.declNo = declNo;
		this.execRslt = execRslt;
		this.unquReason = unquReason;
		this.execRsltDesc = execRsltDesc;
		this.operTime = operTime;
	}

	public String getOrdFeedbackInfoNo() {
		return ordFeedbackInfoNo;
	}

	public void setOrdFeedbackInfoNo(String ordFeedbackInfoNo) {
		this.ordFeedbackInfoNo = ordFeedbackInfoNo;
	}

	public String getFeedbackMainNo() {
		return feedbackMainNo;
	}

	public void setFeedbackMainNo(String feedbackMainNo) {
		this.feedbackMainNo = feedbackMainNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getExecRslt() {
		return execRslt;
	}

	public void setExecRslt(String execRslt) {
		this.execRslt = execRslt;
	}

	public String getUnquReason() {
		return unquReason;
	}

	public void setUnquReason(String unquReason) {
		this.unquReason = unquReason;
	}

	public String getExecRsltDesc() {
		return execRsltDesc;
	}

	public void setExecRsltDesc(String execRsltDesc) {
		this.execRsltDesc = execRsltDesc;
	}

	public Date getOperTime() {
		return operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	
}
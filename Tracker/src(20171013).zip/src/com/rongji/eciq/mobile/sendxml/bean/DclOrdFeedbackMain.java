/**  
 * FileName:  DclOrdFeedbackMain.java   
 * @Description: 布控反馈主表
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.util.Date;
import java.util.List;

/**
 * 
 * Description: 布控反馈主表 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:13:51  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                      1.0         1.0 Version
 */
public class DclOrdFeedbackMain implements java.io.Serializable {

	public static final long serialVersionUID = -4194507148672349117L;
	public String feedbackMainNo;
	public String declNo;
	public Date feedbackTime;
	public String feedbackOrg;
	public String feedbackApp;
	public String feedbackLink;
	public String feedbackDept;
	public String fedbackPersn;
	public String assessStatus;
	public String suplement;
	public Date operTime;

	///////////
	public String transBatch;
	public List<DclOrdFeedbackDetail> feedbackDetailList;
	
	// Constructors

	/** default constructor */
	public DclOrdFeedbackMain() {
	}

	/** minimal constructor */
	public DclOrdFeedbackMain(String feedbackMainNo, Date feedbackTime,
			String feedbackOrg, String fedbackPersn) {
		this.feedbackMainNo = feedbackMainNo;
		this.feedbackTime = feedbackTime;
		this.feedbackOrg = feedbackOrg;
		this.fedbackPersn = fedbackPersn;
	}

	/** full constructor */
	public DclOrdFeedbackMain(String feedbackMainNo, String declNo,
			Date feedbackTime, String feedbackOrg, String feedbackApp,
			String feedbackLink, String feedbackDept, String fedbackPersn,
			String assessStatus, String suplement, Date operTime
			
			) {
		this.feedbackMainNo = feedbackMainNo;
		this.declNo = declNo;
		this.feedbackTime = feedbackTime;
		this.feedbackOrg = feedbackOrg;
		this.feedbackApp = feedbackApp;
		this.feedbackLink = feedbackLink;
		this.feedbackDept = feedbackDept;
		this.fedbackPersn = fedbackPersn;
		this.assessStatus = assessStatus;
		this.suplement = suplement;
		this.operTime = operTime;
	}

	public String getFeedbackMainNo() {
		return feedbackMainNo;
	}

	public void setFeedbackMainNo(String feedbackMainNo) {
		this.feedbackMainNo = feedbackMainNo;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public Date getFeedbackTime() {
		return feedbackTime;
	}

	public void setFeedbackTime(Date feedbackTime) {
		this.feedbackTime = feedbackTime;
	}

	public String getFeedbackOrg() {
		return feedbackOrg;
	}

	public void setFeedbackOrg(String feedbackOrg) {
		this.feedbackOrg = feedbackOrg;
	}

	public String getFeedbackApp() {
		return feedbackApp;
	}

	public void setFeedbackApp(String feedbackApp) {
		this.feedbackApp = feedbackApp;
	}

	public String getFeedbackLink() {
		return feedbackLink;
	}

	public void setFeedbackLink(String feedbackLink) {
		this.feedbackLink = feedbackLink;
	}

	public String getFeedbackDept() {
		return feedbackDept;
	}

	public void setFeedbackDept(String feedbackDept) {
		this.feedbackDept = feedbackDept;
	}

	public String getFedbackPersn() {
		return fedbackPersn;
	}

	public void setFedbackPersn(String fedbackPersn) {
		this.fedbackPersn = fedbackPersn;
	}

	public String getAssessStatus() {
		return assessStatus;
	}

	public void setAssessStatus(String assessStatus) {
		this.assessStatus = assessStatus;
	}

	public String getSuplement() {
		return suplement;
	}

	public void setSuplement(String suplement) {
		this.suplement = suplement;
	}

	public Date getOperTime() {
		return operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	public String getTransBatch() {
		return transBatch;
	}

	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

	public List<DclOrdFeedbackDetail> getFeedbackDetailList() {
		return feedbackDetailList;
	}

	public void setFeedbackDetailList(List<DclOrdFeedbackDetail> feedbackDetailList) {
		this.feedbackDetailList = feedbackDetailList;
	}

	

}
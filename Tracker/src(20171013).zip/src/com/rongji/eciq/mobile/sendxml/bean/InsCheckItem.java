/**  
 * FileName:  InsCheckItem.java   
 * @Description: 查验项目表
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:14:28  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 
 * Description: 查验项目表  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:14:28  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                      1.0         1.0 Version
 */
public class InsCheckItem implements java.io.Serializable {
	public static final long serialVersionUID = 8298020164196570992L;
	public String checkItemId;
	public String declNo;
	public BigDecimal goodsNo;
	public String checkItemCode;
	public String checkItemName;
	public String checkItemResultCode;
	public String parentItemCode;
	public String parentItemName;
	public String batchDesc;
	public String inspProcStatus;
	public String falgArchive;
	public Date operTime;
	public String sampleSch;
	public String whetherQualfy;
	public Date archiveTime;
	public String checkFormCode;
	public String isAppFlag;
	public String scOrgCode;
	public String scOperatorCode;
	public String itemTypeCode;
	public String addInputFlag;
	public String checkCont;
	public String checkGoodsType;
	public String nodeCode;
	
	/////
	public String operOrg;
	public String inspBFlag;
	public String BOrgCode;
	public String BOperatorCode;
	public String transBatch;
	


	// Constructors

	/** default constructor */
	public InsCheckItem() {
	}

	/** minimal constructor */
	public InsCheckItem(String checkItemId, String declNo) {
		this.checkItemId = checkItemId;
		this.declNo = declNo;
	}

	/** full constructor */
	public InsCheckItem(String checkItemId, String declNo, BigDecimal goodsNo,
			String checkItemCode, String checkItemName,
			String checkItemResultCode, String parentItemCode,
			String parentItemName, String batchDesc, String inspProcStatus,
			String falgArchive, Date operTime, String sampleSch,
			String whetherQualfy, Date archiveTime, String checkFormCode,
			String isAppFlag, String scOrgCode, String scOperatorCode,
			String itemTypeCode, String addInputFlag, String checkCont,
			String checkGoodsType, String nodeCode, String formName) {
		this.checkItemId = checkItemId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.checkItemCode = checkItemCode;
		this.checkItemName = checkItemName;
		this.checkItemResultCode = checkItemResultCode;
		this.parentItemCode = parentItemCode;
		this.parentItemName = parentItemName;
		this.batchDesc = batchDesc;
		this.inspProcStatus = inspProcStatus;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.sampleSch = sampleSch;
		this.whetherQualfy = whetherQualfy;
		this.archiveTime = archiveTime;
		this.checkFormCode = checkFormCode;
		this.isAppFlag = isAppFlag;
		this.scOrgCode = scOrgCode;
		this.scOperatorCode = scOperatorCode;
		this.itemTypeCode = itemTypeCode;
		this.addInputFlag = addInputFlag;
		this.checkCont = checkCont;
		this.checkGoodsType = checkGoodsType;
		this.nodeCode = nodeCode;
//		this.formName = formName;
	}

	public String getCheckItemId() {
		return checkItemId;
	}

	public void setCheckItemId(String checkItemId) {
		this.checkItemId = checkItemId;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public BigDecimal getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(BigDecimal goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getCheckItemCode() {
		return checkItemCode;
	}

	public void setCheckItemCode(String checkItemCode) {
		this.checkItemCode = checkItemCode;
	}

	public String getCheckItemName() {
		return checkItemName;
	}

	public void setCheckItemName(String checkItemName) {
		this.checkItemName = checkItemName;
	}

	public String getCheckItemResultCode() {
		return checkItemResultCode;
	}

	public void setCheckItemResultCode(String checkItemResultCode) {
		this.checkItemResultCode = checkItemResultCode;
	}

	public String getParentItemCode() {
		return parentItemCode;
	}

	public void setParentItemCode(String parentItemCode) {
		this.parentItemCode = parentItemCode;
	}

	public String getParentItemName() {
		return parentItemName;
	}

	public void setParentItemName(String parentItemName) {
		this.parentItemName = parentItemName;
	}

	public String getBatchDesc() {
		return batchDesc;
	}

	public void setBatchDesc(String batchDesc) {
		this.batchDesc = batchDesc;
	}

	public String getInspProcStatus() {
		return inspProcStatus;
	}

	public void setInspProcStatus(String inspProcStatus) {
		this.inspProcStatus = inspProcStatus;
	}

	public String getFalgArchive() {
		return falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	public Date getOperTime() {
		return operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	public String getSampleSch() {
		return sampleSch;
	}

	public void setSampleSch(String sampleSch) {
		this.sampleSch = sampleSch;
	}

	public String getWhetherQualfy() {
		return whetherQualfy;
	}

	public void setWhetherQualfy(String whetherQualfy) {
		this.whetherQualfy = whetherQualfy;
	}

	public Date getArchiveTime() {
		return archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	public String getCheckFormCode() {
		return checkFormCode;
	}

	public void setCheckFormCode(String checkFormCode) {
		this.checkFormCode = checkFormCode;
	}

	public String getIsAppFlag() {
		return isAppFlag;
	}

	public void setIsAppFlag(String isAppFlag) {
		this.isAppFlag = isAppFlag;
	}

	public String getScOrgCode() {
		return scOrgCode;
	}

	public void setScOrgCode(String scOrgCode) {
		this.scOrgCode = scOrgCode;
	}

	public String getScOperatorCode() {
		return scOperatorCode;
	}

	public void setScOperatorCode(String scOperatorCode) {
		this.scOperatorCode = scOperatorCode;
	}

	public String getItemTypeCode() {
		return itemTypeCode;
	}

	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	public String getAddInputFlag() {
		return addInputFlag;
	}

	public void setAddInputFlag(String addInputFlag) {
		this.addInputFlag = addInputFlag;
	}

	public String getCheckCont() {
		return checkCont;
	}

	public void setCheckCont(String checkCont) {
		this.checkCont = checkCont;
	}

	public String getCheckGoodsType() {
		return checkGoodsType;
	}

	public void setCheckGoodsType(String checkGoodsType) {
		this.checkGoodsType = checkGoodsType;
	}

	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode;
	}

	public String getOperOrg() {
		return operOrg;
	}

	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}

	public String getInspBFlag() {
		return inspBFlag;
	}

	public void setInspBFlag(String inspBFlag) {
		this.inspBFlag = inspBFlag;
	}

	public String getBOrgCode() {
		return BOrgCode;
	}

	public void setBOrgCode(String bOrgCode) {
		BOrgCode = bOrgCode;
	}

	public String getBOperatorCode() {
		return BOperatorCode;
	}

	public void setBOperatorCode(String bOperatorCode) {
		BOperatorCode = bOperatorCode;
	}

	public String getTransBatch() {
		return transBatch;
	}

	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

	
}
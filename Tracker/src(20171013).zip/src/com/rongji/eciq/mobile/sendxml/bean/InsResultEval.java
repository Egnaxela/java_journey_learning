package com.rongji.eciq.mobile.sendxml.bean;

import java.util.Date;

import oracle.sql.CLOB;
/**
 * InsResultEval entity. @author MyEclipse Persistence Tools
 */
public class InsResultEval implements java.io.Serializable {

	public static final long serialVersionUID = -3574289577805534786L;
	public String insResultEvalId;
	public String declNo;
	public String userCode;
	public String orgCode;
	public CLOB evalInfo;
	public String isEval;
	public String remark;
	public String additional1;
	public String additional2;
	public String additional3;
	public String falgArchive;
	public Date operTime;
	public String receiveFlag;

	/////////////////
	public String transBatch;
	
	
	// Constructors

	/** default constructor */
	public InsResultEval() {
	}

	/** minimal constructor */
	public InsResultEval(String insResultEvalId) {
		this.insResultEvalId = insResultEvalId;
	}

	/** full constructor */
	public InsResultEval(String insResultEvalId, String declNo,
			String userCode, String orgCode, CLOB evalInfo, String isEval,
			String remark, String additional1, String additional2,
			String additional3, String falgArchive, Date operTime) {
		this.insResultEvalId = insResultEvalId;
		this.declNo = declNo;
		this.userCode = userCode;
		this.orgCode = orgCode;
		this.evalInfo = evalInfo;
		this.isEval = isEval;
		this.remark = remark;
		this.additional1 = additional1;
		this.additional2 = additional2;
		this.additional3 = additional3;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
	}

	// Property accessors
	public String getInsResultEvalId() {
		return this.insResultEvalId;
	}

	public void setInsResultEvalId(String insResultEvalId) {
		this.insResultEvalId = insResultEvalId;
	}

	public String getDeclNo() {
		return this.declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public String getUserCode() {
		return this.userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getOrgCode() {
		return this.orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public CLOB getEvalInfo() {
		return this.evalInfo;
	}

	public void setEvalInfo(CLOB evalInfo) {
		this.evalInfo = evalInfo;
	}

	public String getIsEval() {
		return this.isEval;
	}

	public void setIsEval(String isEval) {
		this.isEval = isEval;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAdditional1() {
		return this.additional1;
	}

	public void setAdditional1(String additional1) {
		this.additional1 = additional1;
	}

	public String getAdditional2() {
		return this.additional2;
	}

	public void setAdditional2(String additional2) {
		this.additional2 = additional2;
	}

	public String getAdditional3() {
		return this.additional3;
	}

	public void setAdditional3(String additional3) {
		this.additional3 = additional3;
	}

	public String getFalgArchive() {
		return this.falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	public Date getOperTime() {
		return this.operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	public String getTransBatch() {
		return transBatch;
	}

	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}
	
	public String getReceiveFlag() {
		return receiveFlag;
	}

	public void setReceiveFlag(String receiveFlag) {
		this.receiveFlag = receiveFlag;
	}

	
}
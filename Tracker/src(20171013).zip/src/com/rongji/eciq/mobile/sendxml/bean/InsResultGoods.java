/**  
 * FileName:  InsResultGoods.java   
 * @Description: 货物检验结果表
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 
 * Description: 货物检验结果表  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:17:57  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                      1.0         1.0 Version
 */
public class InsResultGoods implements java.io.Serializable {

	public static final long serialVersionUID = -4570696638723749108L;
	public String resultGoodsId;
	public String declNo;
	public BigDecimal goodsNo;
	public String prodHsCode;
	public String statKindCode;
	public String spec;
	public String mesuUnTypCode;
	public BigDecimal weightNet;
	public BigDecimal weightGross;
	public String wtUnitCode;
	public BigDecimal stdWt;
	public String stdWtUnitCode;
	public BigDecimal statclWtValue;
	public String statWtUnitCode;
	public BigDecimal qty;
	public String qtyUnitCode;
	public BigDecimal stdQty;
	public String stdQtyUnitCode;
	public BigDecimal statclQtyValue;
	public String statQuatyUnCo;
	public BigDecimal packQty;
	public String packTypeCode;
	public String currency;
	public BigDecimal goodsTotalVal;
	public BigDecimal totalValUs;
	public BigDecimal totalValCn;
	public String goodsPlace;
	public Date entryDate;
	public Date cmplDschrgDt;
	public BigDecimal unquaWt;
	public BigDecimal unqualQty;
	public BigDecimal unqualAmt;
	public BigDecimal unquAmntUsd;
	public BigDecimal disquaAmtRmb;
	public BigDecimal claimAmt;
	public BigDecimal claimAmtUsd;
	public BigDecimal claimAmtRmb;
	public String disquaContCodes;
	public String inspUnqResn;
	public String inpUnqualHaCode;
	public String inspPatternCode;
	public String wtDetModeCode;
	public String wtDetWorkModeC;
	public String damagIdProCode;
	public String damgedResnCode;
	public BigDecimal damagedAmt;
	public BigDecimal damageAmtUsd;
	public BigDecimal damageAmtRmb;
	public String qurUnqulRsnCode;
	public String qurUnqProcCode;
	public String speQuarTrmtMecC;
	public String quarTrtOrgCode;
	public String quarTrtDeptCode;
	public String statUnitName;
	public String inspContCodes;
	public String goodsNameCn;
	public String goodsNameEn;
	public String goodsflag;
	public String inspResEval;
	public String inspOrgCode;
	public String inspDeptCode;
	public BigDecimal inspUnquafWt;
	public BigDecimal unqulCommInsQty;
	public BigDecimal inspUnquaAmt;
	public BigDecimal inspUnquAmntUs;
	public BigDecimal inspDisquaAmtRmb;
	public String quarResEval;
	public String quaraOrgCode;
	public String quarDeptCode;
	public BigDecimal quaranUnquaWt;
	public BigDecimal unqulfdQuarQty;
	public BigDecimal unqualQuarAmt;
	public BigDecimal unqulQuarAmtUs;
	public BigDecimal unqulQuarAmtCn;
	public BigDecimal relsWtValue;
	public BigDecimal relsQtyValue;
	public BigDecimal releaseAmt;
	public BigDecimal relsAmountUsd;
	public BigDecimal relsAmountRmb;
	public BigDecimal relsPackQty;
	public BigDecimal relsStdWt;
	public BigDecimal relsStdQty;
	public String apprslOrgCode;
	public String apprtDeptCode;
	public String inspContStr;
	public String quarContStr;
	public String inspDisquaContCodes;
	public String quarDisquaContCodes;
	public String prevtivTreatmt;
	public String mnufctrCode;
	public String prodBatchNo;
	public String inspOperCode;
	public Date insOpertDate;
	public String quarOperCode;
	public Date quarCondtTime;
	public String idenOperCode;
	public Date apprCondtTime;
	public String sntTrtOperCode;
	public Date treatOperateDate;
	public String treatUnit;
	public BigDecimal treatTime;
	public String treatTimeUnit;
	public BigDecimal treatTemper;
	public String medicName;
	public BigDecimal prevTreatTm;
	public String preTreatTmUnit;
	public BigDecimal prvntTreatTemp;
	public String prevMedicName;
	public BigDecimal treatMedicDens;
	public BigDecimal medicConcen;
	public BigDecimal actualQty;
	public BigDecimal realWeight;
	public BigDecimal actSmplNum;
	public BigDecimal suggSmplNum;
	public BigDecimal inspQty;
	public BigDecimal declWt;
	public BigDecimal declGoodsValues;
	public BigDecimal declValuesUsd;
	public BigDecimal declValuesRmb;
	public String produceDate;
	public String extDisquaCauseCode;
	public String extDisquaCauseDesc;
	public String extDisquCauseCode;
	public String extDisquCauseDesc;
	public String standardNo;
	public String disDetailInfo;
	public String riskInfoLevelCode;
	public String reportOrgCode;
	public String disquaTypeCode;
	public String falgArchive;
	public Date operTime;
	public String contNo;
	public String preMeasBasisCode;
	public Date archiveTime;
	public String inspResSpot;
	public String quarResSpot;
	
	
	//////
	public String operOrg;
	public String inspBFlag;
	public String BOrgCode;
	public String BOperatorCode;
	public String transBatch;

	// Constructors

	/** default constructor */
	public InsResultGoods() {
	}

	/** minimal constructor */
	public InsResultGoods(String resultGoodsId, String declNo, BigDecimal goodsNo) {
		this.resultGoodsId = resultGoodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
	}

	/** full constructor */
	public InsResultGoods(String resultGoodsId, String declNo, BigDecimal goodsNo,
			String prodHsCode, String statKindCode, String spec,
			String mesuUnTypCode, BigDecimal weightNet, BigDecimal weightGross,
			String wtUnitCode, BigDecimal stdWt, String stdWtUnitCode,
			BigDecimal statclWtValue, String statWtUnitCode, BigDecimal qty,
			String qtyUnitCode, BigDecimal stdQty, String stdQtyUnitCode,
			BigDecimal statclQtyValue, String statQuatyUnCo, BigDecimal packQty,
			String packTypeCode, String currency, BigDecimal goodsTotalVal,
			BigDecimal totalValUs, BigDecimal totalValCn, String goodsPlace,
			Date entryDate, Date cmplDschrgDt, BigDecimal unquaWt,
			BigDecimal unqualQty, BigDecimal unqualAmt, BigDecimal unquAmntUsd,
			BigDecimal disquaAmtRmb, BigDecimal claimAmt, BigDecimal claimAmtUsd,
			BigDecimal claimAmtRmb, String disquaContCodes, String inspUnqResn,
			String inpUnqualHaCode, String inspPatternCode,
			String wtDetModeCode, String wtDetWorkModeC, String damagIdProCode,
			String damgedResnCode, BigDecimal damagedAmt, BigDecimal damageAmtUsd,
			BigDecimal damageAmtRmb, String qurUnqulRsnCode, String qurUnqProcCode,
			String speQuarTrmtMecC, String quarTrtOrgCode,
			String quarTrtDeptCode, String statUnitName, String inspContCodes,
			String goodsNameCn, String goodsNameEn, String goodsflag,
			String inspResEval, String inspOrgCode, String inspDeptCode,
			BigDecimal inspUnquafWt, BigDecimal unqulCommInsQty, BigDecimal inspUnquaAmt,
			BigDecimal inspUnquAmntUs, BigDecimal inspDisquaAmtRmb, String quarResEval,
			String quaraOrgCode, String quarDeptCode, BigDecimal quaranUnquaWt,
			BigDecimal unqulfdQuarQty, BigDecimal unqualQuarAmt, BigDecimal unqulQuarAmtUs,
			BigDecimal unqulQuarAmtCn, BigDecimal relsWtValue, BigDecimal relsQtyValue,
			BigDecimal releaseAmt, BigDecimal relsAmountUsd, BigDecimal relsAmountRmb,
			BigDecimal relsPackQty, BigDecimal relsStdWt, BigDecimal relsStdQty,
			String apprslOrgCode, String apprtDeptCode, String inspContStr,
			String quarContStr, String inspDisquaContCodes,
			String quarDisquaContCodes, String prevtivTreatmt,
			String mnufctrCode, String prodBatchNo, String inspOperCode,
			Date insOpertDate, String quarOperCode,
			Date quarCondtTime, String idenOperCode,
			Date apprCondtTime, String sntTrtOperCode,
			Date treatOperateDate, String treatUnit, BigDecimal treatTime,
			String treatTimeUnit, BigDecimal treatTemper, String medicName,
			BigDecimal prevTreatTm, String preTreatTmUnit, BigDecimal prvntTreatTemp,
			String prevMedicName, BigDecimal treatMedicDens, BigDecimal medicConcen,
			BigDecimal actualQty, BigDecimal realWeight, BigDecimal actSmplNum,
			BigDecimal suggSmplNum, BigDecimal inspQty, BigDecimal declWt,
			BigDecimal declGoodsValues, BigDecimal declValuesUsd, BigDecimal declValuesRmb,
			String produceDate, String extDisquaCauseCode,
			String extDisquaCauseDesc, String extDisquCauseCode,
			String extDisquCauseDesc, String standardNo, String disDetailInfo,
			String riskInfoLevelCode, String reportOrgCode,
			String disquaTypeCode, String falgArchive, Date operTime,
			String contNo, String preMeasBasisCode, Date archiveTime,
			String inspResSpot, String quarResSpot) {
		this.resultGoodsId = resultGoodsId;
		this.declNo = declNo;
		this.goodsNo = goodsNo;
		this.prodHsCode = prodHsCode;
		this.statKindCode = statKindCode;
		this.spec = spec;
		this.mesuUnTypCode = mesuUnTypCode;
		this.weightNet = weightNet;
		this.weightGross = weightGross;
		this.wtUnitCode = wtUnitCode;
		this.stdWt = stdWt;
		this.stdWtUnitCode = stdWtUnitCode;
		this.statclWtValue = statclWtValue;
		this.statWtUnitCode = statWtUnitCode;
		this.qty = qty;
		this.qtyUnitCode = qtyUnitCode;
		this.stdQty = stdQty;
		this.stdQtyUnitCode = stdQtyUnitCode;
		this.statclQtyValue = statclQtyValue;
		this.statQuatyUnCo = statQuatyUnCo;
		this.packQty = packQty;
		this.packTypeCode = packTypeCode;
		this.currency = currency;
		this.goodsTotalVal = goodsTotalVal;
		this.totalValUs = totalValUs;
		this.totalValCn = totalValCn;
		this.goodsPlace = goodsPlace;
		this.entryDate = entryDate;
		this.cmplDschrgDt = cmplDschrgDt;
		this.unquaWt = unquaWt;
		this.unqualQty = unqualQty;
		this.unqualAmt = unqualAmt;
		this.unquAmntUsd = unquAmntUsd;
		this.disquaAmtRmb = disquaAmtRmb;
		this.claimAmt = claimAmt;
		this.claimAmtUsd = claimAmtUsd;
		this.claimAmtRmb = claimAmtRmb;
		this.disquaContCodes = disquaContCodes;
		this.inspUnqResn = inspUnqResn;
		this.inpUnqualHaCode = inpUnqualHaCode;
		this.inspPatternCode = inspPatternCode;
		this.wtDetModeCode = wtDetModeCode;
		this.wtDetWorkModeC = wtDetWorkModeC;
		this.damagIdProCode = damagIdProCode;
		this.damgedResnCode = damgedResnCode;
		this.damagedAmt = damagedAmt;
		this.damageAmtUsd = damageAmtUsd;
		this.damageAmtRmb = damageAmtRmb;
		this.qurUnqulRsnCode = qurUnqulRsnCode;
		this.qurUnqProcCode = qurUnqProcCode;
		this.speQuarTrmtMecC = speQuarTrmtMecC;
		this.quarTrtOrgCode = quarTrtOrgCode;
		this.quarTrtDeptCode = quarTrtDeptCode;
		this.statUnitName = statUnitName;
		this.inspContCodes = inspContCodes;
		this.goodsNameCn = goodsNameCn;
		this.goodsNameEn = goodsNameEn;
		this.goodsflag = goodsflag;
		this.inspResEval = inspResEval;
		this.inspOrgCode = inspOrgCode;
		this.inspDeptCode = inspDeptCode;
		this.inspUnquafWt = inspUnquafWt;
		this.unqulCommInsQty = unqulCommInsQty;
		this.inspUnquaAmt = inspUnquaAmt;
		this.inspUnquAmntUs = inspUnquAmntUs;
		this.inspDisquaAmtRmb = inspDisquaAmtRmb;
		this.quarResEval = quarResEval;
		this.quaraOrgCode = quaraOrgCode;
		this.quarDeptCode = quarDeptCode;
		this.quaranUnquaWt = quaranUnquaWt;
		this.unqulfdQuarQty = unqulfdQuarQty;
		this.unqualQuarAmt = unqualQuarAmt;
		this.unqulQuarAmtUs = unqulQuarAmtUs;
		this.unqulQuarAmtCn = unqulQuarAmtCn;
		this.relsWtValue = relsWtValue;
		this.relsQtyValue = relsQtyValue;
		this.releaseAmt = releaseAmt;
		this.relsAmountUsd = relsAmountUsd;
		this.relsAmountRmb = relsAmountRmb;
		this.relsPackQty = relsPackQty;
		this.relsStdWt = relsStdWt;
		this.relsStdQty = relsStdQty;
		this.apprslOrgCode = apprslOrgCode;
		this.apprtDeptCode = apprtDeptCode;
		this.inspContStr = inspContStr;
		this.quarContStr = quarContStr;
		this.inspDisquaContCodes = inspDisquaContCodes;
		this.quarDisquaContCodes = quarDisquaContCodes;
		this.prevtivTreatmt = prevtivTreatmt;
		this.mnufctrCode = mnufctrCode;
		this.prodBatchNo = prodBatchNo;
		this.inspOperCode = inspOperCode;
		this.insOpertDate = insOpertDate;
		this.quarOperCode = quarOperCode;
		this.quarCondtTime = quarCondtTime;
		this.idenOperCode = idenOperCode;
		this.apprCondtTime = apprCondtTime;
		this.sntTrtOperCode = sntTrtOperCode;
		this.treatOperateDate = treatOperateDate;
		this.treatUnit = treatUnit;
		this.treatTime = treatTime;
		this.treatTimeUnit = treatTimeUnit;
		this.treatTemper = treatTemper;
		this.medicName = medicName;
		this.prevTreatTm = prevTreatTm;
		this.preTreatTmUnit = preTreatTmUnit;
		this.prvntTreatTemp = prvntTreatTemp;
		this.prevMedicName = prevMedicName;
		this.treatMedicDens = treatMedicDens;
		this.medicConcen = medicConcen;
		this.actualQty = actualQty;
		this.realWeight = realWeight;
		this.actSmplNum = actSmplNum;
		this.suggSmplNum = suggSmplNum;
		this.inspQty = inspQty;
		this.declWt = declWt;
		this.declGoodsValues = declGoodsValues;
		this.declValuesUsd = declValuesUsd;
		this.declValuesRmb = declValuesRmb;
		this.produceDate = produceDate;
		this.extDisquaCauseCode = extDisquaCauseCode;
		this.extDisquaCauseDesc = extDisquaCauseDesc;
		this.extDisquCauseCode = extDisquCauseCode;
		this.extDisquCauseDesc = extDisquCauseDesc;
		this.standardNo = standardNo;
		this.disDetailInfo = disDetailInfo;
		this.riskInfoLevelCode = riskInfoLevelCode;
		this.reportOrgCode = reportOrgCode;
		this.disquaTypeCode = disquaTypeCode;
		this.falgArchive = falgArchive;
		this.operTime = operTime;
		this.contNo = contNo;
		this.preMeasBasisCode = preMeasBasisCode;
		this.archiveTime = archiveTime;
		this.inspResSpot = inspResSpot;
		this.quarResSpot = quarResSpot;
	}

	public String getResultGoodsId() {
		return resultGoodsId;
	}

	public void setResultGoodsId(String resultGoodsId) {
		this.resultGoodsId = resultGoodsId;
	}

	public String getDeclNo() {
		return declNo;
	}

	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}

	public BigDecimal getGoodsNo() {
		return goodsNo;
	}

	public void setGoodsNo(BigDecimal goodsNo) {
		this.goodsNo = goodsNo;
	}

	public String getProdHsCode() {
		return prodHsCode;
	}

	public void setProdHsCode(String prodHsCode) {
		this.prodHsCode = prodHsCode;
	}

	public String getStatKindCode() {
		return statKindCode;
	}

	public void setStatKindCode(String statKindCode) {
		this.statKindCode = statKindCode;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getMesuUnTypCode() {
		return mesuUnTypCode;
	}

	public void setMesuUnTypCode(String mesuUnTypCode) {
		this.mesuUnTypCode = mesuUnTypCode;
	}

	public BigDecimal getWeightNet() {
		return weightNet;
	}

	public void setWeightNet(BigDecimal weightNet) {
		this.weightNet = weightNet;
	}

	public BigDecimal getWeightGross() {
		return weightGross;
	}

	public void setWeightGross(BigDecimal weightGross) {
		this.weightGross = weightGross;
	}

	public String getWtUnitCode() {
		return wtUnitCode;
	}

	public void setWtUnitCode(String wtUnitCode) {
		this.wtUnitCode = wtUnitCode;
	}

	public BigDecimal getStdWt() {
		return stdWt;
	}

	public void setStdWt(BigDecimal stdWt) {
		this.stdWt = stdWt;
	}

	public String getStdWtUnitCode() {
		return stdWtUnitCode;
	}

	public void setStdWtUnitCode(String stdWtUnitCode) {
		this.stdWtUnitCode = stdWtUnitCode;
	}

	public BigDecimal getStatclWtValue() {
		return statclWtValue;
	}

	public void setStatclWtValue(BigDecimal statclWtValue) {
		this.statclWtValue = statclWtValue;
	}

	public String getStatWtUnitCode() {
		return statWtUnitCode;
	}

	public void setStatWtUnitCode(String statWtUnitCode) {
		this.statWtUnitCode = statWtUnitCode;
	}

	public BigDecimal getQty() {
		return qty;
	}

	public void setQty(BigDecimal qty) {
		this.qty = qty;
	}

	public String getQtyUnitCode() {
		return qtyUnitCode;
	}

	public void setQtyUnitCode(String qtyUnitCode) {
		this.qtyUnitCode = qtyUnitCode;
	}

	public BigDecimal getStdQty() {
		return stdQty;
	}

	public void setStdQty(BigDecimal stdQty) {
		this.stdQty = stdQty;
	}

	public String getStdQtyUnitCode() {
		return stdQtyUnitCode;
	}

	public void setStdQtyUnitCode(String stdQtyUnitCode) {
		this.stdQtyUnitCode = stdQtyUnitCode;
	}

	public BigDecimal getStatclQtyValue() {
		return statclQtyValue;
	}

	public void setStatclQtyValue(BigDecimal statclQtyValue) {
		this.statclQtyValue = statclQtyValue;
	}

	public String getStatQuatyUnCo() {
		return statQuatyUnCo;
	}

	public void setStatQuatyUnCo(String statQuatyUnCo) {
		this.statQuatyUnCo = statQuatyUnCo;
	}

	public BigDecimal getPackQty() {
		return packQty;
	}

	public void setPackQty(BigDecimal packQty) {
		this.packQty = packQty;
	}

	public String getPackTypeCode() {
		return packTypeCode;
	}

	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getGoodsTotalVal() {
		return goodsTotalVal;
	}

	public void setGoodsTotalVal(BigDecimal goodsTotalVal) {
		this.goodsTotalVal = goodsTotalVal;
	}

	public BigDecimal getTotalValUs() {
		return totalValUs;
	}

	public void setTotalValUs(BigDecimal totalValUs) {
		this.totalValUs = totalValUs;
	}

	public BigDecimal getTotalValCn() {
		return totalValCn;
	}

	public void setTotalValCn(BigDecimal totalValCn) {
		this.totalValCn = totalValCn;
	}

	public String getGoodsPlace() {
		return goodsPlace;
	}

	public void setGoodsPlace(String goodsPlace) {
		this.goodsPlace = goodsPlace;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public Date getCmplDschrgDt() {
		return cmplDschrgDt;
	}

	public void setCmplDschrgDt(Date cmplDschrgDt) {
		this.cmplDschrgDt = cmplDschrgDt;
	}

	public BigDecimal getUnquaWt() {
		return unquaWt;
	}

	public void setUnquaWt(BigDecimal unquaWt) {
		this.unquaWt = unquaWt;
	}

	public BigDecimal getUnqualQty() {
		return unqualQty;
	}

	public void setUnqualQty(BigDecimal unqualQty) {
		this.unqualQty = unqualQty;
	}

	public BigDecimal getUnqualAmt() {
		return unqualAmt;
	}

	public void setUnqualAmt(BigDecimal unqualAmt) {
		this.unqualAmt = unqualAmt;
	}

	public BigDecimal getUnquAmntUsd() {
		return unquAmntUsd;
	}

	public void setUnquAmntUsd(BigDecimal unquAmntUsd) {
		this.unquAmntUsd = unquAmntUsd;
	}

	public BigDecimal getDisquaAmtRmb() {
		return disquaAmtRmb;
	}

	public void setDisquaAmtRmb(BigDecimal disquaAmtRmb) {
		this.disquaAmtRmb = disquaAmtRmb;
	}

	public BigDecimal getClaimAmt() {
		return claimAmt;
	}

	public void setClaimAmt(BigDecimal claimAmt) {
		this.claimAmt = claimAmt;
	}

	public BigDecimal getClaimAmtUsd() {
		return claimAmtUsd;
	}

	public void setClaimAmtUsd(BigDecimal claimAmtUsd) {
		this.claimAmtUsd = claimAmtUsd;
	}

	public BigDecimal getClaimAmtRmb() {
		return claimAmtRmb;
	}

	public void setClaimAmtRmb(BigDecimal claimAmtRmb) {
		this.claimAmtRmb = claimAmtRmb;
	}

	public String getDisquaContCodes() {
		return disquaContCodes;
	}

	public void setDisquaContCodes(String disquaContCodes) {
		this.disquaContCodes = disquaContCodes;
	}

	public String getInspUnqResn() {
		return inspUnqResn;
	}

	public void setInspUnqResn(String inspUnqResn) {
		this.inspUnqResn = inspUnqResn;
	}

	public String getInpUnqualHaCode() {
		return inpUnqualHaCode;
	}

	public void setInpUnqualHaCode(String inpUnqualHaCode) {
		this.inpUnqualHaCode = inpUnqualHaCode;
	}

	public String getInspPatternCode() {
		return inspPatternCode;
	}

	public void setInspPatternCode(String inspPatternCode) {
		this.inspPatternCode = inspPatternCode;
	}

	public String getWtDetModeCode() {
		return wtDetModeCode;
	}

	public void setWtDetModeCode(String wtDetModeCode) {
		this.wtDetModeCode = wtDetModeCode;
	}

	public String getWtDetWorkModeC() {
		return wtDetWorkModeC;
	}

	public void setWtDetWorkModeC(String wtDetWorkModeC) {
		this.wtDetWorkModeC = wtDetWorkModeC;
	}

	public String getDamagIdProCode() {
		return damagIdProCode;
	}

	public void setDamagIdProCode(String damagIdProCode) {
		this.damagIdProCode = damagIdProCode;
	}

	public String getDamgedResnCode() {
		return damgedResnCode;
	}

	public void setDamgedResnCode(String damgedResnCode) {
		this.damgedResnCode = damgedResnCode;
	}

	public BigDecimal getDamagedAmt() {
		return damagedAmt;
	}

	public void setDamagedAmt(BigDecimal damagedAmt) {
		this.damagedAmt = damagedAmt;
	}

	public BigDecimal getDamageAmtUsd() {
		return damageAmtUsd;
	}

	public void setDamageAmtUsd(BigDecimal damageAmtUsd) {
		this.damageAmtUsd = damageAmtUsd;
	}

	public BigDecimal getDamageAmtRmb() {
		return damageAmtRmb;
	}

	public void setDamageAmtRmb(BigDecimal damageAmtRmb) {
		this.damageAmtRmb = damageAmtRmb;
	}

	public String getQurUnqulRsnCode() {
		return qurUnqulRsnCode;
	}

	public void setQurUnqulRsnCode(String qurUnqulRsnCode) {
		this.qurUnqulRsnCode = qurUnqulRsnCode;
	}

	public String getQurUnqProcCode() {
		return qurUnqProcCode;
	}

	public void setQurUnqProcCode(String qurUnqProcCode) {
		this.qurUnqProcCode = qurUnqProcCode;
	}

	public String getSpeQuarTrmtMecC() {
		return speQuarTrmtMecC;
	}

	public void setSpeQuarTrmtMecC(String speQuarTrmtMecC) {
		this.speQuarTrmtMecC = speQuarTrmtMecC;
	}

	public String getQuarTrtOrgCode() {
		return quarTrtOrgCode;
	}

	public void setQuarTrtOrgCode(String quarTrtOrgCode) {
		this.quarTrtOrgCode = quarTrtOrgCode;
	}

	public String getQuarTrtDeptCode() {
		return quarTrtDeptCode;
	}

	public void setQuarTrtDeptCode(String quarTrtDeptCode) {
		this.quarTrtDeptCode = quarTrtDeptCode;
	}

	public String getStatUnitName() {
		return statUnitName;
	}

	public void setStatUnitName(String statUnitName) {
		this.statUnitName = statUnitName;
	}

	public String getInspContCodes() {
		return inspContCodes;
	}

	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}

	public String getGoodsNameCn() {
		return goodsNameCn;
	}

	public void setGoodsNameCn(String goodsNameCn) {
		this.goodsNameCn = goodsNameCn;
	}

	public String getGoodsNameEn() {
		return goodsNameEn;
	}

	public void setGoodsNameEn(String goodsNameEn) {
		this.goodsNameEn = goodsNameEn;
	}

	public String getGoodsflag() {
		return goodsflag;
	}

	public void setGoodsflag(String goodsflag) {
		this.goodsflag = goodsflag;
	}

	public String getInspResEval() {
		return inspResEval;
	}

	public void setInspResEval(String inspResEval) {
		this.inspResEval = inspResEval;
	}

	public String getInspOrgCode() {
		return inspOrgCode;
	}

	public void setInspOrgCode(String inspOrgCode) {
		this.inspOrgCode = inspOrgCode;
	}

	public String getInspDeptCode() {
		return inspDeptCode;
	}

	public void setInspDeptCode(String inspDeptCode) {
		this.inspDeptCode = inspDeptCode;
	}

	public BigDecimal getInspUnquafWt() {
		return inspUnquafWt;
	}

	public void setInspUnquafWt(BigDecimal inspUnquafWt) {
		this.inspUnquafWt = inspUnquafWt;
	}

	public BigDecimal getUnqulCommInsQty() {
		return unqulCommInsQty;
	}

	public void setUnqulCommInsQty(BigDecimal unqulCommInsQty) {
		this.unqulCommInsQty = unqulCommInsQty;
	}

	public BigDecimal getInspUnquaAmt() {
		return inspUnquaAmt;
	}

	public void setInspUnquaAmt(BigDecimal inspUnquaAmt) {
		this.inspUnquaAmt = inspUnquaAmt;
	}

	public BigDecimal getInspUnquAmntUs() {
		return inspUnquAmntUs;
	}

	public void setInspUnquAmntUs(BigDecimal inspUnquAmntUs) {
		this.inspUnquAmntUs = inspUnquAmntUs;
	}

	public BigDecimal getInspDisquaAmtRmb() {
		return inspDisquaAmtRmb;
	}

	public void setInspDisquaAmtRmb(BigDecimal inspDisquaAmtRmb) {
		this.inspDisquaAmtRmb = inspDisquaAmtRmb;
	}

	public String getQuarResEval() {
		return quarResEval;
	}

	public void setQuarResEval(String quarResEval) {
		this.quarResEval = quarResEval;
	}

	public String getQuaraOrgCode() {
		return quaraOrgCode;
	}

	public void setQuaraOrgCode(String quaraOrgCode) {
		this.quaraOrgCode = quaraOrgCode;
	}

	public String getQuarDeptCode() {
		return quarDeptCode;
	}

	public void setQuarDeptCode(String quarDeptCode) {
		this.quarDeptCode = quarDeptCode;
	}

	public BigDecimal getQuaranUnquaWt() {
		return quaranUnquaWt;
	}

	public void setQuaranUnquaWt(BigDecimal quaranUnquaWt) {
		this.quaranUnquaWt = quaranUnquaWt;
	}

	public BigDecimal getUnqulfdQuarQty() {
		return unqulfdQuarQty;
	}

	public void setUnqulfdQuarQty(BigDecimal unqulfdQuarQty) {
		this.unqulfdQuarQty = unqulfdQuarQty;
	}

	public BigDecimal getUnqualQuarAmt() {
		return unqualQuarAmt;
	}

	public void setUnqualQuarAmt(BigDecimal unqualQuarAmt) {
		this.unqualQuarAmt = unqualQuarAmt;
	}

	public BigDecimal getUnqulQuarAmtUs() {
		return unqulQuarAmtUs;
	}

	public void setUnqulQuarAmtUs(BigDecimal unqulQuarAmtUs) {
		this.unqulQuarAmtUs = unqulQuarAmtUs;
	}

	public BigDecimal getUnqulQuarAmtCn() {
		return unqulQuarAmtCn;
	}

	public void setUnqulQuarAmtCn(BigDecimal unqulQuarAmtCn) {
		this.unqulQuarAmtCn = unqulQuarAmtCn;
	}

	public BigDecimal getRelsWtValue() {
		return relsWtValue;
	}

	public void setRelsWtValue(BigDecimal relsWtValue) {
		this.relsWtValue = relsWtValue;
	}

	public BigDecimal getRelsQtyValue() {
		return relsQtyValue;
	}

	public void setRelsQtyValue(BigDecimal relsQtyValue) {
		this.relsQtyValue = relsQtyValue;
	}

	public BigDecimal getReleaseAmt() {
		return releaseAmt;
	}

	public void setReleaseAmt(BigDecimal releaseAmt) {
		this.releaseAmt = releaseAmt;
	}

	public BigDecimal getRelsAmountUsd() {
		return relsAmountUsd;
	}

	public void setRelsAmountUsd(BigDecimal relsAmountUsd) {
		this.relsAmountUsd = relsAmountUsd;
	}

	public BigDecimal getRelsAmountRmb() {
		return relsAmountRmb;
	}

	public void setRelsAmountRmb(BigDecimal relsAmountRmb) {
		this.relsAmountRmb = relsAmountRmb;
	}

	public BigDecimal getRelsPackQty() {
		return relsPackQty;
	}

	public void setRelsPackQty(BigDecimal relsPackQty) {
		this.relsPackQty = relsPackQty;
	}

	public BigDecimal getRelsStdWt() {
		return relsStdWt;
	}

	public void setRelsStdWt(BigDecimal relsStdWt) {
		this.relsStdWt = relsStdWt;
	}

	public BigDecimal getRelsStdQty() {
		return relsStdQty;
	}

	public void setRelsStdQty(BigDecimal relsStdQty) {
		this.relsStdQty = relsStdQty;
	}

	public String getApprslOrgCode() {
		return apprslOrgCode;
	}

	public void setApprslOrgCode(String apprslOrgCode) {
		this.apprslOrgCode = apprslOrgCode;
	}

	public String getApprtDeptCode() {
		return apprtDeptCode;
	}

	public void setApprtDeptCode(String apprtDeptCode) {
		this.apprtDeptCode = apprtDeptCode;
	}

	public String getInspContStr() {
		return inspContStr;
	}

	public void setInspContStr(String inspContStr) {
		this.inspContStr = inspContStr;
	}

	public String getQuarContStr() {
		return quarContStr;
	}

	public void setQuarContStr(String quarContStr) {
		this.quarContStr = quarContStr;
	}

	public String getInspDisquaContCodes() {
		return inspDisquaContCodes;
	}

	public void setInspDisquaContCodes(String inspDisquaContCodes) {
		this.inspDisquaContCodes = inspDisquaContCodes;
	}

	public String getQuarDisquaContCodes() {
		return quarDisquaContCodes;
	}

	public void setQuarDisquaContCodes(String quarDisquaContCodes) {
		this.quarDisquaContCodes = quarDisquaContCodes;
	}

	public String getPrevtivTreatmt() {
		return prevtivTreatmt;
	}

	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}

	public String getMnufctrCode() {
		return mnufctrCode;
	}

	public void setMnufctrCode(String mnufctrCode) {
		this.mnufctrCode = mnufctrCode;
	}

	public String getProdBatchNo() {
		return prodBatchNo;
	}

	public void setProdBatchNo(String prodBatchNo) {
		this.prodBatchNo = prodBatchNo;
	}

	public String getInspOperCode() {
		return inspOperCode;
	}

	public void setInspOperCode(String inspOperCode) {
		this.inspOperCode = inspOperCode;
	}

	public Date getInsOpertDate() {
		return insOpertDate;
	}

	public void setInsOpertDate(Date insOpertDate) {
		this.insOpertDate = insOpertDate;
	}

	public String getQuarOperCode() {
		return quarOperCode;
	}

	public void setQuarOperCode(String quarOperCode) {
		this.quarOperCode = quarOperCode;
	}

	public Date getQuarCondtTime() {
		return quarCondtTime;
	}

	public void setQuarCondtTime(Date quarCondtTime) {
		this.quarCondtTime = quarCondtTime;
	}

	public String getIdenOperCode() {
		return idenOperCode;
	}

	public void setIdenOperCode(String idenOperCode) {
		this.idenOperCode = idenOperCode;
	}

	public Date getApprCondtTime() {
		return apprCondtTime;
	}

	public void setApprCondtTime(Date apprCondtTime) {
		this.apprCondtTime = apprCondtTime;
	}

	public String getSntTrtOperCode() {
		return sntTrtOperCode;
	}

	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}

	public Date getTreatOperateDate() {
		return treatOperateDate;
	}

	public void setTreatOperateDate(Date treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}

	public String getTreatUnit() {
		return treatUnit;
	}

	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}

	public BigDecimal getTreatTime() {
		return treatTime;
	}

	public void setTreatTime(BigDecimal treatTime) {
		this.treatTime = treatTime;
	}

	public String getTreatTimeUnit() {
		return treatTimeUnit;
	}

	public void setTreatTimeUnit(String treatTimeUnit) {
		this.treatTimeUnit = treatTimeUnit;
	}

	public BigDecimal getTreatTemper() {
		return treatTemper;
	}

	public void setTreatTemper(BigDecimal treatTemper) {
		this.treatTemper = treatTemper;
	}

	public String getMedicName() {
		return medicName;
	}

	public void setMedicName(String medicName) {
		this.medicName = medicName;
	}

	public BigDecimal getPrevTreatTm() {
		return prevTreatTm;
	}

	public void setPrevTreatTm(BigDecimal prevTreatTm) {
		this.prevTreatTm = prevTreatTm;
	}

	public String getPreTreatTmUnit() {
		return preTreatTmUnit;
	}

	public void setPreTreatTmUnit(String preTreatTmUnit) {
		this.preTreatTmUnit = preTreatTmUnit;
	}

	public BigDecimal getPrvntTreatTemp() {
		return prvntTreatTemp;
	}

	public void setPrvntTreatTemp(BigDecimal prvntTreatTemp) {
		this.prvntTreatTemp = prvntTreatTemp;
	}

	public String getPrevMedicName() {
		return prevMedicName;
	}

	public void setPrevMedicName(String prevMedicName) {
		this.prevMedicName = prevMedicName;
	}

	public BigDecimal getTreatMedicDens() {
		return treatMedicDens;
	}

	public void setTreatMedicDens(BigDecimal treatMedicDens) {
		this.treatMedicDens = treatMedicDens;
	}

	public BigDecimal getMedicConcen() {
		return medicConcen;
	}

	public void setMedicConcen(BigDecimal medicConcen) {
		this.medicConcen = medicConcen;
	}

	public BigDecimal getActualQty() {
		return actualQty;
	}

	public void setActualQty(BigDecimal actualQty) {
		this.actualQty = actualQty;
	}

	public BigDecimal getRealWeight() {
		return realWeight;
	}

	public void setRealWeight(BigDecimal realWeight) {
		this.realWeight = realWeight;
	}

	public BigDecimal getActSmplNum() {
		return actSmplNum;
	}

	public void setActSmplNum(BigDecimal actSmplNum) {
		this.actSmplNum = actSmplNum;
	}

	public BigDecimal getSuggSmplNum() {
		return suggSmplNum;
	}

	public void setSuggSmplNum(BigDecimal suggSmplNum) {
		this.suggSmplNum = suggSmplNum;
	}

	public BigDecimal getInspQty() {
		return inspQty;
	}

	public void setInspQty(BigDecimal inspQty) {
		this.inspQty = inspQty;
	}

	public BigDecimal getDeclWt() {
		return declWt;
	}

	public void setDeclWt(BigDecimal declWt) {
		this.declWt = declWt;
	}

	public BigDecimal getDeclGoodsValues() {
		return declGoodsValues;
	}

	public void setDeclGoodsValues(BigDecimal declGoodsValues) {
		this.declGoodsValues = declGoodsValues;
	}

	public BigDecimal getDeclValuesUsd() {
		return declValuesUsd;
	}

	public void setDeclValuesUsd(BigDecimal declValuesUsd) {
		this.declValuesUsd = declValuesUsd;
	}

	public BigDecimal getDeclValuesRmb() {
		return declValuesRmb;
	}

	public void setDeclValuesRmb(BigDecimal declValuesRmb) {
		this.declValuesRmb = declValuesRmb;
	}

	public String getProduceDate() {
		return produceDate;
	}

	public void setProduceDate(String produceDate) {
		this.produceDate = produceDate;
	}

	public String getExtDisquaCauseCode() {
		return extDisquaCauseCode;
	}

	public void setExtDisquaCauseCode(String extDisquaCauseCode) {
		this.extDisquaCauseCode = extDisquaCauseCode;
	}

	public String getExtDisquaCauseDesc() {
		return extDisquaCauseDesc;
	}

	public void setExtDisquaCauseDesc(String extDisquaCauseDesc) {
		this.extDisquaCauseDesc = extDisquaCauseDesc;
	}

	public String getExtDisquCauseCode() {
		return extDisquCauseCode;
	}

	public void setExtDisquCauseCode(String extDisquCauseCode) {
		this.extDisquCauseCode = extDisquCauseCode;
	}

	public String getExtDisquCauseDesc() {
		return extDisquCauseDesc;
	}

	public void setExtDisquCauseDesc(String extDisquCauseDesc) {
		this.extDisquCauseDesc = extDisquCauseDesc;
	}

	public String getStandardNo() {
		return standardNo;
	}

	public void setStandardNo(String standardNo) {
		this.standardNo = standardNo;
	}

	public String getDisDetailInfo() {
		return disDetailInfo;
	}

	public void setDisDetailInfo(String disDetailInfo) {
		this.disDetailInfo = disDetailInfo;
	}

	public String getRiskInfoLevelCode() {
		return riskInfoLevelCode;
	}

	public void setRiskInfoLevelCode(String riskInfoLevelCode) {
		this.riskInfoLevelCode = riskInfoLevelCode;
	}

	public String getReportOrgCode() {
		return reportOrgCode;
	}

	public void setReportOrgCode(String reportOrgCode) {
		this.reportOrgCode = reportOrgCode;
	}

	public String getDisquaTypeCode() {
		return disquaTypeCode;
	}

	public void setDisquaTypeCode(String disquaTypeCode) {
		this.disquaTypeCode = disquaTypeCode;
	}

	public String getFalgArchive() {
		return falgArchive;
	}

	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}

	public Date getOperTime() {
		return operTime;
	}

	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}

	public String getContNo() {
		return contNo;
	}

	public void setContNo(String contNo) {
		this.contNo = contNo;
	}

	public String getPreMeasBasisCode() {
		return preMeasBasisCode;
	}

	public void setPreMeasBasisCode(String preMeasBasisCode) {
		this.preMeasBasisCode = preMeasBasisCode;
	}

	public Date getArchiveTime() {
		return archiveTime;
	}

	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}

	public String getInspResSpot() {
		return inspResSpot;
	}

	public void setInspResSpot(String inspResSpot) {
		this.inspResSpot = inspResSpot;
	}

	public String getQuarResSpot() {
		return quarResSpot;
	}

	public void setQuarResSpot(String quarResSpot) {
		this.quarResSpot = quarResSpot;
	}

	public String getOperOrg() {
		return operOrg;
	}

	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}

	public String getInspBFlag() {
		return inspBFlag;
	}

	public void setInspBFlag(String inspBFlag) {
		this.inspBFlag = inspBFlag;
	}

	public String getBOrgCode() {
		return BOrgCode;
	}

	public void setBOrgCode(String bOrgCode) {
		BOrgCode = bOrgCode;
	}

	public String getBOperatorCode() {
		return BOperatorCode;
	}

	public void setBOperatorCode(String bOperatorCode) {
		BOperatorCode = bOperatorCode;
	}

	public String getTransBatch() {
		return transBatch;
	}

	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

}
/**  
 * FileName:  ItfInsContainerResultB.java   
 * @Description: 集装箱检验结果
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.math.BigDecimal;
import java.util.Date;

/**  
 * Description: 集装箱检验结果    
 * Copyright:   Copyright (c)2017  
 * Company:     rongji
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:21:24  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                     1.0         1.0 Version  
 */  
public class ItfInsContainerResultB implements java.io.Serializable {

	public static final long serialVersionUID = -1785730632262597939L;
	public String contResultId;
	public String declNo;
	public String cntnrModeCode;
	public BigDecimal containerQty;
	public BigDecimal dispsCtnrQty;
	public String contTestResEval;
	public String cntnrUnqlResnC;
	public String ctnrOrgCode;
	public String ctnrDeptCode;
	public String cntnrOpertoCode;
	public Date contOpetnTime;
	public String prevtivTreatmt;
	public String cntnrTreatCodes;
	public String sanitTrtMethCodes;
	public String sntTrtOrgCode;
	public String treatDeptCode;
	public String sntTrtOperCode;
	public Date treatOperateDate;
	public String apprslOrgCode;
	public String apprtDeptCode;
	public String idenOperCode;
	public Date apprCondtTime;
	public BigDecimal unqulfdQuarQty;
	public BigDecimal unqulfCommQty;
	public BigDecimal unqualCommQtyCmp;
	public String disquaContCode;
	public String treatUnit;
	public BigDecimal declContQty;
	public BigDecimal inspContQty;
	public BigDecimal contagionContQty;
	public BigDecimal faunaFloraContQty;
	public BigDecimal detectionContQty;
	public BigDecimal healthProcContQty;
	public BigDecimal cargInspContQty;
	public String cargDisqualItemOne;
	public String epidSituCatg;
	public String contCategory;
	public String falgArchive;
	public Date operTime;
	public Date archiveTime;
	public String quarUnqualReasonCode;
	public String contNo;
	public String lclFlag;
	public String heavyFlag;
	public String checkQuaFlag;
	public String quaDisposeFlag;
	public String cargInsUnqualFlag;
	public String healthInsUnqualFlag;
	public String quarUnqualContentCodes;
	public String sntTrtFlag;
	public String pamQuaUnqualFlag;
	public String pamUnqualReasonCodes;
	public String pamTrtFlag;
	public String pamTrtMethCodes;
	public String pamTrtOrgCode;
	public String frInfRegFlag;
	public String frPamRegFlag;
	public String billLadNo;
	public String boxCompany;
	public String regNum;
	public String expImpFlag;
	public String tradeCountryCode;
	public String emptyFlag;
	public String contQuarUnqualFlag;
	public String contQuarUnqualDesc;
	public String operOrg;
	public String inspBFlag;
	public String BOrgCode;
	public String BOperatorCode;
	public String transBatch;
	public String getContResultId() {
		return contResultId;
	}
	public void setContResultId(String contResultId) {
		this.contResultId = contResultId;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getCntnrModeCode() {
		return cntnrModeCode;
	}
	public void setCntnrModeCode(String cntnrModeCode) {
		this.cntnrModeCode = cntnrModeCode;
	}
	public BigDecimal getContainerQty() {
		return containerQty;
	}
	public void setContainerQty(BigDecimal containerQty) {
		this.containerQty = containerQty;
	}
	public BigDecimal getDispsCtnrQty() {
		return dispsCtnrQty;
	}
	public void setDispsCtnrQty(BigDecimal dispsCtnrQty) {
		this.dispsCtnrQty = dispsCtnrQty;
	}
	public String getContTestResEval() {
		return contTestResEval;
	}
	public void setContTestResEval(String contTestResEval) {
		this.contTestResEval = contTestResEval;
	}
	public String getCntnrUnqlResnC() {
		return cntnrUnqlResnC;
	}
	public void setCntnrUnqlResnC(String cntnrUnqlResnC) {
		this.cntnrUnqlResnC = cntnrUnqlResnC;
	}
	public String getCtnrOrgCode() {
		return ctnrOrgCode;
	}
	public void setCtnrOrgCode(String ctnrOrgCode) {
		this.ctnrOrgCode = ctnrOrgCode;
	}
	public String getCtnrDeptCode() {
		return ctnrDeptCode;
	}
	public void setCtnrDeptCode(String ctnrDeptCode) {
		this.ctnrDeptCode = ctnrDeptCode;
	}
	public String getCntnrOpertoCode() {
		return cntnrOpertoCode;
	}
	public void setCntnrOpertoCode(String cntnrOpertoCode) {
		this.cntnrOpertoCode = cntnrOpertoCode;
	}
	public Date getContOpetnTime() {
		return contOpetnTime;
	}
	public void setContOpetnTime(Date contOpetnTime) {
		this.contOpetnTime = contOpetnTime;
	}
	public String getPrevtivTreatmt() {
		return prevtivTreatmt;
	}
	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}
	public String getCntnrTreatCodes() {
		return cntnrTreatCodes;
	}
	public void setCntnrTreatCodes(String cntnrTreatCodes) {
		this.cntnrTreatCodes = cntnrTreatCodes;
	}
	public String getSanitTrtMethCodes() {
		return sanitTrtMethCodes;
	}
	public void setSanitTrtMethCodes(String sanitTrtMethCodes) {
		this.sanitTrtMethCodes = sanitTrtMethCodes;
	}
	public String getSntTrtOrgCode() {
		return sntTrtOrgCode;
	}
	public void setSntTrtOrgCode(String sntTrtOrgCode) {
		this.sntTrtOrgCode = sntTrtOrgCode;
	}
	public String getTreatDeptCode() {
		return treatDeptCode;
	}
	public void setTreatDeptCode(String treatDeptCode) {
		this.treatDeptCode = treatDeptCode;
	}
	public String getSntTrtOperCode() {
		return sntTrtOperCode;
	}
	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}
	public Date getTreatOperateDate() {
		return treatOperateDate;
	}
	public void setTreatOperateDate(Date treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}
	public String getApprslOrgCode() {
		return apprslOrgCode;
	}
	public void setApprslOrgCode(String apprslOrgCode) {
		this.apprslOrgCode = apprslOrgCode;
	}
	public String getApprtDeptCode() {
		return apprtDeptCode;
	}
	public void setApprtDeptCode(String apprtDeptCode) {
		this.apprtDeptCode = apprtDeptCode;
	}
	public String getIdenOperCode() {
		return idenOperCode;
	}
	public void setIdenOperCode(String idenOperCode) {
		this.idenOperCode = idenOperCode;
	}
	public Date getApprCondtTime() {
		return apprCondtTime;
	}
	public void setApprCondtTime(Date apprCondtTime) {
		this.apprCondtTime = apprCondtTime;
	}
	public BigDecimal getUnqulfdQuarQty() {
		return unqulfdQuarQty;
	}
	public void setUnqulfdQuarQty(BigDecimal unqulfdQuarQty) {
		this.unqulfdQuarQty = unqulfdQuarQty;
	}
	public BigDecimal getUnqulfCommQty() {
		return unqulfCommQty;
	}
	public void setUnqulfCommQty(BigDecimal unqulfCommQty) {
		this.unqulfCommQty = unqulfCommQty;
	}
	public BigDecimal getUnqualCommQtyCmp() {
		return unqualCommQtyCmp;
	}
	public void setUnqualCommQtyCmp(BigDecimal unqualCommQtyCmp) {
		this.unqualCommQtyCmp = unqualCommQtyCmp;
	}
	public String getDisquaContCode() {
		return disquaContCode;
	}
	public void setDisquaContCode(String disquaContCode) {
		this.disquaContCode = disquaContCode;
	}
	public String getTreatUnit() {
		return treatUnit;
	}
	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}
	public BigDecimal getDeclContQty() {
		return declContQty;
	}
	public void setDeclContQty(BigDecimal declContQty) {
		this.declContQty = declContQty;
	}
	public BigDecimal getInspContQty() {
		return inspContQty;
	}
	public void setInspContQty(BigDecimal inspContQty) {
		this.inspContQty = inspContQty;
	}
	public BigDecimal getContagionContQty() {
		return contagionContQty;
	}
	public void setContagionContQty(BigDecimal contagionContQty) {
		this.contagionContQty = contagionContQty;
	}
	public BigDecimal getFaunaFloraContQty() {
		return faunaFloraContQty;
	}
	public void setFaunaFloraContQty(BigDecimal faunaFloraContQty) {
		this.faunaFloraContQty = faunaFloraContQty;
	}
	public BigDecimal getDetectionContQty() {
		return detectionContQty;
	}
	public void setDetectionContQty(BigDecimal detectionContQty) {
		this.detectionContQty = detectionContQty;
	}
	public BigDecimal getHealthProcContQty() {
		return healthProcContQty;
	}
	public void setHealthProcContQty(BigDecimal healthProcContQty) {
		this.healthProcContQty = healthProcContQty;
	}
	public BigDecimal getCargInspContQty() {
		return cargInspContQty;
	}
	public void setCargInspContQty(BigDecimal cargInspContQty) {
		this.cargInspContQty = cargInspContQty;
	}
	public String getCargDisqualItemOne() {
		return cargDisqualItemOne;
	}
	public void setCargDisqualItemOne(String cargDisqualItemOne) {
		this.cargDisqualItemOne = cargDisqualItemOne;
	}
	public String getEpidSituCatg() {
		return epidSituCatg;
	}
	public void setEpidSituCatg(String epidSituCatg) {
		this.epidSituCatg = epidSituCatg;
	}
	public String getContCategory() {
		return contCategory;
	}
	public void setContCategory(String contCategory) {
		this.contCategory = contCategory;
	}
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	public Date getOperTime() {
		return operTime;
	}
	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	public Date getArchiveTime() {
		return archiveTime;
	}
	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	public String getQuarUnqualReasonCode() {
		return quarUnqualReasonCode;
	}
	public void setQuarUnqualReasonCode(String quarUnqualReasonCode) {
		this.quarUnqualReasonCode = quarUnqualReasonCode;
	}
	public String getContNo() {
		return contNo;
	}
	public void setContNo(String contNo) {
		this.contNo = contNo;
	}
	public String getLclFlag() {
		return lclFlag;
	}
	public void setLclFlag(String lclFlag) {
		this.lclFlag = lclFlag;
	}
	public String getHeavyFlag() {
		return heavyFlag;
	}
	public void setHeavyFlag(String heavyFlag) {
		this.heavyFlag = heavyFlag;
	}
	public String getCheckQuaFlag() {
		return checkQuaFlag;
	}
	public void setCheckQuaFlag(String checkQuaFlag) {
		this.checkQuaFlag = checkQuaFlag;
	}
	public String getQuaDisposeFlag() {
		return quaDisposeFlag;
	}
	public void setQuaDisposeFlag(String quaDisposeFlag) {
		this.quaDisposeFlag = quaDisposeFlag;
	}
	public String getCargInsUnqualFlag() {
		return cargInsUnqualFlag;
	}
	public void setCargInsUnqualFlag(String cargInsUnqualFlag) {
		this.cargInsUnqualFlag = cargInsUnqualFlag;
	}
	public String getHealthInsUnqualFlag() {
		return healthInsUnqualFlag;
	}
	public void setHealthInsUnqualFlag(String healthInsUnqualFlag) {
		this.healthInsUnqualFlag = healthInsUnqualFlag;
	}
	public String getQuarUnqualContentCodes() {
		return quarUnqualContentCodes;
	}
	public void setQuarUnqualContentCodes(String quarUnqualContentCodes) {
		this.quarUnqualContentCodes = quarUnqualContentCodes;
	}
	public String getSntTrtFlag() {
		return sntTrtFlag;
	}
	public void setSntTrtFlag(String sntTrtFlag) {
		this.sntTrtFlag = sntTrtFlag;
	}
	public String getPamQuaUnqualFlag() {
		return pamQuaUnqualFlag;
	}
	public void setPamQuaUnqualFlag(String pamQuaUnqualFlag) {
		this.pamQuaUnqualFlag = pamQuaUnqualFlag;
	}
	public String getPamUnqualReasonCodes() {
		return pamUnqualReasonCodes;
	}
	public void setPamUnqualReasonCodes(String pamUnqualReasonCodes) {
		this.pamUnqualReasonCodes = pamUnqualReasonCodes;
	}
	public String getPamTrtFlag() {
		return pamTrtFlag;
	}
	public void setPamTrtFlag(String pamTrtFlag) {
		this.pamTrtFlag = pamTrtFlag;
	}
	public String getPamTrtMethCodes() {
		return pamTrtMethCodes;
	}
	public void setPamTrtMethCodes(String pamTrtMethCodes) {
		this.pamTrtMethCodes = pamTrtMethCodes;
	}
	public String getPamTrtOrgCode() {
		return pamTrtOrgCode;
	}
	public void setPamTrtOrgCode(String pamTrtOrgCode) {
		this.pamTrtOrgCode = pamTrtOrgCode;
	}
	public String getFrInfRegFlag() {
		return frInfRegFlag;
	}
	public void setFrInfRegFlag(String frInfRegFlag) {
		this.frInfRegFlag = frInfRegFlag;
	}
	public String getFrPamRegFlag() {
		return frPamRegFlag;
	}
	public void setFrPamRegFlag(String frPamRegFlag) {
		this.frPamRegFlag = frPamRegFlag;
	}
	public String getBillLadNo() {
		return billLadNo;
	}
	public void setBillLadNo(String billLadNo) {
		this.billLadNo = billLadNo;
	}
	public String getBoxCompany() {
		return boxCompany;
	}
	public void setBoxCompany(String boxCompany) {
		this.boxCompany = boxCompany;
	}
	public String getRegNum() {
		return regNum;
	}
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public String getExpImpFlag() {
		return expImpFlag;
	}
	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}
	public String getTradeCountryCode() {
		return tradeCountryCode;
	}
	public void setTradeCountryCode(String tradeCountryCode) {
		this.tradeCountryCode = tradeCountryCode;
	}
	public String getEmptyFlag() {
		return emptyFlag;
	}
	public void setEmptyFlag(String emptyFlag) {
		this.emptyFlag = emptyFlag;
	}
	public String getContQuarUnqualFlag() {
		return contQuarUnqualFlag;
	}
	public void setContQuarUnqualFlag(String contQuarUnqualFlag) {
		this.contQuarUnqualFlag = contQuarUnqualFlag;
	}
	public String getContQuarUnqualDesc() {
		return contQuarUnqualDesc;
	}
	public void setContQuarUnqualDesc(String contQuarUnqualDesc) {
		this.contQuarUnqualDesc = contQuarUnqualDesc;
	}
	public String getOperOrg() {
		return operOrg;
	}
	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}
	public String getInspBFlag() {
		return inspBFlag;
	}
	public void setInspBFlag(String inspBFlag) {
		this.inspBFlag = inspBFlag;
	}
	public String getBOrgCode() {
		return BOrgCode;
	}
	public void setBOrgCode(String bOrgCode) {
		BOrgCode = bOrgCode;
	}
	public String getBOperatorCode() {
		return BOperatorCode;
	}
	public void setBOperatorCode(String bOperatorCode) {
		BOperatorCode = bOperatorCode;
	}
	public String getTransBatch() {
		return transBatch;
	}
	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

	

}
/**  
 * FileName:  ItfInsDeclMagB.java   
 * @Description: 报检单管理
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.util.Date;

/**  
 * Description: 报检单管理表    
 * Copyright:   Copyright (c)2017  
 * Company:     rongji
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:22:27  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                     1.0         1.0 Version  
 */  

public class ItfInsDeclMagB implements java.io.Serializable {

	public static final long serialVersionUID = -507582530923533851L;
	public String declMagId;
	public String declNo;
	public String exeInspOrgCode;
	public String excInspDeptCode;
	public String asInpTkOrgCode;
	public String asInpTkDeptCode;
	public String flowPathStatus;
	public String receiverDocCode;
	public Date acceptApprTm;
	public String inspAsgnPrsnC;
	public Date inspAssignTm;
	public String inspectorCode;
	public Date confmTime;
	public String otherInspOperator;
	public String inspContCodes;
	public String certTypeCodes;
	public Date finishTime;
	public String inspPassOperatorCode;
	public Date impowerDate;
	public String impowerFlag;
	public String impowerAudit;
	public String passedMode;
	public Date releaseDate;
	public String magDeptCode;
	public Date auditTime;
	public String verifier;
	public String auditContent;
	public String isAudit;
	public String operType;
	public String workContentCode;
	public String cancelFlag;
	public String remark;
	public String falgArchive;
	public Date operTime;
	public Date archiveTime;
	public String expImpFlag;
	public String subType;
	public String goodsName;
	public String retReason;
	public String orgCodePath;
	public String subPriv;
	public String certTypeNames;
	public String isHaveAux;
	public Date declDate;
	public String processStatus;
	public String consigneeCname;
	public String inspRequire;
	public String declRegName;
	public String entName;
	public String auditPriv;
	public String checkPriv;
	public String evalPriv;
	public String unquaPriv;
	public String declWorkNo;
	public String entMgrNo;
	public String transBatch;
	public String getDeclMagId() {
		return declMagId;
	}
	public void setDeclMagId(String declMagId) {
		this.declMagId = declMagId;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getExeInspOrgCode() {
		return exeInspOrgCode;
	}
	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}
	public String getExcInspDeptCode() {
		return excInspDeptCode;
	}
	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}
	public String getAsInpTkOrgCode() {
		return asInpTkOrgCode;
	}
	public void setAsInpTkOrgCode(String asInpTkOrgCode) {
		this.asInpTkOrgCode = asInpTkOrgCode;
	}
	public String getAsInpTkDeptCode() {
		return asInpTkDeptCode;
	}
	public void setAsInpTkDeptCode(String asInpTkDeptCode) {
		this.asInpTkDeptCode = asInpTkDeptCode;
	}
	public String getFlowPathStatus() {
		return flowPathStatus;
	}
	public void setFlowPathStatus(String flowPathStatus) {
		this.flowPathStatus = flowPathStatus;
	}
	public String getReceiverDocCode() {
		return receiverDocCode;
	}
	public void setReceiverDocCode(String receiverDocCode) {
		this.receiverDocCode = receiverDocCode;
	}
	public Date getAcceptApprTm() {
		return acceptApprTm;
	}
	public void setAcceptApprTm(Date acceptApprTm) {
		this.acceptApprTm = acceptApprTm;
	}
	public String getInspAsgnPrsnC() {
		return inspAsgnPrsnC;
	}
	public void setInspAsgnPrsnC(String inspAsgnPrsnC) {
		this.inspAsgnPrsnC = inspAsgnPrsnC;
	}
	public Date getInspAssignTm() {
		return inspAssignTm;
	}
	public void setInspAssignTm(Date inspAssignTm) {
		this.inspAssignTm = inspAssignTm;
	}
	public String getInspectorCode() {
		return inspectorCode;
	}
	public void setInspectorCode(String inspectorCode) {
		this.inspectorCode = inspectorCode;
	}
	public Date getConfmTime() {
		return confmTime;
	}
	public void setConfmTime(Date confmTime) {
		this.confmTime = confmTime;
	}
	public String getOtherInspOperator() {
		return otherInspOperator;
	}
	public void setOtherInspOperator(String otherInspOperator) {
		this.otherInspOperator = otherInspOperator;
	}
	public String getInspContCodes() {
		return inspContCodes;
	}
	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}
	public String getCertTypeCodes() {
		return certTypeCodes;
	}
	public void setCertTypeCodes(String certTypeCodes) {
		this.certTypeCodes = certTypeCodes;
	}
	public Date getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}
	public String getInspPassOperatorCode() {
		return inspPassOperatorCode;
	}
	public void setInspPassOperatorCode(String inspPassOperatorCode) {
		this.inspPassOperatorCode = inspPassOperatorCode;
	}
	public Date getImpowerDate() {
		return impowerDate;
	}
	public void setImpowerDate(Date impowerDate) {
		this.impowerDate = impowerDate;
	}
	public String getImpowerFlag() {
		return impowerFlag;
	}
	public void setImpowerFlag(String impowerFlag) {
		this.impowerFlag = impowerFlag;
	}
	public String getImpowerAudit() {
		return impowerAudit;
	}
	public void setImpowerAudit(String impowerAudit) {
		this.impowerAudit = impowerAudit;
	}
	public String getPassedMode() {
		return passedMode;
	}
	public void setPassedMode(String passedMode) {
		this.passedMode = passedMode;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getMagDeptCode() {
		return magDeptCode;
	}
	public void setMagDeptCode(String magDeptCode) {
		this.magDeptCode = magDeptCode;
	}
	public Date getAuditTime() {
		return auditTime;
	}
	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}
	public String getVerifier() {
		return verifier;
	}
	public void setVerifier(String verifier) {
		this.verifier = verifier;
	}
	public String getAuditContent() {
		return auditContent;
	}
	public void setAuditContent(String auditContent) {
		this.auditContent = auditContent;
	}
	public String getIsAudit() {
		return isAudit;
	}
	public void setIsAudit(String isAudit) {
		this.isAudit = isAudit;
	}
	public String getOperType() {
		return operType;
	}
	public void setOperType(String operType) {
		this.operType = operType;
	}
	public String getWorkContentCode() {
		return workContentCode;
	}
	public void setWorkContentCode(String workContentCode) {
		this.workContentCode = workContentCode;
	}
	public String getCancelFlag() {
		return cancelFlag;
	}
	public void setCancelFlag(String cancelFlag) {
		this.cancelFlag = cancelFlag;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	public Date getOperTime() {
		return operTime;
	}
	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	public Date getArchiveTime() {
		return archiveTime;
	}
	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	public String getExpImpFlag() {
		return expImpFlag;
	}
	public void setExpImpFlag(String expImpFlag) {
		this.expImpFlag = expImpFlag;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getRetReason() {
		return retReason;
	}
	public void setRetReason(String retReason) {
		this.retReason = retReason;
	}
	public String getOrgCodePath() {
		return orgCodePath;
	}
	public void setOrgCodePath(String orgCodePath) {
		this.orgCodePath = orgCodePath;
	}
	public String getSubPriv() {
		return subPriv;
	}
	public void setSubPriv(String subPriv) {
		this.subPriv = subPriv;
	}
	public String getCertTypeNames() {
		return certTypeNames;
	}
	public void setCertTypeNames(String certTypeNames) {
		this.certTypeNames = certTypeNames;
	}
	public String getIsHaveAux() {
		return isHaveAux;
	}
	public void setIsHaveAux(String isHaveAux) {
		this.isHaveAux = isHaveAux;
	}
	public Date getDeclDate() {
		return declDate;
	}
	public void setDeclDate(Date declDate) {
		this.declDate = declDate;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public String getConsigneeCname() {
		return consigneeCname;
	}
	public void setConsigneeCname(String consigneeCname) {
		this.consigneeCname = consigneeCname;
	}
	public String getInspRequire() {
		return inspRequire;
	}
	public void setInspRequire(String inspRequire) {
		this.inspRequire = inspRequire;
	}
	public String getDeclRegName() {
		return declRegName;
	}
	public void setDeclRegName(String declRegName) {
		this.declRegName = declRegName;
	}
	public String getEntName() {
		return entName;
	}
	public void setEntName(String entName) {
		this.entName = entName;
	}
	public String getAuditPriv() {
		return auditPriv;
	}
	public void setAuditPriv(String auditPriv) {
		this.auditPriv = auditPriv;
	}
	public String getCheckPriv() {
		return checkPriv;
	}
	public void setCheckPriv(String checkPriv) {
		this.checkPriv = checkPriv;
	}
	public String getEvalPriv() {
		return evalPriv;
	}
	public void setEvalPriv(String evalPriv) {
		this.evalPriv = evalPriv;
	}
	public String getUnquaPriv() {
		return unquaPriv;
	}
	public void setUnquaPriv(String unquaPriv) {
		this.unquaPriv = unquaPriv;
	}
	public String getDeclWorkNo() {
		return declWorkNo;
	}
	public void setDeclWorkNo(String declWorkNo) {
		this.declWorkNo = declWorkNo;
	}
	public String getEntMgrNo() {
		return entMgrNo;
	}
	public void setEntMgrNo(String entMgrNo) {
		this.entMgrNo = entMgrNo;
	}
	public String getTransBatch() {
		return transBatch;
	}
	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

}
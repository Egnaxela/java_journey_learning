/**  
 * FileName:  ItfInsResultSumB.java   
 * @Description: 检验检疫结果总结表 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**  
 * Description: 检验检疫结果总结表  
 * Copyright:   Copyright (c)2017  
 * Company:     rongji
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:23:53  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                     1.0         1.0 Version  
 */  

public class ItfInsResultSumB implements java.io.Serializable {
	
	public static final long serialVersionUID = 7973317766015938971L;
	public String declNo;
	public String transBatch;
	public Date insBeginDate;
	public Date inspEndDate;
	public String mnufctrRegNo;
	public String inspBasCatCode;
	public String exeInspOrgCode;
	public String excInspDeptCode;
	public String whetherExteIns;
	public String whether2ndIns;
	public String kepIsolat;
	public String ciqResultCode;
	public String inspResltCode;
	public String certTypeCodes;
	public String markNo;
	public BigDecimal ciqValidPeri;
	public String operatorCode;
	public String certOriginals;
	public String certCopies;
	public String transFlag;
	public String inspResEval;
	public String quarResEval;
	public String wodPackResEval;
	public String inspModeCode;
	public String operateTypeCode;
	public String fstRelsSrtCode;
	public String noticeFlag;
	public String markNoStr;
	public String flagNoStr;
	public String quarResult;
	public String quarProcResult;
	public String basisCoding;
	public String checkPlace;
	public String checker;
	public String spotDesc;
	public String woodpackQuarResult;
	public String contQuarResult;
	public String goodsEvalResult;
	public String contRegiStatus;
	public String remark;
	public String falgArchive;
	public Date operTime;
	public String weatherCode;
	public String preMeasBasisCode;
	public String contNoStr;
	public String chngResn;
	public String inspContCodes;
	public Date archiveTime;
	public Date finishDate;
	public String whether2ndInsSource;
	public String operOrg;
	public String resultSumBId;
	public String inspBFlag;
	public String BOrgCode;
	public String BOperatorCode;
	public List<ItfInsResultWoodpackB> rwList;
	public List<ItfInsCheckItemB> ciList;
	public List<ItfInsResultGoodsB> rgList;
	public List<ItfInsContainerResultB> crList;
	public List<ItfInsDeclMagB> dmList; 
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public String getTransBatch() {
		return transBatch;
	}
	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}
	public Date getInsBeginDate() {
		return insBeginDate;
	}
	public void setInsBeginDate(Date insBeginDate) {
		this.insBeginDate = insBeginDate;
	}
	public Date getInspEndDate() {
		return inspEndDate;
	}
	public void setInspEndDate(Date inspEndDate) {
		this.inspEndDate = inspEndDate;
	}
	public String getMnufctrRegNo() {
		return mnufctrRegNo;
	}
	public void setMnufctrRegNo(String mnufctrRegNo) {
		this.mnufctrRegNo = mnufctrRegNo;
	}
	public String getInspBasCatCode() {
		return inspBasCatCode;
	}
	public void setInspBasCatCode(String inspBasCatCode) {
		this.inspBasCatCode = inspBasCatCode;
	}
	public String getExeInspOrgCode() {
		return exeInspOrgCode;
	}
	public void setExeInspOrgCode(String exeInspOrgCode) {
		this.exeInspOrgCode = exeInspOrgCode;
	}
	public String getExcInspDeptCode() {
		return excInspDeptCode;
	}
	public void setExcInspDeptCode(String excInspDeptCode) {
		this.excInspDeptCode = excInspDeptCode;
	}
	public String getWhetherExteIns() {
		return whetherExteIns;
	}
	public void setWhetherExteIns(String whetherExteIns) {
		this.whetherExteIns = whetherExteIns;
	}
	public String getWhether2ndIns() {
		return whether2ndIns;
	}
	public void setWhether2ndIns(String whether2ndIns) {
		this.whether2ndIns = whether2ndIns;
	}
	public String getKepIsolat() {
		return kepIsolat;
	}
	public void setKepIsolat(String kepIsolat) {
		this.kepIsolat = kepIsolat;
	}
	public String getCiqResultCode() {
		return ciqResultCode;
	}
	public void setCiqResultCode(String ciqResultCode) {
		this.ciqResultCode = ciqResultCode;
	}
	public String getInspResltCode() {
		return inspResltCode;
	}
	public void setInspResltCode(String inspResltCode) {
		this.inspResltCode = inspResltCode;
	}
	public String getCertTypeCodes() {
		return certTypeCodes;
	}
	public void setCertTypeCodes(String certTypeCodes) {
		this.certTypeCodes = certTypeCodes;
	}
	public String getMarkNo() {
		return markNo;
	}
	public void setMarkNo(String markNo) {
		this.markNo = markNo;
	}
	public BigDecimal getCiqValidPeri() {
		return ciqValidPeri;
	}
	public void setCiqValidPeri(BigDecimal ciqValidPeri) {
		this.ciqValidPeri = ciqValidPeri;
	}
	public String getOperatorCode() {
		return operatorCode;
	}
	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}
	public String getCertOriginals() {
		return certOriginals;
	}
	public void setCertOriginals(String certOriginals) {
		this.certOriginals = certOriginals;
	}
	public String getCertCopies() {
		return certCopies;
	}
	public void setCertCopies(String certCopies) {
		this.certCopies = certCopies;
	}
	public String getTransFlag() {
		return transFlag;
	}
	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}
	public String getInspResEval() {
		return inspResEval;
	}
	public void setInspResEval(String inspResEval) {
		this.inspResEval = inspResEval;
	}
	public String getQuarResEval() {
		return quarResEval;
	}
	public void setQuarResEval(String quarResEval) {
		this.quarResEval = quarResEval;
	}
	public String getWodPackResEval() {
		return wodPackResEval;
	}
	public void setWodPackResEval(String wodPackResEval) {
		this.wodPackResEval = wodPackResEval;
	}
	public String getInspModeCode() {
		return inspModeCode;
	}
	public void setInspModeCode(String inspModeCode) {
		this.inspModeCode = inspModeCode;
	}
	public String getOperateTypeCode() {
		return operateTypeCode;
	}
	public void setOperateTypeCode(String operateTypeCode) {
		this.operateTypeCode = operateTypeCode;
	}
	public String getFstRelsSrtCode() {
		return fstRelsSrtCode;
	}
	public void setFstRelsSrtCode(String fstRelsSrtCode) {
		this.fstRelsSrtCode = fstRelsSrtCode;
	}
	public String getNoticeFlag() {
		return noticeFlag;
	}
	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}
	public String getMarkNoStr() {
		return markNoStr;
	}
	public void setMarkNoStr(String markNoStr) {
		this.markNoStr = markNoStr;
	}
	public String getFlagNoStr() {
		return flagNoStr;
	}
	public void setFlagNoStr(String flagNoStr) {
		this.flagNoStr = flagNoStr;
	}
	public String getQuarResult() {
		return quarResult;
	}
	public void setQuarResult(String quarResult) {
		this.quarResult = quarResult;
	}
	public String getQuarProcResult() {
		return quarProcResult;
	}
	public void setQuarProcResult(String quarProcResult) {
		this.quarProcResult = quarProcResult;
	}
	public String getBasisCoding() {
		return basisCoding;
	}
	public void setBasisCoding(String basisCoding) {
		this.basisCoding = basisCoding;
	}
	public String getCheckPlace() {
		return checkPlace;
	}
	public void setCheckPlace(String checkPlace) {
		this.checkPlace = checkPlace;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public String getSpotDesc() {
		return spotDesc;
	}
	public void setSpotDesc(String spotDesc) {
		this.spotDesc = spotDesc;
	}
	public String getWoodpackQuarResult() {
		return woodpackQuarResult;
	}
	public void setWoodpackQuarResult(String woodpackQuarResult) {
		this.woodpackQuarResult = woodpackQuarResult;
	}
	public String getContQuarResult() {
		return contQuarResult;
	}
	public void setContQuarResult(String contQuarResult) {
		this.contQuarResult = contQuarResult;
	}
	public String getGoodsEvalResult() {
		return goodsEvalResult;
	}
	public void setGoodsEvalResult(String goodsEvalResult) {
		this.goodsEvalResult = goodsEvalResult;
	}
	public String getContRegiStatus() {
		return contRegiStatus;
	}
	public void setContRegiStatus(String contRegiStatus) {
		this.contRegiStatus = contRegiStatus;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	public Date getOperTime() {
		return operTime;
	}
	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	public String getWeatherCode() {
		return weatherCode;
	}
	public void setWeatherCode(String weatherCode) {
		this.weatherCode = weatherCode;
	}
	public String getPreMeasBasisCode() {
		return preMeasBasisCode;
	}
	public void setPreMeasBasisCode(String preMeasBasisCode) {
		this.preMeasBasisCode = preMeasBasisCode;
	}
	public String getContNoStr() {
		return contNoStr;
	}
	public void setContNoStr(String contNoStr) {
		this.contNoStr = contNoStr;
	}
	public String getChngResn() {
		return chngResn;
	}
	public void setChngResn(String chngResn) {
		this.chngResn = chngResn;
	}
	public String getInspContCodes() {
		return inspContCodes;
	}
	public void setInspContCodes(String inspContCodes) {
		this.inspContCodes = inspContCodes;
	}
	public Date getArchiveTime() {
		return archiveTime;
	}
	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	public Date getFinishDate() {
		return finishDate;
	}
	public void setFinishDate(Date finishDate) {
		this.finishDate = finishDate;
	}
	public String getWhether2ndInsSource() {
		return whether2ndInsSource;
	}
	public void setWhether2ndInsSource(String whether2ndInsSource) {
		this.whether2ndInsSource = whether2ndInsSource;
	}
	public String getOperOrg() {
		return operOrg;
	}
	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}
	public String getResultSumBId() {
		return resultSumBId;
	}
	public void setResultSumBId(String resultSumBId) {
		this.resultSumBId = resultSumBId;
	}
	public String getInspBFlag() {
		return inspBFlag;
	}
	public void setInspBFlag(String inspBFlag) {
		this.inspBFlag = inspBFlag;
	}
	public String getBOrgCode() {
		return BOrgCode;
	}
	public void setBOrgCode(String bOrgCode) {
		BOrgCode = bOrgCode;
	}
	public String getBOperatorCode() {
		return BOperatorCode;
	}
	public void setBOperatorCode(String bOperatorCode) {
		BOperatorCode = bOperatorCode;
	}
	public List<ItfInsResultWoodpackB> getRwList() {
		return rwList;
	}
	public void setRwList(List<ItfInsResultWoodpackB> rwList) {
		this.rwList = rwList;
	}
	public List<ItfInsCheckItemB> getCiList() {
		return ciList;
	}
	public void setCiList(List<ItfInsCheckItemB> ciList) {
		this.ciList = ciList;
	}
	public List<ItfInsResultGoodsB> getRgList() {
		return rgList;
	}
	public void setRgList(List<ItfInsResultGoodsB> rgList) {
		this.rgList = rgList;
	}
	public List<ItfInsContainerResultB> getCrList() {
		return crList;
	}
	public void setCrList(List<ItfInsContainerResultB> crList) {
		this.crList = crList;
	}
	public List<ItfInsDeclMagB> getDmList() {
		return dmList;
	}
	public void setDmList(List<ItfInsDeclMagB> dmList) {
		this.dmList = dmList;
	}
	
}
/**  
 * FileName:  ItfInsResultWoodpackB.java   
 * @Description: 木质包装检疫结果表
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月8日 上午10:13:51  
 *  
 */
package com.rongji.eciq.mobile.sendxml.bean;

import java.math.BigDecimal;
import java.util.Date;

/**  
 * Description: 木质包装检疫结果表  
 * Copyright:   Copyright (c)2017  
 * Company:     rongji
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017年5月8日 上午10:24:31  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月8日      吴有根                     1.0         1.0 Version  
 */  

public class ItfInsResultWoodpackB implements java.io.Serializable {

	public static final long serialVersionUID = -1498525300438975768L;
	public String wodPkResultId;
	public String declNo;
	public BigDecimal goodsNo;
	public String packTypeCode;
	public BigDecimal packQty;
	public String woodContCodes;
	public String wodPackResEval;
	public String woodPackMak;
	public String confsWodPackMak;
	public String wodPkgUnquResnC;
	public String wodPkOrgCode;
	public String wodPkDeptCode;
	public String wdPkgInspCode;
	public Date wodPkOperTime;
	public String prevtivTreatmt;
	public String quarTrmtMeasC;
	public String sanitTrtMethCode;
	public String sntTrtOrgCode;
	public String treatDeptCode;
	public String sntTrtOperCode;
	public Date treatOperateDate;
	public String treatUnit;
	public String falgArchive;
	public Date operTime;
	public Date archiveTime;
	public String transFlag;
	public String operOrg;
	public String inspBFlag;
	public String BOrgCode;
	public String BOperatorCode;
	public String transBatch;
	public String getWodPkResultId() {
		return wodPkResultId;
	}
	public void setWodPkResultId(String wodPkResultId) {
		this.wodPkResultId = wodPkResultId;
	}
	public String getDeclNo() {
		return declNo;
	}
	public void setDeclNo(String declNo) {
		this.declNo = declNo;
	}
	public BigDecimal getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(BigDecimal goodsNo) {
		this.goodsNo = goodsNo;
	}
	public String getPackTypeCode() {
		return packTypeCode;
	}
	public void setPackTypeCode(String packTypeCode) {
		this.packTypeCode = packTypeCode;
	}
	public BigDecimal getPackQty() {
		return packQty;
	}
	public void setPackQty(BigDecimal packQty) {
		this.packQty = packQty;
	}
	public String getWoodContCodes() {
		return woodContCodes;
	}
	public void setWoodContCodes(String woodContCodes) {
		this.woodContCodes = woodContCodes;
	}
	public String getWodPackResEval() {
		return wodPackResEval;
	}
	public void setWodPackResEval(String wodPackResEval) {
		this.wodPackResEval = wodPackResEval;
	}
	public String getWoodPackMak() {
		return woodPackMak;
	}
	public void setWoodPackMak(String woodPackMak) {
		this.woodPackMak = woodPackMak;
	}
	public String getConfsWodPackMak() {
		return confsWodPackMak;
	}
	public void setConfsWodPackMak(String confsWodPackMak) {
		this.confsWodPackMak = confsWodPackMak;
	}
	public String getWodPkgUnquResnC() {
		return wodPkgUnquResnC;
	}
	public void setWodPkgUnquResnC(String wodPkgUnquResnC) {
		this.wodPkgUnquResnC = wodPkgUnquResnC;
	}
	public String getWodPkOrgCode() {
		return wodPkOrgCode;
	}
	public void setWodPkOrgCode(String wodPkOrgCode) {
		this.wodPkOrgCode = wodPkOrgCode;
	}
	public String getWodPkDeptCode() {
		return wodPkDeptCode;
	}
	public void setWodPkDeptCode(String wodPkDeptCode) {
		this.wodPkDeptCode = wodPkDeptCode;
	}
	public String getWdPkgInspCode() {
		return wdPkgInspCode;
	}
	public void setWdPkgInspCode(String wdPkgInspCode) {
		this.wdPkgInspCode = wdPkgInspCode;
	}
	public Date getWodPkOperTime() {
		return wodPkOperTime;
	}
	public void setWodPkOperTime(Date wodPkOperTime) {
		this.wodPkOperTime = wodPkOperTime;
	}
	public String getPrevtivTreatmt() {
		return prevtivTreatmt;
	}
	public void setPrevtivTreatmt(String prevtivTreatmt) {
		this.prevtivTreatmt = prevtivTreatmt;
	}
	public String getQuarTrmtMeasC() {
		return quarTrmtMeasC;
	}
	public void setQuarTrmtMeasC(String quarTrmtMeasC) {
		this.quarTrmtMeasC = quarTrmtMeasC;
	}
	public String getSanitTrtMethCode() {
		return sanitTrtMethCode;
	}
	public void setSanitTrtMethCode(String sanitTrtMethCode) {
		this.sanitTrtMethCode = sanitTrtMethCode;
	}
	public String getSntTrtOrgCode() {
		return sntTrtOrgCode;
	}
	public void setSntTrtOrgCode(String sntTrtOrgCode) {
		this.sntTrtOrgCode = sntTrtOrgCode;
	}
	public String getTreatDeptCode() {
		return treatDeptCode;
	}
	public void setTreatDeptCode(String treatDeptCode) {
		this.treatDeptCode = treatDeptCode;
	}
	public String getSntTrtOperCode() {
		return sntTrtOperCode;
	}
	public void setSntTrtOperCode(String sntTrtOperCode) {
		this.sntTrtOperCode = sntTrtOperCode;
	}
	public Date getTreatOperateDate() {
		return treatOperateDate;
	}
	public void setTreatOperateDate(Date treatOperateDate) {
		this.treatOperateDate = treatOperateDate;
	}
	public String getTreatUnit() {
		return treatUnit;
	}
	public void setTreatUnit(String treatUnit) {
		this.treatUnit = treatUnit;
	}
	public String getFalgArchive() {
		return falgArchive;
	}
	public void setFalgArchive(String falgArchive) {
		this.falgArchive = falgArchive;
	}
	public Date getOperTime() {
		return operTime;
	}
	public void setOperTime(Date operTime) {
		this.operTime = operTime;
	}
	public Date getArchiveTime() {
		return archiveTime;
	}
	public void setArchiveTime(Date archiveTime) {
		this.archiveTime = archiveTime;
	}
	public String getTransFlag() {
		return transFlag;
	}
	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}
	public String getOperOrg() {
		return operOrg;
	}
	public void setOperOrg(String operOrg) {
		this.operOrg = operOrg;
	}
	public String getInspBFlag() {
		return inspBFlag;
	}
	public void setInspBFlag(String inspBFlag) {
		this.inspBFlag = inspBFlag;
	}
	public String getBOrgCode() {
		return BOrgCode;
	}
	public void setBOrgCode(String bOrgCode) {
		BOrgCode = bOrgCode;
	}
	public String getBOperatorCode() {
		return BOperatorCode;
	}
	public void setBOperatorCode(String bOperatorCode) {
		BOperatorCode = bOperatorCode;
	}
	public String getTransBatch() {
		return transBatch;
	}
	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}


}
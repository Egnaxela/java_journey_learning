/**  
 * FileName:   DclOrdFeedBackMainHandelImpl.java  
 * @Description: 布控反馈信息发送xml报文接口实现类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月5日 下午3:13:48  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Component;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.DbConnectContext;
import com.rongji.eciq.mobile.sendxml.bean.DclOrdFeedbackDetail;
import com.rongji.eciq.mobile.sendxml.bean.DclOrdFeedbackMain;
import com.rongji.eciq.mobile.sendxml.service.DclOrdFeedBackMainHandel;
import com.rongji.eciq.mobile.sendxml.utils.CasTicketRequest;
import com.rongji.eciq.mobile.sendxml.utils.CommDao;
import com.rongji.eciq.mobile.sendxml.utils.CommunicationUtil;
import com.rongji.eciq.mobile.sendxml.utils.DbUtils;
import com.rongji.eciq.mobile.sendxml.utils.SignatureUtil;
import com.rongji.eciq.mobile.sendxml.utils.ZipOperation;
import com.rongji.eciq.mobile.utils.DateTools;
import com.sun.org.apache.xpath.internal.operations.Bool;

/**  
 * Description: 布控反馈信息发送xml报文接口实现类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月5日 下午3:13:48  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-05      吴有根                   1.0         1.0 Version
 * 2017-07-14      吴有根                   1.0         报文头增加对报文体进行数字签名的节点BIZ_SIGN_INFO  
 */
@Component
public class DclOrdFeedBackMainHandelImpl implements DclOrdFeedBackMainHandel {

	private static final Logger log=Logger.getLogger(DclOrdFeedBackMainHandelImpl.class);
	/**
	 * 
	* <p>描述: getSendDclOrdFeedBackMain</p>
	* @param feedbackMainNo 布控反馈主编号
	* @param orgCode     机构代码
	* @return
	* @author 吴有根
	 * @throws Exception 
	 */
	@Override
	public String getSendDclOrdFeedBackMain(HttpServletRequest request,HttpServletResponse response,String feedbackMainNo,String orgCode){
		DclOrdFeedBackMainHandelImpl t=new DclOrdFeedBackMainHandelImpl();
		long startTime=System.currentTimeMillis();
		String msg="";
		try{
			Map<String, Object> getPostDatas=t.getPostDatas(feedbackMainNo,orgCode); //"http://192.168.1.82:8086/eciq_service"
			if(Utils.notEmpty(getPostDatas)&&(Boolean)getPostDatas.get("flag")){
				msg=CommunicationUtil.getHttpContentAsByte(CasTicketRequest.getConfigList2("address").getConfigValue()+"/eciq/senddatas",
					((String)getPostDatas.get("data")).getBytes());
			}else{
				msg=(String)getPostDatas.get("msg");
				CasTicketRequest.saveExceptionObject(request,msg);
			}
		}catch (Exception e) {
			try {
				StringWriter writer = new StringWriter();
				e.printStackTrace(new PrintWriter(writer));
				msg=writer.toString();
				CasTicketRequest.saveExceptionObject(request,msg);
			} catch (Exception e1) {
			}
			log.info(msg);
			return msg;
		}
		long endTime=System.currentTimeMillis();
		log.info("耗时:"+(endTime-startTime)+"ms"+",返回的信息为：\n"+msg);
		return msg;
	}
	

	/**
	* <p>描述:拼装回写的接口报文</p>
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	private Map<String, Object> getPostDatas(String feedbackMainNo,String orgCode) throws Exception {
		Map<String,Object> getPostMap=new HashMap<String, Object>();
		String timeStamp=DateTools.getTimeStamp(new Date());
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("ROOT");
		Element declareResult = root.addElement("ECIQ_REQUEST_INFO");
		// 校验头
		Element verify = declareResult.addElement("VERIFY_INFO");
		//CA认证的ticket ADDITIONAL1
		Map<String,Object> ticket=CasTicketRequest.c(orgCode);
		if(Utils.notEmpty(ticket)&&(Boolean)ticket.get("flag")){
			verify.addElement("TICKET").setText((String)ticket.get("data"));
		}else{
			return ticket;
		}
		
		verify.addElement("BIZ_ID").setText("04");
		verify.addElement("SENDER").setText("04");
		verify.addElement("REQUEST_TYPE").setText("01");
		verify.addElement("SEND_TIME").setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		verify.addElement("SOURCE_TYPE").setText("05");

		Map<String, String> hmap = new HashMap<String, String>();
		hmap.put("SOURCE_ID", "380000");
		hmap.put("SOURCE_APP", "APP_MI");
		hmap.put("DESTINATION_ID", "000000");
		hmap.put("DESTINATION_APP", "ECIQ");
		hmap.put("MESSAGE_TYPE", "1");
		hmap.put("MESSAGE_FORMAT", "1");
		hmap.put("MESSAGE_ID", "D9555C59F7944E4E992840062F530DA0");
		hmap.put("MESSAGE_VERSION", "1.0");
		hmap.put("REPORT_TYPE", "ITF_DCL_ORD_FEEDBACK_MAIN_B");
		// xml的源数据 ----开始
		CommDao util = new CommDao();
		DclOrdFeedbackMain feedbackMain = util.getDclOrdFeedbackMain2(feedbackMainNo);
		if(feedbackMain==null){
			getPostMap.put("flag", false);
			getPostMap.put("msg", "该报检号的布控反馈主ID"+feedbackMainNo+"不存在");
			return getPostMap;
		}
		
		feedbackMain.setTransBatch(timeStamp);
		if(feedbackMain.getFeedbackApp()==null){
			feedbackMain.setFeedbackApp("APP_MI");
		}
		
		List<DclOrdFeedbackDetail> fdsub = util.getDclOrdFeedbackDetail2(feedbackMainNo);
		feedbackMain.setFeedbackDetailList(fdsub);
		
		// xml的源数据 ----结束
		// 报文消息列表
		Element bizinfo = declareResult.addElement("BIZ_MESSAGE_INFO");
		Element record = bizinfo.addElement("BIZ_MESSAGE_RECORD");
		record.addElement("BIZ_HEADER").setText(CommunicationUtil.base64(getHeader(hmap,feedbackMain).getBytes("GBK"), DbConnectContext.EONDING_GBK));
		record.addElement("BIZ_BODY").setText(CommunicationUtil.base64(ZipOperation.zip(getResultBodyEntity(feedbackMain).getBytes("GBK")), DbConnectContext.EONDING_GB2312));
		/////////////
//		XMLWriter writer = new XMLWriter(new FileWriter(new File("D:/eclipse/workspace/eciq_app_server/FeedBackMaintest.xml")));
//		writer.setEscapeText(false);
//		writer.write(document);
//		writer.close();
		getPostMap.put("flag", true);
		getPostMap.put("msg", "组装报文成功");
		getPostMap.put("data", document.asXML());
		log.info("ITF_DCL_ORD_FEEDBACK_MAIN_B 总发送报文:"+document.asXML()+"*******************************");
		return getPostMap;
	}

	/**
	* <p>描述:组装报文体信息</p>
	* @param sumB
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	private String getResultBodyEntity(DclOrdFeedbackMain feedbackMain) throws Exception {
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("root");
		Element bizbody = root.addElement("ITF_DCL_ORD_FEEDBACK_MAIN_B");
		Field[] fields = DclOrdFeedbackMain.class.getDeclaredFields();
		for (Field f : fields) {
			buildXmlMethods(feedbackMain, DclOrdFeedbackMain.class.getSimpleName(), f, bizbody);
		}
		addDclOrdFeedBackDetailToBody(feedbackMain, bizbody);// 加入到xml中
		log.info("组装的body:\n"+document.asXML());
		return document.asXML();
	}

	/**
	* <p>描述:利用java反射机制组装xml报文</p>
	* @param sumB
	* @param simpleName
	* @param f
	* @param bizbody
	* @author 吴有根
	 * @throws Exception 
	*/
	private void buildXmlMethods(Object object, String simpleName, Field f, Element bizbody) throws Exception {
		try {
			if (f.get(object) != null) {
				// 目前该报文的主子表中只存在String Date BigDecimal类型的属性，主实体中List不判断
				if (f.getType().getName().equals(String.class.getName()))// String
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.get(object).toString());// 可以为空，实际不为空，直接赋值
				else if (f.getType().getName().equals(Date.class.getName()))// Date
				{
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(sdf.format(f.get(object)));// 可以为空，实际不为空，直接赋值
				} else if (f.getType().getName().equals(java.lang.Integer.class.getName())
						|| f.getType().getName().equals("int"))// int
				{// int
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.getInt(object) + "");
				} else if (f.getType().getName().equals(BigDecimal.class.getName()))// BigDecimal
				{
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.get(object) + "");
				} // 因为主实体中有List，因此这里不处理

			} else if (f.get(object) == null) {
				bizbody.addElement(
						f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()));// 可以为空，实际为空，只添加节点
			}
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (IllegalAccessException e) {
			throw e;
		} // 可以为空，实际不为空，直接赋值
	}
	
	/**
	 * 
	* <p>描述:添加InsResultGoods到xml的body中</p>
	* @param sumB
	* @param bizbody
	* @throws Exception
	* @author 吴有根
	 */
	public void addDclOrdFeedBackDetailToBody(DclOrdFeedbackMain sum, Element bizbody) throws Exception {
		List<DclOrdFeedbackDetail> rgsubs = sum.getFeedbackDetailList();
		Element bizbodyrgs = null;
		bizbodyrgs = bizbody.addElement("ITF_DCL_ORD_FEEDBACK_DETAIL_BS");

		for (DclOrdFeedbackDetail rgsub : rgsubs) {
			Element bizbodyrg = bizbodyrgs.addElement("ITF_DCL_ORD_FEEDBACK_DETAIL_B");
			Field[] subfields = DclOrdFeedbackDetail.class.getDeclaredFields();// 字段必须为public
																			
			for (Field f : subfields) {
				buildXmlMethods(rgsub, DclOrdFeedbackDetail.class.getSimpleName(), f, bizbodyrg);
			}
		}
	}


	


	/**
	* <p>描述:组织报文头信息</p>
	* @param hmap
	* @return
	* @author 吴有根
	* @throws Exception 
	*/
	private String getHeader(Map<String, String> map,DclOrdFeedbackMain feedbackMain) throws Exception {
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("ROOT");
		Element bizhead = root.addElement("BIZ_HEAD_INFO");
		bizhead.addElement("SOURCE_ID").setText(map.get("SOURCE_ID"));
		bizhead.addElement("SOURCE_APP").setText(map.get("SOURCE_APP"));
		bizhead.addElement("DESTINATION_ID").setText(map.get("DESTINATION_ID"));
		bizhead.addElement("DESTINATION_APP").setText(map.get("DESTINATION_APP"));
		bizhead.addElement("MESSAGE_TYPE").setText(map.get("MESSAGE_TYPE"));
		bizhead.addElement("MESSAGE_FORMAT").setText(map.get("MESSAGE_FORMAT"));
		bizhead.addElement("MESSAGE_ID").setText(map.get("MESSAGE_ID"));
		bizhead.addElement("PRE_MESSAGE_ID");
		bizhead.addElement("MESSAGE_VERSION").setText(map.get("MESSAGE_VERSION"));
		bizhead.addElement("REPORT_TYPE").setText(map.get("REPORT_TYPE"));
		bizhead.addElement("ACTION_TYPE").setText("IU");
		bizhead.addElement("BIZ_FIELD1");
		bizhead.addElement("BIZ_FIELD2");
		bizhead.addElement("BIZ_FIELD3");
		bizhead.addElement("BIZ_SIGN_INFO").setText(SignatureUtil.getSignInfo(getResultBodyEntity(feedbackMain)));
		return document.asXML();
	}


}

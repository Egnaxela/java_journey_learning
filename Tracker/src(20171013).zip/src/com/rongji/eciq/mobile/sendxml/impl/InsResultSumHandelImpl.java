/**  
 * FileName:   InsResultSumHandelImpl.java  
 * @Description: 现场查验及结果登记接口发送xml报文实现类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午10:34:13  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Component;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.DbConnectContext;
import com.rongji.eciq.mobile.sendxml.bean.InsCheckItem;
import com.rongji.eciq.mobile.sendxml.bean.InsContainerResult;
import com.rongji.eciq.mobile.sendxml.bean.InsDeclMag;
import com.rongji.eciq.mobile.sendxml.bean.InsResultGoods;
import com.rongji.eciq.mobile.sendxml.bean.InsResultSum;
import com.rongji.eciq.mobile.sendxml.bean.InsResultWoodpack;
import com.rongji.eciq.mobile.sendxml.service.InsResultSumHandel;
import com.rongji.eciq.mobile.sendxml.utils.CasTicketRequest;
import com.rongji.eciq.mobile.sendxml.utils.CommDao;
import com.rongji.eciq.mobile.sendxml.utils.CommunicationUtil;
import com.rongji.eciq.mobile.sendxml.utils.DbUtils;
import com.rongji.eciq.mobile.sendxml.utils.SignatureUtil;
import com.rongji.eciq.mobile.sendxml.utils.ZipOperation;
import com.rongji.eciq.mobile.utils.DateTools;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description: 现场查验及结果登记接口发送xml报文实现类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午10:34:13  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-04      吴有根                      1.0         1.0 Version 
 * 2017-07-14      吴有根                      1.0         报文头增加对报文体进行数字签名的节点BIZ_SIGN_INFO  
 */
@Component
public class InsResultSumHandelImpl implements InsResultSumHandel{

	private static Logger log=Logger.getLogger(InsResultSumHandelImpl.class);
	

	
	/**
	 * 
	* <p>描述: 后面三个字段用于来更新施检备份表</p>
	* @param declNo 报检单号
	* @param inspBflag  主辅检标记
	* @param bOperatorCode  主辅检操作人
	* @param bOrgCode  主辅检操作部门 
	* @param orgCode   机构代码
	* @return
	* @author 吴有根
	 */
	@Override
	public String getSendInsResultSum(HttpServletRequest request,HttpServletResponse response,String declNo,String inspBflag,String bOperatorCode,String bOrgCode,String orgCode) {
		InsResultSumHandelImpl t=new InsResultSumHandelImpl();
		long startTime=System.currentTimeMillis();
		String msg="";
		try{
			
			Map<String, Object> getPostDatas=t.getPostDatas(declNo,inspBflag,bOperatorCode,bOrgCode,orgCode);
			if(Utils.notEmpty(getPostDatas)&&(Boolean)getPostDatas.get("flag")){
				msg=CommunicationUtil.getHttpContentAsByte(CasTicketRequest.getConfigList2("address").getConfigValue()+"/eciq/senddatas",
						((String)getPostDatas.get("data")).getBytes());
			}else{
				msg=(String)getPostDatas.get("msg");
				CasTicketRequest.saveExceptionObject(request,msg);
			}
			
		}catch (Exception e) {
			try {
				StringWriter writer = new StringWriter();
				e.printStackTrace(new PrintWriter(writer));
				msg=writer.toString();
				CasTicketRequest.saveExceptionObject(request,msg);
			} catch (Exception e1) {
			}
			log.info(msg);
			return msg;
		}
		long endTime=System.currentTimeMillis();
		log.info("耗时:"+(endTime-startTime)+"ms"+",返回的信息为：\n"+msg);
		return msg;
	}

	/**
	* <p>描述:拼装回写的接口报文</p>
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	private Map<String, Object> getPostDatas(String declNo,String inspBFlag,String bOperatorCode,String bOrgCode,String orgCode) throws Exception {
		Map<String,Object> getPostMap=new HashMap<String, Object>();
		String timeStamp=DateTools.getTimeStamp(new Date());
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("ROOT");
		Element declareResult = root.addElement("ECIQ_REQUEST_INFO");
		// 校验头
		Element verify = declareResult.addElement("VERIFY_INFO");
		//CA认证的ticket
		Map<String,Object> ticket=CasTicketRequest.c(orgCode);
		if(Utils.notEmpty(ticket)&&(Boolean)ticket.get("flag")){
			verify.addElement("TICKET").setText((String)ticket.get("data"));
		}else{
			return ticket;
		}
		verify.addElement("BIZ_ID").setText("04");
		verify.addElement("SENDER").setText("04");
		verify.addElement("REQUEST_TYPE").setText("01");
		verify.addElement("SEND_TIME").setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		verify.addElement("SOURCE_TYPE").setText("05");

		Map<String, String> hmap = new HashMap<String, String>();
		hmap.put("SOURCE_ID", "380000");
		hmap.put("SOURCE_APP", "APP_MI");
		hmap.put("DESTINATION_ID", "000000");
		hmap.put("DESTINATION_APP", "ECIQ");
		hmap.put("MESSAGE_TYPE", "1");
		hmap.put("MESSAGE_FORMAT", "1");
		hmap.put("MESSAGE_ID", "D9555C59F7944E4E992840062F530DA0");
		hmap.put("MESSAGE_VERSION", "1.0");
		hmap.put("REPORT_TYPE", "ITF_INS_RESULT_SUM_MI");
		// xml的源数据 ----开始
		String DECL_NO = declNo; // 116000000132316  116000000000133
		CommDao util = new CommDao();
		InsResultSum sumB = util.getInsResultSum2(DECL_NO);
		if(sumB==null){
			getPostMap.put("flag", false);
			getPostMap.put("msg", "该报检号"+declNo+"的sum主表不存在");
			return getPostMap;
		}
		sumB.setResultSumBId(UUIDKeyGeneratorUils.newInstance().generateKey());
		sumB.setInspBFlag(inspBFlag);
		sumB.setBOrgCode(bOrgCode);
		sumB.setBOperatorCode(bOperatorCode);
		sumB.setTransBatch(timeStamp);
		sumB.setRemark("移动端数据回写");
		
		List<InsResultGoods> rgsub = util.getInsResultGoods2(DECL_NO);
		if(Utils.notEmpty(rgsub)){
			for(InsResultGoods entity:rgsub){
				entity.setInspBFlag(inspBFlag);
				entity.setBOperatorCode(bOperatorCode);
				entity.setBOrgCode(bOrgCode);
				entity.setTransBatch(timeStamp);
			}
		}
		sumB.setRgList(rgsub);
		
		List<InsResultWoodpack> rwsub = util.getInsResultWoodpack2(DECL_NO);
		if(Utils.notEmpty(rwsub)){
			for(InsResultWoodpack entity:rwsub){
				entity.setInspBFlag(inspBFlag);
				entity.setBOperatorCode(bOperatorCode);
				entity.setBOrgCode(bOrgCode);
				entity.setTransBatch(timeStamp);
			}
		}
		sumB.setRwList(rwsub);
		
		List<InsContainerResult> crsub = util.getInsContainerResult2(DECL_NO);
		if(Utils.notEmpty(crsub)){
			for(InsContainerResult entity:crsub){
				entity.setInspBFlag(inspBFlag);
				entity.setBOperatorCode(bOperatorCode);
				entity.setBOrgCode(bOrgCode);
				entity.setTransBatch(timeStamp);
			}
		}
		sumB.setCrList(crsub);
		
		List<InsCheckItem> cisub = util.getInsCheckItem2(DECL_NO);
		if(Utils.notEmpty(cisub)){
			for(InsCheckItem entity:cisub){
				entity.setInspBFlag(inspBFlag);
				entity.setBOperatorCode(bOperatorCode);
				entity.setBOrgCode(bOrgCode);
				entity.setTransBatch(timeStamp);
			}
		}
		sumB.setCiList(cisub);
		
		List<InsDeclMag> dmsub=util.getInsDeclMag2(DECL_NO,bOperatorCode);
		if(Utils.notEmpty(dmsub)){
			for(InsDeclMag entity:dmsub){
				entity.setTransBatch(timeStamp);
			}
		}
		sumB.setDmList(dmsub);
		
		// xml的源数据 ----结束
		// 报文消息列表
		Element bizinfo = declareResult.addElement("BIZ_MESSAGE_INFO");
		Element record = bizinfo.addElement("BIZ_MESSAGE_RECORD");
		record.addElement("BIZ_HEADER").setText(CommunicationUtil.base64(getHeader(hmap,sumB).getBytes("GBK"), DbConnectContext.EONDING_GBK));
		record.addElement("BIZ_BODY").setText(CommunicationUtil.base64(ZipOperation.zip(getResultBodyEntity(sumB).getBytes("GBK")), DbConnectContext.EONDING_GB2312));
		/////////////
//		XMLWriter writer = new XMLWriter(new FileWriter(new File("D:/eclipse/workspace/eciq_app_server/ResultSumtest.xml")));
//		writer.setEscapeText(false);
//		writer.write(document);
//		writer.close();
		getPostMap.put("flag", true);
		getPostMap.put("msg", "组装报文成功");
		getPostMap.put("data", document.asXML());
		log.info("ITF_INS_RESULT_SUM_MI 总发送报文:"+document.asXML()+"********************");
		return getPostMap;
	}

	/**
	* <p>描述:组装报文体信息</p>
	* @param sumB
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	private String getResultBodyEntity(InsResultSum sumB) throws Exception {
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("root");
		Element bizbody = root.addElement("ITF_INS_RESULT_SUM_B");
		Field[] fields = InsResultSum.class.getDeclaredFields();
		for (Field f : fields) {
			buildXmlMethods(sumB, InsResultSum.class.getSimpleName(), f, bizbody);
		}
		addInsResultGoodsToBody(sumB, bizbody);// InsResultGoods加入到xml中
		addInsResultWoodpackToBody(sumB, bizbody);// InsResultWoodpack加入到xml中
		addInsContainerResultToBody(sumB, bizbody);// InsContainerResult加入到xml中
		addInsCheckItemToBody(sumB, bizbody);// InsCheckItem加入到xml中
		addInsDeclMagToBody(sumB,bizbody);//InsDeclMag到xml中
		log.info("组装的body:\n"+document.asXML());
		return document.asXML();
	}

	
	/**
	* <p>描述:addInsDeclMag到 Body xml中</p>
	* @param sumB
	* @param bizbody
	* @author 吴有根
	 * @throws Exception 
	*/
	private void addInsDeclMagToBody(InsResultSum sumB, Element bizbody) throws Exception {
		List<InsDeclMag> cisubs = sumB.getDmList();
		Element bizbodycis = null;
		bizbodycis = bizbody.addElement("ITF_INS_DECL_MAG_BS");

		for (InsDeclMag cisub : cisubs) {
			Element bizbodyci = bizbodycis.addElement("ITF_INS_DECL_MAG_B");
			Field[] subfields = InsDeclMag.class.getDeclaredFields();
			for (Field f : subfields) {
				buildXmlMethods(cisub, InsDeclMag.class.getSimpleName(), f, bizbodyci);
			}
		}
	}

	/**
	* <p>描述:利用java反射机制组装xml报文</p>
	* @param sumB
	* @param simpleName
	* @param f
	* @param bizbody
	* @author 吴有根
	 * @throws Exception 
	*/
	private void buildXmlMethods(Object object, String simpleName, Field f, Element bizbody) throws Exception {
		try {
			if (f.get(object) != null) {
				// 目前该报文的主子表中只存在String Date BigDecimal类型的属性，主实体中List不判断
				if (f.getType().getName().equals(String.class.getName()))// String
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.get(object).toString());// 可以为空，实际不为空，直接赋值
				else if (f.getType().getName().equals(Date.class.getName()))// Date
				{
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(sdf.format(f.get(object)));// 可以为空，实际不为空，直接赋值
				} else if (f.getType().getName().equals(java.lang.Integer.class.getName())
						|| f.getType().getName().equals("int"))// int
				{// int
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.getInt(object) + "");
				} else if (f.getType().getName().equals(BigDecimal.class.getName()))// BigDecimal
				{
					bizbody.addElement(
							f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()))
							.setText(f.get(object) + "");
				} // 因为主实体中有List，因此这里不处理

			} else if (f.get(object) == null) {
				bizbody.addElement(
						f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1, f.getName().length()));// 可以为空，实际为空，只添加节点
			}
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (IllegalAccessException e) {
			throw e;
		} // 可以为空，实际不为空，直接赋值
	}
	
	/**
	 * 
	* <p>描述:添加InsResultGoods到xml的body中</p>
	* @param sumB
	* @param bizbody
	* @throws Exception
	* @author 吴有根
	 */
	public void addInsResultGoodsToBody(InsResultSum sumB, Element bizbody) throws Exception {
		List<InsResultGoods> rgsubs = sumB.getRgList();
		Element bizbodyrgs = null;
		bizbodyrgs = bizbody.addElement("ITF_INS_RESULT_GOODS_BS");

		for (InsResultGoods rgsub : rgsubs) {
			Element bizbodyrg = bizbodyrgs.addElement("ITF_INS_RESULT_GOODS_B");
			Field[] subfields = InsResultGoods.class.getDeclaredFields();// 字段必须为public，若为private则需要 setAccessible(true)
			for (Field f : subfields) {
				buildXmlMethods(rgsub, InsResultGoods.class.getSimpleName(), f, bizbodyrg);
			}
		}
	}


	/**
	 * 
	* <p>描述:add InsResultWoodpack到body xml中</p>
	* @param sumB
	* @param bizbody
	* @throws Exception
	* @author 吴有根
	 */
	public void addInsResultWoodpackToBody(InsResultSum sumB, Element bizbody) throws Exception {
		List<InsResultWoodpack> rwsubs = sumB.getRwList();
		Element bizbodyrws = null;
		bizbodyrws = bizbody.addElement("ITF_INS_RESULT_WOODPACK_BS");

		for (InsResultWoodpack rwsub : rwsubs) {
			Element bizbodyrw = bizbodyrws.addElement("ITF_INS_RESULT_WOODPACK_B");
			Field[] subfields = InsResultWoodpack.class.getDeclaredFields();
			for (Field f : subfields) {
				buildXmlMethods(rwsub, InsResultWoodpack.class.getSimpleName(), f, bizbodyrw);
			}
		}
	}

	/**
	 * 
	* <p>描述:add InsContainerResult到body xml中</p>
	* @param sumB
	* @param bizbody
	* @throws Exception
	* @author 吴有根
	 */
	public void addInsContainerResultToBody(InsResultSum sumB, Element bizbody) throws Exception {
		List<InsContainerResult> crsubs = sumB.getCrList();
		Element bizbodycrs = null;
		bizbodycrs = bizbody.addElement("ITF_INS_CONTAINER_RESULT_BS");

		for (InsContainerResult crsub : crsubs) {
			Element bizbodycr = bizbodycrs.addElement("ITF_INS_CONTAINER_RESULT_B");
			Field[] subfields = InsContainerResult.class.getDeclaredFields();
			for (Field f : subfields) {
				buildXmlMethods(crsub, InsContainerResult.class.getSimpleName(), f, bizbodycr);
			}
		}
	}


	/**
	 * 
	* <p>描述:add InsCheckItem 到 body xml中</p>
	* @param sumB
	* @param bizbody
	* @throws Exception
	* @author 吴有根
	 */
	public void addInsCheckItemToBody(InsResultSum sumB, Element bizbody) throws Exception {
		List<InsCheckItem> cisubs = sumB.getCiList();
		Element bizbodycis = null;
		bizbodycis = bizbody.addElement("ITF_INS_CHECK_ITEM_BS");

		for (InsCheckItem cisub : cisubs) {
			Element bizbodyci = bizbodycis.addElement("ITF_INS_CHECK_ITEM_B");
			Field[] subfields = InsCheckItem.class.getDeclaredFields();
			for (Field f : subfields) {
				buildXmlMethods(cisub, InsCheckItem.class.getSimpleName(), f, bizbodyci);
			}
		}
	}


	/**
	* <p>描述:组织报文头信息</p>
	* @param hmap
	* @return
	* @author 吴有根
	* @throws Exception 
	*/
	private String getHeader(Map<String, String> map,InsResultSum sumB) throws Exception {
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(DbConnectContext.EONDING_GBK);
		Element root = document.addElement("ROOT");
		Element bizhead = root.addElement("BIZ_HEAD_INFO");
		bizhead.addElement("SOURCE_ID").setText(map.get("SOURCE_ID"));
		bizhead.addElement("SOURCE_APP").setText(map.get("SOURCE_APP"));
		bizhead.addElement("DESTINATION_ID").setText(map.get("DESTINATION_ID"));
		bizhead.addElement("DESTINATION_APP").setText(map.get("DESTINATION_APP"));
		bizhead.addElement("MESSAGE_TYPE").setText(map.get("MESSAGE_TYPE"));
		bizhead.addElement("MESSAGE_FORMAT").setText(map.get("MESSAGE_FORMAT"));
		bizhead.addElement("MESSAGE_ID").setText(map.get("MESSAGE_ID"));
		bizhead.addElement("PRE_MESSAGE_ID");
		bizhead.addElement("MESSAGE_VERSION").setText(map.get("MESSAGE_VERSION"));
		bizhead.addElement("REPORT_TYPE").setText(map.get("REPORT_TYPE"));
		bizhead.addElement("ACTION_TYPE").setText("IU");
		bizhead.addElement("BIZ_FIELD1");
		bizhead.addElement("BIZ_FIELD2");
		bizhead.addElement("BIZ_FIELD3");
		bizhead.addElement("BIZ_SIGN_INFO").setText(SignatureUtil.getSignInfo(getResultBodyEntity(sumB)));
		return document.asXML();
	}

}

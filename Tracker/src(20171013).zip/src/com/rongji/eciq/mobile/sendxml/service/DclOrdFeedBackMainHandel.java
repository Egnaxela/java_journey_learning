/**  
 * FileName:    DclOrdFeedBackMainHandel.java 
 * @Description: 布控反馈信息发送xml报文接口
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月5日 下午3:09:03  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

/**  
 * Description: 布控反馈信息发送xml报文接口  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月5日 下午3:09:03  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月5日      吴有根                      1.0         1.0 Version  
 */

@Component
public interface DclOrdFeedBackMainHandel {

	/**
	 * 
	* <p>描述:根据布控反馈ID组装xml报文 </p>
	* @param feedbackMainNo 布控反馈主编号
	* @param orgCode 用户部门代码
	* @return
	* @author 吴有根
	 */
	String getSendDclOrdFeedBackMain(HttpServletRequest request,HttpServletResponse response,String feedbackMainNo,String orgCode);
}

/**  
 * FileName:InsResultEvalHandel.java     
 * @Description: 发送检验检疫综合评定结果表报文接口
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月25日 上午10:16:38  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.rongji.eciq.mobile.sendxml.bean.InsResultEval;

/**  
 * Description: 发送检验检疫综合评定结果表报文接口 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月25日 上午10:16:38  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月25日      吴有根                      1.0         1.0 Version  
 */

@Component
public interface InsResultEvalHandel {

	/**
	 * 
	* <p>描述:发送检验检疫综合评定结果表报文</p>
	* @param request
	* @param response
	* @param evalEntity
	* @param orgCode 用户机构代码如110000
	* @return
	* @author 吴有根
	 */
	String getSendInsResultEval(HttpServletRequest request,HttpServletResponse response,InsResultEval evalEntity,String... orgCode);
}

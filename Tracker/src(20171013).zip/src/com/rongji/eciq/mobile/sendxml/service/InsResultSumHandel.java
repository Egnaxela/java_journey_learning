/**  
 * FileName:   InsResultSumHandel.java  
 * @Description: 结果登记&现场记录信息发送xml报文接口
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午10:19:25  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;


/**  
 * Description: 结果登记&现场记录信息发送xml报文接口  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午10:19:25  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version  
 */

@Component
public interface InsResultSumHandel{
	
	/**
	 * 
	* <p>描述: 后面三个字段用于来更新施检备份表</p>
	* @param declNo 报检单号
	* @param inspBflag  主辅检标记
	* @param bOperatorCode  主辅检操作人
	* @param bOrgCode  主辅检操作部门 
	* @param orgCode   机构代码
	* @return
	* @author 吴有根
	 */
	String getSendInsResultSum(HttpServletRequest request,HttpServletResponse response,String declNo,String inspBflag,String bOperatorCode,String bOrgCode,String orgCode);
}

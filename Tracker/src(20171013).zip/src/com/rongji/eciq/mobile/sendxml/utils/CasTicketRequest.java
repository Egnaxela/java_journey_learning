/**  
 * FileName:   CasTicketRequest.java  
 * @Description: 用于返回CA认证的结果
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午11:47:33  
 *  
 */  
package com.rongji.eciq.mobile.sendxml.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rongji.cas.client.CasConnectException;
import com.rongji.cas.client.CasRequest;
import com.rongji.cas.client.CasTicket;
import com.rongji.cas.client.request.CasHttpRequest;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.framework.ClusterIdGetter;
import com.rongji.eciq.entity.EciqExceptionLog;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.dao.PubCommonDAO;
import com.rongji.system.common.util.DaoHelper;
import com.rongji.system.entity.SysConfigEntity;

/**
 * 
 * Description: 用于返回CA认证的结果  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午11:47:33  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-04      吴有根                      1.0         1.0 Version
 * 2017-05-24      吴有根                      1.0         改为从数据库中获取CA地址，不再读取配置文件
 */
public class CasTicketRequest {
	
	private static final Logger log=Logger.getLogger(CasTicketRequest.class);

	/**
	 * 
	* <p>描述:用户密码方式</p>
	* @throws CasConnectException
	 */
	public static Map<String, Object> c(String orgCode) {
		// String host = DbUtils.getServerAddress("host");
		Map<String, Object> map = new HashMap<String, Object>();
		String host = null;
		SysConfigEntity caentity = getConfigList2("host");// 获取CA认证平台地址
		if (caentity != null) {
			host = caentity.getConfigValue();
		} else {
			map.put("flag", false);
			map.put("msg", "CA认证平台地址不存在");
			return map;
		}
		// 使用用户名密码的方式
		CasRequest cr = new CasHttpRequest(host);
		String username = null;
		String password = null;
		String appFlag = getAppFlag(orgCode);
		if(StringUtils.isEmpty(appFlag)) {
			appFlag = "ECIQ_ENT";
		}
		// 根据用户机构代码获取
		SysConfigEntity entity = getConfigList(orgCode);
		if (entity != null) {
			username = entity.getConfigCode();
			password = entity.getConfigValue();
		} else {
			map.put("flag", false);
			map.put("msg", "当前机构没有通过CA认证,请联系管理员申请");
			return map;
		}
		// 普通方式
		CasTicket ticket = null;
		try {
			ticket = cr.requestTicketIdPwd(username, password, appFlag);// 用户名
		} catch (Exception e) {
			StringWriter writer = new StringWriter();
			e.printStackTrace(new PrintWriter(writer));
			map.put("flag", false);
			map.put("msg", writer.toString());
			return map;
		}
		if (!ticket.isReqSucc()) {
			log.info("CA认证失败: " + ticket.getReqErrorMsg());
			map.put("flag", false);
			map.put("msg", ticket.getReqErrorMsg());
			return map;
		}
		log.info("Ticket: " + ticket.getEncrypted());
		map.put("flag", true);
		map.put("data", ticket.getEncrypted());
		return map;
	}
	
	static PubCommonDAO dao = DaoHelper.getSystemPageDAO();
	
	/**
	 * 
	* <p>描述:根据条件查询参数列表信息,获取CA认证的用户名和密码</p>
	* @param orgCode 用户机构代码
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public static SysConfigEntity getConfigList(String orgCode) {
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SysConfigEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.companyCode =?");
			param.add(orgCode);
		}else{
			return null;
		}
		sql.append(" AND t.description =?");
		param.add(PropertiesContext.CAUSERS);//CA认证
		List<SysConfigEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		if (Utils.notEmpty(list)&&list.size()==1) {
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 
	* <p>描述:根据条件查询参数列表信息,获取应用标识</p>
	* @param orgCode 用户机构代码
	* @return
	* @author 才江男
	 */
	@SuppressWarnings("unchecked")
	public static String getAppFlag(String orgCode) {
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SysConfigEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(orgCode)){
			sql.append(" AND t.companyCode =?");
			param.add(orgCode);
		}else{
			return null;
		}
		sql.append(" AND t.configCode =?");
		param.add(PropertiesContext.APPFLAG);//应用标识
		List<SysConfigEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		if (Utils.notEmpty(list)&&list.size()==1) {
			return list.get(0).getConfigValue();
		}
		return null;
	}
	
	
	/**
	 * 
	* <p>描述:获取CA认证地址、电子业务平台认证地址</p>
	* @param orgCode
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public static SysConfigEntity getConfigList2(String flag) {
		
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM SysConfigEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.equals(flag, "address")){
			sql.append(" AND t.description =?");
			param.add(PropertiesContext.EBPSA); //电子业务平台服务地址
		}else if(StringUtils.equals(flag, "host")){
			sql.append(" AND t.description =?");
			param.add(PropertiesContext.CAAPA); //CA认证平台地址
		}
		List<SysConfigEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		if (Utils.notEmpty(list)&&list.size()==1) {
			return list.get(0);
		}
		return null;
	}


	/**
	* <p>描述:保存异常报文发送情况信息</p>
	* @param msg
	* @author 吴有根
	 * @throws Exception 
	*/
	public static void saveExceptionObject(HttpServletRequest request, String msg){
		EciqExceptionLog log = new EciqExceptionLog();
		log.setLogId(ClusterIdGetter.getInstance().getNewId());
		log.setLogTime(new Date());
		StringBuffer logUrl = request.getRequestURL();
		log.setLogUrl(logUrl.toString());
		log.setLogIp(getIpAddr(request));
		log.setLogContent(msg);
		Map<String, String> argsMap = getArgsMap(request);
		if (Utils.notEmpty(argsMap)) {
			try {
				log.setLogParam(new ObjectMapper().writeValueAsString(argsMap));
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		log.setLogUser(MobileHelper.getLoginUser(request));

		dao.saveObject(log);
	}

	private static String getIpAddr(HttpServletRequest request) {
		try {
			String ip = request.getHeader("x-forwarded-for");
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			return ip;
		} catch (Exception e) {
		}
		return "";
	}

	public static Map<String, String> getArgsMap(HttpServletRequest request) {
		Map<String, String> argsMap = new LinkedHashMap<String, String>();
		try {
			Map properties = request.getParameterMap();
			if (properties != null) {
				Iterator entries = properties.entrySet().iterator();
				boolean isGet = "GET".equalsIgnoreCase(request.getMethod());
				while (entries.hasNext()) {
					Map.Entry entry = (Map.Entry) entries.next();
					Object valueObj = entry.getValue();
					String name = (String) entry.getKey();
					if (Utils.notEmpty(name) && valueObj != null) {
						String value = "";
						if (valueObj instanceof String[]) {
							String[] values = (String[]) valueObj;
							if (Utils.notEmpty(values)) {
								for (String v : values) {
									if (Utils.notEmpty(v)) {
										if (isGet) {
											v = new String(v.getBytes("ISO-8859-1"), "UTF-8");
										}
										value += "," + v;
									}
								}
								if (Utils.notEmpty(value)) {
									value = value.substring(1);
								}
							}
						} else {
							value = valueObj.toString();
							if (isGet && Utils.notEmpty(value)) {
								value = new String(value.getBytes("ISO-8859-1"), "UTF-8");
							}
						}
						if (Utils.notEmpty(value)) {
							argsMap.put(name, value);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return argsMap;
	}

}

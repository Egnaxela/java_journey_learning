/**  
 * FileName:   CommDao.java  
 * @Description: 组装报文所需数据查询类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午11:56:19  
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.utils;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.rj.dbxml.c.l;
import com.rongji.dfish.base.Page;
import com.rongji.dfish.base.Utils;
import com.rongji.dfish.dao.PubCommonDAO;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsContainerResultEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsResultEvalEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsXmlEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.InsResultWoodpackEntity;
import com.rongji.eciq.mobile.sendxml.bean.DclOrdFeedbackDetail;
import com.rongji.eciq.mobile.sendxml.bean.DclOrdFeedbackMain;
import com.rongji.eciq.mobile.sendxml.bean.InsCheckItem;
import com.rongji.eciq.mobile.sendxml.bean.InsContainerResult;
import com.rongji.eciq.mobile.sendxml.bean.InsDeclMag;
import com.rongji.eciq.mobile.sendxml.bean.InsResultEval;
import com.rongji.eciq.mobile.sendxml.bean.InsResultGoods;
import com.rongji.eciq.mobile.sendxml.bean.InsResultSum;
import com.rongji.eciq.mobile.sendxml.bean.InsResultWoodpack;
import com.rongji.eciq.mobile.sendxml.bean.ItfInsCheckItemB;
import com.rongji.eciq.mobile.sendxml.bean.ItfInsContainerResultB;
import com.rongji.eciq.mobile.sendxml.bean.ItfInsResultGoodsB;
import com.rongji.eciq.mobile.sendxml.bean.ItfInsResultSumB;
import com.rongji.eciq.mobile.sendxml.bean.ItfInsResultWoodpackB;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.system.common.util.FrameworkHelper;


/**
 * 
 * Description: 组装报文所需数据查询类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午11:56:19  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version
 */
public class CommDao {
	
	PubCommonDAO dao = FrameworkHelper.getChgDAO();
	
	/**
     * 
     * @discription 获取主表List<ItfInsResultSumB>内容
     * @param itfId
     * @return
     * @throws Exception
     */
	public InsResultSum getInsResultSum(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List column=null;//获取xml文件中的该表的列节点
		column = fTable.elements("column");
		List columnName=new ArrayList();;
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table =  (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		
		InsResultSum re=null;
		String select = "select * "
				+" from Ins_Result_sum t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				if(re==null){
				re = new InsResultSum();
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsResultSum.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return re;
	}
	
	@SuppressWarnings("unchecked")
	public InsResultSum getInsResultSum2(String declNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultSumEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<InsResultSumEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		if(Utils.notEmpty(list)){
			InsResultSum sum=new InsResultSum();
			try {
				BeanPropertyUtils.getInstance().copyPropertiesBean(sum, list.get(0));
			} catch (Throwable e) {
				e.printStackTrace();
			}
			return sum;
		}
		return null;
	}
	

	/**
     * 
     * @discription 获取子表List<InsResultGoods>内容
     * @param itfId
     * @return
     * @throws Exception
     */
	public List<InsResultGoods> getInsResultGoods(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("INS_RESULT_GOODS")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<InsResultGoods> reList = new ArrayList<InsResultGoods>();
		InsResultGoods re=null;
		String select = "select * "
				+" from Ins_Result_Goods t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new InsResultGoods();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsResultGoods.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}
	
	/**
	 * 
	* <p>描述:获取货物检验结果表信息</p>
	* @param DECL_NO
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public List<InsResultGoods> getInsResultGoods2(String declNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultGoodsXmlEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<InsResultGoodsXmlEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<InsResultGoods> goodslist=new ArrayList<InsResultGoods>();
		if(Utils.notEmpty(list)){
			for(InsResultGoodsXmlEntity entity:list){
				goodslist.ensureCapacity(list.size());
				InsResultGoods goodsEntity=new InsResultGoods();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(goodsEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				goodslist.add(goodsEntity);
			}
		}
		return goodslist;
	}
	
	
	/**
     * 
     * @discription 获取子表List<InsResultWoodpack>内容
     * @param itfId
     * @return
     * @throws Exception
     */
	public List<InsResultWoodpack> getInsResultWoodpack(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("INS_RESULT_WOODPACK")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<InsResultWoodpack> reList = new ArrayList<InsResultWoodpack>();
		InsResultWoodpack re=null;
		String select = "select * "
				+" from Ins_Result_Woodpack t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new InsResultWoodpack();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsResultWoodpack.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}
	
	
	/**
	 * 
	* <p>描述:获取木质包装表信息</p>
	* @param DECL_NO
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public List<InsResultWoodpack> getInsResultWoodpack2(String declNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsResultWoodpackEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		List<InsResultWoodpackEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<InsResultWoodpack> woodpacklist=new ArrayList<InsResultWoodpack>();
		if(Utils.notEmpty(list)){
			for(InsResultWoodpackEntity entity:list){
				woodpacklist.ensureCapacity(list.size());
				InsResultWoodpack woodpackEntity=new InsResultWoodpack();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(woodpackEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				woodpacklist.add(woodpackEntity);
			}
		}
		return woodpacklist;
	}
		

	/**
     * 
         * @discription 获取子表List<InsContainerResult>内容
         * @param itfId
         * @return
         * @throws Exception
     */
	public List<InsContainerResult> getInsContainerResult(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("INS_CONTAINER_RESULT")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<InsContainerResult> reList = new ArrayList<InsContainerResult>();
		InsContainerResult re=null;
		String select = "select * "
				+" from Ins_Container_Result t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				
				re = new InsContainerResult();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsContainerResult.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}

	
	/**
	 * 
	* <p>描述:获取集装箱检疫结果信息</p>
	* @param DECL_NO
	* @return
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public List<InsContainerResult> getInsContainerResult2(String declNo) {
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsContainerResultEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		List<InsContainerResultEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<InsContainerResult> containerlist=new ArrayList<InsContainerResult>();
		if(Utils.notEmpty(list)){
			for(InsContainerResultEntity entity:list){
				containerlist.ensureCapacity(list.size());
				InsContainerResult containerEntity=new InsContainerResult();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(containerEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				containerlist.add(containerEntity);
			}
		}
		return containerlist;
	}
		
    /**
     * 
         * @discription 获取子表List<InsCheckItem>内容
         * @param itfId
         * @return
         * @throws Exception
     */
	public List<InsCheckItem> getInsCheckItem(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("INS_CHECK_ITEM")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<InsCheckItem> reList = new ArrayList<InsCheckItem>();
		InsCheckItem re=null;
		String select = "select * "
				+" from Ins_Check_Item t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new InsCheckItem();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsCheckItem.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}

	
	/**
	 * 
	* <p>描述:</p>
	* @param DECL_NO
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	@SuppressWarnings("unchecked")
	public List<InsCheckItem> getInsCheckItem2(String declNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsCheckItemEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		List<InsCheckItemEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<InsCheckItem> checkItemlist=new ArrayList<InsCheckItem>();
		if(Utils.notEmpty(list)){
			for(InsCheckItemEntity entity:list){
				checkItemlist.ensureCapacity(list.size());
				InsCheckItem checkItemEntity=new InsCheckItem();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(checkItemEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				checkItemlist.add(checkItemEntity);
			}
		}
		return checkItemlist;
	}
		
	
	/**
     * 
     * @discription 获取主表List<ItfInsResultSumB>内容
     * @author huangguohai       
     * @created 2016-7-22 上午9:30:20     
     * @param itfId
     * @return
     * @throws Exception
     */
	public ItfInsResultSumB getItfInsResultSumB(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List column=null;//获取xml文件中的该表的列节点
		column = fTable.elements("column");
		List columnName=new ArrayList();;
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table =  (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		
		ItfInsResultSumB re=null;
		String select = "select * "
				+" from Itf_Ins_Result_sum_B t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_INTERNAL");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				if(re==null){
				re = new ItfInsResultSumB();
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = ItfInsResultSumB.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return re;
	}
	
	public List<ItfInsResultGoodsB> getItfInsResultGoodsB(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("ITF_INS_RESULT_GOODS_B")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<ItfInsResultGoodsB> reList = new ArrayList<ItfInsResultGoodsB>();
		ItfInsResultGoodsB re=null;
		String select = "select * "
				+" from Itf_Ins_Result_Goods_B t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_INTERNAL");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new ItfInsResultGoodsB();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = ItfInsResultGoodsB.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}
	
	public List<ItfInsResultWoodpackB> getItfInsResultWoodpackB(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("ITF_INS_RESULT_WOODPACK_B")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<ItfInsResultWoodpackB> reList = new ArrayList<ItfInsResultWoodpackB>();
		ItfInsResultWoodpackB re=null;
		String select = "select * "
				+" from Itf_Ins_Result_Woodpack_B t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_INTERNAL");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new ItfInsResultWoodpackB();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = ItfInsResultWoodpackB.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}

	/**
     * 
         * @discription 获取子表List<ItfInsContainerResultB>内容
         * @author huangguohai       
         * @created 2016-7-22 上午9:30:20     
         * @param itfId
         * @return
         * @throws Exception
     */
	public List<ItfInsContainerResultB> getItfInsContainerResultB(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("ITF_INS_CONTAINER_RESULT_B")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<ItfInsContainerResultB> reList = new ArrayList<ItfInsContainerResultB>();
		ItfInsContainerResultB re=null;
		String select = "select * "
				+" from Itf_Ins_Container_Result_B t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_INTERNAL");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				
				re = new ItfInsContainerResultB();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = ItfInsContainerResultB.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}

    /**
     * 
         * @discription 获取子表List<ItfInsCheckItemB>内容
         * @author huangguohai       
         * @created 2016-7-22 上午9:30:20     
         * @param itfId
         * @return
         * @throws Exception
     */
	public List<ItfInsCheckItemB> getItfInsCheckItemB(String DECL_NO) throws Exception{
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("ITF_INS_CHECK_ITEM_B")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<ItfInsCheckItemB> reList = new ArrayList<ItfInsCheckItemB>();
		ItfInsCheckItemB re=null;
		String select = "select * "
				+" from Itf_Ins_Check_Item_B t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_INTERNAL");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new ItfInsCheckItemB();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = ItfInsCheckItemB.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}

	/**
	* <p>描述:获取报检单管理表数据</p>
	* @param dECL_NO
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	public List<InsDeclMag> getInsDeclMag(String declNo) throws Exception {
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/INS_RESULT_SUM_MI.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("INS_DECL_MAG")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<InsDeclMag> dmList = new ArrayList<InsDeclMag>();
		InsDeclMag re=null;
		String select = "select * "
				+" from INS_DECL_MAG t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, declNo);
			rs = presl.executeQuery();
			while (rs.next())
			{
				re = new InsDeclMag();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsDeclMag.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				dmList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return dmList;
	}

	/**
	 * 
	* <p>描述:获取报检单管理表信息</p>
	* @param declNo
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	public List<InsDeclMag> getInsDeclMag2(String declNo,String bOperatorCode){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM InsDeclMagEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(declNo)){
			sql.append(" AND t.declNo =?");
			param.add(declNo);
		}
		
		if(StringUtils.isNotEmpty(bOperatorCode)) {
			sql.append(" AND t.receiverDocCode =?");
			param.add(bOperatorCode);
		}
		
		List<InsDeclMagEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<InsDeclMag> declMaglist=new ArrayList<InsDeclMag>();
		if(Utils.notEmpty(list)){
			for(InsDeclMagEntity entity:list){
				declMaglist.ensureCapacity(list.size());
				InsDeclMag declMagEntity=new InsDeclMag();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(declMagEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				declMaglist.add(declMagEntity);
			}
		}
		return declMaglist;
	}
	/**
	* <p>描述:获取布控反馈主表信息</p>
	* @param dECL_NO
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	public DclOrdFeedbackMain getDclOrdFeedbackMain(String feedbackMainNo) throws Exception {
		
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/DCL_ORD_FEEDBACK_MAIN.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List column=null;//获取xml文件中的该表的列节点
		column = fTable.elements("column");
		List columnName=new ArrayList();;
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table =  (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		
		DclOrdFeedbackMain re=null;
		String select = "select * "
				+" from DCL_ORD_FEEDBACK_MAIN t " 
				+" where t.FEEDBACK_MAIN_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, feedbackMainNo);
			rs = presl.executeQuery();
			while (rs.next())
			{
				if(re==null){
				re = new DclOrdFeedbackMain();
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = DclOrdFeedbackMain.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return re;
		
		
	}
	
	/**
	 * 
	* <p>描述:获取布控反馈主表信息</p>
	* @param feedbackMainNo
	* @return
	* @author 吴有根
	 */
	public DclOrdFeedbackMain getDclOrdFeedbackMain2(String feedbackMainNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclOrdFeedbackMainEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(feedbackMainNo)){
			sql.append(" AND t.feedbackMainNo =?");
			param.add(feedbackMainNo);
		}

		List<DclOrdFeedbackMainEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		DclOrdFeedbackMain feedbackmainEntity=new DclOrdFeedbackMain();
		if(Utils.notEmpty(list)){
			try {
				BeanPropertyUtils.getInstance().copyPropertiesBean(feedbackmainEntity, list.get(0));
			} catch (Throwable e) {
				e.printStackTrace();
			}
			return feedbackmainEntity;
		}
		return null;
	}
		

	/**
	* <p>描述:获取布控反馈明细表信息</p>
	* @param dECL_NO
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	public List<DclOrdFeedbackDetail> getDclOrdFeedbackDetail(String feedbackMainNo) throws Exception {
		
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/DCL_ORD_FEEDBACK_MAIN.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List bTables = fTable.elements("table");
		List column=null;//获取xml文件中的该表的列节点
		for(Iterator it  = bTables.iterator();it.hasNext();){
			Element table = (Element)it.next();
			if(table.attribute("name").getText().equals("DCL_ORD_FEEDBACK_DETAIL")){
				column = table.elements();
				hasTable=true;
				break;
			}else{
				hasTable=false;
			}
		}
		if(!hasTable){
			return null;
		}
		List columnName=new ArrayList();;
		List temp=new ArrayList();
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table = (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		temp.addAll(columnName);
		List<DclOrdFeedbackDetail> reList = new ArrayList<DclOrdFeedbackDetail>();
		DclOrdFeedbackDetail re=null;
		String select = "select * "
				+" from DCL_ORD_FEEDBACK_DETAIL t" 
				+" where t.FEEDBACK_MAIN_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, feedbackMainNo);
			rs = presl.executeQuery();
			while (rs.next())
			{
				
				re = new DclOrdFeedbackDetail();
				columnName.addAll(temp);
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = DclOrdFeedbackDetail.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				reList.add(re);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return reList;
	}


	/**
	 * 
	* <p>描述:布控反馈明细表信息</p>
	* @param feedbackMainNo
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	public List<DclOrdFeedbackDetail> getDclOrdFeedbackDetail2(String feedbackMainNo){
		StringBuilder sql=new StringBuilder();
		sql.append(" FROM DclOrdFeedbackDetailEntity t where  1=1 ");
		List<String> param=new ArrayList<String>();
		if(StringUtils.isNotEmpty(feedbackMainNo)){
			sql.append(" AND t.feedbackMainNo =?");
			param.add(feedbackMainNo);
		}

		List<DclOrdFeedbackDetailEntity> list=dao.getQueryList(sql.toString(), param.toArray());
		ArrayList<DclOrdFeedbackDetail> feedbackDetaillist=new ArrayList<DclOrdFeedbackDetail>();
		if(Utils.notEmpty(list)){
			for(DclOrdFeedbackDetailEntity entity:list){
				DclOrdFeedbackDetail feedbackDetailEntity=new DclOrdFeedbackDetail();
				try {
					BeanPropertyUtils.getInstance().copyPropertiesBean(feedbackDetailEntity, entity);
				} catch (Throwable e) {
					e.printStackTrace();
				}
				feedbackDetaillist.add(feedbackDetailEntity);
			}
		}
		return feedbackDetaillist;
	}
		
	/**
	* <p>描述:获取报检单检验检疫综合评定结果信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	 * @throws Exception 
	*/
	public InsResultEval getInsResultEval(String DECL_NO) throws Exception {
		String name=CommDao.class.getResource("/").getPath().toString();
		File xmlBodyFile = new File(name, "/mapconf/ITF_INS_RESULT_EVAL_B.xml");
		SAXReader saxReader = new SAXReader();
		boolean hasTable=true;
		Document xmlDoc = saxReader.read(xmlBodyFile);
		Element root = xmlDoc.getRootElement();
		Element fTable = root.element("table");
		List column=null;//获取xml文件中的该表的列节点
		column = fTable.elements("column");
		List columnName=new ArrayList();;
		if(com.rongji.dfish.base.Utils.notEmpty(column)){
			for(Iterator it  = column.iterator();it.hasNext();){
				Element table =  (Element)it.next();
				columnName.add(table.attribute("name").getText().toLowerCase());//获取xml中该列的列名称
			}
		}
		
		InsResultEval re=null;
		String select = "select * "
				+" from ins_result_eval t" 
				+" where t.DECL_NO=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		Connection conn = new DbUtils().getConnections("ECIQ_OPERATION");
		String cName = null;
		try
		{
			presl = conn.prepareStatement(select);
			presl.setString(1, DECL_NO);
			rs = presl.executeQuery();
			while (rs.next())
			{
				if(re==null){
				re = new InsResultEval();
				while (columnName.size() > 0) {
					cName = columnName.get(0).toString();
					columnName.remove(0);
					Field[] fields = InsResultEval.class
							.getDeclaredFields();
					for (Field f : fields) {
						if (f.getName().equalsIgnoreCase(cName.replaceAll("_", ""))) {
							f.set(re, rs.getObject(cName.toLowerCase()));
						}
					}
				}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(presl!=null){
					presl.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return re;
	}
	
	
	/**
	 * 
	* <p>描述:获取检验检疫综合评定结果信息</p>
	* @param DECL_NO
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	public InsResultEval getInsResultEval2(String declNo) {
		StringBuilder sql = new StringBuilder();
		sql.append(" FROM InsResultEvalEntity t where  1=1 ");
		List<String> param = new ArrayList<String>();
		if (StringUtils.isNotEmpty(declNo)) {
			sql.append(" AND t.declNo =? order by operTime desc");//获取最新一条
			param.add(declNo);
		}
		List<InsResultEvalEntity> list = dao.getQueryList(sql.toString(), param.toArray());
		if (Utils.notEmpty(list)) {
			InsResultEval resultEvalEntity = new InsResultEval();
			try {
				BeanPropertyUtils.getInstance().copyPropertiesBean(resultEvalEntity, list.get(0));
			} catch (Throwable e) {
				e.printStackTrace();
			}

			return resultEvalEntity;
		}
		return null;
	}
	
	
	
}

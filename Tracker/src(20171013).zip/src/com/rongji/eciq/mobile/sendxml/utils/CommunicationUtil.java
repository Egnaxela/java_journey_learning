/**  
 * FileName: CommunicationUtil.java    
 * @Description: 报文发送工具类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 上午11:30:47  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.utils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.codec.binary.Base64;

/**  
 * Description: 报文发送工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 上午11:30:47  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version  
 */

public class CommunicationUtil {

	/**
	* <p>描述:string to base64</p>
	* @param bytes
	* @param string
	* @return
	* @author 吴有根
	*/
	public static String base64(String src) throws Exception {
		byte[] b = src.getBytes("GBK");
		String s = new String(Base64.encodeBase64(b), "UTF-8");
		return s;
	}
	
	public static String base64(String src,String Encode) throws Exception {
		byte[] b = src.getBytes(Encode);
		String s = new String(Base64.encodeBase64(b),Encode);
		return s;
	}
	
	public static String base64(byte[] b,String Encode) throws Exception {
		String s = new String(Base64.encodeBase64(b),Encode);
		return s;
	}

	public static String base64ToString(String src) throws Exception {
		byte[] b = Base64.decodeBase64(src.getBytes("UTF-8"));
		String s = new String(b, "UTF-8");
		return s;
	}
	
	public static byte[] base64ToByte(String src) throws Exception {
		byte[] b = Base64.decodeBase64(src.getBytes("UTF-8"));
		return b;
	}
	
	public static byte[] base64ToByte(byte[] src) throws Exception {
		byte[] b = Base64.decodeBase64(src);
		return b;
	}
	
	public static String base64ToString(byte[] bytes,String Encode) throws Exception {
		byte[] b = Base64.decodeBase64(bytes);
		String s = new String(b, Encode);
		return s;
	}
	
	public static String base64ToStringByEncode(String src,String Encode) throws Exception {
		byte[] b = Base64.decodeBase64(src.getBytes(Encode));
		String s = new String(b, Encode);
		return s;
	}

	/**
	* <p>描述:发送组装好的byte[] 数组</p>
	* @param string
	* @param bs
	* @return
	* @author 吴有根
	 * @throws IOException 
	*/
	public static String getHttpContentAsByte(String url, byte[] postByte) throws IOException {
		if(postByte==null){
			return "报检号不存在";
		}
		URL u = new URL(url);
		HttpURLConnection conn = null;
		try {
			conn = (HttpURLConnection) u.openConnection();
			boolean postData = postByte != null;
			conn.setRequestMethod(postData ? "POST" : "GET");
			conn.setDoOutput(postData);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			if (postData) {
				DataOutputStream osw = new DataOutputStream(conn.getOutputStream());
				osw.write(postByte);
				osw.flush();
				osw.close();
			}
			InputStream is = conn.getInputStream();
			byte[] buff = new byte[8192];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int i = 0;
			while ((i = is.read(buff)) >= 0) {
				baos.write(buff, 0, i);
			}
			String resposeEncoding = conn.getContentEncoding();
			if (resposeEncoding == null)
				resposeEncoding = "UTF-8";
			return new String(baos.toByteArray(), resposeEncoding);

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}

}

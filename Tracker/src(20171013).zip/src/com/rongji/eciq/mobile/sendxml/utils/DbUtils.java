/**  
 * FileName:   DbUtils.java  
 * @Description: 数据库连接操作类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 下午12:00:04  
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.utils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

/**
 * 
 * Description: 数据库连接操作类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 下午12:00:04  
 *  
 * Modification History:  
 * Date            Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-04      吴有根                      1.0.0       1.0 Version
 * 2017-05-11      吴有根                      1.0.0       改用从配置文件获取数据源连接
 */
public class DbUtils {
	private static final Logger log = Logger.getLogger(DbUtils.class);



	/**
	 * e.message_body from esb_message_down t left join esb_message_down_blob e
	 * on t.blob_id=e.blob_id
	 * 
	 * @param conn
	 * @param id
	 * @return
	 * @throws Exception
	 * 
	 */
	public Object[] getMessageDownBlob(Connection conn, String id)
			throws Exception {
		Object[] obj = new Object[2];
		String select = "SELECT MESSAGE_HEAD,MESSAGE_BODY FROM esb_message_down_blob WHERE MESSAGE_UP_ID=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		try {
			presl = conn.prepareStatement(select);
			presl.setString(1, id);
			rs = presl.executeQuery();

			while (rs.next()) {
				String header = rs.getString("MESSAGE_HEAD");
				Blob body = (Blob) rs.getBlob("MESSAGE_BODY");
				obj[0] = header;
				obj[1] = body;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (presl != null) {
					presl.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return obj;
	}

	public Object[] getEntMessage(Connection conn, String id) throws Exception {
		Object[] obj = new Object[2];
		String select = "SELECT MESSAGE_HEAD,MESSAGE_BODY FROM esb_message_up_persistence WHERE MESSAGE_UP_ID=?";
		PreparedStatement presl = null;
		ResultSet rs = null;
		try {
			presl = conn.prepareStatement(select);
			presl.setString(1, id);
			rs = presl.executeQuery();

			while (rs.next()) {
				String header = rs.getString("MESSAGE_HEAD");
				Blob body = (Blob) rs.getBlob("MESSAGE_BODY");
				obj[0] = header;
				obj[1] = body;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (presl != null) {
					presl.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return obj;
	}

	public static String base64(String src, String Encode) throws Exception {
		byte[] b = src.getBytes(Encode);
		String s = new String(Base64.encodeBase64(b), Encode);
		return s;
	}

	public static String base64(byte[] b, String Encode) throws Exception {
		String s = new String(Base64.encodeBase64(b), Encode);
		return s;
	}

	public static String base64ToString(byte[] bytes, String Encode)
			throws Exception {
		byte[] b = Base64.decodeBase64(bytes);
		String s = new String(b, Encode);
		return s;
	}

	public static String base64ToStringByEncode(String src, String Encode)
			throws Exception {
		byte[] b = Base64.decodeBase64(src.getBytes(Encode));
		String s = new String(b, Encode);
		return s;
	}

	public static String base64ToString(String src) throws Exception {
		byte[] b = Base64.decodeBase64(src.getBytes("UTF-8"));
		String s = new String(b, "UTF-8");
		return s;
	}

	/**
	 * 
	 * <p>
	 * 描述:带http消息头的发送url返回数据
	 * </p>
	 * 
	 * @param url
	 * @param postContent
	 * @return
	 * @throws IOException
	 * @author YSY
	 */
	public static String getHttpContentAndHeadAsString(String url,
			String postContent, HttpHeadInfo httpHeadInfo) throws IOException {
		URL u = new URL(url);
		HttpURLConnection conn = null;
		try {
			conn = (HttpURLConnection) u.openConnection();
			conn.setRequestProperty("AUTH_NAME", httpHeadInfo.getAuthName());
			conn.setRequestProperty("AUTH_PWD", httpHeadInfo.getAuthPwd());
			conn.setRequestProperty("SENDER", httpHeadInfo.getSender());
			conn.setRequestProperty("CLIENT_ID", httpHeadInfo.getClientId());
			conn.setRequestProperty("REQUEST_TYPE",
					httpHeadInfo.getRequestType());
			conn.setRequestProperty("REQUEST_TIME",
					httpHeadInfo.getRequestDate());
			conn.setRequestProperty("TEMPLATE_VERSION",
					httpHeadInfo.getTemplateVersion());
			conn.setRequestProperty("REPORT_MD5", httpHeadInfo.getMd5());
			conn.setRequestProperty("APP_SIGN", httpHeadInfo.getBusinessApp());
			conn.setRequestProperty("EXT_VERIFY", httpHeadInfo.getExtVerify());

			boolean postData = postContent != null;
			conn.setRequestMethod(postData ? "POST" : "GET");
			conn.setDoOutput(postData);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			if (postData) {
				OutputStreamWriter osw = new OutputStreamWriter(
						conn.getOutputStream(), "ISO8859_1");
				osw.write(postContent);
				osw.flush();
				osw.close();
			}
			InputStream is = conn.getInputStream();
			byte[] buff = new byte[8192];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int i = 0;
			while ((i = is.read(buff)) >= 0) {
				baos.write(buff, 0, i);
			}
			String resposeEncoding = conn.getContentEncoding();
			if (resposeEncoding == null)
				resposeEncoding = "UTF-8";
			return new String(baos.toByteArray(), resposeEncoding);

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}

	/**
	 * [abstract]:格式化输出XML;<br>
	 * [Author]:RJ ZHL;<br>
	 * [DateTime]:2008-5-12;<br>
	 * [Parameter]:<br>
	 * [Return]:<br>
	 * [Remark]:调试用例.
	 */
	public static void loggerMsg(Document document) throws IOException {
		OutputFormat formater = OutputFormat.createPrettyPrint();
		// 设置xml的输出编码
		formater.setEncoding("utf-8");
		// 创建输出(目标)
		StringWriter out = new StringWriter();
		// 创建输出流
		XMLWriter writer = new XMLWriter(out, formater);
		// 输出格式化的串到目标中，执行后。格式化后的串保存在out中。
		writer.write(document);
		writer.close();
		log.info("\n" + out.toString());
	}

	/**
	 * 
	 * <p>
	 * 描述:发送byte数组
	 * </p>
	 * 
	 * @param url
	 * @param postContent
	 * @return
	 * @throws IOException
	 * @author YSY
	 */
	public static String getHttpContentAndHeadAsByte(String url,
			byte[] postByte, HttpHeadInfo httpHeadInfo) throws IOException {
		URL u = new URL(url);
		HttpURLConnection conn = null;
		try {
			conn = (HttpURLConnection) u.openConnection();
			conn.setRequestProperty("AUTH_NAME", httpHeadInfo.getAuthName());
			conn.setRequestProperty("AUTH_PWD", httpHeadInfo.getAuthPwd());
			conn.setRequestProperty("SENDER", httpHeadInfo.getSender());
			conn.setRequestProperty("CLIENT_ID", httpHeadInfo.getClientId());
			conn.setRequestProperty("REQUEST_TYPE",
					httpHeadInfo.getRequestType());
			conn.setRequestProperty("REQUEST_TIME",
					httpHeadInfo.getRequestDate());
			conn.setRequestProperty("TEMPLATE_VERSION",
					httpHeadInfo.getTemplateVersion());
			conn.setRequestProperty("REPORT_MD5", httpHeadInfo.getMd5());
			conn.setRequestProperty("APP_SIGN", httpHeadInfo.getBusinessApp());
			conn.setRequestProperty("EXT_VERIFY", httpHeadInfo.getExtVerify());

			conn.setRequestProperty("BLOCK_ID", httpHeadInfo.getFileBlockId());
			conn.setRequestProperty("FILE_ID", httpHeadInfo.getFileId());
			conn.setRequestProperty("BATCH_ID", httpHeadInfo.getBatchUuid());
			conn.setRequestProperty("BLOCK_MD5", httpHeadInfo.getFileBlockMd5());

			boolean postData = postByte != null;
			conn.setRequestMethod(postData ? "POST" : "GET");
			conn.setDoOutput(postData);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			if (postData) {
				DataOutputStream osw = new DataOutputStream(
						conn.getOutputStream());
				// osw.writeInt(postByte.length);
				osw.write(postByte);
				osw.flush();
				osw.close();
			}
			InputStream is = conn.getInputStream();
			byte[] buff = new byte[8192];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int i = 0;
			while ((i = is.read(buff)) >= 0) {
				baos.write(buff, 0, i);
			}
			String resposeEncoding = conn.getContentEncoding();
			if (resposeEncoding == null)
				resposeEncoding = "UTF-8";
			return new String(baos.toByteArray(), resposeEncoding);

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}

	/**
	 * 关闭数据库连接
	 */
	public void closeConnection(Connection conn) {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			log.error(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())
					+ "关闭数据库是异常.....", e);
			System.out.println("com.rongji.dfish.util.DBUtil 关闭数据库是异常.....");
		}
	}

	/**
	 * <p>
	 * 获得数据库链接
	 */
	public Connection getConnections(String type) {
		Connection conn = null;
		try {
			
			InputStream in=this.getClass().getClassLoader().getResourceAsStream("db-connect.properties");
			Properties props=new Properties();
			props.load(in);
			Map<String,String> dbMap=new HashMap<String,String>();
			dbMap.put("driverClass",props.getProperty("oracleApp.driverClass"));
			dbMap.put("url",props.getProperty("oracleApp.url"));
			dbMap.put("user",props.getProperty("oracleApp.user"));
			dbMap.put("password",props.getProperty("oracleApp.password"));
			
			
			Class.forName(dbMap.get("driverClass"));
			conn = DriverManager.getConnection(
						dbMap.get("url"),
						dbMap.get("user"), dbMap.get("password"));

			
//			// 加载驱动
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			if("ECIQ_INTERNAL".equals(type)){
//				conn = DriverManager.getConnection(
//						"jdbc:oracle:thin:@192.168.1.28:1521/orcl",
//						"ECIQ_INTERNAL", "ECIQ_INTERNAL");
//			}else if ("ECIQ_OPERATION".equals(type)) {
//				conn = DriverManager.getConnection(
//				"jdbc:oracle:thin:@192.168.1.28:1521/orcl",
//				"ECIQ_OPERATION", "ECIQ_OPERATION");
//			}else if("ECIQ_APP".equals(type)){
//				conn = DriverManager.getConnection(
//				"jdbc:oracle:thin:@192.168.1.28:1521/orcl",
//				"ECIQ_APP", "ECIQ_APP");
//			}

			System.out.println("获得连接："+conn);
		} catch (ClassNotFoundException e) {
			conn = null;
			System.out.println("未找到驱动文件.....");
			e.printStackTrace();
		} catch (Exception e) {
			conn = null;
			System.out
					.println("com.rongji.dfish.util.DBUtil.getConnection() 方法执行异常.....");
			e.printStackTrace();
		}
		return conn;
	}

	/**
	 * 
	 * @return 返回一个uuid字符串
	 * @author ji
	 */
	public static String getuuid() {
		String id = UUID.randomUUID().toString();
		return id.replaceAll("-", "").toUpperCase();
	}
	
	/**
	 * 
	* <p>描述:读取电子业务平台地址</p>
	* @return
	* @author 吴有根
	 */
	public static String getServerAddress(String type){
		
		try {
			Properties props=new Properties();
			props.load(DbUtils.class.getClassLoader().getResourceAsStream("db-connect.properties"));
			Map<String,String> dbMap=new HashMap<String,String>();
			dbMap.put("address",props.getProperty("address"));
			dbMap.put("host",props.getProperty("host"));
			if("address".equals(type)){
				return dbMap.get("address");
			}else if ("host".equals(type)) {
				return dbMap.get("host");
			}else {
				return type;
			}
		} catch (IOException e) {
			log.info("获取电子业务平台服务地址或CA认证地址失败");
			e.printStackTrace();
		}
		return "";
	}
}

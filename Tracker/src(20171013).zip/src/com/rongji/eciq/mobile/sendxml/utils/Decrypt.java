package com.rongji.eciq.mobile.sendxml.utils;

import java.io.FileInputStream;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;


public class Decrypt {
	
	public static void main(String[] args) throws Exception {
		String cerPath = "E:\\a.cer";
		String pfxPath = "E:\\a.pfx";
		test(cerPath,pfxPath);
	}

	private static void test(String cerPath, String pfxPath) throws Exception {
		String msg = "lfjsajdfljskfjksajf我萨芬吉萨联发科技萨拉肯德基弗兰克大fffffff撒 发萨芬了解萨拉附近a1232131321";
		byte[] bts = msg.getBytes("GBK");
		
		byte[] sha1 = DigestUtil.sha1(bts);
		
		X509Certificate cert = RSAUtil.readCert(new FileInputStream(cerPath));
		byte[] bs= RSAUtil.encryptByPublicKey(cert, sha1);
		String b64 = Base64.encodeBase64String(bs);
		System.out.println("加密后的值为："+b64);
		
		byte[] sha2 = DigestUtil.sha1(bts);
		
		PrivateKey prvk = RSAUtil.readPrivateKey(new FileInputStream(pfxPath),"111111");
		
		byte[] bt = RSAUtil.decryptByPrivateKey(prvk,
				Base64.decodeBase64(b64));
		if (!Arrays.equals(sha2, bt)) {
			System.out.println("认证失败....");
		}
		System.out.println("认证成功!");
	}

}

/**  
 * FileName: DigestUtil.java    
 * @Description: sha1与md5加密工具类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月13日 下午2:52:54  
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 
 * Description: sha1与md5加密工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月14日 上午10:56:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月14日      吴有根                      1.0         1.0 Version
 */
public class DigestUtil {
	public static byte[] sha1(byte[] data) {
		if ((data == null) || (data.length < 1)) {
			return null;
		}
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("系统不支持SHA-1算法", e);
		}
		digest.update(data);
		return digest.digest();
	}

	public static byte[] md5(byte[] bytes) {
		if ((bytes == null) || (bytes.length < 1)) {
			return null;
		}
		MessageDigest mdInst;
		try {
			mdInst = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
		mdInst.update(bytes);
		return mdInst.digest();
	}
}
/**  
 * FileName:   HttpHeadInfo.java  
 * @Description: http消息头设置类，主要设置一些头部信息
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 下午12:16:57    
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.utils;


/**
 * 
 * Description: http消息头设置类，主要设置一些头部信息  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 下午12:16:57  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version
 */
public class HttpHeadInfo {
	//认证方式 1—	易检账号/密码 2—	企业组织机构代码/密码

	private String authType;
    //用户名
	private String authName;
	//认证密码
	private String authPwd;
	//业务应用标识符 Decl -- 报检 Visa -- 签证 ES -- 监管
	private String businessApp;
	//通讯请求时间
	private String requestDate;
	//报文体的Md5码
	private String md5;
	//报文体数据格式 compress --压缩 uncompress --不压缩
	private String dataFormat;
	//终端标识符 如：计算机的机器码
	private String terminalSign;
	//请求类型 0–表示默认的RjEdi请求报文 1–表示文件传输请求
	//文件上传时：通讯请求类型 0–表示使用原始报文内容传输 ;1–表示报文上传模板;2–表示报文数查询模板;3–表示报文接收模板;4–表示报文删除模板;5–表示扩展通讯模板
	private String requestType;
	//以下字段为requestType=1的时候，必输
	//32位GUID 文件ID
	private String fileId;
	//32位GUID 文件块ID
	private String fileBlockId;
	//文件块MD5
	private String fileBlockMd5;
	//客户端mac地址
	private String clientMac;
	//客户端软件类型
	private String sourceApp;
	//远程请求的IP地址
	private String remoteIp;
	//浏览器信息
	private String UserAgent;
	//请求消息长度
	private String contentLength;
	//请求方法
	private String methods;
	
	
    //数据发送方 1-榕基软件 2-第三方
    private String sender;
    //客户端编号
    private String clientId;
    //通讯模板版本号
    private String templateVersion = "1.0";
    //扩展验证信息
    private String extVerify;
	//文件批ID
    private String batchUuid;
    
	
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getTemplateVersion() {
		return templateVersion;
	}
	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}
	public String getExtVerify() {
		return extVerify;
	}
	public void setExtVerify(String extVerify) {
		this.extVerify = extVerify;
	}
	/**
	 * @return the userAgent
	 */
	public String getUserAgent() {
		return UserAgent;
	}
	/**
	 * @param userAgent the userAgent to set
	 */
	public void setUserAgent(String userAgent) {
		UserAgent = userAgent;
	}
	/**
	 * @return the contentLength
	 */
	public String getContentLength() {
		return contentLength;
	}
	/**
	 * @param contentLength the contentLength to set
	 */
	public void setContentLength(String contentLength) {
		this.contentLength = contentLength;
	}
	/**
	 * @return the clientMac
	 */
	public String getClientMac() {
		return clientMac;
	}
	/**
	 * @param clientMac the clientMac to set
	 */
	public void setClientMac(String clientMac) {
		this.clientMac = clientMac;
	}
	public String getTerminalSign() {
		return terminalSign;
	}
	public void setTerminalSign(String terminalSign) {
		this.terminalSign = terminalSign;
	}
	public String getAuthName() {
		return authName;
	}
	public void setAuthName(String authName) {
		this.authName = authName;
	}
	public String getAuthPwd() {
		return authPwd;
	}
	public void setAuthPwd(String authPwd) {
		this.authPwd = authPwd;
	}
	public String getBusinessApp() {
		return businessApp;
	}
	public void setBusinessApp(String businessApp) {
		this.businessApp = businessApp;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getDataFormat() {
		return dataFormat;
	}
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}
	public String getSourceApp() {
		return sourceApp;
	}
	public void setSourceApp(String sourceApp) {
		this.sourceApp = sourceApp;
	}
	public String getMd5() {
		return md5;
	}
	public void setMd5(String md5) {
		this.md5 = md5;
	}
	public String getRemoteIp() {
		return remoteIp;
	}
	public void setRemoteIp(String remoteIp) {
		this.remoteIp = remoteIp;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileBlockId() {
		return fileBlockId;
	}
	public void setFileBlockId(String fileBlockId) {
		this.fileBlockId = fileBlockId;
	}
	public String getFileBlockMd5() {
		return fileBlockMd5;
	}
	public void setFileBlockMd5(String fileBlockMd5) {
		this.fileBlockMd5 = fileBlockMd5;
	}
	public String getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	public String getMethods() {
		return methods;
	}
	public void setMethods(String methods) {
		this.methods = methods;
	}
	public String getBatchUuid() {
		return batchUuid;
	}
	public void setBatchUuid(String batchUuid) {
		this.batchUuid = batchUuid;
	}
	
}

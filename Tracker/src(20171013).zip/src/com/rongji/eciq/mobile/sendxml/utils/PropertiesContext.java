/**  
 * FileName: PropertiesContext.java     
 * @Description: 报文发送地址配置定值类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月11日 下午2:32:17  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.utils;

/**  
 * Description: 报文发送地址配置定值类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月11日 下午2:32:17  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月11日      吴有根                      1.0         1.0 Version  
 */

public class PropertiesContext {
	
	/**
	 * 电子业务平台标志 【address】
	 */
	public static final String ADDRESS="address";

	/**
	 * CA认证标志【host】
	 */
	public static final String HOST="host";
    
	/**
	 * <ul>
	 * <li>电子业务平台地址</li> 
	 * <li>ELECTRONIC_BUSINESS_PLATFORM_SERVICE_ADDRESS</li>
	 * <li>com.rongji.system.entity.SysConfigEntity.description</li>
	 * </ul>
	 */
    public static final String EBPSA  ="电子业务平台服务地址";
	
	
    /**
     * <ul>
     * <li>CA认证平台地址</li>
     * <li>CA authentication platform address</li>
     * <li>com.rongji.system.entity.SysConfigEntity.description</li>
     * </ul>
     */
    public static final  String CAAPA ="CA认证平台地址";
	
	
    /**
     * <ul>CA认证用户
     * <li>com.rongji.system.entity.SysConfigEntity.description</li>
     * </ul>
     */
    public static final String CAUSERS="CA认证";
    
    /**
     * <ul>应用标识
     * <li>com.rongji.system.entity.SysConfigEntity.description</li>
     * </ul>
     */
    public static final String APPFLAG="appFlag";
    /**
     * <ul>应用标识
     * <li>com.rongji.system.entity.SysConfigEntity.description</li>
     * </ul>
     */
    public static final String APPFLAG_NAME="应用标识";

}

/**  
 * FileName: RSAUtil.java    
 * @Description: RSA加密工具类
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月13日 下午2:52:54  
 *  
 */ 

package com.rongji.eciq.mobile.sendxml.utils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import javax.crypto.Cipher;

/**
 * 
 * Description: RSA加密工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月14日 上午10:55:47  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月14日      吴有根                      1.0         1.0 Version
 */
public class RSAUtil {
	
	public static boolean valifySign(byte[] sign, byte[] msg, X509Certificate x509) throws Exception {
		PublicKey publicKey = x509.getPublicKey();
		Signature signature = Signature.getInstance(x509.getSigAlgName());
		signature.initVerify(publicKey);
		signature.update(msg);
		return signature.verify(sign);
	}

	public static X509Certificate readX509Cert(InputStream in, String certPassword) throws Exception {
		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(in, certPassword.toCharArray());
		Enumeration er = keyStore.aliases();
		if (er.hasMoreElements()) {
			String alia = (String) er.nextElement();
			X509Certificate cf = (X509Certificate) keyStore.getCertificate(alia);

			return cf;
		}
		return null;
	}

	public static PrivateKey readPrivateKey(InputStream is, String certPassword) throws Exception {
		KeyStore ks = KeyStore.getInstance("PKCS12");
		ks.load(is, certPassword.toCharArray());
		is.close();
		Enumeration enumas = ks.aliases();
		String keyAlias = null;
		if (enumas.hasMoreElements())
			keyAlias = (String) enumas.nextElement();
		else {
			return null;
		}
		PrivateKey prikey = (PrivateKey) ks.getKey(keyAlias, certPassword.toCharArray());
		return prikey;
	}

	public static byte[] encryptByPublicKey(X509Certificate cert, byte[] data) throws Exception {
		PublicKey publicKey = cert.getPublicKey();
		return crypt(data, publicKey, 1);
	}

	public static byte[] crypt(byte[] data, Key key, int opmode) throws Exception {
		if ((data == null) || (data.length < 1)) {
			return null;
		}
		int limitBlockSize = 2 == opmode ? 128 : 117;
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(opmode, key);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		for (int i = 0; i < data.length; i += limitBlockSize) {
			byte[] to = cipher.doFinal(data, i,
					data.length - i - limitBlockSize > 0 ? limitBlockSize : data.length - i);
			bos.write(to, 0, to.length);
		}
		return bos.toByteArray();
	}

	public static X509Certificate readCert(InputStream is) throws CertificateException {
		CertificateFactory certificatefactory = CertificateFactory.getInstance("X.509");
		X509Certificate cert = (X509Certificate) certificatefactory.generateCertificate(is);
		return cert;
	}

	public static byte[] decryptByPrivateKey(PrivateKey prvk, byte[] data) throws Exception {
		if ((prvk == null) || (data == null)) {
			return null;
		}
		return crypt(data, prvk, 2);
	}
}
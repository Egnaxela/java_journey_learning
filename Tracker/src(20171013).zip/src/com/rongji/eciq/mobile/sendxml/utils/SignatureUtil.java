/**  
 * FileName: SignatureUtil.java    
 * @Description: 获取对报文的签名证书  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月13日 下午2:50:54  
 *  
 */  

package com.rongji.eciq.mobile.sendxml.utils;

import java.io.FileInputStream;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;


/**  
 * Description: 获取对报文的签名证书  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月13日 下午2:50:54  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月13日      吴有根                      1.0         1.0 Version  
 */

public class SignatureUtil {

	private static final Logger log = Logger.getLogger(SignatureUtil.class);

	/**
	 * 
	* <p>描述:对<BIZ_BODY>报文体进行数字签名</p>
	* @param body
	* @return
	* @throws Exception
	* @author 吴有根
	 */
	public static String getSignInfo(String body) throws Exception {
		// 签名证书
		String cerPath = SignatureUtil.class.getResource("/").getPath().toString() + "signature/zj.cer";
		//String password = "111111";
		byte[] sha1=DigestUtil.sha1(body.getBytes("GBK"));
		X509Certificate cert=RSAUtil.readCert(new FileInputStream(cerPath));
		byte[] bs=RSAUtil.encryptByPublicKey(cert, sha1);
		String b64=Base64.encodeBase64String(bs);
		log.info("加密后的值"+b64);
		return b64;
	}

	
	public static byte[] sign(byte[] data, PrivateKey privateKey, X509Certificate cert) throws Exception {
		Signature signature = Signature.getInstance(cert.getSigAlgName());
		signature.initSign(privateKey);
		signature.update(data);
		return signature.sign();
	}
}

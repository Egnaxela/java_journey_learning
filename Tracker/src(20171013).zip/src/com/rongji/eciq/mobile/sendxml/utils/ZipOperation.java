/**  
 * FileName:   ZipOperation.java  
 * @Description: zip压缩文件通用类  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月4日 下午12:17:11  
 *  
 */ 
package com.rongji.eciq.mobile.sendxml.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;


/**
 * 
 * Description: zip压缩文件通用类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月4日 下午12:17:11  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月4日      吴有根                      1.0         1.0 Version
 */
public class ZipOperation {


	/**
	 * 压缩Zip
	 * 
	 * @param data
	 * @return
	 * @throws IOException 
	 */
	public static byte[] zip(byte[] data) throws IOException {
		byte[] b = null;
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ZipOutputStream zip = new ZipOutputStream(bos);
			ZipEntry entry = new ZipEntry("zip");
			entry.setSize(data.length);
			zip.putNextEntry(entry);
			zip.write(data);
			zip.closeEntry();
			zip.close();
			b = bos.toByteArray();
			bos.close();
		return b;
	}

	/***************************************************************************
	 * 解压byte数组类型的Zip
	 * 
	 * @param data
	 * @return
	 * @throws IOException 
	 */
	public static byte[] unZip(byte[] data) throws IOException {
		byte[] b = null;
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ZipInputStream zip = new ZipInputStream(bis);
		while (zip.getNextEntry() != null) {
			byte[] buf = new byte[8096];
			int num = -1;
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			while ((num = zip.read(buf, 0, buf.length)) != -1) {
				baos.write(buf, 0, num);
			}
			b = baos.toByteArray();
			baos.flush();
			baos.close();
		}
		zip.close();
		bis.close();
		return b;
	}

	/**
	 * 把字节数组转换成16进制字符串
	 * 
	 * @param bArray
	 * @return
	 */
	public static String bytesToHexString(byte[] bArray) {
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & bArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
		}
		return sb.toString();
	}

	public static void main(String[] args) throws Exception {
		String s = "123456789省";
		// byte[] b2 = unZip(b1);
		// System.out.println("unZip:" + new String(b2));
		// 压缩后base64
		byte[] bytes = ZipOperation.zip(s.getBytes("UTF-8"));
		String aaaa=CommunicationUtil.base64(bytes, "UTF-8");
		System.out.println("zip:" +aaaa );
		// 对bytes进行base64
		System.out.println("ddddd:" +CommunicationUtil.base64ToString(aaaa) );

		/*String ddd = new String(bytes, "GBK");
		System.out.println("压缩后:" + ddd);*/
		System.out.println("解压:" + new String(unZip(CommunicationUtil.base64ToByte(aaaa))));

		/*
		 * byte[] b3 = bZip2(s.getBytes()); System.out.println("bZip2:" +
		 * bytesToHexString(b3)); byte[] b4 = unBZip2(b3);
		 * System.out.println("unBZip2:" + new String(b4));
		 * 
		 * byte[] b5 = gZip(s.getBytes()); System.out.println("bZip2:" +
		 * bytesToHexString(b5)); byte[] b6 = unGZip(b5);
		 * System.out.println("unBZip2:" + new String(b6));
		 */

		/*
		 * byte[] b7 = jzlib(s.getBytes()); System.out.println("jzlib:" +
		 * bytesToHexString(b7)); byte[] b8 = unjzlib(b7);
		 * System.out.println("unjzlib:" + new String(b8));
		 */
	}
}

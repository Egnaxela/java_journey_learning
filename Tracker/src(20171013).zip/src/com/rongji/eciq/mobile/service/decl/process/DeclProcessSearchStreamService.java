package com.rongji.eciq.mobile.service.decl.process;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.dao.decl.process.DeclProcessSearchStreamDao;
import com.rongji.eciq.mobile.dao.decl.query.DeclInfoQueryDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;

/**
 * Description 流程查询-报检信息查询service
 * @author 		魏波
 * @version		1.0
 */
@Service
public class DeclProcessSearchStreamService {
	@Resource
	DeclProcessSearchStreamDao declProcessSearchStreamDao;
	
	/**
	 * 获取报检单主表信息
	 * @param expImpFlag
	 * @param declNo
	 * @return
	 */
	public List<DclIoDeclEntity> getSubAuditList(String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage,String beginDate,String endDate){
		return declProcessSearchStreamDao.getSubAuditList(exeInspOrgCode, receiverDocCode, declNo, declRegName, currentPage,beginDate,endDate);
	}
	
	 /**
	  * 工作流程查询下发库
	  * @param declNo
	  * @return
	  */
	 public List<SysProcessLogEntity> getSysProcessLog(String declNo){
		 return declProcessSearchStreamDao.getSysProcessLog(declNo);
	 }
}

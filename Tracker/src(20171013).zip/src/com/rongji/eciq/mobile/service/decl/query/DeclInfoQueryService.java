package com.rongji.eciq.mobile.service.decl.query;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.dao.decl.query.DeclInfoQueryDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;

/**
 * Description 综合查询-报检信息查询service
 * @author 		魏波
 * @version		1.0
 */
@Service
public class DeclInfoQueryService {
	@Resource
	DeclInfoQueryDao declInfoQueryDao;
	
	/**
	 * 获取报检单主表信息
	 * @param expImpFlag
	 * @param exeInspOrgCode
	 * @param receiverDocCode
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	public List<DclIoDeclEntity> getSubAuditList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage){
		return declInfoQueryDao.getSubAuditList(expImpFlag, exeInspOrgCode, receiverDocCode, declNo, declRegName, currentPage);
	}
}

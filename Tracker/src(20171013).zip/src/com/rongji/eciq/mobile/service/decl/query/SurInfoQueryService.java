/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-26 上午11:23:16  
 *  
 */  

package com.rongji.eciq.mobile.service.decl.query;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.dao.decl.query.SurInfoQueryDao;
import com.rongji.eciq.mobile.entity.OrdInfoSearchVo;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波
 * @version:    1.0  
 * Create at:   2017-5-26 上午11:23:16  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-26      魏波                     1.0         1.0 Version  
 */
@Service
public class SurInfoQueryService {
	@Resource
	SurInfoQueryDao surInfoQueryDao;
	
	/**
	 * 
	* <p>描述:查看布控信息dao</p>
	* @param declNo
	* @return
	* @author 魏波
	 */
	public List<OrdInfoSearchVo> getOrdInfoSearchVo(String declNo){
		return surInfoQueryDao.getOrdInfoSearchVo(declNo);
	}

}

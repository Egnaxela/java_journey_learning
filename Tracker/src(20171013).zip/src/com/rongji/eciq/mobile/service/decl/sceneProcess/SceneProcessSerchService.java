/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      魏波  
 * @version:     1.0
 * Createdate:   2017-5-9 上午10:52:21  
 *  
 */  

package com.rongji.eciq.mobile.service.decl.sceneProcess;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.dao.decl.sceneProcess.SceneProcessSerchDao;
import com.rongji.eciq.mobile.utils.CommonCodeToNameUtils;
import com.rongji.system.entity.SysAppProcessLog;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波
 * @version:    1.0  
 * Create at:   2017-5-9 上午10:52:21  
 */

@Service
public class SceneProcessSerchService {

	@Resource
	SceneProcessSerchDao dao;
	
	/**
	 * 
	* <p>描述:获取查验信息</p>
	* @param declNo
	* @param operCode
	* @param operDateBegin
	* @param operDateEnd
	* @param processStatus
	* @param processNode
	* @param currentPage
	* @return
	* @author 魏波
	 */
	public List<SysAppProcessLog> getList(String declNo,String operCode,String operDateBegin,String operDateEnd,
			String processStatus,String processNode, String currentPage,String exeInspOrgCode){
		return dao.getList(declNo, operCode, operDateBegin, operDateEnd, processStatus, processNode, currentPage,exeInspOrgCode);
	}
	
	/**
	 * 
	* <p>描述:保存查验流程日志</p>
	* @param log
	* @return
	* @author 魏波
	 */
	public void savelog(SysAppProcessLog log){
		dao.saveLog(log);
	}
	
	/**
	 * 
	 * <p>描述:更新查验流程日志</p>
	 * @param log
	 * @return
	 * @author 张锡森
	 */
	public void updateLog(SysAppProcessLog log){
		dao.updateLog(log);
	}
}

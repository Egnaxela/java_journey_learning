package com.rongji.eciq.mobile.service.insp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.rongji.eciq.mobile.dao.insp.ShowDeclInfoDao;
import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsPackEntity;
import com.rongji.eciq.mobile.entity.ZBbdHsCode;

/**
 * 查看报检单信息service
 * @author  吴有根
 * @version 1.0
 * Modification History:  
 * Date        Author     Version     Description  
 * ------------------------------------------------------------------  
 * 20170419    魏波                             1.0         根据货物条数查询货物信息
 * 20170607    魏波                             1.0         对hs编码表的查询
 * 2017-07-07  才江男                         1.0         判断是否需要选择拼箱标志
 */
@Service
public class ShowDeclInfoService {
	
	@Resource
	ShowDeclInfoDao showDeclInfoDao;

	/**
	 * 根据报检单号查询报检单基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclEntity> queryDclIoDeclList(String declNo, String expImpFlag) {
		return showDeclInfoDao.queryDclIoDeclList(declNo,expImpFlag);
	}

	/**
	 * 根据hs编码查hs实体
	 * @param hsCode
	 * @return
	 */
	public ZBbdHsCode queryZBbdHsCode(String hsCode){
		return showDeclInfoDao.queryZBbdHsCode(hsCode);
	}
	
	/**
	 * 根据报检号查询货物基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsList(String declNo, String expImpFlag,String currentPage) {
		return showDeclInfoDao.queryDclIoDeclGoodsList(declNo,expImpFlag,currentPage);
	}
	
	/**
	 * 根据报检号，货物条数查询货物基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @param size
	 * @return
	 */
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsListBySize(String declNo, String expImpFlag,String currentPage,String size) {
		return showDeclInfoDao.queryDclIoDeclGoodsListBySize(declNo,expImpFlag,currentPage,size);
	}

	/**
	 * 根据报检号查询集装箱基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<DclIoDeclContEntity> queryDclIoDeclContList(String declNo, String expImpFlag) {
		return showDeclInfoDao.queryDclIoDeclContList(declNo,expImpFlag);
	}
	
	/**
	* <p>描述:判断是否需要选择拼箱标志</p>
	* @param declNo
	*/
	public List<DclIoDeclContDetailEntity> isNeedLclFlag(String declNo, String contId) {
		if (StringUtils.isEmpty(declNo) || StringUtils.isEmpty(contId)) {
			return null;
		}
		return showDeclInfoDao.isNeesLclFlag(declNo, contId);
	}

	/**
	* <p>描述:查询全部货物信息</p>
	* @param declNo
	* @param expImpFlag
	* @return
	* @author 夏晨琳
	*/
	public List<DclIoDeclGoodsEntity> queryDclIoDeclGoodsList(String declNo, String expImpFlag) {
		return showDeclInfoDao.queryDclIoDeclGoodsList(declNo,expImpFlag);
	}

	/**
	* <p>描述:获取货物包装数量</p>
	* @param declNo
	* @param goodsNo
	* @author 夏晨琳
	 * @return 
	*/
	public DclIoDeclGoodsPackEntity getDclGoodsPackName(String declNo, String goodsNo) {
		return showDeclInfoDao.getDclGoodsPackName(declNo,goodsNo);
	}

}

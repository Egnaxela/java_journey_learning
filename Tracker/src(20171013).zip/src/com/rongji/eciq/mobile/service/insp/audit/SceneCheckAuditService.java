/**  
 * FileName: SceneCheckAuditService.java   
 * @Description:  施检员复审，科长审核，处长审核服务类
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-4-27 下午2:41:48  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.audit;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.dao.insp.audit.SceneCheckAuditDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.sendxml.service.DclOrdFeedBackMainHandel;
import com.rongji.eciq.mobile.sendxml.service.InsResultSumHandel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.scene.OrdProcessService;
import com.rongji.eciq.mobile.service.insp.scene.SceneCheckBackCommitService;
import com.rongji.eciq.mobile.service.insp.scene.SceneService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.MobileHelper;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.server.entity.InsDeclMag;
import com.rongji.eciq.server.entity.InsDeclReview;
import com.rongji.eciq.server.entity.InsDeclReviewSt;
import com.rongji.system.entity.SysAppProcessLog;


/**  
 * Description:   施检员复审，科长审核，处长审核服务类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-4-27 下午2:41:48  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-27    才江男                      1.0         1.0 Version  
 * 2017-05-04            才江男		1.0                             增加审核更新及查找审核记录      
 * 2017-05-11            才江男		1.0                             审核逻辑放到service
 * 2017-05-11            才江男		1.0                             判断是否为批量审核 
 * 2017-05-12            才江男		1.0                             更改审核不通过标志
 * 2017-05-13    才江男                     1.0          增加部门参数
 * 2017-05-15    李云龙                    1.0          增加审核环节流程日志
 * 2017-05-15    李云龙                         1。0         添加更新报检信息流程环节，流程状态
 * 2017-05-16    魏波                              1.0         审核查询添加出入境标示
 * 2017-05-22    才江男                     1.0          更新报检单流程状态及插入流程日志
 * 2017-05-26    才江男                     1.0          更新流程状态
 * 2017-05-27            才江男		1.0                               审核不通过   
 * 2017-06-16            才江男		1.0          1、该单子结果登记点击提交，如果选择走审核环节，则在处长审核通过之后回写数据，并调用自动调综合评定服务。
 *	2、如果该单子不走审核环节，在回写之前要先保存数据，校验是否满足综合评定条件，除满足送检外的其他的条件，则会回写，并调用综合评定服务。
 *  对需要送检的，数据回写，并直接显示在送检环节（移动端提示：该单进入主干系统送检环节），
 *	此处的提交相当于一个单独的综合评定按钮。与前面的批量综合评定对应。
 * 2017-07-11    才江男                      1.0          先回写评定信息，再回写查验信息
 * 2017-08-30    才江男                      1.0          记录报检单完成数量
 * 2017-09-12    才江男                      1.0          先回写再更新权限
 * 2017-09-20    才江男                       2.0          增加辅施检完成回写
 */
@Service
public class SceneCheckAuditService {

	@Resource
	SceneCheckAuditDao dao;
	@Autowired
	private SceneService sceneService;
	@Autowired
	private SubOrReasService reaService;
	@Resource
	SceneProcessSerchService processService;
	@Resource
	StatusControlUtils statusControlUtils;
	@Autowired(required = false)
	SubOrReasDao subOrReasDao;
	@Autowired
	InsResultSumHandel insResultSumHandel;
	
	@Autowired
	DclOrdFeedBackMainHandel dclOrdFeedBackMainHandel;
	
	@Autowired
	private OrdProcessService ordService;
	@Resource
	SceneCheckAuditDao checkAuditdao;
	@Autowired
	private SceneCheckBackCommitService evalService;
	
	/**
	 * 根据参数初始化查询现场查验table
	 * @param expImpFlag   	        出入境标志
	 * @param exeInspOrgCode   施检机构代码
	 * @return 现场查验数据
	 */
	public List<InsDeclMag> getMagList(String flag, String orgCode,String declNo,String currentPage,String expImpFlag) {
		return dao.getMagList(flag, orgCode, declNo, currentPage,expImpFlag);
	}
	
	/**
	* <p>描述: 获取审核记录</p>
	* @param declNo 报检单号
	* @return 审核记录
	* @author 才江男
	 */
	public List<InsDeclReviewSt> getAuditList(String declNo) {
		return dao.getAuditList(declNo);
	}
	
	/**
	* <p>描述: 保存审核记录</p>
	* @param review 审核记录
	* @author 才江男
	 */
	public void saveAudit(InsDeclReview review) {
		dao.saveAudit(review);
	}
	
	/**
	* <p>描述: 更新审核记录</p>
	* @param review 审核记录
	* @author 才江男
	 */
	public void updateAudit(InsDeclReview review, String batch, String processStatus) {
		dao.updateAudit(review);
		//更新审核留痕表
		updateAuditSt(review, batch, processStatus);
	}
	
	/**
	* <p>描述: 查找审核</p>
	* @param declNo 报检号
	* @return
	* @author 才江男
	 */
	public DataModel findAuditByDeclNo(String batch, HttpServletRequest request,HttpServletResponse response,String declNo, String flag, String advice, String userCode, String status, String orgCode, String picked, String appFlag) {
		List<String> list = null;
		DataModel back=MobileHelper.getBaseModel();
		List<SceneCheckInitTableModel> itemsList = null;
		SceneCheckInitTableModel item  = null;
		list = new ArrayList<String>();
//		if(declNo.length()==15) {
//			list.add(declNo);
//		} else {
		
		if(StringUtils.isNotEmpty(batch)){
			JSONArray itemsArray = JSONArray.fromObject(declNo);
			itemsList = (List<SceneCheckInitTableModel>)JSONArray.toList(itemsArray, SceneCheckInitTableModel.class);
			if(CollectionUtils.isNotEmpty(itemsList)) {
				for (SceneCheckInitTableModel sceneCheckInitTableModel : itemsList) {
					list.add(sceneCheckInitTableModel.getDeclNo());
				}
			} else {
				back.setMsg("未提供报检号");
				return back;
			}
		}else{
			if("mobile".equals(appFlag)) {
				JSONObject jsonItem = JSONObject.fromObject(declNo);
				item = (SceneCheckInitTableModel) JSONObject.toBean(jsonItem, SceneCheckInitTableModel.class);
				list.add(item.getDeclNo());
			} else {
				list.add(declNo);
			}
			
		}
		
//		}
		
		List<InsDeclReview> declReviewList = dao.findAuditByDeclNo(list);
		
		String msg = "";
		String flowPathStatusCode = "";
		String isRequire = "";
		if(CollectionUtils.isNotEmpty(declReviewList)) {
			SysUser sysUser=reaService.getSysUser(userCode);
			for (InsDeclReview declReview : declReviewList) {
				if(null == declReview) {
					msg += "审核记录不存在";
				} else if (CommContext.AUDIT_DONE.equals(declReview.getProcessStatus())) {
					msg += declReview.getDeclNo() + "审核完成";
				} else {
					
					//判断是否已审核过
					int processStatus = Integer.parseInt(declReview.getProcessStatus());
					int flagInt = Integer.parseInt(flag);
					if(processStatus > flagInt) {
						msg += declReview.getDeclNo() + "已审核";
					}
					
					declReview.setAuditAdvice(advice);
					if("1".equals(batch)) {
						if("1".equals(status)) {//审核通过
							declReview.setProcessStatus((Integer.parseInt(flag) + 1) + "");
						} else {//审核不通过
							declReview.setProcessStatus(CommContext.AUDIT_DONE);
						}
						if(CommContext.AUDIT_SECT.equals(flag) && "1".equals(status)) {
							declReview.setIsAudit("1");
						} else if(!"1".equals(status)) {
							declReview.setIsAudit("2");
						}
					} else {
						if("1".equals(status)) {//审核通过
							declReview.setIsAudit("1");
							if(StringUtils.isNotEmpty(picked)) {//并提交上级审核
								declReview.setProcessStatus(picked);
							} else {
								declReview.setProcessStatus(CommContext.AUDIT_DONE);
							}
						} else {
							declReview.setIsAudit("2");
							declReview.setProcessStatus(CommContext.AUDIT_DONE);
						}
					}
					
					declReview.setAuditCode(userCode);
					declReview.setAuditTime(new Date());
					updateAudit(declReview, batch, String.valueOf(processStatus));
					if(Utils.notEmpty(itemsList)){
						Iterator<SceneCheckInitTableModel> iterator = itemsList.iterator();
						while(iterator.hasNext()) {
							SceneCheckInitTableModel next = iterator.next();
							if(declReview.getDeclNo().equals(next.getDeclNo())) {
								flowPathStatusCode = next.getFlowPathStatusCode();
								isRequire = next.getInsRequire();
								sysUser.setUserCode(next.getReceiverDocCode());
								itemsList.remove(next);
								break;
							}
						}
					} else {
						if(null != item) {
							flowPathStatusCode = item.getFlowPathStatusCode();
							isRequire = item.getInsRequire();
							sysUser.setUserCode(item.getReceiverDocCode());
						}
					}
					msg += writeAuditLog(batch, picked, msg, request, response, flowPathStatusCode, isRequire, userCode, sysUser, declReview.getDeclNo(), flag, status);
					//处长审核通过
					if("3".equals(flag) && "1".equals(status)) {
//						sceneService.auditSendBack(declNo, userCode, orgCode);
					}
				}
			}
//			if(StringUtils.isNotEmpty(msg)) {
				back.setMsg(msg);
//			}
			
		} else {
			back.setMsg("存在异常审核");
		}
		
		return back;
	}
	
	/**
	* <p>描述: 更新报检单流程状态及流程日志</p>
	* @param userCode 人员代码
	* @param declNo 报检号
	* @param flag 审核标志
	* @author 才江男
	 */
	public String writeAuditLog(String batch, String picked, String msg, HttpServletRequest request, HttpServletResponse response, String flowPathStatus, String isRequire,String userCode, SysUser sysUser, String declNo, String flag, String status) {
		SysAppProcessLog log = new SysAppProcessLog();
		log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		log.setDeclNo(declNo);
		log.setOperCode(userCode);
		log.setOperName(sysUser.getUserName());
		log.setTreaOrgCode(sysUser.getOrgCode());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		Date newDate;
		try {
			newDate = formatter.parse(dateString);
			log.setOperDate(newDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!"1".equals(status)) {
			log.setProcessNode(MobileCommContext.SPOT);
			log.setNodeMemo(MobileCommContext.SPOT_NAME);
			log.setProcessStatus(MobileCommContext.AUDIT_FAIL);
			log.setStatusMemo(MobileCommContext.AUDIT_FAIL_NAME);
			dao.auditFail(declNo, userCode);
			statusControlUtils.updateProcess(declNo, MobileCommContext.SPOT, MobileCommContext.AUDIT_FAIL, userCode);
			processService.savelog(log);
			return "";
		}
		
		if ("1".equals(batch)) {
			if(flag.equals("1")){
				log.setProcessNode(MobileCommContext.INSP_AUDIT);
				log.setNodeMemo(MobileCommContext.INSP_AUDIT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_DEPT_AUDIT);
				log.setStatusMemo(MobileCommContext.WAIT_DEPT_AUDIT_NAME);
				statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_DEPT_AUDIT, userCode);
				processService.savelog(log);
			}else if(flag.equals("2")){
				log.setProcessNode(MobileCommContext.INSP_AUDIT);
				log.setNodeMemo(MobileCommContext.INSP_AUDIT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_SECT_AUDIT);
				log.setStatusMemo(MobileCommContext.WAIT_SECT_AUDIT_NAME);
				statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_SECT_AUDIT, userCode);
				processService.savelog(log);
			}else if(flag.equals("3")){
				msg = sendBackData(msg, request, response, declNo, flowPathStatus, isRequire, sysUser.getUserCode(), sysUser.getOrgCode());
				dao.registerEval(declNo, userCode);
			}
		} else {
			if(StringUtils.isEmpty(picked)) {
				msg = sendBackData(msg, request, response, declNo, flowPathStatus, isRequire, sysUser.getUserCode(), sysUser.getOrgCode());
				dao.registerEval(declNo, userCode);
			} else if(picked.equals("2")){
				log.setProcessNode(MobileCommContext.INSP_AUDIT);
				log.setNodeMemo(MobileCommContext.INSP_AUDIT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_DEPT_AUDIT);
				log.setStatusMemo(MobileCommContext.WAIT_DEPT_AUDIT_NAME);
				statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_DEPT_AUDIT, userCode);
				processService.savelog(log);
			}else if(picked.equals("3")){
				log.setProcessNode(MobileCommContext.INSP_AUDIT);
				log.setNodeMemo(MobileCommContext.INSP_AUDIT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_SECT_AUDIT);
				log.setStatusMemo(MobileCommContext.WAIT_SECT_AUDIT_NAME);
				statusControlUtils.updateProcess(declNo, MobileCommContext.INSP_AUDIT, MobileCommContext.WAIT_SECT_AUDIT, userCode);
				processService.savelog(log);
//			}else if(flag.equals("3")){
//				dao.registerEval(declNo, userCode);
//				msg = sendBackData(msg, request, response, declNo, flowPathStatus, isRequire, userCode, sysUser.getOrgCode());
			}
		}
		
		return msg;
	}
	
	/**
	* <p>描述: 结果登记-综合评定</p>
	* @param request
	* @param response
	* @param flowPathStatus 主辅检标志
	* @param isRequire 是否需送检
	* @param userCode 用户代码
	* @param orgCode 部门代码
	* @param declNo 报检号
	* @return
	* @author 才江男
	 */
	public DataModel registerEval(HttpServletRequest request, HttpServletResponse response, String flowPathStatus, String isRequire, String userCode, String orgCode, String declNo) {
		DataModel back=MobileHelper.getBaseModel();
		String msg = sendBackDataEval("", request, response, declNo, flowPathStatus, isRequire, userCode, orgCode);
		dao.registerEval(declNo, userCode);
		back.setMsg(msg);
		return back;
	}
	
	/**
	* <p>描述: 回写数据</p>
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param userCode 用户代码
	* @param orgCode 部门代码
	* @return 回写结果
	* @author 才江男
	 */
	public String sendBackDataEval(String msg, HttpServletRequest request,HttpServletResponse response,String declNo,String flowPathStatus, String isRequire,String userCode,String orgCode) {
		
		// 机构
		if(6 > orgCode.length()) {
			return "操作失败";
		}
		// 机构
		String businessOrgCode = orgCode.substring(0, 2) + "0000";
		
		//综合评定
		String evaled = evalService.isEvaled(declNo, flowPathStatus, isRequire);
		
		if("1".equals(evaled)) {
			//flag 2
			msg = evalService.evalCommit(request, declNo, userCode, orgCode, businessOrgCode, "2");
			sendSceneData(msg, request, response, declNo, flowPathStatus, isRequire, userCode, orgCode, businessOrgCode);
			//回写现场查验数据
		} else if ("0".equals(evaled) || "3".equals(evaled)) {
			evalService.writeEvalLog(declNo, userCode, MobileCommContext.EVALUATE, MobileCommContext.EVALUATE_NAME, MobileCommContext.SEND_DATA_BACK, MobileCommContext.SEND_DATA_BACK_NAME, MobileCommContext.EVALUATE_NAME);
		} else if ("2".equals(evaled)) {
			msg = "该单进入主干系统送检环节";
			evalService.writeEvalLog(declNo, userCode, MobileCommContext.SEND, MobileCommContext.SEND_NAME, MobileCommContext.SUBMIT, MobileCommContext.SUBMIT_NAME, MobileCommContext.SUBMIT_NAME);
		}
		
		if(!"1".equals(evaled)) {
			//回写现场查验数据
			sendSceneData(msg, request, response, declNo, flowPathStatus, isRequire, userCode, orgCode, businessOrgCode);
		}
		
		return msg;
	}
	
	private String sendSceneData(String msg, HttpServletRequest request,HttpServletResponse response,String declNo,String flowPathStatus, String isRequire,String userCode,String orgCode,String businessOrgCode) {
		// 现场查验
		String msgCheck = insResultSumHandel.getSendInsResultSum(request,
				response, declNo, flowPathStatus, userCode, orgCode,
				businessOrgCode);
		if (StringUtils.isNotEmpty(msgCheck)
				&& msgCheck.contains("<RESULT_DESC>")) {
			int indexStart = msgCheck.indexOf("<RESULT_DESC>");
			int indexEnd = msgCheck.indexOf("</RESULT_DESC>");
			msgCheck = msgCheck.substring(indexStart + 13, indexEnd);
		}

		// 布控反馈
		DclOrdFeedbackMainEntity backMain = ordService.getOrdFeedBackMain(declNo, "16");
		String msgFeedBack = "";
		if (null != backMain) {
			msgFeedBack = dclOrdFeedBackMainHandel.getSendDclOrdFeedBackMain(
					request, response, backMain.getFeedbackMainNo(),
					businessOrgCode);
			if (StringUtils.isNotEmpty(msgFeedBack)
					&& msgFeedBack.contains("<RESULT_DESC>")) {
				int indexStart = msgFeedBack.indexOf("<RESULT_DESC>");
				int indexEnd = msgFeedBack.indexOf("</RESULT_DESC>");
				msgFeedBack = msgFeedBack.substring(indexStart + 13, indexEnd);
			}
		}
		
		//查询最新主辅检标志
		String getflowPathStatusByDeclNo = sceneService.getflowPathStatusByDeclNo(declNo.substring(0,1), orgCode, userCode, declNo);
		
		if("802".equals(getflowPathStatusByDeclNo) || "辅施检完成".equals(getflowPathStatusByDeclNo)) {
			evalService.evalCommitFushijian(request, declNo, userCode, orgCode, businessOrgCode, "2");
		}

		// 拼接返回信息
		if (StringUtils.isNotEmpty(msgCheck)) {
			msg += msgCheck;
		}
		if (StringUtils.isNotEmpty(msgFeedBack)) {
			msg += msgFeedBack;
		}
		if (StringUtils.isNotEmpty(msg) && msg.contains("!")) {
			msg = msg.replaceAll("!", "");
		}
		if(msg.contains("成功")) {
			//记录报检单完成数量
			sceneService.recordCount(declNo, userCode, request, response);
		}
		
		return msg;
	}
	
	/**
	* <p>描述: 回写数据</p>
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param userCode 用户代码
	* @param orgCode 部门代码
	* @return 回写结果
	* @author 才江男
	 */
	public String sendBackData(String msg, HttpServletRequest request,HttpServletResponse response,String declNo,String flowPathStatus, String isRequire,String userCode,String orgCode) {
		
		// 机构
		if(6 > orgCode.length()) {
			return "操作失败";
		}
		// 机构
		String businessOrgCode = orgCode.substring(0, 2) + "0000";

		//综合评定
		String evaled = evalService.isEvaled(declNo, flowPathStatus, isRequire);
		if("1".equals(evaled)) {
			//flag 2
			evalService.evalCommit(request, declNo, userCode, orgCode, businessOrgCode, "2");
			/*// 现场查验
			insResultSumHandel.getSendInsResultSum(request,response,declNo,
					flowPathStatus, userCode, orgCode, businessOrgCode);

			// 布控反馈
			DclOrdFeedbackMainEntity backMain = ordService.getOrdFeedBackMain(declNo, "16");
			if (null != backMain) {
				dclOrdFeedBackMainHandel.getSendDclOrdFeedBackMain(
						request,response,backMain.getFeedbackMainNo(), businessOrgCode);
			}*/
			sendSceneData("", request, response, declNo, flowPathStatus, isRequire, userCode, orgCode, businessOrgCode);
		} else if ("0".equals(evaled)) {
			evalService.writeEvalLog(declNo, userCode, MobileCommContext.EVALUATE, MobileCommContext.EVALUATE_NAME, MobileCommContext.SEND_DATA_BACK, MobileCommContext.SEND_DATA_BACK_NAME, MobileCommContext.EVALUATE_NAME);
		} else if ("2".equals(evaled)) {
			msg = declNo + "进入主干系统送检环节";
			evalService.writeEvalLog(declNo, userCode, MobileCommContext.SEND, MobileCommContext.SEND_NAME, MobileCommContext.SUBMIT, MobileCommContext.SUBMIT_NAME, MobileCommContext.SUBMIT_NAME);
		}
		
		if(!"1".equals(evaled)) {
			sendSceneData("", request, response, declNo, flowPathStatus, isRequire, userCode, orgCode, businessOrgCode);
//			// 现场查验
//			insResultSumHandel.getSendInsResultSum(request,response,declNo,
//					flowPathStatus, userCode, orgCode, businessOrgCode);
//
//			// 布控反馈
//			DclOrdFeedbackMainEntity backMain = ordService.getOrdFeedBackMain(declNo, "16");
//			if (null != backMain) {
//				dclOrdFeedBackMainHandel.getSendDclOrdFeedBackMain(
//						request,response,backMain.getFeedbackMainNo(), businessOrgCode);
//			}
//			
//			//查询最新主辅检标志
//			String getflowPathStatusByDeclNo = sceneService.getflowPathStatusByDeclNo(declNo.substring(0,1), orgCode, userCode, declNo);
//			
//			if("802".equals(getflowPathStatusByDeclNo) || "辅施检完成".equals(getflowPathStatusByDeclNo)) {
//				evalService.evalCommitFushijian(request, declNo, userCode, orgCode, businessOrgCode, "2");
//			}
		}
		
		return msg;
	}
	
	/**
	* <p>描述: 更新审核留痕表</p>
	* @param review 审核表
	* @author 才江男
	 */
	public void updateAuditSt(InsDeclReview review, String batch, String processStatus) {
		InsDeclReviewSt st = new InsDeclReviewSt();
		try {
			PropertyUtils.copyProperties(st, review);
			st.setProcessStatus(processStatus); 
			st.setDeclReviewStId(UUIDKeyGeneratorUils.newInstance().generateKey());
			dao.saveAudit(st);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
	}

	/**
	* <p>描述: 查询审核记录</p>
	* @param declNo 报检单号
	* @return
	* @author 才江男
	*/
	public InsDeclReview findAuditByDeclNo(String declNo) {
		
		return dao.findAuditByDeclNo(declNo);
	}
}

/**  
 * FileName: CheckAppointmentService.java    
 * @Description: 查验预约service
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年6月27日 下午5:58:20  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.check;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.dao.insp.check.CheckAppointmentDao;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.InsCheckAppointInfoEntity;

/**  
 * Description: 查验预约service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年6月27日 下午5:58:20  
 *  
 * Modification History:  
 * Date          Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-06-27    吴有根                               1.0         1.0 Version
 * 2017-07-07    李云龙                               1.0         添加查询，更新，删除，撤销等方法
 * 2017-07-19    李云龙                               1.0         修改预约-查询
 * 2017-07-21    吴有根                               1.0         增加根据报检单位注册号带出企业基本信息
 *  
 */
@Service
public class CheckAppointmentService {

	@Autowired
	CheckAppointmentDao checkAppointmentDao;

	/**
	 * 
	 * <p>
	 * 描述:查询查验预约信息
	 * </p>
	 * 
	 * @return
	 * @author 李云龙
	 */
	public InsCheckAppointInfoEntity getInsCheckAppointInfoEntity(String applyId) {
		return checkAppointmentDao.getInsCheckAppointInfoEntity(applyId);
	}

	/**
	 * 
	 * <p>
	 * 描述:保存查验信息
	 * </p>
	 * 
	 * @param insCheckAppointInfoEntity
	 * @author 李云龙
	 */
	public void saveInsCheckAppointInfoEntity(InsCheckAppointInfoEntity insCheckAppointInfoEntity) {
		checkAppointmentDao.saveInsCheckAppointInfoEntity(insCheckAppointInfoEntity);
	}

	/**
	 * 
	 * <p>
	 * 描述:更新查验信息
	 * </p>
	 * 
	 * @param insCheckAppointInfoEntity
	 * @author 李云龙
	 */
	public void updateInsCheckAppointInfoEntity(String applyStatus, String declNo) {
		checkAppointmentDao.updateInsCheckAppointInfoEntity(applyStatus, declNo);
	}

	/**
	 * <p>
	 * 描述:查验预约-查询
	 * </p>
	 * 
	 * @param declNo
	 * @param declRegNo
	 * @param declRegName
	 * @param startApplyTime
	 * @param endApplyTime
	 * @param applyStatus
	 * @param acceptResult
	 * @return
	 * @author 吴有根
	 */
	public List<InsCheckAppointInfoEntity> getAppointInfo(String declNo, String declRegNo, String declRegName,
			String startTime,String endTime, String applyStatus, String acceptResult, String exeInspOrgCode,
			String type,String currentPage,String entOrgCode) {

		return checkAppointmentDao.getAppointInfo(declNo, declRegNo, declRegName, startTime, endTime,
				applyStatus, acceptResult, exeInspOrgCode,type, currentPage,entOrgCode);
	}
	
	/**
	 * 
	* <p>描述:获取申请单号</p>
	* @return
	* @author 李云龙
	 */
	public String getMaxApplyNo() {
		String applyNo = "";
		String right="000000";
		String maxApplyNo = checkAppointmentDao.getMaxApplyNo();
		if (StringUtils.isNotEmpty(maxApplyNo) ) {
			if (maxApplyNo.length() > 6) {
				maxApplyNo = maxApplyNo.substring(maxApplyNo.length() - 6,
						maxApplyNo.length());
			} else {
				maxApplyNo = right;
			}
		} else {
			maxApplyNo = right;
		}
		maxApplyNo=String.valueOf(Integer.parseInt(maxApplyNo)+1);
		if(maxApplyNo.length()>6){
			maxApplyNo=right;
		}else if(maxApplyNo.length()<6){
			maxApplyNo=right.substring(0, right.length()-maxApplyNo.length())+maxApplyNo;
		}

		Calendar now = Calendar.getInstance();
		String year = String.valueOf(now.get(Calendar.YEAR));
		String month = String.valueOf(now.get(Calendar.MONTH) + 1);
		if(month.length()==1){
			month="0"+month;
		}
		String day = String.valueOf(now.get(Calendar.DAY_OF_MONTH));
		if(day.length()==1){
			day="0"+day;
		}
		applyNo = applyNo + year + month + day + maxApplyNo;
		return applyNo;

	}
	
	/**
	 * 
	 * <p>
	 * 描述:提交查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void submitInsCheckAppointInfoEntity(String applyId) {
		checkAppointmentDao.submitInsCheckAppointInfoEntity(applyId);
	}
	
	
	/**
	 * 
	 * <p>
	 * 描述:撤销查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void cancelInsCheckAppointInfoEntity(String applyId) {
		checkAppointmentDao.cancelInsCheckAppointInfoEntity(applyId);
	}
	
	/**
	 * 
	 * <p>
	 * 描述:删除查验预约
	 * </p>
	 * 
	 * @param applyId 申请ID
	 * @author 李云龙
	 */
	public void deleteInsCheckAppointInfoEntity(String applyId) {
		checkAppointmentDao.deleteInsCheckAppointInfoEntity(applyId);
	}
	
	/**
	 * 
	 * <p>
	 * 描述:获取查验预约信息
	 * </p>
	 * 
	 * @return
	 * @author 李云龙
	 */
	public List<InsCheckAppointInfoEntity> getInsCheckAppointInfoEntityList(String declNo) {
		return checkAppointmentDao.getInsCheckAppointInfoEntityList(declNo);
	}

	
	/**
	 * 
	* <p>描述:</p>
	* @return
	* @author 李云龙
	 */
	public EntBaseInfoEntity getEntBaseInfoEntity(String declRegNo){
		return checkAppointmentDao.getEntBaseInfoEntity(declRegNo);
	}

	/**
	* <p>描述:根据报检单位注册号查询企业基本信息</p>
	* @param declRegNo
	* @return
	* @author 吴有根
	*/
	public EntBaseInfoEntity loadCheckAppointBaseInfo(String declRegNo,String declNo) {
		return checkAppointmentDao.loadCheckAppointBaseInfo(declRegNo,declNo);
	}

	
	/**
	* <p>描述:申请单号生成规则</p>
	* <p>组织机构代码+日期+序号
	* 可以直观看出企业某一天报了多少单子，便于统计
	* FIXME 后续若有新规则替换
	* </p>
	* @return
	* @author 吴有根
	*/
	public String getApplyNoRul(String entOrgCode) {
		String prefix=entOrgCode+new SimpleDateFormat("yyyyMMdd").format(new Date());
		String suffix="100000";
		List<String> list=checkAppointmentDao.getApplyNoRul(prefix);
		if(Utils.notEmpty(list)) {
			ArrayList<String> list2=new ArrayList<String>();
			list2.ensureCapacity(list.size());
			for (String str : list) {
				list2.add(str.substring(str.length()-6, str.length()));
			}
			Integer integer=Integer.valueOf(Collections.max(list2))+1;
			return prefix+integer.toString();
		}else {
			entOrgCode=prefix+suffix;
		}
		return entOrgCode;
	}
}

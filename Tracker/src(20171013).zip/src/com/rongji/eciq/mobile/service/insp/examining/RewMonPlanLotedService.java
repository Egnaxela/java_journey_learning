/**  
 * FileName: RewMonPlanLotedService.java   
 * @Description:  风险监控数据初始化service
 * Company       rongji
 * @version      1.0
 * @author:      魏波 
 * @version:     1.0
 * Createdate:   2017-4-27 下午2:41:48  
 *  
 */ 
package com.rongji.eciq.mobile.service.insp.examining;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.dao.insp.examining.RewMonPlanLotedDao;
import com.rongji.eciq.mobile.entity.RewMonPlanCycStatus;
import com.rongji.eciq.mobile.entity.RewMonPlanLotedVo;

/**
 * 
 * Description: 风险监控数据初始化service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     魏波 
 * @version:    1.0  
 * Create at:   2017-5-12 上午11:06:38  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      魏波                      1.0         1.0 Version
 */
@Service
public class RewMonPlanLotedService {

	@Resource
	RewMonPlanLotedDao dao;
	
	String REW_MO_TIME_N = "2";//[风险监控-执行次数是否作用到逐个企业-否]编码
	
	 /**
     * 取得报检命中的规划
     *
     * @param declNo 报检单
     * @param goodsNo 货物序号
     * @param entCode 企业组织机构代码（入境：收货人；出境：发货人）
     * @return 命中规划list
     */
	public List<RewMonPlanLotedVo> getLotedPlans(String declNo, String goodsNo, String entCode) {
		List<RewMonPlanLotedVo> list = dao.getRewMonPlanLotedModel(declNo,goodsNo);
		if (list == null) {
            return null;
        }
		for(RewMonPlanLotedVo model : list){
			List<RewMonPlanCycStatus> statusList;
			if(REW_MO_TIME_N.equals(model.getIsExeNumEffect())){
				statusList = dao.getRewStatusById(model.getMonPlanId(),null);
			}else{
				statusList = dao.getRewStatusById(model.getMonPlanId(),entCode);
			}
			if (statusList != null && !statusList.isEmpty()) {
                RewMonPlanCycStatus status = statusList.get(0);
                model.setExecutNms(Double.valueOf(""+status.getExecutedNums()).intValue());
            }
		}
		return list;
	}
}

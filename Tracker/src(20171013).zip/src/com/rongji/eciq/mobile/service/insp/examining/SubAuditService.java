/**  
 * FileName: SubAuditService.java   
 * @Description:  施检员审单table数据初始化service
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-27 下午2:41:48  
 *  
 */ 
package com.rongji.eciq.mobile.service.insp.examining;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.CommMsgContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.dao.decl.sceneProcess.SceneProcessSerchDao;
import com.rongji.eciq.mobile.dao.insp.examining.SubAuditDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.AuxInsProcessLogEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsReturnReasonEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysBusinessLockEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysReleaseRecordEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.utils.ProcessControlUtils;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.entity.SysAppProcessLog;


/**
 * 
 * Description: 施检员审单table数据初始化service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-12 上午11:07:54  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 20170411               李晨阳 		   1.0 		  新增功能-查询查验项目
 * 20170427    吴有根                             1.0      审单退单、分单退单操作 
 * 20170510    魏波                                 1.0       添加退单移动查验流程      
 * 20170512    魏波                                1.0       根据报检单号查第一条货物的名称
 */
@Service
public class SubAuditService {

	@Resource
	SubAuditDao subAuditDao;
	@Resource
	SceneProcessSerchDao dao;
	@Resource
	ProcessControlUtils processControlUtils;
	@Resource
	StatusControlUtils statusControlUtils;

	@Autowired(required = false)
	SubOrReasDao subOrReasDao;

	private final static Logger logger = Logger.getLogger(SubAuditService.class);

	/**
	 * 根据参数初始化查询施检员审单数据
	 * 
	 * @param expImpFlag
	 *            出入境标志
	 * @param exeInspOrgCode
	 *            施检机构
	 * @param receiverDocCode
	 *            接单员
	 * @param declNo
	 * @param declRegName
	 * @param currentPage
	 * @return
	 */
	public List<SubOrReasEntity> getSubAuditList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo, String declRegName, String currentPage) {
		return subAuditDao.getSubAuditList(expImpFlag, exeInspOrgCode, receiverDocCode, declNo, declRegName,
				currentPage);
	}

	/**
	 * 施检员审单-查验项目信息
	 * 
	 * @param declNo
	 * @param goodsNo
	 * @param type
	 * @return
	 */
	public List<InsCheckItemEntity> getInsCheckItemList(String declNo, String goodsNo, String type) {
		List<InsCheckItemEntity> list = subAuditDao.getInsCheckItemList(declNo, Integer.valueOf(goodsNo), type);
		if (!CollectionUtils.isEmpty(list)) {
			for (InsCheckItemEntity insCheckItemEntity : list) {
				insCheckItemEntity.setNodeCode(insCheckItemEntity.getNodeCode().toLowerCase());
				// insCheckItemEntity.setNodeCode(StringUtils.lowerCase(insCheckItemEntity.getNodeCode()));
				insCheckItemEntity.setParentItemCode(insCheckItemEntity.getParentItemCode().toLowerCase());
			}
		}
		return list;
	}

	/**
	 * <p>
	 * 描述:获取报检单管理表的基本信息
	 * </p>
	 * 
	 * @param declNo
	 * @return
	 * @author 吴有根
	 */
	public SubOrReasEntity getInsDeclMagByNo(String declNo, String flowPathStatus,String userOrgCode, String ... str) {
		return subAuditDao.getInsDeclMagByNo(declNo, flowPathStatus,userOrgCode, str);
	}

	/**
	 * <p>
	 * 描述:出入境审单-退单/分单改派单退单
	 * </p>
	 * 
	 * @param entity
	 * @param returnReason
	 * @param operType
	 * @return
	 * @author 吴有根
	 */
	public String chargeBack(SubOrReasEntity entity, String returnReason, String operType, String userCode) {
		// 报检单号
		String declNo;
		String workNo;
		// 管理记录id
		String declMagId;
		// 报检单环节
		String processLink;
		// 报检单状态
		String processStatus;
		// 主辅检状态
		String flowPathStatus;
		// 分单、审单退单实体
		InsReturnReasonEntity returnEntity;

		UserInfo user = new UserInfo();
		user.setUserCode(userCode);
		SysUser sysUser = subOrReasDao.getSysUser(userCode);
		if (sysUser != null) {
			user.setCompanyCode(sysUser.getOrgCode());
			user.setUserName(sysUser.getUserName());
		}

		HashMap<String, String> subBack = new HashMap<String, String>();
		subBack.put("SUB_PRIV", CommContext.N);
		HashMap<String, String> auditBack = new HashMap<String, String>();
		auditBack.put("SUB_PRIV", CommContext.Y);
		auditBack.put("AUDIT_PRIV", CommContext.N);
		auditBack.put("CHECK_PRIV", CommContext.N);
		auditBack.put("EVAL_PRIV", CommContext.N);
		//结果登记退单权限设置
		HashMap<String, String> regBack = new HashMap<String, String>();
		regBack.put("SUB_PRIV", CommContext.N);
		regBack.put("AUDIT_PRIV", CommContext.N);
		regBack.put("CHECK_PRIV", CommContext.Y);
		regBack.put("EVAL_PRIV", CommContext.N);
		regBack.put("REGI_PRIV", CommContext.N);
		regBack.put("RECEIVER_DOC_CODE", userCode);
		
		declNo = entity.getDeclNo();// 报检单号
		workNo = entity.getDeclWorkNo();// 工作流水号
		declMagId = entity.getDeclMagId();// 管理记录Id
		flowPathStatus = entity.getFlowPathStatus();// 流程状态
		// 判断是否锁单
		if (getLocked(declMagId, null)) {
			String msg = String.format(CommMsgContext.THIS_DECL_NO_LOCK_MSG, declNo, user.getUserName(),
					user.getCompanyCode(), "退单");
			return msg;
		}
		// 锁单
		comLock(declMagId, userCode, "");

		try {
			returnEntity = new InsReturnReasonEntity();
			returnEntity.setDeclNo(declNo);
			returnEntity.setOperTime(new Timestamp(System.currentTimeMillis()));
			returnEntity.setReturnReason(returnReason);
			returnEntity.setDocmtreturnCode(userCode);
			returnEntity.setFalgArchive(InsContext.SUP_ARCHIVE_N);
			returnEntity.setInspectorCode(entity.getReceiverDocCode());
			returnEntity.setExeInspOrgCode(entity.getExeInspOrgCode());
			returnEntity.setExcInspDeptCode(entity.getExcInspDeptCode());
			returnEntity.setReturnReasonId(UUIDKeyGeneratorUils.newInstance().generateKey());

			// 若为分单改派单-主施检退单
			if (StringUtils.equals(operType, InsContext.BACK_SUB_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_MAIN)) {
				// 退单类型
				returnEntity.setReturnType(InsContext.SUB_MAIN_BACK);

				// 记录报检受理退回日志
				recordDeclBackLog(declNo, user);

				// 核销证书回滚  暂不
				verifyDataRollBack(declNo);
				containerVerifyRollBack(declNo);

				//流程日志表
				processLink=CommContext.DECL;//审单受理
				processStatus=CommContext.INS_BACK;//施检退回		
				writeProcessLog(declNo,workNo,null,user,processLink,processStatus,null,"移动-由分单退回至报检受理");
				//移动端查验流程日志
				SysAppProcessLog log = new SysAppProcessLog();
				log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
				log.setDeclNo(declNo);
				log.setProcessNode(MobileCommContext.DECL);
				log.setNodeMemo(MobileCommContext.DECL_NAME);
				log.setProcessStatus(MobileCommContext.PUMP_GROUP_N);
				log.setStatusMemo(MobileCommContext.PUMP_GROUP_N_NAME);
				log.setOperCode(userCode);
				log.setOperName(user.getUserName());
				log.setTreaOrgCode(user.getCompanyCode());
				log.setRemark("移动-由分单退回至报检受理");
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(new Date());
				Date newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
				dao.saveLog(log);
				statusControlUtils.updateProcess(declNo,MobileCommContext.DECL,MobileCommContext.PUMP_GROUP_N,userCode);
				//分单权限
				subOrReasDao.updatePriv(declMagId, subBack);
				
				// 若为施检员审单-主施检退单
			} else if (StringUtils.equals(operType, InsContext.BACK_AUDIT_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_MAIN)) {
				//退单类型
				returnEntity.setReturnType(InsContext.AUDIT_MAIN_BACK);

				//清空接单员和分单标记
				subAuditDao.clearRecCodeById2(declMagId);

				subOrReasDao.updatePriv(declMagId, auditBack);

				processLink=CommContext.SUBMENU;//分单
				processStatus=CommContext.INS_CHECK_BACK;//审单退回	
				writeProcessLog(declNo,workNo,null,user,processLink,processStatus,null,"由施检审单退回至分单");
				//移动端查验流程日志
				SysAppProcessLog log = new SysAppProcessLog();
				log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
				log.setDeclNo(declNo);
				log.setProcessNode(MobileCommContext.SUBMENU);
				log.setNodeMemo(MobileCommContext.SUBMENU_NAME);
				log.setProcessStatus(MobileCommContext.INS_CHECK_N);
				log.setStatusMemo(MobileCommContext.INS_CHECK_N_NAME);
				log.setOperCode(userCode);
				log.setOperName(user.getUserName());
				log.setTreaOrgCode(user.getCompanyCode());
				log.setRemark("由施检审单退回至分单");
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(new Date());
				Date newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
				dao.saveLog(log);
				statusControlUtils.updateProcess(declNo,MobileCommContext.SUBMENU,MobileCommContext.INS_CHECK_N,userCode);
				// 若为结果登记退单-主施检
			}  else if (StringUtils.equals(operType, InsContext.BACK_REG_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_MAIN)) {
				//退单类型
				returnEntity.setReturnType(InsContext.REG_MAIN_BACK);
				//清空接单员和分单标记
				subAuditDao.clearRecCodeById2(declMagId);

				subOrReasDao.updatePriv(declMagId, regBack);

				processLink=CommContext.SPOT;//现场查验
				processStatus=CommContext.WAIT_CHECK;//待查验
				writeProcessLog(declNo,workNo,null,user,processLink,processStatus,null,"有结果登记退回现场查验");
				//移动端查验流程日志
				SysAppProcessLog log = new SysAppProcessLog();
				log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
				log.setDeclNo(declNo);
				log.setProcessNode(MobileCommContext.SPOT);
				log.setNodeMemo(MobileCommContext.SPOT_NAME);
				log.setProcessStatus(MobileCommContext.WAIT_CHECK);
				log.setStatusMemo(MobileCommContext.WAIT_CHECK_NAME);
				log.setOperCode(userCode);
				log.setOperName(user.getUserName());
				log.setTreaOrgCode(user.getCompanyCode());
				log.setRemark("有结果登记退回现场查验");
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(new Date());
				Date newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
				dao.saveLog(log);
				statusControlUtils.updateProcess(declNo,MobileCommContext.SPOT,MobileCommContext.WAIT_CHECK,userCode);
//				StatusControlUtils
				// 若为结果登记-辅施检退单
			}else if (StringUtils.equals(operType, InsContext.BACK_REG_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY)) {
				// 根据报检单管理表ID
				subAuditDao.clearRecCodeById2(declMagId);
				returnEntity.setReturnType(InsContext.REG_AUXILIARY_BACK);
				writeAuxLog(entity.getExeInspOrgCode(),entity.getExcInspDeptCode(),entity.getInspContCodes(),declMagId,declNo,CommContext.SUBMENU,CommContext.INS_CHECK_BACK,"辅施检施检员审单退至分单改派单",user);
				subOrReasDao.updatePriv(declMagId, regBack);
				// 若为施检员分单-辅施检退单
			}else if (StringUtils.equals(operType, InsContext.BACK_SUB_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY)) {
				subAuditDao.dltInsDelMagById(declMagId);
				List<InsDeclMagEntity> all = subAuditDao.findInsDeclMagByFlowType2(declNo);
				if (Utils.notEmpty(all) && all.size() == 1
						&& StringUtils.equals(InsContext.FLOW_PATH_STATUS_MAIN, all.get(0).getFlowPathStatus())) {
					subAuditDao.updateIsHaveAux(declNo, false);
				}
				returnEntity.setReturnType(InsContext.SUB_AUXILIARY_BACK);
				
				//辅施检流程日志
				processLink=CommContext.SUBMENU;//分单
				processStatus=entity.getProcessStatus();
				writeAuxLog(entity.getExeInspOrgCode(),entity.getExcInspDeptCode(),entity.getInspContCodes(),declMagId,declNo,CommContext.SUBMENU,processStatus,"辅施检分单退回至主施检",user);

				// 若为施检员审单-辅施检退单
			} else if (StringUtils.equals(operType, InsContext.BACK_AUDIT_TYPE)
					&& StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY)) {
				// 根据报检单管理表ID
				subAuditDao.clearRecCodeById2(declMagId);
				returnEntity.setReturnType(InsContext.AUDIT_AUXILIARY_BACK);
				writeAuxLog(entity.getExeInspOrgCode(),entity.getExcInspDeptCode(),entity.getInspContCodes(),declMagId,declNo,CommContext.SUBMENU,CommContext.INS_CHECK_BACK,"辅施检施检员审单退至分单改派单",user);
				subOrReasDao.updatePriv(declMagId, auditBack);
			}

			subOrReasDao.saveEntity(returnEntity, true);
			subAuditDao.updateBackReason(declMagId, returnReason);

		} catch (Exception e) {
		} finally {
			comUnLock(declMagId);
		}

		return null;
	}

	/**
	 * <p>
	 * 描述:
	 * </p>
	 * 
	 * @param declMagId
	 * @author 吴有根
	 */

	private void comUnLock(String uuid) {
		subOrReasDao.comUnLock(uuid);
	}

	/**
	 * <p>
	 * 描述:核销证书回滚
	 * </p>
	 * @param declNo
	 * @author 吴有根
	 */
	private void containerVerifyRollBack(String declNo) {
		
	}

	/**
	 * <p>
	 * 描述:核销证书回滚
	 * </p>
	 * 
	 * @param declNo
	 */
	private void verifyDataRollBack(String declNo) {

	}

	/**
	 * <p>
	 * 描述:记录报检受理退回日志
	 * </p>
	 * 
	 * @param declNo
	 * @param user
	 * @author 吴有根
	 */
	private void recordDeclBackLog(String declNo, UserInfo user) {
		String processType = InsContext.WORKPROC_TREAT_STATE_BACK;
		SysReleaseRecordEntity record = new SysReleaseRecordEntity();
		record.setDeclNo(declNo);
		record.setFalgArchive(CommContext.ARCHIVE_0);
		record.setTreatState(processType);
		record.setRecTime(new Timestamp(System.currentTimeMillis()));
		record.setOperState(InsContext.WORKPROC_OPER_STATE_N);
		record.setSysReleaseRecordNo(UUIDKeyGeneratorUils.newInstance().generateKey());
		record.setDeclAcceptPerson(user.getUserCode());
		record.setDeclAcceptDept(user.getCompanyCode());
		try {
			subOrReasDao.saveObject(record);
		} catch (Exception e) {
			logger.info("记录报检单流程日志出错,declNo:" + declNo + "处理方式:" + processType);
		}
	}

	/**
	 * <p>
	 * 描述:锁单
	 * </p>
	 * 
	 * @param declMagId
	 * @author 吴有根
	 */
	private void comLock(String declMagId, String userCode, String orgCode) {
		SysBusinessLockEntity entity = new SysBusinessLockEntity();
		entity.setOid(UUIDKeyGeneratorUils.newInstance().generateKey());
		entity.setKeyId(declMagId);
		entity.setUserId(userCode);
		entity.setOrgCode(orgCode);
		entity.setInsertTime(new Date());
		subOrReasDao.saveObject(entity);
	}

	/**
	 * <p>
	 * 描述:判断报检号是否被锁
	 * </p>
	 * 
	 * @param declMagId
	 * @param object
	 * @return
	 * @author 吴有根
	 */
	private boolean getLocked(String declMagId, String status) {
		boolean flag = false;
		List list = subOrReasDao.getLocked(declMagId, status);
		if (Utils.notEmpty(list)) {
			return true;
		}
		return flag;
	}

	/**
	 * 
	* <p>描述:记录辅施检流程日志</p>
	* @param exeInspOrgCode
	* @param excInspDeptCode
	* @param inspContCodes
	* @param insDclMagId
	* @param declNo
	* @param processLink
	* @param processStatus
	* @param remark
	* @param user
	* @author 吴有根
	 */
	public void writeAuxLog(String exeInspOrgCode, String excInspDeptCode, String inspContCodes, String insDclMagId, String declNo, String processLink, String processStatus, String remark, UserInfo user){
		AuxInsProcessLogEntity logEntity=new AuxInsProcessLogEntity();
		logEntity.setAuxInsProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		logEntity.setDeclMagId(insDclMagId);
		logEntity.setDeclNo(declNo);
		logEntity.setProcessNode(processLink);
		logEntity.setProcessStatus(processStatus);
        // 设定操作人代码
        String userName;
        String userCode;
        if (user == null || StringUtils.isEmpty(user.getUserCode())) {
            userCode = "auto";
        } else {
            userCode = user.getUserCode();
        }
        if (user == null || StringUtils.isEmpty(user.getUserName())) {
            userName = "系统";
        } else {
            userName = user.getUserName();
        }
		logEntity.setOperCode(userCode);
		logEntity.setOperName(userName);
		logEntity.setOperDate(new Date());
		logEntity.setFalgArchive(CommContext.ARCHIVE_0);
		logEntity.setRemark(remark);
		logEntity.setTreaOrgCode(user.getCompanyCode());
		logEntity.setExeInspOrgCode(exeInspOrgCode);
		logEntity.setExcInspDeptCode(excInspDeptCode);
		logEntity.setInspContCodes(inspContCodes);
		subOrReasDao.saveObject(logEntity);
	}
	/**
	* <p>描述:记录主施检流程日志</p>
	* @param declNo
	* @param workNo
	* @param object
	* @param user
	* @param processLink
	* @param processStatus
	* @param object2
	* @param string
	* @author 吴有根
	*/
	public void writeProcessLog(String declNo, String workNo, Object ruleEngineResultList, UserInfo user, String processLink,
			String processStatus, Object object2, String remark) {
		SysProcessLogEntity entity=new SysProcessLogEntity();
		entity.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		entity.setDeclNo(declNo);
		entity.setProcessNode(processLink);
		entity.setProcessStatus(processStatus);
		entity.setOperCode(user.getUserCode());
		entity.setOperName(user.getUserName());
		entity.setOperDate(new Date());
		entity.setFalgArchive(CommContext.ARCHIVE_0);
		entity.setTreaOperCode(user.getUserCode());
		entity.setTreaOperName(user.getUserName());
		entity.setTreaOrgCode(user.getCompanyCode());
		entity.setEndFlag("0");
		entity.setDeclWorkNo(declNo);
		entity.setRemark(remark);
		subOrReasDao.saveObject(entity);
	}
	/**
	 * 
	* <p>描述:更加报检单号查货物名</p>
	* @param declNo
	* @return
	* @author 魏波
	 */
	public String getGoodName(String declNo){
		return subAuditDao.getGoodName(declNo);
	}
	/**
	 * 根据报检号查验报检单结果基本信息
	 * @param declNo
	 * @return
	 */
	public List<DclIoDeclEntity> getDclIoDeclEntity(String declNo) {
		return subAuditDao.getDclIoDeclEntity(declNo);
	}
}

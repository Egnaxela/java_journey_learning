/**  
 * FileName:    ResultRegisterService.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      才江男  
 * @version:     1.0
 * Createdate:   2017-5-9 下午7:41:22  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.result;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.dao.insp.result.ResultRegisterDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.utils.DeclNoUtils;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     才江男  
 * @version:    1.0  
 * Create at:   2017-5-9 下午7:41:22  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-09      才江男                      1.0         1.0 Version 
 * 2017-5-22      才江男                      1.0         报检号短号变长号
 */
@Service
public class ResultRegisterService {

	@Resource
	ResultRegisterDao resultDao;
	@Resource
	private SubOrReasDao subOrReasDao;
	
	/**
	 * 根据参数初始化查询结果登记table
	 * @param expImpFlag   	        出入境标志
	 * @param exeInspOrgCode   施检机构代码
	 * @param receiverDocCode  接单员代码
	 * @param declNo		       报检单号
	 * @param declRegName      报检单位
	 * @return
	 */
	public List<SubOrReasEntity> getMagList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,String declNo,String declRegName,String currentPage) {
		declNo = shortToLong(declNo, expImpFlag, receiverDocCode);
		return resultDao.getMagList( expImpFlag,  exeInspOrgCode,  receiverDocCode, declNo, declRegName, currentPage);
	}
	
	/**
	* <p>描述: 报检号短号变长号</p>
	* @param declNo
	* @param expImpFlag
	* @param userCode
	* @return
	* @author 才江男
	 */
	private String shortToLong(String declNo, String expImpFlag, String userCode) {
		if (StringUtils.isNotEmpty(declNo)) {
			UserInfo user = new UserInfo();
			user.setUserCode(userCode);
			SysUser sysUser = subOrReasDao.getSysUser(userCode);
			if (sysUser != null) {
				user.setCompanyCode(sysUser.getOrgCode());
				user.setUserName(sysUser.getUserName());
			}
			String longDeclNo = "";
			if (expImpFlag.equals("1")) {
				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
						DeclContext.DECL_TYPE_IN, user);
			} else if (expImpFlag.equals("2")) {
				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
						DeclContext.DECL_TYPE_OUT, user);
			}
			declNo = longDeclNo;
		}
		return declNo;
	}
}

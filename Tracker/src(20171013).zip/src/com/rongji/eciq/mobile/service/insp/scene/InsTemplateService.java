/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-10 下午3:22:57  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.scene;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Page;
import com.rongji.eciq.mobile.dao.insp.scene.InsTemplateDao;
import com.rongji.eciq.mobile.entity.InsDeptDefTemplate;
import com.rongji.eciq.mobile.entity.InsTemplate;
import com.rongji.eciq.mobile.entity.InsTemplateSub;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-10 下午3:22:57  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-10      夏晨琳                      1.0         1.0 Version  
 */
@Service
public class InsTemplateService {
	
	@Autowired
	private InsTemplateDao templateDao;

	/**
	* <p>描述:查询模板集合</p>
	* @param orgCode
	* @param expImpFlag
	* @param templateType
	* @author 夏晨琳
	 * @param page 
	 * @param templateTitle 
	*/
	public List<InsTemplate> searchCheckTempListByUser(String expImpFlag, String templateType, Page page, String templateTitle) {
		return  templateDao.searchCheckTempListByUser(expImpFlag,templateType,page,templateTitle);
	}

	/**
	* <p>描述:模板维护查询集合</p>
	* @param templateTitle
	* @param whetherEffect
	* @param orgCodes
	* @return
	* @author 夏晨琳
	 * @param page 
	*/
	public List<InsTemplate> searchCheckTempList(String templateTitle, String whetherEffect, String orgCodes, Page page) {
		return  templateDao.searchCheckTempList(templateTitle,whetherEffect,orgCodes,page);
	}

	/**
	* <p>描述:获取模板对象</p>
	* @param templateId
	* @return
	* @author 夏晨琳
	*/
	public InsTemplate getInsTemplate(String templateId) {
		return templateDao.getInsTemplate(templateId);
	}

	/**
	* <p>描述:模板删除</p>
	* @param templateId
	* @return
	* @author 夏晨琳
	*/
	public boolean  deleteInsTemplate(String templateId) {
		try {
			templateDao.deleteInsTemplate(templateId);
			return false;
		} catch (Exception e) {
		}
		return true;
	}

	/**
	* <p>描述:删除子模板信息</p>
	* @param templateId
	* @author 夏晨琳
	*/
	public boolean deleteSubTemplate(String templateId) {
		try {
			templateDao.deleteSubTemplate(templateId);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	* <p>描述:获取子模板集合</p>
	* @param templateId
	* @return
	* @author 夏晨琳
	*/
	public List<InsTemplateSub> getInsTemplateSubList(String templateId) {
		return templateDao.getInsTemplateSubList(templateId);
	}

	/**
	* <p>描述:保存或者更新模板类</p>
	* @param template
	* @param boo
	* @author 夏晨琳
	*/
	public void saveOrUpdateTemp(InsTemplate template, boolean boo) {
		templateDao.saveOrUpdateTemp(template,boo);
	}

	/**
	* <p>描述:删除模板对应的部门信息</p>
	* @param templateId
	* @author 夏晨琳
	*/
	public void deleteDefTemplate(String templateId) {
		templateDao.deleteDefTemplate(templateId);
	}

	/**
	* <p>描述:查询部门是否存在默认</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	*/
	public List<InsDeptDefTemplate> getDefTemplateEntity(String orgCode) {
		return templateDao.getDefTemplateEntity(orgCode);
	}

	/**
	* <p>描述:更新默认模板</p>
	* @param def
	* @author 夏晨琳
	*/
	public void updateDefTempleate(InsDeptDefTemplate def) {
		templateDao.updateDefTempleate(def);
	}

	/**
	* <p>描述:保存默认模板</p>
	* @param def
	* @author 夏晨琳
	*/
	public void saveDefTemplate(InsDeptDefTemplate def) {
		templateDao.saveDefTemplate(def);
	}

	/**
	* <p>描述:保存子模板信息</p>
	* @param sub
	* @author 夏晨琳
	*/
	public void saveTemplateSub(InsTemplateSub sub) {
		templateDao.saveDefTemplateSub(sub);
	}

}

/**  
 * FileName:OrdProcessService.java     
 * @Description: 布控处理service  
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午11:28:46  
 *  
 */ 
package com.rongji.eciq.mobile.service.insp.scene;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.rongji.eciq.mobile.dao.insp.scene.OrdProcessDao;
import com.rongji.eciq.mobile.entity.DclOrdBackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdBackMainEntity;
import com.rongji.eciq.mobile.entity.DclOrdDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackDetailEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.OrdBackMainVo;
import com.rongji.eciq.mobile.entity.OrdFeedbackDetailVo;
import com.rongji.eciq.mobile.entity.SysSwitchOrg;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.insp.OrdBackVo;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * 
 * Description: 布控处理service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-2 下午4:32:55  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-2      李云龙                      1.0         添加根据布控反馈编号查询布控反馈详细信息方法
 */
@Service
public class OrdProcessService {
	@Resource
	OrdProcessDao ordProcessDao;
	@Autowired
	CompanyCodeUtils companyCodeUtils;
	
	/**
     * 根据报检单号和反馈环节指令查询布控反馈信息
     * @param declNo 报检单号
     * @param feedbackLink  反馈环节指令
     * @return DclOrdFeedbackMainEntity 布控反馈主信息
     */
    public DclOrdFeedbackMainEntity getOrdFeedBackMain(String deptCode,String fedbackPersn,String declNo, String feedbackLink,String currentPage){
    	return ordProcessDao.getOrdFeedBackMain(deptCode, fedbackPersn, declNo, feedbackLink, currentPage);
    }
    
    /**
    * 根据布控反馈编号查询布控反馈详细信息
    * @param feedbackMainNo 反馈主编号【UUID】
    * @return List<DclOrdFeedbackDetailEntity> 布控反馈相信信息
    */
   public List<OrdFeedbackDetailVo> getFeedbackDetailListByMainNo(String feedbackMainNo){
	   return ordProcessDao.getFeedbackDetailListByMainNo(feedbackMainNo);
   }
   
   /**
    * 根据布控反馈编号查询布控反馈详细信息
    * @param feedbackMainNo 反馈主编号【UUID】
    * @return List<DclOrdFeedbackDetailEntity> 布控反馈相信信息
    */
   public List<OrdFeedbackDetailVo> getFeedbackDetailListBydeclNo(String declNo,String linkNo){
	   return ordProcessDao.getFeedbackDetailListBydeclNo(declNo,linkNo);
   }

   /**
    * 根据报检单号查询报检单的布控信息
    * @param declNo 报检单号
    * @return 
    */
   public List<DclOrdDetailEntity> getOrdDetailInfo(String declNo,String currentPage){
	   return ordProcessDao.getOrdDetailInfo(declNo, currentPage);
   }
   
   /**
    * 根据报检单号查询审单环节之前的的布控信息
    * @param declNo 报检单号
    * @return 
    */
   public List<DclOrdDetailEntity> getOrdDetailInfoAudit(String declNo,String currentPage){
	   return ordProcessDao.getOrdDetailInfoAudit(declNo, currentPage);
   }
   
   /**
    * 根据应用和报检单号以及处理的环节号,查询布控回退信息
    * @param declNo     报检单号
    * @param arrivLink  处理的环节号
    * @param arriveApp  处理的应用
    * @return  List<OrdBackMainVo> 
    */
   public List<OrdBackMainVo> getOrdDetail(String declNo, String arrivLink, String arriveApp){
	   return ordProcessDao.getOrdDetail(declNo, arrivLink, arriveApp);
	   
   }
   
   /**
    * 布控反馈 暂存
    * @param dclOrdFeedbackMainEntity 布控反馈主信息
    * @param detailList 布控反馈详细信息
    */
   public void updateFeedbackInfo(DclOrdFeedbackMainEntity dclOrdFeedbackMainEntity,List<DclOrdFeedbackDetailEntity> detailList,String orgCode,String fedbackPersn){
        if(dclOrdFeedbackMainEntity != null ){
            dclOrdFeedbackMainEntity.setOperTime(new Date());
             if(StringUtils.isEmpty(dclOrdFeedbackMainEntity.getFeedbackMainNo()) ){
                   dclOrdFeedbackMainEntity.setFeedbackMainNo(UUIDKeyGeneratorUils.newInstance().generateKey());
               }
               if(orgCode!= null ){
                   if(orgCode.length()>6){
                       orgCode = orgCode.substring(0,6);
                   }
               }
               dclOrdFeedbackMainEntity.setFeedbackOrg(orgCode);
               dclOrdFeedbackMainEntity.setFeedbackTime(new Date());
               dclOrdFeedbackMainEntity.setFedbackPersn(fedbackPersn);
               //保存或修改布控反馈主表信息
               ordProcessDao.updateFeedbackMainInfo(dclOrdFeedbackMainEntity);
               DclOrdFeedbackDetailEntity dclOrdFeedbackDetailEntity = null ;
               if(CollectionUtils.isNotEmpty(detailList)){
                   for(int i =0 ; i < detailList.size() ; i++){
                       dclOrdFeedbackDetailEntity = detailList.get(i);
                       dclOrdFeedbackDetailEntity.setFeedbackMainNo(dclOrdFeedbackMainEntity.getFeedbackMainNo());
                   }
               }
               //保存或修改布控反馈详细信息
               ordProcessDao.updateFeedbackDetailInfo(detailList);
        }
   }
   
   /**
    * 布控回退暂存
    * @param dclOrdBackMainEntity 布控回退主信息
    * @param ordBackMainList 布控回退详细信息
    * @param jpaService 
    */
   public void ordBackSave(DclOrdBackMainEntity dclOrdBackMainEntity ,List<OrdBackVo> ordBackMainList){
       if(dclOrdBackMainEntity != null ){
           //删除选中的布控回退详细信息
           if(CollectionUtils.isNotEmpty(ordBackMainList)){
               for(OrdBackVo vo : ordBackMainList){
                   //删除选中的回退明细信息
            	   ordProcessDao.delBackDetail(vo.getOrdBackInfoNo());
               }
           }
           //}
           //删除布控回退主表信息
           ordProcessDao.deleteOrdBackMain(dclOrdBackMainEntity.getDeclNo(), dclOrdBackMainEntity.getBackLink());    
           //保存布控回退主表信息
           if(StringUtils.isEmpty(dclOrdBackMainEntity.getBackMainNo())){
        	   dclOrdBackMainEntity.setBackMainNo(UUIDKeyGeneratorUils.newInstance().generateKey());
           }else{
        	   dclOrdBackMainEntity.setBackMainNo(dclOrdBackMainEntity.getBackMainNo());
           }
           
           dclOrdBackMainEntity.setOrdBackInfoNo(dclOrdBackMainEntity.getOrdBackInfoNo());
           ordProcessDao.saveOrdBackMain(dclOrdBackMainEntity);
           
           OrdBackVo ordBackMainVo ;
           DclOrdBackDetailEntity dclOrdBackDetailEntity ;
           if(CollectionUtils.isNotEmpty(ordBackMainList)){
               for(int i =0 ;i < ordBackMainList.size(); i ++){
                   ordBackMainVo = ordBackMainList.get(i);
                   ordBackMainVo.setBackMainNo(dclOrdBackMainEntity.getBackMainNo());
                   if(StringUtils.isEmpty(ordBackMainVo.getOrdBackInfoNo())){
                       ordBackMainVo.setOrdBackInfoNo(UUIDKeyGeneratorUils.newInstance().generateKey());
                   }
                   ordBackMainVo.setBackType("1");
                   ordBackMainVo.setDeclNo(dclOrdBackMainEntity.getDeclNo());
                   ordBackMainVo.setArrivLink(dclOrdBackMainEntity.getBackLink());
                   dclOrdBackDetailEntity = new DclOrdBackDetailEntity();
                   //循环获取界面获取的VO数据 转换成布控回退详细信息实体
                   try {
						PropertyUtils.copyProperties(dclOrdBackDetailEntity, ordBackMainVo);
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}
                   //保存布控回退详细信息
                   ordProcessDao.saveOrdBackDetail(dclOrdBackDetailEntity);
               }
           }
       }
   }
   
   /**
    * 初始化布控回退主信息
    * @param declNo 报检单号
    * @param backLink 回退环节号
    * @param jpaService
    * @return DclOrdBackMainEntity 布控回退主信息
    */
   public DclOrdBackMainEntity initOrdBackMain(String declNo,String backLink,String orgCode,String backPerson){
        return ordProcessDao.initOrdBackMain(declNo, backLink, orgCode, backPerson);
   }
   


   /**
    * 获取开关值（追溯上级的方式）
    *
    * @param switchId 开关名称，例如：SwitchContext.DISCHARGE
    * @param orgCode 机构代码
    * @return 开关值，true-开，false-关
    */
   public boolean getSwitchResultByUp(String switchId, String orgCode) {
       // 获取当前机构的所有上级代码
       Map<Integer, String> orgMap = companyCodeUtils.getOrgCode(orgCode);
       if(orgMap.isEmpty()){
           return false;
       }
       Iterator<Integer> iterator = orgMap.keySet().iterator();
       String newOrgCode;
       
       SysSwitchOrg entity;

       // 工作点办事处
       String orgCodeStr = orgMap.get(companyCodeUtils.ORG_LEVEL_3);
       if (StringUtils.isNotEmpty(orgCodeStr)) {
           entity = ordProcessDao.getSwitchOpenByOrgCodeAndId(switchId, orgCodeStr);
           if (null != entity) {
               // 只要遇到开关打开的情况就返回
               return entity.getSwitchValue().equals("1");
           }
       }

       // 分支局
       orgCodeStr = orgMap.get(companyCodeUtils.ORG_LEVEL_2);
       if (StringUtils.isNotEmpty(orgCodeStr)) {
           entity = ordProcessDao.getSwitchOpenByOrgCodeAndId(switchId, orgCodeStr);
           if (null != entity) {
               // 只要遇到开关打开的情况就返回
               return entity.getSwitchValue().equals("1");
           }
       }

       // 直属局
       orgCodeStr = orgMap.get(companyCodeUtils.ORG_LEVEL_1);
       if (StringUtils.isNotEmpty(orgCodeStr)) {
           entity = ordProcessDao.getSwitchOpenByOrgCodeAndId(switchId, orgCodeStr);
           if (null != entity) {
               // 只要遇到开关打开的情况就返回
               return entity.getSwitchValue().equals("1");
           }
       }

       // 国家局
       orgCodeStr = orgMap.get(companyCodeUtils.ORG_LEVEL_0);
       
       if (StringUtils.isNotEmpty(orgCodeStr)) {
           entity = ordProcessDao.getSwitchOpenByOrgCodeAndId(switchId, orgCodeStr);
           if (null != entity) {
               // 只要遇到开关打开的情况就返回
               return entity.getSwitchValue().equals("1");
           }
       }
       return false;
   }
   
   /**
    * 根据 布控环节指令和报检单号查询布控信息是否存在
    * @param declNo 报检单号
    * @param linkNo 环节指令号
    * @return 
    */
   public boolean getOrdMain(String declNo,String linkNo){
	   return ordProcessDao.getOrdMain(declNo, linkNo);
   }
   
   /**
    * 根据报检单号和回退环节编号查询回退主信息
    * @param declNo 报检单号
    * @param backLink 回退环节编码
    * @return DclOrdBackMainEntity 布控回退主信息
    */
    public DclOrdBackMainEntity getOrdBackMain(String declNo,String backLink){
    	return ordProcessDao.getOrdBackMain(declNo,backLink);
    }
    
    /**
     * 根据报检单号和回退环节编号查询回退主信息
     * @param declNo 报检单号
     * @param backLink 回退环节编码
     * @return DclOrdBackMainEntity 布控回退主信息
     */
     public DclOrdFeedbackMainEntity getOrdFeedBackMain(String declNo,String backLink){
     	return ordProcessDao.getOrdFeedBackMain(declNo,backLink);
     }
   
   
}

/**  
 * FileName:     SceneCheckBackCommitService.java
 * @Description: 现场查验数据提交等service  
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月17日 下午4:57:23  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.scene;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclevalConstants;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.InsMsgContext;
import com.rongji.eciq.mobile.context.ManagementContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.context.SceneContext;
import com.rongji.eciq.mobile.context.SwitchContext;
import com.rongji.eciq.mobile.dao.insp.scene.SceneCheckBackCommitDao;
import com.rongji.eciq.mobile.dao.insp.scene.SceneDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DeclLogicVo;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsContainerResultEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsResultEvalEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.insp.scene.SceneCheckInitTableModel;
import com.rongji.eciq.mobile.model.insp.scene.ShowMessageModel;
import com.rongji.eciq.mobile.sendxml.bean.InsResultEval;
import com.rongji.eciq.mobile.sendxml.service.InsResultEvalHandel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.BeanPropertyUtils;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.ProcessControlUtils;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.system.entity.SysAppProcessLog;

/**  
 * Description: 现场查验数据提交等service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月17日 下午4:57:23  
 *  
 * Modification History:  
 * Date            Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-04-17      吴有根                             1.0         1.0 Version  
 * 2017-05-15      魏波                                  1。0         现场查验退单添加流程日志
 * 2017-05-15      李云龙                              1。0         添加更新报检信息流程环节，流程状态
 * 2017-05-26      才江男                               1.0         综合评定
 * 2017-05-26      才江男                               1.0         更新报检单权限
 * 2017-05-26      才江男                               1.0         更新流程日志
 * 2017-05-26      魏波                                   1.0         修改现场查验退单流程环节
 * 2017-05-27      才江男                               1.0         增加评定环节
 * 2017-05-27      才江男                               1.0         综合评定增加数据回写
 * 2017-06-01      才江男                               1.0         增加数据回写标志
 * 2017-06-01      李云龙                              1.0         根据主辅施检更新现场查验-退单流程
 * 2017-06-02      才江男                               1.0         数据回写标志
 * 2017-06-05      才江男                               1.0         数据回写改为直属局
 * 2017-06-05      吴有根                               1.0         增加综合评定判断条件
 * 2017-06-05      才江男                               1.0         增加判断是否满足综合评定条件
 * 2017-06-06      才江男                               1.0         修改评定返回的信息校验
 * 2017-06-16      才江男                               1.0         增加对外调用的综合评定接口
 * 2017-06-23      才江男                               1.0         需送检，有一个货物有抽样量就可以送检
 * 2017-09-20      才江男                               2.0         增加辅施检完成回写
 */

@Service
public class SceneCheckBackCommitService {
	
	@Resource
	SceneCheckBackCommitDao sceneCheckBackCommitDao;
	
	@Resource
	ProcessControlUtils processControlUtils;
	@Resource
	StatusControlUtils statusControlUtils;
	
	@Resource
	SceneProcessSerchService processService;
	
	@Autowired(required=false)
	SceneDao sceneDao;
	
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	@Autowired
	InsResultEvalHandel insResultEvalHandel;
	@Autowired
	CompanyCodeUtils companyCodeUtils;
	@Autowired
	private SubOrReasService subOrReasService;
	@Autowired
	private SceneService sceneService;
	

	/**
	* <p>描述:现场查验打开页面的逻辑判断</p>
	* @param declNo
	* @param procedureCode
	* @return
	* @author 吴有根
	*/
	public Map<String, Object> getLoginUserPermission(String declNo, String flag,String userCode,String orgCode) {
		Map<String, Object> limtsMap=new HashMap<String, Object>();
		
		String receiverDocCode=userCode;
		String inspOrgCode=orgCode;
        //主辅施捡流程状态
        String flowPathStatusFlag = null;
        //弹出的工作内容提示
        String workContent = null;
        //辅施检内容类别代码串
        String inspCountCodes = null;
        //获得主施检记录
        InsDeclMagEntity insDeclMagEntity=sceneCheckBackCommitDao.findMainInsMag(declNo,InsContext.FLOW_PATH_STATUS_MAIN,inspOrgCode);
        if(insDeclMagEntity!=null){
        	flowPathStatusFlag=InsContext.FLOW_PATH_STATUS_MAIN;
        	List<InsDeclMagEntity> insDeclMagEntityList=sceneCheckBackCommitDao.queryInsDeclMagStatus(declNo,InsContext.FLOW_PATH_STATUS_AUXILIARY,true);
        	//拼接施检内容类别代码串   暂不
        	//inspCountCodes=spellString(insDeclMagEntityList,declNo,receiverDocCode);
        	
        } else {//查找辅施捡(此时登录的用户是辅施捡人员)
            //设定局部位置 上的流程状态
            flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_AUXILIARY;
            //辅施检权限
            insDeclMagEntity = sceneCheckBackCommitDao.getjudgeLoginDeptIsChecked(declNo, inspOrgCode, flowPathStatusFlag);
            if (insDeclMagEntity == null) {
                flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE;
                insDeclMagEntity = sceneCheckBackCommitDao.getjudgeLoginDeptIsChecked(declNo, inspOrgCode, flowPathStatusFlag);
            }
            String receiver = insDeclMagEntity == null ? "" : insDeclMagEntity.getReceiverDocCode();
        }
        limtsMap.put(SceneContext.INSP_COUNT_CODE, workContent);
        limtsMap.put(SceneContext.INS_DECL_MAG, insDeclMagEntity);
        limtsMap.put(SceneContext.FLOW_PATH_STATUS_MAIN, flowPathStatusFlag);
        return limtsMap;
	}


	/**
	* <p>描述:根据报检单号查询检验检疫结果表</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public InsResultSumEntity getInsResultSumEntityByNo(String declNo,String userCode) {
		List<InsResultSumEntity> sumlist=sceneDao.getInsResultSumList(declNo, CommContext.IN_FLAG);
		InsResultSumEntity insResultSumEntity=Utils.notEmpty(sumlist)?sumlist.get(0):null;
		if(insResultSumEntity!=null){
			String checkSite=insResultSumEntity.getCheckPlace();//查验地点
			if(StringUtils.isEmpty(checkSite)){
				//查验地点  根据报检单号查询审单发送查验指令的查验场
				List<String> list=sceneCheckBackCommitDao.getInsCheckCommandEntityList(declNo);
				StringBuilder stringBuffer=null;
				if(Utils.notEmpty(list)){
					stringBuffer=new StringBuilder();
					int size=list.size();
                    for (int x = 0; x < size; x++) {
                        String checkSiteName = list.get(x);
                        if (x == size - 1) {
                            stringBuffer.append(checkSiteName);
                        } else {
                            stringBuffer.append(checkSiteName).append(",");
                        }
                    }
                } else {
                    //如果查看场为空,就默认取报检单上边的存放地点
                    DclIoDeclEntity dclIoDeclEntity = sceneCheckBackCommitDao.queryInsResultMark(declNo);
                    if (dclIoDeclEntity != null) {
                        insResultSumEntity.setCheckPlace(dclIoDeclEntity.getGoodsPlace());
                    }

                }
                if (stringBuffer != null) {
                    insResultSumEntity.setCheckPlace(stringBuffer.toString());
                }
            }
            if (StringUtils.isEmpty(insResultSumEntity.getChecker())) {
                //设置默认查验人员
                insResultSumEntity.setChecker(userCode);
            }
            if (StringUtils.isEmpty(insResultSumEntity.getKepIsolat())) {
                insResultSumEntity.setKepIsolat(CommContext.N);
            }
            if (StringUtils.isEmpty(insResultSumEntity.getWhether2ndIns())) {
                insResultSumEntity.setWhether2ndIns(CommContext.N);
            }
            if (insResultSumEntity.getInsBeginDate() == null) {
                //设置默认查验日期
                insResultSumEntity.setInsBeginDate(new Timestamp(System.currentTimeMillis()));
            }
            if (insResultSumEntity.getInspEndDate() == null) {
                //设置默认检毕日期
                insResultSumEntity.setInspEndDate(new Timestamp(System.currentTimeMillis()));
            }
            if (StringUtils.isEmpty(insResultSumEntity.getInspBasCatCode())) {
                insResultSumEntity.setInspBasCatCode("11");//TODO　国际标准
            }

        }
        return insResultSumEntity;
	}


	/**
	* <p>描述:根据报检单号查询报检的基本信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public DclIoDeclEntity queryDclIoDeclByNo(String declNo) {
		return sceneDao.getIoEntDeclNo(declNo);
	}


	/**
	* <p>描述:获得综合评定和送检校验信息</p>
	* @param declNo 报检号
	* @param insResultGoodsVOs  施检结果
	* @param flowPathStatusFlag 主辅检流程状态
	* @param historySign	历史查询标记
	* @param dclIoDeclVO  报检信息
	* @param orgCode   机构
	* @param sendContext  判断是送检还是综合评定
	* @param perProcessStatus 当前环节
	* @return
	* @author 吴有根
	*/
	public String getSendAndEvalMessage(String declNo, List<InsResultGoodsEntity> insResultGoodsVOs,
			String flowPathStatusFlag, String historySign, DclIoDeclEntity dclIoDeclVO, String orgCode,
			String sendContext, String perProcessStatus) {

		if (StringUtils.equals(CommContext.SEND, sendContext)) {
			// 判断当前货物列表是否有检验要求为需送检的单子
//			boolean sendFlag = true;
//			BigDecimal actSmplNum = BigDecimal.ZERO;
//			if (Utils.notEmpty(insResultGoodsVOs)) {
//				int goodsSize = insResultGoodsVOs.size();// 货物条数
//				int addCount = 0;
//				for (InsResultGoodsEntity insResultGoodsVO : insResultGoodsVOs) {
//					if (StringUtils.equals(historySign, InsContext.HISTORY_SIGN)) {
//						InsResultGoodsEntity resultGoodsVO = sceneHistoryService
//								.queryInsResultGoodsVOByDeclNoAndGoodsNo(declNo, insResultGoodsVO.getGoodsNo());
//						if (resultGoodsVO != null && (insResultGoodsVO.getActSmplNum() == null
//								|| resultGoodsVO.getActSmplNum().doubleValue() <= 0)) {
//							// 抽样量为空，不校验
//							addCount++;
//							continue;
//						}
//						if (resultGoodsVO != null && StringUtils.equals(InsContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE,
//								insResultGoodsVO.getInspRequire())) {
//
//							sendFlag = false;
//							// 校验实际抽样量
//							String message = judgeActSmpNum(resultGoodsVO, true);
//							if (StringUtils.isNotEmpty(message)) {
//								return message;
//							}
//							if (resultGoodsVO.getActSmplNum().doubleValue() <= 0) {
//								return "实际抽样量必须大于0！";
//							}
//						} else {
//							if (resultGoodsVO.getActSmplNum() != null) {
//								actSmplNum = actSmplNum.add(resultGoodsVO.getActSmplNum());
//							}
//							String message = judgeActSmpNum(resultGoodsVO, false);
//							if (StringUtils.isNotEmpty(message)) {
//								return message;
//							}
//						}
//					} else {
//						InsResultGoodsEntity resultGoodsVO = sceneService.queryInsResultGoodsVOByDeclNoAndGoodsNo(declNo,
//								insResultGoodsVO.getGoodsNo());
//						if (resultGoodsVO != null && (insResultGoodsVO.getActSmplNum() == null
//								|| resultGoodsVO.getActSmplNum().doubleValue() <= 0)) {
//							// 抽样量为空，不校验
//							addCount++;
//							continue;
//						}
//						if (resultGoodsVO != null && StringUtils.equals(InsContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE,
//								insResultGoodsVO.getInspRequire())) {
//							sendFlag = false;
//							// 校验实际抽样量
//
//							String message = judgeActSmpNum(resultGoodsVO, true);
//							if (StringUtils.isNotEmpty(message)) {
//								return message;
//							}
//							if (resultGoodsVO.getActSmplNum().doubleValue() <= 0) {
//								return "【" + resultGoodsVO.getGoodsNameCn() + "】该条货物实际抽样量必须大于0！";
//							}
//						} else {
//							if (resultGoodsVO.getActSmplNum() != null) {
//								actSmplNum = actSmplNum.add(resultGoodsVO.getActSmplNum());
//							}
//							String message = judgeActSmpNum(resultGoodsVO, false);
//							if (StringUtils.isNotEmpty(message)) {
//								return message;
//							}
//						}
//					}
//				}
//				if (goodsSize == addCount) {
//					// 所有货物均没有送检
//					return "实际抽样量不能<=0！";
//				}
//			}
//
//			// 如果sendFlag 为true的话 说明当前报检单下的货物
//			// 没有检验要求为需送检的,那么就要校验所有货物的实际抽样量总和是不是大于0
//			if (sendFlag && (actSmplNum == null || actSmplNum.doubleValue() <= 0)) {
//				return "该报检单下的所有货物的实际抽样量总和必须大于0！";
//			}

		}

		// 验证布控开关是否打开
		boolean b = sceneCheckBackCommitDao.judgeSwitchResule(SwitchContext.INS_ORDER, orgCode);
		// 等待布控开关的判断
		if (b) {// 布控开关为打开状态
			boolean booB = sceneCheckBackCommitDao.getOrdFeedbackDetailList(declNo, CommContext.SPOT);
			if (booB) {
				return InsMsgContext.INSPECTION_PROCESS_LOCK;// "报检单流程被锁定,请填写相关布控信息或等待布控信息";
			}
		}

		return null;
	}


	/**
	* <p>描述:判断是否存在不合格的查验项目</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean isCheckItemFail(String declNo) {
		List<InsCheckItemEntity> insCheckItemList=sceneCheckBackCommitDao.getInsCheckItemList(declNo, 0);
		if(Utils.notEmpty(insCheckItemList)){
			for(InsCheckItemEntity entity:insCheckItemList){
				if(StringUtils.equals(entity.getWhetherQualfy(), InsContext.INS_N)){//是否合格
					return true;
				}
			}
		}
		return false;
	}


	/**
	* <p>描述:判断报检货物是否存在检验或检疫结果不合格</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean isGoodsResultFail(String declNo) {
		List<InsResultGoodsEntity> insResultGoodsList=sceneCheckBackCommitDao.getInsResultGoodsList(declNo);
		if(Utils.notEmpty(insResultGoodsList)){
			for(InsResultGoodsEntity entity:insResultGoodsList){ //现场查验检验结果    现场查验检疫结果
				if(StringUtils.equals(entity.getInspResSpot(), DeclevalConstants.INSP_QUAR_RESULT_INSP_FAIL)
						||StringUtils.equals(entity.getQuarResSpot(), DeclevalConstants.INSP_QUAR_RESULT_QUAR_FAIL)){
					return true;
				}
			}
		}
		return false;
	}


	/**
	* <p>描述:获取报检单实体</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public DclIoDeclEntity queryDclIoDeclByDeclNo(String declNo) {
		return sceneDao.getIoEntDeclNo(declNo);
	}


	/**
	*************************** 
	* <p>描述:施检综合评定方法</p>
	* @param declNo
	* @param declWorkNo
	* @param checkEvaluateType
	* @param processStatus
	* @param processLink
	* @return
	* @author 吴有根
	*/
	public Map<String, Object> synthesizeEvaluate(String declNo, String workNo, String oprType, String currentState,
			String currentLink) {
		Map<String, Object> map=new HashMap<String, Object>();
		//校验是否可以执行综合评定
		map=isSynthBatch(declNo);
		if(map.get("flag")!=null&&(Boolean)(map.get("flag"))==true){
			//为流程再造-送检-综合评定  准备特殊的数据
			if(StringUtils.equals("pro", currentLink)){
			//	String reVal=evaluationUpdateProAndStatus(declNo);
				String reVal="";
				if(StringUtils.isNotEmpty(reVal)){
					map.put("msg", reVal);
					map.put("flag",false);
					return map;
				}
				map.put("flag", true);
				return map;
			}
			
			//为流程再造-送检-批量综合评定
		}
		return map;
	}


	/**
	* <p>描述:流程再造送检，综合评定</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
//	private String evaluationUpdateProAndStatus(String declNo) {
//		DclIoDeclEntity vo=sceneDao.getIoEntDeclNo(declNo);
//		//判断是否有锁
//		boolean isLock=sceneCheckBackCommitDao.getInsIsLocked(declNo,vo.getProcessStatus());
//		if(isLock){
//			String msg=String.format(CommMsgContext.DECL_NO_LOCK_MSG, userName,userOrgName,CommContext.EVALUATE_NAME);
//			return msg;
//		}else{
//			try {
//				sceneCheckBackCommitDao.lock(declNo,vo.getProcessStatus());
//				InsDeclMagEntity mag=sceneCheckBackCommitDao.getMainDeclMag(declNo);
//				sceneCheckBackCommitDao.updateProAndStatus(declNo,mag.getDeclWorkNo(),CommContext.EVALUATE,vo.getProcessStatus(),  ,vo.getProcessLink(),);
//			} catch (Exception e) {
//				// TODO: handle exception
//			}finally {
//				sceneCheckBackCommitDao.unDeclLock(declNo,vo.getProcessStatus());
//			}
//		}
//	}


	/**
	* <p>描述:校验是否可以执行综合评定</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private Map<String, Object> isSynthBatch(String declNo) {
		Map<String, Object> map=new HashMap<String, Object>();
		String msg=null;
		
		//判断特殊要求 需查验、需送检、需查验送检
//		String s=isEvaluation(declNo);
//		String msg=null;
//		if(!StringUtils.equals(ManagementContext.sucess, s)){
//			//货物未全部送检
//			if(StringUtils.equals(ManagementContext.send, s)){
//				msg="报检单号"+declNo+ManagementContext.sendName+",不可进行综合评定！";
//			}else if(StringUtils.equals(ManagementContext.sence, s)){
//				msg="报检单号"+declNo+ManagementContext.senceName+",不可进行综合评定！";
//			}else if(StringUtils.equals(ManagementContext.senceSend, s)){
//				msg="报检单号"+declNo+ManagementContext.senceSendName+",不可进行综合评定！";
//			}
//			map.put("msg", msg);
//			map.put("flag",false);
//			return map;
//		}
		
		List<InsCheckItemEntity> insCheckItemEntityList=sceneCheckBackCommitDao.getInsCheckItemList(declNo, 1);
		if(isCheckItemValue2(insCheckItemEntityList)){
			msg="存在未登记的现场查验项目,不可进行综合评定";
			map.put("msg", msg);
			map.put("flag",false);
			return map;
		}
		
		//判断主检是否完成
		if(!isFshInspWorkByMain(declNo)){
			map.put("msg", "报检单号"+declNo+ManagementContext.senceZJ+",不可进行综合评定");
			map.put("flag", false);
			return map;
		}
		
		//判断辅检是否完成
		if(!isFshInspWorkByFJ(declNo)){
			map.put("msg", "报检单号"+declNo+ManagementContext.senceFJ+",不可进行综合评定");
			map.put("flag", false);
			return map;
		}
		
		//判断集装箱不合格未登记
		if(!checkQualified(declNo)){
			map.put("msg", "报检单号"+declNo+"集装箱不合格且未登记,不可进行综合评定");
			map.put("flag", false);
			return map;
		}
	
		
		//判断隔离检疫是否完成
		InsResultSumEntity insResultSumEntity=sceneDao.getInsResultSumEntityByNo(declNo);
		if(insResultSumEntity!=null&&StringUtils.equals(insResultSumEntity.getKepIsolat(), CommContext.Y)){
			InsIsolationQuarEntity insIsolationQuarEntity=sceneDao.findInsIsolationQuarEntityByDeclNo(declNo);
			if(insIsolationQuarEntity==null||StringUtils.isEmpty(insIsolationQuarEntity.getResultEvaluate())){
				map.put("msg", "报检单号"+declNo+"未完成隔离检疫,不可进行综合评定");
				map.put("flag", false);
				return map;
			}
		}
		
		
		//判断证书核销
		
		
		return map;
	}


	/**
	* <p>描述:判断集装箱检疫是否完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private boolean checkQualified(String declNo) {
		String result=sceneDao.getContQuarResult(declNo);
		List<InsContainerResultEntity> list=sceneDao.getCoutResultList(declNo);
		if(StringUtils.equals(result, "2")){
			if(Utils.notEmpty(list)){
				for(InsContainerResultEntity entity:list){
					if(StringUtils.isEmpty(entity.getCntnrUnqlResnC())){
						return false;
					}
				}
			}
		}
		return true;
	}


	/**
	* <p>描述:判断辅检的工作内容是否完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private boolean isFshInspWorkByFJ(String declNo) {
		return sceneDao.isFjEnd(declNo);
	}


	/**
	* <p>描述:判断主检的工作内容是否完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private boolean isFshInspWorkByMain(String declNo) {
		List<InsDeclMagEntity> list=sceneCheckBackCommitDao.findInsDeclMagByFlowType2(declNo,InsContext.FLOW_PATH_STATUS_MAIN);
		InsDeclMagEntity entity=Utils.notEmpty(list)?list.get(0):null;
		if(entity!=null){
			return this.isFshInspWork(declNo,entity.getReceiverDocCode(),entity.getInspContCodes());
		}
		return false;
	}


	/**
	* <p>描述:判断用户下的工作是否已完成</p>
	* @param declNo
	* @param receiverDocCode
	* @param inspContCodes
	* @return
	* @author 吴有根
	*/
	private boolean isFshInspWork(String declNo, String userCode, String inspWorkCodes) {
		boolean result=true;
		String[] s=null;
		if(StringUtils.isEmpty(inspWorkCodes)||(s=inspWorkCodes.split(","))==null||(s!=null&&s.length<=0)){
			return result;
		}
		for(int i=0;i<s.length;i++){
			if(result==false){
				break;
			}
			
			 //货物鉴定 "1"
            if (StringUtils.equals(s[i], InsContext.GOODS_IDENTIFY)) {
                result = this.isFshGoodsAuth(declNo);
            }
            //木质包装结果检疫按钮 "2"
            if (StringUtils.equals(s[i], InsContext.WOOD_PACKAG_QUARANTINE)) {
                result = this.isFshWoodQuar(declNo, userCode);
            }
            //集装箱检疫结果按钮 "3"
            if (StringUtils.equals(s[i], InsContext.CONTAINER_QUARANTINE)) {
                result = this.isFshContQuar(declNo, userCode);
            }
            //货物检疫(检疫结果) "4"
            if (StringUtils.equals(s[i], InsContext.SGOODS_QUARANTINE)) {
                result = this.isFshGoodsQuar(declNo, userCode);
            }
            //隔离检疫按钮 "5"
            if (StringUtils.equals(s[i], InsContext.ISOLATION_QUARANTINE)) {
                result = this.isFshIsolation(declNo);
            }
            //货物检验 "6"
            if (StringUtils.equals(s[i], InsContext.SGOODS_CHECKOUT_CODE)) {
                result = this.isFshGoodsInsp(declNo, userCode);
            }
            //检验检疫 "7"
            if (StringUtils.equals(s[i], InsContext.AUX_INS_QUAR_CODE)) {
                result = this.isFshInspQuar(declNo, userCode);
            }
            //卫生检疫 "8"
            if (StringUtils.equals(s[i], InsContext.AUX_INS_HEALTH_CODE)) {
                result = this.isFshInspQuar(declNo, userCode);
            }
		}
		return result;
	}


	/**
	* <p>描述:判断检验检疫是否完成</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	private boolean isFshInspQuar(String declNo, String userCode) {
		boolean inspQuar=false;
		List<InsResultSumEntity> list=sceneDao.getInsResultSumList2(declNo, userCode);
		if(Utils.notEmpty(list)){
			for(InsResultSumEntity entity:list){
				if(StringUtils.isNotEmpty(entity.getCheckPlace())){
					inspQuar=true;
					break;
				}
			}
		}
		return inspQuar;
	}


	/**
	* <p>描述:判断货物检疫是否完成</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	private boolean isFshGoodsInsp(String declNo, String userCode) {
		boolean goodsCheckFlag=false;
		List<InsResultSumEntity> list=sceneDao.getInsResultSumList2(declNo, userCode);
		if(Utils.notEmpty(list)){
			for(InsResultSumEntity entity:list){
				if(StringUtils.isNotEmpty(entity.getCheckPlace())){
					goodsCheckFlag=true;
					break;
				}
			}
		}
		return goodsCheckFlag;
	}


	/**
	* <p>描述:判断隔离检疫是否完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private boolean isFshIsolation(String declNo) {
		InsIsolationQuarEntity insIsolationQuarEntity=sceneDao.getInsIsolationQuarEntityByNo(declNo);
		if(insIsolationQuarEntity!=null&&StringUtils.isNotEmpty(insIsolationQuarEntity.getResultEvaluate())){
			return true;
		}else{
			return false;
		}
	}


	/**
	* <p>描述:判断货物检疫是否完成</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	private boolean isFshGoodsQuar(String declNo, String userCode) {
		boolean goodsFlag=false;
		List<InsResultSumEntity> list=sceneDao.getInsResultSumList2(declNo, userCode);
		if(Utils.notEmpty(list)){
			for(InsResultSumEntity entity:list){
				if(StringUtils.isNotEmpty(entity.getCheckPlace())){
					goodsFlag=true;
					break;
				}
			}
		}
		return goodsFlag;
	}


	/**
	* <p>描述:判断集装箱检疫是否完成</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	private boolean isFshContQuar(String declNo, String userCode) {
		boolean contflag=false;//集装箱检疫完成标记
		List<InsResultSumEntity> list=sceneDao.getInsResultSumList2(declNo, userCode);
		if(Utils.notEmpty(list)){
			for(InsResultSumEntity entity:list){
				if(StringUtils.isNotEmpty(entity.getContQuarResult())){
					contflag=true;
					break;
				}
			}
		}
		return contflag;
	}


	/**
	* <p>描述:判断木质包装是否完成</p>
	* @param declNo
	* @param userCode
	* @return
	* @author 吴有根
	*/
	private boolean isFshWoodQuar(String declNo, String userCode) {
		boolean woodsflag=false; //木质包装标记
		//InsResultSumScEntity 表改查InsResultSumEntity
		List<InsResultSumEntity> list=sceneDao.getInsResultSumList2(declNo, userCode);
		if(Utils.notEmpty(list)){
			for(InsResultSumEntity entity:list){
				if(StringUtils.isNotEmpty(entity.getWoodpackQuarResult())){
					woodsflag=true;
					break;
				}
			}
		}
		
		return woodsflag;
	}


	/**
	* <p>描述:判断货物鉴定是否完成</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private boolean isFshGoodsAuth(String declNo) {
		InsAuthenticateProcEntity insAuthenticateProcEntity= sceneDao.getInsAuthenticateProcEntity(declNo);
		if(insAuthenticateProcEntity!=null&&StringUtils.equals(CommContext.Y, insAuthenticateProcEntity.getIsAuthFlag())){
			return true;
		}
		return false;
	}


	/**
	* <p>描述:判断是否存在未登记的项目</p>
	* @param insCheckItemEntityList
	* @return
	* @author 吴有根
	*/
	private boolean isCheckItemValue2(List<InsCheckItemEntity> insCheckItemEntityList) {
		if(Utils.notEmpty(insCheckItemEntityList)){
			for(InsCheckItemEntity entity:insCheckItemEntityList){
				if(StringUtils.isEmpty(entity.getWhetherQualfy())){
					return true;
				}
			}
		}
		return false;
	}


	/**
	* <p>描述:判断是否可进行综合评定</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	private String isEvaluation(String declNo) {
		DeclLogicVo vo=sceneCheckBackCommitDao.getDeclLogicVo(declNo);
		String b=ManagementContext.sucess;
        if (vo != null) {
            String sendSpecial = vo.getInspRequire() == null ? "" : vo.getInspRequire();
            String sates = vo.getProcessStatus() == null ? "" : vo.getProcessStatus();
            //送检后的环节
            String sendStatue = CommContext.SUBMIT + "," + CommContext.VER_APP_Y + "," + CommContext.VER_APP_N;
            //送检前的环节
            String senceStatue = CommContext.INS_CHECK_BACK + "," + CommContext.INS_EXCEPTION + "," + CommContext.MANUAL_INTERVENTION + ","
                    + CommContext.PUMP_GROUP + "," + CommContext.WAIT_CHECK;

            if (StringUtils.equals(InsContext.TEST_REQUIRE_SENDCHECK, sendSpecial)) { //需送检
                int i = sendStatue.indexOf(sates);
                if (i != -1) {
                    b = ManagementContext.send;
                }

            } else if (StringUtils.equals(InsContext.TEST_REQUIRE_EXAMINE, sendSpecial)) {//需查验
                if (senceStatue.indexOf(sates) != -1) {
                    b = ManagementContext.sence;
                }

            } else if (StringUtils.equals(InsContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE, sendSpecial)) {//需查验送检

                //如果为二次查验或调回时，检验要求为需查验送检判断是否有查验记录，实验室检测项目是否全部合格时，
                //不需要提示查验送检
                InsResultSumEntity sumentity = sceneCheckBackCommitDao.findInsResultSumEntitybyDeclNo(declNo);
                if (sumentity != null && StringUtils.isNotEmpty(sumentity.getSpotDesc()) && sceneCheckBackCommitDao.isNotQualifiedSampleItem(declNo)) {
                    return b;
                }
                //如果状态为已查验时,需要将状态补进去（1020）
                if ((senceStatue + "," + CommContext.CHECKED).indexOf(sates) != -1) {
                    b = ManagementContext.senceSend;
                } else{
                    boolean re = sceneCheckBackCommitDao.isFinshSend(declNo);
                    if (re) {
                        b = ManagementContext.send;
                    }
                }
            }
        }
        return b;

	}


	/**
	* <p>描述:现场查验-退单</p>
	* @param declMagId
	* @param declNo
	* @param inOutFlag
	* @param dclIoDeclEntity
	* @param workNo
	*/
	public void declBack(String declMagId, String declNo, String inOutFlag, DclIoDeclEntity dclIoDeclEntity,
			String workNo,String userCode,String userOrgCode,InsDeclMagEntity insDeclMagEntity) {
		if(dclIoDeclEntity==null){
			return ;
		}
		
		dclIoDeclEntity.setProcessLink(CommContext.INS);
		//获取此报检单施检最后一次施检审单状态
        UserInfo user=new UserInfo();
        user.setUserCode(userCode);
        SysUser sysUser=subOrReasDao.getSysUser(userCode);
        if(sysUser!=null){
        	user.setCompanyCode(sysUser.getOrgCode());
        	user.setUserName(sysUser.getUserName());
        }
        
		SysProcessLogEntity processLogEntity=sceneCheckBackCommitDao.getLastAuditStatu(declNo);
		processControlUtils.updateProAndStatus(declNo, workNo, CommContext.INS,processLogEntity==null?CommContext.PUMP_GROUP:processLogEntity.getProcessStatus(), user, dclIoDeclEntity.getProcessLink(), dclIoDeclEntity.getProcessStatus(), null, "由现场查验退回至施检审单", true, null);
		//现场查验退单待办事项 暂不
		
		//if(StringUtils.equals(insDeclMagEntity.getFlowPathStatus(), InsContext.FLOW_PATH_STATUS_MAIN)){
			//保存移动流程日志
			SysAppProcessLog log = new SysAppProcessLog();
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			log.setDeclNo(declNo);
			log.setProcessStatus(MobileCommContext.CHECK_N);
			log.setStatusMemo(MobileCommContext.CHECK_N_NAME);
			log.setProcessNode(MobileCommContext.INS);
			log.setNodeMemo(MobileCommContext.INS_NAME);
			
			log.setOperCode(userCode);
			log.setOperName(user.getUserName());
			log.setTreaOrgCode(user.getCompanyCode());
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = formatter.format(new Date());
			Date newDate;
			try {
				newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			processService.savelog(log);
			statusControlUtils.updateProcess(declNo, MobileCommContext.INS, MobileCommContext.CHECK_N, userCode);
			
		//}else if(StringUtils.equals(insDeclMagEntity.getFlowPathStatus(), InsContext.FLOW_PATH_STATUS_AUXILIARY)){
		//	statusControlUtils.writeAuxLog(insDeclMagEntity.getExeInspOrgCode(),insDeclMagEntity.getExcInspDeptCode(), insDeclMagEntity.getInspContCodes(), declMagId, declNo, MobileCommContext.INS, MobileCommContext.CHECK_N, "现场查验退单", user.userCode,user.userName,user.getCompanyCode());
			
		//}
		
		
		//更新报检单管理表
		HashMap<String, String> map=new HashMap<String, String>();
		map.put("CHECK_PRIV", CommContext.N);
		map.put("AUDIT_PRIV", CommContext.Y);
		sceneCheckBackCommitDao.updatePriv(declMagId,map);
		
	}


	/**
	* <p>描述:根据报检单号获取报检单管理表</p>
	* @param declNo
	* @param expImpFlag
	* @param userOrgCode
	* @return
	* @author 吴有根
	*/
	public List<InsDeclMagEntity> getInsDeclMag(String declNo, String expImpFlag, String userOrgCode,String flowPathStatus) {
		return sceneCheckBackCommitDao.getInsDeclMag(declNo,expImpFlag,userOrgCode,flowPathStatus);
	}


	/**
	* <p>描述:校验实际抽样量和数重量</p>
	* @param resultGoodsVO
	* @param b
	* @return
	* @author 吴有根
	*/
	
	
//	private String judgeActSmpNum(InsResultGoodsEntity insResultGoodsVO, boolean flag) {
//        //如果货物上的检验要求为需送检的话 ,则需要校验实际抽样量
//        if (flag) {
//            if (insResultGoodsVO.getActSmplNum() == null) {
//                if (StringUtils.equals(insResultGoodsVO.getHsType(), DeclevalConstants.UNIT_CAT_CODE_WEIGHT)){
//                    return "实际抽样量【重量】不能为空！";
//                }else{
//                    return "实际抽样量【数量】不能为空！";
//                }
//            } 
//        }
//
//        if (StringUtils.equals(insResultGoodsVO.getHsType(), DeclevalConstants.UNIT_CAT_CODE_WEIGHT)) {
//            if (insResultGoodsVO.getRealWeight() == null) {
//                return "实际重量不能为空！";
//            }
//        } else if (StringUtils.equals(insResultGoodsVO.getHsType(), DeclevalConstants.UNIT_CAT_CODE_QTY)) {
//            if (insResultGoodsVO.getActualQty() == null) {
//                return "实际数量不能为空！";
//            } 
//        }
//        return null;
//	}

	/**
	* <p>描述: 综合评定</p>
	* @param request
	* @param decl 评定数据
	* @param userCode 用户代码
	* @param deptCode 部门代码
	* @return
	* @author 才江男
	 */
	public ShowMessageModel synthBatchEval(HttpServletRequest request, HttpServletResponse response, String decl, String userCode, String deptCode, String flag) {
		ShowMessageModel back = new ShowMessageModel();
		
		back.setMessage("评定成功");
		JSONArray ResultGoods = JSONArray.fromObject(decl);
		List<SceneCheckInitTableModel> resultList =(List<SceneCheckInitTableModel>)JSONArray.toList(ResultGoods, SceneCheckInitTableModel.class);
		if(CollectionUtils.isNotEmpty(resultList)) {
			//校验是否符合评定
			String insRequire = null;
			for (SceneCheckInitTableModel subAuditInitTableModel : resultList) {
				String declNo = subAuditInitTableModel.getDeclNo();
				//批量判断选中列表是否状态为辅施检
	            if (!checkAuxEvaluate(subAuditInitTableModel.getFlowPathStatus())) {
	            	back.setMessage("报检单号:" + declNo + "为辅施检单,不可执行综合评定");
					return back;
	            }
	            
	            //批量判断选中列表是否送检
	            insRequire = subAuditInitTableModel.getInsRequire();
	            if(!(InsContext.TEST_REQUIRE_EXAMINE.equals(insRequire) || StringUtils.isEmpty(insRequire)) ) {
	            	back.setMessage("报检单号" + declNo + "需送检,不可执行综合评定");
	            	return back;
	            }
	            
	            Map<String, Object> synthBatchEvalCheck = getSynthBatchEvalCheck(declNo);
	            Object object = synthBatchEvalCheck.get("flag");
	            if(null != object && !(Boolean)object ) {
	            	back.setMessage((String) synthBatchEvalCheck.get("msg"));
	            	return back;
	            }
			}
			if(6 > deptCode.length()) {
				back.setMessage("评定失败");
            	return back;
			}
			// 机构
			String orgCode = deptCode.substring(0, 2) + "0000";
			InsResultEvalEntity entity = null;
			InsResultEval insResultEval = null;
			
			for (SceneCheckInitTableModel sceneCheckInitTableModel : resultList) {
				String declNo = sceneCheckInitTableModel.getDeclNo();
				if(StringUtils.isNotEmpty(declNo)) {
					
					//数据回写
					String sendBackData = sceneService.sendBackData(request,response,declNo, sceneCheckInitTableModel.getFlowPathStatusCode(), userCode, deptCode);
					if(!(StringUtils.isNotEmpty(sendBackData) && sendBackData.contains("保存成功"))) {
						back.setMessage("评定失败");
						return back;
					}
					
					//记录报检单完成数量
					sceneService.recordCount(declNo, userCode, request, response);
					
					//机构
					entity = new InsResultEvalEntity();
					entity.setInsResultEvalId(UUIDKeyGeneratorUils.newInstance().generateKey());
					entity.setDeclNo(declNo);
					entity.setUserCode(userCode);
					entity.setOrgCode(deptCode);
					entity.setIsEval("0");
					entity.setFalgArchive("0");
					entity.setOperTime(new Date());
					entity.setAdditional3(flag);
					entity.setAdditional2("1");//综合评定
					entity.setReceiveFlag("0");
					
					//保存综合评定信息
					sceneCheckBackCommitDao.saveInsResultEval(entity);
					
					insResultEval = new InsResultEval();
					
					try {
						BeanPropertyUtils.getInstance().copyPropertiesBean(
								insResultEval, entity);
						
						//数据回写标志，默认为到交换库
						insResultEval.setReceiveFlag("0");
					} catch (Throwable e) {
						back.setMessage("评定失败");
						return back;
					}

					//调用
					String msg = insResultEvalHandel.getSendInsResultEval(request, null, insResultEval, orgCode);
					
					if (StringUtils.isNotEmpty(msg)
							&& msg.contains("<RESULT_DESC>")) {
						int indexStart = msg.indexOf("<RESULT_DESC>");
						int indexEnd = msg.indexOf("</RESULT_DESC>");
						msg = msg.substring(indexStart + 13, indexEnd);
						if(!(StringUtils.isNotEmpty(msg) && msg.contains("数据保存成功"))) {
							back.setMessage("评定失败");
							return back;
						} else {
							writeLog(declNo, userCode);
						}
					}
				} else {
					back.setMessage("数据有误");
					return back;
				}
			}
		} else {
			back.setMessage("数据有误");
		}
		return back;
	}
	
	/**
	* <p>描述:更新流程日志</p>
	* @param declNo 报检号
	* @param userCode 用户代码
	* @author 才江男
	 */
	public void writeLog(String declNo, String userCode) {
		//更新权限
		sceneCheckBackCommitDao.updatePriv(declNo);
		
		// 移动端查验流程日志
		SysAppProcessLog log = new SysAppProcessLog();
		SysUser sysUser = subOrReasService.getSysUser(userCode);
		if (sysUser != null) {
			log.setOperCode(userCode);
			log.setOperName(sysUser.getUserName());
			log.setTreaOrgCode(sysUser.getOrgCode());
		}
		log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		log.setDeclNo(declNo);
		log.setProcessNode(MobileCommContext.EVALUATE);
		log.setNodeMemo(MobileCommContext.EVALUATE_NAME);
		log.setProcessStatus(MobileCommContext.VER_APP_RESULT);
		log.setStatusMemo(MobileCommContext.VER_APP_RESULT_NAME);
		log.setRemark("综合评定");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		Date newDate;
		try {
			newDate = formatter.parse(dateString);
			log.setOperDate(newDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		processService.savelog(log);
		statusControlUtils.updateProcess(declNo, MobileCommContext.EVALUATE,
				MobileCommContext.VER_APP_RESULT, userCode);

	}
	
	/**
	* <p>描述:判断报检单是否为辅施检单</p>
	* @param declNo 报检单号
	* @param flowPathStatus 流程状态
	* @return 辅施检返回false, 否则返回true
	* @author 才江男
	*/
	public boolean checkAuxEvaluate(String flowPathStatus) {
		if ((StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY)
                || StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE))) {
            return false;
        }
		if ((StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY_NAME)
                || StringUtils.equals(flowPathStatus, InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE_NAME))) {
            return false;
        }
        return true;
	}
	
	
	/**
	 * 
	* <p>描述:判断是否满足综合评定条件</p>
	* @param declNo
	* @return
	* @author 吴有根
	 */
	public Map<String, Object> getSynthBatchEvalCheck(String declNo){
		Map<String, Object> map=new HashMap<String, Object>();
		//判断是否存在未登记的现场查验项目
		List<InsCheckItemEntity> insCheckItemEntityList=sceneCheckBackCommitDao.getInsCheckItemList(declNo, 1);
		if(isCheckItemValue2(insCheckItemEntityList)){
			map.put("msg", "报检单号"+declNo+"存在未登记的现场查验项目，不可进行综合评定");
			map.put("flag", false);
			return map;
		}
		
		//判断主检是否完成
		if(!isFshInspWorkByMain(declNo)){
			map.put("msg", "报检单号"+declNo+ManagementContext.senceZJ+",不可进行综合评定");
			map.put("flag", false);
			return map;
		}
		
		//判断辅检是否完成
		if(!isFshInspWorkByFJ(declNo)){
			map.put("msg", "报检单号"+declNo+ManagementContext.senceFJ+",不可进行综合评定");
			map.put("flag", false);
			return map;
		}
		
		//判断集装箱不合格未登记
		if(!checkQualified(declNo)){
			map.put("msg", "报检单号"+declNo+"集装箱不合格且未登记,不可进行综合评定");
			map.put("flag", false);
			return map;
		}
	
		
		//判断隔离检疫是否完成
		InsResultSumEntity insResultSumEntity=sceneDao.getInsResultSumEntityByNo(declNo);
		if(insResultSumEntity!=null&&StringUtils.equals(insResultSumEntity.getKepIsolat(), CommContext.Y)){
			InsIsolationQuarEntity insIsolationQuarEntity=sceneDao.findInsIsolationQuarEntityByDeclNo(declNo);
			if(insIsolationQuarEntity==null||StringUtils.isEmpty(insIsolationQuarEntity.getResultEvaluate())){
				map.put("msg", "报检单号"+declNo+"未完成隔离检疫,不可进行综合评定");
				map.put("flag", false);
				return map;
			}
		}
		return map;
	}
	
	/**
	* <p>描述:判断是否满足综合评定条件，供外部调用</p>
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param insRequire 是否送检
	* @return 0不满足 1满足  2不满足，需送检，满足  3不满足，需送检,不满足
	* @author 才江男
	 */
	public String isEvaled(String declNo, String flowPathStatus, String insRequire){
        
        //批量判断选中列表是否送检
        if(!(InsContext.TEST_REQUIRE_EXAMINE.equals(insRequire) || StringUtils.isEmpty(insRequire)) ) {
        	List<InsResultGoodsEntity> resultList=sceneService.getInsResultGoodsList(declNo,"0");
        	if(CollectionUtils.isNotEmpty(resultList)) {
        		for (InsResultGoodsEntity insResultGoodsEntity : resultList) {
    				if(null != insResultGoodsEntity.getActSmplNum() && 0 < insResultGoodsEntity.getActSmplNum().doubleValue()) {
    					return "2";
    				}
    			}
        		return "3";
        	}
        	return "2";
        }
        
        //批量判断选中列表是否状态为辅施检
        if (!checkAuxEvaluate(flowPathStatus)) {
        	return "0";
        }
        
		//判断是否存在未登记的现场查验项目
		List<InsCheckItemEntity> insCheckItemEntityList=sceneCheckBackCommitDao.getInsCheckItemList(declNo, 1);
		if(isCheckItemValue2(insCheckItemEntityList)){
			return "0";
		}
		
		//判断主检是否完成
		if(!isFshInspWorkByMain(declNo)){
			return "0";
		}
		
		//判断辅检是否完成
		if(!isFshInspWorkByFJ(declNo)){
			return "0";
		}
		
		//判断集装箱不合格未登记
		if(!checkQualified(declNo)){
			return "0";
		}
		
		//判断隔离检疫是否完成
		InsResultSumEntity insResultSumEntity=sceneDao.getInsResultSumEntityByNo(declNo);
		if(insResultSumEntity!=null&&StringUtils.equals(insResultSumEntity.getKepIsolat(), CommContext.Y)){
			InsIsolationQuarEntity insIsolationQuarEntity=sceneDao.findInsIsolationQuarEntityByDeclNo(declNo);
			if(insIsolationQuarEntity==null||StringUtils.isEmpty(insIsolationQuarEntity.getResultEvaluate())){
				return "0";
			}
		}
		
		return "1";
	}
	
	/**
	* <p>描述: 综合评定-供审核调用</p>
	* @param request
	* @param declNo 报检号
	* @param userCode 用户代码
	* @param deptCode 部门代码
	* @param orgCode 直属局代码
	* @param flag 环节
	* @return 评定信息
	* @author 才江男
	 */
	public String evalCommit(HttpServletRequest request, String declNo, String userCode, String deptCode, String orgCode, String flag) {
		String msg = "评定成功";
		//机构
		InsResultEvalEntity entity = new InsResultEvalEntity();
		entity.setInsResultEvalId(UUIDKeyGeneratorUils.newInstance().generateKey());
		entity.setDeclNo(declNo);
		entity.setUserCode(userCode);
		entity.setOrgCode(deptCode);
		entity.setIsEval("0");
		entity.setFalgArchive("0");
		entity.setOperTime(new Date());
		entity.setAdditional3(flag);
		entity.setReceiveFlag("0");
		entity.setAdditional2("1");//综合评定
		
		//保存综合评定信息
		sceneCheckBackCommitDao.saveInsResultEval(entity);
		
		InsResultEval insResultEval = new InsResultEval();
		
		try {
			BeanPropertyUtils.getInstance().copyPropertiesBean(
					insResultEval, entity);
			
			//数据回写标志，默认为到交换库
			insResultEval.setReceiveFlag("0");
		} catch (Throwable e) {
			msg = "评定失败";
		}

		//调用
		msg = insResultEvalHandel.getSendInsResultEval(request, null, insResultEval, orgCode);
		
		if (StringUtils.isNotEmpty(msg)
				&& msg.contains("<RESULT_DESC>")) {
			int indexStart = msg.indexOf("<RESULT_DESC>");
			int indexEnd = msg.indexOf("</RESULT_DESC>");
			msg = msg.substring(indexStart + 13, indexEnd);
			if(!(StringUtils.isNotEmpty(msg) && msg.contains("数据保存成功"))) {
				msg = "评定失败";
			} else {
				msg = "评定成功";
				writeLog(declNo, userCode);
			}
		}
		
		return msg;
	}
	
	/**
	* <p>描述: 综合评定-供审核调用</p>
	* @param request
	* @param declNo 报检号
	* @param userCode 用户代码
	* @param deptCode 部门代码
	* @param orgCode 直属局代码
	* @param flag 环节
	* @return 评定信息
	* @author 才江男
	 */
	public void evalCommitFushijian(HttpServletRequest request, String declNo, String userCode, String deptCode, String orgCode, String flag) {
		//机构
		InsResultEvalEntity entity = new InsResultEvalEntity();
		entity.setInsResultEvalId(UUIDKeyGeneratorUils.newInstance().generateKey());
		entity.setDeclNo(declNo);
		entity.setUserCode(userCode);
		entity.setOrgCode(deptCode);
		entity.setIsEval("0");
		entity.setFalgArchive("0");
		entity.setOperTime(new Date());
		entity.setAdditional3(flag);
		entity.setReceiveFlag("0");
		entity.setAdditional2("2");//辅施检完成
		
		//保存综合评定信息
		sceneCheckBackCommitDao.saveInsResultEval(entity);
		
		InsResultEval insResultEval = new InsResultEval();
		
		try {
			BeanPropertyUtils.getInstance().copyPropertiesBean(
					insResultEval, entity);
			
			//数据回写标志，默认为到交换库
			insResultEval.setReceiveFlag("0");
		} catch (Throwable e) {
			e.printStackTrace();
		}

		//调用
		insResultEvalHandel.getSendInsResultEval(request, null, insResultEval, orgCode);
		
	}
	
	
	/**
	* <p>描述:更新流程日志</p>
	* @param declNo 报检号
	* @param userCode 用户代码
	* @author 才江男
	 */
	public void writeEvalLog(String declNo, String userCode, String processLink, String processLinkName, String processStatus, String processStatusName, String remark) {
		// 移动端查验流程日志
		SysAppProcessLog log = new SysAppProcessLog();
		SysUser sysUser = subOrReasService.getSysUser(userCode);
		if (sysUser != null) {
			log.setOperCode(userCode);
			log.setOperName(sysUser.getUserName());
			log.setTreaOrgCode(sysUser.getOrgCode());
		}
		log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
		log.setDeclNo(declNo);
		log.setProcessNode(processLink);
		log.setNodeMemo(processLinkName);
		log.setProcessStatus(processStatus);
		log.setStatusMemo(processStatusName);
		log.setRemark(remark);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		Date newDate;
		try {
			newDate = formatter.parse(dateString);
			log.setOperDate(newDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		processService.savelog(log);
		statusControlUtils.updateProcess(declNo, processLink,
				processStatus, userCode);

	}
	
	
}

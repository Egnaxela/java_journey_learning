/**  
 * FileName: SceneService.java   
 * @Description:  现场查验service
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-27 下午2:41:48  
 *  
 */ 
package com.rongji.eciq.mobile.service.insp.scene;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rongji.common.mfile.FileManager;
import com.rongji.common.mfile.FileManagerHolder;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.context.SceneContext;
import com.rongji.eciq.mobile.controller.insp.scene.SceneCheckInitController;
import com.rongji.eciq.mobile.controller.sys.DeclNoCountController;
import com.rongji.eciq.mobile.dao.decl.sceneProcess.SceneProcessSerchDao;
import com.rongji.eciq.mobile.dao.insp.HQLCodeToNameDao;
import com.rongji.eciq.mobile.dao.insp.audit.SceneCheckAuditDao;
import com.rongji.eciq.mobile.dao.insp.scene.SceneDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclContEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclContDetailEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclOrdFeedbackMainEntity;
import com.rongji.eciq.mobile.entity.DclPackDeclEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsContainerResultEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.model.base.DataModel;
import com.rongji.eciq.mobile.model.insp.scene.DeclBaseInfoModel;
import com.rongji.eciq.mobile.model.insp.scene.GoodsResultRegisterModel;
import com.rongji.eciq.mobile.model.insp.scene.PaperLessModel;
import com.rongji.eciq.mobile.sendxml.service.DclOrdFeedBackMainHandel;
import com.rongji.eciq.mobile.sendxml.service.InsResultSumHandel;
import com.rongji.eciq.mobile.service.decl.sceneProcess.SceneProcessSerchService;
import com.rongji.eciq.mobile.service.insp.sub.SubOrReasService;
import com.rongji.eciq.mobile.utils.CompanyCodeUtils;
import com.rongji.eciq.mobile.utils.DeclNoUtils;
import com.rongji.eciq.mobile.utils.DesDecryptUtil;
import com.rongji.eciq.mobile.utils.StatusControlUtils;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;
import com.rongji.eciq.mobile.vo.insp.FileVo;
import com.rongji.eciq.server.entity.InsDeclLob;
import com.rongji.eciq.server.entity.InsDeclLobEntity;
import com.rongji.eciq.server.entity.InsDeclReview;
import com.rongji.eciq.server.service.SenceCheckService;
import com.rongji.system.entity.SysAppProcessLog;
import com.rongji.system.sys.service.SysUserService;



/**
 * 
 * Description: 现场查验service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-12 上午11:11:32  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      才江男                      1.0        增加附件保存查询方法  
 * 2017-4-24      魏波                           1.0        现场查验跳不合格登记
 * 2017-4-25      才江男                      1.0        货物不合格登记代码转名称
 * 2017-4-25      才江男                      1.0        获取附件时，增加人员条件
 * 2017-4-27      才江男                      1.0        多代码转名称
 * 2017-4-27      才江男                      1.0        审单进入现场查验
 * 2017-5-05      才江男                      1.0        删除附件
 * 2017-05-09     才江男                      1.0        结束现场查验，进入结果登记
 * 2017-05-09     才江男                      1.0        数据回写
 * 2017-05-10     才江男                      1.0        数据回写,默认操作失败
 * 2017-05-11     才江男                      1.0        消息截取
 * 2017-05-11     才江男                      1.0        数据回写前，增加审核校验
 * 2017-05-12     吴有根                     1.0.0       增加货物评定合格判断&返回集装箱检疫、木质包装检疫结果
 * 2017-05-13     才江男                     1.0.0       获取主辅施检标志
 * 2017-05-15     才江男                     1.0.0       获取完整访问的无纸化地址
 * 2017-05-19     才江男                     1.0.0       返回消息去“！”
 * 2017-05-26     才江男                     1.0.0       更新流程环节及流程状态
 * 2017-05-27     才江男                     1.0.0       流程日志放到service
 * 2017-06-01     李云龙                      1.0         根据主辅施检更新现场查验方面流程
 * 2017-06-05     才江男                      1.0         数据回写改为直属局
 * 2017-06-07     才江男                      1.0         辅施检数据回写
 * 2017-06-13     才江男                      1.0         辅施检改为结果登记回写
 * 2017-06-16     才江男                      1.0         更新报检单权限-辅施检保存现场查验后，不可操作
 * 2017-07-20     才江男                      1.0         附件
 * 2017-07-26             吴有根                      1.0		        根据报检单号带出企业、生产批号等基本信息
 * 2017-08-29             吴有根                      1.0		         报检单回写操作流程记录(&适用统计)
 * 2017-09-15     夏晨琳                       2.0         修改记录报检单回写记录信息
 * 2017-09-22     吴有根                       2.0         增加报检单首次回写字段
 */
@Service
//@Transactional
public class SceneService {

	
	@Resource
	SceneDao sceneDao;
	@Resource
	SceneProcessSerchDao dao;
	@Autowired(required = false)
	SubOrReasDao subOrReasDao;
	@Resource
	private HQLCodeToNameDao codeToNameUtils;
	
	@Resource
	private CompanyCodeUtils companyCodeUtils;

	
	@Autowired
	InsResultSumHandel insResultSumHandel;
	
	@Autowired
	DclOrdFeedBackMainHandel dclOrdFeedBackMainHandel;
	
	@Autowired
	private OrdProcessService ordService;
	@Resource
	SceneCheckAuditDao checkAuditdao;
	@Autowired
	private SubOrReasService subOrReasService;
	@Autowired
	private SceneProcessSerchService processService;
	@Resource
	private StatusControlUtils statusControlUtils;
	@Autowired
	private SenceCheckService senceCheckService;
	@Autowired
	private SceneCheckInitController sceneCheckInitController;
	@Autowired
	private SysUserService userService;
	@Autowired
	private DeclNoCountController declNoCountController;
	private static final Logger log=Logger.getLogger(SceneService.class);
	
	/**
	 * 根据参数初始化查询现场查验table
	 * @param expImpFlag   	        出入境标志
	 * @param exeInspOrgCode   施检机构代码
	 * @param receiverDocCode  接单员代码
	 * @param declNo		       报检单号
	 * @param declRegName      报检单位
	 * @return
	 */
	public List<SubOrReasEntity> getMagList(String expImpFlag, String exeInspOrgCode, String receiverDocCode,String declNo,String declRegName,String currentPage) {
		return sceneDao.getMagList( expImpFlag,  exeInspOrgCode,  receiverDocCode, declNo, declRegName, currentPage);
	}

	/**
	 * 根据参数初始化查询报检单的货物基本信息
	 * @param declNo
	 * @param currentPage
	 * @return
	 */
	public List<InsResultGoodsEntity> getInsResultGoodsList(String declNo,String currentPage) {
		return sceneDao.getInsResultGoodsList(declNo,currentPage);
	}

	/**
	 * 现场查验跳不合格登记
	 * @param declNo
	 * @param goodsNo
	 * @param ioFlag
	 * @return
	 */
	public GoodsResultRegisterModel getInsResultGoodsEntity(String declNo,String goodsNo, String ioFlag){
		InsResultGoodsEntity ent = sceneDao.getInsResultGoodsEntity(declNo, goodsNo);
		GoodsResultRegisterModel model = new GoodsResultRegisterModel();
		if(null != ent) {
			assembleResultGoods(ent, model, declNo, goodsNo, ioFlag);
		}
		return model;
	}
	
	/**
	* <p>描述: 拼装货物结果</p>
	* @param ent 货物结果
	* @param model 所需结果
	* @param declNo 报检单号
	* @param goodsNo 货物序号
	* @param ioFlag 出入境标志
	* @author 才江男
	 */
	private void assembleResultGoods(InsResultGoodsEntity ent, GoodsResultRegisterModel model, String declNo, String goodsNo, String ioFlag) {
		model.setResultGoodsId(ent.getResultGoodsId());
		model.setDeclNo(declNo);
		model.setGoodsNo(goodsNo);
		//检验不合格处理
		String unqualHaCode = ent.getInpUnqualHaCode();
		model.setInpUnqualHaCode(unqualHaCode);
		if(StringUtils.isNotEmpty(unqualHaCode)) {
			//检验不合格处理名称
			String unqualHaName = resultGoodsCodeToName(ioFlag, unqualHaCode,"1");
			model.setInpUnqualHaName(unqualHaName);
		}
		//检验不合格数量
		model.setUnqulCommInsQty(ent.getUnqulCommInsQty());
		//检验不合格金额
		model.setInspUnquaAmt(ent.getInspUnquaAmt());
		//检验不合格原因
		String inspUnqResn = ent.getInspUnqResn();
		model.setInspUnqResn(inspUnqResn);
		if(StringUtils.isNotEmpty(inspUnqResn)) {
			//检验不合格原因名称
			String inspUnqResnName = resultGoodsCodeToName(null, inspUnqResn, "2");
			model.setInspUnqResnName(inspUnqResnName);
		}
		//检验不合格内容
		String inspDisquaContCodes = ent.getInspDisquaContCodes();
		model.setInspDisquaContCodes(inspDisquaContCodes);
		if(StringUtils.isNotEmpty(inspDisquaContCodes)) {
			//检验不合格内容名称
			String inspDisquaContNames = resultGoodsCodeToName(null, inspDisquaContCodes, "3");
			model.setInspDisquaContNames(inspDisquaContNames);
		}
		//检疫不合格处理
		String qurUnqProcCode = ent.getQurUnqProcCode();
		model.setQurUnqProcCode(qurUnqProcCode);
		if(StringUtils.isNotEmpty(qurUnqProcCode)) {
			//检疫不合格处理名称
			String qurUnqProcName = resultGoodsCodeToName(null, qurUnqProcCode,"4");
			model.setQurUnqProcName(qurUnqProcName);
		}
		//检疫不合格处理方法
		String speQuarTrmtMecC = ent.getSpeQuarTrmtMecC();
		model.setSpeQuarTrmtMecC(speQuarTrmtMecC);
		if(StringUtils.isNotEmpty(speQuarTrmtMecC)) {
			//检疫不合格处理方法名称
			String speQuarTrmtMecCName = resultGoodsCodeToName(null, speQuarTrmtMecC, "5");
			model.setSpeQuarTrmtMecCName(speQuarTrmtMecCName);
		}
		//检疫不合格数量
		model.setUnqulfdQuarQty(ent.getUnqulfdQuarQty());
		//检疫不合格金额
		model.setUnqualQuarAmt(ent.getUnqualQuarAmt());
		//检疫不合格原因
		String qurUnqulRsnCode = ent.getQurUnqulRsnCode();
		model.setQurUnqulRsnCode(qurUnqulRsnCode);
		if(StringUtils.isNotEmpty(qurUnqulRsnCode)) {
			//检疫不合格原因名称
			String qurUnqulRsnName = resultGoodsCodeToName(null, qurUnqulRsnCode, "6");
			model.setQurUnqulRsnName(qurUnqulRsnName);
		}
		//检疫不合格内容
		String quarDisquaContCodes = ent.getQuarDisquaContCodes();
		model.setQuarDisquaContCodes(quarDisquaContCodes);
		if(StringUtils.isNotEmpty(quarDisquaContCodes)) {
			String quarDisquaContNames = resultGoodsCodeToName(null, quarDisquaContCodes, "7");
			model.setQuarDisquaContNames(quarDisquaContNames);
		}
		//综合不合格数量
		model.setUnqualQty(ent.getUnqualQty());
		//综合不合格金额
		model.setUnqualAmt(ent.getUnqualAmt());
		//货币种类
		String currency = codeToNameUtils.getMeasurementNameByCode(ent.getCurrency(),"CurrencyType");
		if (StringUtils.isEmpty(currency)) {
			model.setCurrency("人民币");
		}else{
			model.setCurrency(currency);
		}
		//重量
		String wtUnitCode = codeToNameUtils.getMeasurementNameByCode(ent.getWtUnitCode(),"Measurement");
		if(StringUtils.isEmpty(wtUnitCode)){
			model.setWtUnitCode("千克");
		}else{
			model.setWtUnitCode(wtUnitCode);
		}
		//数量
		String qtyUnitName = codeToNameUtils.getMeasurementNameByCode(ent.getQtyUnitCode(),"Measurement");
		if(StringUtils.isEmpty(qtyUnitName)){
			model.setQtyUnitName("个");
		}else{
			model.setQtyUnitName(qtyUnitName);
		}
		
		model.setInspUnquafWt(ent.getInspUnquafWt());//检验不合格重量
		model.setQuaranUnquaWt(ent.getQuaranUnquaWt());//检疫不合格重量
		model.setUnquaWt(ent.getUnquaWt());//综合不合格重量
		model.setMesuUnTypCode(ent.getMesuUnTypCode());//计量单位类别
	}
	
	/**
	* <p>描述:代码转名称名称</p>
	* @param ioFlag 检验检疫标志
	* @param unqualHaCode 检验不合格内容代码
	* @return 检验不合格内容名称
	* @author 才江男
	 */
	private String resultGoodsCodeToName(String ioFlag, String unqualHaCode, String flag) {
		String name = "";
		if(StringUtils.isNotEmpty(unqualHaCode) && unqualHaCode.contains(",")) {
			String[] codes = unqualHaCode.split(",");
			for (int i=0;i<codes.length;i++) {
				String tmp = "";
				if("1".equals(flag)) {
					tmp = codeToNameUtils.getUnqualHaDic(ioFlag, codes[i]);
				} else if("2".equals(flag)) {
					tmp = codeToNameUtils.getIOFGoodCheckoutDisQR(codes[i]);
				}  else if("3".equals(flag)) {
					tmp = codeToNameUtils.getIOFGoodCheckoutDisQC("1", codes[i]);
				}  else if("4".equals(flag)) {
					tmp = codeToNameUtils.getProductDwHandleMethd(codes[i]);
				}  else if("5".equals(flag)) {
					tmp = codeToNameUtils.getProductDwDetailMethd(codes[i]);
				}  else if("6".equals(flag)) {
					tmp = codeToNameUtils.getProductDwHandleRea(codes[i]);
				}  else if("7".equals(flag)) {
					tmp = codeToNameUtils.getIOFGoodCheckoutDisQC("2", codes[i]);
				} 
				if(i != 0) {
					name += "," + tmp;
				} else {
					name += tmp;
				}
			}
		} else {
			if("1".equals(flag)) {
				name = codeToNameUtils.getUnqualHaDic(ioFlag, unqualHaCode);
			} else if("2".equals(flag)) {
				name = codeToNameUtils.getIOFGoodCheckoutDisQR(unqualHaCode);
			}  else if("3".equals(flag)) {
				name = codeToNameUtils.getIOFGoodCheckoutDisQC("1", unqualHaCode);
			}  else if("4".equals(flag)) {
				name = codeToNameUtils.getProductDwHandleMethd(unqualHaCode);
			}  else if("5".equals(flag)) {
				name = codeToNameUtils.getProductDwDetailMethd(unqualHaCode);
			}  else if("6".equals(flag)) {
				name = codeToNameUtils.getProductDwHandleRea(unqualHaCode);
			}  else if("7".equals(flag)) {
				name = codeToNameUtils.getIOFGoodCheckoutDisQC("2", unqualHaCode);
			} 
		}
		return name;
	}
	
	/**
	 * 根据货物序号和报检号获取查验项目
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	public List<InsCheckItemEntity> getInsCheckItemList(String declNo, String goodsNo,String checkItemName) {
		return sceneDao.getInsCheckItemList(declNo,goodsNo,checkItemName);
	}

	/**
	 * 根据参数初始化查询现场查验记录基本信息
	 * @param declNo
	 * @param expImpFlag
	 * @return
	 */
	public List<InsResultSumEntity> getInsResultSumList(String declNo, String expImpFlag) {
		return sceneDao.getInsResultSumList(declNo,expImpFlag);
	}

	/**
	 * 根据指定参数查询
	 * @param orgCode   机构代码
	 * @param paperlessUrlParam  参数编码
	 * @return
	 */
	public String getPaperLessUrl(String orgCode, String paperlessUrlParam) {
		return sceneDao.getPaperLessUrl(orgCode,paperlessUrlParam);
	}
	
	/**
	 * 根据指定参数查询
	 * 
	 * @param orgCode 机构代码
	 * @param paperlessUrlParam 参数编码
	 * @return
	 */
	public DataModel getFullPaperLessUrl(DataModel base, String declNo,
			String orgCode, String paperlessUrlParam) {
		// 部门代码转机构
//		orgCode = companyCodeUtils.getBusinessOrgCode(orgCode.substring(0, 6), false);
		String paperLessUrl = sceneDao.getPaperLessUrl(orgCode.substring(0,2)+"0000",
				paperlessUrlParam);
		Map<String, String> map = new HashMap<String, String>();
		String entDeclNo = "";
		if (StringUtils.isEmpty(paperLessUrl)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(DeclContext.INFO_SET_PAPERLESS_PARAM);
			return base;
		}

		map = getDeclInfo(declNo);
		if (null == map) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg("未找到相关信息");
			return base;
		}
		map.put("decl_no", declNo);

		// 判断declNo为正式号
		if (DeclNoUtils.checkOfficialDeclNo(declNo)) {
			if (!StringUtils.isEmpty(map.get("decl_get_no"))
					&& DeclNoUtils.checkDeclNoE(map.get("decl_get_no"))) {
				entDeclNo = declNo;
			} else {
				entDeclNo = "";
			}
		} else if (DeclNoUtils.checkDeclNoE(declNo)) {
			entDeclNo = declNo;
		}

		// 企业报检号为空时返回结果
		if (StringUtils.isEmpty(entDeclNo)) {
			base.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			base.setMsg(DeclContext.INFO_NO_PAPERLESS);
			return base;
		} else {
			PaperLessModel model = new PaperLessModel();
			model.setPaperLessUrl(getPaperLess(paperLessUrl, map, entDeclNo));
			base.setData(model);
			return base;
		}
	}

	/**
	 * <p>描述:获取完整访问的无纸化地址</p>
	 * 
	 * @param map
	 * @param entDeclNo
	 * @return
	 * @author 才江男
	 */
	private String getPaperLess(String paperLessUrl, Map<String, String> map,
			String entDeclNo) {
		if (StringUtils.isNotEmpty(entDeclNo)) {
			String params = "";
			String paramsJc = "";
			String declNo = "";
			String entUuid = "";
			try {
				// 加密
				if (null != map.get("decl_no")) {
					declNo = DesDecryptUtil
							.encrypt((String) map.get("decl_no"));
					params = "?declNo=" + declNo;
				}
				if (null != map.get("ent_decl_no")) {
					entDeclNo = DesDecryptUtil.encrypt((String) map
							.get("ent_decl_no"));
					params += "?entDeclNo=" + entDeclNo;
				}
				if (null != map.get("ent_uuid")) {
					entUuid = DesDecryptUtil.encrypt((String) map
							.get("ent_uuid"));
					params += "?entUuid=" + entUuid;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			if (!StringUtils.contains(paperLessUrl, "-entDeclNo")) {

				if (StringUtils.contains(paperLessUrl, "?")) {
					paramsJc = "&entDeclNo=" + entUuid;
				} else {
					paramsJc = "?entDeclNo=" + entUuid;
				}
				paperLessUrl = paperLessUrl + paramsJc;
			} else {
				paperLessUrl = paperLessUrl.replaceAll("-entDeclNo", "");
				if (StringUtils.contains(paperLessUrl, "?")) {
					if (!StringUtils.isEmpty(params)) {
						params = params.replaceAll("\\?", "&");
					}
					paperLessUrl = paperLessUrl + params;

				} else {
					if (!StringUtils.isEmpty(params)) {
						params = params.replaceAll("\\?", "&");
						params = "?" + params.substring(1, params.length());
					}
					paperLessUrl = paperLessUrl + params;
				}
			}

		} else {
			if (StringUtils.contains(paperLessUrl, "-entDeclNo")) {
				paperLessUrl = paperLessUrl.replaceAll("-entDeclNo", "");
			}
		}

		return paperLessUrl;
	}

	/**
	 * 通过报检号查看预报检号
	 * @param declNo
	 * @return
	 */
	public Map<String, String> getDeclInfo(String declNo) {
		Map<String, String> map=null;
		//判断报检单类型  出入境
		if(DeclNoUtils.checkInDeclType(declNo)||DeclNoUtils.checkOutDeclType(declNo)){
			DclIoDeclEntity dclIoDeclEntity=sceneDao.getIoEntDeclNo(declNo);
			if(dclIoDeclEntity!=null){//?
				map=new HashMap<String, String>();
				map.put("ent_decl_no", dclIoDeclEntity.getEntUuid());
				map.put("ent_uuid", dclIoDeclEntity.getEntDeclNo());
				map.put("decl_get_no", dclIoDeclEntity.getDeclGetNo());
				return map;
			}else{
				return map;
			}
			//出境包装
		}else if (DeclNoUtils.checkGoodsDeclType(declNo)) {
			DclPackDeclEntity dclPackDeclEntity=sceneDao.getPackEntDeclNo(declNo);
			if(dclPackDeclEntity!=null){
                map = new HashMap<String, String>();
                map.put("ent_decl_no", dclPackDeclEntity.getEntUuid());
                map.put("ent_uuid", dclPackDeclEntity.getEntDeclNo());
                map.put("decl_get_no", dclPackDeclEntity.getDeclGetNo());
                return map;
			}else {
				return map;
			}
			//集装箱适载
		}else if (DeclNoUtils.checkContainerDeclType(declNo)) {
			DclContEntity dclContEntity=sceneDao.getContainerEntDeclNo(declNo);
            if (dclContEntity != null) {
                map = new HashMap<String, String>();
                map.put("ent_decl_no", dclContEntity.getEntUuid());
                map.put("ent_uuid", dclContEntity.getEntDeclNo());
                map.put("decl_get_no", dclContEntity.getDeclGetNo());
            } else {
                return map;
            }
		}else {
			return map;
		}
		return map;
	}

	/**
	 * 通过转单号查看转出局报检号
	 * @param declNo
	 * @return
	 */
	public String getOutDeclNoByTranNo(String tranNo) {
		return sceneDao.getOutDeclNoByTranNo(tranNo);
	}

	/**
	 * 通过报检号查看预报检号
	 * @param officialDeclNo
	 * @return
	 */
	public String getDeclGetNoByDeclNo(String declNo) {
        //判断报检单类型  出入境
        if (DeclNoUtils.checkInDeclType(declNo) || DeclNoUtils.checkOutDeclType(declNo)) {
            DclIoDeclEntity dclIoDeclEntity = sceneDao.getIoEntDeclNo(declNo);
            if (dclIoDeclEntity != null) {
                return dclIoDeclEntity.getDeclGetNo();
            } else {
                return "";
            }
            //出境包装
        } else if (DeclNoUtils.checkGoodsDeclType(declNo)) {
            DclPackDeclEntity dclPackDeclEntity = sceneDao.getPackEntDeclNo(declNo);
            if (dclPackDeclEntity != null) {
                return dclPackDeclEntity.getDeclGetNo();
            } else {
                return "";
            }
            //集装箱适载
        } else if (DeclNoUtils.checkContainerDeclType(declNo)) {
            DclContEntity dclContEntity = sceneDao.getContainerEntDeclNo(declNo);
            if (dclContEntity != null) {
                return dclContEntity.getDeclGetNo();
            } else {
                return "";
            }
        } else {
            return "";
        }
	}

	/**
	 * 保存现场查验记录
	 * @param entity
	 */
	public String saveRecordCheck(InsResultSumEntity entity) {
		return sceneDao.updateEntity(entity);
	}

	/**
	* <p>描述:判断是否可以进行二次检验勾选</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean judgeIsSecondUse(String declNo) {
		SysProcessLogEntity sysProcessLogEntity=sceneDao.getSysProcessLogEntityByChecked(declNo,CommContext.CHECKED);
		if(sysProcessLogEntity==null){
			sysProcessLogEntity=sceneDao.getSysProcessLogEntityByChecked(declNo, CommContext.HAVE_SAMPLE);
		}
		
		String processStatus="";
		if(sysProcessLogEntity!=null){
			Date date=sysProcessLogEntity.getOperDate();
			if(date!=null){
				List<SysProcessLogEntity> list=sceneDao.getSysProcessLogAfterChecked(declNo,date);
				if(Utils.notEmpty(list)){
					for(SysProcessLogEntity entity:list){
						processStatus+=entity.getProcessStatus()+",";
					}
				}
			}
		}
		
		if(processStatus.length()>0){
            //拟制、不合格、检务调回
            if(processStatus.indexOf(CommContext.WAIT_FICTION)!=-1||processStatus.indexOf(CommContext.VER_APP_N)!=-1||processStatus.indexOf(CommContext.DISQUR_RELEAS)!=-1
                    ||processStatus.indexOf(CommContext.VER_APP_Y)!=-1||processStatus.indexOf(CommContext.SELF_CHECK_S)!=-1||processStatus.indexOf(CommContext.MUTI_CHECK)!=-1){
                return true;           
            }
		}
		return false;
	}

	/**
	* <p>描述:保存附件路径到数据库</p>
	* @param entity 附件实体
	* @author 才江男
	 */
	public void saveFile(InsDeclLobEntity entity) {
		sceneDao.saveFile(entity);
	}
	
	/**
	* <p>描述: 获取附件</p>
	* @param declNo 报检单号
	* @param userCode 用户代码
	* @return 附件
	* @author 才江男
	 */
	public List<FileVo> loadFile(String path, String declNo, String userCode, String flag) {
		List<DspFileAttach> paths = sceneDao.loadFile(declNo, userCode, flag);
		List<FileVo> files = new ArrayList<FileVo>();
		FileVo vo;
		String file;
		if(CollectionUtils.isNotEmpty(paths)) {
			for (DspFileAttach insDeclLobEntity : paths) {
				file = path + "/" + insDeclLobEntity.getFileId();
				vo = new FileVo();
				vo.setPath(file);
				vo.setName(insDeclLobEntity.getFileName());
				if(null != file) {
					files.add(vo);
				}
			}
			
			return files;
		}
		return null;
	}
	
	/**
	* <p>描述: 审单进入现场查验</p>
	* @param declNo 报检号
	* @param receiverDocCode 接单员代码
	* @param flowPathStatus 主辅检标志
	* @author 才江男
	 */
	public void examingToScene(String declNo, String receiverDocCode, String flowPathStatus) {
		sceneDao.examingToScene(declNo, receiverDocCode, flowPathStatus);
		SysUser sysUser = subOrReasDao.getSysUser(receiverDocCode);
		String userName="";
		String orgCode="";
		if (sysUser != null) {
			userName=sysUser.getUserName();
			orgCode=sysUser.getOrgCode();
		}
		
		//if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_MAIN)){
			//移动端查验流程日志
			SysAppProcessLog log = new SysAppProcessLog();
			if (sysUser != null) {
				log.setOperCode(receiverDocCode);
				log.setOperName(sysUser.getUserName());
				log.setTreaOrgCode(sysUser.getOrgCode());
			}
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			log.setDeclNo(declNo);
			log.setProcessNode(MobileCommContext.SPOT);
			log.setNodeMemo(MobileCommContext.SPOT_NAME);
			log.setProcessStatus(MobileCommContext.WAIT_CHECK);
			log.setStatusMemo(MobileCommContext.WAIT_CHECK_NAME);
			
			log.setRemark("由施检审单到现场查验");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = formatter.format(new Date());
			Date newDate;
			try {
				newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			dao.saveLog(log);
			
			statusControlUtils.updateProcess(declNo, MobileCommContext.SPOT, MobileCommContext.WAIT_CHECK, receiverDocCode);
		//}else if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_AUXILIARY)){
		//	statusControlUtils.writeAuxLog("", "", "", "", declNo, MobileCommContext.SPOT, MobileCommContext.WAIT_CHECK, "由施检审单到现场查验", receiverDocCode, userName, orgCode);
		//}
		
	}
	
	/**
	* <p>描述: 删除附件</p>
	* @param path 附件
	* @author 才江男
	 */
	public void delFile(String path) {
		sceneDao.delFile(path);
		sceneDao.delDspFile(path);
	}
	
	/**
	 * 结束现场查验
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void endScene(String declNo, String receiverDocCode, String flowPathStatus) {
		SysUser sysUser = subOrReasDao.getSysUser(receiverDocCode);
		String userName="";
		String orgCode="";
		if (sysUser != null) {
			userName=sysUser.getUserName();
			orgCode=sysUser.getOrgCode();
		}
		//if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_MAIN)){
			//移动端查验流程日志
			SysAppProcessLog log = new SysAppProcessLog();
			if (sysUser != null) {
				log.setOperCode(receiverDocCode);
				log.setOperName(sysUser.getUserName());
				log.setTreaOrgCode(sysUser.getOrgCode());
			}
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			log.setDeclNo(declNo);
			log.setProcessNode(MobileCommContext.RESULT);
			log.setNodeMemo(MobileCommContext.RESULT_NAME);
			log.setProcessStatus(MobileCommContext.END_SCENE);
			log.setStatusMemo(MobileCommContext.END_SCENE_NAME);
			log.setRemark("结束现场查验");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = formatter.format(new Date());
			Date newDate;
			try {
				newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			dao.saveLog(log);
			statusControlUtils.updateProcess(declNo, MobileCommContext.RESULT, MobileCommContext.END_SCENE, receiverDocCode);
		//}else if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_AUXILIARY)){
		//	statusControlUtils.writeAuxLog("", "", "", "", declNo, MobileCommContext.RESULT, MobileCommContext.END_SCENE, "结束现场查验", receiverDocCode, userName, orgCode);
		//}
		
		sceneDao.endScene(declNo, receiverDocCode, flowPathStatus);
	}
	
	/**
	 * 进入结果登记
	 * 
	 * @param declNo 报检号
	 * @param receiverDocCode 接单员代码
	 * @param flowPathStatus 主辅检标志
	 */
	public void enterResultRegister(HttpServletRequest request,HttpServletResponse response, String declNo, String receiverDocCode, String flowPathStatus) {
		sceneDao.enterResultRegister(declNo, receiverDocCode, flowPathStatus);
//		//辅施检回写，sum_sc表
//		if("801".equals(flowPathStatus) || "802".equals(flowPathStatus)) {
//			sendBackSum(request, response, declNo, flowPathStatus, receiverDocCode);
//		}
	}
	
	/**
	* <p>描述: 回写现场查验信息</p>
	* @param request
	* @param response
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param userCode 用户代码
	* @author 才江男
	 */
	private void sendBackSum(HttpServletRequest request,HttpServletResponse response, String declNo, String flowPathStatus, String userCode) {
		String orgCode = request.getParameter("orgCode");
		
		// 机构
		if (StringUtils.isEmpty(orgCode) || 6 > orgCode.length()) {
			return ;
		}
		// 机构
		String businessOrgCode = orgCode.substring(0, 2) + "0000";

		// 现场查验
		insResultSumHandel.getSendInsResultSum(request,
				response, declNo, flowPathStatus, userCode, orgCode,
				businessOrgCode);
	}
	
	/**
	* <p>描述: 回写数据</p>
	* @param declNo 报检号
	* @param flowPathStatus 主辅检标志
	* @param userCode 用户代码
	* @param orgCode 部门代码
	* @return 回写结果
	* @author 才江男
	 */
	public String sendBackData(HttpServletRequest request,HttpServletResponse response,String declNo,String flowPathStatus,String userCode,String orgCode) {
		
		//是否提交审核并审核完毕
		String checkAudit = checkAudit(declNo);
		if (StringUtils.isNotEmpty(checkAudit)) {
			return checkAudit;
		}
		// 机构
		if(6 > orgCode.length()) {
			return "操作失败";
		}
		// 机构
		String businessOrgCode = orgCode.substring(0, 2) + "0000";

		// 现场查验
		String msgCheck = insResultSumHandel.getSendInsResultSum(request,response,declNo,
				flowPathStatus, userCode, orgCode, businessOrgCode);
		if (StringUtils.isNotEmpty(msgCheck)
				&& msgCheck.contains("<RESULT_DESC>")) {
			int indexStart = msgCheck.indexOf("<RESULT_DESC>");
			int indexEnd = msgCheck.indexOf("</RESULT_DESC>");
			msgCheck = msgCheck.substring(indexStart + 13, indexEnd);
		}

		// 布控反馈
		DclOrdFeedbackMainEntity backMain = ordService.getOrdFeedBackMain(declNo, "16");
		String msgFeedBack = "";
		if (null != backMain) {
			msgFeedBack = dclOrdFeedBackMainHandel.getSendDclOrdFeedBackMain(
					request,response,backMain.getFeedbackMainNo(), businessOrgCode);
			if (StringUtils.isNotEmpty(msgFeedBack)
					&& msgFeedBack.contains("<RESULT_DESC>")) {
				int indexStart = msgFeedBack.indexOf("<RESULT_DESC>");
				int indexEnd = msgFeedBack.indexOf("</RESULT_DESC>");
				msgFeedBack = msgFeedBack.substring(indexStart + 13, indexEnd);
			}
		}

		// 拼接返回信息
		String msg = "操作失败";
		if (StringUtils.isNotEmpty(msgCheck)) {
			msg = msgCheck;
		}
		if (StringUtils.isNotEmpty(msgFeedBack)) {
			msg += msgFeedBack;
		}
		if(StringUtils.isNotEmpty(msg) && msg.contains("!")){
			msg = msg.replaceAll("!", "");
		}
		
		// 移动端查验流程日志
		writeLog(declNo, userCode,flowPathStatus);
		
		return msg;
	}
	
	/**
	* <p>描述: 移动端查验流程日志</p>
	* @param declNo 报检号
	* @param userCode 用户代码
	* @author 才江男
	 */
	private void writeLog(String declNo, String userCode,String flowPathStatus) {
		SysUser sysUser = subOrReasService.getSysUser(userCode);
		String userName="";
		String companyCode="";
		if (sysUser != null) {
			userName=sysUser.getUserName();
			companyCode=sysUser.getOrgCode();
		}
		//if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_MAIN)){
			// 移动端查验流程日志
			SysAppProcessLog log = new SysAppProcessLog();
			
			if (sysUser != null) {
				log.setOperCode(userCode);
				log.setOperName(sysUser.getUserName());
				log.setTreaOrgCode(sysUser.getOrgCode());
			}
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			log.setDeclNo(declNo);
			log.setProcessNode(MobileCommContext.EVALUATE);
			log.setNodeMemo(MobileCommContext.EVALUATE_NAME);
			log.setProcessStatus(MobileCommContext.WAIT_VER_APP);
			log.setStatusMemo(MobileCommContext.WAIT_VER_APP_NAME);
			log.setRemark("数据回写");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = formatter.format(new Date());
			Date newDate;
			try {
				newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			processService.savelog(log);
			statusControlUtils.updateProcess(declNo, MobileCommContext.EVALUATE,
					MobileCommContext.WAIT_VER_APP, userCode);
		//}else if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_AUXILIARY)){
		//	statusControlUtils.writeAuxLog("", "", "", "", declNo, MobileCommContext.EVALUATE, MobileCommContext.WAIT_VER_APP, "数据回写", userCode, userName, companyCode);
		//}
	}
	
	/**
	* <p>描述: 报检单是否提交审核</p>
	* @param declNo 报检号
	* @return
	* @author 才江男
	 */
	public String checkAudit(String declNo) {
		InsDeclReview declReview = checkAuditdao.findAuditByDeclNo(declNo);
		if(null != declReview && !"4".equals(declReview.getProcessStatus())) {
			return "请先施检审核";
		}
		return "";
	}

	/**
	* <p>描述:判断当前报检单有无集装箱</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public boolean getDclIoDeclGoodsContEntitys(String declNo) {
		List<DclIoDeclContDetailEntity> list=sceneDao.getDclIoDeclGoodsContEntitys(declNo);
		if(Utils.notEmpty(list)){
			return true;
		}
		return false;
	}
	
	/**
	* <p>描述: 获取主辅施检标志</p>
	* @param expImpFlag 出入境标志
	* @param exeInspOrgCode 所属部门
	* @param receiverDocCode 接单员
	* @param declNo 报检号
	* @return 主辅施检标志
	* @author 才江男
	 */
	public String getflowPathStatusByDeclNo(String expImpFlag, String exeInspOrgCode, String receiverDocCode,
			String declNo) {
		return sceneDao.getflowPathStatusByDeclNo(expImpFlag, exeInspOrgCode, receiverDocCode, declNo);
	}
	
	/**
	* <p>描述:回写数据</p>
	* @param declNo 报检号
	* @param userCode 接单员
	* @param orgCode 所属部门
	* @return 数据回写结果
	* @author 才江男
	 */
	public String auditSendBack(HttpServletRequest request,HttpServletResponse response,String declNo, String userCode, String orgCode) {
		//出入境标志
		String expImpFlag = declNo.substring(0, 1);
		//获取主辅施检标志
		String flowPathStatus = getflowPathStatusByDeclNo(expImpFlag, orgCode, userCode, declNo);
		if(StringUtils.isEmpty(flowPathStatus)) {
			return "不存在主辅施检标志";
		}
		// 回写，并返回结果
		String msg = sendBackData(request,response,declNo, flowPathStatus, userCode, orgCode);
        
		SysUser sysUser = subOrReasService.getSysUser(userCode);
		String userName="";
		String companyCode="";
		if (sysUser != null) {
			userName=sysUser.getUserName();
			companyCode=sysUser.getOrgCode();
		}
		
		//if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_MAIN)){
			// 移动端查验流程日志
			SysAppProcessLog log = new SysAppProcessLog();
			if (sysUser != null) {
				log.setOperCode(userCode);
				log.setOperName(sysUser.getUserName());
				log.setTreaOrgCode(sysUser.getOrgCode());
			}
			log.setProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
			log.setDeclNo(declNo);
			log.setProcessNode(MobileCommContext.RESULT);
			log.setNodeMemo(MobileCommContext.RESULT_NAME);
			log.setProcessStatus(MobileCommContext.INS_RESULT);
			log.setStatusMemo(MobileCommContext.INS_RESULT_NAME);
			log.setRemark("提交结果登记信息");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = formatter.format(new Date());
			Date newDate;
			try {
				newDate = formatter.parse(dateString);
				log.setOperDate(newDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			processService.savelog(log);
			statusControlUtils.updateProcess(declNo, MobileCommContext.RESULT, MobileCommContext.INS_RESULT, userCode);
		//}else if(StringUtils.equals(flowPathStatus,CommContext.FLOW_PATH_STATUS_AUXILIARY)){
		//	statusControlUtils.writeAuxLog("", "", "", "", declNo, MobileCommContext.RESULT, MobileCommContext.INS_RESULT, "提交结果登记信息", userCode, userName, companyCode);
		//}

		
		return msg;
	}

	/**
	* <p>描述:根据报检单号查询所有集装箱信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public List<InsContainerResultEntity> findInsContainerResultListByDeclNo2(String declNo) {
		return sceneDao.findInsContainerResultListByDeclNo(declNo);
	}

	/**
	* <p>描述:获取用户展示现场查验记录的逻辑判断</p>
	* @param declNo
	* @param procedureCode
	* @return
	* @author 吴有根
	*/
	public Map<String, Object> getLoginUserPermission(String declNo,String userCode,String orgCode, String procedureCode) {
		Map<String, Object> limtsMap=new HashMap<String, Object>();
		//接单员代码
		String receiverDocCode=userCode;
		//施检机构代码
		String inspOrgCode=orgCode;
		//主辅施检流程状态
		String flowPathStatusFlag=null;
		//工作内容
		String workContent=null;
		//辅施检内容类别代码串
        String inspCountCodes = null;
       //辅检是否有鉴定处理工作内容
        String identifyUserCode = null;
        //辅检是否包含隔离检疫工作内容
        String isolationUserCode = null;
        //是否包含货物的检疫和检验
        String isIncludeGoodsCont = null;
		//主施检记录
		InsDeclMagEntity insDeclMagEntity=sceneDao.getMainInsMag(declNo,InsContext.FLOW_PATH_STATUS_MAIN,inspOrgCode);
		
		//主施检记录不为null,为主施检
		 if (insDeclMagEntity != null) {
	            //设定局部位置 上的流程状态
	            flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_MAIN;
	            //辅施检信息集合
	            List<InsDeclMagEntity> insDeclMagEntityList = sceneDao.queryInsDeclMagStatus(declNo,
	                    InsContext.FLOW_PATH_STATUS_AUXILIARY,
	                    true);
	            //拼接施检内容类别代码串
	            inspCountCodes = spellString(insDeclMagEntityList, declNo, receiverDocCode);
	            //主施检内容代码串
	            String mainInspCountCodes = returnPermissionStr(insDeclMagEntity, null, declNo, insDeclMagEntity.getReceiverDocCode());
	            if (StringUtils.isNotEmpty(mainInspCountCodes) && StringUtils.isNotEmpty(inspCountCodes)) {
	                workContent = "当前登录人为主施检员" + mainInspCountCodes + " 辅施检:" + inspCountCodes;
	            } else if (StringUtils.isEmpty(mainInspCountCodes) && StringUtils.isNotEmpty(inspCountCodes)) {
	                workContent = "当前登录人为主施检员" + mainInspCountCodes + " 辅施检:" + inspCountCodes;
	            } else if (StringUtils.isEmpty(mainInspCountCodes) && StringUtils.isEmpty(inspCountCodes)) {
	                workContent = "当前登录人为主施检员" + mainInspCountCodes;
	            } else if (StringUtils.isNotEmpty(mainInspCountCodes) && StringUtils.isEmpty(inspCountCodes)) {
	                workContent = "当前登录人为主施检员" + mainInspCountCodes;
	            }
	        } else {//查找辅施捡(此时登录的用户是辅施捡人员)
	            //设定局部位置 上的流程状态
	            flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_AUXILIARY;
	            //辅施检权限
	            insDeclMagEntity = sceneDao.getjudgeLoginDeptIsChecked(declNo, inspOrgCode, flowPathStatusFlag);
	            if (insDeclMagEntity == null) {
	                flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE;
	                insDeclMagEntity = sceneDao.getjudgeLoginDeptIsChecked(declNo, inspOrgCode, flowPathStatusFlag);
	            }
	            String receiver = insDeclMagEntity == null ? "" : insDeclMagEntity.getReceiverDocCode();
	            //拼接施检内容类别代码串
	            inspCountCodes = returnPermissionStr(insDeclMagEntity, null, declNo, receiver);
	            //主施检工作内容
	            List<InsDeclMagEntity> insDeclMagEntityList = sceneDao.queryInsDeclMagStatus(declNo, InsContext.FLOW_PATH_STATUS_MAIN, false);
	            String mainInspCountCodes = null;
	            if (CollectionUtils.isNotEmpty(insDeclMagEntityList)) {
	                mainInspCountCodes = returnPermissionStr(insDeclMagEntityList.get(0), null, declNo, insDeclMagEntityList.get(0).getReceiverDocCode());
	            }

	            if (insDeclMagEntity != null) {
	                if (StringUtils.isNotEmpty(inspCountCodes) && StringUtils.isNotEmpty(mainInspCountCodes)) {
	                    workContent = "当前登录人为辅施检员" + inspCountCodes + " 主施检:" + mainInspCountCodes;
	                } else if (StringUtils.isNotEmpty(inspCountCodes) && StringUtils.isEmpty(mainInspCountCodes)) {
	                    workContent = "当前登录人为辅施检员" + inspCountCodes;
	                } else if (StringUtils.isEmpty(inspCountCodes) && StringUtils.isNotEmpty(mainInspCountCodes)) {
	                    workContent = "当前登录人为辅施检员" + inspCountCodes + " 主施检:" + mainInspCountCodes;
	                }
	            }
	        }
	        limtsMap.put(SceneContext.INSP_COUNT_CODE, workContent);
	        limtsMap.put(SceneContext.INS_DECL_MAG, insDeclMagEntity);
	        limtsMap.put(SceneContext.FLOW_PATH_STATUS_MAIN, flowPathStatusFlag);
	        if (StringUtils.isNotEmpty(identifyUserCode)) {
	            limtsMap.put(SceneContext.GOODS_IDENTIFY, identifyUserCode);
	        }
	        if (StringUtils.isNotEmpty(isolationUserCode)) {
	            limtsMap.put(InsContext.ISOLATION_QUARANTINE, isolationUserCode);
	        }
	        if (StringUtils.isNotEmpty(isIncludeGoodsCont)) {
	            limtsMap.put(InsContext.SGOODS_QUARANTINE, isolationUserCode);
	        }

	        return limtsMap;
	}
	

	/**
	 * 
	* <p>描述:将所有的辅检权限拼成一个字符串</p>
	* @param list 所有的辅检数据
	* @param declNo
	* @param userCode
	* @return 辅检权限
	* @author 李云龙
	 */
    private String spellString(List<InsDeclMagEntity> list,
            String declNo,
            String userCode) {
        StringBuffer stringBuffer = new StringBuffer();
        List<String> permissionStrList = null;
        if (CollectionUtils.isNotEmpty(list)) {
            permissionStrList = new ArrayList<String>();
            for (InsDeclMagEntity insDeclMagEntity : list) {
                String returnPermissionStr = returnPermissionStr(insDeclMagEntity,
                        permissionStrList,
                        declNo,
                        insDeclMagEntity.getReceiverDocCode());
                stringBuffer.append(returnPermissionStr);
            }
        }
        return stringBuffer.toString();
    }
	
    /**
     * 
    * <p>描述:获取现场查验消息</p>
    * @param insDeclMagEntity
    * @param permissionStr
    * @param declNo
    * @param userCode
    * @return
    * @author 李云龙
     */
    private String returnPermissionStr(InsDeclMagEntity insDeclMagEntity,
            List<String> permissionStr,
            String declNo,
            String userCode) {
        //最终返回的消息
        String message = "";
        //机构+部门名称
        String orgDeptName = "";
        //辅检是否有鉴定处理工作内容
        String identifyUserCode = null;
        //是否包含货物的检疫和检验
        String isIncludeGoodsCont = null;
        //辅检是否包含隔离检疫工作内容
        String isolationUserCode = null;

        StringBuffer stringBuffer = new StringBuffer();
        boolean packagFlag = false;
        boolean containerFlag = false;
        boolean sgoodsFlag = false;
        boolean goodsCheckFlag = false;

        List<InsResultSumScEntity> insResultSumScEntitys = null;
        //施检mag实体为空时返回空字符
        if (insDeclMagEntity == null) {
            return message;
        }
        //by苏超-展示出施检机构+施检部门
        String orgName = codeToNameUtils.getOrgNameByCode(companyCodeUtils.getBusinessOrgCode(insDeclMagEntity.getExcInspDeptCode(),false));
        String deptName = codeToNameUtils.getOrgNameByCode(insDeclMagEntity.getExcInspDeptCode());
        if (orgName == null || "null".equals(orgName)) {
            orgName = "";
        }
        if (deptName == null || "null".equals(deptName)) {
            deptName = "";
        }
        orgDeptName = orgName + deptName;
        //记录当前登录人，登录机构+部门
        message = "[" + codeToNameUtils.getUserNameByCode(userCode) + "," + orgDeptName + "]";

        if (StringUtils.isNotEmpty(insDeclMagEntity.getInspContCodes())) {
            if (CollectionUtils.isEmpty(permissionStr)) {
                permissionStr = new ArrayList<String>();
            }
            String[] s = insDeclMagEntity.getInspContCodes().split(",");
            for (int x = 0; x < s.length; x++) {
                if (!permissionStr.contains(s[x])) {
                    permissionStr.add(s[x]);
                    if (StringUtils.equals(s[x], InsContext.GOODS_IDENTIFY)) {//货物鉴定
                        identifyUserCode = userCode;
                        boolean b = judgeIdentifyIsFinished(declNo);
                        if (b) {
                            stringBuffer.append(InsContext.GOODS_IDENTIFY_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.GOODS_IDENTIFY_NAME + "(未完成);");
                        }
                    }
                    //木质包装结果检疫按钮 "2"
                    if (StringUtils.equals(s[x], InsContext.WOOD_PACKAG_QUARANTINE)) {
                        insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getWoodpackQuarResult())) {
                                    packagFlag = true;
                                    break;
                                }
                            }
                        }
                        if (packagFlag) {
                            stringBuffer.append(InsContext.WOOD_PACKAG_QUARANTINE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.WOOD_PACKAG_QUARANTINE_NAME + "(未完成);");
                        }
                    }
                    //集装箱检疫结果按钮 "3"
                    if (StringUtils.equals(s[x], InsContext.CONTAINER_QUARANTINE)) {
                        if (CollectionUtils.isEmpty(insResultSumScEntitys)) {
                            insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        }
                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getContQuarResult())) {
                                    containerFlag = true;
                                    break;
                                }
                            }
                        }
                        if (containerFlag) {
                            stringBuffer.append(InsContext.CONTAINER_QUARANTINE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.CONTAINER_QUARANTINE_NAME + "(未完成);");
                        }
                    }
                    //货物检疫(检疫结果) "4"
                    if (StringUtils.equals(s[x], InsContext.SGOODS_QUARANTINE)) {
                        isIncludeGoodsCont = insDeclMagEntity.getReceiverDocCode();
                        if (CollectionUtils.isEmpty(insResultSumScEntitys)) {
                            insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        }

                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    sgoodsFlag = true;
                                    break;
                                }
                            }
                        }
                        if (sgoodsFlag) {
                            stringBuffer.append(InsContext.SGOODS_QUARANTINE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.SGOODS_QUARANTINE_NAME + "(未完成);");
                        }
                    }
                    //隔离检疫按钮 "5"
                    if (StringUtils.equals(s[x], InsContext.ISOLATION_QUARANTINE)) {
                        isolationUserCode = insDeclMagEntity.getReceiverDocCode();
                        InsIsolationQuarEntity insIsolationQuarEntity = sceneDao.getInsIsolationQuarEntityByNo(declNo);
                        if (insIsolationQuarEntity != null && StringUtils.isNotEmpty(insIsolationQuarEntity.getResultEvaluate())) {
                            stringBuffer.append(InsContext.ISOLATION_QUARANTINE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.ISOLATION_QUARANTINE_NAME + "(未完成);");
                        }

                    }
                    //货物检验 "6"
                    if (StringUtils.equals(s[x], InsContext.SGOODS_CHECKOUT_CODE)) {
                        isIncludeGoodsCont = insDeclMagEntity.getReceiverDocCode();
                        if (CollectionUtils.isEmpty(insResultSumScEntitys)) {
                            insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        }
                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    goodsCheckFlag = true;
                                    break;
                                }
                            }
                        }
                        if (goodsCheckFlag) {
                            stringBuffer.append(InsContext.SGOODS_CHECKOUT_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.SGOODS_CHECKOUT_NAME + "(未完成);");
                        }
                    }
                    //检验检疫 "7"
                    if (StringUtils.equals(s[x], InsContext.AUX_INS_QUAR_CODE)) {
                        isIncludeGoodsCont = insDeclMagEntity.getReceiverDocCode();
                        if (CollectionUtils.isEmpty(insResultSumScEntitys)) {
                            insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        }
                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    goodsCheckFlag = true;
                                    break;
                                }
                            }
                        }
                        if (goodsCheckFlag) {
                            stringBuffer.append(InsContext.AUX_INS_QUAR_CODE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.AUX_INS_QUAR_CODE_NAME + "(未完成);");
                        }
                    }
                    
                    //卫生检疫 "8"
                    if (StringUtils.equals(s[x], InsContext.AUX_INS_HEALTH_CODE)) {
                        isIncludeGoodsCont = insDeclMagEntity.getReceiverDocCode();
                        if (CollectionUtils.isEmpty(insResultSumScEntitys)) {
                            insResultSumScEntitys = judgeLoginUserIsChecked(declNo, userCode);
                        }
                        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
                            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    goodsCheckFlag = true;
                                    break;
                                }
                            }
                        }
                        if (goodsCheckFlag) {
                            stringBuffer.append(InsContext.AUX_INS_HEALTH_CODE_NAME + "(已完成);");
                        } else {
                            stringBuffer.append(InsContext.AUX_INS_HEALTH_CODE_NAME + "(未完成);");
                        }
                    }
                }
            }

            if (stringBuffer.length() > 0) {
                message += " 工作内容:" + stringBuffer.toString();
            }
        }
        return message;
    }
    
    /**
     * 
    * <p>描述:判断是否完成鉴定处理</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
    public boolean judgeIdentifyIsFinished(String declNo) {
        InsAuthenticateProcEntity insAuthenticateProcEntity = sceneDao.getInsAuthenticateProcEntity(declNo);
        if (insAuthenticateProcEntity != null && StringUtils.equals(CommContext.Y, insAuthenticateProcEntity.getIsAuthFlag())) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 根据报检单号和当前登录人来判断当前登录人是否保存过历史数据
     *
     * @param declNo
     * @param userCode
     * @param service
     * @return
     */
    public List<InsResultSumScEntity> judgeLoginUserIsChecked(String declNo, String userCode) {
        return sceneDao.getInsResultSumScEntity(declNo, userCode);
    }
    
	/**
	* <p>描述: 更新报检单权限-辅施检保存现场查验后，不可操作</p>
	* @param declNo 报检号
	* @author 才江男
	 */
	public void updatePriv(String declNo) {
		sceneDao.updatePriv(declNo);
	}
	
	/**
	 * <p>描述: 根据报检号、流程状态和流程环节获取移动端流程日志</p>
	 * @param declNo 报检号
	 * @author 张锡森
	 */
	public SysAppProcessLog getSysAppProcessLog(String declNo) {
		return sceneDao.getSysAppProcessLog(declNo);
	}

	/**
	* <p>描述:获取复审开关</p>
	* @param orgCode
	* @return
	* @author 吴有根
	*/
	public String getReCheckSwitchFlag(String orgCode,String configcode) {
		return sceneDao.getReCheckSwitchFlag(orgCode,configcode);
	}
	
	/**
	 * 存储文件以及获取文件ID（即存储文件名,老式方法）
	 * @param fileIDs
	 * @param request
	 */
	public void uploadFiles(HttpServletRequest request, String declNo, String userCode) {
		List<String> fileIDs = new ArrayList<String>();
		// 文件上传 -- 文件上传表ID filetTableId 文件存储ID-- fileIDs
		Map<String, MultipartFile> files = null;
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			// 获得文件：
			files = multipartRequest.getFileMap();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Set<Entry<String, MultipartFile>> sets = files.entrySet();
		Iterator<Entry<String, MultipartFile>> itr = sets.iterator();
		MultipartFile file = null;
		fileIDs = new ArrayList<String>();// 上传文件ID
		
		while (itr.hasNext()) {
			file = itr.next().getValue();
			String pre = UUIDKeyGeneratorUils.newInstance().generateKey().replaceAll("-", "");
			String suffix = file.getOriginalFilename().substring(
					file.getOriginalFilename().lastIndexOf("."));// 文件后缀名
			File f = null;
			try {
				f = File.createTempFile(pre, suffix);
				file.transferTo(f);
				FileManager fm = FileManagerHolder.getFileManager();
				byte[] fileByte = getFileToBytes(f);
				try {
					String fileId = fm.upload(fileByte, suffix);
					fileIDs.add(fileId);
					
					DspFileAttach attach = new DspFileAttach();
					attach.setFileAttachId(com.rongji.common.util.Utils.getuuid());
					attach.setFileName(file.getOriginalFilename());
					attach.setFileExt(suffix);
					attach.setFileId(fileId);
					attach.setFileSize(new BigDecimal(fileByte.length));
					senceCheckService.save(attach);
					
					InsDeclLob lob = new InsDeclLob();
					lob.setDeclLobId(com.rongji.common.util.Utils.getuuid());
					lob.setDeclNo(declNo);
					lob.setFileAttachId(attach.getFileAttachId());
					lob.setOperTime(new Date());
					lob.setOperCode(userCode);
					lob.setPath(fileId);
					senceCheckService.save(lob);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}
		
	}
	
	/**
	 * 将文件转换为byte数组
	 * @param file
	 * @return
	 */
	public static byte[] getFileToBytes(File file) {
		byte[] buffer = null;
		try {
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
			byte[] b = new byte[1000];
			int n;
			while ((n = fis.read(b)) != -1) {
				bos.write(b, 0, n);
			}
			fis.close();
			bos.close();
			buffer = bos.toByteArray();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer;
	}

	/**
	* <p>描述:由报检单号带出企业、生产批号等基本信息</p>
	* @param declNo
	* @return
	* @author 吴有根
	*/
	public List<DeclBaseInfoModel> loadBaseInfo(String declNo) {
		return sceneDao.loadBaseInfoByDeclNo(declNo);
	}

	/**
	* <p>描述:记录报检单回写记录信息</p>
	* @param declNo
	* @param userCode
	* @param request
	* @param response
	* @return
	* @author 吴有根
	*/
	public boolean recordCount(String declNo, String userCode, HttpServletRequest request,
			HttpServletResponse response) {
		DclProcessStatsEntity entity = sceneDao.getRecordCountByDeclNo(declNo);
		SysUser sysUser = subOrReasDao.getSysUser(userCode);
		String orgCode = companyCodeUtils.getLevelOrgCode(sysUser.getOrgCode());
		Date date=new Date();
		boolean boo=false;
		if (entity == null) {
			entity = new DclProcessStatsEntity();
			entity.setProcessStatsId(UUIDKeyGeneratorUils.newInstance().generateKey());
			entity.setOperCount("1");
			entity.setFirstOperDate(new Timestamp(date.getTime()));
			boo = declNoCountController.updateCount(orgCode,sysUser.getOrgCode(),new Date());
		}else {
			boo = true;
			entity.setOperCount(Integer.valueOf(entity.getOperCount())+1+"");
		}
		entity.setOperDate(new Timestamp(date.getTime()));
		entity.setDeclNo(declNo);
		entity.setOperCode(userCode);// 操作人员代码
		entity.setOrgCode(orgCode);
		entity.setOperName(sysUser != null ? sysUser.getUserName() : "");// 操作人员名称
		String operIp;
		try {
			operIp = this.getIp(request);
		} catch (Exception e) {
			e.printStackTrace();
			operIp = "unknow";
		}
		entity.setOperIp(operIp);
		//operIp="39.155.212.90";
		entity.setOperAddress(getIpAddr(operIp));// 地址
		entity.setOperNo(getOperNo(userCode));//操作号
		return sceneDao.recordCount(entity)&&boo;
	}
	
	private String getOperNo(String userCode) {
		String prefix = userCode + new SimpleDateFormat("yyyyMMdd").format(new Date());
		String suffix = "100000";
		List<String> list = sceneDao.getOperNoRul(prefix);
		if (Utils.notEmpty(list)) {
			ArrayList<String> list2 = new ArrayList<String>();
			list2.ensureCapacity(list.size());
			for (String str : list) {
				list2.add(str.substring(str.length() - 6, str.length()));
			}
			Integer integer = Integer.valueOf(Collections.max(list2)) + 1;
			return prefix + integer.toString();
		} else {
			userCode = prefix + suffix;
		}
		return userCode;

	}
	
	public String getIpAddr(String ip) {
		if ("unknow".equals(ip)) {
			return "unknowAddress";
		}

		String path = "http://ip.taobao.com/service/getIpInfo.php";
		String returnJson = this.getResult(path, "ip=" + ip, "utf-8");
		log.info("returnJson:"+returnJson);
		if(StringUtils.isNotEmpty(returnJson)) {
			JsonObject parser=new JsonParser().parse(returnJson).getAsJsonObject();
			if("0".equals(parser.get("code").toString())) {
				StringBuffer buffer=new StringBuffer();
				buffer.append(decodeUnicode(parser.get("data").getAsJsonObject().get("area").toString()));
				buffer.append("-"+decodeUnicode(parser.get("data").getAsJsonObject().get("region").toString()));
				buffer.append("-"+decodeUnicode(parser.get("data").getAsJsonObject().get("city").toString()));
				buffer.append("-"+decodeUnicode(parser.get("data").getAsJsonObject().get("isp").toString()));
				log.info("ipAdress:"+buffer.toString());
				return buffer.toString();
			}else {
				return "connect fail";
			}
		}
		return "";
	}
	
	
	private String getResult(String urlStr, String content, String encoding) {
		URL url = null;
		HttpURLConnection connection = null;
		try {
			url = new URL(urlStr);
			connection = (HttpURLConnection) url.openConnection();
			connection.setConnectTimeout(2000);// 连接超时时间
			connection.setReadTimeout(2000);//读取超时时间
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setRequestMethod("POST");
			connection.setUseCaches(false);// 是否使用缓存
			connection.connect();// 打开连接端口
			DataOutputStream out = new DataOutputStream(connection.getOutputStream());// 打开输出流往对端服务器写数据
			out.writeBytes(content);// 写数据
			out.flush();
			out.close();
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), encoding));
			StringBuffer buffer = new StringBuffer();
			String line = "";
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}
			reader.close();
			return buffer.toString();
		} catch (IOException e) {
			//e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();// 关闭连接
			}
		}
		return null;
	}  
	
	public static String decodeUnicode(String theString) {
		char aChar;
		int len = theString.length();
		StringBuffer buffer = new StringBuffer(len);
		for (int i = 0; i < len;) {
			aChar = theString.charAt(i++);
			if (aChar == '\\') {
				aChar = theString.charAt(i++);
				if (aChar == 'u') {
					int val = 0;
					for (int j = 0; j < 4; j++) {
						aChar = theString.charAt(i++);
						switch (aChar) {
						case '0':
						case '1':
						case '2':
						case '3':
						case '4':
						case '5':
						case '6':
						case '7':
						case '8':
						case '9':
							val = (val << 4) + aChar - '0';
							break;
						case 'a':
						case 'b':
						case 'c':
						case 'd':
						case 'e':
						case 'f':
							val = (val << 4) + 10 + aChar - 'a';
							break;
						case 'A':
						case 'B':
						case 'C':
						case 'D':
						case 'E':
						case 'F':
							val = (val << 4) + 10 + aChar - 'A';
							break;
						default:
							throw new IllegalArgumentException("字符转码异常");
						}
					}
					buffer.append((char) val);
				} else {
					if (aChar == 't') {
						aChar = '\t';
					}
					if (aChar == 'r') {
						aChar = '\r';
					}
					if (aChar == 'n') {
						aChar = '\n';
					}
					if (aChar == 'f') {
						aChar = '\f';
					}
					buffer.append(aChar);
				}

			} else {
				buffer.append(aChar);
			}
		}
		return buffer.toString();

	}  
	
	public String getIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip.equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : ip;
	}
}

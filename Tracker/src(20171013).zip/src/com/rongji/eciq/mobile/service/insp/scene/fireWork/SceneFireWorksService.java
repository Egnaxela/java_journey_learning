/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      weibo  
 * @version:     1.0
 * Createdate:   2017-7-20 下午2:41:21  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.scene.fireWork;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.dao.insp.scene.fireWork.SceneFireWorkDao;
import com.rongji.eciq.mobile.entity.InsResultRecord;
import com.rongji.eciq.mobile.entity.InsResultRecordItem;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     weibo 
 * @version:    1.0  
 * Create at:   2017-7-20 下午2:41:21  
 *  
 */
@Service
public class SceneFireWorksService {
	@Resource
	SceneFireWorkDao fireWorkDao;

	/**
	 * 
	* <p>描述:根据报检单号查询烟花查验单信息</p>
	* @param declNo
	* @return
	* @author weibo
	 */
	public InsResultRecord getInsResultRecord(String declNo){
		return fireWorkDao.getInsResultRecord(declNo);
	}
	
	/**
	 * 
	* <p>描述:根据记录单id查询检验项目</p>
	* @param resultRecordId
	* @return
	* @author weibo
	 */
	public List<InsResultRecordItem> getInsResultRecordItem(String resultRecordId){
		return fireWorkDao.getInsResultRecordItem(resultRecordId);
	}
	
	/**
	* <p>描述: 根据报检单号获取唛头-标记号码e-CIQ</p>
	* @param declNo 报检单号
	* @return 唛头
	* @author 才江男
	 */
	public String getMarkNoByDeclNo(String declNo) {
		return fireWorkDao.getMarkNoByDeclNo(declNo);
	}
	
	/**
	 * 
	* <p>描述:保存查验信息</p>
	* @param ins
	* @author weibo
	 */
	public void saveOrUpDate(InsResultRecord ins){
		fireWorkDao.saveOrUpDate(ins);
	}
	
	/**
	 * 
	* <p>描述:保存检验项目</p>
	* @param ins
	* @author weibo
	 */
	public void saveOrUpDateItem(InsResultRecordItem ins){
		fireWorkDao.saveOrUpDateItem(ins);
	}
}

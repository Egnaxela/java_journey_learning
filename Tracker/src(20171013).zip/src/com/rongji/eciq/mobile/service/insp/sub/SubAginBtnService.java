/**  
 * FileName:SubAginBtnService.java     
 * @Description: 施检再分单Service层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午11:28:46  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.sub;

import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.dao.insp.sub.SubAginBtnDao;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;

/**  
 * Description: 施检再分单Service层 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 上午11:28:46  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version  
 */
@Service
public class SubAginBtnService {
	@Resource
	SubAginBtnDao subAginBtnDao;

	
	/**
     * 根据报检号/施检机构代码查询重复的施检管理记录
     *
     * @param orgCode 施检机构代码
     * @param List<SubOrReasVO> 分单记录集合
     * @return 返回重复的施检管理记录,否则返回null
     */
    public SubOrReasEntity findRepeatInsMagByDeclNoOrgCode(List<SubOrReasEntity> list, String orgCode) {
        int rel;
        if (CollectionUtils.isNotEmpty(list)) {
            for (SubOrReasEntity vo : list) {
                rel = subAginBtnDao.getInsMagCountByDeclNoOrgCode(vo.getDeclNo(), orgCode);
                if (rel > 0) {
                    return vo;
                }
            }
        }
        return null;
    }
    
    
    /**
     * 出入境施检再分单
     *
     * @param orgCode 再分单机构代码
     * @param declMagId 报检单管理表id
     */
    public void againSubmenu(String declMagId, String orgCode, String orgCodePatch) {
    	 subAginBtnDao.againSubmenu(declMagId, orgCode, orgCodePatch);
    }
    
    /**
     * 更新结果表接单人/施检机构代码
     *
     * @param declNo 报检单号
     * @param orgCode 施检机构代码
     * @param recCode 施检接单人代码
     */
    public void updateInsResultSum(String declNo, String orgCode, String companyCode, String recCode) {
    	subAginBtnDao.updateInsResultSum(declNo, orgCode, companyCode, recCode);
    }
    
}

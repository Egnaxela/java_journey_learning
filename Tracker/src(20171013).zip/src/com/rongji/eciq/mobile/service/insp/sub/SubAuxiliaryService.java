/**  
 * FileName:SubAuxiliaryService.java     
 * @Description: 辅检分改单Service层
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午11:28:46  
 *  
 */ 
package com.rongji.eciq.mobile.service.insp.sub;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;

import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.dao.insp.sub.SubAuxiliaryDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.entity.InsAuthenticateProcEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsResultSumScEntity;
import com.rongji.eciq.mobile.entity.LoginLogInfo;
import com.rongji.eciq.mobile.utils.StringTools;
import com.rongji.eciq.mobile.vo.insp.InsDeclMagVo;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hwpf.model.SubdocumentType;
/**
 * 
 * Description: 辅检分改单Service层
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-2 下午3:44:12  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-2      李云龙                      1.0         修改根据报检单号查询贸易国别代码方法
 * 2017-08-04    李云龙                      1.0.0       添加根据报检单号与部门代码获得施检管理记录方法。 
 */
@Service
public class SubAuxiliaryService {
	@Resource
	SubAuxiliaryDao subAuxiliaryDao;
	@Resource
	SubOrReasDao subOrReasDao;
	
	
	/**
	 * 根据报检号查询报检单管理表
	 * @param declNo
	 * @return
	 */
	public InsDeclMagEntity findInsDeclMagEntity(String declNo){
		return subAuxiliaryDao.findInsDeclMagEntity(declNo);
	}
	
	
	
	/**
	 * 根据报检号查询出入境报检扩展信息
	 * @param declNo
	 * @return
	 */
	public DclIoDeclEx findDclIoDeclEx(String declNo){
		return subAuxiliaryDao.findDclIoDeclEx(declNo);
	}
	
	
	/**
	 * 根据报检号查国别代码
	 * @param declNo
	 * @return
	 */
	public String getTradeCountryCodeByDeclNo(String declNo){
		return subOrReasDao.getTradeCountryCodeByDeclNo(declNo);
	}
	
	/**
	 * 贸易国别代码转名称
	 * @param code
	 * @return
	 */
	public String getTradeCountryNameByCode(String code){
		return subOrReasDao.getTradeCountryNameByCode(code);
	}
	
	/**
	 * 根据企业分类代码获得企业分类名称
	 * @param declNo
	 * @return
	 */

	public String findEntTypeName(String code){
		return subAuxiliaryDao.findEntTypeName(code);
	}
	
	
	
	/**
     * 根据报检单号获得施检管理记录
     *
     * @param declNo 报检单号
     * @return List<InsDeclMagVO>
     */
	public List<InsDeclMagEntity> findInsDeclListByDeclNo(String declNo) {
		List<InsDeclMagEntity> list=subAuxiliaryDao.findInsDeclListByDeclNo(declNo);
        return list;
	}
	
	/**
     * 根据报检单号与部门代码获得施检管理记录
     *
     * @param declNo 报检单号
     * @return List<InsDeclMagVO>
     */
    public List<InsDeclMagEntity> findInsDeclListByDeclNoAndDeptCode(String declNo,String deptCode) {
    	return subAuxiliaryDao.findInsDeclListByDeclNoAndDeptCode(declNo, deptCode);
    }
	
	
	/**
	 * 根据机构代码查询机构名称
	 * @param orgCode
	 * @return
	 */
	public String getOrgCodeNameOrgCode(String orgCode){
		return subAuxiliaryDao.getOrgCodeNameOrgCode(orgCode);
	}
	
	 /**
     * 根据报检单号获得施检结果登记实体
     *
     * @param declNo 报检单号
     * @return InsResultSumEntity
     */
    public InsResultSumEntity findInsResultSumByDeclNo(String declNo) {
    	return subAuxiliaryDao.findInsResultSumByDeclNo(declNo);
    }
	
    /**
     * 辅施检选择证书后，过滤出主施检中相同的证书代码
     *
     * @param mainCertCodes 报检时所需证单代码
     * @param List<InsDeclMagVO> 辅施检InsDeclMagVO对象集合
     */
    public String[] repMainCert1(String mainCertCodes, List<InsDeclMagVo> list) {
        //主施检所需证单数组
        String[] mainCertCodeArray = StringTools.sptString(mainCertCodes, ",");
        //判断不为空
        if (CollectionUtils.isNotEmpty(list) && mainCertCodeArray != null
                && mainCertCodeArray.length > 0) {
            for (InsDeclMagVo vo : list) {
                for (int i = 0; i < mainCertCodeArray.length; i++) {
                    //辅施检所需证单串
                    String auxCertTypeCodes = vo.getCertTypeCodes();
                    //辅施检所需证单数组
                    String[] auxCertTypeCodeArray = StringTools.sptString(auxCertTypeCodes, ",");
                    //如果未复选证单
                    if (auxCertTypeCodeArray.length == 0) {
                        if (StringUtils.equals(auxCertTypeCodes, mainCertCodeArray[i])) {
                            mainCertCodeArray[i] = "";
                        }
                    } else {
                        int s = auxCertTypeCodeArray.length;
                        for (int j = 0; j < s; j++) {
                            if (StringUtils.equals(mainCertCodeArray[i], auxCertTypeCodeArray[j])) {
                                mainCertCodeArray[i] = "";
                            }
                        }
                    }
                }
            }
        }
        return getNotEmptyCert(mainCertCodeArray);
    }
    
    /**
     * 所需证单数据里的非空字符值的元素即是主施检最后的证书代码串
     *
     * @param certCodes 所需证单代码
     */
    public String[] getNotEmptyCert(String[] certCodes) {
        String[] array = new String[2];
        String newCertCode = "";
        String newCertName = "";
        if (certCodes != null && certCodes.length > 0) {
            for (String code : certCodes) {
                if (StringUtils.isNotEmpty(code)) {
                    newCertName += subAuxiliaryDao.getIOFCertBillNameName(code) + ",";
                    newCertCode = newCertCode + code + ",";
                }
            }
            if (newCertCode.length() > 0) {
                newCertCode = newCertCode.substring(0, newCertCode.length() - 1);
            }
            if (newCertName.length() > 0) {
                newCertName = newCertName.substring(0, newCertName.length() - 1);
            }
        }
        array[0] = newCertCode;
        array[1] = newCertName;
        return array;
    }
    
    /**
	 * 证单号转名称
	 * @param code
	 * @return
	 */
    public String getIOFCertBillNameName(String code){
    	return subAuxiliaryDao.getIOFCertBillNameName(code);
    }
    
    
    /**
     * 辅施检保存/更新主施检的所需证单代码串
     *
     * @param declNo 报检单号
     * @param certCodes 主施检申报证单代码串
     * @param ModifiedTableData 列表值变更对象
     */
    public void saveInsMag1(String declNo, String[] cert, String io, List<InsDeclMagEntity>  allList, boolean isHaveAux, HashMap<String, String> map,String sorgCode) {
    	// 加入辅施检增删改待办事项  暂未
    	
//    	//获取工作流水号     
//    	String workDeclNo;//工作流水号
//    	 if (CollectionUtils.isNotEmpty(allList)) {
//             for (InsDeclMagEntity v : allList) {
//                 workDeclNo = map.get(sorgCode);
//                 if (StringUtils.isEmpty(workDeclNo)) {
////                   workDeclNo = declNoLogic.createDeclNo(service.getEntityManager(), v.getExeInspOrgCode(),
////                             v.getSorgCode(), io, DeclContext.DECL_NULL);
//                     v.setDeclWorkNo(workDeclNo);
//                     map.put(sorgCode, workDeclNo);
//
//                 } else {
//                     v.setDeclWorkNo(workDeclNo);
//                 }
//             }
//         }
   
    	
    	
    	List<InsDeclMagEntity> list=subAuxiliaryDao.getInsDeclMagList(declNo);
    	List<InsDeclMagEntity> deleteList=new ArrayList<InsDeclMagEntity>();
    	
    	if(CollectionUtils.isNotEmpty(list)){
    		for(InsDeclMagEntity vo:list){
    			int i=0;
    			for(InsDeclMagEntity vv:allList){
    				if(vo.getDeclMagId().equals(vv.getDeclMagId())){
    					i=i+1;
    				}
    			}
    			if(i==0){
    				deleteList.add(vo);
    			}
    			
    		}
    		
    	}
 
    	subAuxiliaryDao.deleteInsMag(deleteList);//删除报检单管理表
    	subAuxiliaryDao.saveInsMag(allList);//保存新增/修改报检单管理表
    	subAuxiliaryDao.updateMainCertCodes1(declNo, cert);//主施检的所需证单更新
    	subAuxiliaryDao.updateIsHaveAux(declNo, isHaveAux);//更新是否存在辅检
    	
    	
    }
    
    
    
    
    /**
     * 判断此用户下的工作内容是否完成
     *
     */
    public boolean isFshInspWork(String declNo, String userCode, String inspWorkCodes) {

        boolean result = true;//总完成结果
        String[] s = null;
        //无工作内容则表示完成
        if (StringUtils.isEmpty(inspWorkCodes) || (s = inspWorkCodes.split(",")) == null || (s != null && s.length <= 0)) {
            return result;
        }
        for (int i = 0; i < s.length; i++) {

            if (result == false) {
                break;
            }

            //货物鉴定 "1"
            if (StringUtils.equals(s[i], InsContext.GOODS_IDENTIFY)) {
                result = isFshGoodsAuth(declNo);
            }
            //木质包装结果检疫按钮 "2"
            if (StringUtils.equals(s[i], InsContext.WOOD_PACKAG_QUARANTINE)) {
                result = isFshWoodQuar(declNo, userCode);
            }
            //集装箱检疫结果按钮 "3"
            if (StringUtils.equals(s[i], InsContext.CONTAINER_QUARANTINE)) {
                result = isFshContQuar(declNo, userCode);
            }
            //货物检疫(检疫结果) "4"
            if (StringUtils.equals(s[i], InsContext.SGOODS_QUARANTINE)) {
                result = isFshGoodsQuar(declNo, userCode);
            }
            //隔离检疫按钮 "5"
            if (StringUtils.equals(s[i], InsContext.ISOLATION_QUARANTINE)) {
                result = isFshIsolation(declNo);
            }
            //货物检验 "6"
            if (StringUtils.equals(s[i], InsContext.SGOODS_CHECKOUT_CODE)) {
                result = isFshGoodsInsp(declNo, userCode);
            }
            //检验检疫 "7"
            if (StringUtils.equals(s[i], InsContext.AUX_INS_QUAR_CODE)) {
                result = isFshInspQuar(declNo, userCode);
            }
            //卫生检疫 "8"
            if (StringUtils.equals(s[i], InsContext.AUX_INS_HEALTH_CODE)) {
                result = isFshInspQuar(declNo, userCode);
            }
        }
        return result;
    }
    
    /**
     * 判断货物鉴定是否完成
     *
     */
    public boolean isFshGoodsAuth(String declNo) {
    	InsAuthenticateProcEntity insAuthenticateProcEntity = subAuxiliaryDao.getInsAuthenticateProcEntity(declNo);
        if (insAuthenticateProcEntity != null && StringUtils.equals(CommContext.Y, insAuthenticateProcEntity.getIsAuthFlag())) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 辅施检保存/设置主施检状态
     *
     * @param mainVo 主施检管理记录vo
     * @param magVo 辅施检管理记录vo
     */
    public void setMainIns(InsDeclMagEntity mainVo, InsDeclMagEntity magVo,String businessOrgCode) {
        if (magVo != null && mainVo != null) {

            //主检的工作内容完成结果
            boolean mianWkRlt = isFshInspWork(mainVo.getDeclNo(), mainVo.getReceiverDocCode(), mainVo.getInspContCodes());
            //如果当前主检完成所有的工作内容后,转换后变成辅施检完成,否则变成辅施检
            String mainFls = InsContext.FLOW_PATH_STATUS_AUXILIARY;
            if (mianWkRlt) {
                mainFls = InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE;
            }
            
            InsDeclMagEntity entity=subAuxiliaryDao.getInsDeclMag(mainVo.getDeclNo(),mainVo.getExpImpFlag(),mainVo.getExcInspDeptCode());
            if(entity!=null){
            	mainVo.setDeclMagId(entity.getDeclMagId());
            }
            //将主施检状态更换为辅施检状态
            subAuxiliaryDao.saveEntity(mainVo, false);
            subAuxiliaryDao.updateFlowPathStatus(mainVo.getDeclMagId(), mainFls);
            HashMap<String, String> auxPriv = new HashMap<String, String>();
            if (StringUtils.equals(mainFls, InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE)) {
                auxPriv.put("SUB_PRIV", CommContext.N); //辅施检完成的报检单不允许在分单改派单界面展示 modify by 董方旭
                auxPriv.put("AUDIT_PRIV", CommContext.N);
                auxPriv.put("CHECK_PRIV", CommContext.Y);
                auxPriv.put("EVAL_PRIV", CommContext.N);
                auxPriv.put("UNQUA_PRIV", CommContext.N);
            } else if (StringUtils.equals(mainFls, InsContext.FLOW_PATH_STATUS_AUXILIARY)) {
                if (StringUtils.isNotEmpty(mainVo.getReceiverDocCode())) {
                    auxPriv.put("SUB_PRIV", CommContext.Y);
                    auxPriv.put("AUDIT_PRIV", CommContext.Y);
                    auxPriv.put("CHECK_PRIV", CommContext.Y);
                    auxPriv.put("EVAL_PRIV", CommContext.N);
                    auxPriv.put("UNQUA_PRIV", CommContext.N);
                } else {
                    auxPriv.put("SUB_PRIV", CommContext.Y);
                    auxPriv.put("AUDIT_PRIV", CommContext.N);
                    auxPriv.put("CHECK_PRIV", CommContext.Y);
                    auxPriv.put("EVAL_PRIV", CommContext.N);
                    auxPriv.put("UNQUA_PRIV", CommContext.N);
                }
            }
            subOrReasDao.updatePriv(mainVo.getDeclMagId(), auxPriv);
            if (StringUtils.isEmpty(magVo.getReceiverDocCode())) {
                magVo.setSubPriv(CommContext.Y);
                magVo.setAuditPriv(CommContext.N);
                magVo.setCheckPriv(CommContext.N);
                magVo.setEvalPriv(CommContext.N);
                magVo.setUnquaPriv(CommContext.N);
            } else {
                magVo.setSubPriv(CommContext.Y);
                magVo.setAuditPriv(CommContext.Y);
                //增加辅施检流程判断，判断是否处于现场查验环节 add by 董方旭
                if(!StringUtils.equals(magVo.getProcessStatus(), null) && magVo.getProcessStatus().compareTo("1015") >= 0 && StringUtils.equals(magVo.getCheckPriv(), CommContext.Y)){
                    magVo.setCheckPriv(CommContext.Y);
                }else{
                    magVo.setCheckPriv(CommContext.N);
                }
                magVo.setEvalPriv(CommContext.N);
                magVo.setUnquaPriv(CommContext.N);
            }
            //将辅施检状态更换为主施检状态
            magVo.setFlowPathStatus(InsContext.FLOW_PATH_STATUS_MAIN);
            InsDeclMagEntity entity1=subAuxiliaryDao.getInsDeclMag(magVo.getDeclNo(),magVo.getExpImpFlag(),magVo.getExcInspDeptCode());
            if(entity1!=null){
            	magVo.setDeclMagId(entity1.getDeclMagId());
            }
            subAuxiliaryDao.saveEntity(magVo, false);
              //初始化签证信息
//            if (mianWkRlt) {
//                InsDeclMagEntity entity = new InsDeclMagEntity();
//                BeanHelper.copyProperties(entity, mainVo);
//                entity.setFlowPathStatus(mainFls);
//                initVisa(mainVo.getDeclNo(), entity, mainVo.getExeInspOrgCode(), mainVo.getExpImpFlag(), false);
//            }
            
            //subAuxiliaryDao.updatDeclExFledOrgCode(magVo.getDeclNo(),businessOrgCode);
        }
    }
    
    
    /**
     * 判断木包检疫是否完成
     *
     *
     */
    public boolean isFshWoodQuar(String declNo, String userCode) {
        boolean woodsflag = false;//木包装完成标记
        List<InsResultSumScEntity> insResultSumScEntitys = subAuxiliaryDao.getInsResultSumScEntity(declNo, userCode);
        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                if (StringUtils.isNotEmpty(entity.getWoodpackQuarResult())) {
                    woodsflag = true;
                    break;
                }
            }
        }
        return woodsflag;
    }
    
    
    /**
     * 判断集装箱检疫是否完成
     *
     *
     */
    public boolean isFshContQuar(String declNo, String userCode) {

        boolean contflag = false; //集装箱检疫完成标记

        List<InsResultSumScEntity> insResultSumScEntitys = subAuxiliaryDao.getInsResultSumScEntity(declNo, userCode);
        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                if (StringUtils.isNotEmpty(entity.getContQuarResult())) {
                    contflag = true;
                    break;
                }
            }
        }
        return contflag;
    }
    
    /**
     * 判断货物检疫是否完成
     *
     *
     */
    public boolean isFshGoodsQuar(String declNo, String userCode) {

        boolean sgoodsFlag = false;
        List<InsResultSumScEntity> insResultSumScEntitys = subAuxiliaryDao.getInsResultSumScEntity(declNo, userCode);
        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                    sgoodsFlag = true;
                    break;
                }
            }
        }
        return sgoodsFlag;
    }
    
    /**
     * 判断隔离检疫是否完成
     *
     *
     */
    public boolean isFshIsolation(String declNo) {
        InsIsolationQuarEntity insIsolationQuarEntity = subAuxiliaryDao.getInsIsolationQuarEntityByNo(declNo);
        if (insIsolationQuarEntity != null && StringUtils.isNotEmpty(insIsolationQuarEntity.getResultEvaluate())) {
            return true;
        } else {
            return false;

        }
    }
    
    /**
     * 判断货物检验是否完成
     *
     *
     */
    public boolean isFshGoodsInsp(String declNo, String userCode) {
        boolean goodsCheckFlag = false;//货物检验标记
        List<InsResultSumScEntity> insResultSumScEntitys = subAuxiliaryDao.getInsResultSumScEntity(declNo, userCode);
        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                    goodsCheckFlag = true;
                    break;
                }
            }
        }
        return goodsCheckFlag;
    }
    
    /**
     * 判断检验检疫是否完成
     *
     *
     */
    public boolean isFshInspQuar(String declNo, String userCode) {
        boolean inspQuar = false;//检验检疫
        List<InsResultSumScEntity> insResultSumScEntitys = subAuxiliaryDao.getInsResultSumScEntity(declNo, userCode);
        if (CollectionUtils.isNotEmpty(insResultSumScEntitys)) {
            for (InsResultSumScEntity entity : insResultSumScEntitys) {
                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                    inspQuar = true;
                    break;
                }
            }
        }
        return inspQuar;
    }
    
    /**
     * 获取本机构的报检单管理表信息
    * <p>描述:</p>
    * @author 李云龙
     */
    public InsDeclMagEntity getInsDeclMag(String declNo,String expImpFlag,String orgCode){
    	return subAuxiliaryDao.getInsDeclMag(declNo, expImpFlag, orgCode);
    			
    }
    
    /**
     * 
    * <p>描述:根据报检号查询流程状态</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
    public String getProcessStatus(String declNo){
    	return subAuxiliaryDao.getProcessStatus(declNo);
    }


	/**
	* <p>描述:保存登录日志</p>
	* @param log
	* @author 夏晨琳
	*/
	public void saLog(LoginLogInfo log) {
		subAuxiliaryDao.saveLog(log);
	}
    
     
    
}

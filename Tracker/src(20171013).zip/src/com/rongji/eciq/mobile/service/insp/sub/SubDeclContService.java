/**  
 * FileName:    SubDeclContService.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      夏晨琳  
 * @version:     1.0
 * Createdate:   2017-10-11 下午2:40:21  
 *  
 */  

package com.rongji.eciq.mobile.service.insp.sub;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.util.Utils;
import com.rongji.eciq.mobile.dao.insp.sub.SubDeclContDao;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsCheckCommand;
import com.rongji.eciq.mobile.entity.InsCheckCommandCont;
import com.rongji.eciq.mobile.entity.InsContModel;
import com.rongji.eciq.mobile.entity.SysIfcCheckCommonModel;
import com.rongji.eciq.mobile.model.insp.sub.SubInsContModel;
import com.rongji.eciq.mobile.utils.UUIDKeyGeneratorUils;

/**  
 * Description: 分单改派单发送查验指令  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     夏晨琳  
 * @version:    1.0  
 * Create at:   2017-10-11 下午2:40:21  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-10-11      夏晨琳                      1.0         1.0 Version  
 */
@Service
public class SubDeclContService {
	
	@Autowired
	SubDeclContDao contDao;

	/**
	* <p>描述:根据报检单号获得所有集装箱</p>
	* @param declNo
	* @return
	* @author 夏晨琳
	*/
	public List<InsContModel> getContList(String declNo) {
		return contDao.getContList(declNo);
	}

	/**
	* <p>描述:通过报检号/集装箱号获得所关联货物信息集合</p>
	* @param declNo
	* @param contNo
	* @return
	* @author 夏晨琳
	*/
	public List<DclIoDeclGoodsEntity> getGoodsList(String declNo, String contNo) {
		return contDao.getGoodsList(declNo,contNo);
	}

	/**
	* <p>描述:判断是否已经发送查验指令</p>
	* @param declNo
	* @param contNo
	* @param cntnrModeCode
	* @return
	* @author 夏晨琳
	*/
	public boolean findCheckCommandByContNo(String declNo, String contNo, String cntnrModeCode) {
		return contDao.findCheckCommandByContNo(declNo,contNo,cntnrModeCode);
	}

	/**
	* <p>描述:保存开掏箱设置</p>
	* @param addList
	* @author 夏晨琳
	*/
	public void saveBoxSet(List<SubInsContModel> addList,String operCode) {
		if(Utils.isEmpty(addList)){
			return;
		}
		contDao.saveBoxSet(addList,operCode);
	}

	/**
	* <p>描述: 将集装箱信息转换为查验集装箱信息</p>
	* @param checkCmdId
	* @param list
	* @return
	* @author 夏晨琳
	*/
	public List<InsCheckCommandCont> insContToCommandCont(String checkCmdId, List<SubInsContModel> list) {
		 List<InsCheckCommandCont> comdList = new ArrayList<InsCheckCommandCont>();
	        if (Utils.notEmpty(list)) {
	            InsCheckCommandCont commandVO;
	            for (SubInsContModel vo : list) {
	                commandVO = new InsCheckCommandCont();
	               // commandVO.setDeclNo(vo.getDeclNo());
	                commandVO.setContNo(vo.getContNo());
	                commandVO.setCheckCmdId(checkCmdId);
	                commandVO.setGoodsNos(vo.getGoodsNos());
	                commandVO.setGoodsNames(vo.getDeclGoodsCnames());
	                commandVO.setCheckCmdContId(UUIDKeyGeneratorUils.newInstance().generateKey());
	                commandVO.setCntnrModeCode(vo.getCntnrModeCode());
	                commandVO.setIsCheck(vo.getIsCheck());
	                commandVO.setIfOpenBox(vo.getIfOpenBox());
	                commandVO.setIfDrawBox(vo.getIfDrawBox());
	                //开掏箱设置
	                commandVO.setIsCheck(vo.isChekIs() ? "1":"0");
	                commandVO.setIfOpenBox(vo.isIfOpeBox() ?"1":"0");
	                commandVO.setIfDrawBox(vo.isIfDrwBox() ? "1":"0");

	               // commandVO.setIsChek(vo.isChekIs()+"");
	               // commandVO.setIfOpeBox(vo.isIfOpeBox()+"");
	               // commandVO.setIfDrwBox(vo.isIfDrwBox()+"");
	                comdList.add(commandVO);
	            }
	        }
	        return comdList;
	}

	/**
	* <p>描述:发送查验指令</p>
	* @param checkEntity
	* @param contList
	* @param list
	* @author 夏晨琳
	 * @param operCode 
	*/
	public void sendCommand(InsCheckCommand checkEntity, List<InsCheckCommandCont> contList, List<SubInsContModel> list, String operCode) {
		contDao.sendCommand(checkEntity,contList,list,operCode);
	}

	/**
	* <p>描述:查询查验场信息集合</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	 * @param fieldName 
	 * @param fieldNo 
	*/
	public List<SysIfcCheckCommonModel> queryInspList(String orgCode, String fieldNo, String fieldName) {
		return contDao.queryInspList(orgCode,fieldNo,fieldName);
	}

	

}

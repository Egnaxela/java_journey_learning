package com.rongji.eciq.mobile.service.insp.sub;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclIoDeclEx;
import com.rongji.eciq.mobile.entity.DclIoDeclGoodsEntity;
import com.rongji.eciq.mobile.entity.InsCheckItemEntity;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.entity.InsGoodsMonItemEntity;
import com.rongji.eciq.mobile.entity.InsIsolationQuarEntity;
import com.rongji.eciq.mobile.entity.InsMonItemEvalStdEntity;
import com.rongji.eciq.mobile.entity.InsOriaudiExcePbinfoEntity;
import com.rongji.eciq.mobile.entity.InsResultGoodsEntity;
import com.rongji.eciq.mobile.entity.InsResultSumEntity;
import com.rongji.eciq.mobile.entity.InsReturnReasonEntity;
import com.rongji.eciq.mobile.entity.RulBatchruleEntity;
import com.rongji.eciq.mobile.entity.SubOrReasEntity;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;
import com.rongji.eciq.mobile.model.insp.scene.GoodsResultRegisterModel;


/**
 * Description: 分单改派单service
 * @author  吴有根
 * @version 1.0
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------ 
 * 2017-04-14     李云龙                       1.0        添加updatePriv方法    
 * 2017-04-14     李云龙                       1.0        分单改派单---更新施检总结果表
 * 2017-04-14     李云龙                       1.0        分单改派单---更新施检总结果表
 * 2017-04-14     李云龙                       1.0        获取通用数据下发开关
 * 2017-04-14     李云龙                       1.0        根据人员代码查询名称
 * 2017-04-14     李云龙                       1.0        根据报检单号，查询管理表辅施检机构，并获取其直属局信息
 * 2017-04-14     李云龙                       1.0        记录辅施检流程日志
 * 2017-04-14     李云龙                       1.0        判断是否有锁
 * 2017-04-14     李云龙                       1.0        非报检单号解锁(业务主键)
 * 2017-04-14     李云龙                       1.0        添加判断人员与机构是否匹配
 * 2017-04-14     李云龙                       1.0        记录辅施检流程日志
 * 2017-04-14     李云龙                       1.0        将索引表写入异常补偿用户
 * 2017-04-14     李云龙                       1.0        根据报检号查询报检单管理表
 * 2017-05-12     李云龙                       1.0        根据报检号与施检部门获得出入境报检单基本信息
 * 2017-05-13     才江男                       1.0        不合格登记时，更新现场记录货物评定为不合格
 * 2017-06-06     魏波                            1.0        辅检完成公用方法
 */

@Service
//@Transactional
public class SubOrReasService {

	
	@Resource
	SubOrReasDao subOrReasDao;
	/**
	 * 
	 * @param declNo
	 * @param orgCode
	 * @param orgPath  机构路径
	 * @param subStatus
	 * @param recCode
	 * @param processStatus
	 * @param starDate
	 * @param endDate
	 * @param checkRequire
	 * @param consigneeCname
	 * @param expImpFlag
	 * @param entName  企业名称
	 * @param declRegName  报检单位名称【报检单位的名称】
	 * @param userOrgCode
	 * @return
	 */
	public List<SubOrReasEntity> querySubList(String declNo, String orgCode, String orgPath, String subStatus,
			String recCode, String processStatus, Date starDate, Date endDate, String checkRequire,
			String consigneeCname, String expImpFlag, String entName, String declRegName, String userOrgCode,String currentPage) {

		return subOrReasDao.querySubList(declNo, orgCode, orgPath, subStatus, recCode, processStatus, starDate, endDate,
				checkRequire, consigneeCname, expImpFlag, entName, declRegName, userOrgCode,currentPage);

	}
	
	/**
	 * 根据传递的报检单号进行分单改派单操作
	 * @param declNos
	 * @return
	 */
	public List<SubOrReasEntity> queryList(String declNos,String expImpFlag,String userOrgCode ) {
		return subOrReasDao.queryList(declNos,expImpFlag,userOrgCode);
	}

	/**
	 * 分单更新报检单主表信息
	 * @param entity
	 * @param userCode
	 */
	public void update(SubOrReasEntity entity,String userCode) {
		 subOrReasDao.update(entity,userCode);
	}
	
	/**
	 * 不合格登记保存
	 * @param model
	 * @return
	 */
	public boolean updateResiter(GoodsResultRegisterModel model, String declNo,String code,String type){
		boolean updateResiter = subOrReasDao.updateResiter(model,code,type);
		if(updateResiter) {
			updateRecordCheck(declNo);
		}
		return updateResiter;
	}
	
	/**
	* <p>描述: 不合格登记时，更新现场记录为货物评定为不合格</p>
	* @param declNo 报检号
	* @author 才江男
	 */
	public void updateRecordCheck(String declNo) {
		subOrReasDao.updateRecordCheck(declNo);
	}
	
	/**
     * 更新主检权限
    * <p>描述:</p>
    * @param declMagId
    * @param subBack
    * @author 李云龙
     */
	public void updatePriv(String declMagId, HashMap<String, String> subBack) {
		subOrReasDao.updatePriv(declMagId,subBack);
	}

	public void dltInsDelMagById(String declMagId) {
		subOrReasDao.dltInsDelMagById(declMagId);
	}

	public void updateIsHaveAux(String declNo, boolean b) {
		subOrReasDao.updateIsHaveAux(declNo,b);
	}

	/**
	 * 更新实体
	 * @param entity
	 * @param b
	 */
	public <T extends Serializable> void saveEntity(InsReturnReasonEntity entity, boolean b) {
		subOrReasDao.saveEntity(entity,b);
	}
	
	/**
	 * 更新MAG表的退单原因
	 * @param declMagId
	 * @param backReason
	 */
	public void updateBackReason(String declMagId, String backReason) {
		subOrReasDao.updateBackReason(declMagId,backReason);
	}

	public List<SubOrReasEntity> findInsDeclMagByFlowType2(String declNo) {
		return subOrReasDao.findInsDeclMagByFlowType2(declNo);
	}

	/**
	 * 根据报检单号查询货物信息带分页
	 * @param declNo
	 * @param currentPage
	 * @return
	 */
	public List<DclIoDeclGoodsEntity> queryGoodsListByDeclNo(String declNo,String currentPage) {
		return subOrReasDao.queryGoodsListByDeclNo(declNo,currentPage);
	}

	/**
	 * 根据审单查看-布控信息
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	public List<InsOriaudiExcePbinfoEntity> findInsOriaudiExcePbinfo(String declNo, String goodsNo) {
		return subOrReasDao.findInsOriaudiExcePbinfo(declNo,goodsNo);
	}

	/**
	 * 查找货物监控项目
	 * @param declNo
	 * @param goodsNo
	 * @return
	 */
	public List<InsGoodsMonItemEntity> findGoodsItemsByGoodsNo(String declNo, String goodsNo) {
		return subOrReasDao.findGoodsItemsByGoodsNo(declNo,goodsNo);
	}

	/**
	 * 获得监管货物评定标准对象集合
	 * @param monItemId
	 * @return
	 */
	public List<InsMonItemEvalStdEntity> findInsMonItemEvalStdEntityById(String monItemId) {
		return subOrReasDao.findInsMonItemEvalStdEntityById(monItemId);
	}

	/**
	 * 获得表单名称
	 * @param monItemId
	 * @return
	 */
	public String getRulCtlitemFormName(String monItemId) {
		return subOrReasDao.getRulCtlitemFormName(monItemId);
	}

	/**
	 * 获取法规标题串
	 * @param insMonStdList
	 * @return
	 */
	public String getlegalBasisTitles(List<InsMonItemEvalStdEntity> insMonStdList) {
		String legalBasisTitles = "";
		if(Utils.notEmpty(insMonStdList)){
			String lawStdNo=insMonStdList.get(0).getLawStdNo();
			legalBasisTitles=subOrReasDao.getRule2(lawStdNo);
		}
		if(StringUtils.isNotEmpty(legalBasisTitles)){
			legalBasisTitles+="...";
		}
		return legalBasisTitles;
	}

	/**
	 * 根据报检号获取报检基本信息
	 * @param declNo
	 * @return
	 */
	public DclIoDeclEx getInsDeclInfo(String declNo) {
		return subOrReasDao.getInsDeclInfo(declNo);
	}

	/**
	 * 加载法定抽批规则
	 * @param countryCode
	 * @param ciqCode
	 * @param expImpFlag
	 * @param entMgrCode
	 * @return
	 */
	public List<RulBatchruleEntity> queryRuleList(String countryCode, String ciqCode, String expImpFlag,
			String entMgrCode,String userOrgCode) {
		
		String entCategory =subOrReasDao.getEntCategory(entMgrCode, expImpFlag);
		String riskGradeCode=subOrReasDao.getRiskGradeCode(entMgrCode, expImpFlag, ciqCode);
		return subOrReasDao.queryRuleList2(countryCode,userOrgCode,ciqCode,expImpFlag,entCategory,riskGradeCode);
	}

	/**
	 * 判断人员与机构是否匹配
	 * @param orgCode
	 * @param userCode
	 * @return
	 */
	public boolean isUserByOrg(String orgCode, String userCode) {
		return subOrReasDao.isUserByOrg(orgCode, userCode);
	}
	
	
	/**
     * 判断是否有锁
     *
     * @param declNo 报检单号
     * @param status 流程状态
     * @return
     */
    public boolean getLocked(String declNo, String status){
    	boolean flag = false;
        List list = subOrReasDao.getLocked(declNo, status);
        if (!CollectionUtils.isEmpty(list)) {
            flag = true;
        }
        return flag;
    	
    }
    
    /**
     * 很据报检号，获得出入境报检单基本信息
     *
     * @param declNo 报检号
     * @return 出入境报检单基本信息
     */
    public DclIoDeclEntity getDeclDetails(String declNo) {
    	return subOrReasDao.getDeclDetails(declNo);
    }
    
    /**
     * 
    * <p>描述:根据报检号与施检部门获得出入境报检单基本信息</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
    public DclIoDeclEntity getDclIoDeclEntity(String declNo) {
    	return subOrReasDao.getDclIoDeclEntity(declNo);
    	
    }
    
    /**
     * 分单改派单按钮--更新报检单管理表
     * @param sql
     */
    public void updateInsDeclMag(String deptCode,String time,String userCode,String recCode,String declMagId){
    	subOrReasDao.updateInsDeclMag( deptCode, time, userCode, recCode, declMagId);
    	
    }
    
    /**
     * 非报检单号加锁(业务主键)
     *
     * @param uuid
     * @param service
     */
    public void comLock(String uuid,String userCode,String orgCode) {
    	subOrReasDao.comLock(uuid, userCode, orgCode);
    }
    
    /**
     * 非报检单号解锁(业务主键)
     *
     * @param uuid
     */
    public void comUnLock(String uuid) {
    	subOrReasDao.comUnLock(uuid);
    }
    
    
    /**
     * 分单改派单---更新施检总结果表
     */
    public void updateInsResultSum(String recCode,String orgCode,String declNo){
    	subOrReasDao.updateInsResultSum( recCode, orgCode, declNo);
    }
    
    /**
     * 更新流程日志表
    * <p>描述:</p>
    * @param declNo
    * @param remark
    * @author 李云龙
     */
    public void updateRecerByProcessLog(String declNo, String remark) {
    	subOrReasDao.updateRecerByProcessLog(declNo, remark);
    }
    
    /**
	  * 获取报检单管理表信息
	 * <p>描述:</p>
	 * @param declNo
	 * @return
	 * @author 李云龙
	  */
    public InsDeclMagEntity getMainDeclMag(String declNo) {
    	return subOrReasDao.getMainDeclMag(declNo);
    }
    
    /**
	 * 获取机构代码串
	* <p>描述:</p>
	* @param orgCode
	* @return
	* @author 李云龙
	 */
    public String getOrgPathByOrgCode(String orgCode) {
    	return subOrReasDao.getOrgPathByOrgCode(orgCode);
    }
    
    /**
     * 根据报检单号，查询管理表辅施检机构，并获取其直属局信息
     *
     * @param declNo
     * @return
     */
    public List<String> getAuxOrgs(String declNo) {
    	return subOrReasDao.getAuxOrgs(declNo);
    }
    
    /**
     * 保存实体
     *
     * @param obj
     */
    public void saveObject(Object obj) {
    	subOrReasDao.saveObject(obj);
    }
    
    
    /**
     * 记录辅施检流程日志
     *
     */
    public void writeAuxLog(String exeInspOrgCode, String excInspDeptCode, String inspContCodes, String insDclMagId, String declNo, String processLink, String processstatus, String remark, UserInfo user){
    	subOrReasDao.writeAuxLog(exeInspOrgCode, excInspDeptCode, inspContCodes, insDclMagId, declNo, processLink, processstatus, remark, user);
    }
    
    /**
	  * 获取用户信息
	 * <p>描述:</p>
	 * @param userCode
	 * @return
	 * @author 李云龙
	  */
    public SysUser getSysUser(String userCode){
    	return subOrReasDao.getSysUser(userCode);
    }
  
   
   /**
	 * 根据人员代码查询名称
	 * @param orgCode
	 * @return
	 */
	public String getUserNameUserCode(String code){
		return subOrReasDao.getUserNameUserCode(code);
	}
	
	/**
	 * 更新实体
	 * @param InsCheckItemEntity
	 * @param b
	 */
	public  void updateEntity(InsCheckItemEntity entity) {
		subOrReasDao.updateEntity(entity);
	}
	
	/**
	 * 更新实体
	 * @param InsResultGoodsEntity
	 * @param b
	 */
	public  void updateEntity(InsResultGoodsEntity entity) {
		subOrReasDao.updateEntity(entity);
	}
	
	/**
	 * 
	* <p>描述:</p>
	* @param userCode 用户id
	* @param companyCode 部门
	* @param declNo 报检号
	* @param flowPathStatus
	* @return
	* @author 魏波
	 */
	public InsDeclMagEntity judgeLoginUser(String userCode,String companyCode,String declNo,String flowPathStatus){
		return subOrReasDao.judgeLoginUser(userCode, companyCode, declNo, flowPathStatus);
		
	}
	
//	 /**
//     * 判断是否完成鉴定处理
//     *
//     * @param declNo
//     * @return
//     */
//    public boolean judgeIdentifyIsFinished(String declNo) {
//
//
//        InsAuthenticateProcEntity insAuthenticateProcEntity = subOrReasDao.getInsAuthenticateProcEntity(declNo);
//        if (insAuthenticateProcEntity != null && StringUtils.equals("1", insAuthenticateProcEntity.getIsAuthFlag())) {
//            return true;
//        } else {
//            return false;
//        }
//    }
	
    
    public InsIsolationQuarEntity getInsIsolationQuarEntityByNo(String declNo){
    	return subOrReasDao.getInsIsolationQuarEntityByNo(declNo);
    }
    
    public List<InsResultSumEntity> getInsResultSumScEntity(String declNo, String userCode) {
    	return subOrReasDao.getInsResultSumScEntity(declNo, userCode);
    }
    
    public void updateInsDeclMagEntity1(String userCode,String companyCode,String declNo,String flowPathStatus){
    	subOrReasDao.updateInsDeclMagEntity1(userCode, companyCode, declNo, flowPathStatus);
    }
	/**
     * 辅检完成公用方法
     * 
     * @param declNo 
     * @param userInfo 当前登录人信息
     * @param flowPathStatus 主辅施检状态
     * @param service 
     */
    public  void judgeLoginUserIsChecked(String declNo,
    		SysUser userInfo,
            String flowPathStatus) {
        //主辅施捡流程状态
        String flowPathStatusFlag = null;
//        InsResultSumEntity insResultSumEntity;
        List<InsResultSumEntity> insResultSumEntitys = null;
        InsDeclMagEntity insDeclMagEntity = null;
        if (StringUtils.isEmpty(flowPathStatus)) {
            //查找主施捡
            insDeclMagEntity =subOrReasDao.judgeLoginUser(userInfo.getUserCode(),
                    userInfo.getOrgCode(), declNo, InsContext.FLOW_PATH_STATUS_MAIN);
            //如果insDeclMagEntity不为空的话,说明当前登录的是主施捡人员,否则是辅施捡人员登录
            if (insDeclMagEntity != null) {
                //设定局部位置 上的流程状态
                flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_MAIN;
            } else {
                //设定局部位置 上的流程状态
                flowPathStatusFlag = InsContext.FLOW_PATH_STATUS_AUXILIARY;
            }
        } else {
            flowPathStatusFlag = flowPathStatus;
        }

        //当前登录的人是辅施检
        if (StringUtils.equals(InsContext.FLOW_PATH_STATUS_AUXILIARY, flowPathStatusFlag)) {
            insDeclMagEntity = subOrReasDao.judgeLoginUser(userInfo.getUserCode(),null,declNo, 
                    InsContext.FLOW_PATH_STATUS_AUXILIARY);
            if (insDeclMagEntity != null && StringUtils.isNotEmpty(insDeclMagEntity.getInspContCodes())) {
                //判断辅施检是否完成标记
                boolean packagFlag = false;
                boolean containerFlag = false;
                boolean sgoodsFlag = false;
                boolean goodsCheckFlag = false;
                boolean insQuarFlag = false;
                boolean healthFlag = false;
                //当前登录人的施检内容代码串
                String inspContCodes = insDeclMagEntity.getInspContCodes();
                String[] splitInspContCodes = inspContCodes.split(",");
                StringBuffer stringBuffer = new StringBuffer();
                for (int x = 0; x < splitInspContCodes.length; x++) {
                    stringBuffer.append(splitInspContCodes[x]);
                }
                if (StringUtils.isNotEmpty(stringBuffer.toString())) {
                    String inspCountCodes = stringBuffer.toString();
                    //木质包装结果检疫按钮 "2"
                    if (!inspCountCodes.contains(InsContext.WOOD_PACKAG_QUARANTINE)) {
                        packagFlag = true;
                    }
                    //集装箱检疫结果按钮 "3"
                    if (!inspCountCodes.contains(InsContext.CONTAINER_QUARANTINE)) {
                        containerFlag = true;
                    }
                    //货物检疫(检疫结果) "4"
                    if (!inspCountCodes.contains(InsContext.SGOODS_QUARANTINE)) {
                        sgoodsFlag = true;
                    }
                    
                    //货物检验---------------bysuchao
                    if (!inspCountCodes.contains(InsContext.SGOODS_CHECKOUT_CODE)) {
                        goodsCheckFlag = true;
                    }
                    //检验检疫---------------bysuchao
                    if (!inspCountCodes.contains(InsContext.AUX_INS_QUAR_CODE)) {
                        insQuarFlag = true;
                    }
                    
                    //卫生检疫---------------bysuchao
                    if (!inspCountCodes.contains(InsContext.AUX_INS_HEALTH_CODE)) {
                        healthFlag = true;
                    }
                }

                for (int x = 0; x < splitInspContCodes.length; x++) {
                    if (StringUtils.equals(InsContext.WOOD_PACKAG_QUARANTINE, splitInspContCodes[x])) {//木质包装
                        //查询sum表
//                        insResultSumEntity = sceneLogic.getInsResultSumEntityByNo(declNo, service);
                        insResultSumEntitys = subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getWoodpackQuarResult())) {
                                    packagFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!packagFlag) {
                            break;
                        }
                    }
                    if (StringUtils.equals(InsContext.CONTAINER_QUARANTINE, splitInspContCodes[x])) {//集装箱
                        if (CollectionUtils.isEmpty(insResultSumEntitys)) {
                        	insResultSumEntitys = subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        }
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getContQuarResult())) {
                                    containerFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!containerFlag) {
                            break;
                        }
                    }
                    if (StringUtils.equals(InsContext.SGOODS_CHECKOUT_CODE, splitInspContCodes[x])) {//货物检验
                        if (CollectionUtils.isEmpty(insResultSumEntitys)) {
                        	insResultSumEntitys = subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        }
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    goodsCheckFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!goodsCheckFlag) {
                            break;
                        }
                    }
                    if (StringUtils.equals(InsContext.SGOODS_QUARANTINE, splitInspContCodes[x])) {//检疫结果
                        if (CollectionUtils.isEmpty(insResultSumEntitys)) {
                        	insResultSumEntitys = subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        }
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    sgoodsFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!sgoodsFlag) {
                            break;
                        }

                    }
                    
             if (StringUtils.equals(InsContext.AUX_INS_QUAR_CODE, splitInspContCodes[x])) {//检验检疫

                        if (CollectionUtils.isEmpty(insResultSumEntitys)) {
                            insResultSumEntitys = subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        }
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    insQuarFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!insQuarFlag) {
                            break;
                        }

                    }
                                        
                   if (StringUtils.equals(InsContext.AUX_INS_HEALTH_CODE, splitInspContCodes[x])) {//卫生检验

                        if (CollectionUtils.isEmpty(insResultSumEntitys)) {
                        	insResultSumEntitys =subOrReasDao.getInsResultSumScEntity(declNo, userInfo.getUserCode());
                        }
                        if (!CollectionUtils.isEmpty(insResultSumEntitys)) {
                            for (InsResultSumEntity entity : insResultSumEntitys) {
                                if (StringUtils.isNotEmpty(entity.getCheckPlace())) {
                                    healthFlag = true;
                                    break;
                                }
                            }
                        }
                        if (!healthFlag) {
                            break;
                        }

                    }
                }
                //说明当前辅施检都已做完辅检工作
                if (packagFlag && containerFlag && sgoodsFlag && goodsCheckFlag 
                    &&healthFlag&&insQuarFlag){//
                        //修改辅施检人的状态为辅件完成
                	subOrReasDao.updateInsDeclMagEntity1(userInfo.getUserCode(), userInfo.getOrgCode(), declNo, InsContext.FLOW_PATH_STATUS_AUXILIARY_DONE);
                }

            }
        }
    }	
}

/**  
 * FileName:    DeclNoCountService.java 
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年9月12日 下午7:25:37  
 *  
 */  

package com.rongji.eciq.mobile.service.sys;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Page;
import com.rongji.eciq.mobile.dao.sys.DeclNoCountDao;
import com.rongji.eciq.mobile.entity.DclProcessCountEntity;
import com.rongji.eciq.mobile.entity.DclProcessStatsEntity;

/**  
 * Description: 数据统计服务层  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年9月12日 下午7:25:37  
 *  
 * Modification History:  
 * Date          Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-09-12     吴有根                       2.0         2.0 Version
 * 2017-09-14     夏晨琳                       2.0         统计各直属局每年，每月，每周，每天的报检单数量  
 */

@Service
public class DeclNoCountService {

	@Autowired
	DeclNoCountDao dao;

	/**
	* <p>描述:判断是否存在这个年份的</p>
	* @param orgCode
	* @param year
	* @return 
	* @author 夏晨琳
	*/
	public DclProcessCountEntity dclProcessIsExit(String deptCode, int year) {
		return dao.dclProcessIsExit(deptCode,year);
	}

	/**
	* <p>描述:保存</p>
	* @param dcl
	* @author  夏晨琳
	*/
	public void saveDclProcess(DclProcessCountEntity dcl) {
		dao.saveDclProcess(dcl);
	}

	/**
	* <p>描述:更新</p>
	* @param dcl
	* @param monthName
	* @param weekName
	* @param hourName
	* @author 夏晨琳
	 * @param isSameDay 
	 * @param isSameWeek 
	*/
	public boolean updateDclProcess(DclProcessCountEntity dcl, String monthName, String weekName, String hourName, boolean isSameWeek, boolean isSameDay) {
		try {
			 dao.updateDclProcess(dcl,monthName,weekName,hourName,isSameWeek,isSameDay);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	* <p>描述:获取数据集合</p>
	* @param orgCode
	* @return
	* @author 夏晨琳
	*/
	public List<DclProcessCountEntity> getDclProcessList(String orgCode) {
		return dao.getDclProcessList(orgCode);
	}

	/**
	* <p>描述:获取各直属局今年数量</p>
	* @param year
	* @return
	* @author 夏晨琳
	*/
	public List<DclProcessCountEntity> getNowYearCount(String year) {
		return dao.getNowYearCount(year);
	}

	/**
	* <p>描述:获取某直属局指定年份月份的报检单</p>
	* @param orgCode
	* @param month
	* @param year
	* @return
	* @author 夏晨琳
	 * @param page 
	 * @param day 
	 * @param hour 
	 * @param isAll 
	 * @param deptCode 
	*/
	public List<DclProcessStatsEntity> getDeclNoList(String orgCode, String month, String year, Page page, String hour, String day, String deptCode, boolean isAll) {
		return dao.getDeclNoList(orgCode,month,year,page,hour,day,deptCode,isAll);
	}

	/**
	* <p>描述:更新每天的数量</p>
	* @param dcl
	* @author 夏晨琳
	*/
	public void updateDay(DclProcessCountEntity dcl) {
		dao.updateDay(dcl);
	}
	
	/**
	* <p>描述:更新每周的数量</p>
	* @param dcl
	* @author 夏晨琳
	*/
	public void updateWeek(DclProcessCountEntity dcl) {
		dao.updateWeek(dcl);
	}

	/**
	* <p>描述:更新数量</p>
	* @param orgCode
	* @param year
	* @param isSameWeek
	* @param weekName
	* @param isSameDay
	* @param hourName
	* @author 夏晨琳
	 * @param monthName 
	*/
	public void updateCountForReDeclNo(String orgCode, int year, String monthName, boolean isSameWeek, String weekName, boolean isSameDay, String hourName) {
		dao.updateCountForReDeclNo(orgCode,year,monthName,isSameWeek,weekName,isSameDay,hourName);
	}

	/**
	* <p>描述:获取操作时间</p>
	* @param deptCode
	* @param year
	* @return
	* @author 夏晨琳
	*/
	public List<String[]> getDclOperDateCount(String deptCode, String year) {
		return dao.getDclOperDateCount(deptCode,year);
	}

	/**
	* <p>描述:获取今天所有数量</p>
	* @param deptCode
	* @param year
	* @param day
	* @return
	* @author 夏晨琳
	 * @param day2 
	*/
	public List<String[]> getDclDayCountCount(String deptCode, String year, String month, String day) {
		return dao.getDclDayCountCount(deptCode,year,month,day);
	}

	/**
	* <p>描述:获取每周的数量</p>
	* @param deptCode
	* @param year
	* @param firstDayOfWeek
	* @param lastDayOfWeek
	* @return
	* @author 夏晨琳
	 * @param lastDayOfWeek2 
	*/
	public List<String[]> getWeekDateCount(String deptCode, String year, String month, String firstDayOfWeek, String lastDayOfWeek) {
		return dao.getWeekDateCount(deptCode,year,month,firstDayOfWeek,lastDayOfWeek);
	}

	/**
	* <p>描述:</p>
	* @param orgCode
	* @param parseInt
	* @return
	* @author 夏晨琳
	 * @param isAll 
	 * @param deptCode2 
	*/
	public List<DclProcessCountEntity> getdclistByDeptCode(String orgCode, int year, String deptCode, boolean isAll) {
		return dao.getdclistByDeptCode(orgCode,year,deptCode,isAll);
	}
	
}

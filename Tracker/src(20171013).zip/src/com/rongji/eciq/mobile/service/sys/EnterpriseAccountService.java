/**  
 * FileName: EnterpriseAccountService.java    
 * @Description: 企业注册、登录、修改信息service
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年7月18日 上午9:42:33  
 *  
 */  

package com.rongji.eciq.mobile.service.sys;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.dao.sys.EnterpriseAccountDao;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.utils.HashMD5File;

/**  
 * Description: 企业注册、登录、修改信息service  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年7月18日 上午9:42:33  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年7月18日      吴有根                      1.0         1.0 Version  
 */

@Service
public class EnterpriseAccountService {

	private static final  String MD5Salt="rjkd;askd;lakdpqndnqnlw&*"; 
	@Autowired 
	EnterpriseAccountDao dao;
	
	/**
	* <p>描述:企业注册</p>
	* @param entOrgCode
	* @param entPWD
	* @return
	* @author 吴有根
	*/
	public String registerInfo(String entOrgCode, String entPWD) {
		List<EntBaseInfoEntity> list=dao.checkexist(entOrgCode);
		if(Utils.isEmpty(list)){
			return "该企业组织机构代码不存在！请检查填写是否正确或联系管理员";
		}
		String info=dao.registerInfo(entOrgCode,HashMD5File.getStringMD5(entPWD+MD5Salt));
		return StringUtils.equals(info, "1")?"":"注册失败";
	}

	/**
	* <p>描述:企业登录</p>
	* @param entOrgCode
	* @param entPWD
	* @return
	* @author 吴有根
	*/
	public Map<String, Object> loginInfo(String entOrgCode, String entPWD) {
		List<EntBaseInfoEntity> list=dao.checkexist(entOrgCode);
		Map<String, Object> map=new HashMap<String, Object>();
		if(Utils.isEmpty(list)){
			map.put("flag", false);
			map.put("data", "该企业组织机构代码不存在！请检查填写是否正确或联系管理员");
			return map;
		}
		String id=HashMD5File.getStringMD5(entPWD+MD5Salt);
		List<EntBaseInfoEntity> list2=dao.checkexist(entOrgCode,HashMD5File.getStringMD5(entPWD+MD5Salt));
		if(Utils.isEmpty(list2)){
			map.put("flag", false);
			map.put("data", "密码错误");
			return map;
		}else {
			map.put("flag", true);
			map.put("data", list2.get(0));
		}
		return map;
	}

	/**
	* <p>描述:保存实体</p>
	* @param entity
	* @author 吴有根
	 * @throws Throwable 
	*/
	public String saveObject(Object obj)  {
		EntBaseInfoEntity entity=(EntBaseInfoEntity)obj;
		
		List<EntBaseInfoEntity> list=dao.checkexist(entity.getEntOrgCode(),HashMD5File.getStringMD5(entity.getEntOrgPwd()+MD5Salt));
		EntBaseInfoEntity entity0=null;
		if(Utils.notEmpty(list)){
			entity0=list.get(0);
			entity0.setOperTime(new Date());
			entity0.setEntOrgPwd(HashMD5File.getStringMD5(entity.getEntOrgPwd()+MD5Salt));
		}else{
			return "操作失败,原密码错误";
		}
		dao.saveObject(entity0);
		return "";
	}

}

/**  
 * FileName: HomePageInfoService.java    
 * @Description: 首页待办信息service
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月19日 下午4:20:37  
 *  
 */  

package com.rongji.eciq.mobile.service.sys;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.mapping.Array;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sun.misc.BASE64Encoder;

import com.rongji.common.mfile.FileManager;
import com.rongji.common.mfile.FileManagerHolder;
import com.rongji.dfish.base.Utils;
import com.rongji.eciq.basic.service.FileService;
import com.rongji.eciq.entity.DspFileAttach;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.MobileCommContext;
import com.rongji.eciq.mobile.dao.sys.HomePageInfoDao;
import com.rongji.eciq.mobile.entity.InsDeclMagEntity;
import com.rongji.eciq.mobile.model.sys.SysHomePageTodoModel;


/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月19日 下午4:20:37  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年5月19日   吴有根                      1.0         1.0 Version 
 * 2017-08-30    才江男                      1.0         查询报检单回写记录信息  
 * 2017-08-31    才江男                      1.0         任务完成统计
 * 2017-09-01    李晨阳                      1.0         获取推广图片
 * 2017-09-12    才江男                      1.0         数据量统计
 */

@Service
public class HomePageInfoService {

	private static final Logger log=Logger.getLogger(HomePageInfoService.class);
	
	@Autowired
	private HomePageInfoDao dao;
	@Autowired
	private FileService fileServie;
	
	/**
	* <p>描述:</p>
	* @param userCode
	* @return
	* @author 吴有根
	*/
	public SysHomePageTodoModel getCount(String userCode,String userOrgCode) {
		List<InsDeclMagEntity> list= dao.getCount(userCode,userOrgCode);
		SysHomePageTodoModel model=new SysHomePageTodoModel();
		int IMP_PUMP_GROUP = 0;// 入境待分单
		int IMP_WAIT_INS_CHECK = 0;// 入境待施检审单
		int IMP_WAIT_CHECK = 0;// 入境待查验
		int IMP_WAIT_INS_RESULT = 0;// 入境待登记
		int IMP_WAIT_INSP_AUDIT = 0;// 入境待审核
		int IMP_WAIT_DEPT_AUDIT = 0;// 入境待科长审核
		int IMP_WAIT_SECT_AUDIT = 0;// 入境待处长审核

		int EXP_PUMP_GROUP = 0;// 出境待分单
		int EXP_WAIT_INS_CHECK = 0;// 出境待施检审单
		int EXP_WAIT_CHECK = 0;// 出境待查验
		int EXP_WAIT_INS_RESULT = 0;// 出境待登记
		int EXP_WAIT_INSP_AUDIT = 0;// 出境待审核
		int EXP_WAIT_DEPT_AUDIT = 0;// 出境待科长审核
		int EXP_WAIT_SECT_AUDIT = 0;// 出境待处长审核
		if(Utils.notEmpty(list)){
			log.info("size:"+list.size());
			long t1=System.currentTimeMillis();
			for(InsDeclMagEntity entity:list){
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.PUMP_GROUP)){
					IMP_PUMP_GROUP++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INS_CHECK)){
					IMP_WAIT_INS_CHECK++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_CHECK)){
					IMP_WAIT_CHECK++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INS_RESULT)){
					IMP_WAIT_INS_RESULT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INSP_AUDIT)){
					IMP_WAIT_INSP_AUDIT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_DEPT_AUDIT)){
					IMP_WAIT_DEPT_AUDIT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.IN_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_SECT_AUDIT)){
					IMP_WAIT_SECT_AUDIT++;
				}
				
				////////////
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.PUMP_GROUP)){
					EXP_PUMP_GROUP++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INS_CHECK)){
					EXP_WAIT_INS_CHECK++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_CHECK)){
					EXP_WAIT_CHECK++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INS_RESULT)){
					EXP_WAIT_INS_RESULT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_INSP_AUDIT)){
					EXP_WAIT_INSP_AUDIT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_DEPT_AUDIT)){
					EXP_WAIT_DEPT_AUDIT++;
				}
				if(StringUtils.equals(entity.getExpImpFlag(), CommContext.OUT_FLAG)
						&&StringUtils.equals(entity.getProcessStatus(), MobileCommContext.WAIT_SECT_AUDIT)){
					EXP_WAIT_SECT_AUDIT++;
				}
			}
			long t2=System.currentTimeMillis();
			log.info("case time:"+(t2-t1)+"ms");
			model.setIMP_PUMP_GROUP(IMP_PUMP_GROUP+"");
			model.setIMP_WAIT_INS_CHECK(IMP_WAIT_INS_CHECK+"");
			model.setIMP_WAIT_CHECK(IMP_WAIT_CHECK+"");
			model.setIMP_WAIT_INS_RESULT(IMP_WAIT_INS_RESULT+"");
			model.setIMP_WAIT_INSP_AUDIT(IMP_WAIT_INSP_AUDIT+"");
			model.setIMP_WAIT_DEPT_AUDIT(IMP_WAIT_DEPT_AUDIT+"");
			model.setIMP_WAIT_SECT_AUDIT(IMP_WAIT_SECT_AUDIT+"");
			
			model.setEXP_PUMP_GROUP(EXP_PUMP_GROUP+"");
			model.setEXP_WAIT_INS_CHECK(EXP_WAIT_INS_CHECK+"");
			model.setEXP_WAIT_CHECK(EXP_WAIT_CHECK+"");
			model.setEXP_WAIT_INS_RESULT(EXP_WAIT_INS_RESULT+"");
			model.setEXP_WAIT_INSP_AUDIT(EXP_WAIT_INSP_AUDIT+"");
			model.setEXP_WAIT_DEPT_AUDIT(EXP_WAIT_DEPT_AUDIT+"");
			model.setEXP_WAIT_SECT_AUDIT(EXP_WAIT_SECT_AUDIT+"");
			
		}
		return model;
		
	}


	/**
	 * 
	* <p>描述:首页待办事项查询</p>
	* @param userCode
	* @param userOrgCode
	* @return
	* @author 吴有根
	 */
	public SysHomePageTodoModel getCount2(String userCode, String userOrgCode,String privileges) {
		SysHomePageTodoModel model=new SysHomePageTodoModel();
		int IMP_PUMP_GROUP = 0;// 入境待分单
		int IMP_WAIT_INS_CHECK = 0;// 入境待施检审单
		int IMP_WAIT_CHECK = 0;// 入境待查验
		int IMP_WAIT_INS_RESULT = 0;// 入境待登记
		int IMP_WAIT_INSP_AUDIT = 0;// 入境待审核
		int IMP_WAIT_DEPT_AUDIT = 0;// 入境待科长审核
		int IMP_WAIT_SECT_AUDIT = 0;// 入境待处长审核

		int EXP_PUMP_GROUP = 0;// 出境待分单
		int EXP_WAIT_INS_CHECK = 0;// 出境待施检审单
		int EXP_WAIT_CHECK = 0;// 出境待查验
		int EXP_WAIT_INS_RESULT = 0;// 出境待登记
		int EXP_WAIT_INSP_AUDIT = 0;// 出境待审核
		int EXP_WAIT_DEPT_AUDIT = 0;// 出境待科长审核
		int EXP_WAIT_SECT_AUDIT = 0;// 出境待处长审核
		
		long t0=System.currentTimeMillis();
		//待分单
		IMP_PUMP_GROUP= dao.getCountPumpGroup(userCode,userOrgCode,"1");
		EXP_PUMP_GROUP= dao.getCountPumpGroup(userCode,userOrgCode,"2");
		
		//待审单
		IMP_WAIT_INS_CHECK= dao.getCountWaitInsCheck(userCode,userOrgCode,"1");
		EXP_WAIT_INS_CHECK= dao.getCountWaitInsCheck(userCode,userOrgCode,"2");

		//待查验
		IMP_WAIT_CHECK=dao.getCountWaitCheck(userCode, userOrgCode,"1");
		EXP_WAIT_CHECK=dao.getCountWaitCheck(userCode, userOrgCode,"2");
		
		//待登记
		IMP_WAIT_INS_RESULT=dao.getCountWaitInsResult(userCode, userOrgCode,"1");
		EXP_WAIT_INS_RESULT=dao.getCountWaitInsResult(userCode, userOrgCode,"2");
		
		//待审核
		IMP_WAIT_INSP_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"1","1");
		EXP_WAIT_INSP_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"2","1");
		
		//待科长审核
		IMP_WAIT_DEPT_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"1","2");
		EXP_WAIT_DEPT_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"2","2");
		
		//待处长审核
		IMP_WAIT_SECT_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"1","3");
		EXP_WAIT_SECT_AUDIT=dao.getCountWaitAudit(userCode, userOrgCode,"2","3");
		
//		List<PrivilegeModel> privilegeslist = sysUserMgrService.getUserPrivileges(userCode);
		

//		Gson gson=new GsonBuilder().create();
//		PrivilegeModel privilegeModel=null;
//		try {
//			 privilegeModel=gson.fromJson(privileges, PrivilegeModel.class);
//		} catch (Exception e) {
//			log.info("类型转换异常");
//		}
//		
		long t1=System.currentTimeMillis();
		log.info("sql query "+(t1-t0)+"ms");
		if (StringUtils.contains(privileges, "\"code\":\"121111\"")) {
			model.setIMP_PUMP_GROUP(IMP_PUMP_GROUP + "");
		} else {
			model.setIMP_PUMP_GROUP("-");
		}
		log.info("contains 121111 case "+ (System.currentTimeMillis()-t1));
		if (StringUtils.contains(privileges, "\"code\":\"121112\"")) {
			model.setIMP_WAIT_INS_CHECK(IMP_WAIT_INS_CHECK + "");
		} else {
			model.setIMP_WAIT_INS_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121113\"")) {
			model.setIMP_WAIT_CHECK(IMP_WAIT_CHECK + "");
		} else {
			model.setIMP_WAIT_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121160\"")) {
			model.setIMP_WAIT_INS_RESULT(IMP_WAIT_INS_RESULT + "");
		} else {
			model.setIMP_WAIT_INS_RESULT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121161\"")) {
			model.setIMP_WAIT_INSP_AUDIT(IMP_WAIT_INSP_AUDIT + "");
		} else {
			model.setIMP_WAIT_INSP_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121162\"")) {
			model.setIMP_WAIT_DEPT_AUDIT(IMP_WAIT_DEPT_AUDIT + "");
		} else {
			model.setIMP_WAIT_DEPT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121163\"")) {
			model.setIMP_WAIT_SECT_AUDIT(IMP_WAIT_SECT_AUDIT + ""); // 入境
		} else {
			model.setIMP_WAIT_SECT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121211\"")) {
			model.setEXP_PUMP_GROUP(EXP_PUMP_GROUP + ""); // 出境
		} else {
			model.setEXP_PUMP_GROUP("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121212\"")) {
			model.setEXP_WAIT_INS_CHECK(EXP_WAIT_INS_CHECK + "");
		} else {
			model.setEXP_WAIT_INS_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121213\"")) {
			model.setEXP_WAIT_CHECK(EXP_WAIT_CHECK + "");
		} else {
			model.setEXP_WAIT_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121260\"")) {
			model.setEXP_WAIT_INS_RESULT(EXP_WAIT_INS_RESULT + "");
		} else {
			model.setEXP_WAIT_INS_RESULT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121261\"")) {
			model.setEXP_WAIT_INSP_AUDIT(EXP_WAIT_INSP_AUDIT + "");
		} else {
			model.setEXP_WAIT_INSP_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121262\"")) {
			model.setEXP_WAIT_DEPT_AUDIT(EXP_WAIT_DEPT_AUDIT + "");
		} else {
			model.setEXP_WAIT_DEPT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"121263\"")) {
			model.setEXP_WAIT_SECT_AUDIT(EXP_WAIT_SECT_AUDIT + "");
		} else {
			model.setEXP_WAIT_SECT_AUDIT("-");
		}
		log.info("contains case "+(System.currentTimeMillis()-t1));
		
//		model.setIMP_PUMP_GROUP(IMP_PUMP_GROUP+"");
//		model.setIMP_WAIT_INS_CHECK(IMP_WAIT_INS_CHECK+"");
//		model.setIMP_WAIT_CHECK(IMP_WAIT_CHECK+"");
//		model.setIMP_WAIT_INS_RESULT(IMP_WAIT_INS_RESULT+"");
//		model.setIMP_WAIT_INSP_AUDIT(IMP_WAIT_INSP_AUDIT+"");
//		model.setIMP_WAIT_DEPT_AUDIT(IMP_WAIT_DEPT_AUDIT+"");
//		model.setIMP_WAIT_SECT_AUDIT(IMP_WAIT_SECT_AUDIT+"");
//		
//		model.setEXP_PUMP_GROUP(EXP_PUMP_GROUP+"");
//		model.setEXP_WAIT_INS_CHECK(EXP_WAIT_INS_CHECK+"");
//		model.setEXP_WAIT_CHECK(EXP_WAIT_CHECK+"");
//		model.setEXP_WAIT_INS_RESULT(EXP_WAIT_INS_RESULT+"");
//		model.setEXP_WAIT_INSP_AUDIT(EXP_WAIT_INSP_AUDIT+"");
//		model.setEXP_WAIT_DEPT_AUDIT(EXP_WAIT_DEPT_AUDIT+"");
//		model.setEXP_WAIT_SECT_AUDIT(EXP_WAIT_SECT_AUDIT+"");
		return model;
	}

	
	public SysHomePageTodoModel getCount3(String userCode, String userOrgCode,String privileges) {
		SysHomePageTodoModel model=new SysHomePageTodoModel();
		int IMP_PUMP_GROUP = 0;// 入境待分单
		int IMP_WAIT_INS_CHECK = 0;// 入境待施检审单
		int IMP_WAIT_CHECK = 0;// 入境待查验
		int IMP_WAIT_INS_RESULT = 0;// 入境待登记
		int IMP_WAIT_INSP_AUDIT = 0;// 入境待审核
		int IMP_WAIT_DEPT_AUDIT = 0;// 入境待科长审核
		int IMP_WAIT_SECT_AUDIT = 0;// 入境待处长审核

		int EXP_PUMP_GROUP = 0;// 出境待分单
		int EXP_WAIT_INS_CHECK = 0;// 出境待施检审单
		int EXP_WAIT_CHECK = 0;// 出境待查验
		int EXP_WAIT_INS_RESULT = 0;// 出境待登记
		int EXP_WAIT_INSP_AUDIT = 0;// 出境待审核
		int EXP_WAIT_DEPT_AUDIT = 0;// 出境待科长审核
		int EXP_WAIT_SECT_AUDIT = 0;// 出境待处长审核
		
		long t0=System.currentTimeMillis();
		//待分单
		List<Character> PUMP_GROUP_LIST=dao.getCountPumpGroup(userCode, userOrgCode);
		if(Utils.notEmpty(PUMP_GROUP_LIST)){
			for(Character s:PUMP_GROUP_LIST){
				if(StringUtils.equals(s+"", "1")){
					IMP_PUMP_GROUP++;
					continue;
				}
				if(StringUtils.equals(s+"", "2")){
					EXP_PUMP_GROUP++;
				}
			}
		}
		
		
		
		//待审单
		List<Character> WAIT_INS_CHECK_LIST=dao.getCountWaitInsCheck(userCode, userOrgCode);
		if(Utils.notEmpty(WAIT_INS_CHECK_LIST)){
			for(Character s:WAIT_INS_CHECK_LIST){
				if(StringUtils.equals(s+"", "1")){
					IMP_WAIT_INS_CHECK++;
					continue;
				}
				if(StringUtils.equals(s+"", "2")){
					EXP_WAIT_INS_CHECK++;
				}
			}
		}

		//待查验
		List<Character> WAIT_CHECK_LIST=dao.getCountWaitCheck(userCode, userOrgCode);
		if(Utils.notEmpty(WAIT_CHECK_LIST)){
			for(Character s:WAIT_CHECK_LIST){
				if(StringUtils.equals(s+"", "1")){
					IMP_WAIT_CHECK++;
					continue;
				}
				if(StringUtils.equals(s+"", "2")){
					EXP_WAIT_CHECK++;
				}
			}
		}
		
		//待登记
		List<Character> WAIT_INS_RESULT_LIST=dao.getCountWaitInsResult(userCode, userOrgCode);
		if(Utils.notEmpty(WAIT_INS_RESULT_LIST)){
			for(Character s:WAIT_INS_RESULT_LIST){
				if(StringUtils.equals(s+"", "1")){
					IMP_WAIT_INS_RESULT++;
					continue;
				}
				if(StringUtils.equals(s+"", "2")){
					EXP_WAIT_INS_RESULT++;
				}
			}
		}
		
		
		
		//待审核
		List<Object[]> AUDIT_LIST=dao.getCountWaitAudit2(userCode, userOrgCode);
	//	List<Character> WAIT_INSP_AUDIT_LIST=dao.getCountWaitAudit(userCode, userOrgCode,"1");
		if(Utils.notEmpty(AUDIT_LIST)){
			for(Object[] s:AUDIT_LIST){
				if(StringUtils.equals(s[0]+"","1")&&"1".equals(s[1])){
					IMP_WAIT_INSP_AUDIT++;
				}
				if(StringUtils.equals(s[0]+"","2")&&"1".equals(s[1])){
					EXP_WAIT_INSP_AUDIT++;
				}
				
				if(StringUtils.equals(s[0]+"","1")&&"2".equals(s[1])){
					IMP_WAIT_DEPT_AUDIT++;
				}
				if(StringUtils.equals(s[0]+"","2")&&"2".equals(s[1])){
					EXP_WAIT_DEPT_AUDIT++;
				}
				
				if(StringUtils.equals(s[0]+"","1")&&"3".equals(s[1])){
					IMP_WAIT_SECT_AUDIT++;
				}
				if(StringUtils.equals(s[0]+"","2")&&"3".equals(s[1])){
					EXP_WAIT_SECT_AUDIT++;
				}
			}
		}
		
		
		
		//待科长审核
//		List<Character> WAIT_DEPT_AUDIT_LIST=dao.getCountWaitAudit(userCode, userOrgCode,"2");
//		if(Utils.notEmpty(WAIT_DEPT_AUDIT_LIST)){
//			for(Character s:WAIT_DEPT_AUDIT_LIST){
//				if(StringUtils.equals(s+"", "1")){
//					IMP_WAIT_DEPT_AUDIT++;
//					continue;
//				}
//				if(StringUtils.equals(s+"", "2")){
//					EXP_WAIT_DEPT_AUDIT++;
//				}
//			}
//		}
//		
//		//待处长审核
//		List<Character> WAIT_SECT_AUDIT_LIST=dao.getCountWaitAudit(userCode, userOrgCode,"3");
//		if(Utils.notEmpty(WAIT_SECT_AUDIT_LIST)){
//			for(Character s:WAIT_SECT_AUDIT_LIST){
//				if(StringUtils.equals(s+"", "1")){
//					IMP_WAIT_SECT_AUDIT++;
//					continue;
//				}
//				if(StringUtils.equals(s+"", "2")){
//					EXP_WAIT_SECT_AUDIT++;
//				}
//			}
//		}
		

		long t1=System.currentTimeMillis();
		log.info("sql query "+(t1-t0)+"ms--------");
		if (StringUtils.contains(privileges, "\"code\":\"1202010100\"")) {
			model.setIMP_PUMP_GROUP(IMP_PUMP_GROUP + "");
		} else {
			model.setIMP_PUMP_GROUP("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010200\"")) {
			model.setIMP_WAIT_INS_CHECK(IMP_WAIT_INS_CHECK + "");
		} else {
			model.setIMP_WAIT_INS_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010300\"")) {
			model.setIMP_WAIT_CHECK(IMP_WAIT_CHECK + "");
		} else {
			model.setIMP_WAIT_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010400\"")) {
			model.setIMP_WAIT_INS_RESULT(IMP_WAIT_INS_RESULT + "");
		} else {
			model.setIMP_WAIT_INS_RESULT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010500\"")) {
			model.setIMP_WAIT_INSP_AUDIT(IMP_WAIT_INSP_AUDIT + "");
		} else {
			model.setIMP_WAIT_INSP_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010600\"")) {
			model.setIMP_WAIT_DEPT_AUDIT(IMP_WAIT_DEPT_AUDIT + "");
		} else {
			model.setIMP_WAIT_DEPT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202010700\"")) {
			model.setIMP_WAIT_SECT_AUDIT(IMP_WAIT_SECT_AUDIT + ""); // 入境
		} else {
			model.setIMP_WAIT_SECT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020100\"")) {
			model.setEXP_PUMP_GROUP(EXP_PUMP_GROUP + ""); // 出境
		} else {
			model.setEXP_PUMP_GROUP("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020200\"")) {
			model.setEXP_WAIT_INS_CHECK(EXP_WAIT_INS_CHECK + "");
		} else {
			model.setEXP_WAIT_INS_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020300\"")) {
			model.setEXP_WAIT_CHECK(EXP_WAIT_CHECK + "");
		} else {
			model.setEXP_WAIT_CHECK("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020400\"")) {
			model.setEXP_WAIT_INS_RESULT(EXP_WAIT_INS_RESULT + "");
		} else {
			model.setEXP_WAIT_INS_RESULT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020500\"")) {
			model.setEXP_WAIT_INSP_AUDIT(EXP_WAIT_INSP_AUDIT + "");
		} else {
			model.setEXP_WAIT_INSP_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020600\"")) {
			model.setEXP_WAIT_DEPT_AUDIT(EXP_WAIT_DEPT_AUDIT + "");
		} else {
			model.setEXP_WAIT_DEPT_AUDIT("-");
		}
		if (StringUtils.contains(privileges, "\"code\":\"1202020700\"")) {
			model.setEXP_WAIT_SECT_AUDIT(EXP_WAIT_SECT_AUDIT + "");
		} else {
			model.setEXP_WAIT_SECT_AUDIT("-");
		}
		log.info("contains case "+(System.currentTimeMillis()-t1)+"ms");
		
//		model.setIMP_PUMP_GROUP(IMP_PUMP_GROUP+"");
//		model.setIMP_WAIT_INS_CHECK(IMP_WAIT_INS_CHECK+"");
//		model.setIMP_WAIT_CHECK(IMP_WAIT_CHECK+"");
//		model.setIMP_WAIT_INS_RESULT(IMP_WAIT_INS_RESULT+"");
//		model.setIMP_WAIT_INSP_AUDIT(IMP_WAIT_INSP_AUDIT+"");
//		model.setIMP_WAIT_DEPT_AUDIT(IMP_WAIT_DEPT_AUDIT+"");
//		model.setIMP_WAIT_SECT_AUDIT(IMP_WAIT_SECT_AUDIT+"");
//		
//		model.setEXP_PUMP_GROUP(EXP_PUMP_GROUP+"");
//		model.setEXP_WAIT_INS_CHECK(EXP_WAIT_INS_CHECK+"");
//		model.setEXP_WAIT_CHECK(EXP_WAIT_CHECK+"");
//		model.setEXP_WAIT_INS_RESULT(EXP_WAIT_INS_RESULT+"");
//		model.setEXP_WAIT_INSP_AUDIT(EXP_WAIT_INSP_AUDIT+"");
//		model.setEXP_WAIT_DEPT_AUDIT(EXP_WAIT_DEPT_AUDIT+"");
//		model.setEXP_WAIT_SECT_AUDIT(EXP_WAIT_SECT_AUDIT+"");
		return model;
	}
	
	/**
	 * 
	* <p>描述:查询报检单回写记录信息</p>
	* @param sqlToDay 今日
	* @param sqlWeek 本周
	* @param sqlMonth 本月
	* @return
	* @author 才江男
	 */
	public Map jobDone(String userCode) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String date = format.format(new Date());
		String sqlToDay = date + " 00:00:00";
		String sqlEndDay = date + " 23:59:59";
		
		Calendar c = Calendar.getInstance();   
		//本周
		int d = 0;
		if(c.get(Calendar.DAY_OF_WEEK)==1){
			d = -6;
		}else{
			d = 2-c.get(Calendar.DAY_OF_WEEK);
		}
		c.add(Calendar.DAY_OF_WEEK, d);
		String sqlWeek = format.format(c.getTime()) + " 00:00:00";
		
		//本月
		c.add(Calendar.MONTH, 0);
		c.set(Calendar.DAY_OF_MONTH,1);//设置为1号,当前日期既为本月第一天 
		String first = format.format(c.getTime());
		String sqlMonth = first + " 00:00:00";
		
		return dao.jobDone(userCode, sqlToDay, sqlEndDay, sqlWeek, sqlMonth);
	}
	
	/*
	 * 判断是否更新
	 */
	public String[] isRefresh(String date){
		Object[] result = dao.getfile();
		String[] res = new String[result.length];
		res[0] = result[0].toString();
		res[1] = result[1].toString();
		res[2] = result[2].toString();
		boolean flag = date.equals(res[0]);
		if(flag){
			res[0] = "No";
		}
		return res;
	}
	
	
	/*
	 * 获取Base64编码的字节流文件
	 */
	public String[] getBase64Img(String fileIds){
		BASE64Encoder encoder = new BASE64Encoder();  
		FileManager fm = FileManagerHolder.getFileManager();
		DspFileAttach dfa;
		String[] id = fileIds.split(",");
		String[] img = new String[id.length];
		for(int i=0; i<id.length; i++){
			dfa = fileServie.getFileAttach(id[i]);
			// 对字节数组Base64编码  
			try {
				byte[] data = fm.download(dfa.getFileId());
				img[i] = encoder.encode(data);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return img;
	}
	
}

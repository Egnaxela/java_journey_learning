/**  
 * FileName:     
 * @Description: 公告信息服务类 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-12 上午10:29:18  
 *  
 */

package com.rongji.eciq.mobile.service.sys;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.rongji.eciq.mobile.dao.insp.sub.SubAuxiliaryDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.dao.sys.PortalNoticeDao;
import com.rongji.eciq.mobile.entity.SysAnnInfoMainEntity;

/**  
 * Description: 公告信息服务类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-12 上午10:29:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-12      李晨阳                      1.0         1.0 Version  
 */

@Service
public class PortalNoticeService {

	@Resource
	PortalNoticeDao portalNoticeDao;

	@Resource
	SubAuxiliaryDao subAuxiliaryDao;

	@Resource
	SubOrReasDao subOrReasDao;

	/**
	 * 
	 * <p>
	 * 描述: 获得公告信息
	 * </p>
	 * 
	 * @param annTitle
	 * @param currentPage
	 * @return
	 * @author 李晨阳
	 */
	public List<SysAnnInfoMainEntity> getPortalNotice(String annTitle, String currentPage) {
		List<SysAnnInfoMainEntity> noticeList = portalNoticeDao.getPortalNotice(annTitle, currentPage);
		if (!CollectionUtils.isEmpty(noticeList)) {
			for (SysAnnInfoMainEntity entity : noticeList) {
				entity.setIsueOrgCode(subAuxiliaryDao
						.getOrgCodeNameOrgCode(entity.getIsueOrgCode()));
				entity.setAnnIssuerCode(subOrReasDao.getUserNameUserCode(entity
						.getAnnIssuerCode()));
			}
		}
		return noticeList;

	}

	/**
	 * 
	 * <p>
	 * 描述:获得公告信息（备用）
	 * </p>
	 * 
	 * @param userCode
	 * @param userOrgCode
	 * @return
	 * @author 李晨阳
	 */
//	public List<SysAnnInfoMainEntity> getPortalNoticeList(String userCode,
//			String userOrgCode) {
//		// 获得用户所属带分类码的机构代码
//		String businOrgCode = companyCodeUtils.getBusinessOrgCode(userOrgCode,
//				false);
//		// 获得机构层级
//		int orgLevel = companyCodeUtils.getOrgDeptLevelByOrgCode(businOrgCode);
//		List<SysAnnInfoMainEntity> noticeList = portalNoticeDao
//				.getPortalNoticeList(orgLevel, businOrgCode, userOrgCode,
//						userCode);
//		return noticeList;
//	}
}

/**  
 * FileName:     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      李晨阳  
 * @version:     1.0
 * Createdate:   2017-5-25 上午9:30:17  
 *  
 */  

package com.rongji.eciq.mobile.service.sys;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.rj.dbxml.Db2XmlGenerator;
import com.rj.dbxml.DbXmlMappingFactory;
import com.rj.dbxml.Xml2DbExecutor;
import com.rj.dbxml.exception.DbXmlCoughtNoDataException;
import com.rj.dbxml.exception.DbXmlMappingException;
import com.rj.dbxml.xml2db.ExecuteResult;
import com.rongji.eciq.mobile.dao.sys.RetrieveInspDeclDao;
import com.rongji.system.quartz.utils.DataSourceUtil;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李晨阳  
 * @version:    1.0  
 * Create at:   2017-5-25 上午9:30:17  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-25      李晨阳                      1.0         1.0 Version
 * 2017-6-06      李晨阳                      1.0         解决连续调单报错  
 * 2017-6-06      才江男                      1.0         校验数据是否已同步过
 * 2017-6-19      李晨阳                      1.0         调整代码，独立mag表模板归档数据，解决相同主键引发的问题
 */

@Service
public class RetrieveInspDeclService {
	
	@Resource
	RetrieveInspDeclDao retrieveInspDeclDao;
	
	public static Logger logger = Logger
			.getLogger(RetrieveInspDeclService.class);

	// 模板报文名称
	private String dclReportType1 = "ITF_DCL_IO_DECL";
	private String dclReportType2 = "ITF_DCL_IO_DECL_APP";
	private String fbReportType1 = "ITF_DCL_ORD_FEEDBACK_MAIN";
	private String fbReportType2 = "ITF_DCL_ORD_FEEDBACK_MAIN_APP";
	private String ordReportType1 = "ITF_DCL_ORD_MAIN";
	private String ordReportType2 = "ITF_DCL_ORD_MAIN_APP";
	private String insReportType1 = "ITF_INS_RESULT_SUM";
	private String insReportType2 = "ITF_INS_RESULT_SUM_APP";
	private String magReportType1 = "ITF_INS_DECL_MAG";
	private String magReportType2 = "ITF_INS_DECL_MAG_APP";
	

	public String[] getDecl(String declNo){
		return retrieveInspDeclDao.getDecl(declNo);
	}
	
	/**
	* <p>描述:数据是否已同步过</p>
	* @param declNo 报检单号
	* @return
	* @author 才江男
	 */
	public String findDecl(String declNo) {
		return retrieveInspDeclDao.findDecl(declNo);
	}
	
	
	public String retrieveInspDecl(String declNo, String writeUsec) {
		ExecuteResult er = null;
		DataSource chgDataSource = DataSourceUtil
				.getDataSource(DataSourceUtil.CHAG_DATA_SOURCE);
		DataSource appServerSource = DataSourceUtil
				.getDataSource(DataSourceUtil.APP_DATA_SOUCE);
		Connection chgConn = null;
		Connection appConn = null;
		try {
			chgConn = chgDataSource.getConnection();
		} catch (SQLException e1) {
			logger.error("获取下发库联接异常!" + e1.getMessage(), e1);
		}
		try {
			appConn = appServerSource.getConnection();
		} catch (SQLException e1) {
			logger.error("获取移动平台数据库联接异常!" + e1.getMessage(), e1);
		}

//		String condition = " DECL_NO = '" + declNo + "' ";
		String condition2 = " DECL_NO = '" + declNo + "' and write_usec = '"+ writeUsec +"' ";
		String magCondition = " DECL_NO = '" + declNo + "' and trans_batch = (select max(trans_batch) from " + magReportType1 + " where decl_no = '" + declNo+ "') ";

		StringBuilder MSG = new StringBuilder();
		MSG.append("报检单号为："+ declNo +"\n");
		
		// 报检单管理表数据
		try {
			// 获取db2xml实例
			Db2XmlGenerator db2xml = DbXmlMappingFactory.getInstance()
					.getXmlGenerator(chgConn);// 源库
			// 传入应相模板与条件参数，产生数据报文
			String xml = db2xml.generateXml(magReportType1, magCondition, "IU"); // 获取xml2db实例
			String xml2 = xml.replace("ITF_", "");
			Xml2DbExecutor x2d = DbXmlMappingFactory.getInstance()
					.getXml2DbExecutor(appConn);
			// 使用xml2db进行数据持久化操作，根据操作类型参为进行相应操作：（I插入U更新D删除）
			er = x2d.getXml2Db(magReportType2, xml2, "IU", true);
			boolean sucFlag = er.isSuccess();
			logger.info("报检单管理表同步结果：报检单号为" + declNo + "处理" + sucFlag);
			if (sucFlag) {
				MSG.append("\n报检单管理表调取成功");
			} else {
				MSG.append("\n报检单管理表调取失败");
			}

		} catch (DbXmlCoughtNoDataException e) {
			e.printStackTrace();
			MSG.append("\n报检单管理表调取异常，请联系管理员");
			logger.info("报检单管理表数据同步结果：报检单号为" + declNo + "处理失败");
		} catch (DbXmlMappingException e) {
			e.printStackTrace();
		}
		// 报检单信息
		try {
			// 获取db2xml实例
			Db2XmlGenerator db2xml = DbXmlMappingFactory.getInstance()
					.getXmlGenerator(chgConn);// 源库
			// 传入应相模板与条件参数，产生数据报文
			String xml = db2xml.generateXml(dclReportType1, getConditionM(dclReportType1, declNo), condition2,"IU"); // 获取xml2db实例
			String xml2 = xml.replace("ITF_", "");
			Xml2DbExecutor x2d = DbXmlMappingFactory.getInstance()
					.getXml2DbExecutor(appConn);
			// 使用xml2db进行数据持久化操作，根据操作类型参为进行相应操作：（I插入U更新D删除）
			er = x2d.getXml2Db(dclReportType2, xml2, "IU", true);
			boolean sucFlag = er.isSuccess();
			logger.info("报检单数据同步结果：报检单号为" + declNo + "处理" + sucFlag);
			if (sucFlag) {
				MSG.append("\n详细报检信息调取成功");
			} else {
				MSG.append("\n详细报检信息调取失败");
			}

		} catch (DbXmlCoughtNoDataException e) {
			e.printStackTrace();
			MSG.append("\n详细报检信息调取异常，请联系管理员");
			logger.info("报检单数据同步结果：报检单号为" + declNo + "处理失败");
		} catch (DbXmlMappingException e) {
			e.printStackTrace();
		}

		// 布控反馈
		try {
			// 获取db2xml实例
			Db2XmlGenerator db2xml = DbXmlMappingFactory.getInstance()
					.getXmlGenerator(chgConn);// 源库
			// 传入应相模板与条件参数，产生数据报文
			String xml = db2xml.generateXml(fbReportType1, getConditionM(fbReportType1, declNo), condition2,"IU"); // 获取xml2db实例
			String xml2 = xml.replace("ITF_", "");
			Xml2DbExecutor x2d = DbXmlMappingFactory.getInstance()
					.getXml2DbExecutor(appConn);
			// 使用xml2db进行数据持久化操作，根据操作类型参为进行相应操作：（I插入U更新D删除）
			er = x2d.getXml2Db(fbReportType2, xml2, "IU", true);
			boolean sucFlag = er.isSuccess();
			logger.info("布控反馈数据同步结果：报检单号为" + declNo + "处理" + sucFlag);
			if (sucFlag) {
				MSG.append("\n布控反馈信息调取成功");
			} else {
				MSG.append("\n布控反馈信息调取失败");
			}
		} catch (DbXmlCoughtNoDataException e) {
			e.printStackTrace();
			MSG.append("\n布控反馈信息调取异常，请联系管理员");
			logger.info("布控反馈数据同步结果：报检单号为" + declNo + "处理失败");
		} catch (DbXmlMappingException e) {
			e.printStackTrace();
		}

		// 布控信息
		try {
			// 获取db2xml实例
			Db2XmlGenerator db2xml = DbXmlMappingFactory.getInstance()
					.getXmlGenerator(chgConn);// 源库
			// 传入应相模板与条件参数，产生数据报文
			String xml = db2xml.generateXml(ordReportType1, getConditionM(ordReportType1, declNo), condition2,"IU"); // 获取xml2db实例
			String xml2 = xml.replace("ITF_", "");
			Xml2DbExecutor x2d = DbXmlMappingFactory.getInstance()
					.getXml2DbExecutor(appConn);
			// 使用xml2db进行数据持久化操作，根据操作类型参为进行相应操作：（I插入U更新D删除）
			er = x2d.getXml2Db(ordReportType2, xml2, "IU", true);
			boolean sucFlag = er.isSuccess();
			logger.info("布控信息数据同步结果：报检单号为" + declNo + "处理" + sucFlag);
			if (sucFlag) {
				MSG.append("\n详细布控信息调取成功");
			} else {
				MSG.append("\n详细布控信息调取失败");
			}
		} catch (DbXmlCoughtNoDataException e) {
			e.printStackTrace();
			MSG.append("\n详细布控信息调取异常，请联系管理员");
			logger.info("布控信息数据同步结果：报检单号为" + declNo + "处理失败");
		} catch (DbXmlMappingException e) {
			e.printStackTrace();
		}

		// 施检信息
		try {
			// 获取db2xml实例
			Db2XmlGenerator db2xml = DbXmlMappingFactory.getInstance()
					.getXmlGenerator(chgConn);// 源库
			// 传入应相模板与条件参数，产生数据报文
			String xml = db2xml.generateXml(insReportType1, getConditionM(insReportType1, declNo), condition2,"IU"); // 获取xml2db实例
			String xml2 = xml.replace("ITF_", "");
			Xml2DbExecutor x2d = DbXmlMappingFactory.getInstance()
					.getXml2DbExecutor(appConn);
			// 使用xml2db进行数据持久化操作，根据操作类型参为进行相应操作：（I插入U更新D删除）
			er = x2d.getXml2Db(insReportType2, xml2, "IU", true);
			boolean sucFlag = er.isSuccess();
			logger.info("施检信息数据同步结果：报检单号为" + declNo + "处理" + sucFlag);
			if (sucFlag) {
				MSG.append("\n施检信息调取成功");
			} else {
				MSG.append("\n施检信息调取失败");
			}
		} catch (DbXmlCoughtNoDataException e) {
			e.printStackTrace();
			MSG.append("\n施检信息调取异常，请联系管理员");
			logger.info("施检信息数据同步结果：报检单号为" + declNo + "处理失败");
		} catch (DbXmlMappingException e) {
			e.printStackTrace();
		}
		
	    try {
			chgConn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			appConn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return MSG.toString();

	}
	
	/**
	* <p>描述:查询条件</p>
	* @param table
	* @param declNo
	* @return
	* @author 才江男
	 */
	public String getConditionM(String table, String declNo) {
		String param = " DECL_NO = '" + declNo + "' and trans_batch = (select max(trans_batch) from " + table + " where decl_no = '" + declNo+ "') and rownum=1";
		return param;
	}

}

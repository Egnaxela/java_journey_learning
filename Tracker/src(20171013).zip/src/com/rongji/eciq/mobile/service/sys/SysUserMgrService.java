package com.rongji.eciq.mobile.service.sys;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rongji.dfish.base.Utils;
import com.rongji.eciq.mobile.dao.sys.EnterpriseAccountDao;
import com.rongji.eciq.mobile.dao.sys.SysUserMgrDao;
import com.rongji.eciq.mobile.entity.EntBaseInfoEntity;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;
import com.rongji.eciq.mobile.entity.SysTableCacheConfig;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.model.sys.PrivilegeModel;
import com.rongji.eciq.mobile.model.sys.PrivilegeModelSub;
import com.rongji.eciq.mobile.model.sys.PrivilegeModelUrl;
import com.rongji.eciq.mobile.model.sys.SysOrgModel;
import com.rongji.eciq.mobile.model.sys.SysOrgSubModel;
import com.rongji.eciq.mobile.utils.DateTools;
import com.rongji.eciq.mobile.vo.sys.SysTableCacheConfigList;
import com.rongji.eciq.mobile.vo.sys.SysTableCacheConfigVo;
import com.rongji.system.entity.SysFeedback;
import com.rongji.system.entity.SysFunction;
/**
 * 用户服务类
 *
 * @author 才江男
 * @since 1.0
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-08      才江男                      1.0        保存意见
 * 2017-5-16      才江男                      1.0        增加路径参数，主要用于出入境标志
 * 2017-5-17      才江男                      1.0        刷新缓存
 * 2017-5-17      才江男                      1.0        更改复制方法
 * 2017-6-08      才江男                      1.0        完善权限
 * 2017-7-24      吴有根                      1.0        增加企业的信息查看、密码修改
 * 2017-7-28      才江男                      1.0        前后台权限统一管理
 */
@Service
//@Transactional
public class SysUserMgrService {
	
	@Resource
	SysUserMgrDao sysUserMgrDao;
	
	@Autowired
	EnterpriseAccountDao enterpriseAccountDao;
	
	/**
	 * 根据用户代码查询用户
	 * 
	 * @param userCode 用户代码
	 * @return 用户信息
	 */
	public SysUser checkUser(String userCode) {
		return sysUserMgrDao.checkUser(userCode);
	}
	
	/**
	 * 根据用户代码查询用户权限信息
	 * 
	 * @param userCode 用户代码
	 * @return 用户权限信息
	 */
	public List<PrivilegeModel> getUserPrivileges(String userCode) {
		List<SysFunction> privileges = sysUserMgrDao.getUserPrivileges(userCode);
		//将权限改装为JSON格式权限
		List<PrivilegeModel> privilegeModel = null;
		if (CollectionUtils.isNotEmpty(privileges)) {
			privilegeModel = assemblePrivileges(privileges);
		}
		return privilegeModel;
	}
	
	/**
	 * 将权限改装为JSON格式权限
	 * 
	 * @param privileges
	 * @return JSON格式权限
	 */
	private List<PrivilegeModel> assemblePrivileges(List<SysFunction> privileges) {
		List<PrivilegeModel> privilegeModelsList = new ArrayList<PrivilegeModel>();
		PrivilegeModel privilegeModel;
		for (SysFunction sysPrivilege : privileges) {
			String parentCode = sysPrivilege.getParentFunction();
			String code = sysPrivilege.getFunctionId();
			if ("1200000000".equals(parentCode)) {
				List<PrivilegeModel> assembleModel = assembleModel(privileges, code);
				if (CollectionUtils.isNotEmpty(assembleModel)) {
					privilegeModel = new PrivilegeModelSub();
					privilegeModel.setCode(code);
					privilegeModel.setName(sysPrivilege.getFunctionName());
					//有子界面
					((PrivilegeModelSub) privilegeModel).setSub(assembleModel);
					privilegeModelsList.add(privilegeModel);
				}
			}
		}
		return privilegeModelsList;
	}
	
	/**
	 * 遍历子权限为JSON
	 * 
	 * @param privileges 权限
	 * @param code 父权限码
	 * @return 子JSON
	 */
	private List<PrivilegeModel> assembleModel (List<SysFunction> privileges, String code) {
		List<PrivilegeModel> privilegeModelsList = new ArrayList<PrivilegeModel>();
		PrivilegeModel privilegeModel = null;
		for (SysFunction sysPrivilege : privileges) {
			String parentCode = sysPrivilege.getParentFunction();
			String subCode = sysPrivilege.getFunctionId();
			if (parentCode.equals(code)) {
				/*if(StringUtils.isNotEmpty(sysPrivilege.getMapping())) {
					if(sysPrivilege.getMapping().contains("#")) {
						return null;
					}
					if(sysPrivilege.getMapping().contains("Navigation")){
						continue;
					}
				}*/
				List<PrivilegeModel> assembleModel = assembleModel(privileges, subCode);
				if (CollectionUtils.isNotEmpty(assembleModel)) {
					privilegeModel = new PrivilegeModelSub();
					privilegeModel.setCode(subCode);
					privilegeModel.setName(sysPrivilege.getFunctionName());
					//有子界面
					((PrivilegeModelSub) privilegeModel).setSub(assembleModel);
					//路径参数
					((PrivilegeModelSub) privilegeModel).setUrl(sysPrivilege.getAppPath());
				} else {
					privilegeModel = new PrivilegeModelUrl();
					privilegeModel.setCode(subCode);
					privilegeModel.setName(sysPrivilege.getFunctionName());
					//无子界面
					((PrivilegeModelUrl) privilegeModel).setUrl(sysPrivilege.getAppPath());
				}
				privilegeModelsList.add(privilegeModel);
			}

		}
		return privilegeModelsList;
	}
	
	/**
	 * 根据用户代码查询用户
	 * 
	 * @param userCode 用户代码
	 * @return 用户信息
	 */
	public void modifyPwd(String userCode, String password) {
		sysUserMgrDao.modifyPwd(userCode, password);
	}

	/**
	 * 根据部门代码、用户代码，首页获取用户信息
	 * 
	 * @param orgCode 部门代码
	 * @param userCode 用户代码
	 * @param cp 页码
	 * @return 用户信息
	 */
	public List getUsers(String orgCode, String userCode, String cp) {
		return sysUserMgrDao.getUsers(orgCode, userCode, cp);
	}
	
	/**
	 * 根据机构代码查询下属部门信息
	 * 
	 * @param orgCode 机构代码
	 * @return 下属部门信息
	 */
	public SysOrgModel getOrgs(String orgCode) {
		SysOrgModel model = new SysOrgModel();
		List<SysOrganizeEntity> orgs = sysUserMgrDao.getOrgs(orgCode);
		if(CollectionUtils.isNotEmpty(orgs)) {
			SysOrganizeEntity sysOrg = null;
			for (SysOrganizeEntity sysOrganizeEntity : orgs) {
				if(orgCode.equals(sysOrganizeEntity.getOrgCode())) {
					sysOrg = sysOrganizeEntity;
					break;
				}
			}
			//判断本机构是否存在，及在编状态
			if(null == sysOrg) {
				model.setMsg("机构不存在");
			} else if(!"1".equals(sysOrg.getState())) {
				model.setMsg("机构不在编");
			} else {
				//本机构存在且在编，查找
				List<SysOrgModel> orgList = assembleOrgs(orgs, orgCode);
				model.setOrgs(orgList);
			}
		} else {
			model.setMsg("机构不存在");
		}
		return model;
	}
	
	/**
	 * 根据机构代码查询子级下属部门信息
	 * 
	 * @param orgCodes 部门代码
	 * @return 子级下属部门信息
	 */
	public List<String> getSubOrgs(List<String> orgCodes) {
		return sysUserMgrDao.getSubOrgs(orgCodes);
	}
	
	/**
	 * 查询子级下属部门
	 * 
	 * @param orgs
	 * @return
	 */
	public List<SysOrgModel> assembleOrgs(List<SysOrganizeEntity> orgs, String orgCode) {
		List<SysOrgModel> mainList = new ArrayList<SysOrgModel>();
		List<SysOrgSubModel> subList = new ArrayList<SysOrgSubModel>();
		SysOrgModel mainModel = new SysOrgModel();
		
		for (SysOrganizeEntity sysOrg : orgs) {
			if(sysOrg.getOrgCode().equals(orgCode)) {
				mainModel.setOrgCode(orgCode);
				mainModel.setOrgNameSc(sysOrg.getOrgNameSc());
				//只留子节点
				orgs.remove(sysOrg);
				break;
			}
		}
		//根节点
		mainList.add(mainModel);
		if(2 > orgs.size()) {
			//无子部门
			return mainList;
		}
		
		//有子部门
		mainModel.setSub(subList);
		
		List<String> orgCodes = new ArrayList<String>();
		if(CollectionUtils.isNotEmpty(orgs)) {
			//拼接子节点
			for (SysOrganizeEntity sysOrganizeEntity : orgs) {
				orgCodes.add(sysOrganizeEntity.getCategoryCode());
			}
			//查询子节点是否还有子节点
			List<String> subSubList = getSubOrgs(orgCodes);
			
			SysOrgSubModel subModel = null;
			if(CollectionUtils.isNotEmpty(subSubList)) {
				//有孙节点
				for (SysOrganizeEntity sysOrganizeEntity : orgs) {
					subModel = new SysOrgSubModel();
					subModel.setOrgNameSc(sysOrganizeEntity.getOrgNameSc());
					String subCode = sysOrganizeEntity.getCategoryCode();
					subModel.setOrgCode(sysOrganizeEntity.getOrgCode());
					//遍历孙节点
					for (String org : subSubList) {
						if(subCode.equals(org)) {
							//如果有相应的孙节点，为true
							subModel.setSub(true);
							break;
						}
					}
					subList.add(subModel);
				}
				
			} else {
				//没有孙节点
				for (SysOrganizeEntity sysOrganizeEntity : orgs) {
					subModel = new SysOrgSubModel();
					subModel.setOrgNameSc(sysOrganizeEntity.getOrgNameSc());
					subModel.setOrgCode(sysOrganizeEntity.getOrgCode());
					subList.add(subModel);
				}
			}
			
		}
		return mainList;
	}
	
	
	/**
	 * 根据用户代码查询所在部门
	 * 
	 * @param userCode 用户代码
	 * @return 部门信息
	 */
	public SysOrganizeEntity getOrgByUserCode(String userCode) {
		return sysUserMgrDao.getOrgByUserCode(userCode);
	}
	
	/**
	 * 保存意见
	 * @param sysFeedback 意见
	 */
	public void saveFeeBack(SysFeedback sysFeedback) {
		sysUserMgrDao.saveFeeBack(sysFeedback);
	}
	
	/**
	 * 
	* <p>描述:获取缓存配置项</p>
	* @return
	* @author 才江男
	 */
	public List<SysTableCacheConfigVo> getDbConfig() {
		List<SysTableCacheConfig> dbConfig = sysUserMgrDao.getDbConfig();
		List<SysTableCacheConfigVo> vos = null;
		if(CollectionUtils.isNotEmpty(dbConfig)) {
			vos = new ArrayList<SysTableCacheConfigVo>();
			SysTableCacheConfigVo vo = null;
			for (SysTableCacheConfig SysTableCacheConfig : dbConfig) {
				vo = new SysTableCacheConfigVo();
				vos.add(vo);
				try {
					PropertyUtils.copyProperties(vo, SysTableCacheConfig);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				}
			}
		}
		return vos;
	}
	
	/**
	* <p>描述:获取需要更新的数据</p>
	* @param dbs
	* @return
	* @author 才江男
	 */
	public List<SysTableCacheConfigList> dbUpdate(List<SysTableCacheConfigVo> dbs) {
		if(CollectionUtils.isEmpty(dbs)) {
			return null;
		}
		
		List<SysTableCacheConfigList> list = new ArrayList<SysTableCacheConfigList>();
		SysTableCacheConfigList updateList = null;
		StringBuilder sql = new StringBuilder();
		for (SysTableCacheConfigVo sysTableCacheConfigVo : dbs) {
			String tableName = sysTableCacheConfigVo.getTableName();
			Date lastUpdateTime = sysTableCacheConfigVo.getLastUpdateTime();
			if(StringUtils.isEmpty(tableName) || null == lastUpdateTime) {
				continue;
			}
			sql.append(" where tableName = ? and lastUpdateTime > ?");
			SysTableCacheConfig dbUpdate = sysUserMgrDao.dbUpdate(sql, tableName, lastUpdateTime);
			if(null != dbUpdate) {
				List<SysTableCacheConfigVo> queryDb = sysUserMgrDao.queryDb(dbUpdate.getCondition(), lastUpdateTime, dbUpdate.getLastUpdateTime());
				if(CollectionUtils.isNotEmpty(queryDb)) {
					updateList = new SysTableCacheConfigList();
					updateList.setTableName(tableName);
					updateList.setTime(DateTools.getDateDayFormat(dbUpdate.getLastUpdateTime()));
					updateList.setList(queryDb);
					list.add(updateList);
				}
			}
			sql = new StringBuilder();
		}
		
		return list;
	}

	/**
	* <p>描述:</p>
	* @param entOrgCode
	* @return
	* @author 吴有根
	*/
	public EntBaseInfoEntity getEntBaseInfo(String entOrgCode) {
		List<EntBaseInfoEntity> list=enterpriseAccountDao.checkexist(entOrgCode);
		return Utils.notEmpty(list)?list.get(0):null;
	}

	/**
	* <p>描述:修改企业密码</p>
	* @param entOrgCode
	* @param encodedPassword
	* @author 吴有根
	*/
	public void modifyEntBaseInfoPwd(String entOrgCode, String newpwd) {
		sysUserMgrDao.modifyEntBaseInfoPwd(entOrgCode, newpwd);
	}
	
}

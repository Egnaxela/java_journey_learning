/**  
 * FileName: BeanPropertyUtils.java    
 * @Description: 此类用于实体间按属性字段拷贝
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月18日 上午9:35:12  
 *  
 */  

package com.rongji.eciq.mobile.utils;

import java.math.BigDecimal;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.log4j.Logger;

/**  
 * Description: 此类用于实体间按属性字段拷贝  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年5月18日 上午9:35:12  
 *  
 * Modification History:  
 * Date          Author       Version     Description  
 * ------------------------------------------------------------------  
 * 2017-05-18    吴有根                      1.0         1.0 Version  
 */

public class BeanPropertyUtils {
	
	private static final Logger log=Logger.getLogger(BeanPropertyUtils.class);
	private static final BigDecimal BIG_DECIMAL_ZERO=new BigDecimal("0");

	//注册转换器
	static {
		//注册BigDecimal转换器
		BigDecimalConverter bDecimalConverter=new BigDecimalConverter(BIG_DECIMAL_ZERO);
		ConvertUtils.register(bDecimalConverter, java.math.BigDecimal.class);
		
		//注册sqldate转换器
		ConvertUtils.register(new org.apache.commons.beanutils.converters.SqlTimestampConverter(null), java.sql.Timestamp.class);
		ConvertUtils.register(new org.apache.commons.beanutils.converters.SqlDateConverter(null), java.sql.Date.class);
		ConvertUtils.register(new org.apache.commons.beanutils.converters.SqlTimeConverter(null), java.sql.Time.class);    
	}

	private static volatile BeanPropertyUtils getInstance=null; 
	public  static BeanPropertyUtils getInstance(){
		BeanPropertyUtils instance=getInstance;
		if(instance==null){
			synchronized (BeanPropertyUtils.class) {
				instance=getInstance;
				if(instance==null){
					instance=new BeanPropertyUtils();
					getInstance=instance;
				}
			}
		}
		return instance;
	}
	
	
	
	/**
	 * 
	* <p>描述:从源实体拷贝状态值到目标实体
	* <ul>
	* <li>源实体与目标实体的需拷贝的属性值名称要保持一致
	* <li>此方法在拷贝过程中，不会对允许范围内的属性类型进行转换;若对应key的类型不同会抛出异常
	* </ul>
	* </p>
	* @param target 目标对象
	* @param origin 源头对象
	* @throws Throwable
	* @author 吴有根
	 */
	public void copyBeanProperties(final Object target,final Object origin) throws Throwable{
		if(target==null){
			throw new IllegalArgumentException("目标对象不能为空");
		}
		
		if(origin==null){
			throw new IllegalArgumentException("源对象不能为空");
		}
		
		log.info("正在执行拷贝PropertyUtils.copyProperties(): "+origin.getClass().getName()+" To "+target.getClass().getName());
		
		PropertyUtils.copyProperties(target, origin);

    }

	
	/**
	 * 
	* <p>描述:从源实体拷贝状态值到目标实体
	* <ul>
	* <li>源实体与目标实体的需拷贝的属性值名称要保持一致
	* <li>此方法在拷贝过程中，会对允许范围内的属性类型进行转换;
	* <li>推荐用此方法
	* </ul>
	* </p>
	* @param target  目标对象
	* @param origin  源头对象
	* @throws Throwable
	* @author 吴有根
	 */
	public  void copyPropertiesBean(final Object target,final Object origin) throws Throwable{
		if(target==null){
			throw new IllegalArgumentException("目标对象不能为空");
		}
		
		if(origin==null){
			throw new IllegalArgumentException("源对象不能为空");
		}
		
		log.info("正在执行拷贝BeanUtils.copyProperties(): "+origin.getClass().getName()+" To "+target.getClass().getName());
		
		BeanUtils.copyProperties(target, origin);

    }
	
  
}



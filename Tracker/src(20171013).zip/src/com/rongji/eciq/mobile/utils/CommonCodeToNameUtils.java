/**  
 * FileName:CommonCodeToNameUtils.java
 * @Description: 基础代码转名称工具类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.context.InsContext;
import com.rongji.eciq.mobile.context.MobileCommContext;

/**
 * 
 * Description: 基础代码转名称工具类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:33:15  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19    李云龙                  1.0         增加施报检环节转名称
 * 2017-4-20    李晨阳                  1.0         添加综合评定结论状态转名称
 * 2017-5-05    魏波                       1.0         增加报检单流程环节、状态、报检类别代码转名称
 * 2017-5-15    魏波                       1.0         所需单证代码转名称
 * 2017-5-26    才江男                   1.0         结果查验代码转名称
 * 2017-6-16    才江男                   1.0         增加送检，抽样，回写流程代码转名称
 * 2017-06-28   李云龙                   1.0         添加查验预约申请，受理基础代码转名称
 * 2017-07-19   李云龙                  1.0         添加查验预约申请代码转名称
 */
public class CommonCodeToNameUtils {
	
	//private static Map<String, BasicData> BASICDATAS = new HashMap();
	
	/**
	 * 主辅检标记代码转名称
	 * @param statusCode
	 * @return
	 */
	public static String flowPathStatusToName(String statusCode){
		
		if(StringUtils.isNotEmpty(statusCode)){
			String statusName="";
			if(statusCode.equals(CommContext.FLOW_PATH_STATUS_MAIN)){
				statusName=CommContext.FLOW_PATH_STATUS_MAIN_NAME;
			}else if(statusCode.equals(CommContext.FLOW_PATH_STATUS_AUXILIARY)){
				statusName=CommContext.FLOW_PATH_STATUS_AUXILIARY_NAME;
			}else if(statusCode.equals(CommContext.FLOW_PATH_STATUS_AUXILIARY_DONE)){
				statusName=CommContext.FLOW_PATH_STATUS_AUXILIARY_DONE_NAME;
			}else{
				statusName=statusCode;
			}
			return statusName;	
		}
		
		return null;
		
	}

	/**
	 * 分单状态代码转名称
	 * @param subType
	 * @return
	 */
	public static String subTypeStatusToName(String subType) {
		if(StringUtils.isNotEmpty(subType)){
			String statusName="";
			if(subType.equals(CommContext.SUBMENU_TYPE_YET_SUB)){
				statusName=CommContext.SUBMENU_TYPE_YET_SUB_NAME;
			}else if(subType.equals(CommContext.SUBMENU_TYPE_NOT_SUB)){
				statusName=CommContext.SUBMENU_TYPE_NOT_SUB_NAME;
			}else{
				statusName=subType;
			}
			return statusName;	
		}
		
		return null;
	}
	
    /**
     * 世界各国和地区名称代码代码转名称
     *
     * @param code 代码
     *
     * @return 世界各国和地区名称代码名称
     */
//    public static String getWorldDistrictName(String code) {
//        if (StringUtils.isEmpty(code)) {
//            return "";
//        }
//        //代码转名称
//        return String.valueOf(getBasicDatas("WorldDistrict").getNameByCode(code));
//    }
//    
//
//    
//    static BasicData getBasicDatas(String basicDataId) {
//        //代码转名称
//        BasicData basicData = BASICDATAS.get(basicDataId);
//        if (basicData == null) {
//            basicData = (BasicData) BasicDataFactory.getInstance().getBasicData(basicDataId);
//            BASICDATAS.put(basicDataId, basicData);
//        }
//        return basicData;
//    }
	
	/**
	 * 施检-检验要求代码转名称
	 * @param code
	 * @return
	 */
	public static String inspRequireToName(String code) {
		String requireName="";
		if(StringUtils.isNotEmpty(code)){
			if(code.equals(CommContext.TEST_REQUIRE_EXAMINE)){
				requireName=CommContext.TEST_REQUIRE_EXAMINE_NAME;
			}else if(code.equals(CommContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE)){
				requireName=CommContext.TEST_REQUIRE_SEDCHK_AND_EXAMINE_NAME;
			}else if(code.equals(CommContext.TEST_REQUIRE_SENDCHECK)){
				requireName=CommContext.TEST_REQUIRE_SENDCHECK_NAME;
			}else {
				requireName=code;
			}
			return requireName;
		}
		return requireName;
		
	}
	
	/**
	 * 
	 * 布控拦截信息代码转名称
	 * @param code
	 * @return
	 */
	public static String MonitorBlockTypeCodeToName(String code) {
		String monitorBlock = "";
		int codeNumber = 1;
		if (StringUtils.isNotEmpty(code)) {
			try {
				codeNumber = Integer.valueOf(code);
			} catch (Exception e) {
				return monitorBlock;
			}

			switch (codeNumber) {
			case 1:
				monitorBlock = InsContext.RISK_EARLY_WARNING_NAME;
				break;
			case 2:
				monitorBlock = InsContext.PERMISSION_TO_INTERCEPT_NAME;
				break;
			case 3:
				monitorBlock = InsContext.PICK_A_GROUP_OF_NAME;
				break;
			case 4:
				monitorBlock = InsContext.SUPERVISED_RULES_INTERCEPT_NAME;
				break;
			case 5:
				monitorBlock = InsContext.AUXILIARY_INSPECTION_INTERCEPT_NAME;
				break;
			case 6:
				monitorBlock = InsContext.MONITOR_ORDER_INTERCEPT_NAME;
				break;
			case 7:
				monitorBlock = InsContext.NOT_MONITORING_PROJECT_INTERCEPT_NAME;
				break;
			case 8:
				monitorBlock = InsContext.REVISED_BACK_TO_INTERCEPT_NAME;
				break;
			case 9:
				monitorBlock = InsContext.BUSINESS_CYCLE_ABNORMAL_INTERCEPT_NAME;
				break;
			case 10:
				monitorBlock = InsContext.ENTERPRISE_CAPACITY_VERIFICATION_NAME;
				break;
			case 11:
				monitorBlock = InsContext.NO_REGULATORY_PROPERTIES_NAME;
				break;
			case 12:
				monitorBlock = InsContext.MONITOR_AND_INTERCEPT_NAME;
				break;
			case 13:
				monitorBlock = InsContext.HIS_BLOCK_NAME;
				break;
			case 14:
				monitorBlock = InsContext.PRODUCTION_BATCH_NO_CIQ_CODE_BLOCK_NAME;
				break;
			case 15:
				monitorBlock = InsContext.COMPANIES_REPORT_THE_ABNORMAL_INTERCEPT_NAME;
				break;
			case 16:
				monitorBlock = InsContext.PRODUCTION_BATCH_SUPERVISION_BUREAU_END_INTERCEPT_NAME;
				break;
			case 17:
				monitorBlock = InsContext.PRODUCTION_BATCH_VALIDITY_OF_INTERCEPTION_NAME;
				break;
			case 18:
				monitorBlock = InsContext.FIRST_EXPORT_INTERCEPT_NAME;
				break;
			case 19:
				monitorBlock = InsContext.FIRST_IMPORT_INTERCEPT_NAME;
				break;
			case 20:
				monitorBlock = InsContext.NO_INSP_USER_NAME;
				break;
			default:
				monitorBlock = code;
				break;
			}
		}
		return monitorBlock;
	}
	
	/**
	 * 施检-检疫结果代码转名称
	 * @param code
	 * @return
	 */
	public static String inspquarCodeToName(String code){
		if(StringUtils.isNotEmpty(code)){
			String inspquarName="";
			if(code.equals(InsContext.INSP_QUAR_RESULT_PASS)){
				inspquarName=InsContext.INSP_QUAR_RESULT_PASS_NAME;
			}else if(code.equals(InsContext.INSP_QUAR_RESULT_REDO_PASS)){
				inspquarName=InsContext.INSP_QUAR_RESULT_REDO_PASS_NAME;
			}else if(code.equals(InsContext.INSP_QUAR_RESULT_QUAR_FAIL)){
				inspquarName=InsContext.INSP_QUAR_RESULT_QUAR_FAIL_NAME;
			}else{
				inspquarName=code;
			}
			return inspquarName;	
		}
		
		return null;
	}
	
	/**
	 * 施检-检验结果代码转名称
	 * @param code
	 * @return
	 */
	public static String inspquarCodeToName2(String code){
		if(StringUtils.isNotEmpty(code)){
			String inspquarName="";
			if(code.equals(InsContext.INSP_QUAR_RESULT_PASS)){
				inspquarName=InsContext.INSP_QUAR_RESULT_PASS_NAME;
			}else if(code.equals(InsContext.INSP_QUAR_RESULT_REDONE_PASS)){
				inspquarName=InsContext.INSP_QUAR_RESULT_REDONE_PASS_NAME;
			}else if(code.equals(InsContext.INSP_QUAR_RESULT_CHANGE_SRANDARD)){
				inspquarName=InsContext.INSP_QUAR_RESULT_CHANGE_SRANDARD_NAME;
			}else if(code.equals(InsContext.INSP_QUAR_RESULT_INSP_FAIL)){
				inspquarName=InsContext.INSP_QUAR_RESULT_INSP_FAIL_NAME;
			}else{
				inspquarName=code;
			}
			return inspquarName;	
		}
		
		return null;
	}
	
	public static String commonCodeToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(code, CommContext.Y_1)){
				name=CommContext.Y_1_NAME;
			}else if(StringUtils.equals(code, CommContext.N_0)){
				name=CommContext.N_0_NAME;
			}else{
				name=code;
			}
		}
		
		return name;
	}
	
	/**
	 * 施检-查验项目是否合格代码转名称
	 * @param code
	 * @return
	 */
	public static String insSceneItemCodeToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(code, InsContext.INS_Y)){
				name=InsContext.INS_Y_NAME;
			}else if(StringUtils.equals(code, InsContext.INS_N)){
				name=InsContext.INS_N_NAME;
			}else if(StringUtils.equals(code, InsContext.NOT_TRY_OUT_CODE)){
				name=InsContext.NOT_TRY_OUT_NAME;
			}else{
				name=code;
			}
		}
		
		return name;
		
	}
	
	/**
	 * 抽样方案基础代码转名称
	 * @param code
	 * @return
	 */
	public static String samplePlanCodeToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_PERCENT)){
				name=DeclContext.SAMPLE_PLAN_PERCENT_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_STANDARD)){
				name=DeclContext.SAMPLE_PLAN_STANDARD_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_NONE)){
				name=DeclContext.SAMPLE_PLAN_NONE_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_PRODUCT)){
				name=DeclContext.SAMPLE_PLAN_PRODUCT_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_TIME)){
				name=DeclContext.SAMPLE_PLAN_TIME_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_CUSTOM)){
				name=DeclContext.SAMPLE_PLAN_CUSTOM_NAME;
			}else if(StringUtils.equals(code, DeclContext.SAMPLE_PLAN_SPECIAL)){
				name=DeclContext.SAMPLE_PLAN_SPECIAL_NAME;
			}else{
				name=code;
			}
		}
		
		return name;
		
	}
	

	/**
	 * 现场查验-货物评定代码转名称
	 * @param code
	 * @return
	 */
	public static String goodsEvalResultCodeToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(code, InsContext.INS_UNQUALIFIED)){
				name=InsContext.INS_UNQUALIFIED_NAME;
			}else if(StringUtils.equals(code, InsContext.INS_QUALIFIED)){
				name=InsContext.INS_QUALIFIED_NAME;
			}else if(StringUtils.equals(code, InsContext.BACK_INS_UNQUALIFIED)){
				name=InsContext.BACK_INS_UNQUALIFIED;
			}else{
				name=code;
			}
		}
		return name;
	}
	
	
	/**
	 * 辅施检分单--施检内容代码转名称
	 */
	public static String insContCodesToName(String insContCodes) {
		if (StringUtils.isNotEmpty(insContCodes)) {
			// 将代码替换成名称
			insContCodes = insContCodes.replaceAll(InsContext.GOODS_IDENTIFY,
					InsContext.GOODS_IDENTIFY_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.SGOODS_QUARANTINE,
					InsContext.SGOODS_QUARANTINE_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.SGOODS_CHECKOUT_CODE,
					InsContext.SGOODS_CHECKOUT_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.ISOLATION_QUARANTINE,
					InsContext.ISOLATION_QUARANTINE_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.CONTAINER_QUARANTINE,
					InsContext.CONTAINER_QUARANTINE_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.WOOD_PACKAG_QUARANTINE,
					InsContext.WOOD_PACKAG_QUARANTINE_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.AUX_INS_QUAR_CODE,
					InsContext.AUX_INS_QUAR_CODE_NAME);
			insContCodes = insContCodes.replaceAll(
					InsContext.AUX_INS_HEALTH_CODE,
					InsContext.AUX_INS_HEALTH_CODE_NAME);
		}
		return insContCodes;
	}
	
	/**
	 * 
	* <p>描述:法定抽批状态转名称</p>
	* @param code
	* @return
	* @author 吴有根
	 */
	public static String legalRuleStatusToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(DeclContext.STATUS_EDIT, code)){
				name=DeclContext.STATUS_EDIT_NAME;
			}else if(StringUtils.equals(DeclContext.STATUS_PUBLISH, code)){
				name=DeclContext.STATUS_PUBLISH_NAME;
			}else if(StringUtils.equals(DeclContext.STATUS_RELIEVE, code)){
				name=DeclContext.STATUS_RELIEVE_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}
	
	/**
	 * 
	* <p>描述:报检环节转名称</p>
	* @param code
	* @return
	* @author 魏波
	 */
	public static  String processLinkToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(CommContext.BACK_DECL, code)){
				name=CommContext.BACK_DECL_NAME;
			}else if(StringUtils.equals(CommContext.SELF_DECL, code)){
				name=CommContext.SELF_DECL_NAME;
			}else if(StringUtils.equals(CommContext.AUTO_DECL, code)){
				name=CommContext.AUTO_DECL_NAME;
			}else if(StringUtils.equals(CommContext.SELF_CHECK, code)){
				name=CommContext.SELF_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.DECL, code)){
				name=CommContext.DECL_NAME;
			}else if(StringUtils.equals(CommContext.SUBMENU, code)){
				name=CommContext.SUBMENU_NAME;
			}else if(StringUtils.equals(CommContext.INS, code)){
				name=CommContext.INS_NAME;
			}else if(StringUtils.equals(CommContext.SPOT, code)){
				name=CommContext.SPOT_NAME;
			}else if(StringUtils.equals(CommContext.SEND, code)){
				name=CommContext.SEND_NAME;
			}else if(StringUtils.equals(CommContext.EVALUATE, code)){
				name=CommContext.EVALUATE_NAME;
			}else if(StringUtils.equals(CommContext.UNQULIFIED, code)){
				name=CommContext.UNQULIFIED_NAME;
			}else if(StringUtils.equals(CommContext.QULIFIED, code)){
				name=CommContext.QULIFIED_NAME;
			}else if(StringUtils.equals(CommContext.DRAFT, code)){
				name=CommContext.DRAFT_NAME;
			}else if(StringUtils.equals(CommContext.ATTESTATION, code)){
				name=CommContext.ATTESTATION_NAME;
			}else if(StringUtils.equals(CommContext.ACQUIR, code)){
				name=CommContext.ACQUIR_NAME;
			}else if(StringUtils.equals(CommContext.RECHECK, code)){
				name=CommContext.RECHECK_NAME;
			}else if(StringUtils.equals(CommContext.MAKE, code)){
				name=CommContext.MAKE_NAME;
			}else if(StringUtils.equals(CommContext.VERIFY, code)){
				name=CommContext.VERIFY_NAME;
			}else if(StringUtils.equals(CommContext.SIGN, code)){
				name=CommContext.SIGN_NAME;
			}else if(StringUtils.equals(CommContext.DOC, code)){
				name=CommContext.DOC_NAME;
			}else if(StringUtils.equals(CommContext.CANCEL_DOC, code)){
				name=CommContext.CANCEL_DOC_NAME;
			}else if(StringUtils.equals(CommContext.CUST_CLEARANCE, code)){
				name=CommContext.CUST_CLEARANCE_NAME;
			}else if(StringUtils.equals(CommContext.PASS, code)){
				name=CommContext.PASS_NAME;
			}else if(StringUtils.equals(CommContext.CHARG, code)){
				name=CommContext.CHARG_NAME;
			}else if(StringUtils.equals(CommContext.RESULT, code)){
				name=CommContext.RESULT_NAME;
			}else if(StringUtils.equals(CommContext.SCE_RECORD, code)){
				name=CommContext.SCE_RECORD_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}
	
	/**
	 * <p>报检流程状态转名称</p>
	 * @param code
	 * @return
	 * @author 魏波
	 */
	public static String processStateToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(CommContext.WAIT_AOTU_CHECK, code)){
				name=CommContext.WAIT_AOTU_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.DECL_BACK, code)){
				name=CommContext.DECL_BACK_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_DOC, code)){
				name=CommContext.WAIT_DOC_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_SELF_CHECK, code)){
				name=CommContext.WAIT_SELF_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_DECL, code)){
				name=CommContext.WAIT_DECL_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_INS, code)){
				name=CommContext.WAIT_INS_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_HEALTH, code)){
				name=CommContext.WAIT_HEALTH_NAME;
			}else if(StringUtils.equals(CommContext.DECL_RETURN, code)){
				name=CommContext.DECL_RETURN_NAME;
			}else if(StringUtils.equals(CommContext.H_BACK, code)){
				name=CommContext.H_BACK_NAME;
			}else if(StringUtils.equals(CommContext.ACC_RETURN, code)){
				name=CommContext.ACC_RETURN_NAME;
			}else if(StringUtils.equals(CommContext.E_BACK, code)){
				name=CommContext.E_BACK_NAME;
			}else if(StringUtils.equals(CommContext.INS_BACK, code)){
				name=CommContext.INS_BACK_NAME;
			}else if(StringUtils.equals(CommContext.DECL_RETURNED, code)){
				name=CommContext.DECL_RETURNED_NAME;
			}else if(StringUtils.equals(CommContext.INS_CHECK_BACK, code)){
				name=CommContext.INS_CHECK_BACK_NAME;
			}else if(StringUtils.equals(CommContext.INS_EXCEPTION, code)){
				name=CommContext.INS_EXCEPTION_NAME;
			}else if(StringUtils.equals(CommContext.MANUAL_INTERVENTION, code)){
				name=CommContext.MANUAL_INTERVENTION_NAME;
			}else if(StringUtils.equals(CommContext.PUMP_GROUP, code)){
				name=CommContext.PUMP_GROUP_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_INS_CHECK, code)){
				name=CommContext.WAIT_INS_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_CHECK, code)){
				name=CommContext.WAIT_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.CHECKED, code)){
				name=CommContext.CHECKED_NAME;
			}else if(StringUtils.equals(CommContext.HAVE_SAMPLE, code)){
				name=CommContext.HAVE_SAMPLE_NAME;
			}else if(StringUtils.equals(CommContext.SUBMIT, code)){
				name=CommContext.SUBMIT_NAME;
			}else if(StringUtils.equals(CommContext.VER_APP_Y, code)){
				name=CommContext.VER_APP_Y_NAME;
			}else if(StringUtils.equals(CommContext.VER_APP_N, code)){
				name=CommContext.VER_APP_N_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_FICTION, code)){
				name=CommContext.WAIT_FICTION_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_ATTESTATION, code)){
				name=CommContext.WAIT_ATTESTATION_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_ACQUIR, code)){
				name=CommContext.WAIT_ACQUIR_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_RECHECK, code)){
				name=CommContext.WAIT_RECHECK_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_MAKE, code)){
				name=CommContext.WAIT_MAKE_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_VERIFY, code)){
				name=CommContext.WAIT_VERIFY_NAME;
			}else if(StringUtils.equals(CommContext.WAIT_SIGN, code)){
				name=CommContext.WAIT_SIGN_NAME;
			}else if(StringUtils.equals(CommContext.DOCUMENTED, code)){
				name=CommContext.DOCUMENTED_NAME;
			}else if(StringUtils.equals(CommContext.CANCEL_DOC_S, code)){
				name=CommContext.CANCEL_DOC_S_NAME;
			}else if(StringUtils.equals(CommContext.CUST_CLEARANCE_S, code)){
				name=CommContext.CUST_CLEARANCE_S_NAME;
			}else if(StringUtils.equals(CommContext.SELF_CHECK_S, code)){
				name=CommContext.SELF_CHECK_S_NAME;
			}else if(StringUtils.equals(CommContext.MUTI_CHECK, code)){
				name=CommContext.MUTI_CHECK_NAME;
			}else if(StringUtils.equals(CommContext.INS_ERR, code)){
				name=CommContext.INS_ERR_NAME;
			}else if(StringUtils.equals(CommContext.DISQUR_RELEAS, code)){
				name=CommContext.DISQUR_RELEAS_NAME;
			}else if(StringUtils.equals(CommContext.HISTORY_LIBRARY, code)){
				name=CommContext.HISTORY_LIBRARY_NAME;
			}else if(StringUtils.equals(CommContext.RESSIGNMENT_DECL, code)){
				name=CommContext.RESSIGNMENT_DECL_NAME;
			}else if(StringUtils.equals(CommContext.REVOKED_DECL, code)){
				name=CommContext.REVOKED_DECL_NAME;
			}else if(StringUtils.equals(CommContext.TMP_SAVE, code)){
				name=CommContext.TMP_SAVE_NAME;
			}else if(StringUtils.equals(CommContext.DECL_PACK_AD_REG, code)){
				name=CommContext.DECL_PACK_AD_REG_NAME;
			}else if(StringUtils.equals(CommContext.NO_DECL_PACK_AD_REG, code)){
				name=CommContext.NO_DECL_PACK_AD_REG_NAME;
			}else if(StringUtils.equals(CommContext.DECL_PACK_AD_REG_BACK, code)){
				name=CommContext.DECL_PACK_AD_REG_BACK_NAME;
			}else if(StringUtils.equals(CommContext.INS_SECOND_EXCEPTION, code)){
				name=CommContext.INS_SECOND_EXCEPTION_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}
	
	/**
	 * <p>报检类别转名称</p>
	 * @param code
	 * @return
	 * @author 魏波
	 */
	public static String declCodeToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(CommContext.IN_TEST_QUE, code)){
				name=CommContext.IN_TEST_QUE_NAME;
			}else if(StringUtils.equals(CommContext.IN_FLOW, code)){
				name=CommContext.IN_FLOW_NAME;
			}else if(StringUtils.equals(CommContext.IN_VALI, code)){
				name=CommContext.IN_VALI_NAME;
			}else if(StringUtils.equals(CommContext.OUT_PRE, code)){
				name=CommContext.OUT_PRE_NAME;
			}else if(StringUtils.equals(CommContext.OUT_TEST_QUE, code)){
				name=CommContext.OUT_TEST_QUE_NAME;
			}else if(StringUtils.equals(CommContext.OUT_CHECK_CAR, code)){
				name=CommContext.OUT_CHECK_CAR_NAME;
			}else if(StringUtils.equals(CommContext.OUT_VALI, code)){
				name=CommContext.OUT_VALI_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}
	/**
	 * 
	* <p>描述:结果登记综合评定结论状态转名称</p>
	* @param code
	* @return
	* @author 李晨阳
	 */
	public static String assessStatusToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(CommContext.ASSESS_STATUS_BHG, code)){
				name=CommContext.ASSESS_STATUS_BHG_NAME;
			}else if(StringUtils.equals(CommContext.ASSESS_STATUS_HG, code)){
				name=CommContext.ASSESS_STATUS_HG_NAME;
			}else if(StringUtils.equals(CommContext.ASSESS_STATUS_WPD, code)){
				name=CommContext.ASSESS_STATUS_WPD_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}

	/**
	 * 
	* <p>描述:所需单证代码转名称</p>
	* @param codes
	* @return
	* @author 魏波
	 */
	public static String certCodeToName(String codes){
		String name="";
		if(!StringUtils.isEmpty(codes)){
			String code[] = codes.split(",");
			for(String cret:code){
				if(StringUtils.equals(CommContext.QUALITE, cret)){
					name +=CommContext.QUALITE_NAME+",";
				}else if(StringUtils.equals(CommContext.WEITHT, cret)){
					name +=CommContext.QUALITE_NAME+",";
				}else if(StringUtils.equals(CommContext.NUM, cret)){
					name +=CommContext.NUM_NAME+",";
				}else if(StringUtils.equals(CommContext.VET_HEAL, cret)){
					name +=CommContext.VET_HEAL_NAME+",";
				}else if(StringUtils.equals(CommContext.HEAL, cret)){
					name +=CommContext.HEAL_NAME+",";
				}else if(StringUtils.equals(CommContext.HYGI, cret)){
					name +=CommContext.HYGI_NAME+",";
				}else if(StringUtils.equals(CommContext.ANIM, cret)){
					name +=CommContext.ANIM_NAME+",";
				}else if(StringUtils.equals(CommContext.PLANT, cret)){
					name +=CommContext.PLANT_NAME+",";
				}else if(StringUtils.equals(CommContext.STEA_DIS, cret)){
					name +=CommContext.STEA_DIS_NAME+",";
				}else if(StringUtils.equals(CommContext.OUT_GOODS, cret)){
					name +=CommContext.OUT_GOODS_NAME+",";
				}else if(StringUtils.equals(CommContext.OUT_GOODS_N, cret)){
					name +=CommContext.OUT_GOODS_N_NAME+",";
				}else if(StringUtils.equals(CommContext.IN_DECL, cret)){
					name +=CommContext.IN_DECL_NAME+",";
				}else if(StringUtils.equals(CommContext.CONT, cret)){
					name +=CommContext.CONT_NAME+",";
				}else if(StringUtils.equals(CommContext.PORT, cret)){
					name +=CommContext.PORT_NAME+",";
				}else if(StringUtils.equals(CommContext.ELSE, cret)){
					name +=CommContext.ELSE_NAME+",";
				}else if(StringUtils.equals(CommContext.ELSE_DESC, cret)){
					name +=CommContext.ELSE_DESC_NAME+",";
				}
			}
			if(StringUtils.isNotEmpty(name)){
				return name.substring(0,name.length()-1);
			}
		}
		return "";
	}
	
	/**
	 * 
	* <p>描述:移动报检环节转名称</p>
	* @param code
	* @return
	* @author 魏波
	 */
	public static  String mobileLinkToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(MobileCommContext.DECL, code)){
				name=MobileCommContext.DECL_NAME;
			}else if(StringUtils.equals(MobileCommContext.SELF_DECL, code)){
				name=MobileCommContext.SELF_DECL_NAME;
			}else if(StringUtils.equals(MobileCommContext.AUTO_DECL, code)){
				name=MobileCommContext.AUTO_DECL_NAME;
			}else if(StringUtils.equals(MobileCommContext.SELF_CHECK, code)){
				name=MobileCommContext.SELF_CHECK_NAME;
			}else if(StringUtils.equals(MobileCommContext.SUBMENU, code)){
				name=MobileCommContext.SUBMENU_NAME;
			}else if(StringUtils.equals(MobileCommContext.INS, code)){
				name=MobileCommContext.INS_NAME;
			}else if(StringUtils.equals(MobileCommContext.SPOT, code)){
				name=MobileCommContext.SPOT_NAME;
			}else if(StringUtils.equals(MobileCommContext.SEND, code)){
				name=MobileCommContext.SEND_NAME;
			}else if(StringUtils.equals(MobileCommContext.RESULT, code)){
				name=MobileCommContext.RESULT_NAME;
			}else if(StringUtils.equals(MobileCommContext.INSP_AUDIT, code)){
				name=MobileCommContext.INSP_AUDIT_NAME;
//			}else if(StringUtils.equals(MobileCommContext.DEPT_AUDIT, code)){
//				name=MobileCommContext.DEPT_AUDIT_NAME;
//			}else if(StringUtils.equals(MobileCommContext.SECT_AUDIT, code)){
//				name=MobileCommContext.SECT_AUDIT_NAME;
			}else if(StringUtils.equals(MobileCommContext.EVALUATE, code)){
				name=MobileCommContext.EVALUATE_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}
	
	/**
	 * 
	* <p>描述:移动报检状态转名称</p>
	* @param code
	* @return
	* @author 魏波
	 */
	public static  String mobileStatusToName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			if(StringUtils.equals(MobileCommContext.WAIT_DECL, code)){
				name=MobileCommContext.WAIT_DECL_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_INS, code)){
				name=MobileCommContext.WAIT_INS_NAME;
			}else if(StringUtils.equals(MobileCommContext.PUMP_GROUP, code)){
				name=MobileCommContext.PUMP_GROUP_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_INS_CHECK, code)){
				name=MobileCommContext.WAIT_INS_CHECK_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_CHECK, code)){
				name=MobileCommContext.WAIT_CHECK_NAME;
			}else if(StringUtils.equals(MobileCommContext.CHECKED, code)){
				name=MobileCommContext.CHECKED_NAME;
			}else if(StringUtils.equals(MobileCommContext.HAVE_SAMPLE, code)){
				name=MobileCommContext.HAVE_SAMPLE_NAME;
			}else if(StringUtils.equals(MobileCommContext.SUBMIT, code)){
				name=MobileCommContext.SUBMIT_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_INS_RESULT, code)){
				name=MobileCommContext.WAIT_INS_RESULT_NAME;
			}else if(StringUtils.equals(MobileCommContext.INS_RESULT, code)){
				name=MobileCommContext.INS_RESULT_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_INSP_AUDIT, code)){
				name=MobileCommContext.WAIT_INSP_AUDIT_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_DEPT_AUDIT, code)){
				name=MobileCommContext.WAIT_DEPT_AUDIT_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_SECT_AUDIT, code)){
				name=MobileCommContext.WAIT_SECT_AUDIT_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_SEND_DATA_BACK, code)){
				name=MobileCommContext.WAIT_SEND_DATA_BACK_NAME;
			}else if(StringUtils.equals(MobileCommContext.WAIT_VER_APP, code)){
				name=MobileCommContext.WAIT_VER_APP_NAME;
			}else if(StringUtils.equals(MobileCommContext.VER_APP_RESULT, code)){
				name=MobileCommContext.VER_APP_RESULT_NAME;
			}else if(StringUtils.equals(MobileCommContext.VER_APP_Y, code)){
				name=MobileCommContext.VER_APP_Y_NAME;
			}else if(StringUtils.equals(MobileCommContext.VER_APP_N, code)){
				name=MobileCommContext.VER_APP_N_NAME;
			}else if(StringUtils.equals(MobileCommContext.PUMP_GROUP_N, code)){
				name=MobileCommContext.PUMP_GROUP_N_NAME;
			}else if(StringUtils.equals(MobileCommContext.INS_CHECK_N, code)){
				name=MobileCommContext.INS_CHECK_N_NAME;
			}else if(StringUtils.equals(MobileCommContext.CHECK_N, code)){
				name=MobileCommContext.CHECK_N_NAME;
			}else if(StringUtils.equals(MobileCommContext.INS_RESULT_N, code)){
				name=MobileCommContext.INS_RESULT_N_NAME;
			}else if(StringUtils.equals(MobileCommContext.END_SCENE, code)){
				name=MobileCommContext.END_SCENE_NAME;
			}else if(StringUtils.equals(MobileCommContext.AUDIT_FAIL, code)){
				name=MobileCommContext.AUDIT_FAIL_NAME;
			}else if(StringUtils.equals(MobileCommContext.SEND_DATA_BACK, code)){
				name=MobileCommContext.SEND_DATA_BACK_NAME;
			}else{
				name=code;
			}
		}
		return name;
	}

	
	/**
	 * 
	* <p>描述:查验预约-申请状态转名称</p>
	* @param code
	* @return
	* @author 吴有根
	 */
	public static String getApplyStatusName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			HashMap<String, String> statusMap=new HashMap<String, String>();
			statusMap.put(InsContext.APPLY_STATUS_0,InsContext.APPLY_STATUS_0_NAME);
			statusMap.put(InsContext.APPLY_STATUS_1,InsContext.APPLY_STATUS_1_NAME);
			statusMap.put(InsContext.APPLY_STATUS_2,InsContext.APPLY_STATUS_2_NAME);
			statusMap.put(InsContext.APPLY_STATUS_3,InsContext.APPLY_STATUS_3_NAME);
			statusMap.put(InsContext.APPLY_STATUS_4,InsContext.APPLY_STATUS_4_NAME);
			return statusMap.get(code) instanceof Object?statusMap.get(code):"";
		}
		return name;
	}
	
	
	/**
	 * 
	* <p>描述:查验预约-申请类别转名称</p>
	* @param code
	* @return
	* @author 吴有根
	 */
	public static String getApplyTypeName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			HashMap<String, String> typeMap=new HashMap<String, String>();
			typeMap.put(InsContext.APPLY_TYPE_1,InsContext.APPLY_TYPE_1_NAME);
			typeMap.put(InsContext.APPLY_TYPE_2,InsContext.APPLY_TYPE_2_NAME);
			return typeMap.get(code) instanceof Object?typeMap.get(code):"";
		}
		return name;
	}
	
	
	/**
	 * 
	* <p>描述:查验预约-受理结果转名称</p>
	* @param code
	* @return
	* @author 吴有根
	 */
	public static String getAcceptResultName(String code){
		String name="";
		if(StringUtils.isNotEmpty(code)){
			HashMap<String, String> resultMap=new HashMap<String, String>();
			resultMap.put(InsContext.ACCEPT_RESULT_0,InsContext.ACCEPT_RESULT_0_NAME);
			resultMap.put(InsContext.ACCEPT_RESULT_1,InsContext.ACCEPT_RESULT_1_NAME);
			resultMap.put(InsContext.ACCEPT_RESULT_2,InsContext.ACCEPT_RESULT_2_NAME);
			return resultMap.get(code) instanceof Object?resultMap.get(code):"";
		}
		return name;
	}

}

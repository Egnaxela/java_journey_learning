/**  
 * FileName:CompanyCodeUtils.java
 * @Description: 机构处理工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */
package com.rongji.eciq.mobile.utils;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.dao.insp.sub.SubAuxiliaryDao;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.SysOrganizeEntity;

/**
 * 
 * Description: 机构处理工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:34:56  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-07-12    李云龙                         1.0         添加：获取直属局机构代码方法
 */
@Service
public class CompanyCodeUtils {
	@Resource
	SubOrReasDao subOrReasDao;
	@Resource
	SubAuxiliaryDao  subAuxiliaryDao;
	 
	/**
     * 国家局代码
     */
    public   String NATION_ORG_CODE = "000000";
    /**
     * 国家局名称
     */
    public   String NATION_ORG_NAME_SC = "国家质检总局本部";
    /**
     * 国家局分类代码
     */
    public   String NATION_CATEGORY_CODE = "00000000";
    /**
     * 缺省定值
     */
    public   String DEFAULT_CODE = "00000000";
    /**
     * 国家局分类代码 未补零
     */
    public   String NATION_CATEGORY_CODE_N = "00";
	/**
     * 机构局代码所属层级 0级 总局
     */
    public   int ORG_LEVEL_0 = 0;
    /**
     * 机构局代码所属层级 1级 直属局
     */
    public   int ORG_LEVEL_1 = 1;
    /**
     * 机构局代码所属层级 2级 分支局（业务层级）
     */
    public   int ORG_LEVEL_2 = 2;
    /**
     * 机构局代码所属层级 3级 办事处/办公室（业务层级）
     */
    public   int ORG_LEVEL_3 = 3;
    /**
     * 机构局代码所属层级 4级 科室（处室） --新增
     */
    public   int ORG_LEVEL_4 = 4;
    /**
     * 机构局代码所属层级 5级 科室（部门） --调整
     */
    public   int ORG_LEVEL_5 = 5;
    /**
     * 机构局代码所属层级判断失败
     */
    public   int ORG_LEVEL_ERR = -1;
    /**
     * 机构代码长度
     */
    public   int ORG_LENGTH = 6;
    /**
     * 处室机构代码长度 --新增
     */
    public   int OFFICE_LENGTH = 8;
    /**
     * 部门机构代码长度 --新增
     */
    public   int DEPARTMENT_LENGTH = 10;
    /**
     * 机构分类代码长度 --新增
     */
    public   int ORG_CATEGORY_CODE_LENGTH = 8;
    /**
     * 处室分类代码长度：对应机构分类码+处室机构代码 总长16位 --新增
     */
    public   int OFFICE_CATEGORY_CODE_LENGTH = 16;
    /**
     * 部门分类代码长度：对应机构分类代码+部门机构代码 总长18位 --新增
     */
    public   int DEPARTMENT_CATEGORY_CODE_LENGTH = 18;
    
    
    
    /**
     * 通过传入的当前机构代码，返回一个map， 获得总局、直属局、分支局、办事处机构代码 <br>
     * 本方法已经被规则引擎征用，方法改进时，通知规则引擎制作者调整规则引擎 KEY：机构代码，VALUE：机构名称 <br>
     * KEY：ORG_LEVEL_0 VALUE：国家局代码 <br>
     * KEY：ORG_LEVEL_1 VALUE：直属局 <br>
     * KEY：ORG_LEVEL_2 VALUE：分支局 <br>
     * KEY：ORG_LEVEL_3 VALUE：办事处/办公室（业务层级） <br>
     * KEY：ORG_LEVEL_4 VALUE：科室(处室级别) <br>
     * KEY：ORG_LEVEL_5 VALUE：科室(部门级别)
     *
     * @param companyCode 机构代码
     *
     * @return Map KEY：机构层级，VALUE：机构代码
     */
    public Map<Integer, String> getOrgCode(String companyCode) {
        return getOrgMap(companyCode);
    }
    
    
    /**
     * 通过传入的当前机构代码，返回一个map， 获得总局、直属局、分支局、办事处机构代码 <br>
     * KEY：ORG_LEVEL_0 VALUE：国家局代码 <br>
     * KEY：ORG_LEVEL_1 VALUE：直属局 <br>
     * KEY：ORG_LEVEL_2 VALUE：分支局 <br>
     * KEY：ORG_LEVEL_3 VALUE：办事处/办公室（业务层级） <br>
     * KEY：ORG_LEVEL_4 VALUE：科室(处室级别) <br>
     * KEY：ORG_LEVEL_5 VALUE：科室(部门级别)
     *
     * @param companyCode 机构代码
     *
     * @return 机构map
     */
    public Map<Integer, String> getOrgMap(String companyCode) {
        if (StringUtils.isEmpty(companyCode)) {
            return null;
        } else {
            Map<Integer, String> orgLevel = new HashMap<Integer, String>();
            subOrReasDao.queryOrgMapByOrgCode(companyCode, orgLevel);
            return orgLevel;
        }
    }
    
    /**
     * 得到机构局代码所属层级
     *
     * @param categoryCode 机构分类码
     * @param seniorCategoryCode 父分类码
     *
     * @return 机构所属层级 <br>
     * -1 传递参数有误 <br>
     * 0 总局 <br>
     * 1 直属局 <br>
     * 2 分支局 <br>
     * 3 办事处、工作点 <br>
     * 4 科室(处室) <br>
     * 5 部门
     */
    public  int getOrgDeptLevelByCategoryCode(String categoryCode,
            String seniorCategoryCode) {
        // 分类码长度为16位 返回处室级别
        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == OFFICE_CATEGORY_CODE_LENGTH) {
            return ORG_LEVEL_4;
        }

        // 分类码长度为18位 返回部门级别
        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == DEPARTMENT_CATEGORY_CODE_LENGTH) {
            return ORG_LEVEL_5;
        }

        // 如果机构代码与总局代码一致则返回总局层级
        if (StringUtils.equals(NATION_CATEGORY_CODE, categoryCode)) {
            return ORG_LEVEL_0;
        }

        if (StringUtils.isNotEmpty(categoryCode)
                && categoryCode.length() == ORG_CATEGORY_CODE_LENGTH) {
            if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE, 0, 6),
                    StringUtils.substring(categoryCode, 2))) {
                // 如果分类码后六位为零，则为直属局
                return ORG_LEVEL_1;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 6), StringUtils.substring(seniorCategoryCode, 2))) {
                // 如果父分类码为直属局的，则本机构是分支局
                return ORG_LEVEL_2;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 4), StringUtils.substring(seniorCategoryCode, 4))) {
                // 如果父分类码为直属分支局的，则本机构是办事处/工作点
                return ORG_LEVEL_3;
            } else if (StringUtils.equals(StringUtils.substring(DEFAULT_CODE,
                    0, 2), StringUtils.substring(seniorCategoryCode, 6))) {
                // 如果父分类码为办事处，则本机构是工作点
                return ORG_LEVEL_4;
            } else {
                // 其他情况，失败。
                return ORG_LEVEL_ERR;
            }
        } else {
            // 其他情况，失败。
            return ORG_LEVEL_ERR;
        }
    }
    
    
    /**
     * 根据机构代码获取其作用机构代码 --后台调用 <br>
     * needOfficeCode true：优先返回上级处室代码；false：返回作用机构代码
     *
     * @param companyCode 机构代码
     * @param needOfficeCodeFirst 是否优先返回上级处室代码
     *
     * @return 作用机构代码
     */
    public  String getBusinessOrgCode(String companyCode,
            boolean needOfficeCodeFirst) {
    	SysOrganizeEntity sysOrg = getBusinessOrganize(companyCode,
                needOfficeCodeFirst);
        if (sysOrg != null) {
            return sysOrg.getOrgCode();
        } else {
            return null;
        }
    }
    
    /**
     * 根据机构代码、是否优先返回处级机构标志，获得作用机构信息
     *
     * @param orgCode 机构代码
     * @param needOfficeFirst 是否优先返回处室
     *
     * @return 作用机构信息
     */
    private SysOrganizeEntity getBusinessOrganize(String orgCode,
            boolean needOfficeFirst) {
        if (StringUtils.isEmpty(orgCode)) {
            return null;
        }
        
        SysOrganizeEntity sysOrg = subAuxiliaryDao.getSysOrgByOrgCode(orgCode);
        if (sysOrg != null
                && StringUtils.isNotEmpty(sysOrg.getCategoryCode())
                && sysOrg.getCategoryCode().length() == DEPARTMENT_CATEGORY_CODE_LENGTH) {
            // 机构代码为部门级别
            if (needOfficeFirst
                    || (StringUtils.isNotEmpty(sysOrg.getSeniorCategoryCode()) && sysOrg
                    .getSeniorCategoryCode().length() == ORG_CATEGORY_CODE_LENGTH)) {
                // 如果优先返回处室代码，则直接根据父分类码获得父机构代码
                sysOrg = subAuxiliaryDao.getSysOrgByCategoryCode(sysOrg
                        .getSeniorCategoryCode());
            } else {
                // 无需优先返回处室代码 需根据父分类代码获得上级机构父分类码再执行查询
                sysOrg = subAuxiliaryDao
                        .getSysOrgByCategoryCode(subAuxiliaryDao
                                .getSysOrgByCategoryCode(
                                        sysOrg.getSeniorCategoryCode())
                                .getSeniorCategoryCode());
            }
        } else if (sysOrg != null
                && StringUtils.isNotEmpty(sysOrg.getCategoryCode())
                && sysOrg.getCategoryCode().length() == OFFICE_CATEGORY_CODE_LENGTH) {
            // 当前登录机构为处室
            sysOrg = subAuxiliaryDao.getSysOrgByCategoryCode(sysOrg
                    .getSeniorCategoryCode());
        }
        return sysOrg;
    }
    
    /**
     * 根据机构代码获取机构级别
     *
     * @param manager
     * @param orgCode 机构代码
     *
     * @return 机构级别
     */
    public int getOrgDeptLevelByOrgCode(String orgCode) {

        String[] category = subAuxiliaryDao.queryCategory(orgCode);
        if (null == category) {
            return ORG_LEVEL_ERR;
        }

        return getOrgDeptLevelByCategoryCode(category[0], category[1]);
    }

    
    /**
     * 通过传入的当前机构代码，返回一个map， 获得总局、直属局、分支局、办事处机构代码 ---前台使用 <br>
     * KEY：ORG_LEVEL_0 VALUE：国家局代码 <br>
     * KEY：ORG_LEVEL_1 VALUE：直属局 <br>
     * KEY：ORG_LEVEL_2 VALUE：分支局 <br>
     * KEY：ORG_LEVEL_3 VALUE：办事处/办公室（业务层级） <br>
     * KEY：ORG_LEVEL_4 VALUE：科室(处室级别) <br>
     * KEY：ORG_LEVEL_5 VALUE：科室(部门级别)
     *
     * @param companyCode 机构代码
     *
     * @return 机构map
     */
    public Map<Integer, String> getOrgMapForFront(String companyCode) {
        Map<Integer, String> orgMap = getOrgMap(companyCode);
        return orgMap;
    }
    
    /**
     * 不论传什么，获得直属局机构代码
     */
    
    public String getLevelOrgCode(String companyCode){
    	Map<Integer, String> orgMap = getOrgMap(companyCode);
        if(orgMap!=null){
        	return orgMap.get(ORG_LEVEL_1);
        }
    	return companyCode;
    }
    
    
    
    
}

/**  
 * FileName:DateTools.java
 * @Description: 时间处理工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */ 
package com.rongji.eciq.mobile.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * 
 * Description: 时间处理工具类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-19 上午11:04:19  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-19      李云龙                      1.0         1.0 Version
 */
public class DateTools {
	
	private static final long serialVersionUID = 440525605745656148L;
    private static SimpleDateFormat sdf = new SimpleDateFormat();
    /**
     * 日期格式化(yyyy-MM-dd)
     */
    public static final String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";
    /**
     * 日期格式化(yyyy-MM)
     */
    public static final String PATTERN_YYYY_MM = "yyyy-MM";
    /**
     * 时间戳格式(yyyyMMddHHmmssSSS) 17位
     */
    public static final String PATTERN_TIMESTAMP = "yyyyMMddHHmmssSSS";
	
	/**
     * 获取毫秒级时间戳 17位
     *
     * @param * date 时间
     *
     * @return 时间戳
     */
    public static String getTimeStamp(Date date) {
        if (null == date) {
            return "";
        }
        String timeStampString = DateTools.getDateFormat(date, PATTERN_TIMESTAMP);
        return timeStampString;
    }
    
    /**
     * 根据传入的java.util.Date日期和规定的格式，得到字符串型的日期
     *
     * @param date java.util.Date日期， 如：new Date()
     * @param pattern 规定的格式，如：yyyy-MM-dd HH:mm:ss，或yyyy-MM-dd 等
     *
     * @return String 字符串型的日期
     */
    public static synchronized String getDateFormat(java.util.Date date,
            String pattern) {
        if (date == null) {
            return "";
        }
        synchronized (sdf) {
            String str = null;
            sdf.applyPattern(pattern);
            str = sdf.format(date);
            return str;
        }
    }

    /**
     * @param date
     *
     * @return String
     */
    public static synchronized String getDateDayFormat(java.util.Date date) {
        if (date == null) {
            return "";
        }
        String pattern = PATTERN_YYYY_MM_DD;
        return getDateFormat(date, pattern);
    }
    
}

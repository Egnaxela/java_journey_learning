/**  
 * FileName:DeclNoUtils.java
 * @Description: 报检号处理工具类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根 
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itown.rcp.core.utils.DateUtils;
import com.rongji.eciq.mobile.context.CommMsgContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.SysUser;
import com.rongji.eciq.mobile.entity.UserInfo;

/**
 * 
 * Description: 报检号处理工具类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根 
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:38:01  
 *  
 * Modification History:  
 * Date           Author      Version       Description  
 * ------------------------------------------------------------------  
 * 2017-05-10      吴有根                  1.0.0         1.0 Version
 * 2017-05-12      吴有根                  1.0.0         添加短号变长号的功能 
 * 2017-05-24      才江男                  1.0.0         短号变长号-对外
 */
@Service
public class DeclNoUtils {
	
	@Autowired(required=false)
	SubOrReasDao subOrReasDao;
	
	/**
	 * 报检号默认包含字符集
	 */
	private static final List<String> DEFAULT_DECL_CHAR_LIST=new ArrayList<String>(){
		
		private static final long serialVersionUID = 3494796344632441563L;
		
		{
            add("0");
            add("1");
            add("2");
            add("3");
            add("4");
            add("5");
            add("6");
            add("7");
            add("8");
            add("9");
            add("-");
		}
	};
	
    /**
     * 报检号默认包含的小写字符集合
     */
    private static final List<String> DEFAULT_DECL_L_CHAR_LIST = new ArrayList<String>() {
        {
            add("h");
            add("l");
            add("t");
            add("e");
        }
    };
    /**
     * 报检号默认包含的小写字符集合
     */
    private static final List<String> DEFAULT_DECL_H_CHAR_LIST = new ArrayList<String>() {
        {
            add("H");
            add("L");
            add("T");
            add("E");
        }
    };
    
    /**
     * 报检类型："1"表示入境货物报检，"2"表示出境货物报检，"3"表示出境货物运输包装报检，"4"表示集装箱适载报检,
     * "7"表示尸体棺柩，"8"表示更改申请 "6"旅客携带物，"5"邮寄截获物
     */
    private static final List<String> DEF_DECL_TYPE = new ArrayList<String>() {
        {
            add("1");
            add("2");
            add("3");
            add("4");
            add("7");
            add("8");
            add("5");
            add("6");
        }
    };

    /**
     * 报检号默认包含的大小写字符集合
     */
    private static final List<String> DEFAULT_DECL_L_CHAR_LIST_ALL = new ArrayList<String>() {
        {
            add("h");
            add("l");
            add("t");
            add("e");
            add("H");
            add("L");
            add("T");
            add("E");
        }
    };
    
    /**
     * 报检号为空""
     */
    private static final String EMPTY = "";

    /**
     * ASCII码大小写字母之间的差额
     */
    private static final int ASCII_L_TO_H = 32;

    /**
     * 报检号中的"-"
     */
    private static final String SUB_STR = "-";
    
    /**
     * 报检号长度"-"
     */
    public static final int DECL_NO_LENGTH = 15;

    /**
     * 报检号右侧12位默认代码
     */
    private static final String DEF_DECL_NO_RIGHT = "000000000000";
    
    /**
     * 企业端报检结尾字符
     */
    public static final String DECL_E = "E";
    
    /**
     * 转单结尾字符
     */
    public static final String DECL_T = "T";
    
    /**
     * 正式保存号结尾字符
     */
    public static final String DECL_H = "H";
    
    /**
     * 临时保存号结尾字符
     */
    public static final String DECL_L = "L";
    
    /**
     * 短报检号"-"右侧长度
     */
    private static final int DECL_NO_RIGHT_LENGTH = 13;
    
    /**
     * 报检号右侧6位默认代码
     */
    private static final String DEF_DECL_NO_RIGHT_6 = "000000";
    
    /**
     * 短报检号"-"右侧长度
     */
    private static final int DECL_NO_RIGHT_LENGTH_8 = 8;
    
	/**
	 * 判断是否为正式报检号
	 * @param declNo
	 * @return
	 */
	public static boolean checkOfficialDeclNo(String declNo) {
		//截取报检号最后一位进行匹配
        String decl_type = StringUtils.substring(declNo, declNo.length() - 1, declNo.length());
        if (DEFAULT_DECL_CHAR_LIST.contains(decl_type) && DECL_NO_LENGTH == declNo.length()) {
            return true;
        }
        return false;
	}

	/**
	 * 企业端报检号判断
	 * @param string
	 * @return
	 */
	public static boolean checkDeclNoE(String declNo) {
        if(StringUtils.isNotEmpty(declNo)){
            // 截取报检号的最后一位进行匹配
            String decl_type = StringUtils.substring(declNo, declNo.length() - 1, declNo.length());
            if (StringUtils.equals(decl_type, DECL_E)) {
                return true;
            }
        }
        return false;
	}

	/**
	 * 判断转单号
	 * @param declNo
	 * @return
	 */
	public static boolean checkDeclNoT(String declNo) {
        // 截取报检号的最后一位进行匹配
        String decl_type = StringUtils.substring(declNo, declNo.length() - 1, declNo.length());
        if (StringUtils.equals(decl_type, DECL_T)) {
            return true;
        }
        return false;
	}

	/**
	 * 判断入境报检类型
	 * @param declNo
	 * @return
	 */
	public static boolean checkInDeclType(String declNo) {
        // 报检号空值和长度判断
        if (StringUtils.isEmpty(declNo)
                || StringUtils.isEmpty(StringUtils.trim(declNo))
                || declNo.length() < DECL_NO_LENGTH) {
            return Boolean.FALSE;
        }
        if (StringUtils.contains(declNo, DECL_H)
                || StringUtils.contains(declNo, DECL_E)
                || StringUtils.contains(declNo, DECL_L)
                || StringUtils.contains(declNo, DECL_T)) {
            // 判断报检类型是否是入境报检
            if (StringUtils.equals(StringUtils.substring(declNo, 6, 7), DeclContext.DECL_TYPE_IN)) {
                return Boolean.TRUE;
            }
        } else {
            //TODO 根据报检号的生成规则获取
            if (StringUtils.equals(StringUtils.substring(declNo, 0, 1), DeclContext.DECL_TYPE_IN)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
	}

	/**
     * 出境报检类型判定（全号）。
     *
     * @param declNo 报检号
     * @return 是否为出境报检
     */
    public static boolean checkOutDeclType(String declNo) {
        // 报检号空值和长度判断
        if (StringUtils.isEmpty(declNo)
                || StringUtils.isEmpty(StringUtils.trim(declNo))
                || declNo.length() < DECL_NO_LENGTH) {
            return Boolean.FALSE;
        }
        // 判断报检类型是否是出境报检
        if (StringUtils.contains(declNo, DECL_H)
                || StringUtils.contains(declNo, DECL_E)
                || StringUtils.contains(declNo, DECL_L)
                || StringUtils.contains(declNo, DECL_T)) {
            // 判断报检类型是否是入境报检
            if (StringUtils.equals(StringUtils.substring(declNo, 6, 7), DeclContext.DECL_TYPE_OUT)) {
                return Boolean.TRUE;
            }
        } else {
            //TODO 根据报检号的生成规则获取
            if (StringUtils.equals(StringUtils.substring(declNo, 0, 1), DeclContext.DECL_TYPE_OUT)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
    }

	/**
	 * 出境包装报检类型判定
	 * @param declNo
	 * @return
	 */
	public static boolean checkGoodsDeclType(String declNo) {
        // 报检号空值和长度判断
        if (StringUtils.isEmpty(declNo)
                || StringUtils.isEmpty(StringUtils.trim(declNo))
                || declNo.length() < DECL_NO_LENGTH) {
            return Boolean.FALSE;
        }
        // 判断报检类型是否是出境包装报检
        if (StringUtils.contains(declNo, DECL_H)
                || StringUtils.contains(declNo, DECL_E)
                || StringUtils.contains(declNo, DECL_L)) {
            // 判断报检类型是否是入境报检
            if (StringUtils.equals(StringUtils.substring(declNo, 6, 7), DeclContext.DECL_TYPE_GOODS)) {
                return Boolean.TRUE;
            }
        } else {
            //TODO 根据报检号的生成规则获取
            if (StringUtils.equals(StringUtils.substring(declNo, 0, 1), DeclContext.DECL_TYPE_GOODS)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
	}

	/**
	 * 集装箱报检类型判定
	 * @param declNo
	 * @return
	 */
	public static boolean checkContainerDeclType(String declNo) {
        // 报检号空值和长度判断
        if (StringUtils.isEmpty(declNo)
                || StringUtils.isEmpty(StringUtils.trim(declNo))
                || declNo.length() < DECL_NO_LENGTH) {
            return Boolean.FALSE;
        }
        // 判断报检类型是否是集装箱报检
        if (StringUtils.contains(declNo, DECL_H)
                || StringUtils.contains(declNo, DECL_E)
                || StringUtils.contains(declNo, DECL_L)) {
            // 判断报检类型是否是入境报检
            if (StringUtils.equals(StringUtils.substring(declNo, 6, 7), DeclContext.DECL_TYPE_CONTAINER)) {
                return Boolean.TRUE;
            }
        } else {
            //TODO 根据报检号的生成规则获取
            if (StringUtils.equals(StringUtils.substring(declNo, 0, 1), DeclContext.DECL_TYPE_CONTAINER)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
	}

	 /**
     * 获取报检类型（全号、且不为空）。
     *
     * @param declNo 报检号
     * @return 是否为入境报检
     */
    public static String getDeclType(String declNo) {
        if (StringUtils.contains(declNo, DECL_H)
                || StringUtils.contains(declNo, DECL_E)
                || StringUtils.contains(declNo, DECL_L)
                || StringUtils.contains(declNo, DECL_T)) {
            return StringUtils.substring(declNo, 6, 7);
        } else {
            return StringUtils.substring(declNo, 0, 1);
        }
    }
	
    
    /**
     * 
    * <p>描述:报检单号短号变长号</p>
    * @param declNo
    * @return
    * @author 吴有根
     */
    public static String chageDeclNoToLangNo(String declNo, String declType, UserInfo userInfo) {
        if (StringUtils.isEmpty(declNo) || StringUtils.isEmpty(StringUtils.trim(declNo))) {
            // 报检号为空值时，弹出【报检号为空值！】
            return CommMsgContext.ERR_DECL_NULL;
        }

        // 执行报检号去空格操作
        declNo = StringUtils.trim(declNo);

        // 验证报检号合法性
        int declNoLength = declNo.length();
        // 单个报检号字符
        String subDeclStr;
        // 报检号中小写字母个数统计
        int lCharCount = 0;
        // 报检号中大写字母个数统计
        int hCharCount = 0;
        // 暂时存储报检号最后位的字母
        String declNoLastChar = "";
        // 记录报检号最后位的字母
        String declLastChar = "";
        for (int i = 0; i < declNoLength; i++) {
            // 如果报检号中包含数字或者指定字母以外的时候
            subDeclStr = declNo.substring(i, i + 1);
            if (!DEFAULT_DECL_CHAR_LIST.contains(subDeclStr)
                    && !DEFAULT_DECL_L_CHAR_LIST.contains(subDeclStr)
                    && !DEFAULT_DECL_H_CHAR_LIST.contains(subDeclStr)) {
                return CommMsgContext.ERR_DECL_CHAR_FORMAT;
            }

            if ((DEFAULT_DECL_L_CHAR_LIST.contains(subDeclStr)
                    || DEFAULT_DECL_H_CHAR_LIST.contains(subDeclStr)) && i != declNoLength - 1) {
                // 如果报检号中的字母不在最后出现则需报错
                return CommMsgContext.ERR_DECL_CHAR_RIGHT_FORMAT;
            }

            if (DEFAULT_DECL_L_CHAR_LIST.contains(subDeclStr)) {
                // 如果报检号中含有小写字母，则报检号中小写字母个数统计加一
                lCharCount += 1;
                // 暂存最后位的字母
                declNoLastChar = String.valueOf((char) ((int) subDeclStr.charAt(0) - ASCII_L_TO_H));
                // 将报检号最后位的字母去除
                declLastChar = declNo.substring(declNo.length() - 1, declNo.length());
                declNo = declNo.substring(0, declNo.length() - 1);
            }

            if (DEFAULT_DECL_H_CHAR_LIST.contains(subDeclStr)) {
                // 如果报检号中含有大写字母，则报检号中大写字母个数统计加一
                hCharCount += 1;
                // 暂存最后位的字母
                declNoLastChar = subDeclStr;
                // 将报检号最后位的字母去除
                declLastChar = declNo.substring(declNo.length() - 1, declNo.length());
                declNo = declNo.substring(0, declNo.length() - 1);
            }
        }

        if (lCharCount > 1 || hCharCount > 1) {
            // 报检号中的字母个数不得超过2个
        	return CommMsgContext.ERR_DECL_CHAR_SIZE;
             
        }

        // 获取年份
        Calendar date = new GregorianCalendar();
        String year = StringUtils.substring(DateUtils.toDateStr(date), 2, 4);
        if (DEFAULT_DECL_L_CHAR_LIST_ALL.contains(declNoLastChar)) {
            return chageDeclNoToLangNo(declNo, declType, userInfo, year, declNoLastChar, declLastChar);
        }
        if (declNo.contains(SUB_STR)) {
            // 传入的报检号中包含”-”的时候
            // 如果包含多个"-"的时候
            if (declNo.replaceFirst(SUB_STR, EMPTY).contains(SUB_STR)) {
                // 报检号短号格式不正确，号码中间不得存在多个【-】！
                return CommMsgContext.ERR_DECL_STYLE;
            }

            // 将报检号分组
            String[] subDeclNoArr = declNo.split(SUB_STR);
            if (null == subDeclNoArr || subDeclNoArr.length < 2) {
                return CommMsgContext.ERR_QUERY_RESULT;
            }
            if (!DEF_DECL_TYPE.contains(subDeclNoArr[0])) {
                // 报检号前缀必须在('1','2','3','4','7','8')之内 !
                return CommMsgContext.ERR_DECL_FORMAT;
            }

            // 如果输入的内容是“1-”的时候
            if (StringUtils.isEmpty(subDeclNoArr[1])) {
                // 报错格式不正确
                return CommMsgContext.ERR_DECL_LENGTH;
            }

            // 定义报检号"-"右侧号码获取变量
            String declRightNo;
            if (DECL_NO_RIGHT_LENGTH < subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧不得大于8位长度！
                return CommMsgContext.ERR_DECL_RIGHT_FORMAT;
            } else if (DECL_NO_RIGHT_LENGTH == subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧等于8位长度！
                declRightNo = subDeclNoArr[0] + subDeclNoArr[1];
            } else if ((DECL_NO_RIGHT_LENGTH - 1) == subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧等于7位长度！
                declRightNo = subDeclNoArr[0] + year.substring(0, 1) + subDeclNoArr[1];
            } else {
                declRightNo = subDeclNoArr[0] + year
                        + DEF_DECL_NO_RIGHT.substring(0, DEF_DECL_NO_RIGHT.length() - subDeclNoArr[1].length()) + subDeclNoArr[1];
            }

            // 整理报检号右侧（右侧不足6位的，左侧补“0”）
            declNo = declRightNo;
        } else {
            // 传入的报检号中未包含”-”的时候
            if (DECL_NO_LENGTH == declNo.length()
                    || DECL_NO_LENGTH == declNo.length() - 1) {
                return declNo + declLastChar;
            } else {
                if (declNo.length() > 12) {
                    // 如果输入的字符长度大于6，截取前六位作为报检号流水号
                    declNo = StringUtils.substring(declNo, 0, 12);
                } else {
                    // 如果字符长度小于等于6，则补齐6位作为报检号流水号
                    declNo = DEF_DECL_NO_RIGHT.substring(0, DEF_DECL_NO_RIGHT.length() - declNo.length()) + declNo;
                }

                if (StringUtils.isEmpty(declType)) {
                    declNo = DeclContext.DECL_TYPE_IN + year + declNo;
                } else {
                    declNo = declType + year + declNo;
                }
            }
        }
        return declNo;
    }
    
    
    public static String chageDeclNoToLangNo(String declNo, String declType,
            UserInfo userInfo, String year, String declNoLastChar, String declLastChar) {
        // 获取年份
        if (declNo.contains(SUB_STR)) {
            // 传入的报检号中包含”-”的时候
            // 如果包含多个"-"的时候
            if (declNo.replaceFirst(SUB_STR, EMPTY).contains(SUB_STR)) {
                // 报检号短号格式不正确，号码中间不得存在多个【-】！
                return CommMsgContext.ERR_DECL_STYLE;
            }

            // 将报检号分组
            String[] subDeclNoArr = declNo.split(SUB_STR);
            if (null == subDeclNoArr || subDeclNoArr.length < 2) {
                return CommMsgContext.ERR_QUERY_RESULT;
            }
            if (!DEF_DECL_TYPE.contains(subDeclNoArr[0])) {
                // 报检号前缀必须在('1','2','3','4','7','8')之内 !
                return CommMsgContext.ERR_DECL_FORMAT;
            }

            // 如果输入的内容是“1-”的时候
            if (StringUtils.isEmpty(subDeclNoArr[1])) {
                // 报错格式不正确
                return CommMsgContext.ERR_DECL_LENGTH;
            }

            // 定义报检号"-"右侧号码获取变量
            String declRightNo;
            if (DECL_NO_RIGHT_LENGTH_8 < subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧不得大于8位长度！
                return CommMsgContext.ERR_DECL_RIGHT_FORMAT_8;
            } else if (DECL_NO_RIGHT_LENGTH_8 == subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧等于8位长度！
                declRightNo = subDeclNoArr[0] + subDeclNoArr[1];
            } else if ((DECL_NO_RIGHT_LENGTH_8 - 1) == subDeclNoArr[1].length()) {
                // 报检号短号【-】右侧等于7位长度！
                declRightNo = subDeclNoArr[0] + year.substring(0, 1) + subDeclNoArr[1];
            } else {
                declRightNo = subDeclNoArr[0] + year
                        + DEF_DECL_NO_RIGHT_6.substring(0, DEF_DECL_NO_RIGHT_6.length() - subDeclNoArr[1].length()) + subDeclNoArr[1];
            }

            // 整理报检号右侧（右侧不足6位的，左侧补“0”）
            declNo = userInfo.getCompanyCode().substring(0, 6) + declRightNo;
        } else {
            // 传入的报检号中未包含”-”的时候
            if (DECL_NO_LENGTH == declNo.length()
                    || DECL_NO_LENGTH == declNo.length() - 1) {
                return declNo + declLastChar;
            } else {
                if (declNo.length() > 12) {
                    // 如果输入的字符长度大于6，截取前六位作为报检号流水号
                    declNo = StringUtils.substring(declNo, 0, 12);
                } else {
                    // 如果字符长度小于等于6，则补齐6位作为报检号流水号
                    declNo = DEF_DECL_NO_RIGHT_6.substring(0, DEF_DECL_NO_RIGHT_6.length() - declNo.length()) + declNo;
                }

                if (StringUtils.isEmpty(declType)) {
                    declNo = userInfo.getCompanyCode().substring(0, 6) + DeclContext.DECL_TYPE_IN + year + declNo;
                } else {
                    declNo = userInfo.getCompanyCode().substring(0, 6) + declType + year + declNo;
                }
            }
        }
        return declNo + declNoLastChar;

    }
    
    /**
    * <p>描述:短号变长号-对外</p>
    * @param declNo 报检号
    * @param userCode 用户代码
    * @param expImpFlag 出入境标志
    * @return 正式报检单号
    * @author 才江男
     */
    public String shortDeclNoToLong(String declNo, String userCode, String expImpFlag) {
    	if (StringUtils.isNotEmpty(declNo)) {
			UserInfo user = new UserInfo();
			user.setUserCode(userCode);
			SysUser sysUser = subOrReasDao.getSysUser(userCode);
			if (sysUser != null) {
				user.setCompanyCode(sysUser.getOrgCode());
				user.setUserName(sysUser.getUserName());
			}
			String longDeclNo = "";
			if (expImpFlag.equals("1")) {
				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
						DeclContext.DECL_TYPE_IN, user);
			} else if (expImpFlag.equals("2")) {
				longDeclNo = DeclNoUtils.chageDeclNoToLangNo(declNo,
						DeclContext.DECL_TYPE_OUT, user);
			}
			declNo = longDeclNo;
		}
    	return declNo;
    }
	
}

/**  
 * FileName:DeclOrgCodeUtils.java
 * @Description: 报检单流程涉及直属局获取工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.dao.insp.sub.SubOrReasDao;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;

/**
 * 
 * Description: 报检单流程涉及直属局获取工具类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:42:06  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10      李云龙                      1.0         1.0 Version
 */
@Service
public class DeclOrgCodeUtils {
	@Resource
	SubOrReasDao subOrReasDao;
	
	/**
     * 获得报检单流程涉及机构
     *
     * @param service 服务类
     * @param declNo 报检号
     * @param sendOrgCodePath 发送机构编码
     * @return
     */
    public List<String> getOrgCodes(String declNo, String sendOrgCodePath) {
        DclIoDeclEntity dcl = subOrReasDao.getDeclDetails(declNo);
        return getOrgCodes(dcl, sendOrgCodePath);
    }
    
    
    
    public static List<String> getOrgCodes(DclIoDeclEntity dcl, String sendOrgCodePath) {
        if (null == dcl) {
            return null;
        }
        String declOrgCode = dcl.getOrgCodePath();
        String vsaOrgCode = dcl.getVsaOrgCodePath();
        String purpOrgCode = dcl.getPurpOrgCodePath();
        String inspOrgCode = dcl.getInspOrgCodePath();
        List<String> orgPathList = new ArrayList<String>();
        if (StringUtils.isNotEmpty(declOrgCode)) {
            orgPathList.add(declOrgCode);
        }
        if (StringUtils.isNotEmpty(vsaOrgCode)) {
            orgPathList.add(vsaOrgCode);
        }
        if (StringUtils.isNotEmpty(purpOrgCode)) {
            orgPathList.add(purpOrgCode);
        }
        if (StringUtils.isNotEmpty(inspOrgCode)) {
            orgPathList.add(inspOrgCode);
        }
        if (StringUtils.isNotEmpty(sendOrgCodePath)) {
            orgPathList.add(sendOrgCodePath);
        }
        List<String> orgCodes = new ArrayList<String>();
        String org ;
        for (String path : orgPathList) {
            org = getLevel1OrgCode(path);
            if (StringUtils.isNotEmpty(org) && !orgCodes.contains(org)) {
                orgCodes.add(org);
            }
        }
        //入境口岸
        String entyPortCode = dcl.getEntyPortCode();
        //离境口岸
        String despPortCode = dcl.getDespPortCode();
        if (StringUtils.equals(DeclContext.DECL_TYPE_IN, dcl.getDeclType())) {
            if (StringUtils.isNotEmpty(entyPortCode)) {
                org = StringUtils.substring(entyPortCode, 0, 2) + "0000";
                if (StringUtils.isNotEmpty(org) && !orgCodes.contains(org)) {
                    orgCodes.add(org);
                }
            }
        } else {
            if (StringUtils.isNotEmpty(despPortCode)) {
                org = StringUtils.substring(despPortCode, 0, 2) + "0000";
                if (StringUtils.isNotEmpty(org) && !orgCodes.contains(org)) {
                    orgCodes.add(org);
                }
            }
        }

        return orgCodes;
    }
    
    /**
     * 根据orgPath 获得直属局机构
     *
     * @param orgPath
     * @return
     */
    private static String getLevel1OrgCode(String orgPath) {
        if (StringUtils.isNotEmpty(orgPath)) {
            String[] orgs = StringUtils.split(orgPath, "/");
            if (orgs != null && orgs.length > 1) {
                return orgs[1];
            }
        }
        return null;
    }


}

/**  
 * FileName:MobileHelper.java
 * @Description: model工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.DigestUtils;

import com.rongji.dfish.base.Page;
import com.rongji.eciq.mobile.model.base.DataModel;

/**
 * 
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:31:18  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 *  2017-5-08     才江男                      1.0        增加POSTmodel
 *  2017-5-18     才江男                      1.0        使用统一加密方式
 *  2017-6-21     才江男                      1.0        去掉/,附件有关问题
 */
public class MobileHelper {
	
	public static final int PAGE_SIZE = 10;
	
	public static final String LOGIN_USER = "loginUser";
	
	public static final String PARAM_VALIDATE_TIP = "基础参数不完整";
	
	public static final String OPERATION_SUCCESS_FLAG_TIP="操作成功";
	
	public static final String OPERATION_FAIL_FLAG_TIP="操作失败";
	
	public static final String REQUEST_FAIL_FLAG_TIP="请求失败";
	
	public static final String TEL_FORMAT_ERROR_TIP="联系电话格式不正确";
	
	//md5盐值字符串,用于混淆MD5
    private static final String salt = "sadkfjalsdjfalksj23423^&*^&%&!EBJKH#e™£4";

	
	/**
	 * 获得基础数据模型
	 * @param msg
	 * @return
	 */
	public static DataModel getBaseModel(String msg) {
		DataModel model = new DataModel();
		model.setMsg(msg);
		return model;
	}
	
	/**
	 * 获得基础数据模型
	 * @return
	 */
	public static DataModel getBaseModel() {
		return new DataModel();
	}
	
	/**
	 * 获得POST基础数据模型-不需返回实际数据
	 * @return
	 */
	public static DataModel getPOSTModel() {
		DataModel model = new DataModel();
		model.setData(1);
		return model;
	}
	
	
	/**
	 * 分页查询参数模型
	 * @return
	 */
	public static Page getPage(String cp) {
		Page page = new Page();
		page.setCurrentPage(Integer.parseInt(cp));
	    page.setPageSize(PAGE_SIZE);
		return page;
	}
	
	/**
	 * 分页查询参数模型带分页大小
	 * @return
	 */
	public static Page getPage(String cp,String max) {
		Page page = new Page();
		try {
			page.setCurrentPage(Integer.parseInt(cp));
		} catch (Exception e) {
			page.setCurrentPage(1);
		}
		
		try {
			page.setPageSize(Integer.valueOf(max));
		} catch (Exception e) {
			page.setPageSize(PAGE_SIZE);
		}
		return page;
	}
	
	/**
	 * 获得登录人员id
	 * @param request
	 * @return
	 */
	public static String getLoginUser(HttpServletRequest request) {
		return request.getParameter( LOGIN_USER	);
	}
	
	
	/**
	 * 根据用户代码获取防伪码
	 * 
	 * @param userId 用户代码
	 * @return 防伪码
	 */
	public static String getMD5(String userId) {
			String base = userId + salt;
			String md5 = HashMD5File.getStringMD5(base);
//	        String md5 = DigestUtils.md5DigestAsHex(base.getBytes());
	        return md5;
	}
	
}

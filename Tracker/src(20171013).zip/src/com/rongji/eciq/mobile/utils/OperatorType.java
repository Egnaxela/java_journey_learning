/**  
 * FileName:StringHelper.java
 * @Description: 评定指标操作类型辅助类 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根   
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import com.rongji.eciq.mobile.context.DeclContext;

/**
 * 
 * Description: 评定指标操作类型辅助类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:27:44  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10      吴有根                      1.0         1.0 Version
 */
public class OperatorType {

	//等于
    public final static int EQUAL_TYPE = 1;
    //不等于
    public final static int NOT_EQUAL_TYPE = 2;
    //小于
    public final static int LITTLE_THAN_TYPE = 3;
    //小于等于
    public final static int LITTLE_THAN_EQUAL_TYPE = 4;
    //大于
    public final static int GREAT_THAN_TYPE = 5;
    //大于等于
    public final static int GREAT_THAN_EQUAL_TYPE = 6;
    //等于
    public final static String EQUAL_TYPE_LITERAL = DeclContext.CHECK_LEVEL_E;
    //不等于
    public final static String NOT_EQUAL_TYPE_LITERAL = "!=";
    //小于
    public final static String LITTLE_THAN_TYPE_LITERAL =DeclContext.CHECK_LEVEL_L;
    //小于等于
    public final static String LITTLE_THAN_EQUAL_TYPE_LITERAL = DeclContext.CHECK_LEVEL_L_E;
    //大于
    public final static String GREAT_THAN_TYPE_LITERAL =DeclContext.CHECK_LEVEL_H;
    //大于等于
    public final static String GREAT_THAN_EQUAL_TYPE_LITERAL = DeclContext.CHECK_LEVEL_H_E;
    
    private final static Map<String,String> operMap=new HashMap<String,String>(){
        {   
            put(EQUAL_TYPE_LITERAL, EQUAL_TYPE_LITERAL);
            put(NOT_EQUAL_TYPE_LITERAL, NOT_EQUAL_TYPE_LITERAL);
            put(LITTLE_THAN_TYPE_LITERAL, LITTLE_THAN_TYPE_LITERAL);
            put(LITTLE_THAN_EQUAL_TYPE_LITERAL, LITTLE_THAN_EQUAL_TYPE_LITERAL);
            put(GREAT_THAN_TYPE_LITERAL, GREAT_THAN_TYPE_LITERAL);
            put(GREAT_THAN_EQUAL_TYPE_LITERAL, GREAT_THAN_EQUAL_TYPE_LITERAL);
        }
    };
    public static String getLittleThanType() {
        return String.valueOf(LITTLE_THAN_EQUAL_TYPE) + "," + String.valueOf(
                LITTLE_THAN_TYPE);
    }

    public static String getLittleThanTypeLiteral() {
        return String.valueOf(LITTLE_THAN_EQUAL_TYPE_LITERAL) + ","
               + String.valueOf(LITTLE_THAN_TYPE_LITERAL);
    }

    public static String getGreatThanType() {
        return String.valueOf(GREAT_THAN_EQUAL_TYPE) + "," + String.valueOf(
                GREAT_THAN_TYPE);
    }

    public static String getGreatThanTypeLiteral() {
        return String.valueOf(GREAT_THAN_EQUAL_TYPE_LITERAL) + ","
               + String.valueOf(GREAT_THAN_TYPE_LITERAL);
    }

    public static String getLiteral(int type) {
        switch (type) {
            case EQUAL_TYPE:
                return EQUAL_TYPE_LITERAL;
            case NOT_EQUAL_TYPE:
                return NOT_EQUAL_TYPE_LITERAL;
            case LITTLE_THAN_EQUAL_TYPE:
                return LITTLE_THAN_EQUAL_TYPE_LITERAL;
            case LITTLE_THAN_TYPE:
                return LITTLE_THAN_TYPE_LITERAL;
            case GREAT_THAN_EQUAL_TYPE:
                return GREAT_THAN_EQUAL_TYPE_LITERAL;
            case GREAT_THAN_TYPE:
                return GREAT_THAN_TYPE_LITERAL;

            default:
                return "";
        }

    }

    public static String getLiteral(String type) {
        if (type != null) {
            try {
                int i = Integer.parseInt(type);
                return getLiteral(i);
            } catch (Exception e) {
                return getLiteralSearchForOrginal(type);
            }

        } else {
            return "";
        }
    }
    
    public static String getLiteralSearchForOrginal(String orginal){
        String operSymbl=operMap.get(orginal);
        if(StringUtils.isEmpty(operSymbl)){
            operSymbl="";
        }
        return operSymbl;
    }
}

/**  
 * FileName:ProcessControlUtils.java
 * @Description: 流程处理组件 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.entity.SysProcessLogEntity;
import com.rongji.eciq.mobile.entity.SysProcessTimeEntity;
import com.rongji.eciq.mobile.entity.UserInfo;

/**
 * 
 * Description: 流程处理组件
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:26:32  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10      李云龙                      1.0         1.0 Version
 */
@Service
public class ProcessControlUtils {
	@Resource
	StatusControlUtils statusControlUtils;
	@Resource
	SysProcessUtils sysProcessUtils;
	
	
	/**
	 * 更新环节、状态，入库流程日志（不经过流程规则，独立调用）--默认主施检，更新报检单流程
	 * 
	 * @param em
	 *            数据库实体操作对象
	 * @param declNo
	 *            报检号
	 * @param declWorkNo
	 *            流水号
	 * @param processLink
	 *            新流程环节
	 * @param status
	 *            新流程状态
	 * @param user
	 *            用户信息
	 * @param perProcessLink
	 *            本流程环节
	 * @param perProcessStatus
	 *            本流程状态
	 * @param nodeMemo
	 *            流程日志表——环节描述
	 * @param remark
	 *            流程日志表——备注
	 * @param principalFlag
	 *            主施检标志 true-主施检
	 * @param declNoE
	 *            E号或H号
	 */
	public void updateProAndStatus(String declNo,
			String declWorkNo, String processLink, String status,
			UserInfo user, String perProcessLink, String perProcessStatus,
			String nodeMemo, String remark, boolean principalFlag,
			String declNoE) {
		// 更新流程日志上一状态的操作人和操作时间
		updatePreviousProcessLog(declNo, perProcessStatus, perProcessLink,
				user, declNoE);
		// 更新报检单主表状态（并判断是否需要调用施检初始化）、写新流程日志
		updateInspectionStatusAndLink(declNo, declWorkNo, processLink,
				status, user, nodeMemo, remark, principalFlag);
	}
	
	
	
	
	/**
	 * 更新上一流程的结束时间、操作人信息
	 * 
	 * @param declNo
	 *            报检号
	 * @param perProcessStatus
	 *            上一流程状态
	 * @param perProcessNode
	 *            上一流程环节
	 * @param user
	 *            用户信息
	 * @param em
	 *            数据库实体操作对象
	 * @param declNoE
	 *            e号报检号或H号报检号
	 */
	@Autowired
	HibernateTemplate chgHibernateTemplate;
	public  void updatePreviousProcessLog(String declNo,
			String perProcessStatus, String perProcessNode, UserInfo user, String declNoE) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		if (StringUtils.isNotEmpty(declNo)) {
			String selectSql;
			if (StringUtils.isNotEmpty(declNoE)) {
			 selectSql = "select a from SysProcessLogEntity a where a.declNo ='"+declNoE+"' and a.endFlag ='0' ";
			}else{
		      selectSql = "select a from SysProcessLogEntity a where a.declNo ='"+declNo+"' and a.endFlag ='0' ";	
			}
			if (StringUtils.isNotEmpty(perProcessStatus)
					&& StringUtils.isNotEmpty(perProcessNode)) {
				selectSql = selectSql
						+ " and a.processStatus = '"+perProcessStatus+"'"
						+ "and a.processNode ='"+perProcessNode+"'";
			} else {
				selectSql = selectSql + " order by a.operDate desc ";
			}
			Query selectQuery=session.createQuery(selectSql);  
			List<SysProcessLogEntity> nodeLists = selectQuery.list();
			if (CollectionUtils.isNotEmpty(nodeLists)) {
				SysProcessLogEntity sysLog = nodeLists.get(0);
				sysLog.setEndDate(new Date());
				sysLog.setTreaOrgCode((user == null || StringUtils.isEmpty(user
						.getCompanyCode())) ? "auto" : user.getCompanyCode());
				sysLog.setTreaOperName((user == null || StringUtils
						.isEmpty(user.getUserName())) ? "系统" : user
						.getUserName());
				sysLog.setTreaOperCode((user == null || StringUtils
						.isEmpty(user.getUserCode())) ? "auto" : user
						.getUserCode());
				
				session.merge(sysLog);
				session.close();
			}
		}
	}
	
	
	/**
	 * 更新报检单状态、记录流程日志
	 * 
	 * @param service
	 *            服务类
	 * @param declNo
	 *            报检号
	 * @param processLink
	 *            环节
	 * @param status
	 *            状态
	 * @param user
	 *            用户
	 * @param nodeMemo
	 *            备注
	 * @param remark
	 *            备注
	 * @param principalFlag
	 *            主施检标志
	 */
	public  void updateInspectionStatusAndLink(
			String declNo, String declWorkNo, String processLink,
			String status, UserInfo user, String nodeMemo, String remark,
			boolean principalFlag) {
		if (principalFlag) {
			String userCode;
			// 主施检更新报检单状态
			if (user==null|| StringUtils.isEmpty(user.getUserCode())) {
				userCode = "auto";
			}else{
				userCode = user.getUserCode();
			}
			statusControlUtils.updateStatus(declNo, userCode, processLink,status);
		}
		// 保存或修改超流程信息
		saveOrUpdateSysProcessTime(declNo, processLink, user);
		String orgCode = "";
                // add by TK
                if ((DeclNoUtils.checkGoodsDeclType(declNo)
                        || DeclNoUtils.checkContainerDeclType(declNo))
                        && CommContext.SUBMENU.equals(processLink) 
                        && CommContext.WAIT_INS.equals(status)) {
                    orgCode = sysProcessUtils.getDeptCode(declNo);
                }else{
                    orgCode = getOrgCode(user, declNo);
                }
                // add by TK
		// 记录流程日志
		writeLog(user, declNo, declWorkNo, processLink, status, nodeMemo,
				orgCode, remark);
	}
	
	
	/**
	 * 保存或修改流程时间查询表信息
	 * 
	 * @param em
	 * @param declNo
	 *            报检单号
	 * @param processNode
	 *            流程环节
	 * @param user
	 *            用户信息
	 */
	public void saveOrUpdateSysProcessTime(
			String declNo, String processNode, UserInfo user) {
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		SysProcessTimeEntity sysProcessTimeEntity = sysProcessUtils.buildSysProcessTimeEntity(declNo, processNode, user);
		if (sysProcessTimeEntity != null) {
			session.merge(sysProcessTimeEntity);
		}
		session.close();
	}
	
	
	/**
	 * 机构信息
	 * 
	 * @param em
	 * @param user
	 * @param declNo
	 * 
	 * @return 获得
	 */
	public  String getOrgCode( UserInfo user,String declNo) {
		String orgCode;
		// 第一个判断王惠峰增加auto.equals 初始化施检异步后，不能从session中获取机构信息
		if (user != null && StringUtils.isEmpty(user.getCompanyCode())
				&& !"auto".equals(user.getUserCode())) {
			// 签证环节命中待归档结论，获取当前登录人信息作为机构代码
			orgCode = user.getBusinessOrgCode();
		} else if (user != null
				&& StringUtils.isNotEmpty(user.getCompanyCode())) {
			orgCode = user.getCompanyCode();
		} else {
			// 机审直接命中待归档结论的报检单，由于获取不到用户信息，直接获取报检单的主施检机构作为机构代码
			orgCode = sysProcessUtils.getOrgCodeByDeclNo(declNo);
		}
		return orgCode;
	}

	/**
	 * 记录流程日志
	 * 
	 * @param user
	 *            用户信息
	 * @param declNo
	 *            报检号
	 * @param declWorkNo
	 * @param processLink
	 *            环节
	 * @param status
	 *            状态
	 * @param nodeMemo
	 *            环节描述
	 * @param orgCode
	 *            机构代码
	 * @param remark
	 *            备注
	 * @param em
	 *            entityManager
	 */
	public void writeLog(UserInfo user, String declNo,
			String declWorkNo, String processLink, String status,
			String nodeMemo, String orgCode, String remark) {
		// 增加日志信息
		SysProcessLogEntity logEntity = new SysProcessLogEntity();
		// 设定日志ID
		logEntity.setProcessLogId(UUIDKeyGeneratorUils.newInstance()
				.generateKey());
		// 设定报检号
		logEntity.setDeclNo(declNo);
		// 设定流程环节
		logEntity.setProcessNode(processLink);
		// 设定流程状态
		logEntity.setProcessStatus(status);
		// 设定环节描述
		logEntity.setNodeMemo(nodeMemo);
		// 设定操作人代码
		String userName;
		String userCode;
		if (user == null || StringUtils.isEmpty(user.getUserCode())) {
			userCode = "auto";
		} else {
			userCode = user.getUserCode();
		}
		if (user == null || StringUtils.isEmpty(user.getUserName())) {
			userName = "auto";
		} else {
			userName = user.getUserName();
		}
		logEntity.setOperCode(userCode);
		// 设定操作人名称
		logEntity.setOperName(userName);
		// 设定操作人名称
		logEntity.setOperDate(new Date());
		// 设定归档标志
		logEntity.setFalgArchive(CommContext.ARCHIVE_0);
		// 设定备注
		logEntity.setRemark(remark);
		// 设置流程操作机构
		logEntity.setTreaOrgCode(orgCode);
		// 将流程日志入库
		Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
		session.merge(logEntity);
		session.close();
	}
	
    
    public void saveList(List objList) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        if (CollectionUtils.isNotEmpty(objList)) {
            for (Object obj : objList) {
            	session.merge(obj);
            	session.close();
            }
        }
    }
    
	
}

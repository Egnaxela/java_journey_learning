/**  
 * FileName:RedisCacheInitUtils.java     
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年6月12日 上午10:55:35  
 *  
 */  

package com.rongji.eciq.mobile.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rongji.eciq.mobile.entity.InsDeclMagEntity;

/**  
 * Description:   
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年6月12日 上午10:55:35  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年6月12日      吴有根                      1.0         1.0 Version  
 */

public class RedisCacheInitUtils {

	public static void main(String[] args) {
		System.out.println(RedisCacheInitUtils.class.getClassLoader());
		//sun.misc.Launcher$AppClassLoader@27a8c4e7
		//sun.misc.Launcher$AppClassLoader@43be2d65
		System.out.println(RedisCacheInitUtils.class.getResource(""));
		System.out.println(RedisCacheInitUtils.class.getResource("/"));
		System.out.println(java.lang.String.class.getClassLoader());
		System.out.println(String.class.getClassLoader());
		System.out.println();
		ApplicationContext aContext=new ClassPathXmlApplicationContext("/WEB-INF/applicationContext.xml");
		aContext.getBean(InsDeclMagEntity.class);
		System.out.println(aContext);
		
	//	loadClassMethods();

	}
	
	
	@Test
	public void loadClassMethods() throws Exception{
		Integer i=0;
		Class<? extends Integer> clazz=i.getClass();
	
		Field field=Boolean.class.getDeclaredField("TRUE");
		field.setAccessible(true);
		Field modifiersField=Field.class.getDeclaredField("modifiers");
		modifiersField.setAccessible(true);
		modifiersField.setInt(field, field.getModifiers()&~Modifier.FINAL);
		field.set(null, false);
		
		Boolean value=true;
		if(value){
			System.out.println("value is true");
		}else{
			System.out.println("value is false");
		}
	}
}

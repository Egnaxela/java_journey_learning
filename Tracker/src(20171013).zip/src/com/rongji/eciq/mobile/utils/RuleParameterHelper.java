/**  
 * FileName:   RuleParameterHelper.java  
 * @Description: 
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年4月27日 上午10:03:40  
 *  
 */  

package com.rongji.eciq.mobile.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**  
 * Description: 规则引擎参数设置帮助类  
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     吴有根  
 * @version:    1.0  
 * Create at:   2017年4月27日 上午10:03:40  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017年4月27日      吴有根                      1.0         1.0 Version  
 */

public class RuleParameterHelper {
	
    public static List createRuleParam(String paramKey, String paramValue){
        Map map = new HashMap();
        map.put(paramKey, paramValue);
        List mapList = new ArrayList();
        mapList.add(map);
        return mapList;
   }
   
   public static List createRuleParam(Map map){
        List mapList = new ArrayList();
        mapList.add(map);
        return mapList;
   }
}

/**  
 * FileName:StatusControlUtils.java
 * @Description: 更新报检单状态类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */ 
package com.rongji.eciq.mobile.utils;

import java.util.Date;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Service;

import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.entity.AuxInsProcessLogEntity;
import com.rongji.eciq.mobile.entity.UserInfo;

/**
 * Description: 更新报检单状态类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:22:51  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-06-01      李云龙                      1.0         添加记录辅施检流程日志
 */
@Service
public class StatusControlUtils {
	 /**
     * 报检单状态更新
     *
     * @param declNo        报检号
     * @param operator      操作员
     * @param processLink     环节
     * @param status     状态
     */
	@Autowired
	HibernateTemplate chgHibernateTemplate;
    public  void updateStatus(String declNo, String operator, String processLink, String status) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	
    	// 获取报检单类型
        String declType = DeclNoUtils.getDeclType(declNo);
        Date nowTime=new Date();
        // 定义SQL语句
        String sqlStr = "UPDATE DCL_IO_DECL SET PROCESS_STATUS='"+status+"', OPER_CODE='"+operator+"', PROCESS_LINK='"+processLink+"',OPER_TIME=sysdate  WHERE DECL_NO='"+declNo+"'";
        Query query = null;
        // 入境报检、出境报检时
        if (StringUtils.equals(declType, DeclContext.DECL_TYPE_IN)
            || StringUtils.equals(declType, DeclContext.DECL_TYPE_OUT)) {
            query = session.createSQLQuery(sqlStr);
            // 执行更新语句
            session.beginTransaction();
            int i =query.executeUpdate();
            session.getTransaction().commit();
            String magSql = "UPDATE INS_DECL_MAG SET PROCESS_STATUS='"+status+"' WHERE DECL_NO= '"+declNo+"'";
            Query magQuery = session.createSQLQuery(magSql);
            session.beginTransaction();
            magQuery.executeUpdate();
            session.getTransaction().commit();
            session.close();
            // 出境货物包装报检
        } else if (StringUtils.equals(declType, DeclContext.DECL_TYPE_GOODS)) {
            sqlStr = "UPDATE DCL_PACK_DECL SET PROCESS_STATUS = '"+status+"', PROCESS_LINK='"+operator+"',OPER_TIME=sysdate WHERE DECL_NO = '"+declNo+"'";
            query = session.createSQLQuery(sqlStr);
            // 执行更新语句
            session.beginTransaction();
            query.executeUpdate();
            session.getTransaction().commit();
            session.close();
          // 集装箱报检
        } else if (StringUtils.equals(declType, DeclContext.DECL_TYPE_CONTAINER)) {
            sqlStr = "UPDATE DCL_CONT SET PROCESS_STATUS = '"+status+"',PROCESS_LINK = '"+operator+"'OPER_TIME=sysdate WHERE CONT_DECL_NO = '"+declNo+"'";
            query = session.createSQLQuery(sqlStr);
            session.beginTransaction();
            // 执行更新语句
            query.executeUpdate();
            session.getTransaction().commit();
            session.close();
          // 邮寄物报检、旅客携带物报检
        } else if (StringUtils.equals(declType, DeclContext.DECL_TYPE_MAIL)|| StringUtils.equals(declType, DeclContext.DECL_TYPE_CARRY)) {
            sqlStr = "UPDATE DCL_INTER_DECL SET PROCESS_STATUS = '"+status+"' WHERE DECL_NO = '"+declNo+"'";
            query = session.createSQLQuery(sqlStr);
            session.beginTransaction();
            // 执行更新语句
            query.executeUpdate();
            session.getTransaction().commit();
            session.close();
          // 尸体棺柩报检
        } else if (StringUtils.equals(declType, DeclContext.DECL_TYPE_CORPSE)) {
            sqlStr = "UPDATE DCL_DEAD_DECL SET PROCESS_STATUS = '"+status+"' WHERE DECL_NO = '"+declNo+"'";
            query = session.createSQLQuery(sqlStr);
            session.beginTransaction();
            // 执行更新语句
            query.executeUpdate();
            session.getTransaction().commit();
            session.close();
          // 更改申请报检
        } else if (StringUtils.equals(declType, DeclContext.DECL_TYPE_CHANGE)) {
            sqlStr = "UPDATE DCL_CHG_DECL SET PROCESS_STATUS = '"+status+"' WHERE CHG_DECL_NO = '"+declNo+"'";
            query = session.createSQLQuery(sqlStr);
            session.beginTransaction();
            // 执行更新语句
            query.executeUpdate();
            session.getTransaction().commit();
            session.close();
        }
    }
    
    /**
     * 
    * <p>描述:修改流程环节值</p>
    * @param declNo
    * @param processLink
    * @param processStatus
    * @author 李云龙
     */
    public void updateProcess(String declNo,String processLink,String processStatus,String operator){
    	updateDclProcess(declNo,processLink,processStatus,operator);
    	updateMagProcess(declNo,processStatus);
    }
    
    /**
     * 
    * <p>描述:更新报检单主表流程</p>
    * @param declNo
    * @param processLink
    * @param processStatus
    * @param operator
    * @author 李云龙
     */
    public void updateDclProcess(String declNo,String processLink,String processStatus,String operator){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
    	String sqlStr = "UPDATE DCL_IO_DECL SET PROCESS_STATUS='"+processStatus+"', OPER_CODE='"+operator+"', PROCESS_LINK='"+processLink+"',OPER_TIME=sysdate  WHERE DECL_NO='"+declNo+"'";
        Query magQuery = session.createSQLQuery(sqlStr);
        magQuery.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * 
    * <p>描述:更新报检单管理表</p>
    * @param declNo
    * @param processStatus
    * @author 李云龙
     */
    public void updateMagProcess(String declNo,String processStatus){
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
    	session.beginTransaction();
    	String magSql = "UPDATE INS_DECL_MAG SET PROCESS_STATUS='"+processStatus+"',OPER_TIME=sysdate WHERE DECL_NO= '"+declNo+"'";
        Query magQuery = session.createSQLQuery(magSql);
        magQuery.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * 记录辅施检流程日志
     *
     */
    public void writeAuxLog(String exeInspOrgCode, String excInspDeptCode, String inspContCodes, String insDclMagId, String declNo, String processLink, String processstatus, String remark, String userCode,String userName,String companyCode) {
        
    	// 增加日志信息
    	AuxInsProcessLogEntity logEntity = new AuxInsProcessLogEntity();
        // 设定日志ID
        logEntity.setAuxInsProcessLogId(UUIDKeyGeneratorUils.newInstance().generateKey());
        // 施检管理记录id
        logEntity.setDeclMagId(insDclMagId);
        // 设定报检号
        logEntity.setDeclNo(declNo);
        // 设定流程环节
        logEntity.setProcessNode(processLink);
        // 设定流程状态
        logEntity.setProcessStatus(processstatus);
        // 设定环节描述
        //logEntity.setNodeMemo(nodeMemo);
        // 设定操作人代码
        if (StringUtils.isEmpty(userCode)) {
            userCode = "auto";
        } 
        if (StringUtils.isEmpty(userName)) {
            userName = "系统";
        }
        logEntity.setOperCode(userCode);
        // 设定操作人名称
        logEntity.setOperName(userName);
        // 设定操作时间
        logEntity.setOperDate(new Date());
        // 设定归档标志
        logEntity.setFalgArchive(CommContext.ARCHIVE_0);
        // 设定备注
        logEntity.setRemark(remark);
        // 设置流程操作机构
        logEntity.setTreaOrgCode(companyCode);
        //设置施检机构
        logEntity.setExeInspOrgCode(exeInspOrgCode);
        //设置施检部门
        logEntity.setExcInspDeptCode(excInspDeptCode);
        //设置施检内容
        logEntity.setInspContCodes(inspContCodes);
        // 将流程日志入库
        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        session.beginTransaction();
        session.merge(logEntity);
        session.getTransaction().commit();
        session.close();
    }
    
}

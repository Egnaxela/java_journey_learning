/**  
 * FileName:StringHelper.java
 * @Description: 字符串的一些通用方法工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

/**
 * 
 * Description: 字符串的一些通用方法工具类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:20:25  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10      李云龙                      1.0         1.0 Version
 */

public class StringHelper extends StringUtils {

    /**
     * 判断多个字符串参数是否为空或空串组成
     * @param strs 逗号隔开的多个字符串参数
     *
     * @return false:不为空 true:为空
     *
     * @author 黄庆炬
     */
    public static boolean isEmpty(String... strs) {
        boolean flag = false;
        for (String str : strs) {
            flag = StringUtils.isEmpty(str);
            if (flag) {
                break;
            }
        }
        return flag;
    }

    /**
     * 判断多个字符串参数是否为不为空字符串组成
     * @param strs 逗号隔开的多个字符串参数
     *
     * @return false:为空 true:不为空
     *
     * @author 黄庆炬
     */
    public static boolean isNotEmpty(String... strs) {
        boolean flag = true;
        for (String str : strs) {
            flag = StringUtils.isNotEmpty(str);
            if (!flag) {
                break;
            }
        }
        return flag;
    }

    /**
     * 将Bean上的属性名，转成数据库对应中的标准字段名
     * <br/>userName 转化成 USER_NAME
     *
     * @param propName
     *
     * @return 数据库字段名
     */
    public static String transProp2DBField(String propName) {
        if (isEmpty(propName)) {
            return "非标准的Bean属性";
        }

        Pattern pat = Pattern.compile("[A-Z]?[a-z]+");
        Matcher mat = pat.matcher(propName);
        StringBuilder sb = new StringBuilder();
        while (mat.find()) {
            String part = mat.group(0);
            part = "_" + StringUtils.upperCase(part);
            sb.append(part);
        }

        return StringUtils.substringAfter(sb.toString(), "_");
    }

    /**
     * 将数据库对应中的字段名，转成Bean上的标准属性名
     * <br/> USER_NAME 转化成 userName
     *
     * @param fieldName 数据库字段名称
     *
     * @return Bean中属性名
     */
    public static String transDBField2Prop(String fieldName) {
        if (isEmpty(fieldName)) {
            return "";
        }

        //不包含_,将直接返回原来的name
        if (!fieldName.contains("_")) {
            return fieldName;
        }

        fieldName = fieldName.toLowerCase();//统一修改成小写
        String[] colArr = fieldName.split("_");
        StringBuilder sb = new StringBuilder(colArr[0]); //第1个不进行修改
        for (int i = 1; i < colArr.length; i++) {
            sb.append(colArr[i].substring(0, 1).toUpperCase()).append(colArr[i].substring(1));
        }
        return sb.toString();
    }

    /**
     * 判读目标字符串是否在数组中存在
     *
     * @param src  目标字符
     * @param strs 匹配数组
     *
     * @return
     */
    public static boolean isExists(String src, String[] strs) {
        boolean flag = false;
        if (StringHelper.isEmpty(src) || strs == null) {
            return flag;
        }

        for (String str : strs) {
            flag = StringUtils.equals(src, str);
            if (flag) {
                break;
            }
        }
        return flag;
    }

    public static void main(String[] args) {
//        System.out.println("isExists：" + StringHelper.isNotEmpty(null));
    }
    
    /**
     * 格式话字符串，去除空格，回车符号
     *
     * @param str 开始时间控件
     * @author 余超
     * @return 纯字符串
     */
    public static String StringReplace(String str) {
        String StringReplace = "";
        if (StringUtils.isNotEmpty(str)) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            StringReplace = m.replaceAll("");
            StringReplace=StringReplace.replace("<br>","");
        }
        return StringReplace;
    }
}

/**  
 * FileName:StringTools.java
 * @Description: 截取的字符串工具类 
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

/**
 * 
 * Description: 截取的字符串工具类 
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-5-10 下午5:09:26  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-5-10     李云龙                      1.0         1.0 Version
 */
public class StringTools {
	/**
     * 根据指定符号拆分字符
     *
     * @param str 需截取的字符串
     * @param sep 分隔符
     * @return 字符数据
     */
    public static String[] sptString(String str,String sep) {
        String[] array = new String[0];
        if (StringHelper.isNotEmpty(str, sep)) {
            array = str.split(sep);
            return array;
        }
        return array;
    }

}

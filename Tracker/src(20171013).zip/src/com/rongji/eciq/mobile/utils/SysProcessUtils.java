/**  
 * FileName:SysProcessUtils.java
 * @Description: 流程查询处理公共类
 * Company       rongji
 * @version      1.0
 * @author:      李云龙  
 * @version:     1.0
 * Createdate:   2017-4-21 上午10:21:04  
 *  
 */  
package com.rongji.eciq.mobile.utils;

import java.util.Date;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.stereotype.Service;
import com.rongji.eciq.mobile.context.CommContext;
import com.rongji.eciq.mobile.context.DeclContext;
import com.rongji.eciq.mobile.entity.DclIoDeclEntity;
import com.rongji.eciq.mobile.entity.DclPackDeclEntity;
import com.rongji.eciq.mobile.entity.SysProcessTimeEntity;
import com.rongji.eciq.mobile.entity.UserInfo;
/**
 * 
 * Description: 流程查询处理公共类
 * Copyright:   Copyright (c)2017 
 * Company:     rongji  
 * @author:     李云龙  
 * @version:    1.0  
 * Create at:   2017-4-21 下午5:55:54  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * 2017-4-21      李云龙                      1.0         1.0 Version
 */
@Service
public class SysProcessUtils {
	/**
     * 根据报检单号和环节节点构造数据
     *
     * @param declNo
     * @param processNode
     * @param sysProcessTimeEntity
     *
     * @return
     */
	
    public SysProcessTimeEntity buildSysProcessTimeEntity(String declNo, String processNode, UserInfo user) {
        String declType = DeclNoUtils.getDeclType(declNo);
        if (StringUtils.equals(DeclContext.DECL_TYPE_IN, declType) || StringUtils.equals(DeclContext.DECL_TYPE_OUT, declType) || StringUtils.equals(DeclContext.DECL_TYPE_GOODS, declType)) {
            SysProcessTimeEntity sysProcessTimeEntity = getSysProcessTimeEntityByDeclNo(declNo);
            DclIoDeclEntity declEntity =getDeclIoDecl(declNo);
            if (sysProcessTimeEntity != null) {
                sysProcessTimeEntity.setDeclNo(declNo);
                sysProcessTimeEntity.setDeclType(DeclNoUtils.getDeclType(declNo));
                String orgCode = "";
                if (user != null && StringUtils.isNotEmpty(user.getCompanyCode()) && (!StringUtils.equals("auto", user.getUserCode()))) {
                    //获取当前登录人信息作为机构代码
                    orgCode = user.getBusinessOrgCode();
                } else if (user != null && StringUtils.equals("auto", user.getUserCode())&& StringUtils.isNotEmpty(user.getCompanyCode())) {
                    orgCode = user.getCompanyCode();
                } else {
                    //机审直接命中待归档结论的报检单，由于获取不到用户信息，直接获取报检单的主施检机构作为机构代码
                    orgCode = getOrgCode(declNo);
                }
                sysProcessTimeEntity.setOrgCode(orgCode);
                sysProcessTimeEntity.setOperDate(new Date());
                sysProcessTimeEntity.setFalgArchive(CommContext.ARCHIVE_0);
                if (declEntity != null) {
                    sysProcessTimeEntity.setDeclDate(declEntity.getDeclDate());
                } else {
                    if (StringUtils.equals(DeclContext.DECL_TYPE_GOODS, declType)) {
                        DclPackDeclEntity packDeclEntity = getDeclPackDecl(declNo);
                        if (packDeclEntity != null) {
                            sysProcessTimeEntity.setDeclDate(packDeclEntity.getDeclDate());
                        }
                    }
                }
                if (StringUtils.isNotEmpty(processNode)) {
                    //手工报检
                    if (StringUtils.equals(CommContext.SELF_DECL, processNode)) {
                        sysProcessTimeEntity.setSelfDeclDate(new Date());
                    } else if (StringUtils.equals(CommContext.AUTO_DECL, processNode)) {//机审
                        sysProcessTimeEntity.setAutoDeclDate(new Date());
                    } else if (StringUtils.equals(CommContext.SELF_CHECK, processNode)) {//人审
                        sysProcessTimeEntity.setSelfCheckDate(new Date());
                    } else if (StringUtils.equals(CommContext.DECL, processNode)) {//报检受理
                        sysProcessTimeEntity.setDeclAcceptDate(new Date());
                    } else if (StringUtils.equals(CommContext.SUBMENU, processNode)) {//分单
                        sysProcessTimeEntity.setSubmenuDate(new Date());
                    } else if (StringUtils.equals(CommContext.INS, processNode)) {// 施检审单
                        sysProcessTimeEntity.setInsDate(new Date());
                    } else if (StringUtils.equals(CommContext.SPOT, processNode)) {//现场查验
                        sysProcessTimeEntity.setSpotDate(new Date());
                    } else if (StringUtils.equals(CommContext.SEND, processNode)) {//送检
                        sysProcessTimeEntity.setSendDate(new Date());
                    } else if (StringUtils.equals(CommContext.EVALUATE, processNode)) {//综合评定
                        sysProcessTimeEntity.setEvaluateDate(new Date());
                    } else if (StringUtils.equals(CommContext.UNQULIFIED, processNode)) {//不合格
                        sysProcessTimeEntity.setUnqulifiedDate(new Date());
                    } else if (StringUtils.equals(CommContext.QULIFIED, processNode)) {//合格
                        sysProcessTimeEntity.setQulifiedDate(new Date());
                    } else if (StringUtils.equals(CommContext.DRAFT, processNode)) {//拟稿
                        sysProcessTimeEntity.setDraftDate(new Date());
                    } else if (StringUtils.equals(CommContext.ATTESTATION, processNode)) {//核签
                        sysProcessTimeEntity.setAttestationDate(new Date());
                    } else if (StringUtils.equals(CommContext.ACQUIR, processNode)) {//收单
                        sysProcessTimeEntity.setAcquirDate(new Date());
                    } else if (StringUtils.equals(CommContext.RECHECK, processNode)) {//复审
                        sysProcessTimeEntity.setRecheckDate(new Date());
                    } else if (StringUtils.equals(CommContext.MAKE, processNode)) {//缮制
                        sysProcessTimeEntity.setMakeDate(new Date());
                    } else if (StringUtils.equals(CommContext.VERIFY, processNode)) {//审校
                        sysProcessTimeEntity.setVerifyDate(new Date());
                    } else if (StringUtils.equals(CommContext.SIGN, processNode)) {//签发
                        sysProcessTimeEntity.setSignDate(new Date());
                    } else if (StringUtils.equals(CommContext.DOC, processNode)) {//归档
                        sysProcessTimeEntity.setDocDate(new Date());
                    } else if (StringUtils.equals(CommContext.CANCEL_DOC, processNode)) {//归档解除
                        sysProcessTimeEntity.setCancelDocDate(new Date());
                    } else if (StringUtils.equals(CommContext.CUST_CLEARANCE, processNode)) {//通关
                        sysProcessTimeEntity.setCustClearanceDate(new Date());
                    } else if (StringUtils.equals(CommContext.PASS, processNode)) {//放行
                        sysProcessTimeEntity.setPassDate(new Date());
                    } else if (StringUtils.equals(CommContext.CHARG, processNode)) {//计收费
                        sysProcessTimeEntity.setChargDate(new Date());
                    }
                }
                return sysProcessTimeEntity;
            } else {//构造一个新的实体
                SysProcessTimeEntity processTimeEntity = new SysProcessTimeEntity();
                processTimeEntity.setDeclNo(declNo);
                processTimeEntity.setDeclType(DeclNoUtils.getDeclType(declNo));
                String orgCode = "";
                if (user != null && StringUtils.isNotEmpty(user.getCompanyCode())&&!"auto".equals(user.getUserCode())) {
                    //获取当前登录人信息作为机构代码
                    orgCode = user.getBusinessOrgCode();
                } else if(user!=null&&StringUtils.isNotEmpty(user.getCompanyCode())&&"auto".equals(user.getUserCode())){
                	orgCode = user.getCompanyCode();//王惠峰增加判断，施检初始化异步时调用
                }else {
                    //机审直接命中待归档结论的报检单，由于获取不到用户信息，直接获取报检单的主施检机构作为机构代码
                    orgCode = getOrgCode(declNo);
                }
                processTimeEntity.setOrgCode(orgCode);
                processTimeEntity.setOperDate(new Date());
                processTimeEntity.setFalgArchive(CommContext.ARCHIVE_0);
                if (declEntity != null) {
                    processTimeEntity.setDeclDate(declEntity.getDeclDate());
                } else {
                    if (StringUtils.equals(DeclContext.DECL_TYPE_GOODS, declType)) {
                        DclPackDeclEntity packDeclEntity = getDeclPackDecl(declNo);
                        if (packDeclEntity != null) {
                            processTimeEntity.setDeclDate(packDeclEntity.getDeclDate());
                        }
                    }
                }
                if (StringUtils.isNotEmpty(processNode)) {
                    //手工报检
                    if (StringUtils.equals(CommContext.SELF_DECL, processNode)) {
                        processTimeEntity.setSelfDeclDate(new Date());
                    } else if (StringUtils.equals(CommContext.AUTO_DECL, processNode)) {//机审
                        processTimeEntity.setAutoDeclDate(new Date());
                    } else if (StringUtils.equals(CommContext.SELF_CHECK, processNode)) {//人审
                        processTimeEntity.setSelfCheckDate(new Date());
                    } else if (StringUtils.equals(CommContext.DECL, processNode)) {//报检受理
                        processTimeEntity.setDeclAcceptDate(new Date());
                    } else if (StringUtils.equals(CommContext.SUBMENU, processNode)) {//分单
                        processTimeEntity.setSubmenuDate(new Date());
                    } else if (StringUtils.equals(CommContext.INS, processNode)) {// 施检审单
                        processTimeEntity.setInsDate(new Date());
                    } else if (StringUtils.equals(CommContext.SPOT, processNode)) {//现场查验
                        processTimeEntity.setSpotDate(new Date());
                    } else if (StringUtils.equals(CommContext.SEND, processNode)) {//送检
                        processTimeEntity.setSendDate(new Date());
                    } else if (StringUtils.equals(CommContext.EVALUATE, processNode)) {//综合评定
                        processTimeEntity.setEvaluateDate(new Date());
                    } else if (StringUtils.equals(CommContext.UNQULIFIED, processNode)) {//不合格
                        processTimeEntity.setUnqulifiedDate(new Date());
                    } else if (StringUtils.equals(CommContext.QULIFIED, processNode)) {//合格
                        processTimeEntity.setQulifiedDate(new Date());
                    } else if (StringUtils.equals(CommContext.DRAFT, processNode)) {//拟稿
                        processTimeEntity.setDraftDate(new Date());
                    } else if (StringUtils.equals(CommContext.ATTESTATION, processNode)) {//核签
                        processTimeEntity.setAttestationDate(new Date());
                    } else if (StringUtils.equals(CommContext.ACQUIR, processNode)) {//收单
                        processTimeEntity.setAcquirDate(new Date());
                    } else if (StringUtils.equals(CommContext.RECHECK, processNode)) {//复审
                        processTimeEntity.setRecheckDate(new Date());
                    } else if (StringUtils.equals(CommContext.MAKE, processNode)) {//缮制
                        processTimeEntity.setMakeDate(new Date());
                    } else if (StringUtils.equals(CommContext.VERIFY, processNode)) {//审校
                        processTimeEntity.setVerifyDate(new Date());
                    } else if (StringUtils.equals(CommContext.SIGN, processNode)) {//签发
                        processTimeEntity.setSignDate(new Date());
                    } else if (StringUtils.equals(CommContext.DOC, processNode)) {//归档
                        processTimeEntity.setDocDate(new Date());
                    } else if (StringUtils.equals(CommContext.CANCEL_DOC, processNode)) {//归档解除
                        processTimeEntity.setCancelDocDate(new Date());
                    } else if (StringUtils.equals(CommContext.CUST_CLEARANCE, processNode)) {//通关
                        processTimeEntity.setCustClearanceDate(new Date());
                    } else if (StringUtils.equals(CommContext.PASS, processNode)) {//放行
                        processTimeEntity.setPassDate(new Date());
                    } else if (StringUtils.equals(CommContext.CHARG, processNode)) {//计收费
                        processTimeEntity.setChargDate(new Date());
                    }
                }
                return processTimeEntity;
            }
        }
        return null;
    }
    
    
    /**
     * 根据报检单号查询是否在流程时间查询表中存在
     *
     * @param em     数据连接
     * @param declNo 报价单号
     *
     * @return
     */
    @Autowired
	HibernateTemplate chgHibernateTemplate;
    public SysProcessTimeEntity getSysProcessTimeEntityByDeclNo(String declNo) {
        String sql = "select e from SysProcessTimeEntity e where e.declNo ='"+declNo+"'";
        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        Query query = session.createQuery(sql.toString()); 
        List<SysProcessTimeEntity> list = query.list();
        session.close();
        if (CollectionUtils.isNotEmpty(list) && list.size() > 0) {
            return list.get(0);
        }
        return null;
    }
    
    /**
     * 根据报检单号查询报检信息
     *
     * @param em
     * @param declNo 报检单号
     *
     * @return
     */
    public DclIoDeclEntity getDeclIoDecl(String declNo) {
        String sql = "select e from DclIoDeclEntity e where e.declNo ='"+declNo+"'";
        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        Query query = session.createQuery(sql.toString()); 
        List<DclIoDeclEntity> list = query.list();
        session.close();
        if (CollectionUtils.isNotEmpty(list) && list.size() > 0) {
            return list.get(0);
        }
        return null;
    }
    
    public  String getOrgCode(String declNo) {
        //区分出入境 包装
        if (!DeclContext.DECL_TYPE_GOODS.equals(DeclNoUtils.getDeclType(declNo))) {
            //出入境报检
            return getOrgCodeByDeclNo(declNo);
        } else {
            //包装报检
            return getOrgCodeByDeclNo4pack(declNo);
        }
    }
    
    
    /**
     * 根据报检号，获得施检机构代码
     *
     * @param declNo 报检号
     *
     * @return 施检机构代码
     */
    public String getOrgCodeByDeclNo(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "SELECT A.INSP_ORG_CODE FROM DCL_IO_DECL A WHERE A.DECL_NO ='"+declNo+"'";
        Query query=session.createSQLQuery(sql);
        List<String> list = query.list();
        session.close();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        } else {
            return String.valueOf(list.get(0));
        }
    }
    
    /**
     * 根据报检号，获得施检机构代码 包装报检
     *
     * @param declNo 报检号
     *
     * @return 施检机构代码
     */
    public String getOrgCodeByDeclNo4pack( String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "SELECT A.INSP_ORG_CODE FROM DCL_PACK_DECL A WHERE A.DECL_NO ='"+declNo+"'";
        Query query = session.createSQLQuery(sql);
        List<String> list = query.list();
        session.close();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        } else {
            return String.valueOf(list.get(0));
        }
    }
    
    
    /**
     * 根据报检单号查询报检信息
     *
     * @param em
     * @param declNo 报检单号
     *
     * @return
     */
    public  DclPackDeclEntity getDeclPackDecl(String declNo) {
        String sql = "select e from DclPackDeclEntity e where e.declNo ='"+declNo+"'";
        Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        Query query = session.createQuery(sql.toString()); 
        List<DclPackDeclEntity> list = query.list();
        session.close();
        if (CollectionUtils.isNotEmpty(list) && list.size() > 0) {
            return list.get(0);
        }
        
        return null;
    }
    
    /**
     * 获得施检部门代码
    * <p>描述:</p>
    * @param declNo
    * @return
    * @author 李云龙
     */
    public  String getDeptCode(String declNo) {
        //区分出入境 包装
        if (DeclNoUtils.checkOutDeclType(declNo)
                ||DeclNoUtils.checkInDeclType(declNo)) {
            //出入境报检
            return getDeptCodeByDeclNo4io(declNo);
        } else if (DeclNoUtils.checkGoodsDeclType(declNo)) {
            //包装报检
            return getDeptCodeByDeclNo4pack(declNo);
        } else if (DeclNoUtils.checkContainerDeclType(declNo)) {
            //集装箱报检
            return  getDeptCodeByDeclNo4cont(declNo);
        }
        return null;
    }
    
    
    /**
     * 根据报检号，获得施检部门代码 出入境报检
     *
     * @param declNo 报检号
     *
     * @return 施检机构代码
     * 
     */
    public String getDeptCodeByDeclNo4io(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "SELECT A.EXC_INSP_DEPT_CODE FROM DCL_IO_DECL A WHERE A.DECL_NO='"+declNo+"'";
        Query query =session.createSQLQuery(sql);
        List<String> list = query.list();
        session.close();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        } else {
            return String.valueOf(list.get(0));
        }
    }
    
    
    /**
     * 根据报检号，获得施检部门代码 集装箱报检
     *
     * @param declNo 报检号
     *
     * @return 施检机构代码
     */
    public String getDeptCodeByDeclNo4pack(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "SELECT A.EXC_INSP_DEPT_CODE FROM DCL_PACK_DECL A WHERE A.DECL_NO  ='"+declNo+"'";
        Query query = session.createSQLQuery(sql);
        List<String> list = query.list();
        session.close();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        } else {
            return String.valueOf(list.get(0));
        }
    }
    
    /**
     * 根据报检号，获得施检部门代码 集装箱报检
     *
     * @param declNo 报检号
     *
     * @return 施检机构代码
     * add by TK
     */
    public String getDeptCodeByDeclNo4cont(String declNo) {
    	Session session=SessionFactoryUtils.getSession(chgHibernateTemplate.getSessionFactory(), true);
        String sql = "SELECT A.EXC_INSP_DEPT_CODE FROM DCL_CONT A WHERE A.CONT_DECL_NO ='"+declNo+"'";
        Query query = session.createSQLQuery(sql);
        List<String> list = query.list();
        session.close();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        } else {
            return String.valueOf(list.get(0));
        }
    }
    

}

/**  
 * FileName: ThreadHttpModelUtils.java    
 * @Description: 多线程请求模拟
 * Company       rongji
 * @version      1.0
 * @author:      吴有根  
 * @version:     1.0
 * Createdate:   2017年5月19日 上午10:47:44  
 *  
 */
package com.rongji.eciq.mobile.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;


/**
 * Description: 多线程请求模拟
 * Copyright: Copyright (c)2017 
 * Company: rongji
 * @author: 吴有根
 * @version: 1.0 
 * Create at: 2017年5月19日 上午10:47:44
 * Modification History: 
 * Date    			Author    Version      Description
 * ------------------------------------------------------------------
 * 2017-05-19 		吴有根 	  1.0 		   1.0 Version
 */

public class ThreadHttpModelUtils {
	
	private static int thread_num=1;//并发线程控制数
	private static int client_num=2000;//用户请求数
	
	private ThreadHttpModelUtils(){}
	
	public static void main(String[] args) {

		ExecutorService executor = Executors.newCachedThreadPool();
		final Semaphore semap = new Semaphore(thread_num);

		for (int index = 0; index < client_num; index++) {
			final int No = index;
			Runnable run = new Runnable() {
				@Override
				public void run() {
					try {
						// 获取许可
						semap.acquire();
						System.out.println("Thread:" + No);
					//	testchangeDeclNoToLong();
						testinitSceneCheck();
						semap.release();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			
			executor.execute(run);
		}

		//退出线程池
		executor.shutdown();
	}
	
	
	/**
	 * 
	* <p>描述:测试短号变长号</p>
	* @author 吴有根
	 */
	public static void testchangeDeclNoToLong(){
		Map<String, String> parameters=new HashMap<String, String>();
		parameters.put("loginUser", "1100000036");
		parameters.put("hexCode", "EFNBy3zEELygxKIxAPfWCA==");
		parameters.put("receiverDocCode", "1100000036");
		parameters.put("declNo", "2-127");
		parameters.put("expImpFlag", "2");
		long t1=System.currentTimeMillis();
		String result=sendGet("http://localhost:8080/eciq_app_server/insp/scene/changeDeclNoToLong", parameters);
		long t2=System.currentTimeMillis();
		System.out.println("请求响应时间:"+(t2-t1)+"ms,返回的json:"+result);
	}
	
	
	
	/**
	 * 
	* <p>描述:现场查验-现场查验-货物、查验项目信息展示</p>
	* @author 吴有根
	 */
	public static void testinitSceneCheck() {
		// http://localhost:8080/eciq_app_server/insp/scene/initSceneCheck?expImpFlag=1&exeInspOrgCode=1100000402&receiverDocCode=1100000036&hexCode=3de4c781d2ddc7fccbd055b265d30dd2&loginUser=1100000036&declNo=116000000313361

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("loginUser", "1100000036");
		parameters.put("hexCode", "EFNBy3zEELygxKIxAPfWCA==");
		///////
		parameters.put("exeInspOrgCode", "1100000402");
		parameters.put("receiverDocCode", "1100000036");
		parameters.put("declNo", "116000000313361");
		parameters.put("expImpFlag", "1");
		long t1 = System.currentTimeMillis();
		String result = sendGet("http://localhost:8080/eciq_app_server/insp/scene/initSceneCheck", parameters);
//		String result = sendGet("http://222.249.237.28:8099/eciq_app_server/insp/scene/initSceneCheck", parameters);
		long t2 = System.currentTimeMillis();
		System.out.println("请求响应时间:" + (t2 - t1) + "ms,返回的json:" + result);

	}
	

	/**
	 * 发送GET请求
	 * 
	 * @param url
	 *            目的地址
	 * @param parameters
	 *            请求参数，Map类型。
	 * @return 远程响应结果
	 */
	public static String sendGet(String url, Map<String, String> parameters) {

		String result = "";// 返回的结果
		BufferedReader in = null;// 读取响应输入流
		StringBuffer sb = new StringBuffer();// 存储参数
		String params = "";// 编码之后的参数
		try {
			// 编码请求参数
			if (parameters.size() == 1) {
				for (String name : parameters.keySet()) {
					sb.append(name).append("=").append(java.net.URLEncoder.encode(parameters.get(name), "UTF-8"));
				}
				params = sb.toString();
			} else {
				for (String name : parameters.keySet()) {
					sb.append(name).append("=").append(java.net.URLEncoder.encode(parameters.get(name), "UTF-8"))
							.append("&");
				}
				String temp_params = sb.toString();
				params = temp_params.substring(0, temp_params.length() - 1);
			}
			String full_url = url + "?" + params;
			System.out.println("完整的URL:"+full_url);
			// 创建URL对象
			java.net.URL connURL = new java.net.URL(full_url);
			// 打开URL连接
			java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) connURL.openConnection();
			// 设置通用属性
			httpConn.setRequestProperty("Accept", "*/*");
			httpConn.setRequestProperty("Connection", "Keep-Alive");
			httpConn.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
			
			// 建立实际的连接
			httpConn.connect();
			// 响应头部获取
			Map<String, List<String>> headers = httpConn.getHeaderFields();
			// 遍历所有的响应头字段
			for (String key : headers.keySet()) {
				//System.out.println(key + "\t:\t" + headers.get(key));
			}
			// 定义BufferedReader输入流来读取URL的响应,并设置编码方式
			in = new BufferedReader(new InputStreamReader(httpConn.getInputStream(), "UTF-8"));
			String line;
			// 读取返回的内容
			while ((line = in.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * 发送POST请求
	 * 
	 * @param url
	 *            目的地址
	 * @param parameters
	 *            请求参数，Map类型。
	 * @return 远程响应结果
	 */
	public static String sendPost(String url, Map<String, String> parameters) {
		String result = "";// 返回的结果
		BufferedReader in = null;// 读取响应输入流
		PrintWriter out = null;
		StringBuffer sb = new StringBuffer();// 处理请求参数
		String params = "";// 编码之后的参数
		try {
			// 编码请求参数
			if (parameters.size() == 1) {
				for (String name : parameters.keySet()) {
					sb.append(name).append("=").append(java.net.URLEncoder.encode(parameters.get(name), "UTF-8"));
				}
				params = sb.toString();
			} else {
				for (String name : parameters.keySet()) {
					sb.append(name).append("=").append(java.net.URLEncoder.encode(parameters.get(name), "UTF-8"))
							.append("&");
				}
				String temp_params = sb.toString();
				params = temp_params.substring(0, temp_params.length() - 1);
			}
			// 创建URL对象
			java.net.URL connURL = new java.net.URL(url);
			// 打开URL连接
			java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) connURL.openConnection();
			// 设置通用属性
			httpConn.setRequestProperty("Accept", "*/*");
			httpConn.setRequestProperty("Connection", "Keep-Alive");
			httpConn.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
			// 设置POST方式
			httpConn.setDoInput(true);
			httpConn.setDoOutput(true);
			// 获取HttpURLConnection对象对应的输出流
			out = new PrintWriter(httpConn.getOutputStream());
			// 发送请求参数
			out.write(params);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应，设置编码方式
			in = new BufferedReader(new InputStreamReader(httpConn.getInputStream(), "UTF-8"));
			String line;
			// 读取返回的内容
			while ((line = in.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
	
	

}

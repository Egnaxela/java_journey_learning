全宋词
---


```sql
sqlite> .tables
ci        ciauthor
sqlite> select count(1) from ci;
21050
sqlite> select count(1) from ciauthor;
1564
sqlite> select * from ci limit 1;
1|导引|和岘|气和玉烛，睿化著鸿明。
缇管一阳生。
郊盛礼燔柴毕，旋轸凤凰城。
森罗仪卫振华缨。
载路溢欢声。
皇图大业超前古，垂象泰阶平。
岁时丰衍，九土乐升平。
睹寰海澄清。
道高尧舜垂衣治，日月并文明。
sqlite> select * from ciauthor limit 1;
1|苏轼|苏轼：(1037-1101)北宋文学家、书画家...
```



